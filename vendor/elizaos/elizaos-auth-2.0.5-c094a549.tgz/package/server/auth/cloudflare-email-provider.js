export class CloudflareEmailProvider {
    config;
    constructor(config) {
        this.config = config;
    }
    async send(to, subject, text, html, options) {
        const { accountId, apiToken, from } = this.config;
        const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/email/sending/send`, {
            method: "POST",
            redirect: "error",
            signal: AbortSignal.timeout(25_000),
            headers: {
                Authorization: `Bearer ${apiToken}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                to: [to],
                from,
                subject,
                text,
                html,
                reply_to: options?.replyTo,
            }),
        });
        if (!response.ok)
            throw new Error("Cloudflare Email Sending rejected send");
        const body = await response.json();
        const result = body?.result;
        const containsRecipient = (list) => Array.isArray(list) && list.includes(to);
        const id = result?.message_id;
        if (body?.success !== true ||
            typeof id !== "string" ||
            !id.trim() ||
            containsRecipient(result?.permanent_bounces) ||
            containsRecipient(result?.suppressed_recipients) ||
            !(containsRecipient(result?.delivered) ||
                containsRecipient(result?.queued))) {
            throw new Error("Cloudflare Email Sending did not accept recipient");
        }
        return { provider: "cloudflare", id };
    }
}
//# sourceMappingURL=cloudflare-email-provider.js.map