import type { EmailDeliveryReceipt, EmailProvider } from "./email-provider.js";
export declare class CloudflareEmailProvider implements EmailProvider {
    private readonly config;
    constructor(config: {
        accountId: string;
        apiToken: string;
        from: string;
    });
    send(to: string, subject: string, text: string, html?: string, options?: {
        replyTo?: string;
    }): Promise<EmailDeliveryReceipt>;
}
//# sourceMappingURL=cloudflare-email-provider.d.ts.map