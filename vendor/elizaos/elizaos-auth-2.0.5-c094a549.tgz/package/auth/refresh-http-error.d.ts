import { ElizaError } from "@elizaos/core/protocol";
import type { OAuthSubscriptionProvider } from "./types.js";
export declare const OAUTH_REFRESH_HTTP_ERROR = "AUTH_OAUTH_REFRESH_HTTP_ERROR";
export declare function createRefreshHttpError(provider: OAuthSubscriptionProvider, response: Response): Promise<ElizaError>;
//# sourceMappingURL=refresh-http-error.d.ts.map