# @elizaos/capacitor-secure-store

Device-only Apple Keychain and Android Keystore storage for Eliza app credentials.

Install workspace dependencies with `bun install` at the repository root.

Build from the repository root:

```bash
bun run --cwd plugins/plugin-native-secure-store build
```

Native storage behavior requires testing on the target Apple or Android device.

Android hosts can bind `SecureStorePlugin` mutation hooks to their existing
credential intent and resident shutdown policy. Reservation occurs before queued
work; only host-selected keys use the asynchronous worker. The shared native
`CredentialIntentFence`, `CredentialMutationConductor` and `CredentialSlotMutation`
keep intent checks, retirement, commit and exact readback in one path. Hosts provide
their locks and service proof. A build without a resident supplies an explicit
absent-runtime port. This does not create an account, provider or second token store.

`KeystoreTextFrame` is a native-only codec for existing
`Base64(IV):Base64(AES-GCM ciphertext/tag)` records. Hosts retain the deployed
alias, storage and access policy; the format has no unlock requirement.
`seal(value, aad)` and `open(frame, aad)` bind a frame to its context, such as a
record name. A bound frame opens only with the same AAD; existing unbound frames
keep using `seal(value)` and `open(frame)`.
It serializes cold key creation across instances and bounds encoded records on
read and write. Native custody tests cover old-writer/new-reader and
new-writer/old-reader compatibility, tampering and concurrent cold use. Use the
authenticated password vault for passwords, not this codec.

Android's device suite verifies the real WebView/Capacitor/Keystore round trip,
activity recreation, ciphertext persistence, deletion, and invalid/corrupt input:

```bash
node packages/app/scripts/android-native-plugins.ts --serial emulator-5554 --plugin plugin-native-secure-store
```

Android bridge instances serialize Keystore key creation and AtomicFile operations
within one process. Recovery includes backup-only values; removal checks base,
backup and pending writes. The existing ciphertext format and account binding
remain compatible. Keystore availability does not assert StrongBox protection.
Device tests use synthetic credentials in an isolated UID and cover complete
262,144-byte values, backup recovery, corruption and concurrent cold key creation.
Inspect the terminal instrumentation result, not only the shell exit status.

The Android `nativeonly` package provides host-configured password custody,
credential persistence, exact-origin autofill validation and one-shot sessions.
These are native APIs; they are not registered Capacitor methods. Hosts retain
picker UI, signer trust, permission declarations and release/debug policy, and
must preserve deployed aliases, AAD and filenames when adopting them. Custody
uses Android API 26+; browser structure parsing requires API 28+. Production
password keys use device authentication by default. The explicit Android 15+
device-unlocked policy below is a separate custody version. The unauthenticated
constructor mode is only for host-restricted synthetic tests. Autofill metadata key strings
retain their existing browser wire protocol identifiers.


`DeviceCredentialSession` owns native Activity challenge/result fencing and absolute
unlock expiry. Reserve an inclusive request-code range; forward activity results,
`onStop`, and destruction, and call `saveState` from `onSaveInstanceState`. Pass that
Bundle back on creation. Only the request-code watermark is saved, never a grant or
continuation. Missing/corrupt restored counters fail closed. Hosts supply localized
views/prompts and durations. Keep the `locked` listener presentation-only: do not
call `lock()` recursively from it. `authenticated()` rechecks elapsed time even if
Android delays timer delivery. This UI grant does not replace Keystore enforcement.

Run `bun run --cwd plugins/plugin-native-secure-store test:native-session` with a
JDK for deterministic grant tests. The Android DeviceCredentialSession instrumented
tests use real Bundle/Handler lifecycle plumbing and a synthetic challenge port;
they do not establish real device credential or biometric acceptance.

`PasswordAutofillCompletion` filters native vault metadata by the validated request
origin and publishes Android Autofill responses exactly once. Invoke it on the
main thread with a live authentication/browser-trust predicate, product RemoteViews
and a result publisher. It checks admission before and after vault access; the
current session is consumed before publishing, including when the publisher throws.
No secret is returned through Capacitor. Hosts still own picker UI and lifecycle
cancellation. Instrumentation uses synthetic records and field IDs, not a trusted
Chromium integration.

`NativeDeadlineTimer` owns main-thread expiry callbacks with elapsed-time checks,
replacement/cancellation fencing and terminal close. Use `after` for a display
duration or `watch(session::remainingMillis, callback)` for an existing Autofill
request; call `refresh` on resume and close on destruction. `watch` may expire
synchronously. Hosts retain masking/layout and selected display durations. Cancel
on screen replacement or stop as appropriate; callbacks are not persisted.

`PasswordAutofillOffer.create` constructs native Android authentication offers from
verified browser structures. Supply the product browser-trust predicate, explicit
picker Activity, URI scheme and RemoteViews factory; publish its nullable response
once through the OS FillCallback. It invalidates prior requests, binds cancellation,
uses immutable one-shot PendingIntents and revokes partially constructed offers on
failure. Hosts retain localized save rejection and picker UI. Instrumentation covers
real response parcelables with synthetic requests; it does not establish trusted
Chromium or device credential acceptance.

`JsonCredentialSlots` provides native-only JSON slot storage for hosts with the
version/IV-length AES-GCM frame. Hosts supply a no-backup directory, Keystore
alias and per-slot UTF-8 byte limits; renderer access policy remains with the
host. Slot filenames and AAD are the lowercase SHA-256 hex digest of the UTF-8
slot name. Preserve all deployed identities when adopting this helper. It does
not share the single-file `RuntimeCredentialStore` frame. A process-wide lock
covers cold key creation, reads, writes, removal and compare-and-exchange across
instances; writers in separate Android processes need separate coordination.
A size refusal throws `JsonCredentialSlots.CapacityException` before any byte
is written. A host that lowers a slot limit can pass a second, retained limit for
data that an older limit admitted. That slot stays readable, and a write that
does not make it larger is accepted until it fits the new limit again.
The device suite checks old-frame compatibility, backup recovery, tampering,
byte limits, lowered limits, concurrent cold writes and competing admissions
with synthetic JSON.

`CredentialAccessSession.currentTicket()` binds queued work to the grant that admitted it.
Check `authenticated(ticket)` before use. `lock(ticket)` cancels only that owner; an old
Activity cannot revoke a newer challenge or grant. The host must serialize access to the session.

`PasswordVaultStore.KeyPolicy` selects the vault key's user-authentication window and whether
strong biometrics are accepted besides the device credential. The boolean constructor keeps
the deployed `KeyPolicy.LEGACY` (device credential, 120 s); an alias is never reused under a
different policy. `saveEntry`/`entries` add named entries with up to 20 normalized bindings
(`PasswordFacets`: exact HTTPS origins or `android://<sha256>@<package>`); legacy single-origin
records read as one binding, and `list()` still reports the primary web origin. `entries()`
never includes passwords. `PasswordVaultFrame` is the unchanged ciphertext frame, extracted so
it can be tested on a JVM: `bun run --cwd plugins/plugin-native-secure-store test:native-passwords`.

`VerifiedAccountCredentialStore` optionally stores a verified Cloud credential and
owner in one versioned encrypted JSON slot. Supply a new no-backup directory and
alias, plus the lock used for all native owner changes. `read(guard)` returns an
opaque snapshot; `compareExchange(expected, next, guard)` replaces or clears the
whole record only if that snapshot still matches. Both check ownership inside the
lock before and after storage. A failed post-check can follow a committed write;
reconcile using the durable enrollment/revocation receipt. This class validates
shape, not server authenticity: only trusted host verification may supply a record.
No legacy credential slot is read or migrated, no broker route is registered, and
no product policy or encrypted task database is enabled. Java credential strings
cannot be reliably erased from memory. Keep all writers in one Android process.
`TaskDataKeyStore` is a native-only building block for encrypted task storage. It
stores random 256-bit data keys in dedicated `JsonCredentialSlots`, bound to an
exact account ID and stable database ID with length-prefixed UTF-8 identities.
Hosts supply a separate no-backup directory and Keystore alias. `read` returns
null for a missing slot and never creates a data key. Use `createIfAbsent` only
for a new database or migration destination under the database writer lease;
never use it to recover missing custody for an existing database. Corrupt or
unreadable custody fails without replacement. Removal compares a key-generation
ID. Close returned keys and erase caller-owned byte copies after use. Java JSON
and Base64 strings cannot be reliably erased from memory.

`TaskDataKeyStore.perSlot(directory, aliasPrefix, preferStrongBox)` gives each
slot its own Keystore wrapping key (`aliasPrefix` plus the slot digest). StrongBox
is used for new wrapping keys when requested and available, else the default
Keystore. `destroy` crypto-erases one slot: it deletes the Keystore entry first,
then the wrapped copy. A wrapped copy whose entry is gone throws
`WrappingKeyMissingException` and is never replaced; call `destroy` to finish.
`adopt(from, to, databaseId, step)` copies one key generation to another account,
reads it back, runs the host step (for example a file move), and only then erases
the source. A repeat after a stop resumes; a target with a different key is left
unchanged. Reserve a new directory and alias prefix for per-slot custody.

This helper has no renderer bridge and is not enabled by default. It does not
provide a database driver, active-key verification, migration, or complete account
revocation. The host must fence owner changes, close database handles before
removal, and coordinate all writers in one Android process. The wrapping-key
policy is the existing `JsonCredentialSlots` policy, with no fresh-authentication
or device-unlocked claim. A wrapped key does not prove that database files, WAL,
backups, logs, outcomes, or evidence are encrypted. Device instrumentation covers
real Keystore persistence, owner isolation, concurrent creation, stale deletion,
and corruption; compile-only results are not device proof.

`KeyPolicy.deviceUnlocked(context)` is an explicit Android 15+ alternative for a
new custody version. It checks the OS user/device lock and requires a configured
screen lock on every native read/write. Its separate Keystore key has
`unlockedDeviceRequired` without an app authentication window. Earlier Android
versions are refused because of the [documented platform issues](https://developer.android.com/reference/android/security/keystore/KeyGenParameterSpec.Builder#setUnlockedDeviceRequired(boolean)).
Reserve a new alias and no-backup directory; existing authentication-bound aliases
are refused under this policy. An encrypted versioned provenance marker binds
the alias and AAD to the native creation path; existing keys cannot acquire a
marker. Missing, corrupt or copied markers are refused. This is provenance within
trusted native code, not independent Keystore attestation: KeyInfo does not expose
unlockedDeviceRequired. A crash after key creation but before marker commit leaves
the new slot unavailable and the old vault intact for explicit recovery. The
default and legacy policies are unchanged.

`oldStore.migrateToDeviceUnlocked(newStore)` copies one authenticated snapshot,
including IDs/timestamps, through native memory into the new encrypted vault.
It verifies readback and retains the original file/key. Retry accepts an identical
snapshot; a different or corrupt target is refused, never overwritten. The host
must serialize its writer and durably select the new custody version only after
success. This API does not select a host version, remove the old vault, or alter
UI/fill grants. An absent source is an empty snapshot and needs no secret
authentication. Host migration recovery, process death/reboot and physical device
qualification remain separate requirements.
