// Auto-enable check for @elizaos/plugin-coding-tools.
//
// Plugin manifest entry-point — referenced by package.json's
// `elizaos.plugin.autoEnableModule`. Keep this module light: env reads only,
// no service init, no transitive imports of the full plugin runtime. The
// auto-enable engine loads dozens of these per boot.
import type { PluginAutoEnableContext } from "@elizaos/core";

function isFeatureEnabled(
  config: PluginAutoEnableContext["config"],
  key: string,
): boolean {
  const f = (config.features as Record<string, unknown> | undefined)?.[key];
  if (f === true) return true;
  if (f && typeof f === "object" && f !== null) {
    return (f as Record<string, unknown>).enabled !== false;
  }
  return false;
}

function terminalSupportedByEnv(ctx: PluginAutoEnableContext): boolean {
  const env = ctx.env;
  const variant = (env.ELIZA_BUILD_VARIANT ?? "").trim().toLowerCase();
  if (variant === "store") return false;

  const platform = env.ELIZA_PLATFORM?.trim().toLowerCase();
  const mobile =
    platform === "android" ||
    platform === "ios" ||
    Boolean(env.ANDROID_ROOT || env.ANDROID_DATA);
  if (!mobile) return true;

  const mode = (
    env.ELIZA_RUNTIME_MODE ??
    env.RUNTIME_MODE ??
    env.LOCAL_RUNTIME_MODE ??
    ""
  )
    .trim()
    .toLowerCase();
  return platform === "android" && mode === "local-yolo";
}

/**
 * Enable when `config.features.codingTools` is truthy, via the legacy
 * `config.features["coding-agent"]` key, or via `config.features.shell`
 * (the shell services formerly shipped as @elizaos/plugin-shell now live in
 * this plugin).
 */
export function shouldEnable(ctx: PluginAutoEnableContext): boolean {
  return (
    (isFeatureEnabled(ctx.config, "codingTools") ||
      isFeatureEnabled(ctx.config, "coding-agent") ||
      isFeatureEnabled(ctx.config, "shell")) &&
    terminalSupportedByEnv(ctx)
  );
}
