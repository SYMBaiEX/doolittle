package ai.eliza.plugins.calendar;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import org.json.JSONObject;

/**
 * Metadata-only journal; provider owns event text. Unknown operations are never replayed.
 * Statuses: unknown (dispatch may have happened), saved, failed (the provider created no row) and
 * dismissed (the owner retired an unknown row after the provider showed no matching event).
 */
public final class CalendarCreationStore {
 /** Unacknowledged rows at which new creations are refused until receipts are reviewed. */
 static final int MAX_OPEN=1000;
 /** Acknowledged rows kept so a late identical retry still returns its receipt. */
 static final int RETAINED_SETTLED=256;
 /** A definite refusal: nothing was written and no provider effect was attempted. */
 public static final class Full extends IllegalStateException { Full(){super("Too many calendar saves are waiting for review. Check creation receipts, then try again.");} }
 private final String journalName, creationUriPrefix;
 private final String[] bindingFields;
 private static final class State { final String identity; boolean quarantined; String prefix; State(String identity,String prefix){this.identity=identity;this.prefix=prefix;} }
 private static final java.util.Map<String,State> STATES=new java.util.HashMap<>();
 public CalendarCreationStore(CalendarConfiguration configuration){this(configuration.journalName,configuration.creationUriPrefix,null);}
 /** Reuse the same journal protocol with a preserved namespace and ordered provider-field binding. */
 public CalendarCreationStore(String journalName,String creationUriPrefix,String[] bindingFields){
  this.journalName=java.util.Objects.requireNonNull(journalName);this.creationUriPrefix=java.util.Objects.requireNonNull(creationUriPrefix);this.bindingFields=bindingFields==null?null:bindingFields.clone();
 }
 private State state(Context context){
  final String key;
  try{key=new java.io.File(context.getDataDir(),"shared_prefs/"+journalName+".xml").getCanonicalPath();}catch(java.io.IOException failure){throw new IllegalStateException("Calendar journal identity unavailable",failure);}
  String contract=creationUriPrefix+"|"+java.util.Arrays.toString(bindingFields);
  synchronized(STATES){State value=STATES.get(key);if(value==null){value=new State(key,contract);STATES.put(key,value);}else if(!value.prefix.equals(contract))throw new IllegalStateException("Calendar journal identity configuration changed");return value;}
 }

 private SharedPreferences preferences(Context context) {
  if(state(context).quarantined)throw new IllegalStateException("Restart the app after calendar journal persistence failure");
  return context.getSharedPreferences(journalName,Context.MODE_PRIVATE);
 }
 private JSONObject read(Context context)throws Exception {
  JSONObject value=new JSONObject(preferences(context).getString("operations","{}"));
  if(open(value)>MAX_OPEN)throw new IllegalStateException("Calendar operation journal full");
  return value;
 }
 private void write(Context context,JSONObject value) {
  boolean committed=false;
  try{committed=preferences(context).edit().putString("operations",value.toString()).commit();if(!committed)throw new IllegalStateException("Calendar operation persistence failed");}
  finally{if(!committed)state(context).quarantined=true;}
 }
 private String identity(String id) {
  if(id==null||!id.matches("[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"))throw new IllegalArgumentException("Calendar creation identity required");
  return creationUriPrefix+id;
 }
 private String digest(ContentValues values)throws Exception {
  ArrayList<String> keys=new ArrayList<>(bindingFields==null?values.keySet():java.util.Arrays.asList(bindingFields));if(bindingFields==null)Collections.sort(keys);StringBuilder text=new StringBuilder();
  for(String key:keys){String value=values.getAsString(key);text.append(key.length()).append(':').append(key).append(value==null?-1:value.length()).append(':').append(value==null?"":value);}
  byte[] hash=MessageDigest.getInstance("SHA-256").digest(text.toString().getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:hash)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();
 }
 private static JSObject response(String id,JSONObject record)throws Exception {
  JSObject result=new JSObject();result.put("creationId",id);result.put("status",record.optString("status","unknown"));
  if("saved".equals(record.optString("status"))){result.put("id",record.getString("eventId"));result.put("calendarId",record.getString("calendarId"));}
  return result;
 }
 private static int open(JSONObject all)throws Exception {
  int count=0;for(Iterator<String> it=all.keys();it.hasNext();)if(!all.getJSONObject(it.next()).optBoolean("acknowledged"))count++;
  return count;
 }
 /**
  * Removes the oldest acknowledged rows (saved, failed or dismissed) beyond
  * {@link #RETAINED_SETTLED}. Unknown or unacknowledged rows are never removed. Rows order by
  * {@code seq}; legacy rows without one are oldest, in stored order. Returns the next {@code seq}.
  */
 static long retire(JSONObject all)throws Exception {
  ArrayList<String> settled=new ArrayList<>();long next=0;
  for(Iterator<String> it=all.keys();it.hasNext();){
   String id=it.next();JSONObject record=all.getJSONObject(id);next=Math.max(next,record.optLong("seq",-1)+1);
   if(record.optBoolean("acknowledged")&&!"unknown".equals(record.optString("status","unknown")))settled.add(id);
  }
  settled.sort((a,b)->Long.compare(all.optJSONObject(a).optLong("seq",-1),all.optJSONObject(b).optLong("seq",-1)));
  for(int i=0;i<settled.size()-RETAINED_SETTLED;i++)all.remove(settled.get(i));
  return next;
 }
 private static boolean pending(JSONObject all)throws Exception {
  for(Iterator<String> it=all.keys();it.hasNext();)if(!all.getJSONObject(it.next()).optBoolean("acknowledged"))return true;
  return false;
 }
 private boolean reconcile(Context context,String id,JSONObject record)throws Exception {return reconcile(context,id,record,false);}
 /** With {@code strict}, a provider without a cursor throws instead of reading as no match. */
 private boolean reconcile(Context context,String id,JSONObject record,boolean strict)throws Exception {
  if("saved".equals(record.optString("status")))return false;
  String[] defaults={CalendarContract.Events.CALENDAR_ID,CalendarContract.Events.TITLE,CalendarContract.Events.DESCRIPTION,CalendarContract.Events.EVENT_LOCATION,CalendarContract.Events.DTSTART,CalendarContract.Events.DTEND,CalendarContract.Events.EVENT_TIMEZONE};
  String[] bindings=bindingFields==null?defaults:bindingFields;
  String[] fields=new String[bindings.length+1];fields[0]=CalendarContract.Events._ID;System.arraycopy(bindings,0,fields,1,bindings.length);
  String where=CalendarContract.Events.CUSTOM_APP_PACKAGE+"=? AND "+CalendarContract.Events.CUSTOM_APP_URI+"=? AND "+CalendarContract.Events.DELETED+"=0";
  try(Cursor rows=context.getContentResolver().query(CalendarContract.Events.CONTENT_URI,fields,where,new String[]{context.getPackageName(),identity(id)},null)) {
   if(rows==null&&strict)throw new IllegalStateException("Calendar provider returned no cursor");
   if(rows==null||rows.getCount()!=1||!rows.moveToFirst())return false;
   ContentValues actual=new ContentValues();for(int i=1;i<fields.length;i++){if(rows.isNull(i))actual.putNull(fields[i]);else actual.put(fields[i],rows.getString(i));}
   if(!record.getString("argumentHash").equals(digest(actual)))return false;
   record.put("status","saved").put("eventId",Long.toString(rows.getLong(0)));return true;
  }
 }
 private interface PairedWork<T> {T run()throws Exception;}
 private <T> T paired(Context context,CalendarCreationStore other,PairedWork<T> work)throws Exception{
  State own=state(context),peer=other.state(context);
  if(own==peer)throw new IllegalArgumentException("Two distinct calendar journals are required");
  State first=own.identity.compareTo(peer.identity)<0?own:peer,second=first==own?peer:own;
  synchronized(first){synchronized(second){return work.run();}}
 }
 /** One cross-journal admission, including the durable unknown and provider dispatch. */
 public JSObject createUnlessOtherOwns(Context context,String id,ContentValues values,boolean separate,CalendarCreationStore other)throws Exception{
  identity(id);return paired(context,other,()->{if(other.read(context).has(id))throw new IllegalArgumentException("Creation identity belongs to another calendar journal");return createLocked(context,id,values,separate);});
 }
 /** Refuse ambiguous installed receipts without rewriting either journal. */
 public static void acknowledgeEither(Context context,String id,CalendarCreationStore first,CalendarCreationStore second)throws Exception{
  first.identity(id);first.paired(context,second,()->{CalendarCreationStore owner=ownerLocked(context,id,first,second);owner.acknowledgeLocked(context,id);return null;});
 }
 /** {@link #dismiss} for whichever of two journals holds the identity. Returns the final status. */
 public static String dismissEither(Context context,String id,CalendarCreationStore first,CalendarCreationStore second)throws Exception{
  first.identity(id);return first.paired(context,second,()->ownerLocked(context,id,first,second).dismissLocked(context,id));
 }
 private static CalendarCreationStore ownerLocked(Context context,String id,CalendarCreationStore first,CalendarCreationStore second)throws Exception{
  boolean a=first.read(context).has(id),b=second.read(context).has(id);if(a&&b)throw new IllegalStateException("Creation identity exists in both journals");return b?second:first;
 }
 public JSObject create(Context context,String id,ContentValues values,boolean separate)throws Exception {synchronized(state(context)){return createLocked(context,id,values,separate);}}
 private JSObject createLocked(Context context,String id,ContentValues values,boolean separate)throws Exception {
  identity(id);JSONObject all=read(context);String binding=digest(values);
  if(all.has(id)) {
   JSONObject record=all.getJSONObject(id);if(!binding.equals(record.getString("argumentHash")))throw new IllegalArgumentException("Calendar creation identity changed");
   if(reconcile(context,id,record))write(context,all);return response(id,record);
  }
  if(pending(all)&&!separate){JSObject result=new JSObject();result.put("status","pending-creation");return result;}
  if(open(all)>=MAX_OPEN)throw new Full();
  long seq=retire(all); // Retired rows leave in the same commit that adds the new one.
  JSONObject record=new JSONObject().put("argumentHash",binding).put("calendarId",values.getAsString(CalendarContract.Events.CALENDAR_ID)).put("status","unknown").put("acknowledged",false).put("seq",seq);
  all.put(id,record);write(context,all); // Durable unknown must precede the provider effect.
  ContentValues insert=new ContentValues(values);insert.put(CalendarContract.Events.CUSTOM_APP_PACKAGE,context.getPackageName());insert.put(CalendarContract.Events.CUSTOM_APP_URI,identity(id));
  try {
   Uri uri=context.getContentResolver().insert(CalendarContract.Events.CONTENT_URI,insert);
   // A missing row id is the provider's definite answer that it made no row; it is never retried.
   if(uri==null||ContentUris.parseId(uri)<=0){record.put("status","failed").put("acknowledged",true);write(context,all);}
   else if(reconcile(context,id,record))write(context,all);
  }catch(Exception uncertain){/* Persisted unknown survives provider/readback/receipt response loss. */}
  preferences(context); // A failed journal commit must never expose its in-memory receipt.
  return response(id,record);
 }
 public JSObject pendingCreations(Context context)throws Exception {JSObject result=new JSObject();result.put("status","ready");result.put("creations",pendingCreationRows(context));return result;}
 public JSArray pendingCreationRows(Context context)throws Exception {synchronized(state(context)){return pendingCreationsLocked(context);}}
 public boolean hasPending(Context context)throws Exception {synchronized(state(context)){return pending(read(context));}}
 public boolean owns(Context context,String id)throws Exception {synchronized(state(context)){return id!=null&&read(context).has(id);}}
 private JSArray pendingCreationsLocked(Context context)throws Exception {
  JSONObject all=read(context);JSArray pending=new JSArray();boolean changed=false;
  for(Iterator<String> it=all.keys();it.hasNext();) {
   String id=it.next();JSONObject record=all.getJSONObject(id);if(record.optBoolean("acknowledged"))continue;
   try{changed|=reconcile(context,id,record);}catch(Exception unavailable){/* Keep unknown; query failure never authorizes insertion. */}
   pending.put(response(id,record));
  }
  if(changed)write(context,all);return pending;
 }
 public void acknowledge(Context context,String id)throws Exception {synchronized(state(context)){acknowledgeLocked(context,id);}}
 private void acknowledgeLocked(Context context,String id)throws Exception {
  identity(id);JSONObject all=read(context);JSONObject record=all.getJSONObject(id);
  if(!"saved".equals(record.optString("status")))throw new IllegalStateException("Unconfirmed calendar creation cannot be cleared");
  record.put("acknowledged",true);write(context,all);
 }
 /**
  * Owner-driven exit for an unknown creation. Reads the provider now: a matching event settles
  * the row as saved; any other answer settles it as dismissed. A failed query refuses. Nothing is
  * inserted or retried. Returns the final status.
  */
 public String dismiss(Context context,String id)throws Exception {synchronized(state(context)){return dismissLocked(context,id);}}
 private String dismissLocked(Context context,String id)throws Exception {
  identity(id);JSONObject all=read(context);JSONObject record=all.getJSONObject(id);
  if(record.optBoolean("acknowledged")||!"unknown".equals(record.optString("status","unknown")))throw new IllegalStateException("Only an unconfirmed calendar creation can be dismissed");
  if(!reconcile(context,id,record,true))record.put("status","dismissed");
  record.put("acknowledged",true);write(context,all);return record.getString("status");
 }
}
