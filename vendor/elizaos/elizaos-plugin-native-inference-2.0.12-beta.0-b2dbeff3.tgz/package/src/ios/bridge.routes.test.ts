/**
 * Route-table tests for the iOS bridge's direct-core shims — the view-backing
 * endpoints (memories, transcripts, browser workspace) that would otherwise 404
 * on device because the agent's node:http route handlers / plugin-local-inference
 * routes are not wired into the in-process iOS runtime.
 *
 * Each test drives `handleDirectCoreRoute` end-to-end against a real in-memory
 * runtime (the same core memory APIs the production handlers call), asserting
 * the exact response shapes the UI consumes.
 */

import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  compareMemoryIds,
  type IAgentRuntime,
  type Memory,
  type Room,
  type UUID,
} from "@elizaos/core";
import type { TranscriptSegment } from "@elizaos/core/protocol";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { MobileFsGlobals } from "../shared/fs-sandbox.ts";
import {
  handleDirectCoreRoute,
  type IosBridgeBackend,
  resetIosBrowserWorkspace,
  restoreIosConversations,
} from "./bridge.ts";

const AGENT_ID = "00000000-0000-0000-0000-0000000000aa" as UUID;
/** A minimal in-memory runtime implementing the memory APIs the shims use. */
function createFakeRuntime(): IAgentRuntime {
  const tables = new Map<string, Memory[]>();
  const runtime = {
    agentId: AGENT_ID,
    character: { name: "TestAgent" },
    async getMemories(params: {
      tableName: string;
      roomId?: UUID;
      limit?: number;
      count?: number;
      orderBy?: "createdAt";
      orderDirection?: "asc" | "desc";
      offset?: number;
      cursor?: {
        createdAt: number;
        id: UUID;
      };
      end?: number;
      textContains?: string;
    }): Promise<Memory[]> {
      let rows = [...(tables.get(params.tableName) ?? [])];
      if (params.roomId) {
        rows = rows.filter((m) => m.roomId === params.roomId);
      }
      if (params.end !== undefined) {
        const end = params.end;
        rows = rows.filter((m) => (m.createdAt ?? 0) <= end);
      }
      if (params.textContains) {
        const needle = params.textContains.toLowerCase();
        rows = rows.filter((m) =>
          (
            (
              m.content as {
                text?: string;
              }
            ).text ?? ""
          )
            .toLowerCase()
            .includes(needle),
        );
      }
      const dir = params.orderDirection === "asc" ? 1 : -1;
      rows.sort((a, b) => {
        const timeOrder = dir * ((a.createdAt ?? 0) - (b.createdAt ?? 0));
        return timeOrder !== 0
          ? timeOrder
          : dir * compareMemoryIds(a.id ?? "", b.id ?? "");
      });
      if (params.cursor) {
        const cursor = params.cursor;
        rows = rows.filter((row) => {
          const createdAt = row.createdAt ?? 0;
          return (
            createdAt < cursor.createdAt ||
            (createdAt === cursor.createdAt &&
              compareMemoryIds(row.id ?? "", cursor.id) < 0)
          );
        });
      }
      const cap = params.count ?? params.limit;
      const offset = params.offset ?? 0;
      return typeof cap === "number"
        ? rows.slice(offset, offset + cap)
        : rows.slice(offset);
    },
    async countMemories(params: { tableName?: string }): Promise<number> {
      return (tables.get(params.tableName ?? "messages") ?? []).length;
    },
    async getMemoryById(id: UUID): Promise<Memory | null> {
      for (const rows of tables.values()) {
        const found = rows.find((m) => m.id === id);
        if (found) return found;
      }
      return null;
    },
    async createMemory(memory: Memory, tableName: string): Promise<UUID> {
      const rows = tables.get(tableName) ?? [];
      rows.push(memory);
      tables.set(tableName, rows);
      return memory.id as UUID;
    },
    async updateMemory(
      memory: Partial<Memory> & {
        id: UUID;
      },
    ): Promise<boolean> {
      for (const rows of tables.values()) {
        const idx = rows.findIndex((m) => m.id === memory.id);
        if (idx >= 0) {
          rows[idx] = { ...rows[idx], ...memory } as Memory;
          return true;
        }
      }
      return false;
    },
    async deleteMemory(id: UUID): Promise<void> {
      for (const rows of tables.values()) {
        const idx = rows.findIndex((m) => m.id === id);
        if (idx >= 0) rows.splice(idx, 1);
      }
    },
  } as unknown as IAgentRuntime;
  return runtime;
}
function makeBackend(runtime: IAgentRuntime): IosBridgeBackend {
  return {
    runtime,
    dispatchRoute: async () => null,
    cloudInferenceRejection: () => null,
    conversations: new Map(),
    close: async () => {},
  };
}
function jsonBody(payload: unknown): {
  body: string;
} {
  return { body: JSON.stringify(payload) };
}
async function call(
  backend: IosBridgeBackend,
  method: string,
  rawPath: string,
  body?: unknown,
): Promise<{
  status: number;
  json: Record<string, unknown>;
}> {
  const res = await handleDirectCoreRoute(
    backend,
    method,
    rawPath,
    body === undefined ? {} : jsonBody(body),
  );
  if (!res) throw new Error(`route returned null: ${method} ${rawPath}`);
  return { status: res.status, json: JSON.parse(res.body) };
}
const seg = (
  text: string,
  endMs = 1000,
  speaker = "Speaker 1",
): TranscriptSegment => ({
  id: `seg-${Math.random().toString(36).slice(2)}`,
  speakerLabel: speaker,
  startMs: 0,
  endMs,
  text,
  words: [],
});
describe("iOS bridge — memories view routes", () => {
  let backend: IosBridgeBackend;
  let runtime: IAgentRuntime;
  beforeEach(() => {
    runtime = createFakeRuntime();
    backend = makeBackend(runtime);
  });
  async function seedMemory(
    table: string,
    text: string,
    createdAt: number,
    source?: string,
  ): Promise<void> {
    await runtime.createMemory(
      {
        id: crypto.randomUUID() as UUID,
        entityId: AGENT_ID,
        roomId: AGENT_ID,
        agentId: AGENT_ID,
        createdAt,
        content: source ? { text, source } : { text },
      } as Memory,
      table,
    );
  }
  it("feed returns newest-first browse items with the UI shape", async () => {
    await seedMemory("messages", "oldest", 1000);
    await seedMemory("facts", "newest", 3000, "user");
    await seedMemory("memories", "middle", 2000);
    const { status, json } = await call(backend, "GET", "/api/memories/feed");
    expect(status).toBe(200);
    const memories = json.memories as Array<Record<string, unknown>>;
    expect(memories.map((m) => m.text)).toEqual(["newest", "middle", "oldest"]);
    // Exact browse-item shape the MemoryViewer consumes.
    expect(memories[0]).toMatchObject({
      type: "facts",
      text: "newest",
      source: "user",
      createdAt: 3000,
    });
    expect(json).toMatchObject({ count: 3, limit: 50, hasMore: false });
  });
  it("feed honors the limit + hasMore + before params", async () => {
    for (let i = 0; i < 5; i++) {
      await seedMemory("messages", `m${i}`, 1000 + i);
    }
    const first = await call(backend, "GET", "/api/memories/feed?limit=2");
    expect((first.json.memories as unknown[]).length).toBe(2);
    expect(first.json.hasMore).toBe(true);
    // `before` excludes items at/after the cursor (newest is createdAt 1004).
    const before = await call(backend, "GET", "/api/memories/feed?before=1002");
    const beforeTexts = (
      before.json.memories as Array<{
        text: string;
      }>
    ).map((m) => m.text);
    expect(beforeTexts).toEqual(["m1", "m0"]);
    const epoch = await call(backend, "GET", "/api/memories/feed?before=0");
    expect(epoch.status).toBe(200);
    expect(epoch.json.memories).toEqual([]);
    const blank = await call(backend, "GET", "/api/memories/feed?before=%20");
    expect(blank.status).toBe(200);
    expect((blank.json.memories as unknown[]).length).toBe(5);
    for (const cursor of [
      "abc",
      "0x10",
      "1e3",
      "-5",
      "1.5",
      "012",
      "9007199254740993",
    ]) {
      const invalid = await call(
        backend,
        "GET",
        `/api/memories/feed?before=${cursor}`,
      );
      expect(invalid).toEqual({
        status: 400,
        json: { error: "before must be a Unix timestamp in milliseconds" },
      });
    }
  });
  it("pages every tied-timestamp feed row exactly once with the id cursor", async () => {
    const createdAt = 1700000000000;
    for (let i = 0; i < 120; i++) {
      await seedMemory("messages", `tied ${i}`, createdAt);
    }
    const seen: string[] = [];
    let path = "/api/memories/feed?type=messages&limit=50";
    for (let pageNumber = 0; pageNumber < 3; pageNumber++) {
      const page = await call(backend, "GET", path);
      const memories = page.json.memories as Array<{
        id: string;
        createdAt: number;
      }>;
      seen.push(...memories.map((memory) => memory.id));
      if (pageNumber < 2) expect(page.json.hasMore).toBe(true);
      const last = memories.at(-1);
      if (page.json.hasMore === false || !last) break;
      path = `/api/memories/feed?type=messages&limit=50&before=${last.createdAt}&beforeId=${last.id}`;
    }
    expect(seen).toHaveLength(120);
    expect(new Set(seen).size).toBe(120);
  });
  it("rejects an id cursor without its timestamp pair", async () => {
    const result = await call(
      backend,
      "GET",
      `/api/memories/feed?beforeId=${crypto.randomUUID()}`,
    );
    expect(result.status).toBe(400);
    expect(result.json).toEqual({
      error: "beforeId must be a UUID paired with before",
    });
  });
  it("feed type filter scopes to a single table", async () => {
    await seedMemory("messages", "a message", 1000);
    await seedMemory("facts", "a fact", 2000);
    const { json } = await call(
      backend,
      "GET",
      "/api/memories/feed?type=facts",
    );
    const texts = (
      json.memories as Array<{
        text: string;
      }>
    ).map((m) => m.text);
    expect(texts).toEqual(["a fact"]);
  });
  it("browse paginates + keyword-filters with total/limit/offset", async () => {
    await seedMemory("messages", "alpha bravo", 1000);
    await seedMemory("messages", "charlie delta", 2000);
    await seedMemory("facts", "alpha echo", 3000);
    const all = await call(backend, "GET", "/api/memories/browse");
    expect(all.json).toMatchObject({
      total: 3,
      totalIsExact: false,
      hasMore: false,
      limit: 50,
      offset: 0,
    });
    const search = await call(backend, "GET", "/api/memories/browse?q=alpha");
    const texts = (
      search.json.memories as Array<{
        text: string;
      }>
    ).map((m) => m.text);
    expect(texts).toEqual(["alpha echo", "alpha bravo"]);
    expect(search.json.total).toBe(2);
    const page = await call(
      backend,
      "GET",
      "/api/memories/browse?limit=1&offset=1",
    );
    expect((page.json.memories as unknown[]).length).toBe(1);
    expect(page.json).toMatchObject({ total: 3, limit: 1, offset: 1 });
  });
  it("finds sparse matches beyond the first adapter window", async () => {
    for (let i = 0; i < 450; i++) {
      await seedMemory("messages", i < 30 ? `needle ${i}` : `hay ${i}`, i);
    }
    const result = await call(
      backend,
      "GET",
      "/api/memories/browse?type=messages&q=needle%20missing&limit=20",
    );
    expect((result.json.memories as unknown[]).length).toBe(20);
    expect(result.json).toMatchObject({
      totalIsExact: false,
      hasMore: true,
    });
  });
  it("fails closed when an adapter ignores the keyset cursor", async () => {
    for (let i = 0; i < 450; i++) {
      await seedMemory("messages", i < 30 ? `needle ${i}` : `hay ${i}`, i);
    }
    const cursorAware = runtime.getMemories.bind(runtime);
    runtime.getMemories = vi.fn((params) =>
      cursorAware({ ...params, cursor: undefined }),
    );
    await expect(
      call(
        backend,
        "GET",
        "/api/memories/browse?type=messages&q=needle%20missing&limit=20",
      ),
    ).rejects.toMatchObject({ code: "MEMORY_BROWSE_CURSOR_NO_PROGRESS" });
    expect(runtime.getMemories).toHaveBeenCalledTimes(2);
  });
  it("fails closed at the shared request-wide sparse scan bound", async () => {
    let sequence = 0;
    const getMemories = vi.fn(
      async (params: { limit?: number }): Promise<Memory[]> =>
        Array.from({ length: params.limit ?? 0 }, () => {
          const index = sequence++;
          return {
            id: `00000000-0000-4000-8000-${String(index).padStart(12, "0")}` as UUID,
            entityId: AGENT_ID,
            roomId: AGENT_ID,
            agentId: AGENT_ID,
            createdAt: 1000000 - index,
            content: { text: `hay ${index}` },
          } as Memory;
        }),
    );
    runtime.getMemories = getMemories as IAgentRuntime["getMemories"];
    await expect(
      call(
        backend,
        "GET",
        "/api/memories/browse?type=messages&q=needle%20missing&limit=20",
      ),
    ).rejects.toMatchObject({ code: "MEMORY_BROWSE_SCAN_LIMIT" });
    expect(
      getMemories.mock.calls.reduce(
        (sum, [params]) => sum + (params.limit ?? 0),
        0,
      ),
    ).toBe(25000);
  });
  it("stats totals per table", async () => {
    await seedMemory("messages", "m1", 1000);
    await seedMemory("messages", "m2", 2000);
    await seedMemory("facts", "f1", 3000);
    const { status, json } = await call(backend, "GET", "/api/memories/stats");
    expect(status).toBe(200);
    expect(json).toEqual({
      total: 3,
      byType: { messages: 2, memories: 0, facts: 1, documents: 0 },
    });
  });
  it("stats uses exact counts without materializing capped row windows", async () => {
    runtime.getMemories = vi.fn(async () => {
      throw new Error("stats must not read rows");
    });
    const values: Record<string, number> = {
      messages: 25000,
      memories: 4,
      facts: 3,
      documents: 2,
    };
    runtime.countMemories = vi.fn(
      async ({ tableName }) => values[tableName ?? "messages"] ?? 0,
    );
    const { status, json } = await call(backend, "GET", "/api/memories/stats");
    expect(status).toBe(200);
    expect(json).toEqual({ total: 25009, byType: values });
    expect(runtime.countMemories).toHaveBeenCalledTimes(4);
    expect(runtime.getMemories).not.toHaveBeenCalled();
  });
  it("stats fails closed on an invalid adapter count", async () => {
    runtime.countMemories = vi.fn(async () => Number.NaN);
    await expect(
      call(backend, "GET", "/api/memories/stats"),
    ).rejects.toMatchObject({ code: "MEMORY_STATS_INVALID_COUNT" });
  });
  it("stats fails closed when individually safe counts overflow in aggregate", async () => {
    runtime.getMemories = vi.fn(async () => {
      throw new Error("stats must not fall back to reading rows");
    });
    const values: Record<string, number> = {
      messages: Number.MAX_SAFE_INTEGER,
      memories: 1,
      facts: 0,
      documents: 0,
    };
    runtime.countMemories = vi.fn(
      async ({ tableName }) => values[tableName ?? "messages"] ?? 0,
    );
    await expect(
      call(backend, "GET", "/api/memories/stats"),
    ).rejects.toMatchObject({ code: "MEMORY_STATS_INVALID_COUNT" });
    expect(runtime.countMemories).toHaveBeenCalledTimes(4);
    expect(runtime.getMemories).not.toHaveBeenCalled();
  });
});
describe("iOS bridge — transcripts view routes", () => {
  let backend: IosBridgeBackend;
  beforeEach(() => {
    backend = makeBackend(createFakeRuntime());
  });
  it("create → list → get → update → delete round-trips", async () => {
    // Create
    const created = await call(backend, "POST", "/api/transcripts", {
      title: "Standup",
      segments: [seg("hello world", 1500)],
    });
    expect(created.status).toBe(201);
    const transcript = created.json.transcript as Record<string, unknown>;
    expect(transcript).toMatchObject({
      title: "Standup",
      status: "ready",
      durationMs: 1500,
      speakerCount: 1,
    });
    const id = transcript.id as string;
    // List → summary shape
    const list = await call(backend, "GET", "/api/transcripts");
    expect(list.status).toBe(200);
    const summaries = list.json.transcripts as Array<Record<string, unknown>>;
    expect(summaries).toHaveLength(1);
    expect(summaries[0]).toMatchObject({
      id,
      title: "Standup",
      durationMs: 1500,
      speakerCount: 1,
      preview: "hello world",
      hasAudio: false,
    });
    // Get by id
    const got = await call(
      backend,
      "GET",
      `/api/transcripts/${encodeURIComponent(id)}`,
    );
    expect(got.status).toBe(200);
    expect(
      (
        got.json.transcript as {
          id: string;
        }
      ).id,
    ).toBe(id);
    // Update (PUT) — new title + longer segment
    const updated = await call(
      backend,
      "PUT",
      `/api/transcripts/${encodeURIComponent(id)}`,
      { title: "Standup (edited)", segments: [seg("hello there", 3000)] },
    );
    expect(updated.status).toBe(200);
    expect(updated.json.transcript).toMatchObject({
      title: "Standup (edited)",
      durationMs: 3000,
    });
    expect(
      (
        updated.json.transcript as {
          editedAt?: number;
        }
      ).editedAt,
    ).toBeGreaterThan(0);
    // Delete
    const deleted = await call(
      backend,
      "DELETE",
      `/api/transcripts/${encodeURIComponent(id)}`,
    );
    expect(deleted.json).toEqual({ ok: true });
    const emptyList = await call(backend, "GET", "/api/transcripts");
    expect((emptyList.json.transcripts as unknown[]).length).toBe(0);
  });
  it("create rejects empty segments with 400", async () => {
    const res = await call(backend, "POST", "/api/transcripts", {
      segments: [],
    });
    expect(res.status).toBe(400);
    expect(res.json).toMatchObject({ error: "segments are required" });
  });
  it("get + delete of an unknown id 404s", async () => {
    const unknown = "11111111-1111-1111-1111-111111111111";
    const got = await call(backend, "GET", `/api/transcripts/${unknown}`);
    expect(got.status).toBe(404);
  });
  it("update rejects a body with neither title nor segments (400)", async () => {
    const created = await call(backend, "POST", "/api/transcripts", {
      segments: [seg("x")],
    });
    const id = (
      created.json.transcript as {
        id: string;
      }
    ).id;
    const res = await call(
      backend,
      "PUT",
      `/api/transcripts/${encodeURIComponent(id)}`,
      {},
    );
    expect(res.status).toBe(400);
  });
});
describe("iOS bridge — browser workspace routes", () => {
  let backend: IosBridgeBackend;
  beforeEach(() => {
    resetIosBrowserWorkspace();
    backend = makeBackend(createFakeRuntime());
  });
  afterEach(() => {
    resetIosBrowserWorkspace();
  });
  it("starts in web mode with no tabs", async () => {
    const { status, json } = await call(
      backend,
      "GET",
      "/api/browser-workspace",
    );
    expect(status).toBe(200);
    expect(json).toEqual({ mode: "web", tabs: [] });
  });
  it("open → navigate → show/hide → close tab lifecycle", async () => {
    // Open (the "Open a website" button path)
    const opened = await call(backend, "POST", "/api/browser-workspace/tabs", {
      url: "docs.elizaos.ai",
      title: "Docs",
      show: true,
    });
    expect(opened.status).toBe(200);
    const tab = opened.json.tab as Record<string, unknown>;
    expect(tab).toMatchObject({
      title: "Docs",
      url: "https://docs.elizaos.ai",
      visible: true,
      partition: "persist:eliza-browser-user",
    });
    const id = tab.id as string;
    // Snapshot appears in the workspace GET, web mode
    const snapshot = await call(backend, "GET", "/api/browser-workspace");
    expect(snapshot.json.mode).toBe("web");
    expect((snapshot.json.tabs as unknown[]).length).toBe(1);
    // Navigate
    const navigated = await call(
      backend,
      "POST",
      `/api/browser-workspace/tabs/${encodeURIComponent(id)}/navigate`,
      { url: "example.com" },
    );
    expect(
      (
        navigated.json.tab as {
          url: string;
        }
      ).url,
    ).toBe("https://example.com");
    // Hide then show
    const hidden = await call(
      backend,
      "POST",
      `/api/browser-workspace/tabs/${encodeURIComponent(id)}/hide`,
    );
    expect(
      (
        hidden.json.tab as {
          visible: boolean;
        }
      ).visible,
    ).toBe(false);
    const shown = await call(
      backend,
      "POST",
      `/api/browser-workspace/tabs/${encodeURIComponent(id)}/show`,
    );
    expect(
      (
        shown.json.tab as {
          visible: boolean;
        }
      ).visible,
    ).toBe(true);
    // snapshot action returns empty data (web mode has no server screenshot)
    const snap = await call(
      backend,
      "GET",
      `/api/browser-workspace/tabs/${encodeURIComponent(id)}/snapshot`,
    );
    expect(snap.json).toEqual({ data: "" });
    // Close
    const closed = await call(
      backend,
      "DELETE",
      `/api/browser-workspace/tabs/${encodeURIComponent(id)}`,
    );
    expect(closed.json).toEqual({ closed: true });
    const after = await call(backend, "GET", "/api/browser-workspace");
    expect((after.json.tabs as unknown[]).length).toBe(0);
  });
  it("opening a second visible tab hides the first", async () => {
    const a = await call(backend, "POST", "/api/browser-workspace/tabs", {
      url: "a.com",
      show: true,
    });
    await call(backend, "POST", "/api/browser-workspace/tabs", {
      url: "b.com",
      show: true,
    });
    const ws = await call(backend, "GET", "/api/browser-workspace");
    const tabs = ws.json.tabs as Array<{
      id: string;
      visible: boolean;
    }>;
    const first = tabs.find(
      (t) =>
        t.id ===
        (
          a.json.tab as {
            id: string;
          }
        ).id,
    );
    expect(first?.visible).toBe(false);
    expect(tabs.filter((t) => t.visible)).toHaveLength(1);
  });
  it("acting on an unknown tab id 404s", async () => {
    const res = await call(
      backend,
      "POST",
      "/api/browser-workspace/tabs/nope/show",
    );
    expect(res.status).toBe(404);
  });
});
describe("iOS bridge — conversation message failure surfacing", () => {
  // A failed `createMemory` write is best-effort secondary persistence
  // (error-policy:J6): it must not drop the reply, but the failure must surface
  // observably (stderr) rather than be silently swallowed.
  function createMessageServiceRuntime(
    onCreateMemory: () => Promise<UUID>,
  ): IAgentRuntime {
    return {
      agentId: AGENT_ID,
      character: { name: "Eliza" },
      async ensureConnection(): Promise<void> {},
      createMemory: onCreateMemory,
      messageService: {
        async handleMessage(
          _runtime: IAgentRuntime,
          _message: Memory,
          onResponse: (content: { text?: string }) => Promise<unknown>,
        ): Promise<void> {
          await onResponse({ text: "hello from the local agent" });
        },
      },
    } as unknown as IAgentRuntime;
  }
  function seedConversation(backend: IosBridgeBackend, id: string): void {
    backend.conversations.set(id, {
      id,
      title: "Test Chat",
      roomId: "00000000-0000-0000-0000-0000000000cc" as UUID,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }
  // Point the local-inference state dir at an empty temp dir so no real
  // on-disk model registry diverts the reply through the native-llama path;
  // with zero installed models the deterministic messageService path runs.
  let prevStateDir: string | undefined;
  beforeEach(() => {
    prevStateDir = process.env.ELIZA_STATE_DIR;
    process.env.ELIZA_STATE_DIR = mkdtempSync(
      path.join(tmpdir(), "ios-bridge-conv-"),
    );
  });
  afterEach(() => {
    if (prevStateDir === undefined) delete process.env.ELIZA_STATE_DIR;
    else process.env.ELIZA_STATE_DIR = prevStateDir;
    vi.restoreAllMocks();
  });
  it("surfaces a rejected createMemory to stderr but still returns the reply", async () => {
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const runtime = createMessageServiceRuntime(() =>
      Promise.reject(new Error("db offline")),
    );
    const backend = makeBackend(runtime);
    seedConversation(backend, "conv-fail-1");
    const { status, json } = await call(
      backend,
      "POST",
      "/api/conversations/conv-fail-1/messages",
      { text: "hi there" },
    );
    // The reply is produced despite the persistence failure (J6 continues).
    expect(status).toBe(200);
    expect(json.reply).toBe("hello from the local agent");
    // The failure is observable, not swallowed.
    expect(errorSpy).toHaveBeenCalledWith(
      "[ios-bridge] createMemory(messages) failed:",
      "db offline",
    );
  });
  it("does not log when createMemory succeeds", async () => {
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const runtime = createMessageServiceRuntime(() =>
      Promise.resolve(crypto.randomUUID() as UUID),
    );
    const backend = makeBackend(runtime);
    seedConversation(backend, "conv-ok-1");
    const { status, json } = await call(
      backend,
      "POST",
      "/api/conversations/conv-ok-1/messages",
      { text: "hi there" },
    );
    expect(status).toBe(200);
    expect(json.reply).toBe("hello from the local agent");
    expect(errorSpy).not.toHaveBeenCalledWith(
      "[ios-bridge] createMemory(messages) failed:",
      expect.anything(),
    );
  });
});
describe("iOS bridge — first-run submit", () => {
  const cloudRoute = {
    serviceRouting: {
      llmText: { backend: "elizacloud", transport: "cloud-proxy" },
    },
  };
  const noKey = "agent has no Eliza Cloud API key";
  /** The agent's key check answers through this backend seam. */
  function backendWithKeyCheck(rejection: string | null): IosBridgeBackend {
    return {
      ...makeBackend(createFakeRuntime()),
      cloudInferenceRejection: () => rejection,
    };
  }

  it("rejects a Cloud inference selection when the agent has no Cloud API key", async () => {
    const { status, json } = await call(
      backendWithKeyCheck(noKey),
      "POST",
      "/api/first-run",
      cloudRoute,
    );
    expect(status).toBe(409);
    expect(json).toEqual({ error: noKey });
  });
  it("rejects a Cloud inference selection whose key only travels in the request body", async () => {
    // The bridge does not apply the first-run body, so a key submitted with it
    // never reaches the agent. A 200 here would be the same false success.
    const { status, json } = await call(
      backendWithKeyCheck(noKey),
      "POST",
      "/api/first-run",
      { ...cloudRoute, credentialInputs: { cloudApiKey: "body-only-key" } },
    );
    expect(status).toBe(409);
    expect(json).toEqual({ error: noKey });
  });
  it("acknowledges a Cloud inference selection when the agent holds a Cloud API key", async () => {
    const { status, json } = await call(
      backendWithKeyCheck(null),
      "POST",
      "/api/first-run",
      cloudRoute,
    );
    expect(status).toBe(200);
    expect(json.complete).toBe(true);
  });
  it("acknowledges an on-device selection with no Cloud API key", async () => {
    const { status, json } = await call(
      backendWithKeyCheck(noKey),
      "POST",
      "/api/first-run",
      {
        serviceRouting: {
          llmText: { backend: "local", transport: "direct" },
        },
      },
    );
    expect(status).toBe(200);
    expect(json.complete).toBe(true);
  });
});
describe("iOS bridge — conversation transcript route", () => {
  // A scanned GGUF file makes the native reply path run, the path an ios-local
  // build uses. The store is the in-memory runtime the other shims read.
  const fsGlobals = globalThis as MobileFsGlobals;
  let prevResolver: MobileFsGlobals["__ELIZA_MOBILE_FS_RESOLVE__"];
  let prevStateDir: string | undefined;
  beforeEach(() => {
    prevResolver = fsGlobals.__ELIZA_MOBILE_FS_RESOLVE__;
    fsGlobals.__ELIZA_MOBILE_FS_RESOLVE__ = (inputPath) => inputPath;
    prevStateDir = process.env.ELIZA_STATE_DIR;
    process.env.ELIZA_STATE_DIR = mkdtempSync(
      path.join(tmpdir(), "ios-bridge-transcript-"),
    );
    const modelsDir = path.join(
      process.env.ELIZA_STATE_DIR,
      "local-inference",
      "models",
    );
    mkdirSync(modelsDir, { recursive: true });
    writeFileSync(path.join(modelsDir, "chat.gguf"), "GGUF-rest-of-file");
  });
  afterEach(() => {
    fsGlobals.__ELIZA_MOBILE_FS_RESOLVE__ = prevResolver;
    if (prevStateDir === undefined) delete process.env.ELIZA_STATE_DIR;
    else process.env.ELIZA_STATE_DIR = prevStateDir;
  });
  function createNativeReplyBackend(
    useModel: () => Promise<string>,
  ): IosBridgeBackend {
    const runtime = Object.assign(createFakeRuntime(), {
      async ensureConnection(): Promise<void> {},
      useModel,
    });
    return makeBackend(runtime);
  }
  it("returns the stored user turn and native reply, oldest first", async () => {
    // Generation takes time on a device. Without it both rows share one
    // millisecond and their order falls to the random-id tiebreak.
    const backend = createNativeReplyBackend(async () => {
      await new Promise((resolve) => setTimeout(resolve, 5));
      return "Hello from Eliza-1.";
    });
    const created = await call(backend, "POST", "/api/conversations", {});
    const id = (created.json.conversation as { id: string }).id;
    const sent = await call(
      backend,
      "POST",
      `/api/conversations/${id}/messages`,
      {
        text: "hi there",
      },
    );
    expect(sent.json.reply).toBe("Hello from Eliza-1.");
    const { status, json } = await call(
      backend,
      "GET",
      `/api/conversations/${id}/messages`,
    );
    expect(status).toBe(200);
    const messages = json.messages as Array<{
      id: string;
      role: string;
      text: string;
      timestamp: number;
    }>;
    expect(messages.map(({ role, text }) => ({ role, text }))).toEqual([
      { role: "user", text: "hi there" },
      { role: "assistant", text: "Hello from Eliza-1." },
    ]);
    // The whole room was returned, so the page below the oldest row is empty.
    const older = await call(
      backend,
      "GET",
      `/api/conversations/${id}/messages?before=${messages[0].timestamp}&beforeId=${messages[0].id}`,
    );
    expect(older.json).toEqual({ messages: [], hasMore: false });
  });
  it("rebuilds the conversation list from the stored rooms after a restart", async () => {
    // The room store keeps what core's ensureConnection writes for a room.
    const rooms = new Map<UUID, Room>();
    const runtime = Object.assign(createFakeRuntime(), {
      async ensureConnection(params: {
        roomId: UUID;
        roomName?: string;
        worldId: UUID;
        source: string;
        channelId?: string;
      }): Promise<void> {
        rooms.set(params.roomId, {
          id: params.roomId,
          name: params.roomName || "default",
          source: params.source,
          type: "DM" as Room["type"],
          channelId: params.channelId ?? params.roomId,
          worldId: params.worldId,
        });
      },
      async getRoomsByWorlds(worldIds: UUID[]): Promise<Room[]> {
        return [...rooms.values()].filter(
          (room) => room.worldId && worldIds.includes(room.worldId),
        );
      },
      // A real duration keeps the two rows out of one millisecond.
      useModel: async () => {
        await new Promise((resolve) => setTimeout(resolve, 5));
        return "Hello from Eliza-1.";
      },
    });
    const first = makeBackend(runtime);
    const created = await call(first, "POST", "/api/conversations", {
      title: "Trip plan",
    });
    const id = (created.json.conversation as { id: string }).id;
    // A conversation with no message has no room, so it is not stored.
    await call(first, "POST", "/api/conversations", { title: "Unused" });
    await call(first, "POST", `/api/conversations/${id}/messages`, {
      text: "hi there",
    });

    const restarted: IosBridgeBackend = {
      ...makeBackend(runtime),
      conversations: await restoreIosConversations(runtime),
    };
    const list = await call(restarted, "GET", "/api/conversations");
    const conversations = list.json.conversations as Array<{
      id: string;
      title: string;
      createdAt: string;
      updatedAt: string;
    }>;
    expect(conversations.map(({ id, title }) => ({ id, title }))).toEqual([
      { id, title: "Trip plan" },
    ]);
    // The user turn is the oldest row and the reply the newest.
    expect(Date.parse(conversations[0].createdAt)).toBeLessThan(
      Date.parse(conversations[0].updatedAt),
    );
    const transcript = await call(
      restarted,
      "GET",
      `/api/conversations/${id}/messages`,
    );
    expect(
      (transcript.json.messages as Array<{ role: string; text: string }>).map(
        ({ role, text }) => ({ role, text }),
      ),
    ).toEqual([
      { role: "user", text: "hi there" },
      { role: "assistant", text: "Hello from Eliza-1." },
    ]);
  });
  it("does not store a generation-failure notice as a reply", async () => {
    const backend = createNativeReplyBackend(async () => {
      throw new Error("context lost");
    });
    const created = await call(backend, "POST", "/api/conversations", {});
    const id = (created.json.conversation as { id: string }).id;
    await call(backend, "POST", `/api/conversations/${id}/messages`, {
      text: "hi there",
    });
    const { json } = await call(
      backend,
      "GET",
      `/api/conversations/${id}/messages`,
    );
    expect(
      (json.messages as Array<{ role: string }>).map((m) => m.role),
    ).toEqual(["user"]);
  });
  it("still returns the reply when storing it fails", async () => {
    const runtime = Object.assign(createFakeRuntime(), {
      async ensureConnection(): Promise<void> {},
      useModel: async () => "Hello from Eliza-1.",
    });
    const storeMemory = runtime.createMemory.bind(runtime);
    runtime.createMemory = async (memory: Memory, tableName: string) => {
      if (memory.entityId === runtime.agentId) throw new Error("disk full");
      return storeMemory(memory, tableName);
    };
    const backend = makeBackend(runtime);
    const errorLog = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      const created = await call(backend, "POST", "/api/conversations", {});
      const id = (created.json.conversation as { id: string }).id;
      const sent = await call(
        backend,
        "POST",
        `/api/conversations/${id}/messages`,
        { text: "hi there" },
      );
      expect(sent.status).toBe(200);
      expect(sent.json.reply).toBe("Hello from Eliza-1.");
      expect(errorLog).toHaveBeenCalledWith(
        "[ios-bridge] createMemory(messages) failed for the native reply:",
        "disk full",
      );
      const { json } = await call(
        backend,
        "GET",
        `/api/conversations/${id}/messages`,
      );
      expect(
        (json.messages as Array<{ role: string }>).map((m) => m.role),
      ).toEqual(["user"]);
    } finally {
      errorLog.mockRestore();
    }
  });
  it("pages strictly below a bare before timestamp and rejects a bad cursor", async () => {
    const backend = createNativeReplyBackend(async () => {
      await new Promise((resolve) => setTimeout(resolve, 5));
      return "Hello from Eliza-1.";
    });
    const created = await call(backend, "POST", "/api/conversations", {});
    const id = (created.json.conversation as { id: string }).id;
    await call(backend, "POST", `/api/conversations/${id}/messages`, {
      text: "hi there",
    });
    const all = await call(backend, "GET", `/api/conversations/${id}/messages`);
    const [userTurn, reply] = all.json.messages as Array<{
      id: string;
      timestamp: number;
    }>;
    const below = await call(
      backend,
      "GET",
      `/api/conversations/${id}/messages?before=${reply.timestamp}`,
    );
    expect(below.json).toEqual({
      messages: [expect.objectContaining({ id: userTurn.id, role: "user" })],
      hasMore: false,
    });
    for (const query of [
      "before=yesterday",
      `beforeId=${userTurn.id}`,
      `before=${reply.timestamp}&beforeId=not-a-uuid`,
    ]) {
      const rejected = await call(
        backend,
        "GET",
        `/api/conversations/${id}/messages?${query}`,
      );
      expect(rejected.status).toBe(400);
    }
  });
  it("answers 404 for a conversation the bridge does not hold", async () => {
    const { status, json } = await call(
      makeBackend(createFakeRuntime()),
      "GET",
      "/api/conversations/missing/messages",
    );
    expect(status).toBe(404);
    expect(json.error).toBe("Conversation not found");
  });
});
describe("iOS bridge — local-inference verify route", () => {
  // The bridge reads through the sandboxed fs proxy, which needs the resolver
  // the native host installs at boot. Pass paths through unchanged so the
  // route runs against real files in a temp state dir.
  const fsGlobals = globalThis as MobileFsGlobals;
  let prevResolver: MobileFsGlobals["__ELIZA_MOBILE_FS_RESOLVE__"];
  let prevStateDir: string | undefined;
  let modelsDir: string;
  beforeEach(() => {
    prevResolver = fsGlobals.__ELIZA_MOBILE_FS_RESOLVE__;
    fsGlobals.__ELIZA_MOBILE_FS_RESOLVE__ = (inputPath) => inputPath;
    prevStateDir = process.env.ELIZA_STATE_DIR;
    process.env.ELIZA_STATE_DIR = mkdtempSync(
      path.join(tmpdir(), "ios-bridge-verify-"),
    );
    modelsDir = path.join(
      process.env.ELIZA_STATE_DIR,
      "local-inference",
      "models",
    );
    mkdirSync(modelsDir, { recursive: true });
  });
  afterEach(() => {
    fsGlobals.__ELIZA_MOBILE_FS_RESOLVE__ = prevResolver;
    if (prevStateDir === undefined) delete process.env.ELIZA_STATE_DIR;
    else process.env.ELIZA_STATE_DIR = prevStateDir;
  });
  it("reports a GGUF file as unknown: no install-time hash exists to compare", async () => {
    writeFileSync(path.join(modelsDir, "scanned.gguf"), "GGUF-rest-of-file");
    const res = await call(
      makeBackend(createFakeRuntime()),
      "POST",
      "/api/local-inference/installed/scanned/verify",
    );
    expect(res.status).toBe(200);
    expect(res.json).toEqual({
      state: "unknown",
      currentSha256: null,
      expectedSha256: null,
      currentBytes: 17,
    });
  });
  it("reports a file without the GGUF magic as truncated", async () => {
    writeFileSync(path.join(modelsDir, "broken.gguf"), "GG");
    const res = await call(
      makeBackend(createFakeRuntime()),
      "POST",
      "/api/local-inference/installed/broken/verify",
    );
    expect(res.status).toBe(200);
    expect(res.json).toEqual({
      state: "truncated",
      currentSha256: null,
      expectedSha256: null,
      currentBytes: 2,
    });
  });
});
describe("iOS bridge — local TTS text", () => {
  it("treats a reply that is only an open code fence as having no speakable text", async () => {
    const backend = makeBackend(createFakeRuntime());
    const res = await call(backend, "POST", "/api/tts/local-inference", {
      text: "```bash\nrm -rf build/",
    });
    expect(res.status).toBe(400);
    expect(res.json).toEqual({ error: "Missing text" });
  });
});
describe("iOS bridge — unmatched routes still fall through", () => {
  it("returns null (→ eventual 404) for an unknown /api path", async () => {
    const backend = makeBackend(createFakeRuntime());
    const res = await handleDirectCoreRoute(
      backend,
      "GET",
      "/api/does-not-exist",
      {},
    );
    expect(res).toBeNull();
  });
  it("returns null for an unknown /api/memories subpath", async () => {
    const backend = makeBackend(createFakeRuntime());
    const res = await handleDirectCoreRoute(
      backend,
      "GET",
      "/api/memories/unknown",
      {},
    );
    expect(res).toBeNull();
  });
  it("sorts conversations safely when updatedAt contains invalid date strings", async () => {
    const backend = makeBackend(createFakeRuntime());
    backend.conversations.set("conv-invalid", {
      id: "conv-invalid",
      name: "Invalid Date Conv",
      createdAt: "2026-08-01T00:00:00Z",
      updatedAt: "not-a-real-date",
      messageCount: 1,
      isUnread: false,
    });
    backend.conversations.set("conv-valid", {
      id: "conv-valid",
      name: "Valid Date Conv",
      createdAt: "2026-08-01T00:00:00Z",
      updatedAt: "2026-08-20T00:00:00Z",
      messageCount: 1,
      isUnread: false,
    });
    const res = await handleDirectCoreRoute(
      backend,
      "GET",
      "/api/conversations",
      {},
    );
    expect(res?.status).toBe(200);
    const json = JSON.parse(res?.body ?? "{}");
    expect(json.conversations).toHaveLength(2);
    expect(json.conversations[0]?.id).toBe("conv-valid");
    expect(json.conversations[1]?.id).toBe("conv-invalid");
  });
});
