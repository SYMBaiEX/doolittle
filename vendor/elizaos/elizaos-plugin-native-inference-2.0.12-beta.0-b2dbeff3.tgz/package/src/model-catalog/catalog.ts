/**
 * Eliza-curated local model catalog.
 *
 * Default local inference is restricted to the active Eliza-1 line:
 * eliza-1-2b, eliza-1-4b, eliza-1-9b, eliza-1-27b,
 * and eliza-1-27b-256k.
 * These ship Gemma 4 bases: E2B/E4B/12B/31B mapped onto the
 * 2B/4B/9B/27B release tiers (the 2026-06-22 cutover from the legacy
 * hybrid line — see #9033 and packages/training/scripts/training/model_registry.py
 * for the active registry). Gemma 4 is a dense SWA + shared-KV + per-layer-embedding
 * (PLE) + MQA architecture; KV is already minimal so the legacy
 * QJL/TurboQuant KV kernels are not used (stock KV), and the shipping
 * GGUF weight quant is stock Q4_K_M unless a manifest proves a tier-specific
 * PolarQuant recipe was actually applied. External Hub search remains custom/opt-in and
 * never enters first-run or default eligibility.
 * Separate-drafter MTP is still the required release shape, but runtime
 * metadata is gated until the Gemma drafter GGUFs are actually hosted.
 */

import type {
  CatalogModel,
  CatalogQuantizationId,
  CatalogQuantizationVariant,
  InstalledModel,
  LocalRuntimeKernel,
} from "@elizaos/contracts";
import {
  trimBoundaryCharacters,
  trimEndCharacters,
  trimStartCharacters,
} from "@elizaos/core/protocol";
import { type HfDownloadBase, resolveHfDownloadBases } from "./hf-proxy.js";

export const ELIZA_1_HF_REPO = "elizaos/eliza-1" as const;

export const ELIZA_1_TIER_IDS = [
  "eliza-1-2b",
  "eliza-1-4b",
  "eliza-1-9b",
  "eliza-1-27b",
  "eliza-1-27b-256k",
] as const;

export type Eliza1TierId = (typeof ELIZA_1_TIER_IDS)[number];

export const ELIZA_1_RELEASE_TIER_IDS =
  ELIZA_1_TIER_IDS satisfies ReadonlyArray<Eliza1TierId>;

export const ELIZA_1_VISION_TIER_IDS = [
  "eliza-1-2b",
  "eliza-1-4b",
  "eliza-1-9b",
  "eliza-1-27b",
  "eliza-1-27b-256k",
] as const satisfies ReadonlyArray<Eliza1TierId>;

const _ELIZA_1_VISION_TIER_ID_SET: ReadonlySet<Eliza1TierId> = new Set(
  ELIZA_1_VISION_TIER_IDS,
);

export const ELIZA_1_MTP_TIER_IDS = [
  "eliza-1-2b",
  "eliza-1-4b",
  "eliza-1-9b",
  "eliza-1-27b",
  "eliza-1-27b-256k",
] as const satisfies ReadonlyArray<Eliza1TierId>;

/**
 * Tiers whose Gemma MTP drafter GGUFs are present at
 * `bundles/<tier>/mtp/drafter-<tier>.gguf` in the active HF tree.
 *
 * Current HF state (2026-07-02): `bundles/2b/mtp/drafter-2b.gguf` hosts the
 * gemma4-assistant drafter converted from `google/gemma-4-E2B-it-assistant`
 * (arch `gemma4-assistant`, f16, embedding_length_out=1536; sha256
 * 0495d34e08d0…, manifest `files.mtp` + `lineage.drafter` + `evals.mtp`
 * populated — acceptance 0.84, speedup ~1.53x greedy on M4 Max Metal at
 * `--spec-draft-n-max 1`). `bundles/4b/mtp/drafter-4b.gguf` hosts the
 * drafter converted from `google/gemma-4-E4B-it-assistant` (arch
 * `gemma4-assistant`, f16, embedding_length_out=2560; sha256 e4585e558a74…,
 * manifest populated — acceptance 0.79, speedup ~1.33x greedy on M4 Max
 * Metal at `--spec-draft-n-max 1`). The remaining tiers (9b/27b) still only
 * expose legacy `dflash/` paths; add a tier here only once its
 * `mtp/drafter-<tier>.gguf` is actually hosted, so the runtime and
 * downloader never advertise or fetch missing MTP artifacts.
 */
export const ELIZA_1_HOSTED_MTP_TIER_IDS = [
  "eliza-1-2b",
  "eliza-1-4b",
] as const satisfies ReadonlyArray<Eliza1TierId>;

function hostedMtpDrafterAvailableForTier(id: Eliza1TierId): boolean {
  return ELIZA_1_HOSTED_MTP_TIER_IDS.some((mtpId) => mtpId === id);
}

/**
 * On-device (mobile-class) tiers. These are the tiers small enough to run on
 * a phone, so they advertise the Gemma-4 QAT `Q4_0` quant as the
 * mobile-preferred variant and ship a LiteRT `.litertlm` bundle for the
 * on-device LiteRT-LM runtime (NPU/GPU delegate). Mirrors the Kokoro-only
 * voice policy and the SD-1.5 image-gen tiering (2b/4b).
 */
export const ELIZA_1_ON_DEVICE_TIER_IDS = [
  "eliza-1-2b",
  "eliza-1-4b",
] as const satisfies ReadonlyArray<Eliza1TierId>;

const _ELIZA_1_ON_DEVICE_TIER_ID_SET: ReadonlySet<Eliza1TierId> = new Set(
  ELIZA_1_ON_DEVICE_TIER_IDS,
);

export function isOnDeviceTier(id: Eliza1TierId): boolean {
  return _ELIZA_1_ON_DEVICE_TIER_ID_SET.has(id);
}

// The quantized 2B (Gemma 4 E2B) is the shipped first-run default chat model:
// it is the smallest/entry tier, fits 8 GB-class phones comfortably, downloads
// fast, and is the model bundled into the AOSP image. Larger tiers (4B/9B/27B)
// remain available for manual selection on higher-memory hosts.
export const FIRST_RUN_DEFAULT_MODEL_ID: Eliza1TierId = "eliza-1-2b";

export const DEFAULT_ELIGIBLE_MODEL_IDS: ReadonlySet<string> = new Set(
  ELIZA_1_RELEASE_TIER_IDS,
);

export function isDefaultEligibleId(id: string): boolean {
  return DEFAULT_ELIGIBLE_MODEL_IDS.has(id);
}

/**
 * Per-tier publish-state hint. Keys are tier ids that are known to have
 * a pending Hugging Face bundle at the time the catalog snapshot was
 * cut. Tiers not listed here default to `"published"`. The recommender
 * consults this map (or a `publishStatus` field on a synthetic
 * `CatalogModel`) before recommending a first-run default — see
 * `recommendForFirstRun` and elizaOS/eliza#7629.
 *
 * This is intentionally not runtime-overridable: the qwen35 tiers below are
 * blocked until the published bytes pass the Gemma text-architecture gate.
 *
 * W3-12 audit (2026-05-14): the following areas require publish attention:
 *   - 2B vision: enabled in the catalog and canonical vision tier set;
 *     publish staging must include `vision/mmproj-2b.gguf` or manifest
 *     validation fails loudly.
 *   - Voice sub-models (wakeword, turn-detector, speaker-encoder, emotion):
 *     published under the unified elizaos/eliza-1 `voice/<model-id>/...`
 *     layout. Per-tier manifests still need to consume these paths directly
 *     where a bundle wants eager voice downloads.
 *   - Kokoro same voice preset: `af_same.bin` absent from all
 *     bundles; I7 eval showed regression. Current bundles ship af_bella
 *     and standard voices only.
 */
export const ELIZA_1_TIER_PUBLISH_STATUS: Readonly<
  Partial<Record<Eliza1TierId, "published" | "pending">>
> = {
  // 2026-06-28: the HuggingFace `elizaos/eliza-1` 9b / 27b / 27b-256k text
  // GGUFs still report `general.architecture = qwen35` (Qwen3.5 / "Qwen3.6
  // 27B") — the Gemma-4 cutover only landed for the 2b and 4b tiers. Mark the
  // un-cut tiers `pending` so first-run never recommends a non-Gemma model as
  // the default Eliza-1; flip back to published once the Gemma-4 fine-tunes are
  // staged + pass the text-architecture provenance gate (text-provenance.ts).
  "eliza-1-9b": "pending",
  "eliza-1-27b": "pending",
  "eliza-1-27b-256k": "pending",
};

export function eliza1TierPublishStatus(
  id: Eliza1TierId | string,
): "published" | "pending" {
  const hint = (
    ELIZA_1_TIER_PUBLISH_STATUS as Record<
      string,
      "published" | "pending" | undefined
    >
  )[id];
  return hint ?? "published";
}

/** The manifest eval block the activation gate reads (`eliza-1.manifest.json#evals`). */
export interface Eliza1ActivationEvals {
  textEval: { passed: boolean };
}

/**
 * The single activation-eligibility predicate. The runtime applies it to the
 * installed bundle manifest before activation, the downloader applies it to
 * the fetched manifest before any weight byte, and the catalog applies it to
 * the published-manifest snapshot below so recommendation surfaces never offer
 * a tier activation would refuse.
 */
export function eliza1EvalsPassActivationGate(
  evals: Eliza1ActivationEvals,
): boolean {
  return evals.textEval.passed === true;
}

/**
 * Snapshot of each published tier's `eliza-1.manifest.json` activation evals,
 * cut from `elizaos/eliza-1` when the catalog is updated. Both published tiers
 * currently serve candidate manifests (`textEval.passed=false`, checked
 * 2026-09-26), so neither is offered as a first-run or Settings default until
 * the publisher ships a passing manifest and this snapshot is refreshed. The
 * downloader re-checks the live manifest with the same predicate, so a stale
 * snapshot can only under-offer, never let a refused bundle download.
 */
export const ELIZA_1_PUBLISHED_MANIFEST_EVALS: Readonly<
  Partial<
    Record<
      Eliza1TierId,
      { manifestVersion: string; evals: Eliza1ActivationEvals }
    >
  >
> = {
  "eliza-1-2b": {
    manifestVersion: "0.0.1-local.1-gemma4",
    evals: { textEval: { passed: false } },
  },
  "eliza-1-4b": {
    manifestVersion: "1.0.0-weights-staged.2-gemma4",
    evals: { textEval: { passed: false } },
  },
};

/**
 * True only for a published tier whose published manifest passes the
 * activation gate. Pending tiers and tiers without a manifest snapshot are
 * ineligible.
 */
export function isEliza1TierActivationEligible(id: string): boolean {
  if (!isEliza1TierId(id)) return false;
  if (eliza1TierPublishStatus(id) !== "published") return false;
  const snapshot = ELIZA_1_PUBLISHED_MANIFEST_EVALS[id];
  return snapshot ? eliza1EvalsPassActivationGate(snapshot.evals) : false;
}

/**
 * Canonical "may this catalog entry be offered as a chat model to download and
 * activate" check for recommendation and Settings surfaces: a visible,
 * default-eligible Eliza-1 tier that is published and activation-eligible.
 * Entry fields (as served over the API) win over the id-keyed snapshot.
 */
export function isCatalogModelOfferable(model: CatalogModel): boolean {
  if (model.hiddenFromCatalog) return false;
  if (!isDefaultEligibleId(model.id)) return false;
  const publishStatus =
    model.publishStatus ?? eliza1TierPublishStatus(model.id);
  if (publishStatus !== "published") return false;
  return model.activationEligible ?? isEliza1TierActivationEligible(model.id);
}

export const ELIZA_1_PLACEHOLDER_IDS: ReadonlySet<string> = new Set(
  ELIZA_1_TIER_IDS,
);

export type VoiceBackendId = "kokoro";

/**
 * Per-tier voice backend policy. Kokoro is the sole on-device TTS backend
 * for every Eliza-1 tier. At ~82M params (a single ~60-80 MB GGUF) hitting
 * ~97ms CPU TTFB it is small and fast enough to ship on phones and large
 * hosts alike, so every tier bundles exactly Kokoro.
 */
export const ELIZA_1_VOICE_BACKENDS: Record<
  Eliza1TierId,
  ReadonlyArray<VoiceBackendId>
> = {
  "eliza-1-2b": ["kokoro"],
  "eliza-1-4b": ["kokoro"],
  "eliza-1-9b": ["kokoro"],
  "eliza-1-27b": ["kokoro"],
  "eliza-1-27b-256k": ["kokoro"],
};

const BASE_REQUIRED_KERNELS: LocalRuntimeKernel[] = ["turbo3", "turbo4"];

/**
 * Byte sizes of the hosted `elizaos/eliza-1` artifacts, cut from the Hugging
 * Face tree and the published manifests (checked 2026-09-26). The catalog's
 * `sizeGb` (text weights, used for RAM fit) and `downloadSizeGb` (everything
 * the downloader fetches, used for the offer, disk preflight and progress) are
 * derived from these numbers instead of hand-typed estimates.
 *
 *   - `textBytes`: the primary text GGUF (`files.text`).
 *   - `downloadBytes`: the manifest plus every file `collectBundleFiles`
 *     installs (text, voice, asr, vision, mtp, cache, embedding, vad,
 *     wakeword; `imagegen` is fetched on demand and excluded). Absent for
 *     pending tiers, which publish no manifest and cannot be downloaded.
 */
export const ELIZA_1_PUBLISHED_ARTIFACT_BYTES: Readonly<
  Record<Eliza1TierId, { textBytes: number; downloadBytes?: number }>
> = {
  // bundles/e2b, manifest 0.0.1-local.1-gemma4.
  "eliza-1-2b": { textBytes: 4_967_494_592, downloadBytes: 7_515_535_183 },
  // bundles/e4b, manifest 1.0.0-weights-staged.2-gemma4.
  "eliza-1-4b": { textBytes: 8_031_240_160, downloadBytes: 11_533_330_266 },
  // Pending tiers: only the (pre-Gemma-cutover) text GGUF is hosted.
  "eliza-1-9b": { textBytes: 7_381_381_632 },
  "eliza-1-27b": { textBytes: 18_687_045_248 },
  "eliza-1-27b-256k": { textBytes: 18_687_045_248 },
};

const BYTES_PER_GIB = 1024 ** 3;

function bytesToCatalogGb(bytes: number): number {
  return Number((bytes / BYTES_PER_GIB).toFixed(1));
}

function tierTextSizeGb(id: Eliza1TierId): number {
  return bytesToCatalogGb(ELIZA_1_PUBLISHED_ARTIFACT_BYTES[id].textBytes);
}

function tierDownloadSizeGb(id: Eliza1TierId): number | undefined {
  const bytes = ELIZA_1_PUBLISHED_ARTIFACT_BYTES[id].downloadBytes;
  return bytes === undefined ? undefined : bytesToCatalogGb(bytes);
}

interface TierSpec {
  id: Eliza1TierId;
  params: CatalogModel["params"];
  parameterLabel?: CatalogModel["parameterLabel"];
  /**
   * RAM floor: text weights (`tierTextSizeGb`) + a native-window KV reserve +
   * ~1 GB runtime overhead. `device-fit.ts` derives the per-token KV rate from
   * `minRamGb - sizeGb - 1`, so this must stay above the weights.
   */
  minRamGb: number;
  bucket: CatalogModel["bucket"];
  contextLength: number;
  /**
   * Context-window suffix of the primary published text GGUF (`128k`, `256k`).
   * The full published filename is derived as
   * `text/eliza-1-<publishedSlug>-<textContextSuffix>.gguf` so the size-vs-arch
   * slug mapping stays in exactly one place (`ELIZA_1_BUNDLE_SLUGS`).
   */
  textContextSuffix: string;
  q4MinRamGb: number;
  gpuProfile?: CatalogModel["gpuProfile"];
  hasEmbedding?: boolean;
  hasVision?: boolean;
  /**
   * WS3: whether this tier ships a default image-gen model in the bundle
   * extras (`ELIZA_1_BUNDLE_EXTRAS.json#imagegen.perTier`). All active
   * tiers default to SD 1.5 Q5_0 until a legacy-free split-diffusion text
   * encoder is available. The diffusion weights are runtime-downloaded —
   * they are NOT part of the base-v1 bundle.
   */
  hasImageGen?: boolean;
}

const TIER_SPECS: Readonly<Record<Eliza1TierId, TierSpec>> = {
  "eliza-1-2b": {
    id: "eliza-1-2b",
    params: "2B",
    // 4.6 GiB text GGUF + 1.6 GB KV reserve + 1 GB overhead.
    minRamGb: 8,
    q4MinRamGb: 8,
    bucket: "small",
    contextLength: 131072,
    textContextSuffix: "128k",
    // WS2: vision enabled — the 2B tier is the standard "small-phone"
    // default for first-run users, so camera-to-reaction and screen
    // analysis must work here. The mmproj is ~361 MB Q8_0 (actual:
    // 361,518,784 bytes, published 2026-05-14); the arbiter owns the
    // swap with the text weights under pressure.
    hasVision: true,
    // WS3: image-gen on the standard small-phone default uses SD 1.5 Q5_0.
    hasImageGen: true,
  },
  "eliza-1-4b": {
    id: "eliza-1-4b",
    params: "4B",
    // 4B is the shipped mid tier on the Gemma 4 E4B base (7.5 GiB text GGUF).
    // Gemma KV is already minimal (MQA + windowed-SWA + shared-KV) so the
    // runtime ships stock KV (f16/q8_0) — the legacy head_dim=128 QJL/Polar
    // kernels do not apply to Gemma's dual head dims (512 global / 256 swa).
    // The floor is weights + 2.4 GB KV reserve + 1 GB overhead.
    minRamGb: 11,
    q4MinRamGb: 11,
    bucket: "mid",
    contextLength: 131072,
    textContextSuffix: "128k",
    hasEmbedding: true,
    hasVision: true,
    // WS3: 4B uses the same monolithic SD 1.5 default as the rest of the
    // Gemma cutover catalog.
    hasImageGen: true,
  },
  "eliza-1-9b": {
    id: "eliza-1-9b",
    params: "9B",
    // 6.9 GiB hosted text GGUF + 5.6 GB KV reserve + 1 GB overhead.
    minRamGb: 14,
    q4MinRamGb: 14,
    bucket: "large",
    contextLength: 131072,
    textContextSuffix: "128k",
    gpuProfile: "rtx-3090",
    hasEmbedding: true,
    hasVision: true,
    // WS3: keep 9B on the monolithic SD 1.5 default until a legacy-free
    // split-diffusion text encoder is available.
    hasImageGen: true,
  },
  "eliza-1-27b": {
    id: "eliza-1-27b",
    params: "27B",
    // 17.4 GiB hosted text GGUF + 14.2 GB KV reserve + 1 GB overhead.
    minRamGb: 33,
    q4MinRamGb: 33,
    bucket: "large",
    contextLength: 131072,
    textContextSuffix: "128k",
    gpuProfile: "rtx-4090",
    hasEmbedding: true,
    hasVision: true,
    hasImageGen: true,
  },
  "eliza-1-27b-256k": {
    id: "eliza-1-27b-256k",
    params: "27B",
    parameterLabel: "27B 256k",
    // 17.4 GiB hosted text GGUF + 30.2 GB KV reserve + 1 GB overhead.
    minRamGb: 49,
    q4MinRamGb: 49,
    bucket: "large",
    contextLength: 262144,
    textContextSuffix: "256k",
    gpuProfile: "h200",
    hasEmbedding: true,
    hasVision: true,
    hasImageGen: true,
  },
};

/**
 * Hugging Face directory slug for each stable product tier.
 *
 * The repository uses architecture slugs after the Gemma-4 cutover. Directory
 * existence is not publication: only `ELIZA_1_PUBLISHED_TIER_IDS` have a
 * validated manifest and may cross the downloader boundary.
 */
export const ELIZA_1_BUNDLE_SLUGS: Readonly<Record<Eliza1TierId, string>> = {
  "eliza-1-2b": "e2b",
  "eliza-1-4b": "e4b",
  "eliza-1-9b": "12b",
  "eliza-1-27b": "31b",
  "eliza-1-27b-256k": "31b-256k",
};

export const ELIZA_1_PUBLISHED_TIER_IDS = [
  "eliza-1-2b",
  "eliza-1-4b",
] as const satisfies ReadonlyArray<Eliza1TierId>;

/** Manifest-bearing tiers that the runtime may download. */
export const ELIZA_1_PUBLISHED_SLUGS: Readonly<
  Partial<Record<Eliza1TierId, string>>
> = {
  "eliza-1-2b": ELIZA_1_BUNDLE_SLUGS["eliza-1-2b"],
  "eliza-1-4b": ELIZA_1_BUNDLE_SLUGS["eliza-1-4b"],
};

export function tierBundleSlug(id: Eliza1TierId): string {
  return ELIZA_1_BUNDLE_SLUGS[id];
}

export function tierPublishedSlug(id: Eliza1TierId): string | undefined {
  return ELIZA_1_PUBLISHED_SLUGS[id];
}

export function isEliza1TierPublished(id: string): boolean {
  return Object.hasOwn(ELIZA_1_PUBLISHED_SLUGS, id);
}

export function isEliza1TierId(id: string): id is Eliza1TierId {
  return Object.hasOwn(ELIZA_1_BUNDLE_SLUGS, id);
}

function tierDisplaySlug(id: Eliza1TierId): string {
  switch (id) {
    case "eliza-1-2b":
      return "2B";
    case "eliza-1-4b":
      return "4B";
    case "eliza-1-9b":
      return "9B";
    case "eliza-1-27b":
      return "27B";
    case "eliza-1-27b-256k":
      return "27B-256k";
  }
  const exhaustive: never = id;
  return exhaustive;
}

function tierDisplayName(id: Eliza1TierId): string {
  return `eliza-1-${tierDisplaySlug(id)}`;
}

function bundleRemotePrefix(id: Eliza1TierId): string {
  return `bundles/${tierBundleSlug(id)}`;
}

function bundlePath(_id: Eliza1TierId, rel: string): string {
  return rel;
}

function bundleRemotePath(id: Eliza1TierId, rel: string): string {
  return `${bundleRemotePrefix(id)}/${rel}`;
}

type SourceComponentMap = NonNullable<
  CatalogModel["sourceModel"]
>["components"];

function bundleComponent(
  id: Eliza1TierId,
  file: string,
): { repo: string; file: string } {
  return { repo: ELIZA_1_HF_REPO, file: bundleRemotePath(id, file) };
}

function primaryVoiceFileForTier(_id: Eliza1TierId): string {
  return "tts/kokoro/kokoro-82m-v1_0.gguf";
}

function asrFileForTier(id: Eliza1TierId): string {
  return `asr/mmproj-audio-${tierBundleSlug(id)}-bf16.gguf`;
}

function textFileForTier(id: Eliza1TierId): string {
  const spec = TIER_SPECS[id];
  return `text/eliza-1-${tierBundleSlug(id)}-${spec.textContextSuffix}.gguf`;
}

function sourceModelForTier(id: Eliza1TierId): CatalogModel["sourceModel"] {
  const spec = TIER_SPECS[id];
  const components: SourceComponentMap = {
    text: bundleComponent(id, textFileForTier(id)),
    voice: bundleComponent(id, primaryVoiceFileForTier(id)),
    asr: bundleComponent(id, asrFileForTier(id)),
    vad: bundleComponent(id, "vad/silero-vad-v5.gguf"),
  };

  // Runtime ASR remains gated by the bundle manifest + provenance checks. The
  // catalog points at the Gemma audio mmproj artifact the active manifests use;
  // the fused runtime treats the bundle's `asr/` directory as the loadability
  // gate so additional ASR files can be added without changing this source
  // component handle.

  // LiteRT-LM single-file bundle for the on-device runtime: text + vision +
  // audio + MTP packed into one QAT (.litertlm) artifact, parallel to the
  // GGUF `text` component. Only the mobile-class tiers ship it.
  if (isOnDeviceTier(id)) {
    components.litert = bundleComponent(
      id,
      `text/eliza-1-${tierBundleSlug(id)}.litertlm`,
    );
  }

  if (spec.hasEmbedding) {
    components.embedding = bundleComponent(
      id,
      "embedding/eliza-1-embedding.gguf",
    );
  }
  if (spec.hasVision) {
    components.vision = bundleComponent(
      id,
      `vision/mmproj-${tierBundleSlug(id)}.gguf`,
    );
  }
  // Separate-drafter MTP is the Gemma release shape. Advertise the component
  // only for tiers whose gemma4-assistant drafter GGUF is actually hosted at
  // `bundles/<tier>/mtp/drafter-<tier>.gguf` (ELIZA_1_HOSTED_MTP_TIER_IDS);
  // the `dflash/` files still present on other tiers are legacy artifacts.
  if (hostedMtpDrafterAvailableForTier(id)) {
    components.mtp = bundleComponent(
      id,
      `mtp/drafter-${tierBundleSlug(id)}.gguf`,
    );
  }

  return { finetuned: false, components };
}

function runtimeForTier(
  id: Eliza1TierId,
  contextLength: number,
): CatalogModel["runtime"] {
  const requiresKernel: LocalRuntimeKernel[] =
    contextLength >= 65536
      ? [...BASE_REQUIRED_KERNELS, "turbo3_tcq"]
      : BASE_REQUIRED_KERNELS;
  const runtime: CatalogModel["runtime"] = {
    preferredBackend: "llama-cpp",
    optimizations: {
      // Gemma-aware RAM defaults (epic #9033). Eliza-1 is Gemma-4-based and
      // hits llama.cpp/#21690: the server KV context-checkpoint ring grows
      // unbounded on Gemma (a handful of ~16K-prompt turns filled ~64 GB in
      // the upstream repro). The on-device Eliza-1 runtime is single-user, so
      // pin single-slot decode (`-np 1`) and bound the checkpoint ring to 1 —
      // this is pure config, not a kernel change, and only touches the
      // Gemma-4 Eliza-1 tiers built here (never other models).
      parallel: 1,
      flashAttention: true,
      requiresKernel,
      // OpenVINO is the right backend for ASR/Whisper on Intel hosts but
      // never for autoregressive text. The text path uses optimized
      // llama.cpp kernels plus native MTP heads.
      unsupportedKernels: ["openvino"],
      ctxCheckpoints: 1,
      ctxCheckpointInterval: 4096,
    },
  };

  if (hostedMtpDrafterAvailableForTier(id)) {
    // Separate-drafter MTP: Gemma 4 ships an official standalone drafter
    // GGUF, loaded via `-md mtp/drafter-<tier>.gguf --spec-type draft-mtp`.
    //
    // Draft window = 1 (single speculative token). The bionic/desktop FFI
    // MTP engine uses a FIXED window equal to `draftMax` (no adaptive
    // acceptance schedule; `eliza-inference-ffi.cpp` sets
    // `sp.draft.n_max = draft_max`), so the catalog value is the live window.
    // The gemma4-assistant NextN head reliably predicts exactly one token;
    // its multi-token acceptance collapses past the first, so a larger window
    // burns draft forwards that get rejected and regresses decode. Measured on
    // Apple M-series Metal against the eliza-1-2b (Q8) target, greedy, across
    // 3 prompts:
    //   draftMax=1 => 1.37-1.66x win | =2 => ~0.90x | =4 => 0.61x | =6 => 0.37x
    // draftMax=1 is the measured-optimal, never-regress window for this drafter
    // on every tier; widening it is a per-tier/per-device tuning question that
    // needs on-hardware measurement before it can beat 1.
    runtime.mtp = {
      specType: "draft-mtp",
      drafterFile: `mtp/drafter-${tierBundleSlug(id)}.gguf`,
      draftMin: 1,
      draftMax: 1,
      gpuLayers: "auto",
    };
  }

  return runtime;
}

const QUANT_SUFFIX: Record<CatalogQuantizationId, string> = {
  q3_k_m: "q3_k_m",
  // Google's official Gemma-4 QAT quant. `Q4_0` is the GGUF block format
  // their QAT checkpoints export to — distinct from the post-training
  // `q4_k_m` we ship as the desktop default.
  q4_0: "Q4_0",
  q4_k_m: "q4_k_m",
  q5_k_m: "q5_k_m",
  q6_k: "q6_k",
  q8_0: "q8_0",
  // LiteRT-LM mobile bundle suffix. The artifact is a `.litertlm`, not a
  // `.gguf`; `textLiteRtComponent` overrides the filename, so this suffix
  // only feeds the non-LiteRT variant-id naming path defensively.
  wna8o8: "wna8o8",
};

function textQuantizationMatrix(args: {
  primaryGgufFile: string;
  q4SizeGb: number;
  q4MinRamGb: number;
  /**
   * On-device (mobile-class) tier. When true the Gemma-4 QAT `Q4_0` variant
   * is flagged `mobilePreferred` so the on-device selector picks it over the
   * post-training `q4_k_m` default.
   */
  onDevice: boolean;
}): NonNullable<CatalogModel["quantization"]> {
  const fileBase = args.primaryGgufFile.replace(/\.gguf$/, "");
  const litertFile = `${fileBase.replace(/-128k$|-256k$/, "")}.litertlm`;
  const mk = (
    id: CatalogQuantizationId,
    label: CatalogQuantizationVariant["label"],
    scale: number,
    minRamScale: number,
    status: CatalogQuantizationVariant["status"],
    extra?: Pick<
      CatalogQuantizationVariant,
      "mobilePreferred" | "artifactFormat"
    >,
  ): CatalogQuantizationVariant => ({
    id,
    label,
    ggufFile:
      extra?.artifactFormat === "litertlm"
        ? litertFile
        : id === "q4_k_m"
          ? args.primaryGgufFile
          : `${fileBase}-${QUANT_SUFFIX[id]}.gguf`,
    sizeGb: Number((args.q4SizeGb * scale).toFixed(1)),
    minRamGb: Math.ceil(args.q4MinRamGb * minRamScale),
    status,
    ...extra,
  });

  const variants: CatalogQuantizationVariant[] = [
    mk("q3_k_m", "3-bit", 0.76, 0.85, "planned"),
    // Gemma-4 QAT Q4_0: same ~4-bit footprint as q4_k_m but the official
    // quantization-aware-trained checkpoint. Keep this planned until the
    // tier-specific `*-Q4_0.gguf` artifacts are present in the hosted bundle.
    mk(
      "q4_0",
      "4-bit",
      0.94,
      0.95,
      "planned",
      args.onDevice ? { mobilePreferred: true } : undefined,
    ),
    mk("q4_k_m", "4-bit", 1, 1, "published"),
    mk("q5_k_m", "5-bit", 1.22, 1.18, "planned"),
    mk("q6_k", "6-bit", 1.45, 1.35, "planned"),
    mk("q8_0", "8-bit", 1.95, 1.8, "planned"),
  ];

  // On-device tiers also advertise the LiteRT-LM `.litertlm` bundle: the
  // wNa8o8 (4-bit weight / 8-bit activation) mobile schema run by the
  // LiteRT-LM runtime (NPU/GPU delegate), not llama.cpp. It carries the same
  // ~4-bit footprint as the QAT Q4_0 GGUF.
  if (args.onDevice) {
    variants.push(
      mk("wna8o8", "4-bit", 0.94, 0.95, "planned", {
        artifactFormat: "litertlm",
      }),
    );
  }

  return { defaultVariantId: "q4_k_m", variants };
}

function blurbForTier(id: Eliza1TierId): string {
  const displayName = tierDisplayName(id);
  switch (id) {
    case "eliza-1-2b":
      return `${displayName} - smallest/entry local tier for low-memory phones and CPU fallback.`;
    case "eliza-1-4b":
      return `${displayName} - balanced local tier for modern laptops and desktops.`;
    case "eliza-1-9b":
      return `${displayName} - workstation local tier for stronger reasoning.`;
    case "eliza-1-27b":
      return `${displayName} - high-quality local tier for GPU workstations.`;
    case "eliza-1-27b-256k":
      return `${displayName} - long-context local tier for high-memory GPU workstations.`;
  }
  const exhaustive: never = id;
  return exhaustive;
}

function chatTier(id: Eliza1TierId): CatalogModel {
  const spec = TIER_SPECS[id];
  const downloadSizeGb = tierDownloadSizeGb(id);
  return {
    id,
    displayName: tierDisplayName(id),
    hfRepo: ELIZA_1_HF_REPO,
    hfPathPrefix: bundleRemotePrefix(id),
    ggufFile: bundlePath(id, textFileForTier(id)),
    bundleManifestFile: bundlePath(id, "eliza-1.manifest.json"),
    params: spec.params,
    parameterLabel: spec.parameterLabel,
    quant: "Eliza-1 optimized local runtime",
    sizeGb: tierTextSizeGb(id),
    ...(downloadSizeGb === undefined ? {} : { downloadSizeGb }),
    minRamGb: spec.minRamGb,
    category: "chat",
    bucket: spec.bucket,
    contextLength: spec.contextLength,
    tokenizerFamily: "gemma4",
    runtimeClass: "fused-eliza1",
    sourceModel: sourceModelForTier(id),
    voiceBackends: ELIZA_1_VOICE_BACKENDS[id],
    runtime: runtimeForTier(id, spec.contextLength),
    gpuProfile: spec.gpuProfile,
    quantization: textQuantizationMatrix({
      primaryGgufFile: bundlePath(id, textFileForTier(id)),
      q4SizeGb: tierTextSizeGb(id),
      q4MinRamGb: spec.q4MinRamGb,
      onDevice: isOnDeviceTier(id),
    }),
    blurb: blurbForTier(id),
    publishStatus: eliza1TierPublishStatus(id),
    activationEligible: isEliza1TierActivationEligible(id),
  };
}

export const MODEL_CATALOG: CatalogModel[] = ELIZA_1_TIER_IDS.map((id) =>
  chatTier(id),
);

export function findCatalogModel(id: string): CatalogModel | undefined {
  return MODEL_CATALOG.find((m) => m.id === id);
}

export function buildHuggingFaceResolveUrlForPath(
  model: CatalogModel,
  filePath: string,
): string {
  return buildHuggingFaceResolveUrlCandidatesForPath(model, filePath)[0].url;
}

export interface HfResolveUrlCandidate extends HfDownloadBase {
  /** Fully-qualified URL for this candidate base. */
  url: string;
}

export function buildHuggingFaceResolveUrlCandidatesForPath(
  model: CatalogModel,
  filePath: string,
): HfResolveUrlCandidate[] {
  const cleanFilePath = trimStartCharacters(filePath, "/");
  const cleanPrefix = model.hfPathPrefix
    ? trimBoundaryCharacters(model.hfPathPrefix, "/")
    : undefined;
  const pathWithPrefix =
    cleanPrefix &&
    cleanFilePath !== cleanPrefix &&
    !cleanFilePath.startsWith(`${cleanPrefix}/`)
      ? `${cleanPrefix}/${cleanFilePath}`
      : cleanFilePath;
  if (model.hub === "modelscope") {
    const base =
      trimEndCharacters(
        process.env.ELIZA_MODELSCOPE_BASE_URL?.trim() ?? "",
        "/",
      ) || "https://www.modelscope.cn";
    const encodedPath = pathWithPrefix
      .split("/")
      .map((segment) => encodeURIComponent(segment))
      .join("/");
    return [
      {
        base,
        url: `${base}/models/${model.hfRepo}/resolve/master/${encodedPath}`,
        viaCloud: false,
        label: "direct",
      },
    ];
  }
  const encodedPath = pathWithPrefix
    .split("/")
    .map((segment) => encodeURIComponent(segment))
    .join("/");
  return resolveHfDownloadBases().map((candidate) => ({
    ...candidate,
    url: `${candidate.base}/${model.hfRepo}/resolve/main/${encodedPath}?download=true`,
  }));
}

export function buildHuggingFaceResolveUrl(model: CatalogModel): string {
  return buildHuggingFaceResolveUrlForPath(model, model.ggufFile);
}

export function isEliza1ModelFamilyId(id: string): boolean {
  return id.startsWith("eliza-1-");
}
export function isDefaultLocalModelFamily(model: CatalogModel): boolean {
  return (
    isEliza1ModelFamilyId(model.id) && DEFAULT_ELIGIBLE_MODEL_IDS.has(model.id)
  );
}
/**
 * Settings/first-run may offer a model only when it is published AND its
 * published manifest passes the activation gate — the same eligibility rule
 * the runtime applies before activating the installed bundle.
 */
export function isSettingsDefaultLocalModel(model: CatalogModel): boolean {
  return isDefaultLocalModelFamily(model) && isCatalogModelOfferable(model);
}
export function isVerifiedCuratedEliza1Download(
  model: InstalledModel,
): boolean {
  return (
    model.source === "eliza-download" &&
    DEFAULT_ELIGIBLE_MODEL_IDS.has(model.id) &&
    typeof model.bundleVerifiedAt === "string" &&
    model.bundleVerifiedAt.length > 0
  );
}
export function filterSettingsDefaultLocalModels(
  catalog: CatalogModel[],
): CatalogModel[] {
  return catalog.filter(isSettingsDefaultLocalModel);
}
