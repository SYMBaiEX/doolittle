/**
 * Cross-platform KV-cache type resolver for llama.cpp loads.
 *
 * Both the AOSP bun adapter (`packages/agent/src/runtime/aosp-llama-adapter.ts`)
 * and the Capacitor in-WebView adapter (`./capacitor-llama-adapter.ts`) need
 * the same precedence chain when picking K/V cache types:
 *
 *   1. Explicit `LoadOptions.cacheType{K,V}` from the caller (highest).
 *   2. `ELIZA_LLAMA_CACHE_TYPE_K` / `ELIZA_LLAMA_CACHE_TYPE_V` env vars.
 *   3. Otherwise undefined — the loader leaves cache types at llama.cpp's
 *      fp16 default.
 *
 * The resolver is pure: no DOM, no Node APIs. It works in the renderer
 * (Capacitor WebView, where `process.env` is `{}`) and in the bun runtime
 * (where `process.env` is the OS environment).
 *
 * Recognised type names (all comparisons are case-insensitive):
 *   - `f16`     → llama.cpp's fp16 KV cache (upstream default).
 *   - `tbq3_0`  → buun-llama-cpp fork's TurboQuant 3-bit value cache.
 *   - `tbq4_0`  → buun-llama-cpp fork's TurboQuant 4-bit key cache.
 *
 * Stock llama.cpp builds without the buun fork ignore tbq3_0/tbq4_0 because
 * the underlying Capacitor plugin has no `setCacheType` bridge there
 * (warn-and-skip surface in `capacitor-llama-adapter.ts`). The AOSP adapter
 * routes the same names through the fork-specific shim setters.
 */

export type KvCacheTypeName = "f16" | "tbq3_0" | "tbq4_0";

const RECOGNISED_NAMES: ReadonlySet<KvCacheTypeName> = new Set([
  "f16",
  "tbq3_0",
  "tbq4_0",
]);

export interface KvCacheOverride {
  k?: KvCacheTypeName;
  v?: KvCacheTypeName;
}

/** Pure env reader. No process.env coupling — caller passes the env object. */
export type EnvLike = Record<string, string | undefined>;

/**
 * Optional warning sink so callers in environments without `process` (e.g.
 * the WebView) can route to console.warn while bun-side callers can route
 * to their structured logger.
 */
export type WarnSink = (message: string) => void;

function defaultWarn(message: string): void {
  // eslint-disable-next-line no-console
  if (typeof console !== "undefined") console.warn(message);
}

/**
 * Read a `KvCacheTypeName` from an env-like map. Returns undefined when the
 * var is unset, blank, or not a recognised name. Unrecognised values warn
 * (via `warn`) and return undefined so a typo doesn't crash the loader.
 *
 * Exported for unit tests.
 */
export function readEnvKvCacheType(
  name: string,
  env: EnvLike,
  warn: WarnSink = defaultWarn,
): KvCacheTypeName | undefined {
  const raw = env[name]?.trim().toLowerCase();
  if (!raw) return undefined;
  if (RECOGNISED_NAMES.has(raw as KvCacheTypeName)) {
    return raw as KvCacheTypeName;
  }
  warn(
    `[kv-cache-resolver] ${name}=${raw} is not a recognised KV cache type; ignoring (use f16 / tbq3_0 / tbq4_0).`,
  );
  return undefined;
}

/**
 * Resolve the KV-cache type to use for a given model load. See module-level
 * docblock for the precedence chain.
 *
 * Returns `undefined` when no override applies (neither side selected),
 * letting the caller skip the bridge methods entirely. When at least one
 * side is selected the returned object always carries both `k` and `v`
 * fields; either may be undefined when only the other side was overridden.
 */
export function resolveKvCacheType(
  _modelPath: string,
  override: KvCacheOverride | undefined,
  env: EnvLike,
  warn: WarnSink = defaultWarn,
): KvCacheOverride | undefined {
  const explicitK = override?.k;
  const explicitV = override?.v;
  const envK = readEnvKvCacheType("ELIZA_LLAMA_CACHE_TYPE_K", env, warn);
  const envV = readEnvKvCacheType("ELIZA_LLAMA_CACHE_TYPE_V", env, warn);
  const k = explicitK ?? envK;
  const v = explicitV ?? envV;
  if (k === undefined && v === undefined) return undefined;
  return { k, v };
}
