/**
 * Transport-neutral host controller primitives shared by the standalone agent
 * and app. HTTP authorization, response shaping, runtime lookup, and
 * persistence remain host-owned trust-boundary concerns.
 */
/**
 * Coalesces overlapping host wake requests onto one pass per TaskService
 * instance. Each host owns a coordinator, while runtime replacement remains an
 * independent scheduling boundary inside that host.
 */
export class BackgroundTaskRunCoordinator {
    inFlight = new WeakMap();
    async run(service) {
        const existing = this.inFlight.get(service);
        if (existing !== undefined) {
            await existing;
            return { coalesced: true };
        }
        const current = service.runDueTasks();
        this.inFlight.set(service, current);
        try {
            await current;
            return { coalesced: false };
        }
        finally {
            if (this.inFlight.get(service) === current) {
                this.inFlight.delete(service);
            }
        }
    }
}
/** Canonical formatting-insensitive representation of a device pairing code. */
export function normalizeHostPairingCode(code) {
    return code.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
}
