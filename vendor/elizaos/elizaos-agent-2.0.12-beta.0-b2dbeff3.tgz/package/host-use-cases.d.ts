/**
 * Transport-neutral host controller primitives shared by the standalone agent
 * and app. HTTP authorization, response shaping, runtime lookup, and
 * persistence remain host-owned trust-boundary concerns.
 */
export interface DueTaskRunner {
    runDueTasks(): Promise<void>;
}
/**
 * Coalesces overlapping host wake requests onto one pass per TaskService
 * instance. Each host owns a coordinator, while runtime replacement remains an
 * independent scheduling boundary inside that host.
 */
export declare class BackgroundTaskRunCoordinator {
    private readonly inFlight;
    run(service: DueTaskRunner): Promise<{
        coalesced: boolean;
    }>;
}
/** Canonical formatting-insensitive representation of a device pairing code. */
export declare function normalizeHostPairingCode(code: string): string;
