/** Reply correlation belongs to one runtime, HTTP host, and authenticated client. */
import { randomUUID } from "node:crypto";
import { ElizaError, satisfiesRoleGate, } from "@elizaos/core";
import { onNativeViewDisconnect, sendNativeViewFrame, } from "./native-view-renderer.js";
import { PendingRequestMap, } from "./pending-request-map.js";
import { assertRuntimeViewEntry } from "./view-installations.js";
export class ViewInteractionHost {
    runtime;
    closed = false;
    pending = new PendingRequestMap();
    callers = new Map();
    stopSignal;
    onRuntimeStop = () => this.close();
    constructor(runtime) {
        this.runtime = runtime;
        this.stopSignal = runtime.getStopSignal?.();
        if (this.stopSignal?.aborted)
            this.close();
        else
            this.stopSignal?.addEventListener("abort", this.onRuntimeStop, {
                once: true,
            });
    }
    waitFor(requestId, clientId, entry, timeoutMs, binding = {}) {
        if (this.closed)
            throw new ElizaError("View host is closed", { code: "VIEW_HOST_CLOSED" });
        assertRuntimeViewEntry(this.runtime, entry);
        if (this.callers.has(requestId))
            throw new ElizaError("A renderer request with this ID is already pending", {
                code: "VIEW_REQUEST_PENDING",
            });
        if (binding.navigation) {
            const priorNavigations = [...this.callers].filter(([, prior]) => prior.navigation &&
                prior.clientId === clientId &&
                prior.ownerId === binding.ownerId);
            // A claim has already authorized renderer execution. Reject another
            // preparation until it settles rather than revoke its acknowledgment or
            // allow two claimed destinations to commit out of order.
            if (priorNavigations.some(([, prior]) => prior.claimId))
                throw new ElizaError("A navigation is already being applied", {
                    code: "VIEW_NAVIGATION_BUSY",
                });
            for (const [id] of priorNavigations)
                this.cancel(id, new ElizaError("Navigation was superseded", {
                    code: "VIEW_NAVIGATION_SUPERSEDED",
                }));
        }
        const caller = { clientId, entry, ...binding };
        this.callers.set(requestId, caller);
        const detach = onNativeViewDisconnect(this.runtime, clientId, () => this.cancel(requestId, new Error("Native renderer disconnected; outcome unknown")));
        return this.pending.waitFor(requestId, timeoutMs).finally(() => {
            detach();
            if (this.callers.get(requestId) === caller)
                this.callers.delete(requestId);
        });
    }
    /** One renderer may execute a delivered request, even across duplicate sockets. */
    claim(clientId, binding, roles, ownerId) {
        const caller = this.matchCaller(clientId, binding);
        if (!caller ||
            (caller.ownerId !== undefined && caller.ownerId !== ownerId) ||
            caller.claimId ||
            !satisfiesRoleGate(roles, caller.entry.roleGate))
            return null;
        caller.claimId = randomUUID();
        return caller.claimId;
    }
    matchCaller(clientId, binding) {
        const caller = binding.requestId
            ? this.callers.get(binding.requestId)
            : undefined;
        if (this.closed ||
            !caller ||
            caller.clientId !== clientId ||
            caller.entry.id !== binding.viewId ||
            caller.entry.viewType !== binding.viewType ||
            caller.entry.installationId !== binding.installationId)
            return null;
        try {
            assertRuntimeViewEntry(this.runtime, caller.entry);
        }
        catch (error) {
            // error-policy:J4 retired installations cannot claim work or settle replies.
            // The outcome remains unknown until cancellation or timeout; never replay.
            if (error instanceof ElizaError &&
                (error.code === "VIEW_INSTALLATION_INVALID" ||
                    error.code === "VIEW_REGISTRY_CLOSED"))
                return null;
            throw error;
        }
        return caller;
    }
    resolve(clientId, result, ownerId) {
        const caller = this.matchCaller(clientId, result);
        if (!caller?.claimId ||
            caller.claimId !== result.claimId ||
            (caller.ownerId !== undefined && caller.ownerId !== ownerId))
            return false;
        if (caller.navigation) {
            const value = result.result;
            if (!value ||
                typeof value !== "object" ||
                Array.isArray(value) ||
                Object.keys(value).length !== 1 ||
                !("switched" in value) ||
                value.switched !== result.success ||
                result.error !== undefined)
                return false;
        }
        this.pending.resolve(result.requestId, {
            requestId: result.requestId,
            success: result.success,
            ...(result.result !== undefined ? { result: result.result } : {}),
            ...(result.error !== undefined ? { error: result.error } : {}),
        });
        return true;
    }
    cancel(requestId, reason) {
        this.callers.delete(requestId);
        this.pending.reject(requestId, reason);
    }
    close() {
        if (this.closed)
            return;
        this.closed = true;
        this.stopSignal?.removeEventListener("abort", this.onRuntimeStop);
        this.callers.clear();
        this.pending.rejectAll(new ElizaError("View host closed before the outcome was received", {
            code: "VIEW_HOST_CLOSED",
        }));
    }
}
const hosts = new WeakMap();
const closedHosts = new WeakSet();
/** The host key is its in-process server state, never a supplied ID. */
export function viewInteractionHost(runtime, hostKey) {
    if (closedHosts.has(hostKey) || runtime.getStopSignal?.().aborted)
        throw new ElizaError("View host is closed", { code: "VIEW_HOST_CLOSED" });
    let runtimes = hosts.get(hostKey);
    if (!runtimes) {
        runtimes = new Map();
        hosts.set(hostKey, runtimes);
    }
    let host = runtimes.get(runtime);
    if (!host) {
        host = new ViewInteractionHost(runtime);
        runtimes.set(runtime, host);
    }
    return host;
}
export function closeViewInteractionHost(hostKey) {
    closedHosts.add(hostKey);
    for (const host of hosts.get(hostKey)?.values() ?? [])
        host.close();
    hosts.delete(hostKey);
    broadcasters.delete(hostKey);
}
const broadcasters = new WeakMap();
const requestHosts = new WeakMap();
export function bindViewRequestHost(request, hostKey) {
    requestHosts.set(request, hostKey);
}
export function getViewRequestBroadcast(request) {
    return getViewsBroadcastWs(requestHosts.get(request));
}
export function setViewsBroadcastWs(hostKey, broadcast, targeted) {
    if (closedHosts.has(hostKey))
        return;
    broadcasters.set(hostKey, { broadcast, targeted: targeted ?? null });
}
export function getViewsBroadcastWs(hostKey) {
    return hostKey && !closedHosts.has(hostKey)
        ? (broadcasters.get(hostKey)?.broadcast ?? null)
        : null;
}
export function getViewsBroadcastWsToClientId(hostKey) {
    if (!hostKey || closedHosts.has(hostKey))
        return null;
    const ws = broadcasters.get(hostKey)?.targeted;
    return (clientId, payload) => {
        // Native clients use this same host's runtime and the same claim/result map.
        // Never broadcast a targeted command onto the general event bus.
        for (const runtime of hosts.get(hostKey)?.keys() ?? []) {
            const sent = sendNativeViewFrame(runtime, hostKey, clientId, payload);
            if (sent)
                return sent;
        }
        return ws?.(clientId, payload) ?? 0;
    };
}
