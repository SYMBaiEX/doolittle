/**
 * Matches host plugin routes for dispatch, lazy loading and route admission.
 * Empty slash segments are ignored; named parameters and nonempty wildcard
 * tails are decoded once, preserving raw parameter text for malformed escapes.
 * The matcher has no runtime imports so lazy route gates stay cheap.
 */
export declare function matchPluginRoutePath(pattern: string, pathname: string): Record<string, string> | null;
