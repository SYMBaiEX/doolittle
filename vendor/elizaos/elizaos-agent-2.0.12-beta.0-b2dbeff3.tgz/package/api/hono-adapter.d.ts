import type { AccessContext, IAgentRuntime } from "@elizaos/core";
import { Hono } from "hono";
/**
 * Hono adapter for plugin routes.
 *
 * Registers every entry in `runtime.routes` onto a Hono app, marshals the
 * incoming Hono `Context` into a `RouteHandlerContext`, calls the canonical
 * `dispatchRoute` (with `inProcess: false`), and writes the result back to
 * Hono.
 *
 * This lives in front of the existing hardcoded Node HTTP handlers — it
 * covers any plugin route registered via `runtime.routes`. The hardcoded
 * handlers will be migrated onto `runtime.routes` in later phases.
 */
export interface HonoAdapterOptions {
    /** Native transport provenance, supplied only by the authenticated host adapter. */
    inProcess?: (req: Request) => boolean;
    /** Predicate that decides whether the incoming request has a valid token. */
    isAuthorized: (req: Request) => boolean;
    /** Predicate that decides whether the incoming request is trusted loopback/local. */
    isTrustedLocal?: (req: Request) => boolean;
    /**
     * Boundary-resolved requester identity for per-viewer DTO selection
     * (#14781). Absent/`undefined` means the single-owner local boundary and
     * routes serve their existing unfiltered content.
     */
    resolveAccessContext?: (req: Request) => AccessContext | undefined;
}
/**
 * Mount every `runtime.routes` entry onto the given Hono app.
 *
 * Each registered handler runs the canonical {@link dispatchRoute}; that means
 * the Hono surface and the in-process IPC surface execute the exact same code
 * path against the same route table.
 */
export declare function mountRoutesOnHono(app: Hono, runtime: IAgentRuntime, options: HonoAdapterOptions): void;
/** Convenience: build a new Hono app already wired to the runtime. */
export declare function buildHonoAppForRuntime(runtime: IAgentRuntime, options: HonoAdapterOptions): Hono;
