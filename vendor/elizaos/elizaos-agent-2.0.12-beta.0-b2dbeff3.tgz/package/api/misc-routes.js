/**
 * Grab-bag of local control-API endpoints too small for their own module:
 * process restart (POST /api/restart), the share-sheet ingest queue
 * (POST | GET /api/ingest/share), agent event-stream ingestion into the WS
 * broadcast buffer (POST /api/agent/event and the per-agent
 * /api/agents/:id/event variant), coarse IP-based coordinates for the weather
 * widget's no-permission fallback (GET /api/location/approximate), authorized
 * single-line terminal command execution (POST /api/terminal/run), and
 * custom-action CRUD + NL generation + test (/api/custom-actions...). Terminal
 * runs and shell/code custom actions sit behind the local-code-execution gate
 * and terminal-authorization checks.
 */
import crypto from "node:crypto";
import { PostAgentEventRequestSchema, PostCustomActionGenerateRequestSchema, PostCustomActionRequestSchema, PostCustomActionTestRequestSchema, PostIngestShareRequestSchema, PostTerminalRunRequestSchema, PutCustomActionRequestSchema, } from "@elizaos/contracts";
import { logger, ModelType, validateUuid, } from "@elizaos/core";
import { isLocalCodeExecutionAllowed } from "@elizaos/host";
import { isAndroidMobile, } from "@elizaos/host/protocol";
import { composePrompt } from "@elizaos/plugin-assistant/text/template-rendering";
import { loadElizaConfig, saveElizaConfig } from "../config/config.js";
import { buildTestHandler, registerCustomActionLive, unregisterCustomActionLive, } from "../runtime/custom-actions.js";
import { runShell } from "../services/shell-execution-router.js";
import { customActionGenerateTemplate } from "./custom-action-prompt.js";
import { parseOptionalBooleanQuery } from "./query-parameters.js";
import { decodePathComponent } from "./server-helpers.js";
import { capturedTerminalOutputIsSafe, MAX_TERMINAL_CAPTURE_BYTES, terminalRejectionResponse, } from "./terminal-output-contract.js";
import { resolveRequestedTerminalRunId, resolveTerminalRunLimits, } from "./terminal-run-limits.js";
// ---------------------------------------------------------------------------
// Approximate (IP-based) location
// ---------------------------------------------------------------------------
// Server-side IP-geolocation for the weather widget's no-permission fallback.
// The lookup runs here rather than in the browser because the public geo
// services CORS-fail on hosted app origins and would each need a CSP carve-out
// per app shell; the agent process has neither constraint. Mirrors the
// Electrobun desktop LocationManager's provider set and its coarse-accuracy
// contract: IP resolution is a city centroid (~5 km median), surfaced as
// `accuracyMeters` so no consumer can mistake it for a GPS reading.
const DEFAULT_IP_GEO_SERVICES = ["https://ipapi.co/json/", "https://ipwho.is/"];
const IP_GEO_ACCURACY_METERS = 5000;
const IP_GEO_TIMEOUT_MS = 5000;
// A public IP's city doesn't move minute-to-minute; the cache keeps repeated
// widget revalidations from hammering the free-tier providers.
const IP_GEO_CACHE_TTL_MS = 15 * 60000;
let ipGeoCache = null;
let ipGeoInFlight = null;
/** Test seam + self-hoster override: comma-separated lookup URLs. */
function ipGeoServiceUrls() {
    const raw = process.env.ELIZA_IP_GEO_SERVICES;
    if (!raw)
        return DEFAULT_IP_GEO_SERVICES;
    const urls = raw
        .split(",")
        .map((value) => value.trim())
        .filter((value) => value.length > 0);
    return urls.length > 0 ? urls : DEFAULT_IP_GEO_SERVICES;
}
/** Exported for tests: drop the module-level cache between cases. */
export function resetIpGeoCacheForTests() {
    ipGeoCache = null;
    ipGeoInFlight = null;
}
async function lookupApproximateLocation() {
    for (const url of ipGeoServiceUrls()) {
        try {
            const resp = await fetch(url, {
                signal: AbortSignal.timeout(IP_GEO_TIMEOUT_MS),
            });
            if (!resp.ok) {
                logger.warn(`[MiscRoutes] IP geolocation provider returned ${resp.status} (${url})`);
                continue;
            }
            const data = (await resp.json());
            // ipapi.co uses latitude/longitude; ipwho.is and ip-api.com use lat/lon.
            const lat = typeof data.lat === "number" ? data.lat : data.latitude;
            const lon = typeof data.lon === "number" ? data.lon : data.longitude;
            if (typeof lat !== "number" ||
                typeof lon !== "number" ||
                !Number.isFinite(lat) ||
                !Number.isFinite(lon)) {
                logger.warn(`[MiscRoutes] IP geolocation provider returned no usable coordinates (${url})`);
                continue;
            }
            return {
                lat,
                lon,
                accuracyMeters: IP_GEO_ACCURACY_METERS,
                source: new URL(url).hostname,
            };
        }
        catch (err) {
            // error-policy:J4 multi-provider fallback chain — each provider failure
            // is logged and the next provider is tried; exhausting the list yields
            // an explicit null that the route turns into a 502, never fabricated
            // coordinates.
            logger.warn({ err }, `[MiscRoutes] IP geolocation provider failed (${url})`);
        }
    }
    return null;
}
function resolveTerminalShellCommand() {
    if (process.platform === "win32") {
        return {
            command: process.env.ComSpec || "cmd.exe",
            argsFor: (command) => ["/d", "/s", "/c", command],
        };
    }
    return {
        command: process.env.CODING_TOOLS_SHELL ||
            process.env.SHELL ||
            (isAndroidMobile() ? "/system/bin/sh" : "/bin/sh"),
        argsFor: (command) => ["-c", command],
    };
}
function toTerminalRunRequestBody(body) {
    return {
        command: typeof body.command === "string" ? body.command : undefined,
        clientId: body.clientId,
        terminalToken: typeof body.terminalToken === "string" ? body.terminalToken : undefined,
    };
}
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
export async function handleMiscRoutes(ctx) {
    const { req, res, method, pathname, url, state, json, error, readJsonBody } = ctx;
    // ── GET /api/location/approximate ───────────────────────────────────
    if (method === "GET" && pathname === "/api/location/approximate") {
        if (ipGeoCache && Date.now() - ipGeoCache.fetchedAt < IP_GEO_CACHE_TTL_MS) {
            json(res, ipGeoCache.value);
            return true;
        }
        // Concurrent widget revalidations share one upstream lookup.
        ipGeoInFlight ??= lookupApproximateLocation().finally(() => {
            ipGeoInFlight = null;
        });
        const value = await ipGeoInFlight;
        if (!value) {
            error(res, "IP geolocation unavailable", 502);
            return true;
        }
        ipGeoCache = { value, fetchedAt: Date.now() };
        json(res, value);
        return true;
    }
    // ── POST /api/restart ───────────────────────────────────────────────
    if (method === "POST" && pathname === "/api/restart") {
        state.agentState = "restarting";
        state.startup = {
            ...state.startup,
            phase: "restarting",
        };
        state.broadcastStatus?.();
        json(res, { ok: true, message: "Restarting...", restarting: true });
        setTimeout(() => process.exit(0), 1000);
        return true;
    }
    // ── POST /api/ingest/share ───────────────────────────────────────────
    if (method === "POST" && pathname === "/api/ingest/share") {
        const rawShare = await readJsonBody(req, res);
        if (rawShare === null)
            return true;
        const parsedShare = PostIngestShareRequestSchema.safeParse(rawShare);
        if (!parsedShare.success) {
            error(res, parsedShare.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedShare.data;
        const item = {
            id: crypto.randomUUID(),
            source: body.source ?? "unknown",
            title: body.title,
            url: body.url,
            text: body.text,
            suggestedPrompt: body.title
                ? `What do you think about "${body.title}"?`
                : body.url
                    ? `Can you analyze this: ${body.url}`
                    : body.text
                        ? `What are your thoughts on: ${body.text}`
                        : "What do you think about this shared content?",
            receivedAt: Date.now(),
        };
        state.shareIngestQueue.push(item);
        json(res, { ok: true, item });
        return true;
    }
    // ── GET /api/ingest/share ────────────────────────────────────────────
    if (method === "GET" && pathname === "/api/ingest/share") {
        const consumeParsed = parseOptionalBooleanQuery(url.searchParams.get("consume"));
        if (!consumeParsed.ok) {
            error(res, "consume must be a boolean", 400);
            return true;
        }
        const consume = consumeParsed.value === true;
        if (consume) {
            const items = [...state.shareIngestQueue];
            state.shareIngestQueue.length = 0;
            json(res, { items });
        }
        else {
            json(res, { items: state.shareIngestQueue });
        }
        return true;
    }
    // ── POST /api/agent/event ──────────────────────────────────────────────
    if (method === "POST" &&
        (pathname === "/api/agent/event" ||
            /^\/api\/agents\/[^/]+\/event$/.test(pathname))) {
        const rawEvent = await readJsonBody(req, res);
        if (rawEvent === null)
            return true;
        const agentEventMatch = pathname.match(/^\/api\/agents\/([^/]+)\/event$/);
        if (agentEventMatch) {
            const decodedAgentId = decodePathComponent(agentEventMatch[1] ?? "", res, "agent id");
            if (decodedAgentId === null)
                return true;
            const routeAgentId = validateUuid(decodedAgentId.trim());
            if (!routeAgentId) {
                json(res, { error: "Invalid agent id" }, 400);
                return true;
            }
            if (state.runtime?.agentId && state.runtime.agentId !== routeAgentId) {
                json(res, { error: "Agent not found" }, 404);
                return true;
            }
        }
        const normalizedEvent = agentEventMatch
            ? {
                stream: "system",
                data: {
                    gatewayType: rawEvent.type,
                    userId: rawEvent.userId,
                    payload: rawEvent.payload,
                },
            }
            : rawEvent;
        const parsedEvent = PostAgentEventRequestSchema.safeParse(normalizedEvent);
        if (!parsedEvent.success) {
            error(res, parsedEvent.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedEvent.data;
        if (!ctx.AGENT_EVENT_ALLOWED_STREAMS.has(body.stream)) {
            error(res, `Invalid stream: ${body.stream}. Allowed: ${[...ctx.AGENT_EVENT_ALLOWED_STREAMS].join(", ")}`, 400);
            return true;
        }
        const envelope = {
            type: "agent_event",
            version: 1,
            eventId: `evt-${state.nextEventId}`,
            ts: Date.now(),
            stream: body.stream,
            agentId: state.runtime?.agentId
                ? String(state.runtime.agentId)
                : undefined,
            roomId: body.roomId,
            payload: body.data ?? {},
        };
        state.nextEventId += 1;
        state.eventBuffer.push(envelope);
        if (state.eventBuffer.length > 1500) {
            state.eventBuffer.splice(0, state.eventBuffer.length - 1500);
        }
        state.broadcastWs?.({ ...envelope });
        json(res, { ok: true });
        return true;
    }
    // ── POST /api/terminal/run ──────────────────────────────────────────
    if (method === "POST" && pathname === "/api/terminal/run") {
        if (!isLocalCodeExecutionAllowed()) {
            json(res, terminalRejectionResponse("TERMINAL_SHELL_DISABLED"), 403);
            return true;
        }
        if (state.shellEnabled === false) {
            json(res, terminalRejectionResponse("TERMINAL_SHELL_DISABLED"), 403);
            return true;
        }
        const rawTerm = await readJsonBody(req, res);
        if (rawTerm === null)
            return true;
        const parsedTerm = PostTerminalRunRequestSchema.safeParse(rawTerm);
        if (!parsedTerm.success) {
            error(res, parsedTerm.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedTerm.data;
        const terminalRejection = ctx.resolveTerminalRunRejection(req, body);
        if (terminalRejection) {
            json(res, terminalRejectionResponse("TERMINAL_AUTHORIZATION_REQUIRED"), terminalRejection.status);
            return true;
        }
        const command = body.command.trim();
        if (!command) {
            json(res, terminalRejectionResponse("TERMINAL_COMMAND_REQUIRED"), 400);
            return true;
        }
        if (command.length > 4096) {
            json(res, terminalRejectionResponse("TERMINAL_COMMAND_TOO_LONG"), 400);
            return true;
        }
        if (command.includes("\n") ||
            command.includes("\r") ||
            command.includes("\0")) {
            json(res, terminalRejectionResponse("TERMINAL_COMMAND_SINGLE_LINE_REQUIRED"), 400);
            return true;
        }
        const targetClientId = ctx.resolveTerminalRunClientId(req, body);
        if (!targetClientId) {
            error(res, "Missing client id. Provide X-Eliza-Client-Id header or clientId in the request body.", 400);
            return true;
        }
        const emitTerminalEvent = (payload) => {
            try {
                if (ctx.isSharedTerminalClientId(targetClientId)) {
                    state.broadcastWs?.(payload);
                    return;
                }
                if (typeof state.broadcastWsToClientId !== "function")
                    return;
                state.broadcastWsToClientId(targetClientId, payload);
            }
            catch (error) {
                // error-policy:J6 terminal event delivery is observational; a broken
                // subscriber must not replace the command result or leak its lease.
                logger.warn({ error, runClientId: targetClientId }, "[terminal] Failed to broadcast terminal event");
            }
        };
        const captureOutput = body.captureOutput === true;
        const MAX_CAPTURE_BYTES = MAX_TERMINAL_CAPTURE_BYTES;
        const runId = resolveRequestedTerminalRunId(req.headers["x-eliza-terminal-run-id"]);
        if (!runId) {
            error(res, "Invalid X-Eliza-Terminal-Run-Id header", 400);
            return true;
        }
        const { maxConcurrent, maxDurationMs } = resolveTerminalRunLimits();
        const runScopeId = String(state.runtime?.agentId ?? "no-agent");
        const admission = ctx.tryAcquireTerminalRunSlot
            ? ctx.tryAcquireTerminalRunSlot(runScopeId, runId, maxConcurrent)
            : ctx.activeTerminalRunCount < maxConcurrent
                ? {
                    release: (() => {
                        ctx.setActiveTerminalRunCount(1);
                        let released = false;
                        return () => {
                            if (released)
                                return;
                            released = true;
                            ctx.setActiveTerminalRunCount(-1);
                        };
                    })(),
                }
                : { rejection: "capacity" };
        if ("rejection" in admission) {
            if (admission.rejection === "duplicate") {
                error(res, "Terminal run id was already used", 409);
                return true;
            }
            if (admission.rejection === "registry-capacity") {
                error(res, "Terminal run admission is temporarily unavailable", 503);
                return true;
            }
            error(res, `Too many active terminal runs (${maxConcurrent}). Wait for a command to finish.`, 429);
            return true;
        }
        const releaseTerminalRunSlot = admission.release;
        if (!captureOutput) {
            json(res, { ok: true, runId });
        }
        emitTerminalEvent({
            type: "terminal-output",
            runId,
            event: "start",
            command,
            maxDurationMs,
        });
        let finalized = false;
        let timedOut = false;
        let stdout = "";
        let stderr = "";
        let captureOverflowed = false;
        let capturedBytes = 0;
        const appendOutput = (current, chunkText) => {
            if (!captureOutput || captureOverflowed || !chunkText) {
                return current;
            }
            const remaining = MAX_CAPTURE_BYTES - capturedBytes;
            if (remaining <= 0) {
                captureOverflowed = true;
                return current;
            }
            const chunkBytes = Buffer.byteLength(chunkText, "utf8");
            if (chunkBytes <= remaining) {
                capturedBytes += chunkBytes;
                return current + chunkText;
            }
            captureOverflowed = true;
            return current;
        };
        const finalize = () => {
            if (finalized)
                return;
            finalized = true;
            releaseTerminalRunSlot();
            clearTimeout(timeoutHandle);
        };
        const timeoutHandle = setTimeout(() => {
            timedOut = true;
            emitTerminalEvent({
                type: "terminal-output",
                runId,
                event: "timeout",
                maxDurationMs,
            });
        }, maxDurationMs);
        const appendAndEmit = (stream, text) => {
            if (captureOutput) {
                if (stream === "stdout")
                    stdout = appendOutput(stdout, text);
                else
                    stderr = appendOutput(stderr, text);
                return;
            }
            emitTerminalEvent({
                type: "terminal-output",
                runId,
                event: stream,
                data: text,
            });
        };
        Promise.resolve()
            .then(() => {
            const shell = (ctx.resolveTerminalShellCommand ?? resolveTerminalShellCommand)();
            return runShell({
                command: shell.command,
                args: shell.argsFor(command),
                cwd: process.env.SHELL_ALLOWED_DIRECTORY || process.cwd(),
                env: { FORCE_COLOR: "0" },
                timeoutMs: maxDurationMs,
                onStdout: (text) => appendAndEmit("stdout", text),
                onStderr: (text) => appendAndEmit("stderr", text),
                toolName: "terminal.run",
            }, null);
        })
            .then((result) => {
            finalize();
            const runTimedOut = timedOut || result.exitCode === 124;
            if (captureOutput) {
                if (captureOverflowed) {
                    emitTerminalEvent({
                        type: "terminal-output",
                        runId,
                        event: "error",
                        data: "Terminal output exceeded the complete-capture limit",
                    });
                    error(res, `Terminal output exceeded the ${MAX_CAPTURE_BYTES}-byte complete-capture safety limit; no partial result was returned.`, 413);
                    return;
                }
                if (runTimedOut) {
                    error(res, "Terminal execution timed out; no partial result was returned.", 504);
                    return;
                }
                if (!capturedTerminalOutputIsSafe(stdout, stderr)) {
                    emitTerminalEvent({
                        type: "terminal-output",
                        runId,
                        event: "error",
                        data: "Terminal output was not valid safe text",
                    });
                    error(res, "Terminal output was not valid safe text; no result was returned.", 422);
                    return;
                }
                if (stdout) {
                    emitTerminalEvent({
                        type: "terminal-output",
                        runId,
                        event: "stdout",
                        data: stdout,
                    });
                }
                if (stderr) {
                    emitTerminalEvent({
                        type: "terminal-output",
                        runId,
                        event: "stderr",
                        data: stderr,
                    });
                }
            }
            emitTerminalEvent({
                type: "terminal-output",
                runId,
                event: "exit",
                code: result.exitCode,
            });
            if (captureOutput) {
                json(res, {
                    ok: true,
                    runId,
                    command,
                    exitCode: result.exitCode,
                    stdout,
                    stderr,
                    timedOut: runTimedOut,
                    truncated: false,
                    maxDurationMs,
                    sandbox: result.sandbox,
                    durationMs: result.durationMs,
                });
            }
        })
            .catch((_error) => {
            finalize();
            emitTerminalEvent({
                type: "terminal-output",
                runId,
                event: "error",
                data: "Terminal execution failed",
            });
            if (captureOutput) {
                error(res, "Terminal execution failed", 500);
            }
        });
        return true;
    }
    // ── Custom Actions CRUD ──────────────────────────────────────────────
    if (method === "GET" && pathname === "/api/custom-actions") {
        const config = loadElizaConfig();
        json(res, { actions: config.customActions ?? [] });
        return true;
    }
    if (method === "POST" && pathname === "/api/custom-actions") {
        const rawAction = await readJsonBody(req, res);
        if (rawAction === null)
            return true;
        const parsedAction = PostCustomActionRequestSchema.safeParse(rawAction);
        if (!parsedAction.success) {
            error(res, parsedAction.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedAction.data;
        if (body.handler.type === "shell" || body.handler.type === "code") {
            const terminalRejection = ctx.resolveTerminalRunRejection(req, toTerminalRunRequestBody(rawAction));
            if (terminalRejection) {
                error(res, `Creating ${body.handler.type} actions requires terminal authorization. ${terminalRejection.reason}`, terminalRejection.status);
                return true;
            }
        }
        const now = new Date().toISOString();
        const actionDef = {
            id: crypto.randomUUID(),
            name: body.name.toUpperCase().replace(/\s+/g, "_"),
            description: body.description,
            similes: body.similes,
            parameters: body.parameters,
            handler: body.handler,
            enabled: body.enabled,
            createdAt: now,
            updatedAt: now,
        };
        const config = loadElizaConfig();
        if (!config.customActions)
            config.customActions = [];
        config.customActions.push(actionDef);
        saveElizaConfig(config);
        // Keep the live server config in step so the next full save of
        // state.config does not drop this action from disk.
        state.config.customActions = config.customActions;
        if (actionDef.enabled) {
            registerCustomActionLive(actionDef);
        }
        json(res, { ok: true, action: actionDef });
        return true;
    }
    // Generate a custom action definition from a natural language prompt
    if (method === "POST" && pathname === "/api/custom-actions/generate") {
        const rawGen = await readJsonBody(req, res);
        if (rawGen === null)
            return true;
        const parsedGen = PostCustomActionGenerateRequestSchema.safeParse(rawGen);
        if (!parsedGen.success) {
            error(res, parsedGen.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const prompt = parsedGen.data.prompt;
        const runtime = state.runtime;
        if (!runtime) {
            error(res, "Agent runtime not available", 503);
            return true;
        }
        try {
            const composedPrompt = composePrompt({
                state: { request: prompt },
                template: customActionGenerateTemplate,
            });
            const llmResponse = await runtime.useModel(ModelType.TEXT_SMALL, {
                prompt: composedPrompt,
            });
            const text = typeof llmResponse === "string" ? llmResponse : String(llmResponse);
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            if (!jsonMatch) {
                error(res, "Failed to generate action definition", 500);
                return true;
            }
            const generated = JSON.parse(jsonMatch[0]);
            json(res, { ok: true, generated });
        }
        catch (err) {
            error(res, `Generation failed: ${err instanceof Error ? err.message : String(err)}`, 500);
        }
        return true;
    }
    const customActionMatch = pathname.match(/^\/api\/custom-actions\/([^/]+)$/);
    const customActionTestMatch = pathname.match(/^\/api\/custom-actions\/([^/]+)\/test$/);
    if (method === "POST" && customActionTestMatch) {
        const decodedActionId = decodePathComponent(customActionTestMatch[1], res, "custom action id");
        if (decodedActionId === null)
            return true;
        const actionId = validateUuid(decodedActionId);
        if (!actionId) {
            error(res, "Invalid custom action id", 400);
            return true;
        }
        const rawTest = await readJsonBody(req, res);
        if (rawTest === null)
            return true;
        const parsedTest = PostCustomActionTestRequestSchema.safeParse(rawTest);
        if (!parsedTest.success) {
            error(res, parsedTest.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedTest.data;
        const config = loadElizaConfig();
        const def = (config.customActions ?? []).find((a) => a.id === actionId);
        if (!def) {
            error(res, "Action not found", 404);
            return true;
        }
        if (def.handler.type === "shell" || def.handler.type === "code") {
            const terminalRejection = ctx.resolveTerminalRunRejection(req, toTerminalRunRequestBody(rawTest));
            if (terminalRejection) {
                error(res, `Testing ${def.handler.type} actions requires terminal authorization. ${terminalRejection.reason}`, terminalRejection.status);
                return true;
            }
        }
        const testParams = body.params ?? {};
        const start = Date.now();
        try {
            const handler = buildTestHandler(def);
            const result = await handler(testParams);
            json(res, {
                ok: result.ok,
                output: result.output,
                durationMs: Date.now() - start,
            });
        }
        catch (err) {
            json(res, {
                ok: false,
                output: "",
                error: err instanceof Error ? err.message : String(err),
                durationMs: Date.now() - start,
            });
        }
        return true;
    }
    if (method === "PUT" && customActionMatch) {
        const decodedActionId = decodePathComponent(customActionMatch[1], res, "custom action id");
        if (decodedActionId === null)
            return true;
        const actionId = validateUuid(decodedActionId);
        if (!actionId) {
            error(res, "Invalid custom action id", 400);
            return true;
        }
        const rawUpdate = await readJsonBody(req, res);
        if (rawUpdate === null)
            return true;
        const parsedUpdate = PutCustomActionRequestSchema.safeParse(rawUpdate);
        if (!parsedUpdate.success) {
            error(res, parsedUpdate.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedUpdate.data;
        const config = loadElizaConfig();
        const actions = config.customActions ?? [];
        const idx = actions.findIndex((a) => a.id === actionId);
        if (idx === -1) {
            error(res, "Action not found", 404);
            return true;
        }
        const existing = actions[idx];
        const newHandler = body.handler ?? existing.handler;
        if (newHandler.type === "shell" || newHandler.type === "code") {
            const terminalRejection = ctx.resolveTerminalRunRejection(req, toTerminalRunRequestBody(rawUpdate));
            if (terminalRejection) {
                error(res, `Updating to ${newHandler.type} handler requires terminal authorization. ${terminalRejection.reason}`, terminalRejection.status);
                return true;
            }
        }
        const updated = {
            ...existing,
            name: body.name
                ? body.name.trim().toUpperCase().replace(/\s+/g, "_")
                : existing.name,
            description: body.description?.trim()
                ? body.description.trim()
                : existing.description,
            similes: body.similes ?? existing.similes,
            parameters: body.parameters ?? existing.parameters,
            handler: newHandler,
            enabled: body.enabled ?? existing.enabled,
            updatedAt: new Date().toISOString(),
        };
        actions[idx] = updated;
        config.customActions = actions;
        saveElizaConfig(config);
        state.config.customActions = config.customActions;
        if (updated.enabled) {
            registerCustomActionLive(updated);
        }
        else {
            unregisterCustomActionLive(updated.id);
        }
        json(res, { ok: true, action: updated });
        return true;
    }
    if (method === "DELETE" && customActionMatch) {
        const decodedActionId = decodePathComponent(customActionMatch[1], res, "custom action id");
        if (decodedActionId === null)
            return true;
        const actionId = validateUuid(decodedActionId);
        if (!actionId) {
            error(res, "Invalid custom action id", 400);
            return true;
        }
        const config = loadElizaConfig();
        const actions = config.customActions ?? [];
        const idx = actions.findIndex((a) => a.id === actionId);
        if (idx === -1) {
            error(res, "Action not found", 404);
            return true;
        }
        actions.splice(idx, 1);
        config.customActions = actions;
        saveElizaConfig(config);
        state.config.customActions = config.customActions;
        unregisterCustomActionLive(actionId);
        json(res, { ok: true });
        return true;
    }
    // Privy wallet routes (/api/privy/*) are provided by wallet/runtime route
    // registries when the relevant backend is installed.
    return false;
}
