/**
 * Mounts the `/api/permissions` REST surface behind the dashboard control-API
 * auth gate: GET the full permission map or a single permission, POST refresh,
 * per-permission request and open-settings, and PUT shell-access and
 * client-probed permission state. Reads live state through the runtime's
 * permissions registry when present, falls back to the persisted map or an
 * unavailable-permission stub, and validates client-pushed states (fail
 * closed) before persisting. A `PUT /state` also auto-enables capability
 * plugins whose required permissions are now granted and can schedule a
 * runtime restart. Shell access is surfaced as a synthetic permission derived
 * from config, never probed. `GET /native-projection` additionally projects
 * the personal-data permissions through the shared native capability
 * contract (metadata only; personal payloads never leave the device).
 */
import { assertNativePersonalDataProjectionMetadataOnly, PutPermissionsShellRequestSchema, PutPermissionsStateRequestSchema, projectNativePersonalDataCapabilities, } from "@elizaos/contracts";
import { getMacPermissionDeepLink, isPermissionId, PERMISSION_IDS, } from "@elizaos/core";
import { PERMISSIONS_REGISTRY_SERVICE } from "../services/permissions-registry.js";
function currentPlatform() {
    const p = process.platform;
    return p === "darwin" || p === "win32" || p === "linux" ? p : "linux";
}
function isPermissionsRegistry(service) {
    return (typeof service === "object" &&
        service !== null &&
        "get" in service &&
        "check" in service &&
        "request" in service &&
        "openSettings" in service);
}
function getPermissionRegistry(runtime) {
    const service = runtime?.getService(PERMISSIONS_REGISTRY_SERVICE);
    return isPermissionsRegistry(service) ? service : null;
}
function unavailableSystemPermission(id) {
    return {
        id,
        status: "not-applicable",
        lastChecked: Date.now(),
        canRequest: false,
        platform: currentPlatform(),
        reason: "Native permission checks are unavailable in this runtime.",
    };
}
const PERMISSION_STATUSES = [
    "granted",
    "limited",
    "denied",
    "not-determined",
    "restricted",
    "not-applicable",
];
const PLATFORMS = [
    "darwin",
    "win32",
    "linux",
    "ios",
    "android",
    "web",
];
const PERMISSION_RESTRICTED_REASONS = [
    "entitlement_required",
    "platform_unsupported",
    "os_policy",
];
function validateBlockedFeature(value) {
    if (!value || typeof value !== "object")
        return null;
    const v = value;
    if (typeof v.app === "string" &&
        typeof v.action === "string" &&
        typeof v.at === "number") {
        return { app: v.app, action: v.action, at: v.at };
    }
    return null;
}
/**
 * Validate a client-supplied permission map into typed `PermissionState`s.
 *
 * The desktop shell is the only native peer that can probe OS permissions, so
 * it pushes the probed states here over loopback. We still validate the wire
 * shape at this boundary instead of force-casting: every entry must be keyed by
 * a known `PermissionId` and carry a valid `PermissionStatus`/`Platform`, with
 * the required numeric/boolean fields present. Unknown ids and malformed
 * entries are rejected (fail closed) so the persisted map — which feeds GET
 * responses and capability auto-enable — only ever holds real states.
 */
function validatePermissionStates(raw) {
    const result = {};
    for (const [key, entry] of Object.entries(raw)) {
        if (!isPermissionId(key)) {
            return { ok: false, reason: `Unknown permission id "${key}"` };
        }
        if (entry.id !== key) {
            return {
                ok: false,
                reason: `Permission "${key}" has mismatched id field`,
            };
        }
        if (typeof entry.status !== "string" ||
            !PERMISSION_STATUSES.includes(entry.status)) {
            return { ok: false, reason: `Permission "${key}" has invalid status` };
        }
        if (typeof entry.platform !== "string" ||
            !PLATFORMS.includes(entry.platform)) {
            return { ok: false, reason: `Permission "${key}" has invalid platform` };
        }
        if (typeof entry.lastChecked !== "number") {
            return {
                ok: false,
                reason: `Permission "${key}" is missing lastChecked`,
            };
        }
        if (typeof entry.canRequest !== "boolean") {
            return {
                ok: false,
                reason: `Permission "${key}" is missing canRequest`,
            };
        }
        const validated = {
            id: key,
            status: entry.status,
            platform: entry.platform,
            lastChecked: entry.lastChecked,
            canRequest: entry.canRequest,
        };
        if (typeof entry.lastRequested === "number") {
            validated.lastRequested = entry.lastRequested;
        }
        if (typeof entry.reason === "string") {
            validated.reason = entry.reason;
        }
        if (typeof entry.restrictedReason === "string" &&
            PERMISSION_RESTRICTED_REASONS.includes(entry.restrictedReason)) {
            validated.restrictedReason =
                entry.restrictedReason;
        }
        const blockedFeature = validateBlockedFeature(entry.lastBlockedFeature);
        if (blockedFeature) {
            validated.lastBlockedFeature = blockedFeature;
        }
        result[key] = validated;
    }
    return { ok: true, value: result };
}
async function openSystemPermissionSettings(id) {
    const platform = currentPlatform();
    let argv = null;
    if (platform === "darwin") {
        argv = ["open", getMacPermissionDeepLink(id)];
    }
    else if (platform === "win32") {
        const settingsMap = {
            microphone: "ms-settings:privacy-microphone",
            camera: "ms-settings:privacy-webcam",
            location: "ms-settings:privacy-location",
            notifications: "ms-settings:notifications",
        };
        const uri = settingsMap[id];
        if (uri)
            argv = ["cmd", "/c", "start", "", uri];
    }
    else {
        const settingsMap = {
            microphone: "privacy",
            camera: "privacy",
            location: "privacy",
            notifications: "notifications",
        };
        const panel = settingsMap[id];
        if (panel)
            argv = ["sh", "-lc", `gnome-control-center ${panel}`];
    }
    if (!argv)
        return false;
    try {
        const { spawn } = await import("node:child_process");
        const proc = spawn(argv[0], argv.slice(1), {
            detached: true,
            stdio: "ignore",
        });
        proc.unref();
        return true;
    }
    catch {
        return false;
    }
}
async function buildPermissionsPayload(state, refresh = false) {
    const permissionStates = state.permissionStates ?? {};
    const shellEnabled = state.shellEnabled ?? true;
    const registry = getPermissionRegistry(state.runtime);
    const permissions = {};
    await Promise.all(PERMISSION_IDS.map(async (id) => {
        const persisted = permissionStates[id];
        if (!refresh && persisted) {
            permissions[id] = persisted;
            return;
        }
        if (registry) {
            try {
                permissions[id] = refresh
                    ? await registry.check(id)
                    : registry.get(id);
                return;
            }
            catch {
                // Fall through to persisted/unavailable state.
            }
        }
        permissions[id] = persisted ?? unavailableSystemPermission(id);
    }));
    if (!permissions.shell) {
        permissions.shell = unavailableSystemPermission("shell");
    }
    permissions.shell = {
        ...permissions.shell,
        status: shellEnabled ? "granted" : "denied",
        canRequest: false,
    };
    return {
        ...permissions,
        _platform: process.platform,
        _shellEnabled: shellEnabled,
    };
}
export async function handlePermissionRoutes(ctx) {
    const { req, res, method, pathname, state, readJsonBody, json, error, saveConfig, scheduleRuntimeRestart, } = ctx;
    if (!pathname.startsWith("/api/permissions"))
        return false;
    if (method === "GET" && pathname === "/api/permissions") {
        json(res, await buildPermissionsPayload(state));
        return true;
    }
    if (method === "GET" && pathname === "/api/permissions/native-projection") {
        // Project the on-device personal-data bridges through the shared
        // capability contract. Metadata only: permission and availability state,
        // never contact rows, message bodies, or coordinates. The agent host
        // process is by definition foregrounded and evaluates its own local
        // stores, so the runtime context is the host's, not a mobile shell's;
        // native apps compute the same projection client-side with live app state.
        const payload = await buildPermissionsPayload(state);
        const states = PERMISSION_IDS.map((id) => payload[id]).filter((entry) => entry !== undefined);
        const projection = projectNativePersonalDataCapabilities(states, { platform: currentPlatform(), online: true, appState: "foreground" }, new Date().toISOString());
        assertNativePersonalDataProjectionMetadataOnly(projection);
        json(res, projection);
        return true;
    }
    if (method === "GET" && pathname === "/api/permissions/shell") {
        const enabled = state.shellEnabled ?? true;
        if (!state.permissionStates) {
            state.permissionStates = {};
        }
        const shellState = state.permissionStates.shell;
        const permission = {
            id: "shell",
            status: enabled ? "granted" : "denied",
            lastChecked: shellState?.lastChecked ?? Date.now(),
            canRequest: false,
            platform: currentPlatform(),
        };
        state.permissionStates.shell = permission;
        json(res, {
            enabled,
            ...permission,
            permission,
        });
        return true;
    }
    if (method === "GET" && pathname.startsWith("/api/permissions/")) {
        const permId = pathname.slice("/api/permissions/".length);
        if (!permId || permId.includes("/") || !isPermissionId(permId)) {
            error(res, "Invalid permission ID", 400);
            return true;
        }
        const permState = state.permissionStates?.[permId];
        if (permState) {
            json(res, permState);
            return true;
        }
        const registry = getPermissionRegistry(state.runtime);
        if (registry) {
            try {
                json(res, registry.get(permId));
                return true;
            }
            catch {
                // Fall through to persisted/unavailable state.
            }
        }
        json(res, unavailableSystemPermission(permId));
        return true;
    }
    if (method === "POST" && pathname === "/api/permissions/refresh") {
        json(res, await buildPermissionsPayload(state, true));
        return true;
    }
    if (method === "POST" &&
        pathname.match(/^\/api\/permissions\/[^/]+\/request$/)) {
        const permId = pathname.split("/")[3];
        if (!isPermissionId(permId)) {
            error(res, "Invalid permission ID", 400);
            return true;
        }
        const registry = getPermissionRegistry(state.runtime);
        if (registry) {
            try {
                json(res, await registry.request(permId, {
                    reason: "Requested from permissions API.",
                    feature: { app: "settings", action: `request.${permId}` },
                }));
                return true;
            }
            catch {
                // Fall through to bridge hint for runtimes without a prober.
            }
        }
        json(res, unavailableSystemPermission(permId));
        return true;
    }
    if (method === "POST" &&
        pathname.match(/^\/api\/permissions\/[^/]+\/open-settings$/)) {
        const permId = pathname.split("/")[3];
        if (!isPermissionId(permId)) {
            error(res, "Invalid permission ID", 400);
            return true;
        }
        const registry = getPermissionRegistry(state.runtime);
        let opened = false;
        if (registry) {
            try {
                opened = await registry.openSettings(permId);
            }
            catch {
                opened = false;
            }
        }
        if (!opened) {
            opened = await openSystemPermissionSettings(permId);
        }
        json(res, {
            opened,
            id: permId,
            permission: state.permissionStates?.[permId] ?? unavailableSystemPermission(permId),
        });
        return true;
    }
    if (method === "PUT" && pathname === "/api/permissions/shell") {
        const rawShell = await readJsonBody(req, res);
        if (rawShell === null)
            return true;
        const parsedShell = PutPermissionsShellRequestSchema.safeParse(rawShell);
        if (!parsedShell.success) {
            error(res, parsedShell.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const enabled = parsedShell.data.enabled === true;
        state.shellEnabled = enabled;
        if (!state.permissionStates) {
            state.permissionStates = {};
        }
        state.permissionStates.shell = {
            id: "shell",
            status: enabled ? "granted" : "denied",
            lastChecked: Date.now(),
            canRequest: false,
            platform: currentPlatform(),
        };
        if (!state.config.features) {
            state.config.features = {};
        }
        state.config.features.shellEnabled = enabled;
        saveConfig(state.config);
        if (state.runtime) {
            scheduleRuntimeRestart(`Shell access ${enabled ? "enabled" : "disabled"}`);
        }
        json(res, {
            shellEnabled: enabled,
            permission: state.permissionStates.shell,
        });
        return true;
    }
    if (method === "PUT" && pathname === "/api/permissions/state") {
        const rawPermState = await readJsonBody(req, res);
        if (rawPermState === null)
            return true;
        const parsedPermState = PutPermissionsStateRequestSchema.safeParse(rawPermState);
        if (!parsedPermState.success) {
            error(res, parsedPermState.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedPermState.data;
        if (body.permissions && typeof body.permissions === "object") {
            const validated = validatePermissionStates(body.permissions);
            if (!validated.ok) {
                error(res, validated.reason, 400);
                return true;
            }
            state.permissionStates = validated.value;
            let configChanged = false;
            state.config.plugins = state.config.plugins || {};
            state.config.plugins.entries = state.config.plugins.entries || {};
            const capabilities = [
                { id: "browser", required: ["accessibility"] },
                { id: "computeruse", required: ["accessibility", "screen-recording"] },
                { id: "vision", required: ["screen-recording"] },
                { id: "coding-agent", required: [] },
            ];
            for (const cap of capabilities) {
                if (state.config.plugins.entries[cap.id]?.enabled === undefined) {
                    const allGranted = cap.required.every((permId) => {
                        const pStatus = state.permissionStates?.[permId]?.status;
                        return pStatus === "granted" || pStatus === "not-applicable";
                    });
                    if (allGranted) {
                        state.config.plugins.entries[cap.id] = {
                            ...(state.config.plugins.entries[cap.id] || {}),
                            enabled: true,
                        };
                        configChanged = true;
                    }
                }
            }
            if (configChanged) {
                saveConfig(state.config);
                if (state.runtime && !body.startup) {
                    scheduleRuntimeRestart("Auto-enabled newly permitted capabilities");
                }
            }
        }
        json(res, { updated: true, permissions: state.permissionStates });
        return true;
    }
    return false;
}
