/**
 * Transactional Shared Todo importer for a Dedicated agent's local database.
 * It writes only the plugin-todos schema, preserves target-native rows, and
 * verifies the materialized snapshot before the Cloud cutover may route users
 * away from Shared.
 */
import { type AgentRuntime, type SharedTodoCutoverSnapshot, type UUID } from "@elizaos/core";
export interface SharedTodoImportReceipt {
    sourceTodoCount: number;
    sourceTodoMutationCount: number;
    importedTodos: number;
    repairedTodos: number;
    skippedTodos: number;
    removedStaleTodos: number;
    importedTodoMutations: number;
    skippedTodoMutations: number;
    sourceTodoDigest: string;
    targetTodoDigest: string;
}
/**
 * Reconciles one verified snapshot under the same per-user advisory lock used
 * by plugin-todos CRUD. The transaction either leaves an exact digest-matching
 * imported set or rolls back without affecting the Shared route authority.
 */
export declare function importSharedTodoCutover(input: {
    runtime: AgentRuntime;
    entityId: UUID;
    targetRoomId: UUID;
    cutoverToken: string;
    snapshot: SharedTodoCutoverSnapshot;
}): Promise<SharedTodoImportReceipt>;
