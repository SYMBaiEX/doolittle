import { resolveOwnerEntityIdOrDefault, } from "@elizaos/core";
import { DeviceActionError } from "@elizaos/plugin-assistant";
/** Bind local OWNER enrollment to the canonical workflow scope without changing
 * the authenticated subject used by phone approvals. No request fields choose it. */
export function workflowDeviceOwner(runtime, authorization, subjectUserId) {
    if (!authorization?.ok ||
        !["USER", "ADMIN", "OWNER"].includes(authorization.role) ||
        (authorization.identityId ??
            (authorization.principal
                ? `gateway:${authorization.principal}`
                : undefined)) !== subjectUserId)
        throw new DeviceActionError("Verified device subject required");
    return authorization.role === "OWNER" && !authorization.externalIdentity
        ? resolveOwnerEntityIdOrDefault(runtime)
        : subjectUserId;
}
