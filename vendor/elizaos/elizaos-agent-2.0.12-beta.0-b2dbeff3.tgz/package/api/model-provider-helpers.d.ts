import { ElizaError } from "@elizaos/core";
export declare const DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS = 10000;
export declare class ModelCatalogFetchError extends ElizaError {
    readonly name = "ModelCatalogFetchError";
    readonly providerId: string;
    readonly upstreamStatus?: number;
    constructor(providerId: string, options?: {
        cause?: unknown;
        upstreamStatus?: number;
    });
}
type ModelOption = {
    id: string;
    name: string;
    provider: string;
    description: string;
    recommended?: boolean;
    free?: boolean;
};
export declare function getModelOptions(): {
    nano: ModelOption[];
    small: ModelOption[];
    medium: ModelOption[];
    large: ModelOption[];
    mega: ModelOption[];
};
export type ModelCategory = "chat" | "embedding" | "image" | "tts" | "stt" | "other";
export interface CachedModel {
    id: string;
    name: string;
    category: ModelCategory;
}
export interface ProviderCache {
    version: 1;
    providerId: string;
    fetchedAt: string;
    models: CachedModel[];
}
export declare function classifyModel(modelId: string): ModelCategory;
/** Map param key → expected model category */
export declare function paramKeyToCategory(paramKey: string): ModelCategory;
/**
 * Canonical provider-id grammar. Cache paths are built by joining
 * `${providerId}.json` under the models cache dir, so anything outside this
 * shape (path separators, `.` segments) is rejected before a filesystem path
 * exists — a `../` id would otherwise traverse out of the cache directory
 * into an arbitrary unlink/read (W1-024).
 */
export declare const MODEL_PROVIDER_ID_PATTERN: RegExp;
export declare function providerCachePath(providerId: string): string;
export declare function readProviderCache(providerId: string): ProviderCache | null;
export declare function writeProviderCache(cache: ProviderCache): void;
/** Fetch models from unknown provider's /v1/models endpoint (standard REST). */
export declare function fetchModelsREST(providerId: string, apiKey: string, baseUrl: string): Promise<CachedModel[]>;
export declare function restTypeToCategory(type: string): ModelCategory;
export declare function fetchAnthropicModels(apiKey: string): Promise<CachedModel[]>;
export declare function fetchGoogleModels(apiKey: string): Promise<CachedModel[]>;
export declare function fetchOllamaModels(baseUrl: string): Promise<CachedModel[]>;
/** Fetch ALL OpenRouter models: chat (/api/v1/models) + embeddings (/api/v1/embeddings/models). */
export declare function fetchOpenRouterModels(apiKey: string): Promise<CachedModel[]>;
/** Fetch NEAR AI Cloud models from its catalog endpoint. */
export declare function fetchNearAIModels(apiKey: string, baseUrl: string): Promise<CachedModel[]>;
export declare function fetchProviderModels(providerId: string, apiKey: string, baseUrl?: string): Promise<CachedModel[]>;
/** Fetch + cache a single provider. Returns cached models or empty array. */
export declare function getOrFetchProvider(providerId: string, force?: boolean): Promise<CachedModel[]>;
/** Fetch all configured providers (parallel). Returns map of providerId → models. */
export declare function getOrFetchAllProviders(force?: boolean): Promise<Record<string, CachedModel[]>>;
export { getInventoryProviderOptions } from "./wallet-rpc.js";
