import type http from "node:http";
import type { PluginEntry, ServerState } from "./server-types.js";
export interface PluginManagementRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: Pick<ServerState, "runtime" | "config">;
    isOwner: boolean;
    getPlugins: () => Promise<PluginEntry[]>;
    readJsonBody: <T = Record<string, unknown>>(req: http.IncomingMessage, res: http.ServerResponse) => Promise<T | null>;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    scheduleRuntimeRestart: (reason: string) => void;
    restartRuntime?: (reason: string) => Promise<boolean>;
}
export declare function handlePluginManagementRoutes(ctx: PluginManagementRouteContext): Promise<boolean>;
