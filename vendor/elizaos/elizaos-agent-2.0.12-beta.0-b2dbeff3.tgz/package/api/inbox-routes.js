import { PostInboxMessageRequestSchema } from "@elizaos/contracts";
import { createUniqueUuid, expandConnectorSourceFilter, getConnectorAccountManager, normalizeConnectorSource, requireConfirmedSendHandlerDelivery, roleRank, toWellFormedUnicode, truncateWellFormed, } from "@elizaos/core";
import { resolveEffectiveMuteState, setRoomMuteUntil, setWorldMuteState, } from "@elizaos/plugin-assistant";
import { z } from "zod";
let discordModulePromise = null;
// Inlined (not imported from @elizaos/plugin-discord/constants) so the mobile
// Vite bundle does not statically pull in the Discord plugin. Must stay equal to
// plugin-discord's DISCORD_SERVICE_NAME — the dynamic import below resolves the
// same service by this name.
const DISCORD_SERVICE_NAME = "discord";
function getDiscordModule() {
    if (!discordModulePromise) {
        discordModulePromise = import(/* @vite-ignore */ "@elizaos/plugin-discord");
    }
    return discordModulePromise;
}
/**
 * Source tags we consider "inbox-worthy". Messages whose content.source
 * is none of these are excluded from the combined feed — this keeps
 * internal sources (e.g. system events, knowledge ingestion, trajectory
 * markers) out of the user-facing inbox.
 *
 * `client_chat` is intentionally excluded; those are dashboard turns and
 * are already visible in the conversation view. The inbox is for
 * *inbound* messages from other humans via connector channels.
 */
const DEFAULT_INBOX_SOURCE_FILTER = [
    "imessage",
    "telegram",
    "discord",
    "whatsapp",
    "wechat",
    "slack",
    "sms",
];
const DEFAULT_INBOX_SOURCES = expandConnectorSourceFilter(DEFAULT_INBOX_SOURCE_FILTER);
/**
 * Hard ceiling on the number of rooms we scan per request. Large
 * deployments can accumulate hundreds of connector rooms; scanning all
 * of them on every request would make the endpoint scale quadratically
 * with history. 2000 rooms covers heavy deployments and leaves headroom
 * for internal worlds (autonomy/self-talk) without crowding out real
 * connector channels.
 */
const MAX_ROOMS_SCANNED = 2000;
const ORPHAN_ROOM_MEMORY_SCAN_LIMIT = 10000;
/**
 * Worlds we never want to surface in the connector chats sidebar. These
 * are internal scratch worlds (autonomy-service self-talk, advanced
 * memory, relationships graph) that contain hundreds of synthetic rooms
 * the user never interacts with directly. Including them used to consume
 * the entire room-scan budget and drown out real connector channels.
 */
const INTERNAL_WORLD_IDS = new Set([
    "00000000-0000-0000-0000-000000000001", // Autonomy World
]);
const INTERNAL_WORLD_NAME_MARKERS = [
    "advanced memory",
    "relationships world",
    "autonomy world",
];
function isInternalWorld(world) {
    if (world.id && INTERNAL_WORLD_IDS.has(world.id.toLowerCase()))
        return true;
    const name = world.name?.toLowerCase().trim();
    if (!name)
        return false;
    return INTERNAL_WORLD_NAME_MARKERS.some((marker) => name === marker);
}
/**
 * How many memories we ask the database for per room. We over-fetch
 * slightly so that after filtering by source tag we still have enough
 * to fill `limit` for the caller. If a room has 500 messages but only
 * the most recent 50 are connector messages, we'd miss them with a
 * tight per-room limit. 3x the requested limit is a reasonable margin.
 */
const PER_ROOM_OVERFETCH_MULTIPLIER = 3;
/**
 * Parse and clamp the `limit` query parameter. Defaults to 100 and caps
 * canonical positive decimal integers at 500.
 */
function parseLimit(raw) {
    if (raw === null || raw === "")
        return 100;
    if (!/^[1-9]\d*$/.test(raw))
        return null;
    const parsed = Number(raw);
    if (!Number.isSafeInteger(parsed))
        return null;
    return Math.min(parsed, 500);
}
/**
 * Parse the `sources` query parameter into a Set of lowercase tags, or
 * null to mean "use the default inbox source set".
 */
function parseSourceFilter(raw) {
    if (!raw)
        return null;
    const tags = raw
        .split(",")
        .map((t) => t.trim().toLowerCase())
        .filter((t) => t.length > 0);
    if (tags.length === 0)
        return null;
    return expandConnectorSourceFilter(tags);
}
function getRuntimeSendHandlers(runtime) {
    const sendHandlers = Reflect.get(runtime, "sendHandlers");
    return sendHandlers instanceof Map ? sendHandlers : null;
}
const CONNECTOR_ACCOUNT_KEY_SEPARATOR = "\u0000";
function runtimeHasAnySendHandler(runtime, source) {
    const handlers = getRuntimeSendHandlers(runtime);
    if (!handlers)
        return false;
    if (handlers.has(source))
        return true;
    const accountPrefix = `${source}${CONNECTOR_ACCOUNT_KEY_SEPARATOR}`;
    return Array.from(handlers.keys()).some((key) => key.startsWith(accountPrefix));
}
function runtimeHasUnscopedSendHandler(runtime, source) {
    return getRuntimeSendHandlers(runtime)?.has(source) ?? false;
}
function runtimeHasAccountScopedSendHandler(runtime, source) {
    const handlers = getRuntimeSendHandlers(runtime);
    if (!handlers)
        return false;
    const accountPrefix = `${source}${CONNECTOR_ACCOUNT_KEY_SEPARATOR}`;
    return Array.from(handlers.keys()).some((key) => key.startsWith(accountPrefix));
}
/** Mirrors AgentRuntime.sendMessageToTarget's account-aware route lookup. */
function runtimeHasSendHandler(runtime, source, accountId) {
    const handlers = getRuntimeSendHandlers(runtime);
    if (!handlers)
        return false;
    if (accountId &&
        handlers.has(`${source}${CONNECTOR_ACCOUNT_KEY_SEPARATOR}${accountId}`)) {
        return true;
    }
    if (handlers.has(source))
        return true;
    if (accountId)
        return false;
    const accountPrefix = `${source}${CONNECTOR_ACCOUNT_KEY_SEPARATOR}`;
    let scopedHandlerCount = 0;
    for (const key of handlers.keys()) {
        if (!key.startsWith(accountPrefix))
            continue;
        scopedHandlerCount += 1;
        if (scopedHandlerCount > 1)
            return false;
    }
    return scopedHandlerCount === 1;
}
/** Match ConnectorAccountManager's provider-key normalization exactly. */
function normalizeAccountProvider(provider) {
    return provider.trim().toLowerCase();
}
function accountRoutingFailure(code, error, status, context) {
    return { ok: false, code, error, status, context };
}
function accountUnavailableReason(account) {
    if (account.status !== "connected") {
        return `status ${account.status} is not connected`;
    }
    if (account.accessGate === "disabled" ||
        account.metadata?.disabled === true ||
        account.metadata?.enabled === false) {
        return "account is disabled";
    }
    if (!account.purpose.includes("messaging")) {
        return "account does not allow messaging";
    }
    if (account.accessGate !== "open" && account.accessGate !== "owner_binding") {
        return `access gate ${account.accessGate} does not allow direct messaging`;
    }
    return null;
}
async function validateInboxAccount(manager, source, account, callerAuthorization) {
    const provider = normalizeAccountProvider(source);
    const accountProvider = normalizeAccountProvider(account.provider);
    if (accountProvider !== provider) {
        return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_SOURCE_MISMATCH", `Connector account ${account.id} belongs to ${accountProvider}, not ${provider}`, 409, {
            accountId: account.id,
            requestedSource: provider,
            accountSource: accountProvider,
        });
    }
    const unavailableReason = accountUnavailableReason(account);
    if (unavailableReason) {
        return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_UNAVAILABLE", `Connector account ${account.id} is unavailable: ${unavailableReason}`, 409, {
            accountId: account.id,
            source: provider,
            reason: unavailableReason,
        });
    }
    const ownerAuthorityRequired = account.accessGate === "owner_binding" ||
        account.role.trim().toUpperCase() === "OWNER";
    if (ownerAuthorityRequired &&
        roleRank(callerAuthorization.role) < roleRank("OWNER")) {
        return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_CALLER_UNAUTHORIZED", `Authenticated caller cannot use owner connector account ${account.id}`, 403, {
            accountId: account.id,
            source: provider,
            reason: "OWNER authority is required",
        });
    }
    if (account.accessGate !== "owner_binding") {
        return null;
    }
    const evaluation = await manager.evaluatePolicy({
        provider,
        accessGates: ["owner_binding"],
        purposes: ["messaging"],
        statuses: ["connected"],
        required: true,
    }, { accountId: account.id, purpose: "messaging" });
    if (!evaluation.allowed ||
        evaluation.account?.id !== account.id ||
        normalizeAccountProvider(evaluation.account.provider) !== provider) {
        return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_OWNER_BINDING_REQUIRED", `Connector account ${account.id} requires a verified owner binding`, 403, {
            accountId: account.id,
            source: provider,
            reason: evaluation.reason ?? "owner binding has not been verified",
        });
    }
    const instanceId = typeof account.metadata?.instanceId === "string"
        ? account.metadata.instanceId
        : undefined;
    const storage = manager.getStorage();
    const verifiedBinding = account.externalId && storage.findOwnerBinding
        ? await storage.findOwnerBinding({
            connector: account.provider,
            externalId: account.externalId,
            instanceId,
        })
        : null;
    const boundIdentityId = verifiedBinding?.identityId ??
        evaluation.account.ownerIdentityId ??
        account.ownerIdentityId;
    // `principal` is intentionally opaque (wallet, entity id, etc.) and is not
    // in the auth_identity namespace used by owner bindings. Only a host that
    // resolved a verified DB identity may request exact binding equality.
    if (callerAuthorization.identityId &&
        callerAuthorization.identityId !== boundIdentityId) {
        return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_CALLER_UNAUTHORIZED", `Authenticated caller cannot use connector account ${account.id}`, 403, {
            accountId: account.id,
            source: provider,
            reason: "owner binding belongs to a different identity",
        });
    }
    return null;
}
async function findAccountSourceByExactId(manager, requestedSource, accountId) {
    const source = normalizeAccountProvider(requestedSource);
    const storedAccounts = await manager.getStorage().listAccounts();
    const storedMatch = storedAccounts.find((account) => account.id === accountId &&
        normalizeAccountProvider(account.provider) !== source);
    if (storedMatch) {
        return normalizeAccountProvider(storedMatch.provider);
    }
    const registeredSources = manager
        .listProviders()
        .map((provider) => normalizeAccountProvider(provider.provider))
        .filter((provider) => provider && provider !== source)
        .sort();
    for (const provider of registeredSources) {
        const account = await manager.getAccount(provider, accountId);
        if (account?.id === accountId) {
            return normalizeAccountProvider(account.provider);
        }
    }
    return null;
}
/** The connector account a room was created on, as connectors store it. */
function readRoomConnectorAccountId(room, source) {
    const metadata = room.metadata && typeof room.metadata === "object"
        ? room.metadata
        : undefined;
    const scoped = metadata?.[source];
    const candidate = metadata?.accountId ??
        (scoped && typeof scoped === "object"
            ? scoped.accountId
            : undefined);
    return typeof candidate === "string" && candidate.trim()
        ? candidate.trim()
        : undefined;
}
/** Keep a managed room binding even when its account has been removed. */
async function resolveRoomAccountId(runtime, source, storedAccountId) {
    if (!storedAccountId)
        return undefined;
    const provider = normalizeAccountProvider(source);
    const manager = getConnectorAccountManager(runtime);
    const managed = manager.listProviders().some((entry) => entry.provider === provider) ||
        runtimeHasAccountScopedSendHandler(runtime, provider) ||
        (await manager.listAccounts(provider)).length > 0;
    // Pass the binding to the existing account validator. A missing account
    // must not turn a reply into a send from another identity. Legacy sources
    // without managed accounts keep their existing unscoped handler contract.
    return managed ? storedAccountId : undefined;
}
async function resolveInboxAccountRouting(runtime, source, callerAuthorization, requestedAccountId) {
    // Connector-source aliases describe transport/UI grouping, while account
    // providers are exact manager keys. For example, BlueBubbles is grouped
    // under the canonical `imessage` source but registers provider
    // `bluebubbles`; canonicalizing here would reject its valid account.
    const provider = normalizeAccountProvider(source);
    const manager = getConnectorAccountManager(runtime);
    if (requestedAccountId) {
        const account = await manager.getAccount(provider, requestedAccountId);
        if (!account || account.id !== requestedAccountId) {
            const actualSource = await findAccountSourceByExactId(manager, provider, requestedAccountId);
            if (actualSource) {
                return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_SOURCE_MISMATCH", `Connector account ${requestedAccountId} belongs to ${actualSource}, not ${provider}`, 409, {
                    accountId: requestedAccountId,
                    requestedSource: provider,
                    accountSource: actualSource,
                });
            }
            return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_NOT_FOUND", `Connector account ${requestedAccountId} was not found for ${provider}`, 404, { accountId: requestedAccountId, source: provider });
        }
        const failure = await validateInboxAccount(manager, provider, account, callerAuthorization);
        return (failure ?? {
            ok: true,
            accountId: account.id,
            mode: "explicit",
        });
    }
    const accounts = (await manager.listAccounts(provider)).sort((a, b) => a.id.localeCompare(b.id));
    if (accounts.length === 0) {
        if (!runtimeHasUnscopedSendHandler(runtime, provider) &&
            runtimeHasAccountScopedSendHandler(runtime, provider)) {
            return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_REQUIRED", `A registered connector account is required for ${provider}`, 409, { source: provider });
        }
        return { ok: true, mode: "legacy-source-default" };
    }
    const usable = [];
    const failures = [];
    for (const account of accounts) {
        const failure = await validateInboxAccount(manager, provider, account, callerAuthorization);
        if (failure) {
            failures.push(failure);
        }
        else {
            usable.push(account);
        }
    }
    if (usable.length === 0) {
        if (accounts.length === 1 && failures[0]) {
            return failures[0];
        }
        return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_UNAVAILABLE", `No usable messaging account is available for ${provider}`, 409, {
            source: provider,
            accountIds: accounts.map((account) => account.id),
        });
    }
    if (usable.length === 1) {
        return { ok: true, accountId: usable[0].id, mode: "single" };
    }
    const defaults = usable.filter((account) => account.metadata?.isDefault === true);
    if (defaults.length === 1) {
        return {
            ok: true,
            accountId: defaults[0].id,
            mode: "resolved-default",
        };
    }
    return accountRoutingFailure("INBOX_CONNECTOR_ACCOUNT_AMBIGUOUS", `Multiple usable messaging accounts are available for ${provider}; select an account explicitly`, 409, {
        source: provider,
        accountIds: usable.map((account) => account.id),
        defaultAccountIds: defaults.map((account) => account.id),
    });
}
/**
 * Pull the source tag out of a Memory row. Memory.content is typed as
 * `Content` in core but the shape we care about is a loose record with
 * an optional `source?: string` field. Returns null if the source is
 * missing, non-string, or empty.
 */
function extractSource(memory) {
    const content = memory.content;
    const source = content?.source;
    if (typeof source !== "string")
        return null;
    const trimmed = source.trim();
    return trimmed.length > 0 ? trimmed : null;
}
function isDiscordConnectorSource(source) {
    return normalizeConnectorSource(source) === "discord";
}
/**
 * Pull the visible text out of a Memory row. Same rationale as
 * extractSource — we're pulling fields off a loosely-typed Content
 * object and normalizing.
 */
function extractText(memory) {
    const content = memory.content;
    const text = content?.text;
    return typeof text === "string" ? text : "";
}
function extractResponseId(memory) {
    const content = memory.content;
    const responseId = content?.responseId;
    if (typeof responseId === "string" && responseId.length > 0) {
        return responseId;
    }
    return undefined;
}
function extractContentUrl(memory) {
    const content = memory.content;
    const url = content?.url;
    if (typeof url === "string" && url.length > 0) {
        return url;
    }
    return undefined;
}
/**
 * Best-effort sender display name from memory.metadata.entityName. The
 * bootstrap plugin stamps this when it builds memories from
 * ENTITY_JOINED events; connector plugins should do the same via their
 * lifecycle event payloads (iMessage does — see dispatchInboundMessage
 * in plugin-imessage's service.ts).
 */
function extractFrom(memory) {
    const meta = memory.metadata;
    const entityName = meta?.entityName;
    if (typeof entityName === "string" && entityName.length > 0) {
        return entityName;
    }
    return undefined;
}
function extractFromUserName(memory) {
    const meta = memory.metadata;
    const entityUserName = meta?.entityUserName;
    if (typeof entityUserName === "string" && entityUserName.length > 0) {
        return entityUserName;
    }
    const username = meta?.username;
    if (typeof username === "string" && username.length > 0) {
        return username;
    }
    return undefined;
}
function extractFromAvatarUrl(memory) {
    const meta = memory.metadata;
    const entityAvatarUrl = meta?.entityAvatarUrl;
    if (typeof entityAvatarUrl === "string" && entityAvatarUrl.length > 0) {
        return entityAvatarUrl;
    }
    return undefined;
}
function extractRawSenderId(memory) {
    const meta = memory.metadata;
    const fromId = meta?.fromId;
    if (typeof fromId === "string" && fromId.length > 0) {
        return fromId;
    }
    return undefined;
}
function extractDiscordChannelId(memory) {
    const meta = memory.metadata;
    const discordChannelId = meta?.discordChannelId;
    if (typeof discordChannelId === "string" && discordChannelId.length > 0) {
        return discordChannelId;
    }
    return undefined;
}
function extractDiscordMessageId(memory) {
    const meta = memory.metadata;
    const discordMessageId = meta?.discordMessageId;
    if (typeof discordMessageId === "string" && discordMessageId.length > 0) {
        return discordMessageId;
    }
    return undefined;
}
function readLooseStringValue(record, keys) {
    if (!record)
        return null;
    for (const key of keys) {
        const value = record[key];
        if (typeof value !== "string") {
            continue;
        }
        const trimmed = value.trim();
        if (trimmed.length > 0) {
            return trimmed;
        }
    }
    return null;
}
function asLooseRecord(value) {
    return value && typeof value === "object"
        ? value
        : undefined;
}
function readRoomSource(room) {
    return readLooseStringValue(asLooseRecord(room), ["source"]);
}
function connectorSourcesMatch(left, right) {
    // Aliases group sources for inbox display/filtering, but they are not
    // interchangeable transport authorities. Native iMessage and BlueBubbles,
    // for example, share the `imessage` canonical family while owning distinct
    // handlers and account stores.
    return normalizeAccountProvider(left) === normalizeAccountProvider(right);
}
async function resolveTrustedRoomSource(runtime, room) {
    const storedSource = readRoomSource(room);
    if (storedSource)
        return storedSource;
    const latestMemory = await loadLatestRoomMemory(runtime, room.id);
    return latestMemory ? extractSource(latestMemory) : null;
}
function readRoomWorldId(room) {
    return (readLooseStringValue(asLooseRecord(room), ["worldId", "world_id"]) ??
        undefined);
}
function readRoomServerId(room) {
    return (readLooseStringValue(asLooseRecord(room), [
        "serverId",
        "server_id",
        "messageServerId",
        "message_server_id",
    ]) ?? undefined);
}
function readRoomType(room) {
    return readLooseStringValue(asLooseRecord(room), [
        "type",
        "roomType",
        "room_type",
    ]);
}
function readRoomChannelId(room) {
    return (readLooseStringValue(asLooseRecord(room), ["channelId", "channel_id"]) ??
        undefined);
}
function muteUntilIsoFromDuration(durationMinutes) {
    return durationMinutes && durationMinutes > 0
        ? new Date(Date.now() + durationMinutes * 60000).toISOString()
        : undefined;
}
/**
 * A Discord thread inherits its parent channel's mute: the connector's
 * inbound gate drops the thread's messages on the [room, parent] mute chain,
 * so the inbox must report the thread muted too — never muted:false while its
 * messages are being dropped. The parent linkage is not persisted on the room
 * record, so it comes from the same cached live-channel lookup the chat list
 * already uses for titles. When the Discord client is unreachable the parent
 * is unknown and only the room's own state answers — consistent, because a
 * disconnected client is not dropping messages either.
 */
async function resolveDiscordParentRoomId(runtime, room) {
    if (!isDiscordConnectorSource(readRoomSource(room)))
        return undefined;
    const profile = await resolveDiscordRoomProfile(runtime, room);
    return profile?.parentChannelId
        ? createUniqueUuid(runtime, profile.parentChannelId)
        : undefined;
}
async function resolveInboxRoomMuteState(runtime, room, roomId) {
    const worldId = readRoomWorldId(room);
    const parentRoomId = await resolveDiscordParentRoomId(runtime, room);
    const effective = await resolveEffectiveMuteState(runtime, {
        roomIds: parentRoomId ? [roomId, parentRoomId] : [roomId],
        ...(worldId ? { worldId: worldId } : {}),
    });
    if (!effective.muted) {
        return { muted: false };
    }
    return { muted: true, mutedScope: effective.scope };
}
function readRoomCreatedAt(room) {
    const record = asLooseRecord(room);
    const value = record?.createdAt ?? record?.created_at;
    if (typeof value === "number" && Number.isFinite(value)) {
        return value;
    }
    if (value instanceof Date) {
        return value.getTime();
    }
    if (typeof value === "string") {
        const parsed = Date.parse(value);
        return Number.isFinite(parsed) ? parsed : undefined;
    }
    return undefined;
}
function readWorldName(world) {
    return readLooseStringValue(asLooseRecord(world), ["name"]);
}
function readWorldServerId(world) {
    return (readLooseStringValue(asLooseRecord(world), [
        "messageServerId",
        "message_server_id",
        "serverId",
        "server_id",
    ]) ?? undefined);
}
function normalizeRoomTitle(title) {
    if (typeof title !== "string")
        return null;
    const trimmed = title.trim();
    return trimmed.length > 0 ? trimmed : null;
}
function isPlaceholderConversationTitle(title) {
    if (!title)
        return false;
    const normalized = title.trim().toLowerCase();
    return (normalized === "default" ||
        normalized === "new chat" ||
        normalized === "discord chat");
}
function equalsNormalizedTitle(left, right) {
    if (!left || !right)
        return false;
    return left.trim().toLowerCase() === right.trim().toLowerCase();
}
function extractReplyToMessageId(memory) {
    const content = memory.content;
    const inReplyTo = content?.inReplyTo;
    if (typeof inReplyTo === "string" && inReplyTo.length > 0) {
        return inReplyTo;
    }
    const meta = memory.metadata;
    const replyToMessageId = meta?.replyToMessageId;
    if (typeof replyToMessageId === "string" && replyToMessageId.length > 0) {
        return replyToMessageId;
    }
    return undefined;
}
function extractReplyAuthorRecord(memory) {
    const meta = memory.metadata;
    const replyToAuthor = meta?.replyToAuthor;
    if (!replyToAuthor || typeof replyToAuthor !== "object") {
        return null;
    }
    return replyToAuthor;
}
function extractReplyToSenderName(memory) {
    const meta = memory.metadata;
    const replyToSenderName = meta?.replyToSenderName;
    if (typeof replyToSenderName === "string" && replyToSenderName.length > 0) {
        return replyToSenderName;
    }
    const replyAuthor = extractReplyAuthorRecord(memory);
    const displayName = replyAuthor?.displayName;
    if (typeof displayName === "string" && displayName.length > 0) {
        return displayName;
    }
    const username = replyAuthor?.username;
    if (typeof username === "string" && username.length > 0) {
        return username;
    }
    return undefined;
}
function extractReplyToSenderUserName(memory) {
    const meta = memory.metadata;
    const replyToSenderUserName = meta?.replyToSenderUserName;
    if (typeof replyToSenderUserName === "string" &&
        replyToSenderUserName.length > 0) {
        return replyToSenderUserName;
    }
    const replyAuthor = extractReplyAuthorRecord(memory);
    const username = replyAuthor?.username;
    if (typeof username === "string" && username.length > 0) {
        return username;
    }
    return undefined;
}
function extractReplyToSenderId(memory) {
    const meta = memory.metadata;
    const replyToSenderId = meta?.replyToSenderId;
    if (typeof replyToSenderId === "string" && replyToSenderId.length > 0) {
        return replyToSenderId;
    }
    const replyAuthor = extractReplyAuthorRecord(memory);
    const id = replyAuthor?.id;
    if (typeof id === "string" && id.length > 0) {
        return id;
    }
    return undefined;
}
const LEGACY_DISCORD_REACTION_RE = /^\*(Added|Removed) <(.+?)> (?:to|from):/i;
function extractDiscordReactionEvent(memory) {
    const targetMessageId = extractReplyToMessageId(memory);
    if (!targetMessageId) {
        return null;
    }
    const meta = memory.metadata;
    const reactionMeta = meta?.discordReaction && typeof meta.discordReaction === "object"
        ? meta.discordReaction
        : null;
    const structuredAction = reactionMeta?.action === "add" || reactionMeta?.action === "remove"
        ? reactionMeta.action
        : null;
    const structuredEmoji = typeof reactionMeta?.emoji === "string" &&
        reactionMeta.emoji.trim().length > 0
        ? reactionMeta.emoji.trim()
        : null;
    if (structuredAction && structuredEmoji) {
        return {
            action: structuredAction,
            emoji: structuredEmoji,
            targetMessageId,
            userKey: memory.entityId,
            userLabel: extractFrom(memory) ?? extractFromUserName(memory),
        };
    }
    const source = extractSource(memory);
    if (!isDiscordConnectorSource(source)) {
        return null;
    }
    const text = extractText(memory).trim();
    const legacyMatch = text.match(LEGACY_DISCORD_REACTION_RE);
    if (!legacyMatch) {
        return null;
    }
    return {
        action: legacyMatch[1].toLowerCase() === "added" ? "add" : "remove",
        emoji: legacyMatch[2].trim(),
        targetMessageId,
        userKey: memory.entityId,
        userLabel: extractFrom(memory) ?? extractFromUserName(memory),
    };
}
function buildMessageReactionMap(memories) {
    const stateByTargetId = new Map();
    const chronologicallySortedMemories = [...memories].sort((left, right) => (left.createdAt ?? 0) - (right.createdAt ?? 0));
    for (const memory of chronologicallySortedMemories) {
        const event = extractDiscordReactionEvent(memory);
        if (!event) {
            continue;
        }
        const byEmoji = stateByTargetId.get(event.targetMessageId) ??
            new Map();
        const aggregate = byEmoji.get(event.emoji) ?? {
            emoji: event.emoji,
            users: new Map(),
        };
        if (event.action === "add") {
            aggregate.users.set(event.userKey, event.userLabel);
            byEmoji.set(event.emoji, aggregate);
            stateByTargetId.set(event.targetMessageId, byEmoji);
            continue;
        }
        aggregate.users.delete(event.userKey);
        if (aggregate.users.size === 0) {
            byEmoji.delete(event.emoji);
        }
        else {
            byEmoji.set(event.emoji, aggregate);
        }
        if (byEmoji.size === 0) {
            stateByTargetId.delete(event.targetMessageId);
        }
        else {
            stateByTargetId.set(event.targetMessageId, byEmoji);
        }
    }
    const reactionsByTargetId = new Map();
    for (const [targetMessageId, byEmoji] of stateByTargetId) {
        const reactions = Array.from(byEmoji.values())
            .map((aggregate) => {
            const users = Array.from(aggregate.users.values()).filter((value) => typeof value === "string" && value.trim().length > 0);
            return {
                emoji: aggregate.emoji,
                count: aggregate.users.size,
                ...(users.length > 0 ? { users } : {}),
            };
        })
            .filter((reaction) => reaction.count > 0);
        if (reactions.length > 0) {
            reactionsByTargetId.set(targetMessageId, reactions);
        }
    }
    return reactionsByTargetId;
}
const DISCORD_PROFILE_CACHE_TTL_MS = 5 * 60000;
const discordRoomProfileCache = new Map();
const discordUserProfileCache = new Map();
const discordMessageAuthorProfileCache = new Map();
function readCachedValue(cache, key) {
    const entry = cache.get(key);
    if (!entry)
        return undefined;
    if (entry.expiresAt <= Date.now()) {
        cache.delete(key);
        return undefined;
    }
    return entry.value;
}
/**
 * Hard ceiling on the entries a single Discord profile cache may retain.
 *
 * `readCachedValue` is the only place an entry is ever dropped, and it only
 * drops one when that exact key is read back after expiry. That is fine for the
 * room cache (keyed by channel id) and the user cache (keyed by Discord user
 * id), but `discordMessageAuthorProfileCache` is keyed by Discord message id: a
 * key is re-read only while its message is still inside the window
 * `GET /api/inbox/messages` returns. Once the message scrolls out, its entry is
 * unreachable, and past the TTL it is unservable too — yet it stayed resident
 * for the whole life of the agent process, one permanent entry per Discord
 * message the inbox had ever rendered. Sweeping on write bounds every cache
 * regardless of message volume.
 *
 * The ceiling sits well above the 500-row hard cap of one inbox page, so a full
 * page still round-trips entirely from cache.
 */
export const MAX_DISCORD_PROFILE_CACHE_ENTRIES = 2048;
/**
 * Store `value` under `key` and keep the cache within
 * MAX_DISCORD_PROFILE_CACHE_ENTRIES. Expired entries are swept first; if that
 * is not enough, the oldest writes are dropped. Every write re-inserts its key
 * so the Map's insertion order stays equal to write order — that is what makes
 * "oldest" mean what it says here.
 */
function writeCachedValue(cache, key, value) {
    cache.delete(key);
    cache.set(key, {
        expiresAt: Date.now() + DISCORD_PROFILE_CACHE_TTL_MS,
        value,
    });
    if (cache.size <= MAX_DISCORD_PROFILE_CACHE_ENTRIES)
        return;
    const now = Date.now();
    for (const [entryKey, entry] of cache) {
        if (entry.expiresAt <= now)
            cache.delete(entryKey);
    }
    for (const entryKey of cache.keys()) {
        if (cache.size <= MAX_DISCORD_PROFILE_CACHE_ENTRIES)
            break;
        if (entryKey === key)
            continue;
        cache.delete(entryKey);
    }
}
function getDiscordClient(runtime) {
    const runtimeWithServices = runtime;
    const service = runtimeWithServices.getService(DISCORD_SERVICE_NAME);
    return service?.client ?? null;
}
function firstCollectionValue(collection) {
    if (!collection || typeof collection !== "object") {
        return null;
    }
    const record = collection;
    if (typeof record.first === "function") {
        return record.first();
    }
    if (typeof record.values === "function") {
        return record.values().next().value ?? null;
    }
    return null;
}
function readDiscordDisplayName(user) {
    if (!user || typeof user !== "object")
        return undefined;
    const record = user;
    const globalName = record.globalName;
    if (typeof globalName === "string" && globalName.trim()) {
        return globalName.trim();
    }
    const displayName = record.displayName;
    if (typeof displayName === "string" && displayName.trim()) {
        return displayName.trim();
    }
    const username = record.username;
    if (typeof username === "string" && username.trim()) {
        return username.trim();
    }
    return undefined;
}
function readDiscordAvatarUrl(user) {
    if (!user || typeof user !== "object")
        return undefined;
    const record = user;
    if (typeof record.displayAvatarURL === "function") {
        const url = record.displayAvatarURL();
        if (typeof url === "string" && url.trim())
            return url;
    }
    if (typeof record.avatarURL === "function") {
        const url = record.avatarURL();
        if (typeof url === "string" && url.trim())
            return url;
    }
    return undefined;
}
function readStoredDiscordEntityProfile(entity) {
    if (!entity || typeof entity !== "object") {
        return null;
    }
    const metadata = entity.metadata;
    if (!metadata || typeof metadata !== "object") {
        return null;
    }
    const record = metadata;
    const discord = record.discord && typeof record.discord === "object"
        ? record.discord
        : null;
    const fallback = record.default && typeof record.default === "object"
        ? record.default
        : null;
    const displayName = readLooseStringValue(record, ["displayName", "name"]) ??
        readLooseStringValue(discord ?? undefined, [
            "displayName",
            "globalName",
            "name",
        ]) ??
        readLooseStringValue(fallback ?? undefined, ["name"]);
    const username = readLooseStringValue(record, ["username"]) ??
        readLooseStringValue(discord ?? undefined, ["username", "userName"]) ??
        readLooseStringValue(fallback ?? undefined, ["username"]);
    const avatarUrl = readLooseStringValue(record, ["avatarUrl"]) ??
        readLooseStringValue(discord ?? undefined, ["avatarUrl"]) ??
        readLooseStringValue(fallback ?? undefined, ["avatarUrl"]);
    const rawUserId = readLooseStringValue(discord ?? undefined, ["userId", "id"]) ??
        readLooseStringValue(record, ["originalId"]);
    if (!displayName && !username && !avatarUrl && !rawUserId) {
        return null;
    }
    return {
        ...(avatarUrl ? { avatarUrl } : {}),
        ...(displayName ? { displayName } : {}),
        ...(rawUserId ? { rawUserId } : {}),
        ...(username ? { username } : {}),
    };
}
async function resolveStoredDiscordEntityProfile(runtime, entityId) {
    if (!entityId)
        return null;
    const runtimeWithEntityLookup = runtime;
    if (typeof runtimeWithEntityLookup.getEntityById !== "function") {
        return null;
    }
    // A null return from getEntityById means "no stored entity", which the
    // inbox legitimately renders without a stored profile. A rejected read is
    // a storage fault and must not be flattened into that same "no profile"
    // shape, or the sender silently loses their name and avatar.
    const entity = await runtimeWithEntityLookup.getEntityById(entityId);
    return readStoredDiscordEntityProfile(entity);
}
async function cacheInboxDiscordAvatar(runtime, avatarUrl, userId) {
    const { cacheDiscordAvatarUrl } = await getDiscordModule();
    return cacheDiscordAvatarUrl(avatarUrl, {
        fetchImpl: runtime.fetch,
        userId,
    });
}
async function resolveDiscordMessageAuthorProfile(runtime, channelId, messageId) {
    const cacheKey = `${channelId}:${messageId}`;
    const cached = readCachedValue(discordMessageAuthorProfileCache, cacheKey);
    if (cached !== undefined)
        return cached;
    const client = getDiscordClient(runtime);
    const cachedChannel = client?.channels?.cache?.get?.(channelId);
    const fetchChannel = client?.channels?.fetch;
    const channel = cachedChannel ??
        (typeof fetchChannel === "function"
            ? await fetchChannel(channelId).catch(() => null)
            : null);
    const fetchMessage = channel &&
        typeof channel === "object" &&
        typeof channel.messages?.fetch === "function"
        ? channel.messages.fetch
        : null;
    if (!fetchMessage) {
        writeCachedValue(discordMessageAuthorProfileCache, cacheKey, null);
        return null;
    }
    try {
        const message = await fetchMessage(messageId);
        const author = message && typeof message === "object"
            ? (message.author ?? null)
            : null;
        const member = message && typeof message === "object"
            ? (message.member ?? null)
            : null;
        const rawUserId = author &&
            typeof author === "object" &&
            typeof author.id === "string"
            ? author.id
            : undefined;
        const profile = {
            displayName: readDiscordDisplayName(member ?? author),
            username: author &&
                typeof author === "object" &&
                typeof author.username === "string"
                ? author.username
                : undefined,
            avatarUrl: readDiscordAvatarUrl(author),
            ...(rawUserId ? { rawUserId } : {}),
        };
        writeCachedValue(discordMessageAuthorProfileCache, cacheKey, profile);
        return profile;
    }
    catch {
        writeCachedValue(discordMessageAuthorProfileCache, cacheKey, null);
        return null;
    }
}
async function resolveDiscordUserProfile(runtime, userId) {
    const cached = readCachedValue(discordUserProfileCache, userId);
    if (cached !== undefined)
        return cached;
    const client = getDiscordClient(runtime);
    const fetchUser = client?.users?.fetch;
    if (typeof fetchUser !== "function")
        return null;
    try {
        const user = await fetchUser(userId);
        const profile = {
            displayName: readDiscordDisplayName(user),
            username: user &&
                typeof user === "object" &&
                typeof user.username === "string"
                ? user.username
                : undefined,
            avatarUrl: readDiscordAvatarUrl(user),
        };
        writeCachedValue(discordUserProfileCache, userId, profile);
        return profile;
    }
    catch {
        writeCachedValue(discordUserProfileCache, userId, null);
        return null;
    }
}
async function resolveDiscordRoomProfile(runtime, room, channelIdHint) {
    const channelId = typeof channelIdHint === "string" && channelIdHint.trim()
        ? channelIdHint.trim()
        : (readRoomChannelId(room) ?? "");
    if (!channelId)
        return null;
    const cached = readCachedValue(discordRoomProfileCache, channelId);
    if (cached !== undefined)
        return cached;
    const client = getDiscordClient(runtime);
    const cachedChannel = client?.channels?.cache?.get?.(channelId);
    const fetchChannel = client?.channels?.fetch;
    const channel = cachedChannel ??
        (typeof fetchChannel === "function"
            ? await fetchChannel(channelId).catch(() => null)
            : null);
    let title = null;
    let avatarUrl;
    let parentChannelId;
    if (channel && typeof channel === "object") {
        const namedChannel = channel;
        if (typeof namedChannel.name === "string" && namedChannel.name.trim()) {
            title = namedChannel.name.trim();
        }
        else {
            const record = channel;
            const recipient = record.recipient ?? firstCollectionValue(record.recipients);
            title = readDiscordDisplayName(recipient) ?? null;
            avatarUrl = readDiscordAvatarUrl(recipient);
        }
        const parentRecord = channel;
        if (typeof parentRecord.parentId === "string" &&
            parentRecord.parentId.length > 0) {
            parentChannelId = parentRecord.parentId;
        }
    }
    const profile = {
        title,
        ...(typeof avatarUrl === "string" && avatarUrl.length > 0
            ? { avatarUrl }
            : {}),
        ...(parentChannelId ? { parentChannelId } : {}),
    };
    writeCachedValue(discordRoomProfileCache, channelId, profile);
    return profile;
}
/**
 * Enumerate every room the agent currently has state for, up to
 * MAX_ROOMS_SCANNED. We do this by walking every world the runtime
 * knows about and collecting rooms under each. For a single-agent
 * Eliza install this is bounded by the number of connector chats the
 * agent participates in; for multi-tenant it would need a tenant scope
 * but Eliza's runtime is single-tenant per process.
 *
 * Internal scratch worlds (autonomy self-talk, advanced memory,
 * relationships graph) are excluded, mirroring collectAgentWorlds.
 * Including them starves the feed: getMemoriesByRoomIds orders
 * newest-first across ALL scanned rooms with a bounded limit, and an
 * active autonomy loop emits messages continuously, so its synthetic
 * rooms monopolize the fetch window. Every row is then dropped by the
 * connector source filter and the inbox reads empty even though real
 * connector messages exist just past the window.
 */
async function collectAgentRoomIds(runtime) {
    const worlds = await runtime.getAllWorlds();
    if (worlds.length === 0)
        return [];
    const worldIds = worlds
        .filter((w) => !isInternalWorld(w))
        .map((w) => w.id)
        .filter((id) => typeof id === "string");
    if (worldIds.length === 0)
        return [];
    // getRoomsByWorlds is the bulk form — single round trip instead of
    // one query per world.
    const rooms = await runtime.getRoomsByWorlds(worldIds, MAX_ROOMS_SCANNED, 0);
    const roomIds = [];
    for (const room of rooms) {
        if (room.id)
            roomIds.push(room.id);
        if (roomIds.length >= MAX_ROOMS_SCANNED)
            break;
    }
    return roomIds;
}
async function collectAgentWorlds(runtime) {
    const worlds = await runtime.getAllWorlds();
    const worldsById = new Map();
    for (const world of worlds) {
        if (!world.id)
            continue;
        // Skip internal scratch worlds — autonomy self-talk, advanced memory,
        // relationships graph. These accumulate hundreds of synthetic rooms
        // that crowd real connector channels out of the room-scan budget.
        if (isInternalWorld(world))
            continue;
        worldsById.set(world.id, world);
    }
    return worldsById;
}
/**
 * Collect every room owned by the agent (bounded by MAX_ROOMS_SCANNED)
 * as full Room objects rather than just ids. Used by the chats
 * aggregator which needs each room's name + world for display.
 */
async function collectAgentRooms(runtime) {
    const worldsById = await collectAgentWorlds(runtime);
    if (worldsById.size === 0)
        return [];
    const worldIds = Array.from(worldsById.keys()).filter((id) => typeof id === "string");
    if (worldIds.length === 0)
        return [];
    return runtime.getRoomsByWorlds(worldIds, MAX_ROOMS_SCANNED, 0);
}
function resolveInboxWorldLabel(room, world) {
    const namedWorld = readWorldName(world);
    if (namedWorld) {
        return namedWorld;
    }
    const roomServerId = readRoomServerId(room);
    if (roomServerId) {
        return roomServerId;
    }
    const worldServerId = readWorldServerId(world);
    if (worldServerId) {
        return worldServerId;
    }
    const roomType = readRoomType(room)?.trim().toUpperCase();
    if (roomType === "DM") {
        return "Direct messages";
    }
    const worldId = readRoomWorldId(room);
    if (worldId) {
        return worldId;
    }
    return "Unknown world";
}
async function loadRelevantRooms(runtime, requestedRoomId) {
    const roomById = new Map();
    if (requestedRoomId) {
        const runtimeWithGetRoom = runtime;
        if (typeof runtimeWithGetRoom.getRoom === "function") {
            const room = await runtimeWithGetRoom.getRoom(requestedRoomId);
            if (room?.id) {
                roomById.set(room.id, room);
                return roomById;
            }
        }
    }
    const rooms = await collectAgentRooms(runtime);
    for (const room of rooms) {
        if (!room.id)
            continue;
        if (requestedRoomId && room.id !== requestedRoomId)
            continue;
        roomById.set(room.id, room);
    }
    return roomById;
}
function applyInboxChatMemory(accumulator, memory, room, source) {
    const key = memory.roomId;
    if (!key)
        return;
    const text = extractText(memory);
    if (!text)
        return;
    const ts = memory.createdAt ?? 0;
    const senderAvatarUrl = extractFromAvatarUrl(memory);
    const senderEntityId = typeof memory.entityId === "string" ? memory.entityId : undefined;
    const senderName = extractFrom(memory) ?? extractFromUserName(memory) ?? undefined;
    const senderRawId = extractRawSenderId(memory);
    const discordChannelId = extractDiscordChannelId(memory) ?? readRoomChannelId(room);
    const discordMessageId = extractDiscordMessageId(memory);
    const existing = accumulator.get(key);
    if (!existing) {
        accumulator.set(key, {
            latestDiscordChannelId: discordChannelId,
            latestDiscordMessageId: discordMessageId,
            source,
            lastMessageText: truncateWellFormed(toWellFormedUnicode(text), INBOX_CHAT_PREVIEW_LENGTH),
            lastMessageAt: ts,
            messageCount: 1,
            latestSenderAvatarUrl: senderAvatarUrl,
            latestSenderEntityId: senderEntityId,
            latestSenderName: senderName,
            latestSenderRawId: senderRawId,
        });
        return;
    }
    existing.messageCount += 1;
    if (ts > existing.lastMessageAt) {
        existing.lastMessageAt = ts;
        existing.lastMessageText = truncateWellFormed(toWellFormedUnicode(text), INBOX_CHAT_PREVIEW_LENGTH);
        existing.latestSenderAvatarUrl = senderAvatarUrl;
        existing.latestSenderEntityId = senderEntityId;
        existing.latestSenderName = senderName;
        existing.latestSenderRawId = senderRawId;
        existing.latestDiscordMessageId =
            discordMessageId ?? existing.latestDiscordMessageId;
        existing.latestDiscordChannelId =
            discordChannelId ?? existing.latestDiscordChannelId;
    }
    else if (!existing.latestDiscordChannelId && discordChannelId) {
        existing.latestDiscordChannelId = discordChannelId;
    }
    else if (!existing.latestDiscordMessageId && discordMessageId) {
        existing.latestDiscordMessageId = discordMessageId;
    }
}
async function loadLatestRoomMemory(runtime, roomId) {
    const memories = await runtime.getMemories({
        tableName: "messages",
        roomId,
        limit: 10,
        unique: false,
    });
    if (!Array.isArray(memories) || memories.length === 0) {
        return null;
    }
    const candidates = memories
        .filter((memory) => !extractDiscordReactionEvent(memory))
        .filter((memory) => extractText(memory).trim().length > 0)
        .sort((left, right) => {
        const rightCreated = typeof right.createdAt === "number" && Number.isFinite(right.createdAt)
            ? right.createdAt
            : 0;
        const leftCreated = typeof left.createdAt === "number" && Number.isFinite(left.createdAt)
            ? left.createdAt
            : 0;
        return (rightCreated - leftCreated ||
            (left.id ?? "").localeCompare(right.id ?? ""));
    });
    return candidates[0] ?? null;
}
async function augmentRoomsFromRecentMemories(runtime, roomById, sourceFilter) {
    if (roomById.size >= MAX_ROOMS_SCANNED) {
        return;
    }
    const recentMemories = await runtime.getMemories({
        agentId: runtime.agentId,
        limit: ORPHAN_ROOM_MEMORY_SCAN_LIMIT,
        tableName: "messages",
        unique: false,
    });
    for (const memory of recentMemories) {
        if (roomById.size >= MAX_ROOMS_SCANNED) {
            break;
        }
        const roomId = memory.roomId;
        if (!roomId || roomById.has(roomId)) {
            continue;
        }
        const source = extractSource(memory);
        if (!source || !sourceFilter.has(source.toLowerCase())) {
            continue;
        }
        roomById.set(roomId, {
            id: roomId,
            name: normalizeRoomTitle(extractFrom(memory)) ?? undefined,
            source,
            type: "GROUP",
            room_type: "GROUP",
            channelId: extractDiscordChannelId(memory) ?? undefined,
            channel_id: extractDiscordChannelId(memory),
        });
    }
}
/**
 * Fetch messages, optionally scoped to a single room. When `roomId`
 * is set the function skips world enumeration entirely and targets
 * that specific room — used by the cross-channel chat read path where the
 * sidebar already knows which room the user clicked. When `roomId`
 * is null it walks every agent room and merges across them, which is
 * the cross-channel "everything" feed.
 *
 * Either way the source filter applies: rows whose content.source
 * isn't in the allowed set are dropped before ordering, so callers
 * can never accidentally surface an internal trajectory/system memory
 * via this endpoint.
 */
async function loadInboxMessages(runtime, limit, sourceFilter, roomId, roomSourceHint) {
    const roomById = await loadRelevantRooms(runtime, roomId);
    const agentId = runtime.agentId;
    const roomSourceById = new Map();
    for (const [knownRoomId, room] of roomById) {
        const roomSource = readRoomSource(room);
        if (!roomSource || !sourceFilter.has(roomSource.toLowerCase()))
            continue;
        roomSourceById.set(knownRoomId, roomSource);
    }
    const out = [];
    const reactionMemories = [];
    const pendingSourceMemories = new Map();
    const appendMemory = (memory) => {
        const reaction = extractDiscordReactionEvent(memory);
        if (reaction) {
            reactionMemories.push(memory);
            return;
        }
        const room = roomById.get(memory.roomId);
        const explicitSource = extractSource(memory);
        const source = explicitSource ??
            roomSourceById.get(memory.roomId) ??
            (roomId
                ? (readRoomSource(room) ?? roomSourceHint ?? undefined)
                : undefined);
        if (!source) {
            const pending = pendingSourceMemories.get(memory.roomId) ?? [];
            pending.push(memory);
            pendingSourceMemories.set(memory.roomId, pending);
            return;
        }
        if (!sourceFilter.has(source.toLowerCase()))
            return;
        const text = extractText(memory);
        if (!text)
            return;
        out.push({
            id: memory.id ?? "",
            role: memory.entityId === agentId ? "assistant" : "user",
            text,
            timestamp: memory.createdAt ?? 0,
            source,
            rawDiscordChannelId: extractDiscordChannelId(memory) ?? readRoomChannelId(room),
            rawDiscordMessageId: extractDiscordMessageId(memory),
            responseId: extractResponseId(memory),
            roomId: memory.roomId,
            hasExternalUrl: extractContentUrl(memory) !== undefined,
            hasExplicitSource: explicitSource !== null,
            from: extractFrom(memory),
            fromUserName: extractFromUserName(memory),
            avatarUrl: extractFromAvatarUrl(memory),
            replyToMessageId: extractReplyToMessageId(memory),
            replyToSenderName: extractReplyToSenderName(memory),
            replyToSenderUserName: extractReplyToSenderUserName(memory),
            rawReplyToSenderId: extractReplyToSenderId(memory),
            senderEntityId: typeof memory.entityId === "string" ? memory.entityId : undefined,
            rawSenderId: extractRawSenderId(memory),
        });
    };
    const pageSize = limit * PER_ROOM_OVERFETCH_MULTIPLIER;
    const roomIds = roomId ? null : await collectAgentRoomIds(runtime);
    if (roomIds && roomIds.length === 0)
        return [];
    const seenMemoryIds = new Set();
    let previousPageFingerprint = null;
    let offset = 0;
    // The public limit counts renderable, deduplicated messages—not raw storage
    // rows. Keep paging without a history cap; repeated-page detection protects
    // runtimes whose adapters ignore offset.
    while (dedupeInboxMessages(out).length < limit) {
        const page = roomId
            ? await runtime.getMemories({
                tableName: "messages",
                roomId,
                limit: pageSize,
                offset,
                unique: false,
            })
            : await runtime.getMemoriesByRoomIds({
                tableName: "messages",
                roomIds: roomIds ?? [],
                limit: pageSize,
                offset,
            });
        if (page.length === 0)
            break;
        const pageFingerprint = page
            .map((memory) => memory.id
            ? `id:${memory.id}`
            : `row:${String(memory.createdAt)}|${memory.roomId}|${extractText(memory)}`)
            .join("\n");
        if (pageFingerprint === previousPageFingerprint)
            break;
        previousPageFingerprint = pageFingerprint;
        const freshPage = [];
        for (const memory of page) {
            if (memory.id && seenMemoryIds.has(memory.id))
                continue;
            if (memory.id)
                seenMemoryIds.add(memory.id);
            freshPage.push(memory);
        }
        if (freshPage.length === 0)
            break;
        const newlyResolvedRooms = new Set();
        for (const memory of freshPage) {
            const source = extractSource(memory);
            if (!source || !sourceFilter.has(source.toLowerCase()))
                continue;
            const memoryRoomId = memory.roomId;
            if (!memoryRoomId || roomSourceById.has(memoryRoomId))
                continue;
            roomSourceById.set(memoryRoomId, source);
            newlyResolvedRooms.add(memoryRoomId);
        }
        for (const resolvedRoomId of newlyResolvedRooms) {
            const pending = pendingSourceMemories.get(resolvedRoomId) ?? [];
            pendingSourceMemories.delete(resolvedRoomId);
            for (const memory of pending)
                appendMemory(memory);
        }
        for (const memory of freshPage)
            appendMemory(memory);
        if (page.length < pageSize)
            break;
        offset += page.length;
    }
    const reactionsByMessageId = buildMessageReactionMap(reactionMemories);
    for (const message of out) {
        message.reactions = message.id
            ? reactionsByMessageId.get(message.id)
            : undefined;
    }
    const deduped = dedupeInboxMessages(out);
    // Newest first. The core API doesn't guarantee order across rooms, so
    // we do the merge sort client-side.
    deduped.sort((a, b) => {
        const bTime = typeof b.timestamp === "number" && Number.isFinite(b.timestamp)
            ? b.timestamp
            : 0;
        const aTime = typeof a.timestamp === "number" && Number.isFinite(a.timestamp)
            ? a.timestamp
            : 0;
        return bTime - aTime || a.id.localeCompare(b.id);
    });
    const ordered = deduped.slice(0, limit);
    await Promise.all(ordered.map(async (message) => {
        if (!isDiscordConnectorSource(message.source))
            return;
        const storedSenderProfile = await resolveStoredDiscordEntityProfile(runtime, message.senderEntityId);
        if (!message.from && storedSenderProfile?.displayName) {
            message.from = storedSenderProfile.displayName;
        }
        if (!message.fromUserName && storedSenderProfile?.username) {
            message.fromUserName = storedSenderProfile.username;
        }
        if (!message.avatarUrl && storedSenderProfile?.avatarUrl) {
            message.avatarUrl = storedSenderProfile.avatarUrl;
        }
        const messageAuthorProfile = message.rawDiscordChannelId && message.rawDiscordMessageId
            ? await resolveDiscordMessageAuthorProfile(runtime, message.rawDiscordChannelId, message.rawDiscordMessageId)
            : null;
        if (!message.from && messageAuthorProfile?.displayName) {
            message.from = messageAuthorProfile.displayName;
        }
        if (!message.fromUserName && messageAuthorProfile?.username) {
            message.fromUserName = messageAuthorProfile.username;
        }
        if (!message.avatarUrl && messageAuthorProfile?.avatarUrl) {
            message.avatarUrl = messageAuthorProfile.avatarUrl;
        }
        const rawSenderId = message.rawSenderId ??
            storedSenderProfile?.rawUserId ??
            messageAuthorProfile?.rawUserId;
        if (rawSenderId) {
            const profile = await resolveDiscordUserProfile(runtime, rawSenderId);
            if (profile) {
                if (profile.displayName) {
                    message.from = profile.displayName;
                }
                if (profile.username) {
                    message.fromUserName = profile.username;
                }
                if (profile.avatarUrl) {
                    message.avatarUrl = profile.avatarUrl;
                }
            }
        }
        message.avatarUrl = await cacheInboxDiscordAvatar(runtime, message.avatarUrl, rawSenderId);
        if (message.rawReplyToSenderId) {
            const replyProfile = await resolveDiscordUserProfile(runtime, message.rawReplyToSenderId);
            if (replyProfile) {
                if (replyProfile.displayName) {
                    message.replyToSenderName = replyProfile.displayName;
                }
                if (replyProfile.username) {
                    message.replyToSenderUserName = replyProfile.username;
                }
            }
        }
    }));
    return ordered.map(({ hasExternalUrl: _hasExternalUrl, hasExplicitSource: _hasExplicitSource, rawDiscordChannelId: _rawDiscordChannelId, rawDiscordMessageId: _rawDiscordMessageId, rawReplyToSenderId: _rawReplyToSenderId, senderEntityId: _senderEntityId, rawSenderId: _rawSenderId, responseId: _responseId, ...message }) => message);
}
function normalizeInboxComparableText(text) {
    return text.trim().replace(/\s+/g, " ");
}
function getInboxMessagePreferenceScore(message) {
    let score = 0;
    if (message.hasExternalUrl)
        score += 8;
    if (message.hasExplicitSource)
        score += 8;
    if (message.replyToSenderName || message.replyToSenderUserName)
        score += 4;
    if (message.rawReplyToSenderId)
        score += 2;
    if (message.rawSenderId)
        score += 1;
    if (message.avatarUrl)
        score += 1;
    return score;
}
function isConnectorVisibleDiscordAssistantMessage(message) {
    return (isDiscordConnectorSource(message.source) &&
        message.role === "assistant" &&
        (message.hasExplicitSource || message.hasExternalUrl));
}
function isImplicitDiscordAssistantShadow(message) {
    return (isDiscordConnectorSource(message.source) &&
        message.role === "assistant" &&
        !message.hasExplicitSource &&
        !message.hasExternalUrl);
}
function buildDiscordReplyKey(message) {
    const replyToMessageId = message.replyToMessageId?.trim();
    if (!replyToMessageId) {
        return null;
    }
    return `${message.roomId}\u0000${replyToMessageId}`;
}
function suppressUnsentDiscordAssistantShadows(messages) {
    const latestVisibleReplyByKey = new Map();
    for (const message of messages) {
        if (!isConnectorVisibleDiscordAssistantMessage(message)) {
            continue;
        }
        const replyKey = buildDiscordReplyKey(message);
        if (!replyKey) {
            continue;
        }
        const existingTimestamp = latestVisibleReplyByKey.get(replyKey) ?? 0;
        if (message.timestamp >= existingTimestamp) {
            latestVisibleReplyByKey.set(replyKey, message.timestamp);
        }
    }
    return messages.filter((message) => {
        if (!isImplicitDiscordAssistantShadow(message)) {
            return true;
        }
        const replyKey = buildDiscordReplyKey(message);
        if (!replyKey) {
            return true;
        }
        const latestVisibleTimestamp = latestVisibleReplyByKey.get(replyKey);
        if (latestVisibleTimestamp === undefined) {
            return true;
        }
        return message.timestamp > latestVisibleTimestamp;
    });
}
function areLikelyConnectorAssistantDuplicates(left, right) {
    if (left.role !== "assistant" || right.role !== "assistant") {
        return false;
    }
    if (left.roomId !== right.roomId) {
        return false;
    }
    if (normalizeInboxComparableText(left.text) !==
        normalizeInboxComparableText(right.text)) {
        return false;
    }
    const leftResponseId = left.responseId?.trim() ?? "";
    const rightResponseId = right.responseId?.trim() ?? "";
    if (leftResponseId && rightResponseId) {
        return leftResponseId === rightResponseId;
    }
    if (left.hasExplicitSource === right.hasExplicitSource) {
        return false;
    }
    if (Math.abs(left.timestamp - right.timestamp) > 15000) {
        return false;
    }
    const leftReplyId = left.replyToMessageId?.trim() ?? "";
    const rightReplyId = right.replyToMessageId?.trim() ?? "";
    if (leftReplyId && rightReplyId) {
        return leftReplyId === rightReplyId;
    }
    return true;
}
function dedupeInboxMessages(messages) {
    const filteredMessages = suppressUnsentDiscordAssistantShadows(messages);
    const deduped = [];
    for (const message of filteredMessages) {
        const duplicateIndex = deduped.findIndex((candidate) => areLikelyConnectorAssistantDuplicates(candidate, message));
        if (duplicateIndex === -1) {
            deduped.push(message);
            continue;
        }
        const existing = deduped[duplicateIndex];
        const existingScore = getInboxMessagePreferenceScore(existing);
        const nextScore = getInboxMessagePreferenceScore(message);
        if (nextScore > existingScore ||
            (nextScore === existingScore && message.timestamp > existing.timestamp)) {
            deduped[duplicateIndex] = message;
        }
    }
    return deduped;
}
/** Cap on how many characters of last-message text we return per chat. */
const INBOX_CHAT_PREVIEW_LENGTH = 140;
const PostInboxChatMuteRequestSchema = z.object({
    roomId: z.string().trim().min(1),
    action: z.enum(["mute", "unmute"]),
    scope: z.enum(["room", "server"]).optional().default("room"),
    durationMinutes: z
        .number()
        .int()
        .positive()
        .max(60 * 24 * 30)
        .optional(),
});
/**
 * Walk every agent room, collect the subset that contain connector
 * messages, and reduce each to a single InboxChat row with the room's
 * latest activity as the ordering key. This is the sidebar feed for
 * the messages view — one row per external chat thread.
 *
 * We over-fetch memories across all rooms in one bulk call (same
 * pattern loadInboxMessages uses) then group client-side. For the
 * single-agent single-process topology Eliza runs under, this is
 * cheap enough to call on a 5-second poll without special-casing.
 */
async function loadInboxChats(runtime, sourceFilter) {
    const worldsById = await collectAgentWorlds(runtime);
    const rooms = worldsById.size > 0
        ? await runtime.getRoomsByWorlds(Array.from(worldsById.keys()), MAX_ROOMS_SCANNED, 0)
        : [];
    if (rooms.length === 0)
        return [];
    // Build an id → Room lookup so the memory reducer can fill in the
    // chat title from the room's own name field (plugins stamp this when
    // they create the room from ENTITY_JOINED / WORLD_JOINED).
    const roomById = new Map();
    for (const room of rooms) {
        if (room.id)
            roomById.set(room.id, room);
    }
    await augmentRoomsFromRecentMemories(runtime, roomById, sourceFilter);
    const roomIds = Array.from(roomById.keys());
    if (roomIds.length === 0)
        return [];
    // Fetch a wide slice of recent memories in one call and group by
    // room client-side. 2000 messages is enough to catch the latest turn
    // in every active connector chat — the bulk query is the expensive
    // part, so we fetch once and reduce.
    const memories = await runtime.getMemoriesByRoomIds({
        tableName: "messages",
        roomIds,
        limit: 2000,
    });
    // Reduce: per room, keep the most recent source-tagged message.
    const accumulator = new Map();
    const roomSourceById = new Map();
    for (const [knownRoomId, room] of roomById) {
        const roomSource = readRoomSource(room);
        if (!roomSource || !sourceFilter.has(roomSource.toLowerCase()))
            continue;
        roomSourceById.set(knownRoomId, roomSource);
    }
    for (const memory of memories) {
        const source = extractSource(memory);
        if (!source || !sourceFilter.has(source.toLowerCase()))
            continue;
        const key = memory.roomId;
        if (!key || roomSourceById.has(key))
            continue;
        roomSourceById.set(key, source);
    }
    for (const memory of memories) {
        const key = memory.roomId;
        if (!key)
            continue;
        if (extractDiscordReactionEvent(memory)) {
            continue;
        }
        const room = roomById.get(key);
        const source = extractSource(memory) ??
            roomSourceById.get(key) ??
            readRoomSource(room) ??
            undefined;
        if (!source || !sourceFilter.has(source.toLowerCase()))
            continue;
        applyInboxChatMemory(accumulator, memory, room, source);
    }
    const backfilledRooms = await Promise.all(Array.from(roomById.entries())
        .filter(([roomIdKey]) => !accumulator.has(roomIdKey))
        .filter(([, room]) => {
        const roomSource = readRoomSource(room);
        return !!roomSource && sourceFilter.has(roomSource.toLowerCase());
    })
        .map(async ([roomIdKey, room]) => {
        const latestMemory = await loadLatestRoomMemory(runtime, roomIdKey);
        return { latestMemory, room, roomIdKey };
    }));
    for (const { latestMemory, room, roomIdKey } of backfilledRooms) {
        if (latestMemory) {
            const source = extractSource(latestMemory) ?? readRoomSource(room) ?? undefined;
            if (source && sourceFilter.has(source.toLowerCase())) {
                applyInboxChatMemory(accumulator, latestMemory, room, source);
            }
            continue;
        }
        const roomSource = readRoomSource(room);
        if (!roomSource || !sourceFilter.has(roomSource.toLowerCase())) {
            continue;
        }
        accumulator.set(roomIdKey, {
            latestDiscordChannelId: readRoomChannelId(room),
            source: roomSource,
            lastMessageText: "",
            lastMessageAt: readRoomCreatedAt(room) ?? 0,
            messageCount: 0,
        });
    }
    const chats = [];
    for (const [roomIdKey, entry] of accumulator) {
        const room = roomById.get(roomIdKey);
        const worldId = readRoomWorldId(room);
        const world = worldId ? worldsById.get(worldId) : undefined;
        const muteState = await resolveInboxRoomMuteState(runtime, room, roomIdKey);
        const liveDiscordProfile = isDiscordConnectorSource(entry.source)
            ? await resolveDiscordRoomProfile(runtime, room, entry.latestDiscordChannelId)
            : null;
        const latestSenderEntityProfile = isDiscordConnectorSource(entry.source)
            ? await resolveStoredDiscordEntityProfile(runtime, entry.latestSenderEntityId)
            : null;
        const latestMessageAuthorProfile = isDiscordConnectorSource(entry.source) &&
            entry.latestDiscordChannelId &&
            entry.latestDiscordMessageId
            ? await resolveDiscordMessageAuthorProfile(runtime, entry.latestDiscordChannelId, entry.latestDiscordMessageId)
            : null;
        const latestSenderProfile = isDiscordConnectorSource(entry.source) &&
            (entry.latestSenderRawId ??
                latestSenderEntityProfile?.rawUserId ??
                latestMessageAuthorProfile?.rawUserId)
            ? await resolveDiscordUserProfile(runtime, (entry.latestSenderRawId ??
                latestSenderEntityProfile?.rawUserId ??
                latestMessageAuthorProfile?.rawUserId))
            : null;
        const rawStoredTitle = normalizeRoomTitle(room?.name);
        const roomType = readRoomType(room);
        const storedTitle = roomType !== "DM" &&
            (isPlaceholderConversationTitle(rawStoredTitle) ||
                equalsNormalizedTitle(rawStoredTitle, entry.latestSenderName ?? null) ||
                equalsNormalizedTitle(rawStoredTitle, latestSenderEntityProfile?.displayName ?? null) ||
                equalsNormalizedTitle(rawStoredTitle, latestMessageAuthorProfile?.displayName ?? null) ||
                equalsNormalizedTitle(rawStoredTitle, latestSenderProfile?.displayName ?? null) ||
                equalsNormalizedTitle(rawStoredTitle, latestSenderEntityProfile?.username ?? null) ||
                equalsNormalizedTitle(rawStoredTitle, latestMessageAuthorProfile?.username ?? null) ||
                equalsNormalizedTitle(rawStoredTitle, latestSenderProfile?.username ?? null))
            ? null
            : rawStoredTitle;
        const dmFallbackTitle = roomType === "DM" &&
            (entry.latestSenderName ??
                latestSenderEntityProfile?.displayName ??
                latestMessageAuthorProfile?.displayName ??
                latestSenderProfile?.displayName)
            ? (entry.latestSenderName ??
                latestSenderEntityProfile?.displayName ??
                latestMessageAuthorProfile?.displayName ??
                latestSenderProfile?.displayName ??
                null)
            : null;
        const title = liveDiscordProfile?.title ??
            storedTitle ??
            dmFallbackTitle ??
            `${entry.source} chat`;
        const titleMatchesLatestSender = typeof entry.latestSenderName === "string" &&
            entry.latestSenderName.trim().length > 0 &&
            entry.latestSenderName.trim().toLowerCase() === title.toLowerCase();
        const shouldUsePersonAvatar = isDiscordConnectorSource(entry.source)
            ? true
            : roomType === "DM" || titleMatchesLatestSender;
        const resolvedAvatarUrl = shouldUsePersonAvatar
            ? (liveDiscordProfile?.avatarUrl ??
                latestSenderEntityProfile?.avatarUrl ??
                latestMessageAuthorProfile?.avatarUrl ??
                latestSenderProfile?.avatarUrl ??
                entry.latestSenderAvatarUrl)
            : undefined;
        chats.push({
            canSend: runtimeHasAnySendHandler(runtime, entry.source),
            id: roomIdKey,
            source: normalizeConnectorSource(entry.source),
            transportSource: entry.source,
            ...(worldId ? { worldId } : {}),
            worldLabel: resolveInboxWorldLabel(room, world),
            ...(roomType ? { roomType } : {}),
            ...muteState,
            title,
            avatarUrl: isDiscordConnectorSource(entry.source)
                ? await cacheInboxDiscordAvatar(runtime, resolvedAvatarUrl, entry.latestSenderRawId ??
                    latestSenderEntityProfile?.rawUserId ??
                    latestMessageAuthorProfile?.rawUserId)
                : resolvedAvatarUrl,
            lastMessageText: entry.lastMessageText,
            lastMessageAt: entry.lastMessageAt,
            messageCount: entry.messageCount,
        });
    }
    chats.sort((a, b) => {
        const bLast = typeof b.lastMessageAt === "number" && Number.isFinite(b.lastMessageAt)
            ? b.lastMessageAt
            : 0;
        const aLast = typeof a.lastMessageAt === "number" && Number.isFinite(a.lastMessageAt)
            ? a.lastMessageAt
            : 0;
        return bLast - aLast || a.id.localeCompare(b.id);
    });
    return chats;
}
/**
 * Scan recent memories across all agent rooms and return the distinct
 * set of source tags present. Used by the UI to build the filter chip
 * list dynamically — no hardcoded connector names in the frontend.
 */
async function loadInboxSources(runtime) {
    const roomIds = await collectAgentRoomIds(runtime);
    if (roomIds.length === 0)
        return [];
    // Sample a bounded page so this stays cheap. 1000 messages is enough
    // to catch every source an active agent uses day-to-day.
    const memories = await runtime.getMemoriesByRoomIds({
        tableName: "messages",
        roomIds,
        limit: 1000,
    });
    const seen = new Set();
    for (const memory of memories) {
        const source = extractSource(memory);
        if (!source)
            continue;
        // We only care about inbox sources — skip client_chat / api / etc.
        if (!DEFAULT_INBOX_SOURCES.has(source.toLowerCase()))
            continue;
        const normalizedSource = normalizeConnectorSource(source);
        if (!normalizedSource)
            continue;
        seen.add(normalizedSource);
    }
    return Array.from(seen).sort();
}
/**
 * Route handler entry point. Returns `true` when a route matched and
 * the response has been written; `false` so the caller can continue
 * trying other handlers. Mirrors the handleIMessageRoute pattern.
 */
export async function handleInboxRoute(req, res, pathname, method, state, helpers) {
    if (!pathname.startsWith("/api/inbox"))
        return false;
    // ── GET /api/inbox/messages ───────────────────────────────────────
    if (method === "GET" && pathname === "/api/inbox/messages") {
        const url = new URL(req.url ?? pathname, "http://localhost");
        const limit = parseLimit(url.searchParams.get("limit"));
        if (limit === null) {
            helpers.error(res, "limit must be a positive integer", 400);
            return true;
        }
        const explicitFilter = parseSourceFilter(url.searchParams.get("sources"));
        const sourceFilter = explicitFilter ?? DEFAULT_INBOX_SOURCES;
        // Optional roomId scope. When the messages view has a
        // specific connector chat selected, it passes the roomId so the
        // aggregator can skip cross-room enumeration and return just that
        // room's messages. Validated as non-empty; the runtime accepts
        // UUIDs but won't error on arbitrary strings, so we keep parsing
        // forgiving here and let runtime.getMemoriesByRoomIds return empty
        // for bad ids.
        const roomIdParam = url.searchParams.get("roomId")?.trim() ?? "";
        const roomId = roomIdParam.length > 0 ? roomIdParam : null;
        const roomSourceParam = url.searchParams.get("roomSource")?.trim() ?? "";
        const roomSourceHint = roomSourceParam.length > 0 ? roomSourceParam : null;
        const runtime = state.runtime;
        if (!runtime) {
            helpers.error(res, "runtime not ready", 503);
            return true;
        }
        try {
            const messages = await loadInboxMessages(runtime, limit, sourceFilter, roomId, roomSourceHint);
            helpers.json(res, { messages, count: messages.length });
        }
        catch (err) {
            helpers.error(res, `failed to load inbox: ${err instanceof Error ? err.message : String(err)}`, 500);
        }
        return true;
    }
    // ── POST /api/inbox/messages ──────────────────────────────────────
    if (method === "POST" && pathname === "/api/inbox/messages") {
        const runtime = state.runtime;
        if (!runtime) {
            helpers.error(res, "runtime not ready", 503);
            return true;
        }
        const callerAuthorization = state.callerAuthorization;
        if (!callerAuthorization?.ok ||
            roleRank(callerAuthorization.role) < roleRank("USER")) {
            runtime.logger.warn({
                src: "inbox-routes",
                role: callerAuthorization?.role ?? "NONE",
            }, "[InboxRoutes] unauthorised connector send rejected");
            helpers.json(res, {
                error: "Authenticated caller is not allowed to send connector messages",
                code: "INBOX_CALLER_UNAUTHORIZED",
            }, 403);
            return true;
        }
        const rawBody = await helpers.readJsonBody(req, res, { maxBytes: 256 * 1024 });
        if (rawBody === null) {
            return true;
        }
        const parsed = PostInboxMessageRequestSchema.safeParse(rawBody);
        if (!parsed.success) {
            const issue = parsed.error.issues[0];
            const issuePath = issue?.path.join(".");
            helpers.error(res, `Invalid request body at ${issuePath}: ${issue?.message}`, 400);
            return true;
        }
        const { accountId, roomId, source, text, replyToMessageId } = parsed.data;
        const room = await runtime.getRoom(roomId);
        if (!room) {
            helpers.error(res, "inbox room not found", 404);
            return true;
        }
        const trustedRoomSource = await resolveTrustedRoomSource(runtime, room);
        if (!trustedRoomSource ||
            !connectorSourcesMatch(source, trustedRoomSource)) {
            runtime.logger.warn({
                src: "inbox-routes",
                requestedSource: source,
                roomId,
                roomSource: trustedRoomSource,
            }, "[InboxRoutes] room source validation rejected");
            helpers.json(res, {
                error: trustedRoomSource
                    ? `Inbox room belongs to ${trustedRoomSource}, not ${source}`
                    : "Inbox room has no trusted connector source",
                code: "INBOX_ROOM_SOURCE_MISMATCH",
                context: {
                    requestedSource: source,
                    roomId,
                    roomSource: trustedRoomSource,
                },
            }, 409);
            return true;
        }
        // The server threads its already-resolved caller authority into this
        // handler. This boundary authorizes the narrow top-level selector against
        // server-owned room/account records; client-controlled Content.metadata is
        // never promoted into connector routing state.
        // A reply goes out from the account the room belongs to, so the contact
        // sees the same identity they wrote to. Managed rooms retain their binding
        // after account removal; only legacy unscoped sources use source routing.
        let accountRouting;
        try {
            const roomAccountId = await resolveRoomAccountId(runtime, source, readRoomConnectorAccountId(room, trustedRoomSource));
            if (accountId && roomAccountId && accountId !== roomAccountId) {
                helpers.json(res, {
                    error: `This conversation belongs to connector account ${roomAccountId}. Select that account to reply.`,
                    code: "INBOX_CONNECTOR_ACCOUNT_ROOM_MISMATCH",
                    context: { accountId, roomAccountId, roomId, source },
                }, 409);
                return true;
            }
            accountRouting = await resolveInboxAccountRouting(runtime, source, callerAuthorization, accountId ?? roomAccountId);
        }
        catch (error) {
            // error-policy:J1 HTTP route boundary translates account-registry failures
            // into an observable failure instead of dispatching with an unverified id.
            runtime.logger.error({
                src: "inbox-routes",
                accountId,
                source,
                err: error instanceof Error ? error.message : String(error),
            }, "[InboxRoutes] connector account lookup failed");
            helpers.json(res, {
                error: "Connector account validation failed",
                code: "INBOX_CONNECTOR_ACCOUNT_LOOKUP_FAILED",
                context: { accountId, source },
            }, 500);
            return true;
        }
        if (!accountRouting.ok) {
            runtime.logger.warn({
                src: "inbox-routes",
                code: accountRouting.code,
                ...accountRouting.context,
            }, "[InboxRoutes] connector account routing rejected");
            helpers.json(res, {
                error: accountRouting.error,
                code: accountRouting.code,
                context: accountRouting.context,
            }, accountRouting.status);
            return true;
        }
        runtime.logger.info({
            src: "inbox-routes",
            accountId: accountRouting.accountId,
            mode: accountRouting.mode,
            source,
        }, "[InboxRoutes] connector account routing validated");
        if (!runtimeHasSendHandler(runtime, source, accountRouting.accountId)) {
            helpers.error(res, accountRouting.accountId
                ? `no send handler registered for inbox source: ${source} accountId: ${accountRouting.accountId}`
                : `no send handler registered for inbox source: ${source}`, 409);
            return true;
        }
        try {
            const delivery = requireConfirmedSendHandlerDelivery(await runtime.sendMessageToTarget({
                ...(accountRouting.accountId
                    ? { accountId: accountRouting.accountId }
                    : {}),
                source,
                roomId: room.id,
                channelId: room.channelId ?? room.id,
                serverId: room.serverId,
            }, {
                ...(replyToMessageId ? { inReplyTo: replyToMessageId } : {}),
                source,
                text,
                // voice-policy:V2 this is the owner's own manually-typed inbox reply —
                // it is a real person's words, so the voice gate must pass it through
                // verbatim and never rephrase it.
                agentVoiced: true,
            }));
            // Connectors such as iMessage and Slack only report the provider
            // receipt and leave the outbound memory to the caller. Without it the
            // reply is missing from the thread and from the agent's history.
            const receipt = delivery.receipt;
            if (receipt?.persistence.status === "not_attempted") {
                const providerMessageId = receipt.evidenceKind === "local-effect"
                    ? undefined
                    : delivery.providerMessageId;
                const saved = await runtime
                    .createMemory({
                    id: createUniqueUuid(runtime, `${source}:inbox-reply:${receipt.providerMessageIds.join(",")}`),
                    entityId: runtime.agentId,
                    agentId: runtime.agentId,
                    roomId: room.id,
                    content: {
                        text,
                        source,
                        ...(replyToMessageId ? { inReplyTo: replyToMessageId } : {}),
                    },
                    metadata: {
                        type: "message",
                        source,
                        provider: source,
                        evidenceKind: receipt.evidenceKind ?? "provider",
                        ...(receipt.evidenceKind === "local-effect"
                            ? { localEffectIds: receipt.providerMessageIds }
                            : { providerMessageIds: receipt.providerMessageIds }),
                        ...(providerMessageId
                            ? { messageIdFull: providerMessageId }
                            : {}),
                    },
                    createdAt: receipt.acceptedAt,
                }, "messages")
                    .then(() => true, (err) => {
                    // error-policy:J1 the provider already accepted the reply, so a
                    // local write failure must not read as a failed send.
                    runtime.reportError("inbox-reply-persistence", err, {
                        source,
                        roomId: room.id,
                    });
                    return false;
                });
                if (!saved) {
                    helpers.json(res, {
                        ok: false,
                        delivered: true,
                        code: "INBOX_REPLY_NOT_SAVED",
                        error: "The reply was sent but could not be saved. Do not send it again.",
                    }, 500);
                    return true;
                }
            }
            const [message] = await loadInboxMessages(runtime, 1, new Set([source]), room.id, source);
            helpers.json(res, message ? { ok: true, message } : { ok: true });
        }
        catch (err) {
            // error-policy:J1 HTTP route boundary returns a structured 500 when the
            // connector throws or cannot prove provider acceptance.
            helpers.error(res, `failed to send inbox reply: ${err instanceof Error ? err.message : String(err)}`, 500);
        }
        return true;
    }
    // ── POST /api/inbox/chats/mute ───────────────────────────────────
    // Direct UI affordance for the same room/server mute state the ROOM
    // action writes. Keeps the sidebar toggle deterministic instead of
    // sending synthetic chat prompts through the planner.
    if (method === "POST" && pathname === "/api/inbox/chats/mute") {
        const runtime = state.runtime;
        if (!runtime) {
            helpers.error(res, "runtime not ready", 503);
            return true;
        }
        const rawBody = await helpers.readJsonBody(req, res, { maxBytes: 16 * 1024 });
        if (rawBody === null) {
            return true;
        }
        const parsed = PostInboxChatMuteRequestSchema.safeParse(rawBody);
        if (!parsed.success) {
            const issue = parsed.error.issues[0];
            const issuePath = issue?.path.join(".");
            helpers.error(res, `Invalid request body at ${issuePath}: ${issue?.message}`, 400);
            return true;
        }
        const { action, durationMinutes, roomId, scope } = parsed.data;
        const targetRoomId = roomId;
        const room = await runtime.getRoom(targetRoomId);
        if (!room) {
            helpers.error(res, "inbox room not found", 404);
            return true;
        }
        try {
            if (scope === "server") {
                const worldId = readRoomWorldId(room);
                if (!worldId) {
                    helpers.error(res, "inbox room has no server/world", 400);
                    return true;
                }
                const untilIso = muteUntilIsoFromDuration(durationMinutes);
                await setWorldMuteState(runtime, worldId, action === "mute" ? { ...(untilIso ? { untilIso } : {}) } : null);
            }
            else {
                await runtime.updateParticipantUserState(targetRoomId, runtime.agentId, action === "mute" ? "MUTED" : null);
                await setRoomMuteUntil(runtime, targetRoomId, action === "mute"
                    ? (muteUntilIsoFromDuration(durationMinutes) ?? null)
                    : null);
            }
            const latestRoom = (await runtime.getRoom(targetRoomId)) ?? room;
            const muteState = await resolveInboxRoomMuteState(runtime, latestRoom, targetRoomId);
            helpers.json(res, {
                ok: true,
                roomId: targetRoomId,
                scope,
                action,
                ...muteState,
            });
        }
        catch (err) {
            helpers.error(res, `failed to update inbox mute state: ${err instanceof Error ? err.message : String(err)}`, 500);
        }
        return true;
    }
    // ── GET /api/inbox/chats ──────────────────────────────────────────
    // List of connector chat threads (one row per external chat room)
    // used by the messages sidebar. Each row carries the source
    // tag, a display title, last-message preview + timestamp, and a
    // message count. Dashboard conversations aren't included here — the
    // frontend merges this list with /api/conversations on its own.
    if (method === "GET" && pathname === "/api/inbox/chats") {
        const runtime = state.runtime;
        if (!runtime) {
            helpers.error(res, "runtime not ready", 503);
            return true;
        }
        const url = new URL(req.url ?? pathname, "http://localhost");
        const explicitFilter = parseSourceFilter(url.searchParams.get("sources"));
        const sourceFilter = explicitFilter ?? DEFAULT_INBOX_SOURCES;
        try {
            const chats = await loadInboxChats(runtime, sourceFilter);
            helpers.json(res, { chats, count: chats.length });
        }
        catch (err) {
            helpers.error(res, `failed to load inbox chats: ${err instanceof Error ? err.message : String(err)}`, 500);
        }
        return true;
    }
    // ── GET /api/inbox/sources ────────────────────────────────────────
    if (method === "GET" && pathname === "/api/inbox/sources") {
        const runtime = state.runtime;
        if (!runtime) {
            helpers.error(res, "runtime not ready", 503);
            return true;
        }
        try {
            const sources = await loadInboxSources(runtime);
            helpers.json(res, { sources });
        }
        catch (err) {
            helpers.error(res, `failed to load inbox sources: ${err instanceof Error ? err.message : String(err)}`, 500);
        }
        return true;
    }
    return false;
}
