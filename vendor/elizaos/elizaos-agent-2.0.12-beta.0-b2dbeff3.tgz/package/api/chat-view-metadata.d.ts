/**
 * Resolve renderer chat metadata against the authoritative runtime view
 * registry. The renderer supplies the visible path; the server supplies the
 * exact view id, declared agent capabilities, and relevant runtime actions.
 * This keeps typed chat and voice-transcription turns on the same contract
 * without teaching either transport about individual plugins.
 */
import type { ViewRegistryEntry } from "./view-registry-types.js";
/**
 * Resolve the most-specific GUI view for renderer metadata. Path wins over the
 * renderer's view id because older clients intentionally report broad ids such
 * as "system" or "apps" for several distinct fullscreen views.
 */
export declare function resolveChatMetadataView(metadata: Record<string, unknown>, views: readonly ViewRegistryEntry[]): ViewRegistryEntry | null;
/**
 * Add registry-owned view facts to renderer metadata. Unknown paths and
 * non-renderer API turns are preserved unchanged. These fields affect planner
 * relevance only; normal role, context, policy, validation, and execution
 * gates remain authoritative.
 */
export declare function enrichChatUiViewMetadata(metadata: Record<string, unknown> | undefined, views: readonly ViewRegistryEntry[]): Record<string, unknown> | undefined;
