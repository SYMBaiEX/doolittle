export function routeNeedsX402Validation(route) {
    return route.x402 != null;
}
export function runtimeRoutesNeedX402Validation(routes) {
    return Array.isArray(routes) && routes.some(routeNeedsX402Validation);
}
