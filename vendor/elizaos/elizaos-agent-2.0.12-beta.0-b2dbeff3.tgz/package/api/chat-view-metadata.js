/**
 * Resolve renderer chat metadata against the authoritative runtime view
 * registry. The renderer supplies the visible path; the server supplies the
 * exact view id, declared agent capabilities, and relevant runtime actions.
 * This keeps typed chat and voice-transcription turns on the same contract
 * without teaching either transport about individual plugins.
 */
function asString(value) {
    if (typeof value !== "string")
        return null;
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : null;
}
function uniqueStrings(values) {
    const seen = new Set();
    const result = [];
    for (const value of values) {
        const normalized = value.trim();
        if (!normalized)
            continue;
        const key = normalized.toLowerCase();
        if (seen.has(key))
            continue;
        seen.add(key);
        result.push(normalized);
    }
    return result;
}
function normalizeViewPath(value) {
    const path = asString(value);
    if (!path)
        return null;
    const withoutQuery = path.split(/[?#]/, 1)[0] ?? "";
    if (!withoutQuery)
        return null;
    const rooted = withoutQuery.startsWith("/")
        ? withoutQuery
        : `/${withoutQuery}`;
    return rooted.length > 1 && rooted.endsWith("/")
        ? rooted.slice(0, -1)
        : rooted;
}
function viewPathMatches(candidatePath, registeredPath) {
    return (candidatePath === registeredPath ||
        (registeredPath !== "/" && candidatePath.startsWith(`${registeredPath}/`)));
}
/**
 * Resolve the most-specific GUI view for renderer metadata. Path wins over the
 * renderer's view id because older clients intentionally report broad ids such
 * as "system" or "apps" for several distinct fullscreen views.
 */
export function resolveChatMetadataView(metadata, views) {
    // Client-owned counterparts retain registry facts without a hosted web bundle.
    // This chooses the delivery surface; action and renderer authorization remain separate.
    const completedAction = metadata.viewDelivery === "completed-action";
    const candidatePath = normalizeViewPath(metadata.uiViewPath);
    if (candidatePath) {
        const byPath = views
            .filter((view) => view.available !== false || completedAction)
            .flatMap((view) => {
            const registeredPath = normalizeViewPath(view.path);
            return registeredPath && viewPathMatches(candidatePath, registeredPath)
                ? [{ view, registeredPath }]
                : [];
        })
            .sort((a, b) => b.registeredPath.length - a.registeredPath.length)[0];
        if (byPath)
            return byPath.view;
    }
    const candidateId = asString(metadata.uiView);
    if (!candidateId)
        return null;
    return (views.find((view) => view.id === candidateId &&
        (view.available !== false || completedAction)) ?? null);
}
/**
 * Add registry-owned view facts to renderer metadata. Unknown paths and
 * non-renderer API turns are preserved unchanged. These fields affect planner
 * relevance only; normal role, context, policy, validation, and execution
 * gates remain authoritative.
 */
export function enrichChatUiViewMetadata(metadata, views) {
    if (!metadata)
        return undefined;
    const { uiViewActionNames: _callerActionNames, ...metadataWithoutActionNames } = metadata;
    if (!asString(metadata.uiView) &&
        !asString(metadata.uiViewPath) &&
        !Array.isArray(metadata.uiViewCapabilities)) {
        return _callerActionNames === undefined
            ? metadata
            : metadataWithoutActionNames;
    }
    const view = resolveChatMetadataView(metadata, views);
    if (!view) {
        const { uiView: _callerView, uiViewPath: _callerViewPath, uiViewCapabilities: _callerCapabilities, __responseContext: _callerResponseContext, ...unresolvedMetadata } = metadataWithoutActionNames;
        return unresolvedMetadata;
    }
    const declaredCapabilities = uniqueStrings((view.capabilities ?? [])
        .filter((capability) => capability.authority !== "human")
        .map((capability) => capability.id));
    const viewActionNames = uniqueStrings([
        ...(view.relatedActions ?? []),
        ...(view.scopedActions ?? []).map((action) => action.name),
    ]);
    const declaredResponseContext = view.responseContext
        ? {
            primaryContext: view.responseContext.primaryContext,
            secondaryContexts: uniqueStrings(view.responseContext.secondaryContexts ?? []),
        }
        : undefined;
    const { __responseContext: _callerResponseContext, ...metadataWithoutResponseContext } = metadataWithoutActionNames;
    return {
        ...metadataWithoutResponseContext,
        uiView: view.id,
        uiViewPath: normalizeViewPath(metadata.uiViewPath) ?? view.path ?? undefined,
        // A resolved registry view is authoritative even when it declares zero
        // capabilities. Falling back to renderer hints lets stale or invented
        // names become planner facts for actions the server cannot execute.
        uiViewCapabilities: declaredCapabilities,
        uiViewActionNames: viewActionNames,
        ...(declaredResponseContext
            ? { __responseContext: declaredResponseContext }
            : {}),
    };
}
