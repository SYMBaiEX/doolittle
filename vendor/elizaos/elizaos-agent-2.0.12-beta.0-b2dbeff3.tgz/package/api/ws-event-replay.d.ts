/**
 * Pure helpers for the WebSocket event-buffer replay on (re)connect.
 *
 * See loadperf research report 05 (Network & Data Sync),
 * Finding 4: on every (re)connect the server replays the tail of
 * `state.eventBuffer`, re-flooding the client with up to `DEFAULT_REPLAY_LIMIT`
 * historical envelopes even after a brief reconnect. A client that tracks the
 * highest event sequence it has applied can pass it back as a cursor so the
 * server replays only the envelopes the client is actually missing.
 *
 * @module
 */
/**
 * Maximum number of buffered envelopes replayed when the client provides no
 * (or an invalid) cursor. This is the historical, backward-compatible default:
 * a fresh connection with no cursor receives `buffer.slice(-DEFAULT_REPLAY_LIMIT)`.
 */
export declare const DEFAULT_REPLAY_LIMIT = 120;
/**
 * Minimal shape the replay logic needs from a buffered event envelope. The real
 * envelope (`StreamEventEnvelope` from `@elizaos/core`) carries more fields;
 * the cursor only cares about the monotonic sequence, which is the integer
 * portion of `eventId` (`evt-<n>`) and is mirrored on `bufferSeq` for envelopes
 * pushed through the primary `pushEvent` path.
 */
export interface ReplayableEvent {
    eventId: string;
    bufferSeq?: number;
}
/**
 * Resolve the monotonic sequence of a buffered envelope.
 *
 * Prefers the explicit numeric `bufferSeq` (stamped by `pushEvent`); falls back
 * to parsing the trailing integer of `eventId` (`evt-<n>`) so envelopes pushed
 * by other code paths (e.g. the `/api/agent-event` REST mirror) still sort and
 * filter correctly. Returns `null` when no sequence can be derived.
 */
export declare function eventSequence(event: ReplayableEvent): number | null;
/**
 * Parse a client-supplied reconnect cursor (the `lastEventId` WS query param).
 *
 * Accepts either a bare integer (`"42"`) or the full envelope id (`"evt-42"`),
 * since a client may track whichever form it received. Returns the numeric
 * sequence the client has already applied, or `null` when the cursor is absent
 * or not a valid non-negative integer — in which case the caller falls back to
 * the default tail replay (backward-compatible: no cursor => prior behavior).
 */
export declare function parseEventCursor(raw: string | null | undefined): number | null;
/**
 * One page of a cursor-paginated replay.
 *
 * The caller advances its cursor to `nextCursor` and requests the next page
 * while `hasMore` is true. With no cursor (`null`) the caller receives a
 * single tail page and `hasMore` is always false — that path preserves the
 * historical one-shot replay for clients that do not track a cursor.
 */
export interface ReplayPage<T> {
    /** The envelopes to send for this page, in buffer order. */
    events: T[];
    /**
     * True only when a valid cursor was supplied and more missing envelopes
     * remain beyond this page. Always false for `cursor === null`.
     */
    hasMore: boolean;
    /**
     * The sequence of the last envelope in `events` — the cursor to resume
     * from for the next page. `null` when `events` is empty.
     */
    nextCursor: number | null;
}
/**
 * Select the envelopes to replay to a (re)connecting client.
 *
 * - With a valid `cursor`, returns the envelopes whose sequence is strictly
 *   greater than the cursor (the events the client is missing), oldest first,
 *   capped to `limit`. Oldest-first matters: the client resumes from its
 *   cursor, so each page must continue where the previous one left off. The
 *   caller loops on `hasMore`/`nextCursor` until the backlog is drained, so a
 *   stale cursor can never silently skip the events between `cursor + 1` and
 *   a truncated page — that is the cursor-recovery contract.
 * - With `cursor === null` (absent/invalid), returns `buffer.slice(-limit)` —
 *   the exact historical behavior, so clients that send no cursor are
 *   unaffected. No pagination is offered on this path (`hasMore: false`).
 *
 * Does not mutate the input buffer and does not reorder events.
 */
export declare function selectReplayEvents<T extends ReplayableEvent>(buffer: readonly T[], cursor: number | null, limit?: number): ReplayPage<T>;
