/**
 * Dispatches elizaOS AgentRuntime plugin routes (runtime.routes) on the Eliza
 * raw Node HTTP server. Core registers paths like `/music-player/stream`; without
 * this bridge those handlers never run.
 */
import { isJsonObjectBody, readRequestBodyBuffer, writeJsonError, } from "@elizaos/host";
import { assertPublicRouteIntent, getHttpRuntime, setRuntimeRouteHostContext, } from "@elizaos/host/protocol";
import { matchPluginRoutePath } from "./plugin-route-path.js";
import { loadX402PaymentModule, X402_ENFORCEMENT_UNAVAILABLE, } from "./x402-contract.js";
const EXPRESS_SHIM = Symbol("elizaExpressResponseShim");
export { matchPluginRoutePath } from "./plugin-route-path.js";
export function isPublicRuntimePluginRoute(options) {
    const { runtime, method, pathname } = options;
    if (!runtime || !getHttpRuntime(runtime).routes.length)
        return false;
    return getHttpRuntime(runtime).routes.some((route) => {
        assertPublicRouteIntent(route, "runtime.routes");
        if (route.type === "STATIC" ||
            route.type !== method ||
            route.public !== true) {
            return false;
        }
        return matchPluginRoutePath(route.path, pathname) !== null;
    });
}
function searchParamsToQuery(url) {
    const out = {};
    for (const key of url.searchParams.keys()) {
        const vals = url.searchParams.getAll(key);
        out[key] = vals.length <= 1 ? (vals[0] ?? "") : vals;
    }
    return out;
}
function attachExpressResponseHelpers(res) {
    const marked = res;
    if (marked[EXPRESS_SHIM])
        return;
    marked[EXPRESS_SHIM] = true;
    const r = res;
    if (typeof r.status !== "function") {
        r.status = (code) => {
            res.statusCode = code;
            return r;
        };
    }
    if (typeof r.json !== "function") {
        r.json = (data) => {
            if (res.headersSent)
                return r;
            res.setHeader("Content-Type", "application/json; charset=utf-8");
            res.end(JSON.stringify(data));
            return r;
        };
    }
    if (typeof r.send !== "function") {
        r.send = (data) => {
            if (res.headersSent)
                return r;
            if (typeof data === "string" || Buffer.isBuffer(data)) {
                res.end(data);
            }
            else {
                res.setHeader("Content-Type", "application/json; charset=utf-8");
                res.end(JSON.stringify(data));
            }
            return r;
        };
    }
}
function augmentRequest(req, url, params) {
    const query = searchParamsToQuery(url);
    const protoHeader = req.headers["x-forwarded-proto"];
    const proto = typeof protoHeader === "string"
        ? protoHeader.split(",")[0]?.trim() || "http"
        : "http";
    const base = req;
    base.query = query;
    base.params = params;
    base.protocol = proto;
    base.path = url.pathname;
    base.method = req.method ?? "GET";
    base.get = (name) => {
        const v = req.headers[name.toLowerCase()];
        return Array.isArray(v) ? v[0] : v;
    };
    return req;
}
function requestMayHaveJsonBody(req, method) {
    if (method === "GET" || method === "HEAD") {
        return false;
    }
    const contentType = req.headers["content-type"];
    const contentTypeText = Array.isArray(contentType)
        ? contentType.join(",")
        : (contentType ?? "");
    if (!contentTypeText.toLowerCase().includes("application/json")) {
        return false;
    }
    const contentLength = req.headers["content-length"];
    if (contentLength === "0") {
        return false;
    }
    return Boolean(contentLength || req.headers["transfer-encoding"]);
}
async function attachJsonBodyIfPresent(req, res, method, maxBodyBytes) {
    if (!requestMayHaveJsonBody(req, method)) {
        return true;
    }
    try {
        const buffer = await readRequestBodyBuffer(req, {
            ...(maxBodyBytes === undefined ? {} : { maxBytes: maxBodyBytes }),
            returnNullOnError: true,
            returnNullOnTooLarge: true,
            destroyOnTooLarge: true,
        });
        if (buffer === null) {
            await writeJsonError(res, "Failed to read request body", 400);
            return false;
        }
        const rawBody = buffer.toString("utf8");
        const augmented = req;
        augmented.rawBody = rawBody;
        const trimmed = rawBody.trim();
        if (!trimmed) {
            return true;
        }
        let parsed;
        try {
            parsed = JSON.parse(trimmed);
        }
        catch {
            await writeJsonError(res, "Invalid JSON body", 400);
            return false;
        }
        if (!isJsonObjectBody(parsed)) {
            await writeJsonError(res, "JSON body must be an object", 400);
            return false;
        }
        augmented.body = parsed;
        return true;
    }
    catch (error) {
        await writeJsonError(res, error instanceof Error ? error.message : "Failed to read request body", 400);
        return false;
    }
}
/**
 * Runs the first matching runtime plugin route. Returns true if matched (even on handler error).
 */
export async function tryHandleRuntimePluginRoute(options) {
    const { req, res, method, pathname, url, runtime, isAuthorized, hostContext, } = options;
    if (!runtime || !getHttpRuntime(runtime).routes.length)
        return false;
    for (const route of getHttpRuntime(runtime).routes) {
        assertPublicRouteIntent(route, "runtime.routes");
        if (route.type === "STATIC")
            continue;
        if (route.type !== method)
            continue;
        const handler = route.handler;
        if (!handler)
            continue;
        const params = matchPluginRoutePath(route.path, pathname);
        if (params === null)
            continue;
        if (route.public !== true && !isAuthorized()) {
            if (!res.headersSent) {
                res.statusCode = 401;
                res.setHeader("Content-Type", "application/json; charset=utf-8");
                res.end(JSON.stringify({ error: "Unauthorized" }));
            }
            return true;
        }
        attachExpressResponseHelpers(res);
        augmentRequest(req, url, params);
        if (!(await attachJsonBodyIfPresent(req, res, method, route.maxBodyBytes))) {
            return true;
        }
        let effectiveHandler = handler;
        if (route.x402 != null) {
            const x402 = await loadX402PaymentModule();
            if (!x402) {
                // A paid route is never served unpaid: refuse when the payment plugin
                // is absent (not installed, or the mobile null stub).
                res.statusCode = X402_ENFORCEMENT_UNAVAILABLE.status;
                res.setHeader("Content-Type", "application/json; charset=utf-8");
                res.end(JSON.stringify(X402_ENFORCEMENT_UNAVAILABLE.body));
                return true;
            }
            if (!x402.isRoutePaymentWrapped(route)) {
                effectiveHandler = x402.createPaymentAwareHandler(route);
            }
        }
        const restoreHostContext = hostContext
            ? setRuntimeRouteHostContext(runtime, hostContext)
            : undefined;
        try {
            await effectiveHandler(req, res, runtime);
        }
        catch (err) {
            if (!res.headersSent) {
                res.statusCode = 500;
                res.setHeader("Content-Type", "application/json; charset=utf-8");
                res.end(JSON.stringify({
                    error: err instanceof Error ? err.message : "Internal server error",
                }));
            }
            return true;
        }
        finally {
            restoreHostContext?.();
        }
        // Do not auto-end: handlers may return after attaching long-lived streams
        // (e.g. music-player) before headers or first bytes are flushed.
        return true;
    }
    return false;
}
