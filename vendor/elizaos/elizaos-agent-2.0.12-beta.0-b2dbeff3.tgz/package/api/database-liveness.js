import { sql } from "drizzle-orm";
const TERMINAL_PGLITE_PATTERNS = [
    /pglite is closed/i,
    /database is shutting down/i,
    /operation rejected/i,
    /cannot query.*closed/i,
    /closed database/i,
];
function describeProbeError(error) {
    if (error instanceof Error)
        return error.message;
    if (typeof error === "string")
        return error;
    try {
        return JSON.stringify(error);
    }
    catch {
        // error-policy:J3 diagnostic formatting fallback for non-serializable input
        return String(error);
    }
}
export function isTerminalDatabaseLivenessError(error) {
    const seen = new Set();
    let current = error;
    while (current && !seen.has(current)) {
        seen.add(current);
        const message = current instanceof Error
            ? current.message
            : typeof current === "string"
                ? current
                : "";
        if (TERMINAL_PGLITE_PATTERNS.some((pattern) => pattern.test(message))) {
            return true;
        }
        current =
            current instanceof Error
                ? current.cause
                : typeof current === "object" && current !== null && "cause" in current
                    ? current.cause
                    : null;
    }
    return false;
}
function asAdapter(runtime) {
    const adapter = runtime.adapter;
    if (!adapter || typeof adapter !== "object")
        return null;
    return adapter;
}
async function probeHandle(handle) {
    if (handle && typeof handle === "object") {
        const raw = handle;
        if (typeof raw.query === "function") {
            await raw.query("SELECT 1");
            return;
        }
        const executable = handle;
        if (typeof executable.execute === "function") {
            await executable.execute(sql `SELECT 1`);
            return;
        }
    }
    throw new Error("database connection does not expose query or execute");
}
async function runProbe(adapter) {
    if (typeof adapter.getRawConnection === "function") {
        await probeHandle(adapter.getRawConnection());
        return;
    }
    if (typeof adapter.getConnection === "function") {
        await probeHandle(await adapter.getConnection());
        return;
    }
    if (adapter.db) {
        await probeHandle(adapter.db);
        return;
    }
    if (typeof adapter.isReady === "function") {
        const ready = await adapter.isReady();
        if (ready)
            return;
        throw new Error("adapter.isReady() returned false");
    }
    throw new Error("database adapter exposes no liveness probe surface");
}
export async function probeRuntimeDatabaseLiveness(runtime) {
    if (!runtime) {
        return { status: "unknown", ok: false, terminal: false };
    }
    const adapter = asAdapter(runtime);
    if (!adapter) {
        return { status: "unknown", ok: true, terminal: false };
    }
    try {
        await runProbe(adapter);
        return { status: "ok", ok: true, terminal: false };
    }
    catch (error) {
        // error-policy:J4 health probe translates database failure into liveness state
        const terminal = isTerminalDatabaseLivenessError(error);
        return {
            status: terminal ? "terminal_error" : "transient_error",
            ok: false,
            terminal,
            message: describeProbeError(error),
        };
    }
}
