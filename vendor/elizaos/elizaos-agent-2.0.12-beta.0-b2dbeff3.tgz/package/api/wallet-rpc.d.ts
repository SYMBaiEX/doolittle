/**
 * Resolves the wallet's RPC endpoint set and provider selections across EVM, BSC,
 * and Solana. Chooses between Eliza Cloud's managed RPC proxy (keyed by the cloud
 * API key), operator-supplied custom endpoints, and public community fallbacks,
 * then reports per-chain readiness. Also applies wallet-config updates (provider
 * choices, network mode, credential env keys) back into ElizaConfig and
 * `process.env`. Pure resolution logic consumed by the wallet routes and services.
 */
import { type WalletConfigUpdateRequest, type WalletRpcChain, type WalletRpcCredentialKey, type WalletRpcSelections } from "@elizaos/contracts";
import { type ElizaConfig } from "@elizaos/host/protocol";
export declare const DEFAULT_PUBLIC_BSC_RPC_URLS: readonly ["https://bsc.publicnode.com/", "https://bsc-rpc.publicnode.com/", "https://binance.llamarpc.com/", "https://rpc.ankr.com/bsc", "https://bsc-dataseed.bnbchain.org/", "https://bsc-dataseed1.binance.org/", "https://bsc-dataseed2.binance.org/", "https://bsc-dataseed3.binance.org/"];
export declare const DEFAULT_PUBLIC_BSC_TESTNET_RPC_URLS: readonly ["https://bsc-testnet.publicnode.com/", "https://bsc-testnet-rpc.publicnode.com/", "https://data-seed-prebsc-1-s1.binance.org:8545/"];
export declare const DEFAULT_PUBLIC_ETHEREUM_RPC_URLS: readonly ["https://ethereum.publicnode.com/", "https://ethereum-rpc.publicnode.com/", "https://eth.llamarpc.com/", "https://rpc.ankr.com/eth"];
export declare const DEFAULT_PUBLIC_BASE_RPC_URLS: readonly ["https://base.publicnode.com/", "https://base-rpc.publicnode.com/", "https://base.llamarpc.com/", "https://mainnet.base.org/"];
export declare const DEFAULT_PUBLIC_AVALANCHE_RPC_URLS: readonly ["https://avalanche.publicnode.com/ext/bc/C/rpc", "https://avalanche-c-chain-rpc.publicnode.com/", "https://api.avax.network/ext/bc/C/rpc", "https://rpc.ankr.com/avalanche"];
export declare const DEFAULT_PUBLIC_SOLANA_RPC_URLS: readonly ["https://api.mainnet-beta.solana.com", "https://solana-rpc.publicnode.com"];
export declare const DEFAULT_PUBLIC_SOLANA_TESTNET_RPC_URLS: readonly ["https://api.devnet.solana.com"];
type WalletCapableConfig = Pick<ElizaConfig, "cloud" | "env"> & {
    wallet?: {
        rpcProviders?: Partial<Record<keyof WalletRpcSelections, string>>;
        network?: "mainnet" | "testnet";
    };
};
export interface InventoryProviderOption {
    id: WalletRpcChain;
    name: string;
    description: string;
    rpcProviders: Array<{
        id: string;
        name: string;
        description: string;
        envKey: WalletRpcCredentialKey | null;
        requiresKey: boolean;
    }>;
}
export interface WalletRpcResolutionOptions {
    cloudManagedAccess?: boolean | null;
    cloudApiKey?: string | null;
    cloudBaseUrl?: string | null;
    walletNetwork?: "mainnet" | "testnet" | null;
}
export interface WalletRpcReadiness {
    walletNetwork: "mainnet" | "testnet";
    cloudManagedAccess: boolean;
    managedBscRpcReady: boolean;
    evmBalanceReady: boolean;
    solanaBalanceReady: boolean;
    selectedRpcProviders: WalletRpcSelections;
    legacyCustomChains: WalletRpcChain[];
    bscRpcUrls: string[];
    ethereumRpcUrls: string[];
    baseRpcUrls: string[];
    avalancheRpcUrls: string[];
    solanaRpcUrls: string[];
}
type SupportedCloudEvmRpcChain = "mainnet" | "base" | "bsc" | "avalanche";
export declare function resolveWalletNetworkMode(config?: WalletCapableConfig | null, fallback?: string | null): "mainnet" | "testnet";
export declare function normalizeRpcUrl(url: string | null | undefined): string | null;
export declare function buildCloudEvmRpcUrl(chain: SupportedCloudEvmRpcChain, options?: WalletRpcResolutionOptions): string | null;
export declare function buildCloudSolanaRpcUrl(options?: WalletRpcResolutionOptions): string | null;
export declare function hasElizaCloudRpcAccess(config?: WalletCapableConfig | null): boolean;
export declare function getStoredWalletRpcSelections(config?: WalletCapableConfig | null): WalletRpcSelections;
export declare function getInventoryProviderOptions(): InventoryProviderOption[];
export declare function resolveBscRpcUrls(options?: WalletRpcResolutionOptions): string[];
export declare function resolveEthereumRpcUrls(options?: WalletRpcResolutionOptions): string[];
export declare function resolveBaseRpcUrls(options?: WalletRpcResolutionOptions): string[];
export declare function resolveAvalancheRpcUrls(options?: WalletRpcResolutionOptions): string[];
export declare function resolveSolanaRpcUrls(options?: WalletRpcResolutionOptions): string[];
export declare function applyWalletRpcConfigUpdate(config: WalletCapableConfig, update: WalletConfigUpdateRequest): void;
export declare function resolveWalletRpcReadiness(config?: WalletCapableConfig | null): WalletRpcReadiness;
export {};
