/**
 * Derives the human-facing model/provider label the API surface reports for a
 * runtime. detectRuntimeModel resolves in priority order: the character/settings
 * model, the configured service-routing transport (direct / remote /
 * cloud-proxy — but only when the cloud plugin actually registered its
 * chat-brain handler, so a cloud-proxy config without a signed-in account
 * falls through to the local-provider / plugin-name / env-signal path that
 * reflects the handler really serving requests, #20045), the config default
 * model, a loaded provider plugin name, then an env provider signal (API-key
 * or base-URL presence, including ELIZA_LOCAL_LLAMA on AOSP).
 * resolveProviderFromModel maps a model string to a provider display name.
 */
import { type AgentRuntime } from "@elizaos/core";
import { type ElizaConfig } from "@elizaos/host/protocol";
/**
 * The provider that served the most recent successful chat `useModel` call, or
 * undefined before any call has completed. This is evidence rather than
 * availability: a registered handler can still lose to an override or fail
 * over to another provider, so when core knows who actually answered, that
 * wins over every config- and registration-derived guess below.
 *
 * Fails closed to undefined — callers fall through to the configured route
 * rather than fabricating a provider.
 */
export declare function lastServingTextProvider(runtime: AgentRuntime): string | undefined;
/**
 * True when a chat-brain text handler is registered under the elizacloud
 * provider name. `detectRuntimeModel` uses this to decide whether the
 * `cloud-proxy` config branch should report `elizacloud` or fall through to
 * the local-provider / plugin-name / env-signal path that reflects the
 * handler actually serving requests.
 */
export declare function hasCloudTextHandlerRegistered(runtime: AgentRuntime): boolean;
export declare function detectRuntimeModel(runtime: AgentRuntime | null, config?: Pick<ElizaConfig, "deploymentTarget" | "serviceRouting" | "agents">): string | undefined;
export declare function resolveProviderFromModel(model: string): string | null;
