/**
 * Resolves and launches the npm-installed subscription CLIs across platforms.
 * Windows uses real executable boundaries for npm and PATHEXT-aware probes.
 */
export interface SubscriptionCliProcessOptions {
    env?: NodeJS.ProcessEnv;
    platform?: NodeJS.Platform;
}
export interface SubscriptionCliNpmInvocation {
    args: string[];
    command: string;
}
interface RunSubscriptionCliNpmOptions extends SubscriptionCliProcessOptions {
    execute?: (command: string, args: string[], options: {
        timeout: number;
    }) => Promise<unknown>;
    timeout: number;
}
/**
 * Resolve a CLI on PATH using the executable suffixes Windows actually runs.
 * npm writes device-login shims as `.cmd`, so treating the extensionless
 * companion file as executable would make the later child process fail.
 */
export declare function subscriptionCliCommandAvailable(command: string, options?: SubscriptionCliProcessOptions): boolean;
/**
 * Resolve npm without routing the user-controlled state-directory prefix
 * through a command shell. Standard Windows Node installations keep
 * `node.exe`, `npm.cmd`, and `node_modules/npm/bin/npm-cli.js` together; call
 * the JavaScript entrypoint through Node so spaces and shell metacharacters in
 * the prefix remain ordinary argv data.
 */
export declare function resolveSubscriptionCliNpmInvocation(args: string[], options?: SubscriptionCliProcessOptions): SubscriptionCliNpmInvocation;
export declare function runSubscriptionCliNpm(args: string[], options: RunSubscriptionCliNpmOptions): Promise<unknown>;
export {};
