/** Host credential/RPC composition for the wallet-owned read implementation. */
import { type EvmProviderKeys, type EvmProviderKeyset } from "@elizaos/plugin-wallet/read";
export { type AnkrTokenAsset, DEFAULT_EVM_CHAINS, type EvmBalanceChainConfig as EvmChainConfig, type EvmProviderKeys, fetchEvmNativeBalanceViaRpc, } from "@elizaos/plugin-wallet/read";
export declare function resolveEvmProviderKeys(alchemyOrKeys: string | EvmProviderKeys | null | undefined, maybeAnkrKey?: string | null): EvmProviderKeyset;
export declare function fetchEvmBalances(address: string, alchemyOrKeys: string | EvmProviderKeys | null | undefined, maybeAnkrKey?: string | null, knownTokenAddresses?: string[]): any;
export declare function fetchEvmNfts(address: string, alchemyOrKeys: string | EvmProviderKeys | null | undefined, maybeAnkrKey?: string | null): any;
