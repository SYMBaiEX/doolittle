/**
 * Semantic search index for the view registry.
 *
 * Stores embeddings for each registered view and supports cosine-similarity
 * ranking. Embeddings are computed lazily via `runtime.useModel(TEXT_EMBEDDING)`
 * so startup is never blocked.
 *
 * Usage:
 *   await getViewSearchIndex(runtime).indexView(entry);
 *   const results = await getViewSearchIndex(runtime).search(query, 10);
 */
import type { IAgentRuntime } from "@elizaos/core";
import type { ViewRegistryEntry } from "./view-registry-types.js";
export interface ViewSearchEntry {
    viewId: string;
    viewType: ViewRegistryEntry["viewType"];
    embedding: number[];
    /** The text that was embedded: label + description + tags joined. */
    text: string;
}
/** Build the text to embed for a view. */
export declare function buildViewEmbeddingText(view: ViewRegistryEntry): string;
declare class ViewSearchIndex {
    private readonly runtime;
    private readonly entries;
    constructor(runtime: IAgentRuntime);
    private key;
    /**
     * Compute and store an embedding for `view`.
     * Returns without indexing when the runtime has no embedding model configured.
     */
    indexView(view: ViewRegistryEntry): Promise<void>;
    /** Remove the index entry for `viewId`. */
    removeView(viewId: string, viewType?: ViewRegistryEntry["viewType"]): void;
    /**
     * Rank indexed views by semantic similarity to `query`.
     *
     * @param query   - The user's raw search query.
     * @param runtime - Agent runtime used to embed the query.
     * @param topK    - Maximum number of results to return (default 10).
     * @returns       Array of `{ viewId, score }` sorted descending by score,
     *                where score is cosine similarity in [0, 1].
     *                Returns an empty array when the runtime has no embedding
     *                model, or when `topK` is not a positive safe integer.
     */
    search(query: string, topK?: number): Promise<Array<{
        viewId: string;
        viewType: ViewRegistryEntry["viewType"];
        score: number;
    }>>;
    /** Remove all entries (e.g. between test runs). */
    clear(): void;
    /** Number of indexed views. */
    get size(): number;
}
export declare function getViewSearchIndex(runtime: IAgentRuntime): ViewSearchIndex;
export {};
