import { type AgentRuntime, type UUID } from "@elizaos/core";
import type { RouteRequestContext } from "@elizaos/host/protocol";
export declare const HASH_MEMORY_SOURCE = "hash_memory";
export declare const MEMORY_TABLE_NAMES: readonly ["messages", "memories", "facts", "documents"];
export interface MemoryRouteContext extends RouteRequestContext {
    url: URL;
    runtime: AgentRuntime | null;
    agentName: string;
}
/**
 * Rank a candidate set against `query` with Okapi BM25 + Porter2 stemming,
 * returning each item with a [0,1] max-normalized relevance score in input order.
 *
 * Corpus-aware IDF down-weights filler/stop words and TF saturation + length
 * normalization rank genuinely-relevant text first; a naive pairwise substring
 * count with no IDF would let a doc that merely contains a common query word
 * ("the") tie with a real hit. We use the `search.ts` BM25
 * (not the documents `bm25Scores`) specifically for its **Porter2 stemming** —
 * short typed chat queries are usually base forms ("configure") while stored
 * messages carry inflected forms ("configuring"/"configured"/"configuration"),
 * and stemming is the standard keyword answer to that mismatch. It also brings
 * stop-word removal and proper Unicode/accent/CJK normalization (the documents
 * tokenizer strips non-ASCII, silently dropping accented + non-Latin text).
 */
export declare function rankByKeyword<T>(query: string, items: T[], getText: (item: T) => string): Array<{
    item: T;
    score: number;
}>;
/**
 * Boolean keyword match for *filtering* (not ranking): does the text contain the
 * whole query or any query term (≥2 chars)? Used where the caller wants
 * "messages matching this text", not a relevance ranking.
 */
export declare function matchesKeyword(text: string, query: string): boolean;
export declare function invalidateMemorySearchCache(runtime?: AgentRuntime, roomId?: UUID): void;
/**
 * Parse the memory-viewer `type` query. Omitted/empty means every table
 * (the "all" tab). A known table name narrows the scan. Any other token
 * used to fall through to that same unfiltered scan, so `type=notes` or
 * `type=message` silently returned the whole feed.
 */
export declare function parseMemoryTableFilter(typeParam: string | null): {
    ok: true;
    tables?: readonly string[];
} | {
    ok: false;
    message: string;
};
export declare function handleMemoryRoutes(ctx: MemoryRouteContext): Promise<boolean>;
