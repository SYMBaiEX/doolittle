import type http from "node:http";
import { type IAgentRuntime } from "@elizaos/core";
import { type DeviceCredential } from "@elizaos/plugin-assistant";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
export declare function requiresDeviceIdentity(req: Pick<http.IncomingMessage, "headers">, pathname: string): boolean;
export declare function deviceRequestCredential(req: http.IncomingMessage, authorization?: AgentHttpRequestAuthorization): DeviceCredential | null;
interface RouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    runtime: IAgentRuntime | null;
    authorization?: AgentHttpRequestAuthorization;
    json(res: http.ServerResponse, value: unknown, status?: number): void;
    error(res: http.ServerResponse, message: string, status?: number): void;
    revalidateAuthorization?: () => Promise<AgentHttpRequestAuthorization>;
    assertRuntimeCurrent?: () => void;
    readJsonBody<T>(req: http.IncomingMessage, res: http.ServerResponse): Promise<T | null>;
}
export declare function handleDeviceActionRoutes(ctx: RouteContext): Promise<boolean>;
export {};
