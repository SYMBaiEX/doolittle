import { createIntegrationTelemetrySpan } from "@elizaos/core";
import { createDevCloudConfigAuthorityView, materializeDevCloudConfigAuthorityView, } from "../config/dev-cloud-env-authority.js";
import { handleApprovalRoute } from "./approval-routes.js";
import { handleChatRoutes } from "./chat-routes.js";
import { handleConversationRoutes } from "./conversation-routes.js";
import { handleDatabaseRoute } from "./database.js";
import { handleInboxRoute, } from "./inbox-routes.js";
import { handleNotificationRoute } from "./notification-routes.js";
import { handlePushTokenRoute } from "./push-token-routes.js";
import { tryHandleRuntimePluginRoute } from "./runtime-plugin-routes.js";
let computeUsePromise = null;
function getComputeUsePlugin() {
    computeUsePromise ??= import("@elizaos/plugin-computeruse");
    return computeUsePromise;
}
let cloudRoutesPromise = null;
function getCloudRoutesPlugin() {
    cloudRoutesPromise ??= import("@elizaos/plugin-elizacloud/host-routes");
    return cloudRoutesPromise;
}
export async function handleInboxAndCloudRelayRouteGroup({ req, res, method, pathname, state, json, error, readJsonBody, inboxCallerAuthorization, }) {
    // Push-token routes share the /api/notifications namespace but are owned by
    // the push delivery service, so they must be checked BEFORE the notification
    // catch-all (otherwise notification-routes' `:id` matchers would swallow
    // `/api/notifications/push-tokens/<token>`).
    if (pathname.startsWith("/api/notifications/push-tokens")) {
        return handlePushTokenRoute(req, res, pathname, method, { runtime: state.runtime ?? null }, { json, error, readJsonBody });
    }
    if (pathname.startsWith("/api/notifications")) {
        return handleNotificationRoute(req, res, pathname, method, { runtime: state.runtime ?? null }, { json, error, readJsonBody });
    }
    if (pathname.startsWith("/api/approvals")) {
        return handleApprovalRoute(req, res, pathname, method, { runtime: state.runtime ?? null }, { json, error, readJsonBody });
    }
    if (pathname.startsWith("/api/inbox")) {
        return handleInboxRoute(req, res, pathname, method, {
            runtime: state.runtime ?? null,
            callerAuthorization: inboxCallerAuthorization,
        }, { json, error, readJsonBody });
    }
    if (pathname === "/api/approvals") {
        return handleApprovalRoute(req, res, pathname, method, { runtime: state.runtime ?? null }, { json, error, readJsonBody });
    }
    if (pathname !== "/api/cloud/relay-status") {
        return false;
    }
    return (await getCloudRoutesPlugin()).handleCloudRelayRoute(req, res, pathname, method, {
        runtime: state.runtime
            ? {
                getService: (type) => state.runtime.getService(type),
            }
            : undefined,
    }, { json, error, readJsonBody });
}
export async function handleCloudAndCoreRouteGroup({ req, res, method, pathname, state, restartRuntime, saveConfig, }) {
    if (!pathname.startsWith("/api/cloud/")) {
        return false;
    }
    // Note: `/api/cloud/x/*` (X relay) is served by @elizaos/plugin-elizacloud's
    // route surface (elizaCloudRoutePlugin) via the runtime plugin route system,
    // not here. None of the handlers below match `/api/cloud/x/*`, so it falls
    // through to `tryHandleRuntimePluginRoute`.
    const cloudRoutes = await getCloudRoutesPlugin();
    const effectiveConfig = createDevCloudConfigAuthorityView(state.config);
    const billingHandled = await cloudRoutes.handleCloudBillingRoute(req, res, pathname, method, { config: effectiveConfig, runtime: state.runtime });
    if (billingHandled)
        return true;
    const compatHandled = await cloudRoutes.handleCloudCompatRoute(req, res, pathname, method, { config: effectiveConfig, runtime: state.runtime });
    if (compatHandled)
        return true;
    // Core Cloud routes include explicit login/disconnect mutations. Give those
    // handlers a sanitized, unmarked working copy and persist it only through
    // this deliberate adapter; the durable state object remains separate from
    // the read-only authority view until a successful save.
    const cloudRouteConfig = materializeDevCloudConfigAuthorityView(effectiveConfig);
    const persistCloudRouteConfig = cloudRouteConfig === state.config
        ? saveConfig
        : (nextConfig) => {
            saveConfig(nextConfig);
            state.config = nextConfig;
        };
    const cloudState = {
        config: cloudRouteConfig,
        cloudManager: state.cloudManager,
        runtime: state.runtime,
        restartRuntime,
        services: {
            saveElizaConfig: persistCloudRouteConfig,
            createIntegrationTelemetrySpan,
        },
    };
    return cloudRoutes.handleCloudRoute(req, res, pathname, method, cloudState);
}
export async function handleSandboxRouteGroup({ req, res, method, pathname, state, }) {
    if (!pathname.startsWith("/api/sandbox")) {
        return false;
    }
    return (await getComputeUsePlugin()).handleSandboxRoute(req, res, pathname, method, { sandboxManager: state.sandboxManager });
}
export async function handleDatabaseRouteGroup({ req, res, pathname, state, }) {
    if (!pathname.startsWith("/api/database/")) {
        return false;
    }
    return handleDatabaseRoute(req, res, state.runtime, pathname, state.config);
}
export async function handleConversationRouteGroup({ req, res, method, pathname, state, json, error, readJsonBody, callerAuthorization, }) {
    if (pathname.startsWith("/api/conversations")) {
        return handleConversationRoutes({
            req,
            res,
            method,
            pathname,
            readJsonBody,
            json,
            error,
            state,
            callerAuthorization,
        });
    }
    // Per-agent message endpoint mirrors the cloud agent-server contract
    // (`POST /agents/:id/message`) and shares chat-routes' generateChatResponse
    // path — same model routing as `/v1/chat/completions`, including
    // local-inference TEXT_LARGE handlers. Issue #7680.
    const isAgentMessageRoute = method === "POST" && /^\/api\/agents\/[^/]+\/message$/.test(pathname);
    if (!pathname.startsWith("/v1/") && !isAgentMessageRoute) {
        return false;
    }
    return handleChatRoutes({
        req,
        res,
        method,
        pathname,
        readJsonBody,
        json,
        error,
        state,
        callerAuthorization,
    });
}
export async function handleLifeOpsRuntimePluginRoute({ req, res, method, pathname, url, state, isAuthorizedRequest, }) {
    return tryHandleRuntimePluginRoute({
        req,
        res,
        method,
        pathname,
        url,
        runtime: state.runtime,
        isAuthorized: () => isAuthorizedRequest(req),
        hostContext: {
            config: createDevCloudConfigAuthorityView(state.config),
        },
    });
}
