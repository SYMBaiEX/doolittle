import type { Route } from "@elizaos/host/protocol";
/**
 * GET /api/files — list stored files (newest first), selected per viewer
 * (#14778): the single-owner boundary and OWNER/ADMIN-rank viewers see the
 * whole store; USER/GUEST viewers get the designed restricted state.
 */
export declare const filesListRoute: Route;
/** DELETE /api/files/:filename — delete one stored file (reference-unaware). */
export declare const fileDeleteRoute: Route;
export declare const filesRoutes: Route[];
