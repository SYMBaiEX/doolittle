/** Read-only catalog and live registration inventory for the authenticated host API. */
import type http from "node:http";
import type { PluginEntry, ServerState } from "./server-types.js";
type InventoryState = Pick<ServerState, "config" | "runtime" | "plugins">;
/** Rebuild values on every read; configured/enabled never stand in for registration. */
export declare function getPluginInventory(state: InventoryState): PluginEntry[];
export declare function handlePluginInventoryRoutes(ctx: {
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: InventoryState;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
}): boolean;
export {};
