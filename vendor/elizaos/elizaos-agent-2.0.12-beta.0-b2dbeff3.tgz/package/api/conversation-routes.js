/**
 * Conversation CRUD routes extracted from server.ts.
 *
 * Handles:
 *   POST   /api/conversations            – create
 *   GET    /api/conversations             – list
 *   GET    /api/conversations/messages/search – corpus-wide message search
 *   POST   /api/conversations/dev/seed-messages – dev-only backdated corpus seed
 *   GET    /api/conversations/:id/messages – get messages
 *   POST   /api/conversations/:id/messages/truncate – truncate
 *   DELETE /api/conversations/:id/messages/:messageId – delete one message
 *   POST   /api/conversations/:id/messages/stream   – stream message
 *   POST   /api/conversations/:id/messages           – send message
 *   POST   /api/conversations/:id/greeting            – get/store greeting
 *   PATCH  /api/conversations/:id         – update/rename
 *   DELETE /api/conversations/:id         – delete
 */
import crypto from "node:crypto";
import { isChatFailureKind, PatchConversationRequestSchema, PostConversationCleanupEmptyRequestSchema, PostConversationMessageHeardRequestSchema, PostConversationRequestSchema, PostConversationTruncateRequestSchema, PostSeedMessagesRequestSchema, parseChatFailureKind, parseChatTerminalFailure, parseChatUserTextFormat, } from "@elizaos/contracts";
import { attestAuthenticatedApiDeliveryAudience, authorizeOwnerExclusiveDisclosure, bindIncomingMessagePersistence, ChannelType, composeToolDiagnosticRedactor, conversationClientUserMemoryId, createMessageMemory, createUniqueUuid, ElizaError, getEntityRole, getInferenceTimer, hasAtLeastRole, InferenceTurnTimer, logger, MESSAGE_SOURCE_AGENT_GREETING, MESSAGE_SOURCE_CLIENT_CHAT, MESSAGE_SOURCE_TRIGGER_PROMPT, mergeEffectReceipts, nextInferenceTurnId, normalizeActionFailureProvenance, normalizeActionReplyFailure, normalizeEffectReceipts, parsePositiveInteger, parseSharedTodoCutoverSnapshot, projectCompleteToolValueForModel, RoomHandlerQueueClosedError, RoomHandlerQueueGlobalSaturatedError, RoomHandlerQueueSaturatedError, readDurableConversationChatMarker, readSystemNotice, recordOwnerGrant, recordRoleGrant, resolveAppliedUserFacingEffectReceipts, runWithInferenceTiming, runWithStreamingContext, stringToUuid, systemNoticeText, TodoCutoverContractError, timeInferenceSpan, validateUuid, withStandaloneTrajectory, } from "@elizaos/core";
import { LOCAL_VOICE_RUNTIME_AGENT_HEADER, LOCAL_VOICE_RUNTIME_CONVERSATION_HEADER, } from "@elizaos/host/protocol";
import { DeviceActionError, enforceTrustedDeliveryAudienceAtEgress, evaluatePlannedReplyEgress, parseReplyRecoveryHistorySelection, projectToolResultForModel, resolvePlannedReplyEgress, setDeviceReadReplyConversation, shouldSkipResponseMemoryPersistence, withDeviceActionTurn, } from "@elizaos/plugin-assistant";
import { getScheduledTaskRunner, isScheduledTask, } from "@elizaos/plugin-scheduling";
import { agentIdentityName } from "../runtime/build-character-config.js";
import { getAgentHostBridge, } from "../runtime/host-bridge.js";
import { isLegacyUnavailableCheckin, projectLegacySystemNotice, } from "../runtime/legacy-system-notice.js";
import { deleteConversationMemories, deleteConversationMessage, recordHeardAssistantMessage, truncateConversationMessages, } from "../services/conversation-message-service.js";
import { selectAttachmentsForViewer, } from "./attachment-disclosure.js";
import { admitChatMessageId, ChatIdempotencyWaitAbortedError, classifyChatFailure, generateChatResponse, generateConversationTitle, getChatFailureReply, getChatMessageIdOutcome, isIntentionalNoResponseResult, normalizeAccountConnectRequest, normalizeChatResponseText, persistAssistantConversationMemory, persistConversationMemory, persistExactConversationMemory, persistExactConversationMemoryResult, persistInterruptedAssistantReceipt, readChatRequestPayload, releaseChatMessageId, resolveNoResponseFallback, resolveTrustedApiPrincipal, setChatMessageIdOutcome, withoutLiveRateLimit, } from "./chat-routes.js";
import { createChatTokenStreamWriter, initSse, writeChatStatusSse, writeChatToolSse, writeSse, writeSseJson, } from "./chat-stream-writer.js";
import { resolveClientChatAdminEntityId } from "./client-chat-admin.js";
import { assertConversationConnectionRuntime, captureConversationConnectionDescriptor, isConversationConnectionError, prepareConversationConnectionRoom, scheduleConversationConnectionEnsure, serializeConversationConnectionRoomDeletion, } from "./conversation-connection-readiness.js";
import { scheduleImportedConversationEmbeddings } from "./conversation-import-embeddings.js";
import { buildConversationRoomMetadata, sanitizeConversationMetadata, } from "./conversation-metadata.js";
import { restoreConversationFromDb } from "./conversation-restore.js";
import { compareConversationsByRecency, compareMemoriesByCreatedAt, } from "./conversation-sort.js";
import { ELIZA_TRACE_ID_HEADER, resolveConversationTraceContext, } from "./conversation-trace.js";
import { deviceRequestCredential } from "./device-action-routes.js";
import { resolveHttpAccessContext } from "./http-access-context.js";
import { generateMessageCorpus, seedMessageCorpus } from "./message-corpus.js";
import { buildUserMessages, decodePathComponent, getErrorMessage, MAX_DELETED_CONVERSATION_IDS, persistDeletedConversationIdsToState, resolveAppUserName, } from "./server-helpers.js";
import { normalizeWsClientId } from "./server-helpers-auth.js";
import { importSharedTodoCutover, } from "./todo-cutover-import.js";
import { resolveWaifuChatAccess, waifuChatRoleToWorldRole, } from "./waifu-chat-role-resolver.js";
let discordConversationPromise = null;
function getDiscordConversationApi() {
    discordConversationPromise ??= import("@elizaos/plugin-discord");
    return discordConversationPromise;
}
function mayNeedDiscordMessageEnrichment(source) {
    return typeof source === "string" && source.toLowerCase().includes("discord");
}
function chunkVisibleTextForSse(text) {
    const chunks = [];
    let cursor = 0;
    const targetSize = 48;
    while (cursor < text.length) {
        const limit = Math.min(text.length, cursor + targetSize);
        let end = limit;
        if (limit < text.length) {
            const boundary = text.lastIndexOf(" ", limit);
            if (boundary > cursor + 12) {
                end = boundary + 1;
            }
        }
        chunks.push(text.slice(cursor, end));
        cursor = end;
    }
    return chunks;
}
function readCanonicalSingleHeader(req, name) {
    const value = req.headers[name.toLowerCase()];
    if (value === undefined)
        return null;
    if (Array.isArray(value) ||
        value.length === 0 ||
        value.trim() !== value ||
        value.includes(",")) {
        return "invalid";
    }
    return value;
}
function resolveLocalVoiceRuntimeFence(req, state, conversationId) {
    const expectedAgentId = readCanonicalSingleHeader(req, LOCAL_VOICE_RUNTIME_AGENT_HEADER);
    const expectedConversationId = readCanonicalSingleHeader(req, LOCAL_VOICE_RUNTIME_CONVERSATION_HEADER);
    if (expectedAgentId === null && expectedConversationId === null) {
        return { kind: "absent" };
    }
    if (expectedAgentId === null ||
        expectedConversationId === null ||
        expectedAgentId === "invalid" ||
        expectedConversationId === "invalid") {
        return {
            kind: "invalid",
            message: "Local voice runtime identity headers are invalid",
        };
    }
    if (expectedConversationId !== conversationId) {
        return {
            kind: "conflict",
            message: "Local voice conversation identity changed",
        };
    }
    const runtime = state.runtime;
    if (!runtime || String(runtime.agentId) !== expectedAgentId) {
        return {
            kind: "conflict",
            message: "Local voice agent runtime changed",
        };
    }
    return { kind: "valid", fence: { runtime } };
}
function isLocalVoiceRuntimeFenceCurrent(state, fence, conversation) {
    return (fence === null ||
        (state.runtime === fence.runtime &&
            (conversation === undefined ||
                (state.conversations.get(conversation.id) === conversation &&
                    !state.deletedConversationIds.has(conversation.id)))));
}
function assertLocalVoiceTurnFenceCurrent(state, fence, conversation) {
    if (fence === null)
        return;
    if (state.runtime !== fence.runtime) {
        throw new ElizaError("Local voice agent runtime changed", {
            code: "LOCAL_VOICE_RUNTIME_FENCE_CHANGED",
            context: { conversationId: conversation.id },
        });
    }
    if (state.conversations.get(conversation.id) !== conversation ||
        state.deletedConversationIds.has(conversation.id)) {
        throw new ElizaError("Local voice conversation changed", {
            code: "LOCAL_VOICE_CONVERSATION_FENCE_CHANGED",
            context: { conversationId: conversation.id },
        });
    }
}
function readViewInteractionClientId(req) {
    for (const name of ["x-elizaos-client-id", "x-eliza-client-id"]) {
        const value = req.headers[name];
        const candidate = Array.isArray(value) ? value[0] : value;
        const clientId = normalizeWsClientId(candidate);
        if (clientId)
            return clientId;
    }
    return null;
}
export function withViewInteractionClient(message, req) {
    const viewClientId = readViewInteractionClientId(req);
    if (!viewClientId)
        return message;
    const contentMetadata = message.content.metadata &&
        typeof message.content.metadata === "object" &&
        !Array.isArray(message.content.metadata)
        ? message.content.metadata
        : {};
    // The routing identity is request-scoped rather than persisted chat content:
    // a device capability must return to the shell that initiated this turn,
    // while history remains portable across reconnects and devices.
    return {
        ...message,
        content: {
            ...message.content,
            metadata: {
                ...contentMetadata,
                viewClientId,
            },
        },
    };
}
function beginActiveChatTurn(state) {
    state.activeChatTurnCount = Math.max(0, state.activeChatTurnCount) + 1;
    let ended = false;
    return () => {
        if (ended)
            return;
        ended = true;
        state.activeChatTurnCount = Math.max(0, state.activeChatTurnCount - 1);
    };
}
function canonicalChatFingerprintValue(value) {
    if (Array.isArray(value)) {
        return value.map((entry) => canonicalChatFingerprintValue(entry));
    }
    if (value && typeof value === "object") {
        return Object.fromEntries(Object.entries(value)
            // Code-unit order, not localeCompare: ICU collation is locale-dependent
            // and ranks canonically equivalent distinct keys as equal, so two
            // replicas would fingerprint one turn differently and admit a duplicate.
            .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
            .map(([key, entry]) => [key, canonicalChatFingerprintValue(entry)]));
    }
    return value;
}
/**
 * Idempotency identity for one chat turn. Exported so the canonical key
 * ordering it depends on can be pinned by test.
 */
export function buildConversationChatFingerprint(input) {
    return crypto
        .createHash("sha256")
        .update(JSON.stringify(canonicalChatFingerprintValue(input)))
        .digest("hex");
}
function buildConversationChatIdempotencyScope(runtime, roomId, principalId) {
    return `${runtime.agentId}:${roomId}:${principalId}`;
}
function isRoomQueueBackpressureError(error) {
    return (error instanceof RoomHandlerQueueSaturatedError ||
        error instanceof RoomHandlerQueueGlobalSaturatedError);
}
function roomQueueAdmissionStatus(error) {
    if (isRoomQueueBackpressureError(error))
        return 429;
    if (error instanceof RoomHandlerQueueClosedError)
        return 503;
    return 500;
}
async function awaitConversationChatAdmission(scope, clientMessageId, fingerprint, signal) {
    while (true) {
        const admission = admitChatMessageId(scope, clientMessageId, {
            fingerprint,
        });
        if (admission.kind === "unkeyed") {
            return { kind: "owner", reservation: null };
        }
        if (admission.kind === "owner") {
            return { kind: "owner", reservation: admission.reservation };
        }
        if (admission.kind === "settled") {
            return { kind: "settled", outcome: admission.outcome };
        }
        if (admission.kind === "conflict")
            return admission;
        try {
            const result = await admission.wait(signal);
            if (result.kind === "settled") {
                return result;
            }
        }
        catch (error) {
            if (error instanceof ChatIdempotencyWaitAbortedError) {
                return { kind: "aborted" };
            }
            throw error;
        }
    }
}
// ---------------------------------------------------------------------------
// Closure-lifted helpers
// ---------------------------------------------------------------------------
export function resolveConversationAdminEntityId(state) {
    return resolveClientChatAdminEntityId(state);
}
function isStreamEventSource(value) {
    return (typeof value === "object" &&
        value !== null &&
        typeof value.on === "function");
}
function isStreamSocketLike(value) {
    return typeof value === "object" && value !== null;
}
function createRequestDisconnectAbortTracker({ req, res, operation, }) {
    const abortController = new AbortController();
    const registrations = [];
    let aborted = false;
    let completed = false;
    const abort = (reason) => {
        if (completed || aborted)
            return;
        aborted = true;
        abortController.abort(reason instanceof Error ? reason : new Error(`${operation} aborted`));
    };
    const register = (source, event, listener) => {
        if (!isStreamEventSource(source))
            return;
        source.on?.(event, listener);
        registrations.push({ source, event, listener });
    };
    const onClientGone = () => abort(new Error(`${operation} client disconnected`));
    const onResponseClose = () => {
        const ended = Boolean(res.writableEnded);
        if (!ended)
            onClientGone();
    };
    register(req, "aborted", onClientGone);
    register(req, "error", onClientGone);
    register(res, "close", onResponseClose);
    register(res, "error", onClientGone);
    return {
        signal: abortController.signal,
        dispose: () => {
            for (const { source, event, listener } of registrations) {
                source.off?.(event, listener);
            }
            registrations.length = 0;
        },
        isAborted: () => aborted,
        markCompleted: () => {
            completed = true;
        },
    };
}
/**
 * The bearer of a revocable, DB-backed paired-device session, or undefined.
 *
 * A device paired with a user code gets a USER machine session. One paired
 * with the operator code gets a machine session bound to the owner identity,
 * so its principal is `owner_session`. Both are paired devices whose turn
 * should outlive a dropped socket. For the owner case the bearer must itself
 * resolve to a live session for the authenticated identity: the static API
 * token, the trusted-local bypass and cookie sessions keep the existing
 * disconnect-as-cancel behavior.
 */
export async function resolvePairedSessionToken(req, principal, runtime) {
    const bearer = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization ?? "")?.[1];
    if (!bearer)
        return undefined;
    if (principal.kind === "service_gateway") {
        return principal.sessionRole === "USER" && principal.sessionIdentityId
            ? bearer
            : undefined;
    }
    if (principal.kind !== "owner_session")
        return undefined;
    try {
        const authorization = await getAgentHostBridge().resolveSessionTokenAuthorization?.(bearer, runtime ?? null);
        return authorization?.ok &&
            authorization.identityId &&
            authorization.identityId === principal.principalId
            ? bearer
            : undefined;
    }
    catch {
        // error-policy:J7 an unreadable session store denies continuation only;
        // the request still runs with disconnect-as-cancel.
        return undefined;
    }
}
export function createConversationStreamDisconnectTracker({ req, res, conversationId, roomId, continueOnDisconnect, pairedSessionToken, runtime, }) {
    const abortController = new AbortController();
    const registrations = [];
    let aborted = false;
    let transportClosed = false;
    let completed = false;
    const requestSocket = isStreamSocketLike(req.socket)
        ? (req.socket ?? null)
        : null;
    const responseSocket = isStreamSocketLike(res.socket)
        ? (res.socket ?? null)
        : null;
    const responseEnded = () => Boolean(res.writableEnded);
    const cancelGeneration = () => {
        if (completed || aborted)
            return;
        aborted = true;
        transportClosed = true;
        abortController.abort(new Error("Paired session revoked"));
    };
    const bridge = getAgentHostBridge();
    const revalidatePairedSession = () => {
        if (!pairedSessionToken)
            return Promise.resolve(true);
        return Promise.resolve()
            .then(() => bridge.resolveSessionTokenAuthorization?.(pairedSessionToken, runtime ?? null))
            .then((authorization) => {
            if (!authorization?.ok)
                cancelGeneration();
            return authorization?.ok === true;
        })
            .catch(() => {
            cancelGeneration();
            return false;
        });
    };
    const unsubscribeRevocations = pairedSessionToken
        ? bridge.subscribeSessionRevocations?.((sessionId) => {
            if (sessionId === pairedSessionToken) {
                cancelGeneration();
            }
            else if (sessionId === null) {
                // A bulk revoke can except one device. Recheck its live authority
                // before canceling the turn; a failed check denies continuation.
                void revalidatePairedSession();
            }
        })
        : undefined;
    if (pairedSessionToken && !unsubscribeRevocations)
        cancelGeneration();
    // Subscribe first, then close the gap from HTTP authorization to tracker
    // creation. A revoke in that interval must not own a queued turn.
    const authorityReady = revalidatePairedSession();
    // Revocation notifications are process-local. Recheck the durable session
    // while an offline turn is running so expiry or another host's revocation
    // cancels generation too, matching the WebSocket authority interval.
    let authorityCheckPending = false;
    const authorityInterval = pairedSessionToken
        ? setInterval(() => {
            if (completed || aborted || authorityCheckPending)
                return;
            authorityCheckPending = true;
            void revalidatePairedSession().finally(() => {
                authorityCheckPending = false;
            });
        }, 5_000)
        : undefined;
    authorityInterval?.unref();
    const abort = (reason) => {
        if (completed || aborted)
            return;
        if (continueOnDisconnect) {
            // A paired remote device may disappear after its turn was accepted.
            // Stop writing to its SSE socket, but keep the room lease and generation
            // alive so the durable reply can be read after reconnect. An explicit
            // chat Stop still uses /api/turns/:roomId/abort.
            transportClosed = true;
            return;
        }
        aborted = true;
        logger.info({ conversationId, roomId }, "[ConversationStream] client disconnected; aborting generation");
        abortController.abort(reason ?? new Error("Client disconnected"));
    };
    const checkConnectionClosed = () => {
        if (transportClosed)
            return true;
        const socketClosed = requestSocket?.destroyed === true ||
            responseSocket?.destroyed === true ||
            (requestSocket?.writable === false && !responseEnded()) ||
            (responseSocket?.writable === false && !responseEnded());
        const responseClosed = res.destroyed === true && !responseEnded();
        if (socketClosed || responseClosed) {
            abort(new Error("Client disconnected"));
            return true;
        }
        return false;
    };
    const register = (source, event, listener) => {
        if (!isStreamEventSource(source))
            return;
        source.on?.(event, listener);
        registrations.push({ source, event, listener });
    };
    const onRequestClose = () => {
        checkConnectionClosed();
    };
    const onClientGone = () => {
        abort(new Error("Client disconnected"));
    };
    // Bun's node:http shim emits req.close when the POST body finishes, before
    // the SSE response is complete. Socket events must be attached before that
    // point; listeners added after body parsing can miss later client exits.
    register(req, "aborted", onClientGone);
    register(req, "close", onRequestClose);
    register(req, "error", onClientGone);
    register(res, "close", onClientGone);
    register(res, "error", onClientGone);
    register(requestSocket, "close", onClientGone);
    register(requestSocket, "error", onClientGone);
    if (responseSocket && responseSocket !== requestSocket) {
        register(responseSocket, "close", onClientGone);
        register(responseSocket, "error", onClientGone);
    }
    return {
        signal: abortController.signal,
        authorityReady,
        abort,
        checkConnectionClosed,
        dispose: () => {
            if (authorityInterval)
                clearInterval(authorityInterval);
            unsubscribeRevocations?.();
            for (const { source, event, listener } of registrations) {
                source.off?.(event, listener);
            }
            registrations.length = 0;
        },
        isAborted: () => aborted || transportClosed,
        markCompleted: () => {
            completed = true;
        },
    };
}
function writeConversationStreamHeartbeat(res, disconnectTracker) {
    if (disconnectTracker.isAborted() || res.writableEnded)
        return;
    try {
        res.write(": heartbeat\n\n");
    }
    catch {
        disconnectTracker.abort(new Error("Client disconnected"));
    }
}
function isTurnAbortError(err) {
    if (!(err instanceof Error))
        return false;
    const code = err.code;
    return (code === "TURN_ABORTED" ||
        err.name === "TurnAbortedError" ||
        err.message.startsWith("Turn aborted:"));
}
function ensureAdminEntityIdForRuntime(state, runtime) {
    const resolutionState = {
        runtime,
        adminEntityId: state.adminEntityId,
        chatUserId: state.chatUserId,
        config: state.config,
        agentName: state.agentName,
    };
    const ownerId = resolveClientChatAdminEntityId(resolutionState);
    if (state.runtime === runtime) {
        state.adminEntityId = ownerId;
        state.chatUserId = ownerId;
    }
    return ownerId;
}
function ensureAdminEntityId(state) {
    return ensureAdminEntityIdForRuntime(state, state.runtime);
}
/**
 * Exported for the machine-session conversation-attribution regression suite;
 * runtime callers are the conversation route handlers in this module.
 */
export function resolveConversationCaller(req, state, principal, runtime = state.runtime) {
    const access = resolveWaifuChatAccess(req);
    if (access) {
        return {
            entityId: stringToUuid(`waifu-wallet:${access.walletAddress.toLowerCase()}`),
            role: waifuChatRoleToWorldRole(access.role),
            userName: access.walletAddress,
            grantSource: "connector_admin",
        };
    }
    if (principal.kind === "owner_session" ||
        principal.kind === "owner_api_token") {
        return {
            entityId: ensureAdminEntityIdForRuntime(state, runtime),
            role: "OWNER",
            userName: resolveAppUserName(state.config),
            grantSource: "owner",
        };
    }
    if (principal.kind === "service_gateway" && principal.sessionRole) {
        // A paired device's machine session authenticates at boundary role USER.
        // Mirror the compat chat ingress grant (grantSessionUserWorldRole in
        // chat-routes.ts) on the conversation surface so checkSenderRole resolves
        // the session's boundary role here too: sessionRole is the literal "USER"
        // by construction and the grant is recorded with audit source "session".
        return {
            entityId: stringToUuid(`conversation-external:${principal.principalId}`),
            role: principal.sessionRole,
            userName: "External API caller",
            grantSource: "session",
        };
    }
    return {
        entityId: stringToUuid(`conversation-external:${principal.principalId}`),
        role: "GUEST",
        userName: "External API caller",
        grantSource: "connector_admin",
    };
}
function normalizeWaifuWallet(address) {
    if (!address || !/^0x[a-fA-F0-9]{40}$/.test(address))
        return null;
    return address.toLowerCase();
}
function getWaifuChatOwnerWallet(conv) {
    return normalizeWaifuWallet(conv.metadata?.waifuChatOwnerWallet);
}
function addWaifuConversationOwnerMetadata(req, metadata) {
    const access = resolveWaifuChatAccess(req);
    if (!access)
        return metadata;
    return {
        ...(metadata ?? {}),
        waifuChatOwnerWallet: access.walletAddress.toLowerCase(),
        waifuChatRole: access.role,
    };
}
function canWaifuAccessConversation(access, conv) {
    if (!access || access.role === "admin")
        return true;
    return getWaifuChatOwnerWallet(conv) === access.walletAddress.toLowerCase();
}
function rejectWaifuConversationAccessIfNeeded(req, conv, error, res) {
    const access = resolveWaifuChatAccess(req);
    if (canWaifuAccessConversation(access, conv))
        return false;
    error(res, "Conversation not found", 404);
    return true;
}
function rejectWaifuNonAdminMutationIfNeeded(req, error, res) {
    const access = resolveWaifuChatAccess(req);
    if (!access || access.role === "admin")
        return false;
    error(res, "Forbidden", 403);
    return true;
}
async function ensureWorldOwnershipAndRoles(runtime, worldId, ownerId, callerId, callerRole, callerGrantSource, assertCurrent) {
    const world = await runtime.getWorld(worldId);
    assertCurrent?.();
    if (!world) {
        throw new ElizaError("Conversation world is missing after connection initialization", {
            code: "CONVERSATION_WORLD_MISSING",
            context: {
                agentId: runtime.agentId,
                worldId,
                ownerId,
                callerId,
            },
            severity: "fatal",
        });
    }
    let needsUpdate = false;
    if (!world.metadata) {
        world.metadata = {};
        needsUpdate = true;
    }
    if (!world.metadata.ownership ||
        typeof world.metadata.ownership !== "object" ||
        world.metadata.ownership.ownerId !== ownerId) {
        world.metadata.ownership = { ownerId };
        needsUpdate = true;
    }
    // #12087 Item 11: route role writes through the auditable grant helpers so each
    // grant pairs roles[id] with a roleSources[id] entry (the #9948 invariant),
    // instead of mutating metadata.roles directly with raw literals. The owner grant
    // is recorded as source "owner"; the caller's connector-derived role is recorded
    // as "connector_admin" (revocable/demotable), and never overwrites the owner's
    // grant when the caller IS the owner.
    const metadata = world.metadata;
    if (recordOwnerGrant(metadata, ownerId)) {
        needsUpdate = true;
    }
    if (callerId !== ownerId) {
        if (callerGrantSource === "session") {
            // Session-sourced grants mirror grantSessionUserWorldRole in
            // chat-routes.ts: clamped to the session's boundary role and never
            // downgrading an existing USER-or-higher grant (e.g. a manual ADMIN
            // grant by the owner).
            if (!hasAtLeastRole(getEntityRole(metadata, callerId), callerRole) &&
                recordRoleGrant(metadata, callerId, callerRole, "session")) {
                needsUpdate = true;
            }
        }
        else if (recordRoleGrant(metadata, callerId, callerRole, callerGrantSource)) {
            needsUpdate = true;
        }
    }
    if (needsUpdate) {
        assertCurrent?.();
        await runtime.updateWorld(world);
        assertCurrent?.();
    }
}
function findPersistedGeneratedAssistantTurn(runtime, roomId, result) {
    if (!Array.isArray(result.persistedResponseMessageIds) ||
        !Array.isArray(result.responseMessages)) {
        return null;
    }
    const persistedIds = new Set(result.persistedResponseMessageIds);
    const candidate = result.responseMessages.at(-1);
    if (typeof candidate?.id !== "string" ||
        candidate.id.length === 0 ||
        !persistedIds.has(candidate.id) ||
        candidate.entityId !== runtime.agentId ||
        candidate.agentId !== runtime.agentId ||
        candidate.roomId !== roomId) {
        return null;
    }
    return { ...candidate, id: candidate.id };
}
class AssistantReplyPersistenceError extends Error {
    constructor(message, cause) {
        super(message, { cause });
        this.name = "AssistantReplyPersistenceError";
    }
}
async function resolvePersistedAssistantTurn(runtime, roomId, turnStartedAt, result, text, channelType, roomHandlerLease, userMessageId, assertCurrent) {
    const generatedTurn = findPersistedGeneratedAssistantTurn(runtime, roomId, result);
    if (generatedTurn) {
        const generatedText = typeof generatedTurn.content.text === "string"
            ? generatedTurn.content.text
            : "";
        const persistedContent = buildPersistedAssistantContent(text, result, userMessageId);
        const generatedTerminalFailure = parseChatTerminalFailure(generatedTurn.content.terminalFailure);
        const terminalFailureNeedsReconciliation = result.terminalFailure !== undefined &&
            (generatedTerminalFailure?.kind !== result.terminalFailure.kind ||
                generatedTerminalFailure?.message !== result.terminalFailure.message ||
                generatedTerminalFailure?.transient !==
                    result.terminalFailure.transient ||
                generatedTerminalFailure?.code !== result.terminalFailure.code);
        if (generatedText !== text ||
            generatedTurn.content.planningAcknowledgment !==
                result.planningAcknowledgment ||
            (userMessageId !== undefined &&
                generatedTurn.content.inReplyTo !== userMessageId) ||
            terminalFailureNeedsReconciliation) {
            try {
                await runtime.roomHandlerQueue.runInLease(roomId, roomHandlerLease, () => {
                    assertCurrent?.();
                    return runtime.updateMemory({
                        ...generatedTurn,
                        content: persistedContent,
                    });
                });
                assertCurrent?.();
            }
            catch (cause) {
                throw new AssistantReplyPersistenceError("Failed to reconcile the persisted assistant reply", cause);
            }
        }
        return { kind: "durable", id: generatedTurn.id, text };
    }
    const content = buildPersistedAssistantContent(text, result, userMessageId);
    if (shouldSkipResponseMemoryPersistence({
        content,
        roomId,
        entityId: runtime.agentId,
    })) {
        return { kind: "ephemeral", text };
    }
    let persisted;
    try {
        persisted = await persistAssistantConversationMemory(runtime, roomId, content, channelType, turnStartedAt, crypto.randomUUID(), roomHandlerLease, assertCurrent);
    }
    catch (cause) {
        // error-policy:J2 attach the durable-turn boundary before the route
        // translates this into a terminal SSE error.
        throw new AssistantReplyPersistenceError("Failed to persist the assistant reply", cause);
    }
    if (!persisted?.id) {
        throw new AssistantReplyPersistenceError("Assistant reply persistence returned no durable message id");
    }
    return { kind: "durable", id: persisted.id, text };
}
function markConversationDeleted(state, conversationId) {
    const normalizedId = conversationId.trim();
    if (!normalizedId)
        return;
    if (state.deletedConversationIds.has(normalizedId))
        return;
    const nextIds = new Set(state.deletedConversationIds);
    nextIds.add(normalizedId);
    while (nextIds.size > MAX_DELETED_CONVERSATION_IDS) {
        const oldest = nextIds.values().next().value;
        if (!oldest)
            break;
        nextIds.delete(oldest);
    }
    persistDeletedConversationIdsToState(nextIds);
    state.deletedConversationIds.clear();
    for (const id of nextIds)
        state.deletedConversationIds.add(id);
}
async function deleteConversationRoomData(runtime, roomId) {
    await serializeConversationConnectionRoomDeletion(runtime, roomId, async () => {
        const runtimeWithDelete = runtime;
        if (typeof runtimeWithDelete.deleteRoom === "function") {
            await runtimeWithDelete.deleteRoom(roomId);
            return;
        }
        const dbDeleteRoom = runtimeWithDelete.adapter.db.deleteRoom;
        if (typeof dbDeleteRoom === "function") {
            await dbDeleteRoom.call(runtimeWithDelete.adapter.db, roomId);
        }
    });
}
function captureConversationConnection(state, runtime, conv, caller, requestFence) {
    const agentName = runtime.character.name ?? "Eliza";
    const identityName = agentIdentityName(runtime.character) ?? "Eliza";
    const ownerId = ensureAdminEntityIdForRuntime(state, runtime);
    const worldId = stringToUuid(`${identityName}-web-chat-world`);
    const messageServerId = stringToUuid(`${identityName}-web-server`);
    const descriptor = captureConversationConnectionDescriptor({
        runtime,
        conversationId: conv.id,
        roomId: conv.roomId,
        agentName,
        worldId,
        messageServerId,
        channelId: `web-conv-${conv.id}`,
        ownerId,
        callerEntityId: caller.entityId,
        callerRole: caller.role,
        callerGrantSource: caller.grantSource,
        callerUserName: caller.userName,
        requestFence,
    });
    setDeviceReadReplyConversation(runtime, conv.id, conv.roomId);
    return descriptor;
}
async function establishConversationConnection(descriptor, roomName) {
    await descriptor.runtime.ensureConnection({
        roomName,
        entityId: descriptor.callerEntityId,
        roomId: descriptor.roomId,
        worldId: descriptor.worldId,
        userName: descriptor.callerUserName,
        source: MESSAGE_SOURCE_CLIENT_CHAT,
        channelId: descriptor.channelId,
        type: ChannelType.DM,
        messageServerId: descriptor.messageServerId,
        metadata: {
            ownership: { ownerId: descriptor.ownerId },
            waifuRole: descriptor.callerRole,
        },
    });
    descriptor.requestFence?.();
    await ensureWorldOwnershipAndRoles(descriptor.runtime, descriptor.worldId, descriptor.ownerId, descriptor.callerEntityId, descriptor.callerRole, descriptor.callerGrantSource, descriptor.requestFence);
    descriptor.requestFence?.();
}
/**
 * Exported for the machine-session conversation-attribution regression suite;
 * runtime callers are the conversation route handlers in this module.
 */
export async function ensureConversationRoom(state, runtime, conv, caller) {
    const descriptor = captureConversationConnection(state, runtime, conv, caller);
    await scheduleConversationConnectionEnsure(descriptor, () => establishConversationConnection(descriptor, conv.title));
    assertConversationConnectionRuntime(state.runtime, descriptor);
    return descriptor;
}
async function syncConversationRoomState(state, conv) {
    if (!state.runtime)
        return;
    const runtime = state.runtime;
    const room = await runtime.getRoom(conv.roomId);
    if (!room)
        return;
    const ownerId = ensureAdminEntityId(state);
    const nextMetadata = buildConversationRoomMetadata(conv, ownerId, room.metadata);
    const nextName = conv.title;
    const metadataChanged = JSON.stringify(room.metadata ?? null) !== JSON.stringify(nextMetadata);
    if (room.name === nextName && !metadataChanged) {
        return;
    }
    // The runtime writes through every adapter's updateRooms (SQLite has no
    // updateRoom) and refreshes its room read cache.
    await runtime.updateRoom({
        ...room,
        name: nextName,
        metadata: nextMetadata,
    });
}
async function waitForConversationRestore(state) {
    const pending = state.conversationRestorePromise;
    if (!pending)
        return;
    await pending;
}
export function normalizeActionCallbackHistory(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    const history = [];
    for (const entry of value) {
        if (typeof entry !== "string") {
            continue;
        }
        const normalized = entry.trim();
        if (!normalized) {
            continue;
        }
        if (history.at(-1) === normalized) {
            continue;
        }
        history.push(normalized);
    }
    return history;
}
function mergeActionCallbackHistory(existing, incoming) {
    return normalizeActionCallbackHistory([...existing, ...incoming]);
}
export function formatConversationMessageText(text, actionCallbackHistory = []) {
    const history = normalizeActionCallbackHistory(actionCallbackHistory);
    if (history.length === 0) {
        return text;
    }
    const trimmedText = text.trim();
    if (trimmedText.length > 0) {
        return text;
    }
    return history.join("\n");
}
export function buildPersistedAssistantContent(text, result, userMessageId) {
    const responseContent = result?.responseContent && typeof result.responseContent === "object"
        ? result.responseContent
        : null;
    const responseMessageContent = Array.isArray(result?.responseMessages)
        ? (result.responseMessages
            .map((entry) => entry.content && typeof entry.content === "object"
            ? entry.content
            : null)
            .filter((content) => content !== null)
            .at(-1) ?? null)
        : null;
    const actionCallbackHistory = normalizeActionCallbackHistory(result?.actionCallbackHistory);
    const transcriptVisibility = result?.transcriptVisibility === "internal"
        ? "internal"
        : undefined;
    const persistedResponseMessageContent = responseMessageContent
        ? { ...responseMessageContent }
        : {};
    const persistedResponseContent = responseContent
        ? { ...responseContent }
        : {};
    delete persistedResponseMessageContent.transcriptVisibility;
    delete persistedResponseContent.transcriptVisibility;
    const inReplyTo = userMessageId ??
        persistedResponseContent.inReplyTo ??
        persistedResponseMessageContent.inReplyTo ??
        undefined;
    return responseContent || responseMessageContent
        ? {
            ...persistedResponseMessageContent,
            ...persistedResponseContent,
            text,
            ...(inReplyTo ? { inReplyTo } : {}),
            ...(transcriptVisibility ? { transcriptVisibility } : {}),
            ...(actionCallbackHistory.length > 0 ? { actionCallbackHistory } : {}),
            ...(result?.planningAcknowledgment
                ? { planningAcknowledgment: result.planningAcknowledgment }
                : {}),
        }
        : {
            text,
            ...(inReplyTo ? { inReplyTo } : {}),
            ...(transcriptVisibility ? { transcriptVisibility } : {}),
            ...(actionCallbackHistory.length > 0 ? { actionCallbackHistory } : {}),
            ...(result?.planningAcknowledgment
                ? { planningAcknowledgment: result.planningAcknowledgment }
                : {}),
        };
}
function conversationReplyContentHash(content) {
    const request = { ...content };
    delete request.chatIdempotency;
    return crypto
        .createHash("sha256")
        .update(JSON.stringify(canonicalChatFingerprintValue(request)))
        .digest("hex");
}
/** A grounded successful reply replaces only the original failure markers. */
function clearRecoveredReplyFailureMarkers(record) {
    const recovered = { ...record };
    for (const key of ["elizaSyntheticFailure", "syntheticChatFailure"])
        if (recovered[key] === true)
            delete recovered[key];
    for (const key of ["failureKind", "chatFailureKind"])
        if (isChatFailureKind(recovered[key]) ||
            recovered[key] === "no_response" ||
            recovered[key] === "transient_failure")
            delete recovered[key];
    return recovered;
}
function parseDurableConversationReplyRecovery(serialized) {
    try {
        const value = JSON.parse(serialized);
        if (!isRecord(value) ||
            !validateUuid(value.assistantMessageId) ||
            typeof value.userContentHash !== "string" ||
            !/^[a-f0-9]{64}$/.test(value.userContentHash) ||
            typeof value.assistantContentHash !== "string" ||
            !/^[a-f0-9]{64}$/.test(value.assistantContentHash) ||
            typeof value.context !== "string" ||
            !value.context.trim() ||
            !Array.isArray(value.pendingToolCalls) ||
            !Array.isArray(value.evaluatorOutputs) ||
            typeof value.ownerExclusiveDisclosureUsed !== "boolean" ||
            !Array.isArray(value.actionResults) ||
            value.actionResults.length === 0)
            return null;
        for (const result of value.actionResults) {
            if (!isRecord(result) ||
                typeof result.success !== "boolean" ||
                (result.text !== undefined && typeof result.text !== "string") ||
                (result.error !== undefined && typeof result.error !== "string") ||
                (result.data !== undefined && !isRecord(result.data)) ||
                (result.values !== undefined && !isRecord(result.values)))
                return null;
            if (result.effectReceipts !== undefined)
                result.effectReceipts = normalizeEffectReceipts(result.effectReceipts);
            if (result.replyFailure !== undefined)
                result.replyFailure = normalizeActionReplyFailure(result.replyFailure);
            if (result.failureProvenance !== undefined)
                result.failureProvenance = normalizeActionFailureProvenance(result.failureProvenance);
            if (result.success && result.failureProvenance !== undefined)
                return null;
        }
        if (value.reply !== undefined &&
            (!isRecord(value.reply) ||
                typeof value.reply.text !== "string" ||
                !value.reply.text.trim() ||
                typeof value.reply.contentHash !== "string" ||
                !/^[a-f0-9]{64}$/.test(value.reply.contentHash) ||
                !Array.isArray(value.reply.effectReceiptIds) ||
                !value.reply.effectReceiptIds.every((id) => typeof id === "string" && id.length > 0)))
            return null;
        const historySelection = parseReplyRecoveryHistorySelection(value.historySelection, value.context);
        return {
            context: value.context,
            ...(historySelection ? { historySelection } : {}),
            pendingToolCalls: value.pendingToolCalls,
            evaluatorOutputs: value.evaluatorOutputs,
            ownerExclusiveDisclosureUsed: value.ownerExclusiveDisclosureUsed,
            actionResults: value.actionResults,
            assistantMessageId: value.assistantMessageId,
            userContentHash: value.userContentHash,
            assistantContentHash: value.assistantContentHash,
            ...(value.reply !== undefined
                ? {
                    reply: value.reply,
                }
                : {}),
        };
    }
    catch {
        // error-policy:J3 malformed persisted evidence never authorizes recovery.
        return null;
    }
}
function conversationReplyRecoveryIsEligible(recovery) {
    const receipts = mergeEffectReceipts(...recovery.actionResults.map((result) => result.effectReceipts));
    const unknownCommit = recovery.actionResults.some((result) => result.data?.reconciliationRequired === true ||
        result.data?.committed === "unknown" ||
        result.values?.committed === "unknown") ||
        receipts.some((receipt) => receipt.outcome === "failed" &&
            receipt.failure.acceptance === "unknown");
    return (!unknownCommit &&
        receipts.some((receipt) => resolveAppliedUserFacingEffectReceipts({
            verifiedUserFacing: true,
            userFacingText: "Receipt eligibility",
            userFacingEffectReceiptIds: [receipt.receiptId],
        }, receipts) !== null));
}
async function persistConversationReplyRecovery(runtime, roomId, userMessageId, assistantMessageId, result, lease, assertCurrent) {
    if (!result.replyRecovery || !userMessageId || !assistantMessageId)
        return false;
    try {
        const [user] = await runtime.getMemoriesByIds([userMessageId], "messages");
        assertCurrent?.();
        const marker = readDurableConversationChatMarker(user?.content.chatIdempotency);
        if (!user ||
            user.roomId !== roomId ||
            !marker ||
            conversationClientUserMemoryId(marker.scope, marker.clientMessageId) !==
                userMessageId)
            return false;
        const [assistant] = await runtime.getMemoriesByIds([assistantMessageId], "messages");
        if (!assistant ||
            assistant.roomId !== roomId ||
            assistant.entityId !== runtime.agentId ||
            assistant.agentId !== runtime.agentId ||
            assistant.content.inReplyTo !== userMessageId)
            throw new TypeError("Reply recovery assistant does not match the original turn");
        const projected = projectCompleteToolValueForModel({
            ...result.replyRecovery,
            assistantMessageId,
            userContentHash: conversationReplyContentHash(user.content),
            assistantContentHash: conversationReplyContentHash({
                ...assistant.content,
                replyRecoveryAvailable: true,
            }),
            actionResults: result.replyRecovery.actionResults.map((action) => {
                const modelResult = projectToolResultForModel(action);
                return {
                    // Persist the producer's authoritative model projection, not live
                    // registry handles (for example a view's executable component).
                    // Context, receipts, values and the in-flight result stay intact.
                    ...modelResult,
                    // These runtime markers veto recovery even when the model-facing
                    // producer projection omits them. Never hide an uncertain commit.
                    ...(action.data?.reconciliationRequired !== undefined ||
                        action.data?.committed !== undefined
                        ? {
                            data: {
                                ...modelResult.data,
                                ...(action.data.reconciliationRequired !== undefined
                                    ? {
                                        reconciliationRequired: action.data.reconciliationRequired,
                                    }
                                    : {}),
                                ...(action.data.committed !== undefined
                                    ? { committed: action.data.committed }
                                    : {}),
                            },
                        }
                        : {}),
                    ...(action.error instanceof Error
                        ? { error: action.error.stack ?? action.error.message }
                        : {}),
                };
            }),
        }, composeToolDiagnosticRedactor(runtime));
        const serialized = JSON.stringify(projected, (_key, value) => {
            if (typeof value === "number" && !Number.isFinite(value))
                throw new TypeError("Reply recovery evidence contains a non-finite number");
            if (typeof value === "bigint" ||
                typeof value === "function" ||
                typeof value === "symbol")
                throw new TypeError("Reply recovery evidence is not JSON serializable");
            return value;
        });
        const recovery = parseDurableConversationReplyRecovery(serialized);
        if (!recovery)
            throw new TypeError("Reply recovery evidence is invalid");
        await runtime.roomHandlerQueue.runInLease(roomId, lease, () => {
            assertCurrent?.();
            return runtime.updateMemory({
                id: userMessageId,
                content: {
                    ...user.content,
                    chatIdempotency: { ...marker, replyRecoveryJson: serialized },
                },
            });
        });
        assertCurrent?.();
        if (!conversationReplyRecoveryIsEligible(recovery))
            return false;
        await runtime.roomHandlerQueue.runInLease(roomId, lease, () => {
            assertCurrent?.();
            return runtime.updateMemory({
                id: assistantMessageId,
                content: { ...assistant.content, replyRecoveryAvailable: true },
            });
        });
        assertCurrent?.();
        return true;
    }
    catch (cause) {
        // error-policy:J4 the original non-replayable failure remains visible when
        // complete recovery evidence cannot be durably retained.
        runtime.reportError("Conversation.replyRecoveryPersistence", cause, {
            roomId,
            userMessageId,
            assistantMessageId,
        });
        return false;
    }
}
const INCOMPLETE_CHAT_RECOVERY_TEXT = "The previous attempt ended before its final response was saved. It was not run again; send a new message if you want to retry.";
const MAX_DURABLE_CHAT_OUTCOME_BYTES = 256 * 1024;
const DURABLE_CHAT_OUTCOME_KEYS = new Set([
    "text",
    "agentName",
    "messageId",
    "userMessageId",
    "assistantEphemeral",
    "historyRefreshRequired",
    "transcriptVisibility",
    "thought",
    "usage",
    "actionResults",
    "failureKind",
    "terminalFailure",
    "accountConnect",
    "localInference",
    "noResponseReason",
    "interrupted",
    "replyRecoveryAvailable",
]);
function isChannelType(value) {
    return (typeof value === "string" &&
        Object.values(ChannelType).includes(value));
}
function isRecord(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
}
function isDurableChatUsage(value) {
    if (!isRecord(value))
        return false;
    const numericFields = [
        "promptTokens",
        "completionTokens",
        "totalTokens",
        "llmCalls",
    ];
    if (numericFields.some((field) => typeof value[field] !== "number" ||
        !Number.isFinite(value[field])) ||
        typeof value.isEstimated !== "boolean") {
        return false;
    }
    for (const field of [
        "cacheReadInputTokens",
        "cacheCreationInputTokens",
        "cachedInputTokens",
    ]) {
        if (value[field] !== undefined &&
            (typeof value[field] !== "number" ||
                !Number.isFinite(value[field]))) {
            return false;
        }
    }
    return ((value.model === undefined || typeof value.model === "string") &&
        (value.provider === undefined || typeof value.provider === "string"));
}
function isDurableChatActionResult(value) {
    if (!isRecord(value) || typeof value.success !== "boolean")
        return false;
    return ((value.actionName === undefined || typeof value.actionName === "string") &&
        (value.text === undefined || typeof value.text === "string") &&
        (value.error === undefined || typeof value.error === "string") &&
        (value.values === undefined || isRecord(value.values)));
}
function parseDurableConversationChatOutcome(serialized) {
    if (serialized.length === 0 ||
        Buffer.byteLength(serialized, "utf8") > MAX_DURABLE_CHAT_OUTCOME_BYTES) {
        return null;
    }
    let parsed;
    try {
        parsed = JSON.parse(serialized);
    }
    catch {
        // error-policy:J3 persisted markers are untrusted storage input.
        return null;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        return null;
    }
    const outcome = parsed;
    if (Object.keys(outcome).some((key) => !DURABLE_CHAT_OUTCOME_KEYS.has(key))) {
        return null;
    }
    if (typeof outcome.text !== "string" ||
        typeof outcome.agentName !== "string") {
        return null;
    }
    if ((outcome.messageId !== undefined && !validateUuid(outcome.messageId)) ||
        (outcome.userMessageId !== undefined &&
            !validateUuid(outcome.userMessageId)) ||
        (outcome.assistantEphemeral !== undefined &&
            typeof outcome.assistantEphemeral !== "boolean") ||
        (outcome.historyRefreshRequired !== undefined &&
            typeof outcome.historyRefreshRequired !== "boolean") ||
        (outcome.transcriptVisibility !== undefined &&
            outcome.transcriptVisibility !== "internal") ||
        (outcome.thought !== undefined && typeof outcome.thought !== "string") ||
        (outcome.usage !== undefined && !isDurableChatUsage(outcome.usage)) ||
        (outcome.actionResults !== undefined &&
            (!Array.isArray(outcome.actionResults) ||
                !outcome.actionResults.every(isDurableChatActionResult))) ||
        (outcome.failureKind !== undefined &&
            !isChatFailureKind(outcome.failureKind)) ||
        (outcome.terminalFailure !== undefined &&
            parseChatTerminalFailure(outcome.terminalFailure) === undefined) ||
        (outcome.accountConnect !== undefined &&
            normalizeAccountConnectRequest(outcome.accountConnect) === null) ||
        (outcome.localInference !== undefined &&
            !isRecord(outcome.localInference)) ||
        (outcome.noResponseReason !== undefined &&
            outcome.noResponseReason !== "ignored") ||
        (outcome.interrupted !== undefined &&
            typeof outcome.interrupted !== "boolean") ||
        (outcome.replyRecoveryAvailable !== undefined &&
            outcome.replyRecoveryAvailable !== true)) {
        return null;
    }
    const accountConnect = outcome.accountConnect === undefined
        ? undefined
        : normalizeAccountConnectRequest(outcome.accountConnect);
    const terminalFailure = parseChatTerminalFailure(outcome.terminalFailure);
    return {
        text: outcome.text,
        agentName: outcome.agentName,
        ...(typeof outcome.messageId === "string"
            ? { messageId: outcome.messageId }
            : {}),
        ...(typeof outcome.userMessageId === "string"
            ? { userMessageId: outcome.userMessageId }
            : {}),
        ...(typeof outcome.assistantEphemeral === "boolean"
            ? { assistantEphemeral: outcome.assistantEphemeral }
            : {}),
        ...(typeof outcome.historyRefreshRequired === "boolean"
            ? { historyRefreshRequired: outcome.historyRefreshRequired }
            : {}),
        ...(outcome.transcriptVisibility === "internal"
            ? { transcriptVisibility: "internal" }
            : {}),
        ...(typeof outcome.thought === "string"
            ? { thought: outcome.thought }
            : {}),
        ...(outcome.usage !== undefined
            ? { usage: outcome.usage }
            : {}),
        ...(outcome.actionResults !== undefined
            ? {
                actionResults: outcome.actionResults,
            }
            : {}),
        ...(typeof outcome.failureKind === "string"
            ? { failureKind: outcome.failureKind }
            : {}),
        ...(terminalFailure ? { terminalFailure } : {}),
        ...(accountConnect ? { accountConnect } : {}),
        ...(outcome.localInference !== undefined
            ? {
                localInference: outcome.localInference,
            }
            : {}),
        ...(outcome.noResponseReason === "ignored"
            ? { noResponseReason: "ignored" }
            : {}),
        ...(outcome.interrupted === true ? { interrupted: true } : {}),
        ...(outcome.replyRecoveryAvailable === true
            ? { replyRecoveryAvailable: true }
            : {}),
    };
}
function buildRecoveredConversationChatOutcome(memory, userMessageId, agentName) {
    const content = memory.content;
    const failureKind = parseChatFailureKind(content.failureKind);
    const terminalFailure = parseChatTerminalFailure(content.terminalFailure);
    const accountConnect = normalizeAccountConnectRequest(content.accountConnect);
    const localInference = content.localInference && typeof content.localInference === "object"
        ? content.localInference
        : undefined;
    return {
        text: typeof content.text === "string" ? content.text : "",
        agentName,
        messageId: memory.id,
        userMessageId,
        ...(content.transcriptVisibility === "internal"
            ? { transcriptVisibility: "internal" }
            : {}),
        ...(typeof content.thought === "string" && content.thought.trim()
            ? { thought: content.thought }
            : {}),
        ...(failureKind ? { failureKind } : {}),
        ...(terminalFailure ? { terminalFailure } : {}),
        ...(accountConnect ? { accountConnect } : {}),
        ...(localInference ? { localInference } : {}),
        ...(normalizeActionCallbackHistory(content.actionCallbackHistory).length > 0
            ? { historyRefreshRequired: true }
            : {}),
        ...(content.noResponseReason === "ignored"
            ? { noResponseReason: "ignored" }
            : {}),
        ...(content.interrupted === true ? { interrupted: true } : {}),
        ...(content.replyRecoveryAvailable === true
            ? { replyRecoveryAvailable: true }
            : {}),
    };
}
async function persistDurableConversationChatOutcome(runtime, roomId, scope, clientMessageId, fingerprint, outcome, roomHandlerLease, assertCurrent) {
    if (!clientMessageId)
        return;
    const userMessageId = conversationClientUserMemoryId(scope, clientMessageId);
    const [userMemory] = await runtime.getMemoriesByIds([userMessageId], "messages");
    assertCurrent?.();
    if (!userMemory || userMemory.roomId !== roomId) {
        throw new ElizaError("Durable chat outcome has no matching user message", {
            code: "CHAT_IDEMPOTENCY_USER_MEMORY_MISSING",
            context: { roomId, userMessageId, clientMessageId },
        });
    }
    const existingMarker = readDurableConversationChatMarker(userMemory.content.chatIdempotency);
    if (!existingMarker ||
        existingMarker.scope !== scope ||
        existingMarker.clientMessageId !== clientMessageId ||
        existingMarker.fingerprint !== fingerprint) {
        throw new ElizaError("Durable chat outcome does not match its original turn", {
            code: "CHAT_IDEMPOTENCY_CONFLICT",
            context: { roomId, userMessageId },
        });
    }
    await runtime.roomHandlerQueue.runInLease(roomId, roomHandlerLease, () => {
        assertCurrent?.();
        return runtime.updateMemory({
            id: userMessageId,
            content: {
                ...userMemory.content,
                chatIdempotency: {
                    ...existingMarker,
                    version: 1,
                    scope,
                    clientMessageId,
                    fingerprint,
                    outcomeJson: JSON.stringify(withoutLiveRateLimit(outcome)),
                },
            },
        });
    });
    assertCurrent?.();
}
async function recoverDurableConversationChatOutcome(runtime, roomId, scope, clientMessageId, fingerprint, agentName, roomHandlerLease, assertCurrent) {
    if (!clientMessageId)
        return { kind: "none" };
    const userMessageId = conversationClientUserMemoryId(scope, clientMessageId);
    const [userMemory] = await runtime.getMemoriesByIds([userMessageId], "messages");
    assertCurrent?.();
    if (!userMemory)
        return { kind: "none" };
    if (userMemory.roomId !== roomId) {
        return {
            kind: "conflict",
            error: new ElizaError("Idempotency user memory belongs to another room", {
                code: "CHAT_IDEMPOTENCY_CONFLICT",
                context: { roomId, userMessageId, actualRoomId: userMemory.roomId },
            }),
        };
    }
    const marker = readDurableConversationChatMarker(userMemory.content.chatIdempotency);
    if (!marker ||
        marker.scope !== scope ||
        marker.clientMessageId !== clientMessageId ||
        marker.fingerprint !== fingerprint) {
        return {
            kind: "conflict",
            error: new ElizaError("Idempotency key was reused for a different durable chat request", {
                code: "CHAT_IDEMPOTENCY_CONFLICT",
                context: { roomId, userMessageId, clientMessageId },
            }),
        };
    }
    if (marker.outcomeJson !== undefined) {
        const outcome = parseDurableConversationChatOutcome(marker.outcomeJson);
        if (!outcome) {
            return {
                kind: "conflict",
                error: new ElizaError("Durable chat outcome is invalid", {
                    code: "CHAT_IDEMPOTENCY_OUTCOME_INVALID",
                    context: { roomId, userMessageId, clientMessageId },
                }),
            };
        }
        return { kind: "settled", outcome };
    }
    const memories = await runtime.getMemories({
        roomId,
        tableName: "messages",
        start: userMemory.createdAt,
        orderBy: "createdAt",
        orderDirection: "asc",
    });
    assertCurrent?.();
    const transformedUserMessageId = createUniqueUuid(runtime, userMessageId);
    const assistant = memories
        .filter((memory) => typeof memory.id === "string" &&
        memory.entityId === runtime.agentId &&
        memory.agentId === runtime.agentId &&
        (memory.content.inReplyTo === userMessageId ||
            memory.content.inReplyTo === transformedUserMessageId))
        .at(-1);
    if (!assistant) {
        const channelType = userMemory.content.channelType;
        if (!isChannelType(channelType)) {
            return {
                kind: "conflict",
                error: new ElizaError("Incomplete durable chat request has no valid channel type", {
                    code: "CHAT_IDEMPOTENCY_INCOMPLETE_INVALID",
                    context: { roomId, userMessageId, clientMessageId, channelType },
                }),
            };
        }
        const recoveryMessageId = stringToUuid(`conversation-incomplete-recovery:${userMessageId}`);
        assertCurrent?.();
        const persisted = await persistAssistantConversationMemory(runtime, roomId, {
            text: INCOMPLETE_CHAT_RECOVERY_TEXT,
            inReplyTo: userMessageId,
            chatIdempotencyRecovery: "incomplete",
        }, channelType, undefined, recoveryMessageId, roomHandlerLease, assertCurrent);
        assertCurrent?.();
        if (!persisted?.id) {
            throw new ElizaError("Failed to persist the incomplete chat recovery terminal", {
                code: "CHAT_IDEMPOTENCY_INCOMPLETE_WRITE_FAILED",
                context: { roomId, userMessageId, clientMessageId },
            });
        }
        const outcome = {
            text: INCOMPLETE_CHAT_RECOVERY_TEXT,
            agentName,
            messageId: persisted.id,
            userMessageId,
        };
        await persistDurableConversationChatOutcome(runtime, roomId, scope, clientMessageId, fingerprint, outcome, roomHandlerLease, assertCurrent);
        return { kind: "settled", outcome };
    }
    if (assistant.content.inReplyTo !== userMessageId) {
        await runtime.roomHandlerQueue.runInLease(roomId, roomHandlerLease, () => {
            assertCurrent?.();
            return runtime.updateMemory({
                ...assistant,
                content: {
                    ...assistant.content,
                    inReplyTo: userMessageId,
                },
            });
        });
        assertCurrent?.();
        assistant.content = {
            ...assistant.content,
            inReplyTo: userMessageId,
        };
    }
    const outcome = buildRecoveredConversationChatOutcome(assistant, userMessageId, agentName);
    await persistDurableConversationChatOutcome(runtime, roomId, scope, clientMessageId, fingerprint, outcome, roomHandlerLease, assertCurrent);
    return { kind: "settled", outcome };
}
function bindClientUserMemoryId(clientMessageId, scope, fingerprint, messages) {
    if (!clientMessageId)
        return;
    const id = conversationClientUserMemoryId(scope, clientMessageId);
    messages.userMessage.id = id;
    messages.messageToStore.id = id;
    const marker = {
        version: 1,
        scope,
        clientMessageId,
        fingerprint,
    };
    messages.userMessage.content.chatIdempotency = marker;
    messages.messageToStore.content.chatIdempotency = marker;
}
async function persistClientUserMemory(runtime, memory, clientMessageId, roomHandlerLease, assertCurrent) {
    if (!clientMessageId) {
        await persistConversationMemory(runtime, memory, roomHandlerLease, assertCurrent);
        return;
    }
    await persistExactConversationMemory(runtime, memory, roomHandlerLease, assertCurrent);
}
function writeConversationDoneSse(res, outcome) {
    const { text, ...terminalMetadata } = outcome;
    writeSseJson(res, {
        ...terminalMetadata,
        type: "done",
        fullText: text,
    });
}
function buildGenerationMessageIdOutcome(result, text, messageId, terminal) {
    return {
        text,
        agentName: result.agentName,
        ...(messageId ? { messageId } : {}),
        ...terminal,
        // The streamed text does not carry display-only acknowledgment metadata.
        // Reuse the canonical history refresh after its durable reply is saved.
        ...(result.planningAcknowledgment ? { historyRefreshRequired: true } : {}),
        ...(result.transcriptVisibility
            ? { transcriptVisibility: result.transcriptVisibility }
            : {}),
        ...(result.thought ? { thought: result.thought } : {}),
        ...(result.usage ? { usage: result.usage } : {}),
        ...(result.actionResults?.length
            ? { actionResults: result.actionResults }
            : {}),
        ...(result.failureKind ? { failureKind: result.failureKind } : {}),
        ...(result.terminalFailure
            ? { terminalFailure: result.terminalFailure }
            : {}),
        ...(result.accountConnect ? { accountConnect: result.accountConnect } : {}),
        ...(result.localInference ? { localInference: result.localInference } : {}),
        ...(result.noResponseReason
            ? { noResponseReason: result.noResponseReason }
            : {}),
    };
}
function buildConversationJsonOutcome(outcome) {
    return {
        text: outcome.text,
        agentName: outcome.agentName,
        ...(outcome.messageId ? { messageId: outcome.messageId } : {}),
        ...(outcome.userMessageId ? { userMessageId: outcome.userMessageId } : {}),
        ...(outcome.assistantEphemeral ? { assistantEphemeral: true } : {}),
        ...(outcome.historyRefreshRequired ? { historyRefreshRequired: true } : {}),
        ...(outcome.transcriptVisibility
            ? { transcriptVisibility: outcome.transcriptVisibility }
            : {}),
        ...(outcome.actionResults?.length
            ? { actionResults: outcome.actionResults }
            : {}),
        ...(outcome.failureKind ? { failureKind: outcome.failureKind } : {}),
        ...(outcome.terminalFailure
            ? { terminalFailure: outcome.terminalFailure }
            : {}),
        ...(outcome.replyRecoveryAvailable
            ? { replyRecoveryAvailable: true }
            : {}),
        ...(outcome.accountConnect
            ? { accountConnect: outcome.accountConnect }
            : {}),
        ...(outcome.localInference
            ? { localInference: outcome.localInference }
            : {}),
        ...(outcome.noResponseReason
            ? { noResponseReason: outcome.noResponseReason }
            : {}),
        ...(outcome.interrupted ? { interrupted: true } : {}),
    };
}
function isCallbackHistoryPersistenceError(error) {
    return (error instanceof ElizaError &&
        error.code === "CONVERSATION_CALLBACK_HISTORY_WRITE_FAILED");
}
export async function persistRecentAssistantActionCallbackHistory(runtime, roomId, actionCallbackHistory, sinceMs, targetMemoryId, roomHandlerLease, assertCurrent) {
    const normalizedHistory = normalizeActionCallbackHistory(actionCallbackHistory);
    if (normalizedHistory.length === 0) {
        return false;
    }
    const persist = async () => {
        const recent = targetMemoryId
            ? await runtime.getMemoriesByIds([targetMemoryId], "messages")
            : await runtime.getMemories({
                roomId,
                tableName: "messages",
            });
        assertCurrent?.();
        const target = recent
            .filter((memory) => memory.roomId === roomId &&
            memory.agentId === runtime.agentId &&
            memory.entityId === runtime.agentId)
            .filter((memory) => {
            const content = memory.content;
            const createdAt = memory.createdAt ?? 0;
            return (typeof memory.id === "string" &&
                typeof content?.text === "string" &&
                content.text.trim().length > 0 &&
                (targetMemoryId
                    ? memory.id === targetMemoryId
                    : createdAt >= sinceMs - 2000));
        })
            .sort(compareMemoriesByCreatedAt)
            .at(-1);
        if (!target || typeof target.id !== "string") {
            if (targetMemoryId) {
                throw new ElizaError("Exact assistant memory for callback history was not found", {
                    code: "CONVERSATION_CALLBACK_TARGET_NOT_FOUND",
                    context: { roomId, targetMemoryId },
                });
            }
            return false;
        }
        const content = target.content && typeof target.content === "object"
            ? target.content
            : { text: "" };
        const existingHistory = normalizeActionCallbackHistory(content.actionCallbackHistory);
        const mergedHistory = mergeActionCallbackHistory(existingHistory, normalizedHistory);
        if (mergedHistory.length === existingHistory.length &&
            mergedHistory.every((entry, index) => entry === existingHistory[index])) {
            return true;
        }
        assertCurrent?.();
        await runtime.updateMemory({
            id: target.id,
            content: {
                ...content,
                actionCallbackHistory: mergedHistory,
            },
        });
        assertCurrent?.();
        return true;
    };
    try {
        if (runtime.roomHandlerQueue.ownsLease(roomId, roomHandlerLease)) {
            return await runtime.roomHandlerQueue.runInLease(roomId, roomHandlerLease, persist);
        }
        return await runtime.roomHandlerQueue.withLease(roomId, async (lease) => runtime.roomHandlerQueue.runInLease(roomId, lease, persist));
    }
    catch (cause) {
        throw new ElizaError("Failed to persist action callback history", {
            code: "CONVERSATION_CALLBACK_HISTORY_WRITE_FAILED",
            cause,
            context: { roomId, targetMemoryId },
        });
    }
}
async function getConversationWithRestore(state, convId) {
    const existing = state.conversations.get(convId);
    if (existing)
        return existing;
    await waitForConversationRestore(state);
    const restored = state.conversations.get(convId);
    if (restored || !state.runtime)
        return restored;
    return restoreConversationFromDb(state.runtime, state, convId);
}
/** Default recent-window size for GET /messages (the newest N turns). */
const CONVERSATION_MESSAGE_WINDOW = 200;
/**
 * Default page size for the `?before=<cursor>` load-older path (infinite
 * upward scroll, #13532). Smaller than the initial recent window: each
 * scroll-up prepends one page, so a page that is quick to fetch and paint
 * keeps the prefetch ahead of the reader without a large single reflow.
 */
const CONVERSATION_OLDER_PAGE_SIZE = 50;
/**
 * How many messages on EACH side of an `?around=<id>` pivot to load. The
 * centered window is roughly 2× this plus the pivot itself.
 */
const CONVERSATION_AROUND_RADIUS = 100;
/**
 * Load a window of messages CENTERED on `aroundMessageId` for the jump-to-message
 * flow (#9955). The default GET /messages window is the most-recent
 * CONVERSATION_MESSAGE_WINDOW turns, so a keyword-search hit older than that is
 * never in the loaded thread and can't be scrolled to. Given the pivot's id this
 * returns the pivot's own turn plus up to CONVERSATION_AROUND_RADIUS older and
 * newer turns, ordered chronologically by the caller.
 *
 * Each side is a store keyset on `(createdAt, id)` so a burst of messages in
 * the pivot's millisecond cannot push the pivot itself out of both capped
 * halves. Returns the recent window unchanged when the pivot is missing or
 * lives in another room — the latter prevents a cross-room leak via a forged
 * `around` id.
 */
async function loadConversationMessagesAround(runtime, roomId, aroundMessageId) {
    const [pivot] = await runtime.getMemoriesByIds([aroundMessageId], "messages");
    if (!pivot || pivot.roomId !== roomId || !pivot.id) {
        logger.warn(`[conversations] around=${aroundMessageId} is not in room ${roomId}; serving the recent window instead`);
        return runtime.getMemories({
            roomId,
            tableName: "messages",
            limit: CONVERSATION_MESSAGE_WINDOW,
        });
    }
    const cursor = { createdAt: pivot.createdAt ?? 0, id: pivot.id };
    const [older, newer] = await Promise.all([
        runtime.getMemories({
            roomId,
            tableName: "messages",
            cursor,
            limit: CONVERSATION_AROUND_RADIUS,
            orderBy: "createdAt",
            orderDirection: "desc",
        }),
        runtime.getMemories({
            roomId,
            tableName: "messages",
            cursor,
            limit: CONVERSATION_AROUND_RADIUS,
            orderBy: "createdAt",
            orderDirection: "asc",
        }),
    ]);
    const byId = new Map();
    for (const memory of [pivot, ...older, ...newer]) {
        if (memory.id) {
            byId.set(memory.id, memory);
        }
    }
    return Array.from(byId.values());
}
/**
 * Parse the `?before=<createdAt>` cursor: a non-negative integer millisecond
 * timestamp (the createdAt of the client's current oldest message). Returns
 * null for absent, malformed, or negative values so the handler falls back
 * to the recent window instead of paging from a bogus cursor. Zero is the
 * Unix epoch and must page: treating it as missing reloads the recent window
 * above a client that already holds that row.
 */
function parseBeforeCursor(raw) {
    if (raw === null)
        return null;
    const trimmed = raw.trim();
    if (trimmed === "" || !/^\d+$/.test(trimmed))
        return null;
    const value = Number(trimmed);
    return Number.isSafeInteger(value) && value >= 0 ? value : null;
}
/**
 * Clamp the `?limit=N` older-page size to a sane range. Defaults to
 * CONVERSATION_OLDER_PAGE_SIZE and caps at CONVERSATION_MESSAGE_WINDOW so a
 * client can't request an unbounded page.
 */
function clampOlderPageLimit(raw) {
    if (raw === null)
        return CONVERSATION_OLDER_PAGE_SIZE;
    const parsed = Number(raw.trim());
    if (!Number.isFinite(parsed) || parsed <= 0) {
        return CONVERSATION_OLDER_PAGE_SIZE;
    }
    return Math.min(Math.floor(parsed), CONVERSATION_MESSAGE_WINDOW);
}
/**
 * Load one page of messages strictly older than the cursor for the infinite
 * upward scroll (#13532). `before` is the createdAt of the oldest message the
 * client already holds. The page comes back newest-first from the store so the
 * caller can prepend it above the current top.
 *
 * When the client names the cursor row with `beforeId`, the store keyset
 * `(createdAt, id)` keeps every other message in that millisecond and still
 * excludes the cursor. A timestamp alone cannot tell those siblings apart, so
 * that older contract stays `end: before - 1`. One extra row beyond `limit`
 * computes `hasMore` without a second COUNT query; the caller trims it.
 */
async function loadConversationMessagesBefore(runtime, roomId, before, limit, beforeId) {
    const rows = await runtime.getMemories({
        roomId,
        tableName: "messages",
        // Timestamp-only callers cannot name one row inside a shared millisecond,
        // so they keep the exclusive `before - 1` bound. A keyset cursor is already
        // exclusive and must not also apply that bound, or the siblings disappear.
        ...(beforeId
            ? { cursor: { createdAt: before, id: beforeId } }
            : { end: before - 1 }),
        limit: limit + 1,
        orderBy: "createdAt",
        orderDirection: "desc",
    });
    const hasMore = rows.length > limit;
    return { memories: hasMore ? rows.slice(0, limit) : rows, hasMore };
}
function extractConversationMetaString(memory, key) {
    const meta = memory.metadata && typeof memory.metadata === "object"
        ? memory.metadata
        : undefined;
    const value = meta?.[key];
    return typeof value === "string" && value.length > 0 ? value : undefined;
}
// Attachment DTO shaping + per-viewer disclosure selection live in the
// use-case module (#14781); the serializer is re-exported for existing
// importers of this route module.
export { serializeMessageAttachments } from "./attachment-disclosure.js";
// Greeting lookup and persistence share the room's history-writer boundary.
// This keeps concurrent hydration/create callers behind the same committed row
// without publishing a separate single-flight promise that can invert ownership.
async function ensureConversationGreetingStored(state, conv, lang, roomHandlerLease) {
    const runtime = state.runtime;
    if (!runtime) {
        return ensureConversationGreetingStoredUnlocked(state, conv, lang);
    }
    if (roomHandlerLease) {
        return runtime.roomHandlerQueue.runInLease(conv.roomId, roomHandlerLease, () => ensureConversationGreetingStoredUnlocked(state, conv, lang, roomHandlerLease));
    }
    return runtime.roomHandlerQueue.withLease(conv.roomId, (lease) => ensureConversationGreetingStoredUnlocked(state, conv, lang, lease));
}
async function ensureConversationGreetingStoredUnlocked(state, conv, _lang, _roomHandlerLease) {
    const runtime = state.runtime;
    const agentName = runtime?.character.name ?? state.agentName;
    if (!runtime) {
        return {
            text: "",
            agentName,
            generated: false,
            persisted: false,
        };
    }
    let memories;
    try {
        memories = await runtime.getMemories({
            roomId: conv.roomId,
            tableName: "messages",
        });
    }
    catch (error) {
        // error-policy:J2 greeting setup retains the storage cause for the route
        // boundary instead of fabricating an empty conversation.
        throw new ElizaError("Failed to inspect conversation messages", {
            code: "CONVERSATION_GREETING_READ_FAILED",
            cause: error,
            context: { conversationId: conv.id },
        });
    }
    memories.sort(compareMemoriesByCreatedAt);
    const existingGreeting = memories.find((memory) => {
        const content = memory.content;
        return (memory.entityId === runtime.agentId &&
            content?.source === MESSAGE_SOURCE_AGENT_GREETING &&
            typeof content.text === "string" &&
            content.text.trim().length > 0);
    });
    if (existingGreeting) {
        return {
            text: String(existingGreeting.content
                ?.text ?? ""),
            agentName,
            generated: true,
            persisted: false,
        };
    }
    if (memories.length > 0) {
        return {
            text: "",
            agentName,
            generated: false,
            persisted: false,
        };
    }
    // Character examples are prompt material, never fabricated assistant turns.
    // New conversations wait for a real turn through the Eliza pipeline.
    return { text: "", agentName, generated: false, persisted: false };
}
// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------
const MESSAGE_SEARCH_DEFAULT_LIMIT = 20;
const MESSAGE_SEARCH_MAX_LIMIT = 50;
const MESSAGE_SEARCH_SNIPPET_RADIUS = 72;
function clampMessageSearchLimit(value) {
    const parsed = parsePositiveInteger(value, MESSAGE_SEARCH_DEFAULT_LIMIT);
    return Math.min(parsed, MESSAGE_SEARCH_MAX_LIMIT);
}
function normalizeMessageSearchQuery(value) {
    return (value === null ? "" : value).trim().replace(/\s+/g, " ");
}
function isLegacyViewsInventoryContent(content) {
    const text = typeof content.text === "string" ? content.text.trim() : "";
    if (!/^available_views:\s*(?:\n|$)/.test(text))
        return false;
    const callbackHistory = normalizeActionCallbackHistory(content.actionCallbackHistory);
    if (callbackHistory.length > 0 && text === callbackHistory.join("\n")) {
        return true;
    }
    return (/^views\[\d+\]\{id,label,type,path,available\}:/m.test(text) ||
        /^\s*count:\s*0\s*$/m.test(text));
}
/**
 * Parse an optional `since`/`until` search param into epoch ms. Accepts a
 * non-negative epoch-ms integer or any `Date.parse`-able string (ISO 8601).
 * Absent → `null`; present-but-unparseable → `"invalid"` so the route can 400
 * instead of silently searching an unbounded window the caller didn't ask for.
 */
function parseMessageSearchTime(value) {
    if (value === null)
        return null;
    const trimmed = value.trim();
    if (!trimmed)
        return "invalid";
    if (/^\d+$/.test(trimmed)) {
        const epochMs = Number(trimmed);
        return Number.isSafeInteger(epochMs) ? epochMs : "invalid";
    }
    const parsed = Date.parse(trimmed);
    return Number.isNaN(parsed) ? "invalid" : parsed;
}
/** A `…keyword…` excerpt around the first match, or a head-truncated fallback. */
function buildMessageSearchSnippet(text, query) {
    const normalizedText = text.replace(/\s+/g, " ").trim();
    if (!normalizedText)
        return "";
    const index = normalizedText.toLowerCase().indexOf(query.toLowerCase());
    if (index < 0) {
        return normalizedText.length <= MESSAGE_SEARCH_SNIPPET_RADIUS * 2
            ? normalizedText
            : `${normalizedText.slice(0, MESSAGE_SEARCH_SNIPPET_RADIUS * 2).trimEnd()}...`;
    }
    const start = Math.max(0, index - MESSAGE_SEARCH_SNIPPET_RADIUS);
    const end = Math.min(normalizedText.length, index + query.length + MESSAGE_SEARCH_SNIPPET_RADIUS);
    const prefix = start > 0 ? "..." : "";
    const suffix = end < normalizedText.length ? "..." : "";
    return `${prefix}${normalizedText.slice(start, end).trim()}${suffix}`;
}
// Match the method and path once. Handlers retain their domain authorization,
// room leases and effect/delivery ownership; dispatch grants no authority.
const conversationEndpoints = [
    { method: "GET", path: /^\/api\/conversations$/, handle: listConversations },
    {
        method: "GET",
        path: /^\/api\/conversations\/messages\/search$/,
        handle: searchConversationMessages,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/dev\/seed-messages$/,
        handle: seedConversationMessages,
    },
    {
        method: "POST",
        path: /^\/api\/conversations$/,
        handle: createConversation,
    },
    {
        method: "GET",
        path: /^\/api\/conversations\/[^/]+\/messages$/,
        handle: listConversationMessages,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/import$/,
        handle: importConversation,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/messages\/truncate$/,
        handle: truncateConversationMessagesRoute,
    },
    {
        method: "DELETE",
        path: /^\/api\/conversations\/[^/]+\/messages\/[^/]+$/,
        handle: deleteConversationMessageRoute,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/messages\/[^/]+\/retry-reply$/,
        handle: retryConversationReply,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/messages\/[^/]+\/heard$/,
        handle: recordHeardConversationMessageRoute,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/messages\/stream$/,
        handle: streamConversationMessage,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/messages$/,
        handle: sendConversationMessage,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/[^/]+\/greeting$/,
        handle: greetConversation,
    },
    {
        method: "PATCH",
        path: /^\/api\/conversations\/(?!messages$)[^/]+$/,
        handle: patchConversation,
    },
    {
        method: "POST",
        path: /^\/api\/conversations\/cleanup-empty$/,
        handle: cleanupEmptyConversations,
    },
    {
        method: "DELETE",
        path: /^\/api\/conversations\/(?!messages$)[^/]+$/,
        handle: deleteConversation,
    },
];
export async function handleConversationRoutes(ctx) {
    const requestStartedAt = Date.now();
    const endpoint = conversationEndpoints.find(({ method, path }) => method === ctx.method && path.test(ctx.pathname));
    if (!endpoint)
        return false;
    const handle = () => endpoint.handle({
        ...ctx,
        requestStartedAt,
        trustedApiPrincipal: resolveTrustedApiPrincipal(ctx.req, ctx.callerAuthorization),
        requestUrl: new URL(ctx.req.url ?? "", `http://${ctx.req.headers.host ?? "localhost"}`),
    });
    if (ctx.req.headers["x-eliza-device-id"] ||
        ctx.req.headers["x-eliza-device-key"]) {
        const credential = deviceRequestCredential(ctx.req, ctx.callerAuthorization);
        if (!credential || !ctx.state.runtime) {
            ctx.error(ctx.res, "Authenticated device session required", 401);
            return true;
        }
        // The bound identity is never copied from message metadata or model parameters.
        let authenticated = false;
        const authenticatedRuntime = ctx.state.runtime;
        const authenticatedCaller = resolveConversationCaller(ctx.req, ctx.state, resolveTrustedApiPrincipal(ctx.req, ctx.callerAuthorization), authenticatedRuntime);
        try {
            return await withDeviceActionTurn(ctx.state.runtime, credential, async () => {
                authenticated = true;
                return handle();
            }, {
                requestCaller: {
                    subjectUserId: credential.subjectUserId,
                    entityId: authenticatedCaller.entityId,
                    role: authenticatedCaller.role,
                },
                isCurrent: () => !ctx.req.aborted &&
                    !ctx.res.destroyed &&
                    !ctx.res.writableEnded &&
                    ctx.state.runtime === authenticatedRuntime,
            });
        }
        catch (error) {
            if (authenticated)
                throw error;
            if (!(error instanceof DeviceActionError)) {
                ctx.state.runtime.reportError("DeviceActionService", new Error("Device authentication store failed"), { code: "DEVICE_STORE_FAILURE" });
            }
            ctx.error(ctx.res, "Device unavailable", error instanceof DeviceActionError &&
                error.code !== "DEVICE_STORE_UNAVAILABLE"
                ? 403
                : 503);
            return true;
        }
    }
    return handle();
}
async function listConversations(ctx) {
    const { req, res, json, state } = ctx;
    await waitForConversationRestore(state);
    const waifuAccess = resolveWaifuChatAccess(req);
    const convos = Array.from(state.conversations.values())
        .filter((c) => !state.deletedConversationIds.has(c.id))
        .filter((c) => canWaifuAccessConversation(waifuAccess, c))
        .sort(compareConversationsByRecency);
    json(res, { conversations: convos });
    return true;
}
async function searchConversationMessages(ctx) {
    const { req, res, json, error, state, requestUrl } = ctx;
    if (!state.runtime) {
        error(res, "Agent runtime not available", 503);
        return true;
    }
    const query = normalizeMessageSearchQuery(requestUrl.searchParams.get("q"));
    if (query.length < 2) {
        error(res, "Search query must be at least 2 characters", 400);
        return true;
    }
    const limit = clampMessageSearchLimit(requestUrl.searchParams.get("limit"));
    const offset = parsePositiveInteger(requestUrl.searchParams.get("offset"), 0);
    // Optional inclusive time window (epoch ms or ISO 8601): "messages from a
    // year ago" is `until=<9 months ago>` etc. Garbage input is a 400, never a
    // silently ignored filter.
    const since = parseMessageSearchTime(requestUrl.searchParams.get("since"));
    const until = parseMessageSearchTime(requestUrl.searchParams.get("until"));
    if (since === "invalid" || until === "invalid") {
        error(res, "since/until must be an epoch-ms timestamp or an ISO 8601 date", 400);
        return true;
    }
    if (since !== null && until !== null && since > until) {
        error(res, "since must not be later than until", 400);
        return true;
    }
    const runtime = state.runtime;
    const waifuAccess = resolveWaifuChatAccess(req);
    // The room scope below is read from the in-memory conversation list. Wait
    // for the boot-time restore, or a search during startup would answer "no
    // matches" for conversations that are not loaded yet.
    await waitForConversationRestore(state);
    const conversationsByRoomId = new Map();
    for (const conv of state.conversations.values()) {
        if (state.deletedConversationIds.has(conv.id))
            continue;
        if (!canWaifuAccessConversation(waifuAccess, conv))
            continue;
        conversationsByRoomId.set(conv.roomId, conv);
    }
    // Scope the keyword search to the rooms the requester can actually see, in
    // SQL. Filtering after a global LIMIT (newest-N across *all* the agent's
    // rooms — discord/telegram/inbox/deleted/…) would silently drop accessible
    // matches that fall outside that window. Pushing the room set into the store
    // applies LIMIT/OFFSET after access-scoping.
    const accessibleRoomIds = Array.from(conversationsByRoomId.keys());
    if (accessibleRoomIds.length === 0) {
        json(res, { results: [], count: 0 });
        return true;
    }
    try {
        // Corpus-wide FTS + trigram ranking in the store (#13534). Visibility
        // filters used to run after LIMIT, so a page of internal or legacy
        // inventory rows came back empty even when a visible match existed
        // further down the ranking. Scan raw hits until the requested visible
        // page is filled.
        const batchSize = Math.max(limit, 32);
        const needed = offset + limit;
        const visibleHits = [];
        let rawOffset = 0;
        while (visibleHits.length < needed) {
            const hits = await runtime.searchMessages({
                roomIds: accessibleRoomIds,
                query,
                tableName: "messages",
                limit: batchSize,
                offset: rawOffset,
                ...(since !== null ? { since } : {}),
                ...(until !== null ? { until } : {}),
            });
            if (hits.length === 0)
                break;
            rawOffset += hits.length;
            for (const hit of hits) {
                const roomId = hit.memory.roomId;
                const conversation = roomId
                    ? conversationsByRoomId.get(roomId)
                    : undefined;
                if (!roomId || !conversation)
                    continue;
                const content = hit.memory.content;
                if (content?.transcriptVisibility === "internal")
                    continue;
                if (content &&
                    hit.memory.entityId === runtime.agentId &&
                    isLegacyViewsInventoryContent(content)) {
                    continue;
                }
                const text = content?.text;
                if (typeof text !== "string" || !text.trim() || !hit.memory.id)
                    continue;
                if (typeof hit.memory.createdAt !== "number")
                    continue;
                visibleHits.push(hit);
            }
            if (hits.length < batchSize)
                break;
        }
        const results = visibleHits.slice(offset, offset + limit).flatMap((hit) => {
            const roomId = hit.memory.roomId;
            const conversation = roomId
                ? conversationsByRoomId.get(roomId)
                : undefined;
            if (!roomId || !conversation || !hit.memory.id)
                return [];
            const content = hit.memory.content;
            const text = content.text;
            if (typeof text !== "string")
                return [];
            const rawText = text.trim();
            const score = hit.ftsRank > 0 ? hit.ftsRank : hit.trigramSimilarity;
            return [
                {
                    messageId: hit.memory.id,
                    conversationId: conversation.id,
                    roomId,
                    role: (hit.memory.entityId === runtime.agentId
                        ? "assistant"
                        : "user"),
                    text: rawText,
                    snippet: buildMessageSearchSnippet(rawText, query),
                    createdAt: hit.memory.createdAt,
                    score,
                },
            ];
        });
        logger.info({
            queryLength: query.length,
            limit,
            offset,
            ...(since !== null ? { since } : {}),
            ...(until !== null ? { until } : {}),
            rawHits: rawOffset,
            results: results.length,
        }, "[ConversationSearch] FTS message search completed");
        json(res, { results, count: results.length });
        return true;
    }
    catch (err) {
        logger.error({ error: getErrorMessage(err) }, "[ConversationSearch] keyword message search failed");
        error(res, "Failed to search conversation messages", 500);
        return true;
    }
}
async function seedConversationMessages(ctx) {
    const { req, res, readJsonBody, json, error, state } = ctx;
    // 404 (not 403) in production so the route's existence isn't advertised.
    if (process.env.NODE_ENV === "production") {
        error(res, "Not found", 404);
        return true;
    }
    if (!state.runtime) {
        error(res, "Agent runtime not available", 503);
        return true;
    }
    const rawSeed = await readJsonBody(req, res);
    if (rawSeed === null)
        return true;
    const parsedSeed = PostSeedMessagesRequestSchema.safeParse(rawSeed);
    if (!parsedSeed.success) {
        error(res, parsedSeed.error.issues[0]?.message ?? "Invalid request body", 400);
        return true;
    }
    await waitForConversationRestore(state);
    const corpus = generateMessageCorpus({
        ...(parsedSeed.data.conversations !== undefined
            ? { conversationCount: parsedSeed.data.conversations }
            : {}),
        ...(parsedSeed.data.messagesPerConversation !== undefined
            ? { messagesPerConversation: parsedSeed.data.messagesPerConversation }
            : {}),
        ...(parsedSeed.data.spanMonths !== undefined
            ? { spanMonths: parsedSeed.data.spanMonths }
            : {}),
        ...(parsedSeed.data.factsPerConversation !== undefined
            ? { factsPerConversation: parsedSeed.data.factsPerConversation }
            : {}),
        ...(parsedSeed.data.seed !== undefined
            ? { seed: parsedSeed.data.seed }
            : {}),
    });
    const summary = await seedMessageCorpus(state.runtime, corpus);
    // Register the seeded conversations in the live in-memory list so they are
    // visible + searchable immediately, without waiting for a restart-restore.
    for (const conv of summary.conversations) {
        state.conversations.set(conv.id, {
            id: conv.id,
            title: conv.title,
            roomId: conv.roomId,
            createdAt: new Date(conv.createdAt).toISOString(),
            updatedAt: new Date(conv.lastMessageAt ?? conv.createdAt).toISOString(),
        });
    }
    logger.info({
        conversations: summary.conversations.length,
        messages: summary.messagesCreated,
        facts: summary.factsCreated,
        oldestMessageAt: summary.oldestMessageAt,
        newestMessageAt: summary.newestMessageAt,
    }, "[ConversationSearch] seeded backdated message corpus");
    json(res, {
        conversations: summary.conversations.length,
        messagesCreated: summary.messagesCreated,
        factsCreated: summary.factsCreated,
        oldestMessageAt: summary.oldestMessageAt,
        newestMessageAt: summary.newestMessageAt,
        sampleQueries: summary.sampleQueries,
    });
    return true;
}
async function createConversation(ctx) {
    const { req, res, readJsonBody, json, error, state, trustedApiPrincipal } = ctx;
    const rawConv = await readJsonBody(req, res);
    if (rawConv === null)
        return true;
    const parsedConv = PostConversationRequestSchema.safeParse(rawConv);
    if (!parsedConv.success) {
        error(res, parsedConv.error.issues[0]?.message ?? "Invalid request body", 400);
        return true;
    }
    const body = parsedConv.data;
    await waitForConversationRestore(state);
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const roomId = stringToUuid(`web-conv-${id}`);
    const metadata = addWaifuConversationOwnerMetadata(req, sanitizeConversationMetadata(body.metadata));
    const conv = {
        id,
        title: body.title?.trim() || "New Chat",
        roomId,
        ...(metadata ? { metadata } : {}),
        createdAt: now,
        updatedAt: now,
    };
    // Registered before room setup so a concurrent request for this id (the
    // greeting route discovers in-flight conversations through the list)
    // serializes on the room queue instead of answering 404.
    state.conversations.set(id, conv);
    let greeting;
    const runtime = state.runtime;
    if (runtime) {
        try {
            prepareConversationConnectionRoom(runtime, conv.roomId);
            await ensureConversationRoom(state, runtime, conv, resolveConversationCaller(req, state, trustedApiPrincipal, runtime));
            await syncConversationRoomState(state, conv);
            if (body.includeGreeting === true) {
                const storedGreeting = await ensureConversationGreetingStored(state, conv, typeof body.lang === "string" ? body.lang : "en");
                if (storedGreeting.text.trim()) {
                    greeting = {
                        text: storedGreeting.text,
                        agentName: storedGreeting.agentName,
                        generated: storedGreeting.generated,
                        persisted: storedGreeting.persisted,
                    };
                }
            }
        }
        catch (err) {
            // error-policy:J1 boundary translation — withdraw the registration
            // so the failed room setup leaves no listed conversation without a
            // backing room; the identity check keeps a replaced entry intact.
            if (state.conversations.get(id) === conv) {
                state.conversations.delete(id);
            }
            error(res, `Failed to initialize conversation: ${getErrorMessage(err)}`, 500);
            return true;
        }
    }
    json(res, { conversation: conv, ...(greeting ? { greeting } : {}) });
    return true;
}
/** A wallet-scoped waifu conversation belongs to that wallet, not the owner. */
function isOwnerConversation(conv) {
    return (!getWaifuChatOwnerWallet(conv) || conv.metadata?.waifuChatRole === "admin");
}
const ownerConversationCreations = new WeakMap();
/** Bind prompt creation to the admitted runtime across asynchronous restoration. */
export async function resolvePromptDeliveryRoom(state, runtime) {
    if (runtime !== state.runtime) {
        throw new Error("Runtime changed before prompt automation creation");
    }
    const conversation = await ensureOwnerConversation(state, state.runtime);
    if (runtime !== state.runtime) {
        throw new Error("Runtime changed during prompt automation creation");
    }
    return conversation.roomId;
}
/**
 * Resolve the owner's canonical app conversation: the active one, else the
 * most recently updated, restoring persisted conversations first. When the
 * agent has no conversation yet, create one through the same room setup as
 * `POST /api/conversations` so owner-addressed deliveries persist durably and
 * are listed when a client connects. Concurrent callers share one creation.
 */
export async function ensureOwnerConversation(state, runtime) {
    await waitForConversationRestore(state);
    // A registered provisional conversation is not ready until room setup settles.
    const pending = ownerConversationCreations.get(state.conversations);
    if (pending)
        return pending;
    const active = state.activeConversationId
        ? state.conversations.get(state.activeConversationId)
        : undefined;
    if (active && isOwnerConversation(active))
        return active;
    const recent = Array.from(state.conversations.values())
        .filter(isOwnerConversation)
        .sort(compareConversationsByRecency)[0];
    if (recent)
        return recent;
    const creation = (async () => {
        const id = crypto.randomUUID();
        const now = new Date().toISOString();
        const conv = {
            id,
            title: "New Chat",
            roomId: stringToUuid(`web-conv-${id}`),
            createdAt: now,
            updatedAt: now,
        };
        state.conversations.set(id, conv);
        try {
            prepareConversationConnectionRoom(runtime, conv.roomId);
            await ensureConversationRoom(state, runtime, conv, {
                entityId: ensureAdminEntityIdForRuntime(state, runtime),
                role: "OWNER",
                userName: resolveAppUserName(state.config),
                grantSource: "owner",
            });
            await syncConversationRoomState(state, conv);
        }
        catch (err) {
            // error-policy:J1 withdraw the registration so a failed room setup
            // leaves no listed conversation without a backing room; the caller
            // records the delivery failure.
            if (state.conversations.get(id) === conv) {
                state.conversations.delete(id);
            }
            throw err;
        }
        state.broadcastWs?.({ type: "conversation-updated", conversation: conv });
        return conv;
    })();
    ownerConversationCreations.set(state.conversations, creation);
    try {
        return await creation;
    }
    finally {
        ownerConversationCreations.delete(state.conversations);
    }
}
async function listConversationMessages(ctx) {
    const { req, res, pathname, json, error, state, requestUrl } = ctx;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    if (!state.runtime) {
        error(res, "Agent runtime not available", 503);
        return true;
    }
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res)) {
        return true;
    }
    const runtime = state.runtime;
    try {
        // `?around=<messageId>` centers the window on a specific (possibly
        // far-back) message so a keyword-search jump can scroll to a hit older
        // than the default recent window (#9955). Absent → unchanged recent window.
        const aroundParam = validateUuid(requestUrl.searchParams.get("around"));
        // `?before=<createdAt>&beforeId=<id>&limit=N` loads one page strictly older
        // than the cursor for the infinite upward scroll (#13532). `beforeId` is
        // the oldest message the client already holds, so other messages in that
        // same millisecond stay reachable. Timestamp-only `before` remains the
        // previous exclusive bound. Mutually exclusive with `around`.
        const beforeParam = parseBeforeCursor(requestUrl.searchParams.get("before"));
        const beforeIdRaw = requestUrl.searchParams.get("beforeId");
        const beforeId = beforeIdRaw === null ? null : validateUuid(beforeIdRaw);
        if (beforeIdRaw !== null && (beforeParam === null || beforeId === null)) {
            error(res, "beforeId must be a UUID paired with before", 400);
            return true;
        }
        const olderLimit = clampOlderPageLimit(requestUrl.searchParams.get("limit"));
        let hasMore = false;
        let pageLimit = CONVERSATION_MESSAGE_WINDOW;
        let memories;
        if (!aroundParam && beforeParam !== null) {
            const page = await loadConversationMessagesBefore(runtime, conv.roomId, beforeParam, olderLimit, beforeId ?? undefined);
            memories = page.memories;
            hasMore = page.hasMore;
            pageLimit = olderLimit;
        }
        else {
            memories = aroundParam
                ? await loadConversationMessagesAround(runtime, conv.roomId, aroundParam)
                : await runtime.getMemories({
                    roomId: conv.roomId,
                    tableName: "messages",
                    limit: CONVERSATION_MESSAGE_WINDOW,
                });
            hasMore = !aroundParam && memories.length === CONVERSATION_MESSAGE_WINDOW;
        }
        const agentId = runtime.agentId;
        // Per-viewer attachment disclosure (#14781): a boundary-role viewer
        // token (WaifuChat, artifact share-viewer) carries a principal; trunk
        // owner tokens match no resolver, so the local dashboard resolves no
        // context and serves the full DTO unchanged.
        const viewerAccessContext = resolveHttpAccessContext(req);
        // Rows arrive sorted oldest first (see the reads below).
        const projectMessages = (rows) => rows
            // Scheduler instructions are model input, not a user-authored chat turn.
            // Project them out only here; stored history and assistant replies stay intact.
            .filter((m) => m.entityId === agentId ||
            m.content.source !== MESSAGE_SOURCE_TRIGGER_PROMPT)
            .map((m) => {
            const contentSource = m.content?.source;
            const content = m.content;
            const meta = m.metadata;
            const entityName = meta?.entityName;
            const replyToAuthor = meta?.replyToAuthor && typeof meta.replyToAuthor === "object"
                ? meta.replyToAuthor
                : null;
            const normalizedSource = typeof contentSource === "string" &&
                contentSource.length > 0 &&
                contentSource !== MESSAGE_SOURCE_CLIENT_CHAT
                ? contentSource
                : undefined;
            const actionName = typeof content.action === "string" && content.action.length > 0
                ? content.action
                : undefined;
            const actionCallbackHistory = normalizeActionCallbackHistory(content.actionCallbackHistory);
            const transcriptVisibility = content.transcriptVisibility === "internal"
                ? "internal"
                : undefined;
            // The failed assistant turn carries its classification on the live
            // result (`content.failureKind`) or, for synthetic fallbacks, on
            // `metadata.chatFailureKind` (markSyntheticChatFailureContent). Round
            // it back so the renderer's provider/credits gate + Retry survive the
            // GET /messages full-replace instead of vanishing.
            const rawFailureKind = typeof content.failureKind === "string"
                ? content.failureKind
                : typeof meta?.chatFailureKind === "string"
                    ? meta.chatFailureKind
                    : undefined;
            const legacyNotice = m.entityId === agentId &&
                content.metadata &&
                typeof content.metadata === "object" &&
                "escalation" in content.metadata &&
                content.metadata.escalation === true &&
                typeof content.text === "string"
                ? projectLegacySystemNotice(content.text)
                : undefined;
            const systemNotice = m.entityId === agentId
                ? (readSystemNotice(content.systemNotice) ??
                    legacyNotice?.systemNotice ??
                    (contentSource === "lifeops-scheduled-task" &&
                        typeof content.text === "string" &&
                        isLegacyUnavailableCheckin(content.text)
                        ? "runtime-error"
                        : undefined))
                : undefined;
            const failureKind = systemNotice === "model-unavailable" ||
                systemNotice === "model-and-runtime-error"
                ? "no_provider"
                : parseChatFailureKind(rawFailureKind);
            const terminalFailure = parseChatTerminalFailure(content.terminalFailure);
            // The CONNECT_ACCOUNT action stamps `content.accountConnect` on the
            // assistant memory. Validate + round-trip it so the inline
            // AddAccountDialog entry point survives the GET /messages replace.
            const accountConnect = normalizeAccountConnectRequest(content.accountConnect);
            const role = m.entityId === agentId ? "assistant" : "user";
            const userTextFormat = role === "user"
                ? parseChatUserTextFormat(isRecord(content.metadata)
                    ? content.metadata.userTextFormat
                    : undefined)
                : undefined;
            // Only a marker bound to this row's own ID names its client turn.
            const chatMarker = role === "user"
                ? readDurableConversationChatMarker(content.chatIdempotency)
                : undefined;
            const clientMessageId = chatMarker &&
                conversationClientUserMemoryId(chatMarker.scope, chatMarker.clientMessageId) === m.id
                ? chatMarker.clientMessageId
                : undefined;
            const interrupted = content.interrupted === true;
            const rawText = formatConversationMessageText(m.content?.text ?? "", actionCallbackHistory);
            // An interrupted receipt may intentionally have no model text. Keep
            // its exact partial reply; the interruption metadata owns its status.
            const text = transcriptVisibility === "internal"
                ? ""
                : systemNotice
                    ? systemNoticeText(systemNotice)
                    : legacyNotice
                        ? legacyNotice.text
                        : role === "assistant" &&
                            isIntentionalNoResponseResult({ responseContent: m.content }, rawText)
                            ? ""
                            : role === "assistant" && !interrupted
                                ? normalizeChatResponseText(rawText, state.logBuffer, runtime)
                                : rawText;
            const attachments = selectAttachmentsForViewer(m, viewerAccessContext, agentId);
            const topics = Array.isArray(meta?.topics) && meta.topics.length > 0
                ? meta.topics.filter((topic) => typeof topic === "string")
                : undefined;
            return {
                id: m.id ?? "",
                role,
                text,
                ...(userTextFormat ? { userTextFormat } : {}),
                ...(clientMessageId ? { clientMessageId } : {}),
                ...(role === "assistant" &&
                    typeof content.planningAcknowledgment === "string"
                    ? { planningAcknowledgment: content.planningAcknowledgment }
                    : {}),
                timestamp: m.createdAt ?? 0,
                ...(content.replyRecoveryAvailable === true
                    ? { replyRecoveryAvailable: true }
                    : {}),
                ...(transcriptVisibility ? { transcriptVisibility } : {}),
                ...(attachments ? { attachments } : {}),
                ...(topics && topics.length > 0 ? { topics } : {}),
                source: normalizedSource,
                actionName,
                actionCallbackHistory: actionCallbackHistory.length > 0
                    ? [...actionCallbackHistory]
                    : undefined,
                from: typeof entityName === "string" && entityName.length > 0
                    ? entityName
                    : undefined,
                fromUserName: typeof meta?.entityUserName === "string" &&
                    meta.entityUserName.length > 0
                    ? meta.entityUserName
                    : undefined,
                avatarUrl: typeof meta?.entityAvatarUrl === "string" &&
                    meta.entityAvatarUrl.length > 0
                    ? meta.entityAvatarUrl
                    : undefined,
                replyToMessageId: typeof content.inReplyTo === "string" &&
                    content.inReplyTo.length > 0
                    ? content.inReplyTo
                    : typeof meta?.replyToMessageId === "string" &&
                        meta.replyToMessageId.length > 0
                        ? meta.replyToMessageId
                        : undefined,
                replyToSenderName: typeof meta?.replyToSenderName === "string" &&
                    meta.replyToSenderName.length > 0
                    ? meta.replyToSenderName
                    : typeof replyToAuthor?.displayName === "string" &&
                        replyToAuthor.displayName.length > 0
                        ? replyToAuthor.displayName
                        : typeof replyToAuthor?.username === "string" &&
                            replyToAuthor.username.length > 0
                            ? replyToAuthor.username
                            : undefined,
                replyToSenderUserName: typeof meta?.replyToSenderUserName === "string" &&
                    meta.replyToSenderUserName.length > 0
                    ? meta.replyToSenderUserName
                    : typeof replyToAuthor?.username === "string" &&
                        replyToAuthor.username.length > 0
                        ? replyToAuthor.username
                        : undefined,
                rawDiscordChannelId: extractConversationMetaString(m, "discordChannelId"),
                rawDiscordMessageId: extractConversationMetaString(m, "discordMessageId"),
                rawSenderId: extractConversationMetaString(m, "fromId"),
                senderEntityId: typeof m.entityId === "string" ? m.entityId : undefined,
                ...(failureKind ? { failureKind } : {}),
                ...(terminalFailure ? { terminalFailure } : {}),
                ...(accountConnect ? { accountConnect } : {}),
                ...(interrupted ? { interrupted: true } : {}),
            };
        })
            // Drop action-log memories that have no visible text (e.g.
            // plugin action logs with only `thought` / `actions` fields).
            // Without this filter they appear as blank chat bubbles. Image-only
            // turns (uploaded or generated media with no caption) are kept.
            .filter((m) => m.text.trim().length > 0 ||
            (m.attachments?.length ?? 0) > 0 ||
            // A zero-token interrupted receipt has no text but IS the turn's
            // terminal state; dropping it would leave the user turn unanswered
            // on reload and invite regeneration.
            m.interrupted === true);
        memories.sort(compareMemoriesByCreatedAt);
        let messages = projectMessages(memories);
        // The projection hides scheduler prompts and textless action logs after the
        // read, so a window of only those rows came back empty and the client took
        // it as the start of history. Keep reading older rows until a visible turn
        // or the start of history. The around window is a fixed read (hasMore stays false).
        while (messages.length === 0 && hasMore) {
            // memories is sorted oldest first, so the next page starts below [0].
            const oldestRead = memories[0];
            if (!oldestRead?.id || typeof oldestRead.createdAt !== "number")
                break;
            const page = await loadConversationMessagesBefore(runtime, conv.roomId, oldestRead.createdAt, pageLimit, oldestRead.id);
            memories = page.memories.sort(compareMemoriesByCreatedAt);
            hasMore = page.hasMore;
            messages = projectMessages(memories);
        }
        const discordMessages = messages.filter((message) => mayNeedDiscordMessageEnrichment(message.source));
        const discord = discordMessages.length > 0
            ? await getDiscordConversationApi().catch((err) => {
                logger.debug(`[conversations] Discord metadata enrichment unavailable: ${getErrorMessage(err)}`);
                return null;
            })
            : null;
        await Promise.all(discordMessages.map(async (message) => {
            if (!discord) {
                return;
            }
            if (!discord.isCanonicalDiscordSource(message.source)) {
                return;
            }
            try {
                const storedSenderProfile = await discord.resolveStoredDiscordEntityProfile(runtime, message.senderEntityId);
                if (!message.from && storedSenderProfile?.displayName) {
                    message.from = storedSenderProfile.displayName;
                }
                if (!message.fromUserName && storedSenderProfile?.username) {
                    message.fromUserName = storedSenderProfile.username;
                }
                if (!message.avatarUrl && storedSenderProfile?.avatarUrl) {
                    message.avatarUrl = storedSenderProfile.avatarUrl;
                }
                const messageAuthorProfile = message.rawDiscordChannelId && message.rawDiscordMessageId
                    ? await discord.resolveDiscordMessageAuthorProfile(runtime, message.rawDiscordChannelId, message.rawDiscordMessageId)
                    : null;
                if (!message.from && messageAuthorProfile?.displayName) {
                    message.from = messageAuthorProfile.displayName;
                }
                if (!message.fromUserName && messageAuthorProfile?.username) {
                    message.fromUserName = messageAuthorProfile.username;
                }
                if (!message.avatarUrl && messageAuthorProfile?.avatarUrl) {
                    message.avatarUrl = messageAuthorProfile.avatarUrl;
                }
                const rawSenderId = message.rawSenderId ??
                    storedSenderProfile?.rawUserId ??
                    messageAuthorProfile?.rawUserId;
                if (rawSenderId) {
                    const profile = await discord.resolveDiscordUserProfile(runtime, rawSenderId);
                    if (profile) {
                        if (profile.displayName) {
                            message.from = profile.displayName;
                        }
                        if (profile.username) {
                            message.fromUserName = profile.username;
                        }
                        if (profile.avatarUrl) {
                            message.avatarUrl = profile.avatarUrl;
                        }
                    }
                }
                message.avatarUrl = await discord.cacheDiscordAvatarForRuntime(runtime, message.avatarUrl, rawSenderId);
            }
            catch (err) {
                logger.debug(`[conversations] Failed to enrich Discord message metadata: ${getErrorMessage(err)}`);
            }
        }));
        json(res, {
            messages: messages.map(({ rawDiscordChannelId: _rawDiscordChannelId, rawDiscordMessageId: _rawDiscordMessageId, rawSenderId: _rawSenderId, senderEntityId: _senderEntityId, ...message }) => message),
            // Only the load-older (`before`) path advertises pagination state; the
            // recent + around windows are single fixed reads and omit it so their
            // response shape is unchanged.
            ...(beforeParam !== null && !aroundParam ? { hasMore } : {}),
        });
    }
    catch (err) {
        logger.warn(`[conversations] Failed to fetch messages: ${err instanceof Error ? err.message : String(err)}`);
        json(res, { messages: [], error: "Failed to fetch messages" }, 500);
    }
    return true;
}
async function importConversation(ctx) {
    const { req, res, pathname, readJsonBody, json, error, state, trustedApiPrincipal, } = ctx;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const rawImport = await readJsonBody(req, res);
    if (rawImport === null)
        return true;
    const rawMessages = rawImport.messages;
    if (!Array.isArray(rawMessages)) {
        error(res, "Body must include a `messages` array", 400);
        return true;
    }
    const importMessages = rawMessages
        .map((entry) => {
        if (!entry || typeof entry !== "object")
            return null;
        const rec = entry;
        const role = rec.role === "assistant"
            ? "assistant"
            : rec.role === "user"
                ? "user"
                : null;
        const rawText = typeof rec.text === "string"
            ? rec.text
            : typeof rec.content === "string"
                ? rec.content
                : "";
        // Validate emptiness without changing the source being transferred.
        // Quotes, indentation and trailing newlines are part of the message.
        if (!role || !rawText.trim())
            return null;
        const text = rawText;
        const timestamp = typeof rec.timestamp === "number" && Number.isFinite(rec.timestamp)
            ? rec.timestamp
            : undefined;
        const sourceId = typeof rec.sourceId === "string" &&
            rec.sourceId.trim() &&
            rec.sourceId.length <= 256
            ? rec.sourceId.trim()
            : undefined;
        return { role, text, timestamp, sourceId };
    })
        .filter((m) => m !== null);
    const sourceIds = importMessages.map((message) => message.sourceId);
    // A lone surrogate cannot be encoded into the deterministic message id.
    if (sourceIds.some((sourceId) => sourceId && !sourceId.isWellFormed())) {
        error(res, "Imported message sourceIds must contain well-formed Unicode", 400);
        return true;
    }
    const exactImport = sourceIds.length > 0 && sourceIds.every(Boolean);
    if (sourceIds.some(Boolean) && !exactImport) {
        error(res, "Every imported message must include a sourceId", 400);
        return true;
    }
    if (exactImport && new Set(sourceIds).size !== sourceIds.length) {
        error(res, "Imported message sourceIds must be unique", 400);
        return true;
    }
    const rawScheduledTasks = rawImport.scheduledTasks;
    if (rawScheduledTasks !== undefined && !Array.isArray(rawScheduledTasks)) {
        error(res, "`scheduledTasks` must be an array", 400);
        return true;
    }
    const cutoverToken = typeof rawImport.cutoverToken === "string" &&
        rawImport.cutoverToken.trim().length > 0 &&
        rawImport.cutoverToken.length <= 512
        ? rawImport.cutoverToken.trim()
        : null;
    if (rawImport.cutoverToken !== undefined && !cutoverToken) {
        error(res, "A cutoverToken must be a non-empty string of at most 512 characters", 400);
        return true;
    }
    const importTasks = [];
    for (const rawTask of rawScheduledTasks ?? []) {
        if (!isScheduledTask(rawTask) || rawTask.kind !== "reminder") {
            error(res, "Every imported scheduled task must be a valid reminder", 400);
            return true;
        }
        importTasks.push(rawTask);
    }
    if (importTasks.length > 0 && !cutoverToken) {
        error(res, "A cutoverToken is required to import scheduled tasks", 400);
        return true;
    }
    const activateScheduledTasks = rawImport.activateScheduledTasks;
    if (activateScheduledTasks !== undefined &&
        typeof activateScheduledTasks !== "boolean") {
        error(res, "`activateScheduledTasks` must be a boolean", 400);
        return true;
    }
    if (activateScheduledTasks === true && !cutoverToken) {
        error(res, "A cutoverToken is required to activate scheduled tasks", 400);
        return true;
    }
    const rawTodoSnapshot = rawImport.todoSnapshot;
    if (cutoverToken && rawTodoSnapshot === undefined) {
        error(res, "A todoSnapshot is required for an exact cutover import", 400);
        return true;
    }
    if (rawTodoSnapshot !== undefined && !cutoverToken) {
        error(res, "A cutoverToken is required to import todos", 400);
        return true;
    }
    let todoSnapshot = null;
    if (rawTodoSnapshot !== undefined) {
        try {
            todoSnapshot = await parseSharedTodoCutoverSnapshot(rawTodoSnapshot);
        }
        catch (err) {
            // error-policy:J3 the authenticated import boundary rejects malformed
            // or digest-mismatched Todo data without admitting any partial import.
            error(res, err instanceof TodoCutoverContractError
                ? err.message
                : `Todo snapshot validation failed: ${getErrorMessage(err)}`, 400);
            return true;
        }
        if (todoSnapshot.sourceAgentId !== convId) {
            error(res, "Todo snapshot source does not match the conversation", 400);
            return true;
        }
    }
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    await waitForConversationRestore(state);
    let conv = state.conversations.get(convId);
    let createdConversation = false;
    if (!conv) {
        const now = new Date().toISOString();
        conv = {
            id: convId,
            title: typeof rawImport.title === "string" && rawImport.title.trim()
                ? rawImport.title.trim()
                : "New Chat",
            roomId: stringToUuid(`web-conv-${convId}`),
            createdAt: now,
            updatedAt: now,
        };
        state.conversations.set(convId, conv);
        createdConversation = true;
    }
    const caller = resolveConversationCaller(req, state, trustedApiPrincipal, runtime);
    const importAbortTracker = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation import admission",
    });
    let historyLease;
    try {
        historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, importAbortTracker.signal);
    }
    catch (err) {
        // error-policy:J1 Withdraw this import's registration even when the caller
        // disconnected and cannot receive the admission error response.
        importAbortTracker.dispose();
        if (createdConversation && state.conversations.get(convId) === conv) {
            state.conversations.delete(convId);
        }
        if (importAbortTracker.isAborted())
            return true;
        error(res, isRoomQueueBackpressureError(err)
            ? "Conversation is busy; retry import after pending turns finish"
            : `Failed to serialize conversation import: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
        return true;
    }
    importAbortTracker.markCompleted();
    importAbortTracker.dispose();
    try {
        if (state.conversations.get(conv.id) !== conv ||
            state.deletedConversationIds.has(conv.id)) {
            error(res, "Conversation was deleted", 404);
            return true;
        }
        if (createdConversation) {
            prepareConversationConnectionRoom(runtime, conv.roomId);
        }
        try {
            await ensureConversationRoom(state, runtime, conv, caller);
        }
        catch (err) {
            // error-policy:J1 boundary translation — a failed import that created
            // this conversation must not leave it listed without a backing room.
            if (createdConversation && state.conversations.get(convId) === conv) {
                state.conversations.delete(convId);
            }
            error(res, `Failed to initialize conversation room: ${getErrorMessage(err)}`, 500);
            return true;
        }
        if (!exactImport && importTasks.length === 0 && !todoSnapshot) {
            // Legacy imports predate source ids. Preserve their room-level
            // idempotency while exact cloud cutovers use per-message identities.
            const existing = await runtime.getMemories({
                roomId: conv.roomId,
                tableName: "messages",
                limit: 1,
            });
            if (existing.length > 0) {
                json(res, {
                    conversationId: convId,
                    complete: true,
                    sourceMessageCount: importMessages.length,
                    inserted: 0,
                    skipped: importMessages.length,
                    alreadyPopulated: true,
                });
                return true;
            }
        }
        let todoReceipt = null;
        if (todoSnapshot && cutoverToken) {
            try {
                todoReceipt = await (ctx.todoCutoverImporter ?? importSharedTodoCutover)({
                    runtime,
                    entityId: caller.entityId,
                    targetRoomId: conv.roomId,
                    cutoverToken,
                    snapshot: todoSnapshot,
                });
            }
            catch (err) {
                // error-policy:J1 the import boundary keeps Shared authoritative when
                // the Dedicated Todo transaction cannot prove the exact snapshot.
                error(res, `Todo import failed: ${getErrorMessage(err)}`, 500);
                return true;
            }
        }
        // Preserve original ordering: assign strictly increasing timestamps,
        // anchored to the provided ones when present.
        if (importMessages.length > 0) {
            await scheduleImportedConversationEmbeddings(runtime, conv.roomId);
        }
        let inserted = 0;
        let skipped = 0;
        const anchor = Date.now() - importMessages.length;
        for (let i = 0; i < importMessages.length; i += 1) {
            const m = importMessages[i];
            const entityId = m.role === "assistant" ? runtime.agentId : caller.entityId;
            const createdAt = m.timestamp ?? anchor + i;
            try {
                const memory = createMessageMemory({
                    id: m.sourceId
                        ? createUniqueUuid(runtime, `handoff-import:${convId}:${m.sourceId}`)
                        : crypto.randomUUID(),
                    entityId,
                    roomId: conv.roomId,
                    content: {
                        text: m.text,
                        channelType: ChannelType.DM,
                        source: "handoff_import",
                    },
                });
                memory.createdAt = createdAt;
                if (memory.metadata && typeof memory.metadata === "object") {
                    // Import is the source surface, not a live client-chat delivery.
                    // Keep it consistent with content.source for canonical recall.
                    memory.metadata.provider = "handoff_import";
                    memory.metadata.timestamp = createdAt;
                    if (m.sourceId) {
                        memory.metadata.sourceId = m.sourceId;
                        memory.metadata.platformMessageId = m.sourceId;
                    }
                }
                if (m.sourceId) {
                    const result = await persistExactConversationMemoryResult(runtime, memory, historyLease);
                    // Exact identity/content admission above makes this a repair of
                    // this import's old contradictory stamp, never a scope migration.
                    if (!result.created &&
                        result.memory.content.source === "handoff_import" &&
                        result.memory.metadata?.type === "message" &&
                        result.memory.metadata.provider === "client_chat" &&
                        result.memory.metadata.accountId === runtime.agentId) {
                        const metadata = {
                            ...result.memory.metadata,
                            provider: "handoff_import",
                        };
                        const updated = await runtime.roomHandlerQueue.runInLease(conv.roomId, historyLease, () => runtime.updateMemory({ id: result.memory.id, metadata }));
                        if (!updated) {
                            throw new ElizaError("Imported source stamp repair failed", {
                                code: "CONVERSATION_IMPORT_PROVENANCE_REPAIR_FAILED",
                                context: { memoryId: result.memory.id, roomId: conv.roomId },
                            });
                        }
                        result.memory = { ...result.memory, metadata };
                    }
                    if (result.created)
                        inserted += 1;
                    else
                        skipped += 1;
                    // Import bypasses normal message processing, which otherwise
                    // requests embeddings. Read the durable, secret-redacted source;
                    // exact retries also repair a still-missing vector.
                    const persisted = result.created
                        ? (await runtime.getMemoriesByIds([result.memory.id], "messages"))[0]
                        : result.memory;
                    if (!persisted)
                        throw new Error("Imported message was not persisted");
                    await runtime.queueEmbeddingGeneration(persisted, "low");
                }
                else {
                    const result = await persistConversationMemory(runtime, memory, historyLease);
                    const [persisted] = await runtime.getMemoriesByIds([result.id], "messages");
                    if (!persisted)
                        throw new Error("Imported message was not persisted");
                    await runtime.queueEmbeddingGeneration(persisted, "low");
                    inserted += 1;
                }
            }
            catch (err) {
                // error-policy:J1 the import boundary reports the exact partial-write
                // position and never returns a healthy skipped-count response.
                error(res, `Conversation import failed at message ${i}: ${getErrorMessage(err)}`, 500);
                return true;
            }
        }
        let importedScheduledTasks = 0;
        let skippedScheduledTasks = 0;
        let activatedScheduledTasks = 0;
        let skippedActivatedScheduledTasks = 0;
        if (importTasks.length > 0 && cutoverToken) {
            const runner = getScheduledTaskRunner(runtime, {
                agentId: runtime.agentId,
            });
            for (let i = 0; i < importTasks.length; i += 1) {
                try {
                    const result = await runner.importTask(importTasks[i], {
                        sourceAgentId: convId,
                        cutoverToken,
                    });
                    if (result.imported)
                        importedScheduledTasks += 1;
                    else
                        skippedScheduledTasks += 1;
                }
                catch (err) {
                    // error-policy:J1 the conversation import boundary reports the exact failing task.
                    error(res, `Scheduled task import failed at task ${i}: ${getErrorMessage(err)}`, 500);
                    return true;
                }
            }
            if (activateScheduledTasks === true) {
                for (let i = 0; i < importTasks.length; i += 1) {
                    try {
                        const result = await runner.activateImportedTask(importTasks[i].taskId, {
                            sourceAgentId: convId,
                            cutoverToken,
                        });
                        if (result.activated)
                            activatedScheduledTasks += 1;
                        else
                            skippedActivatedScheduledTasks += 1;
                    }
                    catch (err) {
                        // error-policy:J1 the conversation import boundary reports the exact failing task.
                        error(res, `Scheduled task activation failed at task ${i}: ${getErrorMessage(err)}`, 500);
                        return true;
                    }
                }
            }
        }
        conv.updatedAt = new Date().toISOString();
        state.broadcastWs?.({ type: "conversation-updated", conversation: conv });
        json(res, {
            conversationId: convId,
            complete: true,
            sourceMessageCount: importMessages.length,
            inserted,
            skipped,
            sourceScheduledTaskCount: importTasks.length,
            importedScheduledTasks,
            skippedScheduledTasks,
            activatedScheduledTasks,
            skippedActivatedScheduledTasks,
            ...(todoReceipt ?? {}),
        });
        return true;
    }
    finally {
        await historyLease.release();
    }
}
async function truncateConversationMessagesRoute(ctx) {
    const { req, res, pathname, readJsonBody, json, error, state } = ctx;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuNonAdminMutationIfNeeded(req, error, res))
        return true;
    const rawTrunc = await readJsonBody(req, res);
    if (rawTrunc === null)
        return true;
    const parsedTrunc = PostConversationTruncateRequestSchema.safeParse(rawTrunc);
    if (!parsedTrunc.success) {
        error(res, parsedTrunc.error.issues[0]?.message ?? "Invalid request body", 400);
        return true;
    }
    const { messageId, inclusive } = parsedTrunc.data;
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    const truncateAbortTracker = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation truncation admission",
    });
    let historyLease;
    try {
        historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, truncateAbortTracker.signal);
    }
    catch (err) {
        truncateAbortTracker.dispose();
        if (truncateAbortTracker.isAborted())
            return true;
        error(res, isRoomQueueBackpressureError(err)
            ? "Conversation is busy; retry after the pending turns finish"
            : `Failed to serialize conversation history: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
        return true;
    }
    truncateAbortTracker.markCompleted();
    truncateAbortTracker.dispose();
    try {
        if (state.conversations.get(conv.id) !== conv ||
            state.deletedConversationIds.has(conv.id)) {
            error(res, "Conversation was deleted", 404);
            return true;
        }
        const result = await runtime.roomHandlerQueue.runInLease(conv.roomId, historyLease, () => truncateConversationMessages(runtime, conv, messageId, {
            inclusive: inclusive === true,
        }));
        conv.updatedAt = new Date().toISOString();
        state.broadcastWs?.({
            type: "conversation-updated",
            conversation: conv,
        });
        json(res, { ok: true, deletedCount: result.deletedCount });
    }
    catch (err) {
        const status = typeof err.status === "number"
            ? err.status
            : 500;
        error(res, getErrorMessage(err), status);
    }
    finally {
        await historyLease.release();
    }
    return true;
}
async function deleteConversationMessageRoute(ctx) {
    const { req, res, pathname, json, error, state } = ctx;
    const segments = pathname.split("/");
    const convId = decodePathComponent(segments[3], res, "conversation id");
    if (convId === null)
        return true;
    const messageId = decodePathComponent(segments[5], res, "conversation message id");
    if (messageId === null)
        return true;
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    // Non-admin waifu callers may only mutate their own conversation; the
    // access-scoped 404 keeps a foreign conv id from leaking existence.
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res)) {
        return true;
    }
    if (rejectWaifuNonAdminMutationIfNeeded(req, error, res))
        return true;
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    const deleteMessageAbortTracker = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation message deletion admission",
    });
    let historyLease;
    try {
        historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, deleteMessageAbortTracker.signal);
    }
    catch (err) {
        deleteMessageAbortTracker.dispose();
        if (deleteMessageAbortTracker.isAborted())
            return true;
        error(res, isRoomQueueBackpressureError(err)
            ? "Conversation is busy; retry after the pending turns finish"
            : `Failed to serialize conversation history: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
        return true;
    }
    deleteMessageAbortTracker.markCompleted();
    deleteMessageAbortTracker.dispose();
    try {
        if (state.conversations.get(conv.id) !== conv ||
            state.deletedConversationIds.has(conv.id)) {
            error(res, "Conversation was deleted", 404);
            return true;
        }
        const result = await runtime.roomHandlerQueue.runInLease(conv.roomId, historyLease, () => deleteConversationMessage(runtime, conv, messageId));
        conv.updatedAt = new Date().toISOString();
        state.broadcastWs?.({
            type: "conversation-updated",
            conversation: conv,
        });
        json(res, { ok: true, deletedCount: result.deletedCount });
    }
    catch (err) {
        const status = typeof err.status === "number"
            ? err.status
            : 500;
        error(res, getErrorMessage(err), status);
    }
    finally {
        await historyLease.release();
    }
    return true;
}
/**
 * `POST /api/conversations/:id/messages/:messageId/heard` keeps only the part
 * of an assistant reply that the user heard before they interrupted playback.
 *
 * Body: `{ heardText }`, non-empty. It must be a prefix of either the stored
 * reply text or its spoken form (`sanitizeSpeechText` from `@elizaos/core`,
 * the text TTS speaks); whitespace runs compare as one space. A spoken-form
 * prefix is stored as the matching stored-text prefix, rounded up to the end
 * of the word. Anything else is 409; nothing can extend the reply.
 * Or `{ nothingHeard: true }`: the reply was interrupted before any of it
 * played; it is replaced with an empty, interruption-marked memory.
 * Response: `{ ok, messageId, text, truncated, changed }`.
 */
async function recordHeardConversationMessageRoute(ctx) {
    const { req, res, pathname, readJsonBody, json, error, state } = ctx;
    const segments = pathname.split("/");
    const convId = decodePathComponent(segments[3], res, "conversation id");
    if (convId === null)
        return true;
    const rawMessageId = decodePathComponent(segments[5], res, "conversation message id");
    if (rawMessageId === null)
        return true;
    const messageId = validateUuid(rawMessageId);
    if (!messageId) {
        error(res, "Invalid assistant message id", 400);
        return true;
    }
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res)) {
        return true;
    }
    if (rejectWaifuNonAdminMutationIfNeeded(req, error, res))
        return true;
    const rawBody = await readJsonBody(req, res);
    if (rawBody === null)
        return true;
    const parsed = PostConversationMessageHeardRequestSchema.safeParse(rawBody);
    if (!parsed.success) {
        error(res, rawBody && typeof rawBody === "object" && "heardText" in rawBody
            ? "heardText must be non-empty text"
            : "Body must be { heardText } or { nothingHeard: true }", 400);
        return true;
    }
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    const admission = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation heard-text admission",
    });
    let historyLease;
    try {
        historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, admission.signal);
    }
    catch (err) {
        admission.dispose();
        if (admission.isAborted())
            return true;
        error(res, isRoomQueueBackpressureError(err)
            ? "Conversation is busy; retry after the pending turns finish"
            : `Failed to serialize conversation history: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
        return true;
    }
    admission.markCompleted();
    admission.dispose();
    try {
        if (state.conversations.get(conv.id) !== conv ||
            state.deletedConversationIds.has(conv.id)) {
            error(res, "Conversation was deleted", 404);
            return true;
        }
        const result = await runtime.roomHandlerQueue.runInLease(conv.roomId, historyLease, () => recordHeardAssistantMessage(runtime, conv, messageId, parsed.data));
        if (result.changed) {
            conv.updatedAt = new Date().toISOString();
            state.broadcastWs?.({
                type: "conversation-updated",
                conversation: conv,
            });
        }
        json(res, { ok: true, messageId, ...result });
    }
    catch (err) {
        const status = typeof err.status === "number"
            ? err.status
            : 500;
        error(res, getErrorMessage(err), status);
    }
    finally {
        await historyLease.release();
    }
    return true;
}
async function retryConversationReply(ctx) {
    const { req, res, pathname, readJsonBody, json, error, state, trustedApiPrincipal, } = ctx;
    const segments = pathname.split("/");
    const convId = decodePathComponent(segments[3], res, "conversation id");
    const rawMessageId = decodePathComponent(segments[5], res, "conversation message id");
    if (convId === null || rawMessageId === null)
        return true;
    const assistantId = validateUuid(rawMessageId);
    if (!assistantId) {
        error(res, "Invalid assistant message id", 400);
        return true;
    }
    const body = await readJsonBody(req, res);
    if (body === null)
        return true;
    if (!isRecord(body) || Object.keys(body).length > 0) {
        error(res, "Reply recovery does not accept replacement text or evidence", 400);
        return true;
    }
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res))
        return true;
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    const caller = resolveConversationCaller(req, state, trustedApiPrincipal, runtime);
    const disconnect = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation reply recovery",
    });
    let lease;
    let endActive;
    const assertCurrent = () => {
        if (state.runtime !== runtime ||
            state.conversations.get(conv.id) !== conv ||
            state.deletedConversationIds.has(conv.id))
            throw new ElizaError("Conversation runtime changed during reply recovery", { code: "CHAT_REPLY_RECOVERY_CONFLICT" });
    };
    try {
        lease = await runtime.roomHandlerQueue.acquire(conv.roomId, disconnect.signal);
        assertCurrent();
        endActive = beginActiveChatTurn(state);
        const [assistant] = await runtime.getMemoriesByIds([assistantId], "messages");
        const userId = validateUuid(assistant?.content.inReplyTo);
        if (!assistant ||
            assistant.roomId !== conv.roomId ||
            assistant.agentId !== runtime.agentId ||
            assistant.entityId !== runtime.agentId ||
            !userId)
            throw new ElizaError("Original reply is unavailable for recovery", {
                code: "CHAT_REPLY_RECOVERY_UNAVAILABLE",
            });
        const originalAssistantHash = conversationReplyContentHash(assistant.content);
        const [storedUser] = await runtime.getMemoriesByIds([userId], "messages");
        const scope = buildConversationChatIdempotencyScope(runtime, conv.roomId, caller.entityId);
        const marker = readDurableConversationChatMarker(storedUser?.content.chatIdempotency);
        if (!storedUser ||
            storedUser.roomId !== conv.roomId ||
            storedUser.agentId !== runtime.agentId ||
            storedUser.entityId !== caller.entityId ||
            !marker ||
            marker.scope !== scope ||
            conversationClientUserMemoryId(scope, marker.clientMessageId) !== userId)
            throw new ElizaError("Reply recovery belongs to another authenticated turn", { code: "CHAT_REPLY_RECOVERY_IDENTITY" });
        const recovery = marker.replyRecoveryJson === undefined
            ? null
            : parseDurableConversationReplyRecovery(marker.replyRecoveryJson);
        if (!recovery ||
            recovery.assistantMessageId !== assistantId ||
            recovery.userContentHash !==
                conversationReplyContentHash(storedUser.content) ||
            !conversationReplyRecoveryIsEligible(recovery))
            throw new ElizaError("Reply recovery is unavailable or requires outcome reconciliation", { code: "CHAT_REPLY_RECOVERY_UNAVAILABLE" });
        const outcome = marker.outcomeJson === undefined
            ? null
            : parseDurableConversationChatOutcome(marker.outcomeJson);
        if ((marker.outcomeJson !== undefined && !outcome) ||
            (outcome &&
                (outcome.messageId !== assistantId || outcome.userMessageId !== userId)))
            throw new ElizaError("Stored reply outcome does not match its original turn", { code: "CHAT_REPLY_RECOVERY_INVALID" });
        const alreadyRecovered = recovery.reply !== undefined &&
            outcome !== null &&
            outcome.terminalFailure === undefined &&
            outcome.replyRecoveryAvailable !== true;
        if (alreadyRecovered && outcome?.text !== recovery.reply?.text)
            throw new ElizaError("Stored recovered prose does not match its outcome", { code: "CHAT_REPLY_RECOVERY_INVALID" });
        if (alreadyRecovered &&
            originalAssistantHash !== recovery.reply?.contentHash)
            throw new ElizaError("The recovered assistant reply was edited after recovery completed", { code: "CHAT_REPLY_RECOVERY_CONFLICT" });
        if (!alreadyRecovered &&
            originalAssistantHash !== recovery.assistantContentHash &&
            originalAssistantHash !== recovery.reply?.contentHash)
            throw new ElizaError("The failed assistant reply was edited after its outcomes settled", { code: "CHAT_REPLY_RECOVERY_CONFLICT" });
        if (!recovery.reply &&
            (assistant.content.replyRecoveryAvailable !== true ||
                !parseChatTerminalFailure(assistant.content.terminalFailure)))
            throw new ElizaError("The selected assistant turn does not have a missing reply", { code: "CHAT_REPLY_RECOVERY_UNAVAILABLE" });
        const message = {
            ...storedUser,
            content: { ...storedUser.content },
        };
        // Server-owned retry evidence is not part of the user's request content.
        delete message.content.chatIdempotency;
        const authorizeRecoveryAudience = async () => {
            await attestAuthenticatedApiDeliveryAudience(runtime, message, trustedApiPrincipal);
            assertCurrent();
            if (recovery.ownerExclusiveDisclosureUsed) {
                const disclosure = await authorizeOwnerExclusiveDisclosure(runtime, message);
                if (!disclosure.allowed)
                    throw new ElizaError("The current conversation cannot receive this private reply", { code: "CHAT_REPLY_RECOVERY_IDENTITY" });
            }
            for (const actionResult of recovery.actionResults) {
                if (!actionResult.data || !("disclosureSubject" in actionResult.data))
                    continue;
                if (actionResult.data.disclosureSubject === null ||
                    actionResult.data.disclosureSubject === undefined)
                    throw new ElizaError("Stored action disclosure evidence is invalid", {
                        code: "CHAT_REPLY_RECOVERY_INVALID",
                    });
                const checked = await enforceTrustedDeliveryAudienceAtEgress(runtime, message, {
                    data: {
                        disclosureSubject: actionResult.data.disclosureSubject,
                    },
                });
                if (isRecord(checked.data) && checked.data.privacyDenied === true)
                    throw new ElizaError("The current audience cannot receive these action results", { code: "CHAT_REPLY_RECOVERY_IDENTITY" });
            }
        };
        await authorizeRecoveryAudience();
        assertCurrent();
        const recoveryLease = lease;
        const recoverAttempt = async () => {
            const reply = recovery.reply ??
                (await resolvePlannedReplyEgress({
                    runtime,
                    message,
                    reply: "",
                    actionResults: recovery.actionResults,
                    recovery,
                    beforeContextRestore: async () => {
                        await authorizeRecoveryAudience();
                        const currentSources = await runtime.getMemoriesByIds([userId, assistantId], "messages");
                        assertCurrent();
                        const currentUser = currentSources.find((source) => source.id === userId);
                        const currentAssistant = currentSources.find((source) => source.id === assistantId);
                        if (!currentUser ||
                            !currentAssistant ||
                            conversationReplyContentHash(currentUser.content) !==
                                recovery.userContentHash ||
                            conversationReplyContentHash(currentAssistant.content) !==
                                originalAssistantHash) {
                            throw new ElizaError("The original turn changed before reply context restoration", { code: "CHAT_REPLY_RECOVERY_CONFLICT" });
                        }
                    },
                }));
            if (reply.effectReceiptIds.length > 0 &&
                !resolveAppliedUserFacingEffectReceipts({
                    verifiedUserFacing: true,
                    userFacingText: reply.text,
                    userFacingEffectReceiptIds: reply.effectReceiptIds,
                }, mergeEffectReceipts(...recovery.actionResults.map((result) => result.effectReceipts))))
                throw new ElizaError("The saved reply has invalid effect evidence", {
                    code: "CHAT_REPLY_RECOVERY_INVALID",
                });
            const replyBinding = {
                success: true,
                userFacingText: reply.text,
                verifiedUserFacing: true,
                userFacingEffectReceiptIds: reply.effectReceiptIds,
            };
            if (evaluatePlannedReplyEgress({
                reply: reply.text,
                actionResults: [...recovery.actionResults, replyBinding],
                actions: runtime.actions,
            }).verdict !== "allow")
                throw new ElizaError("The saved reply is not grounded in its original effects", { code: "CHAT_REPLY_RECOVERY_INVALID" });
            await authorizeRecoveryAudience();
            assertCurrent();
            let content = {
                ...assistant.content,
                text: reply.text,
                inReplyTo: userId,
                effectReceiptIds: [...reply.effectReceiptIds],
                agentVoiced: true,
            };
            delete content.terminalFailure;
            delete content.failureKind;
            delete content.replyFailure;
            delete content.replyRecoveryAvailable;
            delete content.elizaSyntheticFailure;
            delete content.interrupted;
            delete content.transcriptVisibility;
            const normalizedContent = clearRecoveredReplyFailureMarkers(content);
            if (isRecord(normalizedContent.metadata))
                normalizedContent.metadata = clearRecoveredReplyFailureMarkers(normalizedContent.metadata);
            // New prepared prose binds its successful metadata before persistence.
            // Legacy staged/completed replies keep their exact saved revision: memory
            // evaluators may already have acknowledged that historical content hash.
            const normalizeFailureMetadata = !recovery.reply ||
                recovery.reply.contentHash ===
                    conversationReplyContentHash(normalizedContent);
            if (normalizeFailureMetadata)
                content = normalizedContent;
            if (recovery.reply &&
                recovery.reply.contentHash !== conversationReplyContentHash(content))
                throw new ElizaError("Stored recovered content does not match its prepared revision", { code: "CHAT_REPLY_RECOVERY_INVALID" });
            const checked = await enforceTrustedDeliveryAudienceAtEgress(runtime, message, content);
            if (checked !== content)
                throw new ElizaError("The current audience cannot receive the recovered reply", { code: "CHAT_REPLY_RECOVERY_IDENTITY" });
            assertCurrent();
            if (alreadyRecovered && outcome) {
                return outcome;
            }
            // The model awaited external I/O. Re-read authority before writing so
            // an independently edited/deleted memory is never replaced from a stale
            // snapshot. Runtime memory mutation routes share this same room lease.
            const latestRows = await runtime.getMemoriesByIds([userId, assistantId], "messages");
            const latestUser = latestRows.find((memory) => memory.id === userId);
            const latestAssistant = latestRows.find((memory) => memory.id === assistantId);
            const latestMarker = readDurableConversationChatMarker(latestUser?.content.chatIdempotency);
            if (!latestUser ||
                latestUser.roomId !== conv.roomId ||
                latestUser.entityId !== caller.entityId ||
                latestUser.agentId !== runtime.agentId ||
                conversationReplyContentHash(latestUser.content) !==
                    recovery.userContentHash ||
                !latestMarker ||
                latestMarker.scope !== marker.scope ||
                latestMarker.clientMessageId !== marker.clientMessageId ||
                latestMarker.fingerprint !== marker.fingerprint ||
                latestMarker.replyRecoveryJson !== marker.replyRecoveryJson ||
                !latestAssistant ||
                latestAssistant.roomId !== conv.roomId ||
                latestAssistant.agentId !== runtime.agentId ||
                latestAssistant.entityId !== runtime.agentId ||
                conversationReplyContentHash(latestAssistant.content) !==
                    originalAssistantHash)
                throw new ElizaError("The original turn changed while its reply was recovering", { code: "CHAT_REPLY_RECOVERY_CONFLICT" });
            assertCurrent();
            if (!recovery.reply) {
                // Commit the generated prose first. A crash between this marker and
                // the assistant row only repeats persistence, never tools or the model.
                const preparedRecovery = {
                    ...recovery,
                    reply: {
                        text: reply.text,
                        effectReceiptIds: [...reply.effectReceiptIds],
                        contentHash: conversationReplyContentHash(content),
                    },
                };
                await runtime.roomHandlerQueue.runInLease(conv.roomId, recoveryLease, () => {
                    assertCurrent();
                    return runtime.updateMemory({
                        id: userId,
                        content: {
                            ...latestUser.content,
                            chatIdempotency: {
                                ...latestMarker,
                                replyRecoveryJson: JSON.stringify(preparedRecovery),
                            },
                        },
                    });
                });
            }
            assertCurrent();
            await runtime.roomHandlerQueue.runInLease(conv.roomId, recoveryLease, () => {
                assertCurrent();
                const metadata = latestAssistant.metadata
                    ? normalizeFailureMetadata
                        ? clearRecoveredReplyFailureMarkers(latestAssistant.metadata)
                        : { ...latestAssistant.metadata }
                    : undefined;
                if (!normalizeFailureMetadata &&
                    metadata &&
                    "chatFailureKind" in metadata)
                    delete metadata.chatFailureKind;
                return runtime.updateMemory({
                    id: assistantId,
                    content,
                    ...(metadata ? { metadata } : {}),
                });
            });
            const recoveredOutcome = {
                text: reply.text,
                agentName: state.agentName,
                messageId: assistantId,
                userMessageId: userId,
                ...(outcome?.actionResults
                    ? { actionResults: outcome.actionResults }
                    : {}),
            };
            await persistDurableConversationChatOutcome(runtime, conv.roomId, scope, marker.clientMessageId, marker.fingerprint, recoveredOutcome, recoveryLease, assertCurrent);
            assertCurrent();
            conv.updatedAt = new Date().toISOString();
            state.broadcastWs?.({
                type: "conversation-updated",
                conversation: conv,
            });
            return recoveredOutcome;
        };
        // A prepared/cached reply only resumes persistence. Record fresh model
        // work as its own run, linked to the same original user message; never
        // append it to a completed chat trajectory or replay its tools.
        const recoveredOutcome = recovery.reply
            ? await recoverAttempt()
            : await withStandaloneTrajectory(runtime, {
                source: MESSAGE_SOURCE_CLIENT_CHAT,
                metadata: {
                    roomId: conv.roomId,
                    entityId: caller.entityId,
                    messageId: userId,
                    assistantMessageId: assistantId,
                    replyRecovery: true,
                },
            }, recoverAttempt);
        disconnect.markCompleted();
        json(res, buildConversationJsonOutcome(recoveredOutcome));
    }
    catch (cause) {
        // error-policy:J1 transport boundary preserves the original failed turn;
        // no recovery failure grants permission to re-execute its actions.
        if (!disconnect.isAborted()) {
            const code = cause instanceof ElizaError ? cause.code : "";
            error(res, getErrorMessage(cause), code === "CHAT_REPLY_RECOVERY_IDENTITY"
                ? 403
                : code.startsWith("CHAT_REPLY_RECOVERY_")
                    ? 409
                    : 503);
        }
        runtime.reportError("Conversation.replyRecovery", cause, {
            roomId: conv.roomId,
            assistantMessageId: assistantId,
        });
    }
    finally {
        disconnect.dispose();
        endActive?.();
        await lease?.release();
    }
    return true;
}
async function streamConversationMessage(ctx) {
    const { req, res, pathname, readJsonBody, error, state, requestStartedAt, trustedApiPrincipal, } = ctx;
    const trace = resolveConversationTraceContext(req.headers);
    res.setHeader(ELIZA_TRACE_ID_HEADER, trace.traceId);
    res.setHeader("Access-Control-Expose-Headers", ELIZA_TRACE_ID_HEADER);
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const fenceResolution = resolveLocalVoiceRuntimeFence(req, state, convId);
    if (fenceResolution.kind === "invalid") {
        error(res, fenceResolution.message, 400);
        return true;
    }
    if (fenceResolution.kind === "conflict") {
        error(res, fenceResolution.message, 409);
        return true;
    }
    const localVoiceRuntimeFence = fenceResolution.kind === "valid" ? fenceResolution.fence : null;
    const policyId = readCanonicalSingleHeader(req, "X-Eliza-Voice-Model-Policy");
    const sessionId = readCanonicalSingleHeader(req, "X-Eliza-Voice-Session-Id");
    const voicePolicy = state.voiceModelPolicy;
    const policyRequested = policyId !== null || sessionId !== null;
    if (policyRequested &&
        (!voicePolicy ||
            policyId === "invalid" ||
            sessionId === "invalid" ||
            policyId !== voicePolicy.policyId ||
            sessionId !== voicePolicy.sessionId ||
            !/^[A-Za-z0-9_-]{1,128}$/.test(policyId ?? "") ||
            !/^[A-Za-z0-9_-]{1,128}$/.test(sessionId ?? "") ||
            !localVoiceRuntimeFence ||
            voicePolicy.conversationId !== convId ||
            voicePolicy.agentId !== String(state.runtime?.agentId))) {
        error(res, "Bounded voice model policy is not authorized", 403);
        return true;
    }
    let modelAttemptLease;
    const conv = await getConversationWithRestore(state, convId);
    // Before runtime startup there may be no restore task or conversation map
    // yet. A 404 tells the client to create a replacement conversation, so only
    // report absence once the runtime can restore persisted conversations.
    if (!conv && !state.runtime) {
        error(res, "Agent runtime not available", 503);
        return true;
    }
    if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
        error(res, "Local voice agent runtime changed", 409);
        return true;
    }
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res)) {
        return true;
    }
    const pairedSessionToken = await resolvePairedSessionToken(req, trustedApiPrincipal, state.runtime);
    const disconnectTracker = createConversationStreamDisconnectTracker({
        req,
        res,
        conversationId: conv.id,
        roomId: conv.roomId,
        // Only a revocable, DB-backed paired session gets offline delivery.
        // Other callers retain the existing disconnect-as-cancel behavior.
        continueOnDisconnect: Boolean(pairedSessionToken),
        pairedSessionToken,
        runtime: state.runtime,
    });
    if (!(await disconnectTracker.authorityReady) ||
        disconnectTracker.signal.aborted) {
        disconnectTracker.dispose();
        error(res, "Paired session ended", 401);
        return true;
    }
    const finishStreamResponse = () => {
        disconnectTracker.markCompleted();
        disconnectTracker.dispose();
        if (!res.writableEnded) {
            res.end();
        }
    };
    const chatPayload = await readChatRequestPayload(req, res, {
        runtime: state.runtime,
        readJsonBody,
        error,
    });
    if (!chatPayload) {
        finishStreamResponse();
        return true;
    }
    if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
        disconnectTracker.markCompleted();
        disconnectTracker.dispose();
        error(res, "Local voice agent runtime changed", 409);
        return true;
    }
    const { prompt, channelType, images, preferredLanguage, source, metadata: chatMetadata, clientMessageId, } = chatPayload;
    if (channelType === ChannelType.VOICE_DM &&
        voicePolicy?.conversationId === convId &&
        !policyRequested) {
        error(res, "Bounded voice model policy is required", 403);
        finishStreamResponse();
        return true;
    }
    if (policyRequested && channelType !== ChannelType.VOICE_DM) {
        error(res, "Bounded model policy requires voice transport", 403);
        finishStreamResponse();
        return true;
    }
    logger.info({ traceId: trace.traceId, traceSource: trace.source }, "[ConversationStream] accepted validated trace context");
    const tokenWriter = createChatTokenStreamWriter();
    // The SSE channel opens as soon as the request is validated — before
    // runtime resolution, room setup, and user-message persistence — so the
    // client sees headers, an immediate `thinking` status, and heartbeats
    // during the pre-model work (runtime warming alone can take seconds; the
    // pre-model DB steps add serial round-trips). Everything past this point
    // reports failure as a structured SSE `error` event (the client maps
    // `type:"error"` data lines to StreamGenerationError); only the validation
    // above may answer with plain HTTP status codes.
    initSse(res);
    writeConversationStreamHeartbeat(res, disconnectTracker);
    const heartbeatInterval = setInterval(() => {
        if (disconnectTracker.checkConnectionClosed()) {
            return;
        }
        writeConversationStreamHeartbeat(res, disconnectTracker);
    }, 5000);
    let chatReservation = null;
    let chatIdempotencyScope = String(conv.roomId);
    let reservationSettled = false;
    let runtimeTurnLease = null;
    const runtime = state.runtime;
    const releaseTurnReservation = () => releaseChatMessageId(chatIdempotencyScope, clientMessageId ?? null, chatReservation);
    try {
        const failStream = (message) => {
            releaseTurnReservation();
            writeSse(res, { type: "error", message });
            clearInterval(heartbeatInterval);
            finishStreamResponse();
            return true;
        };
        // Runtime readiness is a lifecycle/API boundary. A chat request must fail
        // immediately when capability is absent instead of occupying an SSE socket
        // behind a hidden boot timer.
        if (!runtime) {
            return failStream("Agent is not running");
        }
        const inferenceTimer = getInferenceTimer() ??
            new InferenceTurnTimer({
                turnId: nextInferenceTurnId(),
                traceId: trace.traceId,
                label: "chat-request",
                roomId: conv.roomId,
                t0EpochMs: requestStartedAt,
            });
        const caller = resolveConversationCaller(req, state, trustedApiPrincipal, runtime);
        const userId = caller.entityId;
        if (policyRequested && voicePolicy?.ownerId !== String(userId)) {
            return failStream("Bounded voice model owner changed");
        }
        chatIdempotencyScope = buildConversationChatIdempotencyScope(runtime, conv.roomId, caller.entityId);
        const chatFingerprint = buildConversationChatFingerprint({
            prompt,
            images,
            source,
            channelType,
            preferredLanguage,
            metadata: chatMetadata,
        });
        const assertLocalVoiceTurnFence = () => assertLocalVoiceTurnFenceCurrent(state, localVoiceRuntimeFence, conv);
        const settleTurnReservationInMemory = (outcome) => {
            setChatMessageIdOutcome(chatIdempotencyScope, clientMessageId ?? null, outcome, chatReservation);
            reservationSettled = true;
        };
        const settleTurnReservation = async (outcome) => {
            if (clientMessageId) {
                if (!runtimeTurnLease) {
                    throw new ElizaError("Chat outcome has no live room ownership", {
                        code: "CHAT_IDEMPOTENCY_LEASE_MISSING",
                        context: { roomId: conv.roomId, clientMessageId },
                    });
                }
                await persistDurableConversationChatOutcome(runtime, conv.roomId, chatIdempotencyScope, clientMessageId, chatFingerprint, outcome, runtimeTurnLease, assertLocalVoiceTurnFence);
                assertLocalVoiceTurnFence();
            }
            settleTurnReservationInMemory(outcome);
        };
        const settleDurableAssistantOutcome = async (outcome) => {
            try {
                await settleTurnReservation(outcome);
            }
            catch (settlementError) {
                assertLocalVoiceTurnFence();
                // error-policy:J7 the assistant reply is already durable and can be
                // reconstructed by its in-reply-to link after restart. Preserve the
                // truthful terminal locally while reporting the failed marker write.
                settleTurnReservationInMemory(outcome);
                runtime.reportError("ConversationStream.durableReplySettlement", settlementError, {
                    conversationId: conv.id,
                    roomId: conv.roomId,
                    clientMessageId,
                    messageId: outcome.messageId,
                });
                logger.warn({
                    err: getErrorMessage(settlementError),
                    conversationId: conv.id,
                    roomId: conv.roomId,
                    messageId: outcome.messageId,
                }, "[ConversationStream] durable assistant reply persisted but outcome marker settlement failed");
            }
        };
        const idempotencyAdmission = await awaitConversationChatAdmission(chatIdempotencyScope, clientMessageId ?? null, chatFingerprint, disconnectTracker.signal);
        if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
            return failStream("Local voice agent runtime changed");
        }
        if (idempotencyAdmission.kind === "aborted") {
            clearInterval(heartbeatInterval);
            finishStreamResponse();
            return true;
        }
        if (idempotencyAdmission.kind === "settled" &&
            !idempotencyAdmission.outcome.replyRecoveryAvailable) {
            writeConversationDoneSse(res, idempotencyAdmission.outcome);
            clearInterval(heartbeatInterval);
            finishStreamResponse();
            return true;
        }
        if (idempotencyAdmission.kind === "conflict") {
            writeSse(res, {
                type: "error",
                message: idempotencyAdmission.error.message,
                code: idempotencyAdmission.error.code,
            });
            clearInterval(heartbeatInterval);
            finishStreamResponse();
            return true;
        }
        chatReservation =
            idempotencyAdmission.kind === "owner"
                ? idempotencyAdmission.reservation
                : null;
        writeChatStatusSse(res, { kind: "thinking" });
        try {
            runtimeTurnLease = await runWithInferenceTiming(inferenceTimer, () => timeInferenceSpan("chat:room-lease-wait", () => runtime.roomHandlerQueue.acquire(conv.roomId, disconnectTracker.signal)));
            if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
                return failStream("Local voice agent runtime changed");
            }
        }
        catch (err) {
            releaseTurnReservation();
            if (disconnectTracker.isAborted()) {
                clearInterval(heartbeatInterval);
                finishStreamResponse();
                return true;
            }
            return failStream(isRoomQueueBackpressureError(err)
                ? "Conversation is busy; retry after the pending turns finish"
                : `Failed to serialize conversation turn: ${getErrorMessage(err)}`);
        }
        try {
            if (state.conversations.get(conv.id) !== conv ||
                state.deletedConversationIds.has(conv.id)) {
                return failStream("Conversation was deleted");
            }
            let durableRecovery;
            try {
                durableRecovery = await recoverDurableConversationChatOutcome(runtime, conv.roomId, chatIdempotencyScope, clientMessageId, chatFingerprint, state.agentName, runtimeTurnLease, assertLocalVoiceTurnFence);
            }
            catch (err) {
                // error-policy:J1 A local voice generation-fence failure is
                // translated at the open SSE transport boundary.
                if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
                    return failStream(getErrorMessage(err));
                }
                throw err;
            }
            if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
                return failStream("Local voice agent runtime changed");
            }
            if (durableRecovery.kind === "conflict") {
                releaseTurnReservation();
                writeSse(res, {
                    type: "error",
                    message: durableRecovery.error.message,
                    code: durableRecovery.error.code,
                });
                clearInterval(heartbeatInterval);
                finishStreamResponse();
                return true;
            }
            if (durableRecovery.kind === "settled") {
                try {
                    await settleTurnReservation(durableRecovery.outcome);
                    assertLocalVoiceTurnFence();
                }
                catch (err) {
                    // error-policy:J1 A late settlement fence failure is translated
                    // before the route can emit a successful terminal frame.
                    if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
                        return failStream(getErrorMessage(err));
                    }
                    throw err;
                }
                writeConversationDoneSse(res, durableRecovery.outcome);
                clearInterval(heartbeatInterval);
                finishStreamResponse();
                return true;
            }
            let userMessages;
            try {
                if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
                    return failStream("Local voice agent runtime changed");
                }
                userMessages = await buildUserMessages({
                    images,
                    prompt,
                    userId,
                    agentId: runtime.agentId,
                    roomId: conv.roomId,
                    channelType,
                    messageSource: source,
                    metadata: chatMetadata,
                });
                if (!isLocalVoiceRuntimeFenceCurrent(state, localVoiceRuntimeFence, conv)) {
                    return failStream("Local voice agent runtime changed");
                }
            }
            catch (err) {
                const handled = failStream(`Failed to prepare user message: ${getErrorMessage(err)}`);
                return handled;
            }
            bindClientUserMemoryId(clientMessageId ?? null, chatIdempotencyScope, chatFingerprint, userMessages);
            const { userMessage, messageToStore } = userMessages;
            const connectionDescriptor = captureConversationConnection(state, runtime, conv, caller, assertLocalVoiceTurnFence);
            try {
                await scheduleConversationConnectionEnsure(connectionDescriptor, () => establishConversationConnection(connectionDescriptor, conv.title));
                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                await attestAuthenticatedApiDeliveryAudience(runtime, userMessage, trustedApiPrincipal);
            }
            catch (err) {
                releaseTurnReservation();
                const handled = failStream(`Failed to initialize conversation room: ${getErrorMessage(err)}`);
                return handled;
            }
            const routedUserMessage = withViewInteractionClient(userMessage, req);
            if (policyRequested && voicePolicy) {
                modelAttemptLease = voicePolicy.allowance.openTurn(String(routedUserMessage.id), disconnectTracker.signal, () => {
                    if (state.voiceModelPolicy !== voicePolicy)
                        throw new ElizaError("Bounded voice model policy retired", {
                            code: "MODEL_ATTEMPT_POLICY_CLOSED",
                        });
                    assertLocalVoiceTurnFence();
                });
            }
            const turnStartedAt = Date.now();
            try {
                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                await persistClientUserMemory(runtime, messageToStore, clientMessageId ?? null, runtimeTurnLease, assertLocalVoiceTurnFence);
                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
            }
            catch (err) {
                const connectionFailed = isConversationConnectionError(err);
                if (connectionFailed) {
                    releaseTurnReservation();
                }
                const handled = failStream(`${connectionFailed ? "Failed to refresh conversation room" : "Failed to store user message"}: ${getErrorMessage(err)}`);
                return handled;
            }
            bindIncomingMessagePersistence(routedUserMessage, messageToStore);
            // ── Local runtime path (streaming) ───────────────────────
            const endActiveChatTurn = beginActiveChatTurn(state);
            // Completion callbacks belong to this acquired lease, not the mutable
            // cleanup slot that is cleared when the request finally releases it.
            const generationLease = runtimeTurnLease;
            let streamedText = "";
            // The route already wrote a `thinking` status when the SSE channel opened;
            // collapse the identical opening status generateChatResponse re-emits so
            // the wire carries each phase transition once. Distinct consecutive phases
            // (thinking → running_action → thinking) still pass through.
            let lastStatusSignature = JSON.stringify({ kind: "thinking" });
            // The early callback can settle a reply before generation later throws.
            // Keep that shared result readable by the terminal recovery path.
            const generation = {
                result: null,
            };
            let resolvedGenerationText;
            let replyReadyPublished = false;
            let generationCompletion;
            let generationDelivered = false;
            try {
                const assertCurrentGenerationOwner = () => assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                const publishReplyReady = async (result) => {
                    if (replyReadyPublished ||
                        // Failure text is a typed system status, not an early model reply.
                        result.terminalFailure !== undefined ||
                        result.noResponseReason === "ignored" ||
                        disconnectTracker.isAborted() ||
                        disconnectTracker.checkConnectionClosed()) {
                        return;
                    }
                    assertCurrentGenerationOwner();
                    resolvedGenerationText = normalizeChatResponseText(result.text, state.logBuffer, runtime);
                    writeSse(res, {
                        type: "reply_ready",
                        fullText: result.transcriptVisibility === "internal"
                            ? ""
                            : resolvedGenerationText,
                        // Generation already copied the finalized client receipts. Expose
                        // that same snapshot now; durable completion still belongs to done.
                        ...(result.actionResults?.length
                            ? { actionResults: result.actionResults }
                            : {}),
                    });
                    replyReadyPublished = true;
                    // Bun's node:http compatibility layer can retain a small write
                    // until the handler reaches its next I/O boundary.
                    await new Promise((resolve) => setImmediate(resolve));
                };
                const completeGeneration = (result) => {
                    if (generationCompletion)
                        return generationCompletion;
                    generationCompletion = (async () => {
                        generation.result = result;
                        assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                        conv.updatedAt = new Date().toISOString();
                        if (result.noResponseReason !== "ignored") {
                            const resolvedText = resolvedGenerationText ??
                                normalizeChatResponseText(result.text, state.logBuffer, runtime);
                            const visibleResolvedText = result.transcriptVisibility === "internal" ? "" : resolvedText;
                            if (!disconnectTracker.isAborted() &&
                                !result.terminalFailure &&
                                !streamedText &&
                                resolvedText &&
                                result.transcriptVisibility !== "internal") {
                                for (const chunk of chunkVisibleTextForSse(resolvedText)) {
                                    if (disconnectTracker.isAborted())
                                        break;
                                    streamedText += chunk;
                                    tokenWriter.writeChunk(res, chunk, streamedText);
                                }
                            }
                            // The reply text is now authoritative: model generation, planner
                            // actions, callback replacement, and final normalization have all
                            // settled. Publish that boundary before durable persistence so
                            // realtime voice can synthesize while the receipt/ids are written;
                            // the later `done` frame remains the sole durable completion and
                            // carries view-handoff metadata.
                            await publishReplyReady(result);
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            // Durable completion belongs to the turn, not to the transport. A
                            // disconnected client can retry the same key and receive this exact
                            // committed outcome without executing or billing another model turn.
                            const persistedAssistant = await resolvePersistedAssistantTurn(runtime, conv.roomId, turnStartedAt, result, resolvedText, channelType, generationLease, messageToStore.id, assertLocalVoiceTurnFence);
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const persistedAssistantId = persistedAssistant.kind === "durable"
                                ? persistedAssistant.id
                                : undefined;
                            if (result.actionCallbackHistory?.length &&
                                persistedAssistantId) {
                                await persistRecentAssistantActionCallbackHistory(runtime, conv.roomId, result.actionCallbackHistory, turnStartedAt, persistedAssistantId, generationLease, assertLocalVoiceTurnFence);
                            }
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const replyRecoveryAvailable = await persistConversationReplyRecovery(runtime, conv.roomId, messageToStore.id, persistedAssistantId, result, generationLease, assertLocalVoiceTurnFence);
                            const outcome = buildGenerationMessageIdOutcome(result, visibleResolvedText, persistedAssistantId, {
                                userMessageId: messageToStore.id,
                                ...(persistedAssistant.kind === "ephemeral"
                                    ? { assistantEphemeral: true }
                                    : {}),
                                ...(result.usedActionCallbacks
                                    ? { historyRefreshRequired: true }
                                    : {}),
                            });
                            if (replyRecoveryAvailable)
                                outcome.replyRecoveryAvailable = true;
                            if (persistedAssistant.kind === "durable") {
                                await settleDurableAssistantOutcome(outcome);
                            }
                            else {
                                await settleTurnReservation(outcome);
                            }
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            if (!disconnectTracker.isAborted()) {
                                writeConversationDoneSse(res, outcome);
                            }
                        }
                        else {
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const outcome = buildGenerationMessageIdOutcome(result, "", undefined, {
                                userMessageId: messageToStore.id,
                                assistantEphemeral: true,
                            });
                            await settleTurnReservation(outcome);
                            if (!disconnectTracker.isAborted()) {
                                writeConversationDoneSse(res, outcome);
                            }
                        }
                        // Delivery is durable now, independently of post-turn reflection.
                        // generateChatResponse still drains room-state work, and the outer
                        // route retains its lease/server activity until that barrier settles.
                        clearInterval(heartbeatInterval);
                        finishStreamResponse();
                        generationDelivered = true;
                    })();
                    return generationCompletion;
                };
                const generationRoomLease = runtimeTurnLease;
                const generate = () => generateChatResponse(runtime, routedUserMessage, state.agentName, {
                    traceId: trace.traceId,
                    inferenceTimer,
                    abortSignal: disconnectTracker.signal,
                    roomHandlerLease: generationRoomLease,
                    onStatus: (status) => {
                        assertCurrentGenerationOwner();
                        if (disconnectTracker.isAborted() ||
                            disconnectTracker.checkConnectionClosed()) {
                            return;
                        }
                        // A new progress label is visible even when the phase is unchanged.
                        const signature = JSON.stringify(status);
                        if (signature === lastStatusSignature) {
                            return;
                        }
                        lastStatusSignature = signature;
                        writeChatStatusSse(res, status);
                    },
                    onToolEvent: (event) => {
                        assertCurrentGenerationOwner();
                        if (disconnectTracker.isAborted() ||
                            disconnectTracker.checkConnectionClosed()) {
                            return;
                        }
                        writeChatToolSse(res, event);
                    },
                    onChunk: (chunk, origin) => {
                        if (!chunk)
                            return;
                        assertCurrentGenerationOwner();
                        const connectionClosed = disconnectTracker.checkConnectionClosed();
                        if (disconnectTracker.signal.aborted)
                            return;
                        // Keep the durable candidate complete even when a paired client
                        // has gone offline. Transport closure only suppresses writes.
                        streamedText += chunk;
                        if (connectionClosed || disconnectTracker.isAborted())
                            return;
                        // Action-callback text is provisional on the wire: the final reply
                        // may replace it wholesale, and a voice client must not speak text
                        // it cannot retract. Text rendering remains unchanged.
                        tokenWriter.writeChunk(res, chunk, streamedText, {
                            provisional: origin === "action_callback",
                        });
                    },
                    onSnapshot: (text, origin) => {
                        if (!text)
                            return;
                        assertCurrentGenerationOwner();
                        const connectionClosed = disconnectTracker.checkConnectionClosed();
                        if (disconnectTracker.signal.aborted)
                            return;
                        // Action callbacks may be the first visible source for a turn. An
                        // authoritative snapshot therefore has to be able to establish the
                        // stream, not merely revise text emitted by a model-token source.
                        // Structured field extractors can briefly normalize whitespace or
                        // closing punctuation while the same visible field is still
                        // streaming. Do not shrink the user-visible token stream for
                        // prefix-equivalent snapshots; later longer snapshots/deltas still
                        // advance normally.
                        if (text.length < streamedText.length &&
                            streamedText.startsWith(text)) {
                            return;
                        }
                        streamedText = text;
                        if (connectionClosed || disconnectTracker.isAborted())
                            return;
                        tokenWriter.writeSnapshot(res, streamedText, {
                            provisional: origin === "action_callback",
                        });
                    },
                    resolveNoResponseText: () => {
                        assertCurrentGenerationOwner();
                        return resolveNoResponseFallback(state.logBuffer, runtime);
                    },
                    onReplyReady: completeGeneration,
                    preferredLanguage,
                });
                const result = modelAttemptLease
                    ? await runWithStreamingContext({
                        messageId: String(routedUserMessage.id),
                        modelAttemptTurnId: String(routedUserMessage.id),
                        modelAttemptLease,
                        abortSignal: disconnectTracker.signal,
                    }, generate)
                    : await generate();
                // Adapters that do not publish the early callback still use the same
                // durable completion path. The promise fences repeated callbacks.
                await completeGeneration(result);
            }
            catch (err) {
                const generationResult = generation.result;
                // Post-delivery drain failure must reach the HTTP error boundary
                // without replacing the durable outcome or writing to its closed SSE.
                if (generationDelivered)
                    throw err;
                let terminalError = err;
                try {
                    assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                }
                catch (runtimeError) {
                    terminalError = runtimeError;
                }
                if (isConversationConnectionError(terminalError)) {
                    logger.warn({
                        err: getErrorMessage(terminalError),
                        conversationId: conv.id,
                        roomId: conv.roomId,
                    }, "[ConversationStream] connection prerequisite failed");
                    releaseTurnReservation();
                    if (!disconnectTracker.isAborted()) {
                        writeSse(res, {
                            type: "error",
                            message: `Failed to refresh conversation room: ${getErrorMessage(terminalError)}`,
                        });
                    }
                }
                else if (isTurnAbortError(terminalError)) {
                    logger.info({
                        conversationId: conv.id,
                        roomId: conv.roomId,
                        streamedTextLength: streamedText.length,
                    }, "[ConversationStream] generation aborted; persisting interrupted receipt");
                    // Stop/disconnect is a terminal outcome of the turn, not a
                    // discarded one: persist the interrupted receipt (partial text or
                    // the zero-token case) and settle the idempotency key so reload
                    // recovery and a retried clientMessageId adopt this durable state
                    // instead of regenerating (#17216).
                    if (!getChatMessageIdOutcome(chatIdempotencyScope, clientMessageId ?? null)) {
                        try {
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const receiptId = crypto.randomUUID();
                            const persisted = await persistInterruptedAssistantReceipt(runtime, conv.roomId, streamedText, channelType, messageToStore.id, receiptId, runtimeTurnLease, assertLocalVoiceTurnFence);
                            conv.updatedAt = new Date().toISOString();
                            const interruptedOutcome = {
                                text: streamedText,
                                agentName: state.agentName,
                                ...(persisted.id ? { messageId: persisted.id } : {}),
                                userMessageId: messageToStore.id,
                                interrupted: true,
                            };
                            try {
                                await settleTurnReservation(interruptedOutcome);
                            }
                            catch (settlementError) {
                                assertLocalVoiceTurnFence();
                                // error-policy:J7 the receipt is already durable and remains
                                // recoverable through its deterministic in-reply-to link;
                                // preserve that terminal outcome locally while reporting the
                                // failed optimization that writes it onto the user marker.
                                settleTurnReservationInMemory(interruptedOutcome);
                                runtime.reportError("ConversationStream.interruptedReceiptSettlement", settlementError, {
                                    conversationId: conv.id,
                                    roomId: conv.roomId,
                                    clientMessageId,
                                    receiptId: persisted.id,
                                });
                                logger.warn({
                                    err: getErrorMessage(settlementError),
                                    conversationId: conv.id,
                                    roomId: conv.roomId,
                                    receiptId: persisted.id,
                                }, "[ConversationStream] interrupted receipt persisted but outcome marker settlement failed");
                            }
                            assertLocalVoiceTurnFence();
                            if (!disconnectTracker.isAborted()) {
                                writeConversationDoneSse(res, interruptedOutcome);
                            }
                        }
                        catch (persistErr) {
                            // error-policy:J4 the interrupted receipt is best-effort
                            // terminal state for an already-severed transport; on write
                            // failure the key is released so the client's next send owns a
                            // fresh turn rather than replaying a half-settled outcome.
                            logger.warn({
                                err: getErrorMessage(persistErr),
                                conversationId: conv.id,
                                roomId: conv.roomId,
                            }, "[ConversationStream] failed to persist interrupted receipt");
                            releaseTurnReservation();
                        }
                    }
                }
                else if (isCallbackHistoryPersistenceError(terminalError) ||
                    terminalError instanceof AssistantReplyPersistenceError) {
                    releaseTurnReservation();
                    if (!disconnectTracker.isAborted()) {
                        writeSse(res, {
                            type: "error",
                            message: getErrorMessage(terminalError instanceof AssistantReplyPersistenceError
                                ? (terminalError.cause ?? terminalError)
                                : terminalError),
                        });
                    }
                }
                else if (!disconnectTracker.signal.aborted) {
                    // If text was already streamed to the client (e.g. the initial
                    // response succeeded but planner follow-up failed), use the
                    // streamed text as the final reply instead of replacing it with a
                    // generic fallback.
                    if (streamedText) {
                        logger.warn({
                            err: getErrorMessage(terminalError),
                            streamedTextLength: streamedText.length,
                        }, "Post-generation error after text was already streamed — using streamed text");
                        try {
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const routeOwnedId = crypto.randomUUID();
                            const persisted = await persistAssistantConversationMemory(runtime, conv.roomId, { text: streamedText, inReplyTo: messageToStore.id }, channelType, turnStartedAt, routeOwnedId, runtimeTurnLease, assertLocalVoiceTurnFence);
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            conv.updatedAt = new Date().toISOString();
                            const outcome = {
                                text: streamedText,
                                agentName: state.agentName,
                                ...(persisted?.id ? { messageId: persisted.id } : {}),
                                userMessageId: messageToStore.id,
                            };
                            await settleTurnReservation(outcome);
                            if (!disconnectTracker.isAborted()) {
                                writeConversationDoneSse(res, outcome);
                            }
                        }
                        catch (persistErr) {
                            if (disconnectTracker.isAborted()) {
                                runtime.reportError("ConversationStream.offlineFailurePersistence", persistErr, {
                                    conversationId: conv.id,
                                    roomId: conv.roomId,
                                    clientMessageId,
                                });
                            }
                            releaseTurnReservation();
                            if (!disconnectTracker.isAborted()) {
                                writeSse(res, {
                                    type: "error",
                                    message: getErrorMessage(persistErr),
                                });
                            }
                        }
                    }
                    else {
                        logger.warn({
                            err: getErrorMessage(terminalError),
                            stack: terminalError instanceof Error
                                ? terminalError.stack
                                : undefined,
                        }, "Chat generation failed with no streamed text");
                        try {
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const generationResolvedText = generationResult
                                ? normalizeChatResponseText(generationResult.text, state.logBuffer, runtime)
                                : "";
                            const exactPersistedResponse = generationResult &&
                                generationResult.transcriptVisibility !== "internal" &&
                                generationResolvedText
                                ? findPersistedGeneratedAssistantTurn(runtime, conv.roomId, generationResult)
                                : null;
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const exactPersistedId = exactPersistedResponse?.id;
                            if (generationResult &&
                                exactPersistedResponse &&
                                exactPersistedId) {
                                if (exactPersistedResponse.content.text !== generationResolvedText) {
                                    await runtime.roomHandlerQueue.runInLease(conv.roomId, runtimeTurnLease, async () => {
                                        assertLocalVoiceTurnFence();
                                        await runtime.updateMemory({
                                            ...exactPersistedResponse,
                                            content: buildPersistedAssistantContent(generationResolvedText, generationResult, messageToStore.id),
                                        });
                                        assertLocalVoiceTurnFence();
                                    });
                                    assertLocalVoiceTurnFence();
                                }
                                logger.warn({
                                    err: getErrorMessage(terminalError),
                                    conversationId: conv.id,
                                    roomId: conv.roomId,
                                    messageId: exactPersistedId,
                                }, "Chat generation failed after its exact assistant reply was already durable");
                                if (generationResult.actionCallbackHistory?.length) {
                                    await persistRecentAssistantActionCallbackHistory(runtime, conv.roomId, generationResult.actionCallbackHistory, turnStartedAt, exactPersistedId, runtimeTurnLease, assertLocalVoiceTurnFence);
                                }
                                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                                const outcome = buildGenerationMessageIdOutcome(generationResult, generationResolvedText, exactPersistedId, {
                                    userMessageId: messageToStore.id,
                                    ...(generationResult.usedActionCallbacks
                                        ? { historyRefreshRequired: true }
                                        : {}),
                                });
                                await settleTurnReservation(outcome);
                                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                                if (!disconnectTracker.isAborted()) {
                                    writeConversationDoneSse(res, outcome);
                                }
                                return true;
                            }
                        }
                        catch (salvageErr) {
                            if (disconnectTracker.isAborted()) {
                                runtime.reportError("ConversationStream.offlineFailurePersistence", salvageErr, {
                                    conversationId: conv.id,
                                    roomId: conv.roomId,
                                    clientMessageId,
                                });
                            }
                            // error-policy:J1 route boundary — this code already runs inside
                            // the generation catch, so exact-row salvage failures require
                            // their own observable SSE terminal instead of escaping silently.
                            releaseTurnReservation();
                            if (!disconnectTracker.isAborted()) {
                                writeSse(res, {
                                    type: "error",
                                    message: getErrorMessage(salvageErr),
                                });
                            }
                            return true;
                        }
                        const providerIssueReply = getChatFailureReply(terminalError, state.logBuffer);
                        const failureKind = classifyChatFailure(terminalError, state.logBuffer);
                        try {
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const routeOwnedId = crypto.randomUUID();
                            const persisted = await persistAssistantConversationMemory(runtime, conv.roomId, { text: providerIssueReply, inReplyTo: messageToStore.id }, channelType, undefined, routeOwnedId, runtimeTurnLease, assertLocalVoiceTurnFence);
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            conv.updatedAt = new Date().toISOString();
                            const outcome = {
                                text: providerIssueReply,
                                agentName: state.agentName,
                                ...(persisted?.id ? { messageId: persisted.id } : {}),
                                userMessageId: messageToStore.id,
                                failureKind,
                            };
                            await settleTurnReservation(outcome);
                            if (!disconnectTracker.isAborted()) {
                                writeConversationDoneSse(res, outcome);
                            }
                        }
                        catch (persistErr) {
                            if (disconnectTracker.isAborted()) {
                                runtime.reportError("ConversationStream.offlineFailurePersistence", persistErr, {
                                    conversationId: conv.id,
                                    roomId: conv.roomId,
                                    clientMessageId,
                                });
                            }
                            releaseTurnReservation();
                            if (!disconnectTracker.isAborted()) {
                                writeSse(res, {
                                    type: "error",
                                    message: getErrorMessage(persistErr),
                                });
                            }
                        }
                    }
                }
                else {
                    if (!getChatMessageIdOutcome(chatIdempotencyScope, clientMessageId ?? null)) {
                        releaseTurnReservation();
                    }
                }
            }
            finally {
                if (clientMessageId &&
                    !getChatMessageIdOutcome(chatIdempotencyScope, clientMessageId)) {
                    releaseTurnReservation();
                }
                clearInterval(heartbeatInterval);
                try {
                    finishStreamResponse();
                }
                finally {
                    endActiveChatTurn();
                }
            }
            return true;
        }
        finally {
            await runtimeTurnLease.release();
            runtimeTurnLease = null;
        }
    }
    catch (streamError) {
        // error-policy:J2 context-adding rethrow: the terminal SSE `error` frame
        // is emitted here, then the original failure is rethrown unchanged to the
        // J1 HTTP boundary.
        // Everything past `initSse` reports failure as a structured SSE `error`
        // event; a throw out of turn setup must not become the one silent exit.
        try {
            if (!disconnectTracker.isAborted() && !res.writableEnded) {
                writeSse(res, {
                    type: "error",
                    message: getErrorMessage(streamError),
                });
            }
        }
        catch (frameError) {
            // error-policy:J6 best-effort teardown: the terminal frame is a
            // courtesy to a socket that is already gone, and the rethrow below
            // still carries the real failure to the J1 boundary.
            logger.warn(`[conversation-stream] terminal error frame undeliverable: ${getErrorMessage(frameError)}`);
        }
        throw streamError;
    }
    finally {
        modelAttemptLease?.close();
        if (!reservationSettled)
            releaseTurnReservation();
        // The heartbeat timer and the SSE socket are owned by this request, not
        // by the HTTP error boundary that catches the rethrow above, so this is
        // the only place a failed turn can release them. Both calls are
        // idempotent: the ordinary exits already cleaned up and are unchanged.
        clearInterval(heartbeatInterval);
        finishStreamResponse();
    }
}
async function sendConversationMessage(ctx) {
    const { req, res, pathname, readJsonBody, json, error, state, requestStartedAt, trustedApiPrincipal, } = ctx;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res)) {
        return true;
    }
    const chatPayload = await readChatRequestPayload(req, res, {
        runtime: state.runtime,
        readJsonBody,
        error,
    });
    if (!chatPayload)
        return true;
    const { prompt, channelType, images, preferredLanguage, source, metadata: restMetadata, clientMessageId, } = chatPayload;
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    const inferenceTimer = getInferenceTimer() ??
        new InferenceTurnTimer({
            turnId: nextInferenceTurnId(),
            label: "chat-request",
            roomId: conv.roomId,
            t0EpochMs: requestStartedAt,
        });
    const caller = resolveConversationCaller(req, state, trustedApiPrincipal, runtime);
    const userId = caller.entityId;
    const chatIdempotencyScope = buildConversationChatIdempotencyScope(runtime, conv.roomId, caller.entityId);
    const chatFingerprint = buildConversationChatFingerprint({
        prompt,
        images,
        source,
        channelType,
        preferredLanguage,
        metadata: restMetadata,
    });
    const admissionDisconnectTracker = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation turn admission",
    });
    const idempotencyAdmission = await awaitConversationChatAdmission(chatIdempotencyScope, clientMessageId ?? null, chatFingerprint, admissionDisconnectTracker.signal);
    if (idempotencyAdmission.kind === "aborted") {
        admissionDisconnectTracker.dispose();
        return true;
    }
    if (idempotencyAdmission.kind === "settled" &&
        !idempotencyAdmission.outcome.replyRecoveryAvailable) {
        admissionDisconnectTracker.markCompleted();
        admissionDisconnectTracker.dispose();
        json(res, buildConversationJsonOutcome(idempotencyAdmission.outcome));
        return true;
    }
    if (idempotencyAdmission.kind === "conflict") {
        admissionDisconnectTracker.markCompleted();
        admissionDisconnectTracker.dispose();
        error(res, idempotencyAdmission.error.message, 409);
        return true;
    }
    const chatReservation = idempotencyAdmission.kind === "owner"
        ? idempotencyAdmission.reservation
        : null;
    let reservationSettled = false;
    let runtimeTurnLease = null;
    const releaseTurnReservation = () => releaseChatMessageId(chatIdempotencyScope, clientMessageId ?? null, chatReservation);
    const settleTurnReservation = async (outcome) => {
        if (clientMessageId) {
            if (!runtimeTurnLease) {
                throw new ElizaError("Chat outcome has no live room ownership", {
                    code: "CHAT_IDEMPOTENCY_LEASE_MISSING",
                    context: { roomId: conv.roomId, clientMessageId },
                });
            }
            await persistDurableConversationChatOutcome(runtime, conv.roomId, chatIdempotencyScope, clientMessageId, chatFingerprint, outcome, runtimeTurnLease);
        }
        setChatMessageIdOutcome(chatIdempotencyScope, clientMessageId ?? null, outcome, chatReservation);
        reservationSettled = true;
    };
    try {
        try {
            runtimeTurnLease = await runWithInferenceTiming(inferenceTimer, () => timeInferenceSpan("chat:room-lease-wait", () => runtime.roomHandlerQueue.acquire(conv.roomId, admissionDisconnectTracker.signal)));
        }
        catch (err) {
            admissionDisconnectTracker.dispose();
            releaseTurnReservation();
            if (admissionDisconnectTracker.isAborted()) {
                return true;
            }
            error(res, isRoomQueueBackpressureError(err)
                ? "Conversation is busy; retry after the pending turns finish"
                : `Failed to serialize conversation turn: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
            return true;
        }
        admissionDisconnectTracker.markCompleted();
        admissionDisconnectTracker.dispose();
        try {
            if (state.conversations.get(conv.id) !== conv ||
                state.deletedConversationIds.has(conv.id)) {
                releaseTurnReservation();
                error(res, "Conversation was deleted", 404);
                return true;
            }
            const durableRecovery = await recoverDurableConversationChatOutcome(runtime, conv.roomId, chatIdempotencyScope, clientMessageId, chatFingerprint, state.agentName, runtimeTurnLease);
            if (durableRecovery.kind === "conflict") {
                releaseTurnReservation();
                error(res, durableRecovery.error.message, 409);
                return true;
            }
            if (durableRecovery.kind === "settled") {
                await settleTurnReservation(durableRecovery.outcome);
                json(res, buildConversationJsonOutcome(durableRecovery.outcome));
                return true;
            }
            let connectionDescriptor;
            try {
                connectionDescriptor = await ensureConversationRoom(state, runtime, conv, caller);
            }
            catch (err) {
                releaseTurnReservation();
                error(res, `Failed to initialize conversation room: ${getErrorMessage(err)}`, 500);
                return true;
            }
            let userMessages;
            try {
                userMessages = await buildUserMessages({
                    images,
                    prompt,
                    userId,
                    agentId: runtime.agentId,
                    roomId: conv.roomId,
                    channelType,
                    messageSource: source,
                    metadata: restMetadata,
                });
            }
            catch (err) {
                releaseTurnReservation();
                error(res, `Failed to prepare user message: ${getErrorMessage(err)}`, 500);
                return true;
            }
            bindClientUserMemoryId(clientMessageId ?? null, chatIdempotencyScope, chatFingerprint, userMessages);
            const { userMessage, messageToStore } = userMessages;
            try {
                await attestAuthenticatedApiDeliveryAudience(runtime, userMessage, trustedApiPrincipal);
            }
            catch (err) {
                releaseTurnReservation();
                error(res, `Failed to attest conversation audience: ${getErrorMessage(err)}`, 500);
                return true;
            }
            const routedUserMessage = withViewInteractionClient(userMessage, req);
            const turnStartedAt = Date.now();
            try {
                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                await persistClientUserMemory(runtime, messageToStore, clientMessageId ?? null, runtimeTurnLease);
                assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
            }
            catch (err) {
                releaseTurnReservation();
                error(res, `Failed to store user message: ${getErrorMessage(err)}`, 500);
                return true;
            }
            bindIncomingMessagePersistence(routedUserMessage, messageToStore);
            const endActiveChatTurn = beginActiveChatTurn(state);
            let generationDelivered = false;
            try {
                const deliveryLease = runtimeTurnLease;
                let generationCompletion;
                const completeGeneration = (result) => {
                    if (generationCompletion)
                        return generationCompletion;
                    generationCompletion = (async () => {
                        assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                        conv.updatedAt = new Date().toISOString();
                        if (result.noResponseReason !== "ignored") {
                            const resolvedText = normalizeChatResponseText(result.text, state.logBuffer, runtime);
                            const persistedAssistant = await resolvePersistedAssistantTurn(runtime, conv.roomId, turnStartedAt, result, resolvedText, channelType, deliveryLease, messageToStore.id);
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const persistedAssistantId = persistedAssistant.kind === "durable"
                                ? persistedAssistant.id
                                : undefined;
                            if (result.actionCallbackHistory?.length &&
                                persistedAssistantId) {
                                await persistRecentAssistantActionCallbackHistory(runtime, conv.roomId, result.actionCallbackHistory, turnStartedAt, persistedAssistantId, deliveryLease);
                            }
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const visibleResolvedText = result.transcriptVisibility === "internal" ? "" : resolvedText;
                            const replyRecoveryAvailable = await persistConversationReplyRecovery(runtime, conv.roomId, messageToStore.id, persistedAssistantId, result, deliveryLease);
                            const outcome = buildGenerationMessageIdOutcome(result, visibleResolvedText, persistedAssistantId, {
                                userMessageId: messageToStore.id,
                                ...(persistedAssistant.kind === "ephemeral"
                                    ? { assistantEphemeral: true }
                                    : {}),
                                ...(result.usedActionCallbacks
                                    ? { historyRefreshRequired: true }
                                    : {}),
                            });
                            if (replyRecoveryAvailable)
                                outcome.replyRecoveryAvailable = true;
                            await settleTurnReservation(outcome);
                            json(res, buildConversationJsonOutcome(outcome));
                        }
                        else {
                            assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                            const outcome = buildGenerationMessageIdOutcome(result, "", undefined, {
                                userMessageId: messageToStore.id,
                                assistantEphemeral: true,
                            });
                            await settleTurnReservation(outcome);
                            json(res, buildConversationJsonOutcome(outcome));
                        }
                        generationDelivered = true;
                    })();
                    return generationCompletion;
                };
                const result = await generateChatResponse(runtime, routedUserMessage, state.agentName, {
                    inferenceTimer,
                    roomHandlerLease: runtimeTurnLease,
                    resolveNoResponseText: () => resolveNoResponseFallback(state.logBuffer, runtime),
                    preferredLanguage,
                    onReplyReady: completeGeneration,
                });
                // Compatibility adapters may omit the early callback; the promise
                // fence ensures durable completion and JSON are still emitted once.
                await completeGeneration(result);
            }
            catch (err) {
                if (generationDelivered) {
                    // error-policy:J7 The durable reply and idempotency outcome already
                    // reached the caller; report a later drain failure without replying again.
                    runtime.reportError("ConversationJson.postDelivery", err, {
                        conversationId: conv.id,
                        roomId: conv.roomId,
                        clientMessageId,
                    });
                    return true;
                }
                if (isCallbackHistoryPersistenceError(err) ||
                    err instanceof AssistantReplyPersistenceError) {
                    releaseTurnReservation();
                    error(res, getErrorMessage(err instanceof AssistantReplyPersistenceError
                        ? (err.cause ?? err)
                        : err), 500);
                    return true;
                }
                logger.warn(`[conversations] POST /messages failed: ${err instanceof Error ? err.message : String(err)}`);
                if (isConversationConnectionError(err)) {
                    releaseTurnReservation();
                    error(res, `Failed to refresh conversation room: ${getErrorMessage(err)}`, 500);
                    return true;
                }
                const providerIssueReply = getChatFailureReply(err, state.logBuffer);
                const failureKind = classifyChatFailure(err, state.logBuffer);
                try {
                    assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                    const routeOwnedId = crypto.randomUUID();
                    const persisted = await persistAssistantConversationMemory(runtime, conv.roomId, { text: providerIssueReply, inReplyTo: messageToStore.id }, channelType, undefined, routeOwnedId, runtimeTurnLease);
                    assertConversationConnectionRuntime(state.runtime, connectionDescriptor);
                    conv.updatedAt = new Date().toISOString();
                    const outcome = {
                        text: providerIssueReply,
                        agentName: state.agentName,
                        ...(persisted?.id ? { messageId: persisted.id } : {}),
                        userMessageId: messageToStore.id,
                        failureKind,
                    };
                    await settleTurnReservation(outcome);
                    json(res, buildConversationJsonOutcome(outcome));
                }
                catch (persistErr) {
                    releaseTurnReservation();
                    error(res, getErrorMessage(persistErr), 500);
                }
            }
            finally {
                if (clientMessageId &&
                    !getChatMessageIdOutcome(chatIdempotencyScope, clientMessageId)) {
                    releaseTurnReservation();
                }
                endActiveChatTurn();
            }
            return true;
        }
        finally {
            await runtimeTurnLease.release();
            runtimeTurnLease = null;
        }
    }
    finally {
        if (!reservationSettled)
            releaseTurnReservation();
    }
}
async function greetConversation(ctx) {
    const { req, res, pathname, json, error, state, trustedApiPrincipal } = ctx;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuConversationAccessIfNeeded(req, conv, error, res)) {
        return true;
    }
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    const url = new URL(req.url ?? "", `http://${req.headers.host}`);
    const lang = url.searchParams.get("lang") ?? "en";
    const greetingAbortTracker = createRequestDisconnectAbortTracker({
        req,
        res,
        operation: "Conversation greeting admission",
    });
    let historyLease;
    try {
        historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, greetingAbortTracker.signal);
    }
    catch (err) {
        greetingAbortTracker.dispose();
        if (greetingAbortTracker.isAborted())
            return true;
        error(res, isRoomQueueBackpressureError(err)
            ? "Conversation is busy; retry after the pending turns finish"
            : `Failed to serialize conversation history: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
        return true;
    }
    greetingAbortTracker.markCompleted();
    greetingAbortTracker.dispose();
    try {
        if (state.conversations.get(conv.id) !== conv ||
            state.deletedConversationIds.has(conv.id)) {
            error(res, "Conversation was deleted", 404);
            return true;
        }
        try {
            await ensureConversationRoom(state, runtime, conv, resolveConversationCaller(req, state, trustedApiPrincipal, runtime));
        }
        catch (err) {
            error(res, `Failed to initialize conversation room: ${getErrorMessage(err)}`, 500);
            return true;
        }
        const greeting = await ensureConversationGreetingStored(state, conv, lang, historyLease);
        json(res, {
            text: greeting.text,
            agentName: greeting.agentName,
            generated: greeting.generated,
            persisted: greeting.persisted,
        });
    }
    catch (err) {
        error(res, getErrorMessage(err), 500);
    }
    finally {
        await historyLease.release();
    }
    return true;
}
async function patchConversation(ctx) {
    const { req, res, pathname, readJsonBody, json, error, state } = ctx;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const conv = await getConversationWithRestore(state, convId);
    if (!conv) {
        error(res, "Conversation not found", 404);
        return true;
    }
    if (rejectWaifuNonAdminMutationIfNeeded(req, error, res))
        return true;
    const rawPatch = await readJsonBody(req, res);
    if (rawPatch === null)
        return true;
    const parsedPatch = PatchConversationRequestSchema.safeParse(rawPatch);
    if (!parsedPatch.success) {
        error(res, parsedPatch.error.issues[0]?.message ?? "Invalid request body", 400);
        return true;
    }
    const body = parsedPatch.data;
    // A title or metadata change is persisted on the conversation's room, so it
    // needs the runtime: changing only the in-process record would show the
    // new value until the next restart and then serve the old one.
    if (!state.runtime) {
        error(res, "Agent is not running", 503);
        return true;
    }
    if (body.generate) {
        // Get the last user message to use as the prompt for generation
        let prompt = "A generic conversation";
        const memories = await state.runtime.getMemories({
            roomId: conv.roomId,
            tableName: "messages",
        });
        const lastUserMemory = memories.find((m) => m.entityId !== state.runtime?.agentId);
        if (lastUserMemory?.content?.text) {
            prompt = String(lastUserMemory.content.text);
        }
        const titleAbortTracker = createRequestDisconnectAbortTracker({
            req,
            res,
            operation: "conversation title generation",
        });
        let newTitle = null;
        try {
            newTitle = await generateConversationTitle(state.runtime, prompt, state.agentName, { signal: titleAbortTracker.signal });
        }
        finally {
            titleAbortTracker.markCompleted();
            titleAbortTracker.dispose();
        }
        if (titleAbortTracker.isAborted())
            return true;
        const fallbackTitle = prompt
            .replace(/\s+/g, " ")
            .trim()
            .split(" ")
            .slice(0, 5)
            .join(" ")
            .trim();
        const resolvedTitle = newTitle ?? fallbackTitle;
        if (resolvedTitle) {
            conv.title = resolvedTitle;
            conv.updatedAt = new Date().toISOString();
            await syncConversationRoomState(state, conv);
        }
    }
    else if (body.title?.trim()) {
        conv.title = body.title.trim();
        conv.updatedAt = new Date().toISOString();
        await syncConversationRoomState(state, conv);
    }
    if (body.metadata !== undefined) {
        const nextMetadata = sanitizeConversationMetadata(body.metadata);
        if (nextMetadata) {
            conv.metadata = nextMetadata;
        }
        else {
            delete conv.metadata;
        }
        conv.updatedAt = new Date().toISOString();
        await syncConversationRoomState(state, conv);
    }
    json(res, { conversation: conv });
    return true;
}
async function cleanupEmptyConversations(ctx) {
    const { req, res, readJsonBody, json, error, state } = ctx;
    if (rejectWaifuNonAdminMutationIfNeeded(req, error, res))
        return true;
    const rawCleanup = await readJsonBody(req, res);
    if (rawCleanup === null)
        return true;
    const parsedCleanup = PostConversationCleanupEmptyRequestSchema.safeParse(rawCleanup);
    if (!parsedCleanup.success) {
        error(res, parsedCleanup.error.issues[0]?.message ?? "Invalid request body", 400);
        return true;
    }
    await waitForConversationRestore(state);
    const runtime = state.runtime;
    if (!runtime) {
        error(res, "Agent runtime not available", 503);
        return true;
    }
    const keepId = parsedCleanup.data.keepId;
    const agentId = runtime.agentId;
    const deleted = [];
    for (const conv of Array.from(state.conversations.values())) {
        if (keepId && conv.id === keepId)
            continue;
        if (state.deletedConversationIds.has(conv.id))
            continue;
        const cleanupAbortTracker = createRequestDisconnectAbortTracker({
            req,
            res,
            operation: "Empty conversation cleanup admission",
        });
        let historyLease;
        try {
            historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, cleanupAbortTracker.signal);
        }
        catch (err) {
            cleanupAbortTracker.dispose();
            if (cleanupAbortTracker.isAborted())
                return true;
            error(res, isRoomQueueBackpressureError(err)
                ? "Conversation is busy; retry cleanup after pending turns finish"
                : `Failed to serialize conversation cleanup: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
            return true;
        }
        cleanupAbortTracker.markCompleted();
        cleanupAbortTracker.dispose();
        try {
            if (state.conversations.get(conv.id) !== conv ||
                state.deletedConversationIds.has(conv.id)) {
                continue;
            }
            const memories = await runtime.getMemories({
                roomId: conv.roomId,
                tableName: "messages",
            });
            const hasUserMessage = memories.some((m) => m.entityId !== agentId);
            if (hasUserMessage)
                continue;
            const memoryIds = memories
                .map((memory) => memory.id)
                .filter((memoryId) => typeof memoryId === "string" && memoryId.trim().length > 0);
            if (memoryIds.length > 0) {
                await runtime.roomHandlerQueue.runInLease(conv.roomId, historyLease, () => deleteConversationMemories(runtime, memoryIds));
            }
            await deleteConversationRoomData(runtime, conv.roomId);
            state.conversations.delete(conv.id);
            markConversationDeleted(state, conv.id);
            deleted.push(conv.id);
        }
        finally {
            await historyLease.release();
        }
    }
    json(res, { deleted });
    return true;
}
async function deleteConversation(ctx) {
    const { req, res, pathname, json, error, state } = ctx;
    if (rejectWaifuNonAdminMutationIfNeeded(req, error, res))
        return true;
    const convId = decodePathComponent(pathname.split("/")[3], res, "conversation id");
    if (convId === null)
        return true;
    const conv = await getConversationWithRestore(state, convId);
    const runtime = state.runtime;
    if (conv?.roomId && !runtime) {
        // The room and its messages can only be deleted through the runtime. A
        // tombstone without that deletion would hide the conversation until the
        // tombstone expires and keep its messages in search and the memory feed.
        error(res, "Agent is not running", 503);
        return true;
    }
    if (conv?.roomId && runtime) {
        const deleteConversationAbortTracker = createRequestDisconnectAbortTracker({
            req,
            res,
            operation: "Conversation deletion admission",
        });
        let historyLease;
        try {
            historyLease = await runtime.roomHandlerQueue.acquire(conv.roomId, deleteConversationAbortTracker.signal);
        }
        catch (err) {
            deleteConversationAbortTracker.dispose();
            if (deleteConversationAbortTracker.isAborted())
                return true;
            error(res, isRoomQueueBackpressureError(err)
                ? "Conversation is busy; retry deletion after pending turns finish"
                : `Failed to serialize conversation deletion: ${getErrorMessage(err)}`, roomQueueAdmissionStatus(err));
            return true;
        }
        deleteConversationAbortTracker.markCompleted();
        deleteConversationAbortTracker.dispose();
        try {
            if (state.conversations.get(conv.id) !== conv ||
                state.deletedConversationIds.has(conv.id)) {
                json(res, { ok: true });
                return true;
            }
            try {
                const memories = await runtime.getMemories({
                    roomId: conv.roomId,
                    tableName: "messages",
                });
                const memoryIds = memories
                    .map((memory) => memory.id)
                    .filter((memoryId) => typeof memoryId === "string" && memoryId.trim().length > 0);
                if (memoryIds.length > 0) {
                    await runtime.roomHandlerQueue.runInLease(conv.roomId, historyLease, () => deleteConversationMemories(runtime, memoryIds));
                }
            }
            catch (err) {
                // error-policy:J1 deletion must not create a tombstone while message
                // rows remain; report the failed operation to the caller.
                error(res, `Failed to delete conversation messages: ${getErrorMessage(err)}`, 500);
                return true;
            }
            try {
                await deleteConversationRoomData(runtime, conv.roomId);
            }
            catch (err) {
                if (isConversationConnectionError(err)) {
                    error(res, `Failed to serialize conversation deletion: ${getErrorMessage(err)}`, 503);
                    return true;
                }
                // error-policy:J1 an incomplete room deletion is a route failure, not a
                // successful tombstone-only delete.
                error(res, `Failed to delete conversation room: ${getErrorMessage(err)}`, 500);
                return true;
            }
            state.conversations.delete(convId);
            markConversationDeleted(state, convId);
            json(res, { ok: true });
            return true;
        }
        finally {
            await historyLease.release();
        }
    }
    state.conversations.delete(convId);
    markConversationDeleted(state, convId);
    json(res, { ok: true });
    return true;
}
