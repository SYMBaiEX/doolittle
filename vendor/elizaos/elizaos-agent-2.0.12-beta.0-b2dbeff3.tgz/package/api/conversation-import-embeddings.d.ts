import { type IAgentRuntime, type UUID } from "@elizaos/core";
/** Called under the import's room lease, before persisting any source rows. */
export declare function scheduleImportedConversationEmbeddings(runtime: IAgentRuntime, roomId: UUID): Promise<void>;
/** Durable bookkeeping only: the existing embedding queue still owns inference. */
export declare function registerImportedConversationEmbeddingWorker(runtime: IAgentRuntime): void;
