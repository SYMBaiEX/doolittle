/**
 * Mounts POST `/api/plugins/load-from-directory`, which hot-loads a plugin from
 * an absolute local path into the live runtime and broadcasts a plugin_reloaded
 * view event so the dashboard refreshes the plugin's views. Gated behind the
 * local-code-execution policy (blocked in locked-down store variants) and an
 * available runtime; the directory must be an absolute path.
 */
import type http from "node:http";
import type { ServerState } from "./server-types.js";
type JsonHelper = (res: http.ServerResponse, data: unknown, status?: number) => void;
type ErrorHelper = (res: http.ServerResponse, message: string, status?: number) => void;
type ReadJsonBody = <T = Record<string, unknown>>(req: http.IncomingMessage, res: http.ServerResponse) => Promise<T | null>;
type LoadPluginFromDirectory = typeof import("../runtime/load-plugin-from-directory.js").loadPluginFromDirectory;
export interface PluginDirectoryRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: Pick<ServerState, "runtime" | "broadcastWs">;
    readJsonBody: ReadJsonBody;
    json: JsonHelper;
    error: ErrorHelper;
    isLocalCodeExecutionAllowed?: () => boolean;
    buildStoreVariantBlockedMessage?: (feature: string) => string;
    loadPluginFromDirectory?: LoadPluginFromDirectory;
}
export declare function handlePluginDirectoryRoutes(ctx: PluginDirectoryRouteContext): Promise<boolean>;
export {};
