import { parseOptionalBooleanQuery } from "./query-parameters.js";
import { buildModelCatalog } from "./model-catalog.js";
import { MODEL_PROVIDER_ID_PATTERN, ModelCatalogFetchError, } from "./model-provider-helpers.js";
export async function handleModelsRoutes(ctx) {
    const { res, method, pathname, url, json, providerCachePath, getOrFetchProvider, getOrFetchAllProviders, resolveModelsCacheDir, pathExists, readDir, unlinkFile, joinPath, } = ctx;
    if (method !== "GET" || pathname !== "/api/models")
        return false;
    const catalogOnlyParsed = parseOptionalBooleanQuery(url.searchParams.get("catalogOnly"));
    if (!catalogOnlyParsed.ok) {
        json(res, { error: "catalogOnly must be a boolean" }, 400);
        return true;
    }
    const refreshParsed = parseOptionalBooleanQuery(url.searchParams.get("refresh"));
    if (!refreshParsed.ok) {
        json(res, { error: "refresh must be a boolean" }, 400);
        return true;
    }
    const force = refreshParsed.value === true;
    const specificProvider = url.searchParams.get("provider");
    // Built per request: the codex slice re-reads the CLI's models_cache.json
    // at call time so a refreshed server catalog shows up without a restart.
    const catalog = (ctx.buildCatalog ?? buildModelCatalog)();
    // Catalog consumers (the settings model panel)
    // only need the validated catalog — local static tables + one file read.
    // The all-providers fan-out below hits every provider's live model-list API
    // and takes tens of seconds on a cold cache, which blows the UI client's
    // 10s fetch budget and renders as a failed options load.
    // Accept both shipped identities: UI catalog path uses `1`, refresh uses `true`.
    if (catalogOnlyParsed.value === true) {
        json(res, { providers: {}, catalog });
        return true;
    }
    if (specificProvider) {
        // The provider id becomes a filesystem path segment in providerCachePath,
        // so reject anything outside the canonical id grammar before the cache
        // bust or fetch runs — `../` ids would otherwise traverse the unlink/read
        // out of the models cache dir (W1-024).
        if (!MODEL_PROVIDER_ID_PATTERN.test(specificProvider)) {
            json(res, { error: "Invalid provider id" }, 400);
            return true;
        }
        if (force) {
            try {
                unlinkFile(providerCachePath(specificProvider));
            }
            catch {
                // Ignore cache-bust errors and continue with a fresh fetch.
            }
        }
        let models;
        try {
            models = await getOrFetchProvider(specificProvider, force);
        }
        catch (error) {
            if (!(error instanceof ModelCatalogFetchError))
                throw error;
            // error-policy:J1 translate an upstream provider failure at the HTTP
            // boundary instead of fabricating a successful empty catalog.
            json(res, {
                error: error.message,
                code: error.code,
                provider: error.providerId,
            }, 502);
            return true;
        }
        json(res, { provider: specificProvider, models, catalog });
        return true;
    }
    if (force) {
        try {
            const dir = resolveModelsCacheDir();
            if (pathExists(dir)) {
                for (const file of readDir(dir)) {
                    if (file.endsWith(".json"))
                        unlinkFile(joinPath(dir, file));
                }
            }
        }
        catch {
            // Ignore cache-bust errors and continue with a fresh fetch.
        }
    }
    const all = await getOrFetchAllProviders(force);
    json(res, { providers: all, catalog });
    return true;
}
