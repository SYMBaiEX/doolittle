/**
 * Buffers structured logs emitted before the API server can expose them.
 * The logger listener API preserves logger ownership and provides an explicit
 * handoff when the server installs its long-lived capture listener.
 */
import { addLogListener, } from "@elizaos/core";
const LEVEL_NAMES = {
    10: "trace",
    20: "debug",
    27: "success",
    28: "progress",
    29: "log",
    30: "info",
    40: "warn",
    50: "error",
    60: "fatal",
};
const ADZE_PRETTY_PREFIX = /^\s*(?:trace|debug|verbose|success|progress|log|info|warn|error|fatal|alert)\s{2,}/i;
let earlyLogBuffer = null;
let stopEarlyCapture = null;
/** Converts logger-package entries into the API's stable transport shape. */
export function formatStructuredLogEntry(entry) {
    const metadata = entry;
    const bracketSource = /^\[([^\]]+)\]\s*/.exec(entry.msg)?.[1];
    const source = typeof metadata.src === "string"
        ? metadata.src
        : (bracketSource ?? "agent");
    const structuredTags = Array.isArray(metadata.tags)
        ? metadata.tags.filter((tag) => typeof tag === "string")
        : [];
    return {
        timestamp: entry.time,
        level: LEVEL_NAMES[entry.level ?? 30] ?? "info",
        message: entry.msg,
        source,
        tags: [...new Set(["agent", ...structuredTags, source])],
    };
}
/**
 * Subscribes to one logical entry per logger call. The logger currently emits
 * both its invocation entry and Adze's rendered mirror to the global listener;
 * only the invocation entry belongs in the API transport.
 */
export function listenForUiLogs(onEntry) {
    return addLogListener((entry) => {
        // Wrapper calls use Pino-compatible priorities (10..60); Adze mirrors use
        // its own 0..8 scale. Prefer that stable provenance signal because pretty
        // text can vary with terminal/color configuration.
        if ((entry.level ?? 30) < 10 || ADZE_PRETTY_PREFIX.test(entry.msg))
            return;
        onEntry(formatStructuredLogEntry(entry));
    });
}
/** Starts idempotent capture for the pre-server portion of agent startup. */
export function captureEarlyLogs() {
    if (earlyLogBuffer)
        return;
    earlyLogBuffer = [];
    stopEarlyCapture = listenForUiLogs((entry) => {
        earlyLogBuffer?.push(entry);
    });
}
/** Drains captured entries and releases the pre-server logger listener. */
export function flushEarlyLogs() {
    const entries = earlyLogBuffer ? [...earlyLogBuffer] : [];
    stopEarlyCapture?.();
    stopEarlyCapture = null;
    earlyLogBuffer = null;
    return entries;
}
