/**
 * Simple in-memory sliding-window rate limiter for API endpoints.
 *
 * Each key (typically `agentId:operationName`) tracks request timestamps
 * within a configurable window. When the count hits the limit, new requests
 * are rejected with a `retryAfterMs` hint.
 *
 * This is intentionally per-process / in-memory. It resets on restart, which
 * is fine for a local-first app — the goal is to prevent runaway scripts and
 * accidental tight loops, not to enforce billing quotas.
 */
const buckets = new Map();
/** Interval between full-map cleanup sweeps (ms). */
const CLEANUP_INTERVAL_MS = 5 * 60 * 1_000;
let lastCleanup = Date.now();
/**
 * Prune every bucket by ITS OWN window. The sweep used to reuse the calling
 * endpoint's `windowMs` for the whole map, so any check with a short window
 * would wipe still-valid history from keys tracked with a longer window —
 * silently resetting those limits.
 */
function cleanup() {
    const now = Date.now();
    if (now - lastCleanup < CLEANUP_INTERVAL_MS)
        return;
    lastCleanup = now;
    for (const [key, entry] of buckets) {
        const cutoff = now - entry.windowMs;
        entry.timestamps = entry.timestamps.filter((t) => t > cutoff);
        if (entry.timestamps.length === 0)
            buckets.delete(key);
    }
}
/**
 * Check whether a request identified by `key` is within the rate limit
 * defined by `config`. If allowed, the request is recorded in the window.
 */
export function checkRateLimit(key, config) {
    const now = Date.now();
    cleanup();
    let entry = buckets.get(key);
    if (!entry) {
        entry = { timestamps: [], windowMs: config.windowMs };
        buckets.set(key, entry);
    }
    // Keep the sweep window in sync if a key's config ever changes.
    entry.windowMs = config.windowMs;
    // Evict timestamps outside the sliding window.
    const cutoff = now - config.windowMs;
    entry.timestamps = entry.timestamps.filter((t) => t > cutoff);
    if (entry.timestamps.length >= config.maxRequests) {
        const oldestInWindow = entry.timestamps[0];
        if (oldestInWindow === undefined) {
            return { allowed: true, retryAfterMs: 0 };
        }
        const retryAfterMs = oldestInWindow + config.windowMs - now;
        return { allowed: false, retryAfterMs: Math.max(retryAfterMs, 0) };
    }
    entry.timestamps.push(now);
    return { allowed: true, retryAfterMs: 0 };
}
/** Clear all rate limit state (buckets + sweep clock). Useful in tests. */
export function resetRateLimits() {
    buckets.clear();
    lastCleanup = Date.now();
}
