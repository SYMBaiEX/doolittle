/**
 * Correlates server-initiated requests with asynchronous frontend results.
 *
 * The server registers before broadcasting a WebSocket message so a fast
 * frontend response cannot outrun the waiter. Each request id owns one slot;
 * registering it again rejects the displaced waiter before replacing it.
 */
import { type ViewInteractResult } from "@elizaos/core";
export type { ViewInteractResult } from "@elizaos/core";
export declare class PendingRequestMap {
    private readonly map;
    /**
     * Register a pending request and return a Promise that resolves when the
     * frontend sends the result back (or rejects on timeout).
     */
    waitFor(requestId: string, timeoutMs: number): Promise<ViewInteractResult>;
    /**
     * Resolve a pending request with the given result.
     * Ignored when the requestId is unknown (e.g. already timed out).
     */
    resolve(requestId: string, result: ViewInteractResult): void;
    reject(requestId: string, reason: Error): void;
    /** Stop all waiters owned by the closing host. */
    rejectAll(reason: Error): void;
    /** Number of in-flight requests. Useful for diagnostics. */
    get size(): number;
}
