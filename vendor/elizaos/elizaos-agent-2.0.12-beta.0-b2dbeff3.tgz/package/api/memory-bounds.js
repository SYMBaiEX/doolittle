/**
 * Pure helper functions for bounded in-memory data structures.
 *
 * @module
 */
/**
 * Evict expired entries from a rate-limit map when it exceeds `threshold`.
 * Safe to call during iteration (Map spec permits deletion during for-of).
 */
export function sweepExpiredEntries(map, now, threshold) {
    if (map.size <= threshold)
        return;
    for (const [k, v] of map) {
        if (now > v.resetAt)
            map.delete(k);
    }
}
/**
 * Retrieve a file from a bounded cache, reading from disk on miss.
 * Files larger than `fileSizeLimit` are never cached.
 *
 * @param cache         - The Map serving as the LRU-ish cache.
 * @param filePath      - Absolute path to the file.
 * @param mtimeMs       - File's last-modified time (for invalidation).
 * @param readFile      - Callback that reads the file (injected for testing).
 * @param maxEntries    - Maximum number of cached files.
 * @param fileSizeLimit - Maximum file size (bytes) eligible for caching.
 */
export function getOrReadCachedFile(cache, filePath, mtimeMs, readFile, maxEntries, fileSizeLimit) {
    const cached = cache.get(filePath);
    if (cached && cached.mtimeMs === mtimeMs)
        return cached.body;
    const body = readFile(filePath);
    if (body.length <= fileSizeLimit) {
        if (cache.size >= maxEntries) {
            const firstKey = cache.keys().next().value;
            if (firstKey !== undefined)
                cache.delete(firstKey);
        }
        cache.set(filePath, { body, mtimeMs });
    }
    return body;
}
