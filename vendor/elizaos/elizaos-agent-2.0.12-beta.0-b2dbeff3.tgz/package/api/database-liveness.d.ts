/**
 * Database liveness probing for process health endpoints. The probe performs a
 * real `SELECT 1` round trip against the active adapter instead of trusting
 * cached adapter state, so a closed embedded PGlite instance cannot report as
 * healthy while every real operation is failing.
 */
import type { AgentRuntime } from "@elizaos/core";
export type DatabaseLivenessStatus = "ok" | "unknown" | "transient_error" | "terminal_error";
export interface DatabaseLivenessProbeResult {
    status: DatabaseLivenessStatus;
    ok: boolean;
    terminal: boolean;
    message?: string;
}
export declare function isTerminalDatabaseLivenessError(error: unknown): boolean;
export declare function probeRuntimeDatabaseLiveness(runtime: AgentRuntime | null): Promise<DatabaseLivenessProbeResult>;
