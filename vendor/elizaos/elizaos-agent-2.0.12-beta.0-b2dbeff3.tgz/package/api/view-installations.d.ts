import { type IAgentRuntime } from "@elizaos/core";
import type { ViewRegistryEntry } from "./view-registry-types.js";
/** An opaque in-process handle. Serialized IDs never grant installation authority. */
export interface ViewInstallation {
    readonly id: string;
}
/** Reserve a new installation without deleting the currently usable one. */
export declare function beginViewInstallation(runtime: IAgentRuntime, owner: string, packageName?: string): ViewInstallation;
/** Validate the entire replacement before publishing any entry. */
export declare function commitViewInstallation(runtime: IAgentRuntime, handle: ViewInstallation, entries: readonly ViewRegistryEntry[]): ViewRegistryEntry[];
/** Revocation is synchronous and cannot remove a newer installation of the same owner. */
export declare function revokeViewInstallation(runtime: IAgentRuntime, handle: ViewInstallation): void;
export declare function assertViewInstallation(runtime: IAgentRuntime, handle: ViewInstallation): void;
export declare function runtimeViewEntries(runtime: IAgentRuntime): ViewRegistryEntry[];
/** Runtime stop, never ordinary plugin unload or an individual HTTP host's close. */
export declare function closeRuntimeViewRegistry(runtime: IAgentRuntime): void;
/** Bind a retained entry to its actual current in-process installation. */
export declare function assertRuntimeViewEntry(runtime: IAgentRuntime, entry: ViewRegistryEntry): void;
