import { EventType, toWellFormedUnicode, } from "@elizaos/core";
import { readRequestBodyBuffer } from "@elizaos/host";
const MAX_BODY_BYTES = 4 * 1024;
/** Stable shortcut id: kebab-case, bounded length (e.g. "open-command-palette"). */
const SHORTCUT_ID_PATTERN = /^[a-z][a-z0-9-]{1,48}$/;
const SURFACE_ID_PATTERN = /^[a-z][a-z0-9_-]{1,64}$/;
const MAX_CONVERSATION_ID_CHARS = 128;
const MAX_DRAFT_LENGTH = 100000;
const COMPOSER_ACTIVITY_TO_EVENT = {
    typing_started: EventType.USER_TYPING_STARTED,
    typing_paused: EventType.USER_TYPING_PAUSED,
    draft_abandoned: EventType.USER_DRAFT_ABANDONED,
};
/** Parse + validate the shortcut report body; null on anything malformed. */
export function parseShortcutBody(raw) {
    if (!raw.trim())
        return null;
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch {
        // error-policy:J3 untrusted request JSON parses to an explicit invalid body.
        return null;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        return null;
    }
    const body = parsed;
    const shortcutId = typeof body.shortcutId === "string" ? body.shortcutId.trim() : "";
    if (!SHORTCUT_ID_PATTERN.test(shortcutId))
        return null;
    const context = typeof body.context === "string" && body.context.trim()
        ? toWellFormedUnicode(body.context.trim())
        : undefined;
    return { shortcutId, ...(context ? { context } : {}) };
}
function readStringWithinLimit(value, maxChars) {
    if (typeof value !== "string")
        return undefined;
    const trimmed = value.trim();
    if (!trimmed)
        return undefined;
    const wellFormed = toWellFormedUnicode(trimmed);
    return wellFormed.length <= maxChars ? wellFormed : undefined;
}
function readNonNegativeInteger(value) {
    if (typeof value !== "number" || !Number.isSafeInteger(value))
        return null;
    return value >= 0 ? value : null;
}
function readOccurredAt(value) {
    if (typeof value !== "string")
        return new Date().toISOString();
    const parsedMs = Date.parse(value);
    return Number.isFinite(parsedMs) ? new Date(parsedMs).toISOString() : null;
}
/** Parse + validate a composer lifecycle report; null on anything malformed. */
export function parseComposerBody(raw) {
    if (!raw.trim())
        return null;
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch {
        // error-policy:J3 untrusted request JSON parses to an explicit invalid body.
        return null;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        return null;
    }
    const body = parsed;
    const activity = typeof body.activity === "string" &&
        body.activity in COMPOSER_ACTIVITY_TO_EVENT
        ? body.activity
        : null;
    if (!activity)
        return null;
    const surface = readStringWithinLimit(body.surface, 64);
    if (!surface || !SURFACE_ID_PATTERN.test(surface))
        return null;
    const draftLength = readNonNegativeInteger(body.draftLength);
    if (draftLength === null || draftLength > MAX_DRAFT_LENGTH)
        return null;
    const idleForMs = body.idleForMs === undefined
        ? undefined
        : readNonNegativeInteger(body.idleForMs);
    if (idleForMs === null ||
        (activity === "typing_paused" && idleForMs === undefined)) {
        return null;
    }
    const reason = body.reason === "cleared" ||
        body.reason === "blurred" ||
        body.reason === "conversation_switched" ||
        body.reason === "unknown"
        ? body.reason
        : undefined;
    const occurredAt = readOccurredAt(body.occurredAt);
    if (!occurredAt)
        return null;
    let conversationId;
    if (body.conversationId !== undefined) {
        conversationId = readStringWithinLimit(body.conversationId, MAX_CONVERSATION_ID_CHARS);
        if (!conversationId)
            return null;
    }
    return {
        activity,
        surface,
        draftLength,
        ...(conversationId ? { conversationId } : {}),
        ...(idleForMs !== undefined ? { idleForMs } : {}),
        ...(reason ? { reason } : {}),
        occurredAt,
    };
}
export async function handleInteractionsRoutes(ctx) {
    const { req, res, method, pathname, json, error, runtime } = ctx;
    if (pathname !== "/api/interactions/shortcut" &&
        pathname !== "/api/interactions/composer") {
        return false;
    }
    if (method !== "POST") {
        error(res, "Method not allowed", 405);
        return true;
    }
    const buffer = await readRequestBodyBuffer(req, {
        maxBytes: MAX_BODY_BYTES,
        returnNullOnTooLarge: true,
    });
    if (pathname === "/api/interactions/composer") {
        const request = parseComposerBody(buffer?.toString("utf8") ?? "");
        if (!request) {
            error(res, "Invalid composer interaction body", 400);
            return true;
        }
        if (runtime) {
            const eventType = COMPOSER_ACTIVITY_TO_EVENT[request.activity];
            void runtime
                .emitEvent(eventType, {
                runtime,
                source: "composer-interaction",
                activity: request.activity,
                surface: request.surface,
                ...(request.conversationId
                    ? { conversationId: request.conversationId }
                    : {}),
                draftLength: request.draftLength,
                ...(request.idleForMs !== undefined
                    ? { idleForMs: request.idleForMs }
                    : {}),
                ...(request.reason ? { reason: request.reason } : {}),
                occurredAt: request.occurredAt,
                initiatedBy: "user",
            })
                .catch((err) => {
                // error-policy:J7 telemetry emission must not break the interaction
                // route, but a broken event bus must reach RECENT_ERRORS.
                runtime.reportError("InteractionsRoutes.composerActivity", err, {
                    activity: request.activity,
                    surface: request.surface,
                });
            });
        }
        json(res, { ok: true, activity: request.activity });
        return true;
    }
    const shortcutBody = buffer ? buffer.toString("utf8") : null;
    const request = shortcutBody ? parseShortcutBody(shortcutBody) : null;
    if (!request) {
        error(res, "Invalid shortcut interaction body", 400);
        return true;
    }
    // Emit the first-class SHORTCUT_FIRED interaction event (#8792). Fire-and-forget
    // so the proactive decider can react without ever blocking the response.
    if (runtime) {
        void runtime
            .emitEvent(EventType.SHORTCUT_FIRED, {
            runtime,
            source: "shortcut-interaction",
            shortcutId: request.shortcutId,
            ...(request.context ? { context: request.context } : {}),
            initiatedBy: "user",
        })
            .catch((err) => {
            // error-policy:J7 telemetry emission must not break the interaction
            // route, but a broken event bus must reach RECENT_ERRORS.
            runtime.reportError("InteractionsRoutes.shortcutFired", err, {
                shortcutId: request.shortcutId,
            });
        });
    }
    json(res, { ok: true, shortcutId: request.shortcutId });
    return true;
}
