export declare function isNoResponsePlaceholder(text: string): boolean;
export declare function isClientVisibleNoResponse(text: string): boolean;
