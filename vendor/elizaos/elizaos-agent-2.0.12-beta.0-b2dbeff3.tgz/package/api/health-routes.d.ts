/**
 * Health, status, and runtime-introspection routes for the local agent server:
 * `GET /api/status` (agent state, active model, uptime, cloud-connection and
 * pending-restart summary), `GET /api/health` (subsystem readiness — runtime,
 * plugins loaded/failed, service registrations including failed starts, swarm
 * coordinator, connector statuses), and
 * `GET /api/runtime` (deep, memoized reflective snapshot of the runtime object
 * graph for the debug UI).
 *
 * Read-only introspection; both status endpoints treat optional local-inference
 * and cloud health as best-effort and degrade rather than 500. Also exports
 * `computeCanRespond`, the shared "first-turn capability online" predicate
 * (live runtime AND `running` AND a registered text-generation handler AND available
 * weights when the sole provider is local inference AND no
 * cached Cloud catalog answer that the only text provider's model is gone) reused
 * by `/api/status`, `/api/health`, and the WS `status` broadcast.
 */
import type http from "node:http";
import { type AgentRuntime } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { ConnectorHealthMonitor } from "./connector-health.js";
interface PluginEntryLike {
    enabled: boolean;
    configured: boolean;
    isActive?: boolean;
    loadError?: string | null;
}
interface AgentStartupDiagnostics {
    phase: string;
    attempt: number;
    lastError?: string;
    lastErrorAt?: number;
    nextRetryAt?: number;
}
export interface HealthRouteState {
    runtime: AgentRuntime | null;
    config: ElizaConfig;
    agentState: string;
    agentName: string;
    model: string | undefined;
    startedAt: number | undefined;
    startup: AgentStartupDiagnostics;
    plugins: PluginEntryLike[];
    pendingRestartReasons: string[];
    connectorHealthMonitor: ConnectorHealthMonitor | null;
}
/** Trusted host composition before status JSON is serialized. */
export type ApiStatusComposer = (payload: Record<string, unknown>) => Record<string, unknown>;
export interface HealthRouteContext {
    composeStatus?: ApiStatusComposer;
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    state: HealthRouteState;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
}
interface RuntimeDebugSerializeOptions {
    maxDepth: number;
    maxArrayLength: number;
    maxObjectEntries: number;
    maxStringLength: number;
}
export declare function parseDebugPositiveInt(raw: string | null, fallback: number, min: number, max: number): number | "invalid";
export declare function serializeForRuntimeDebug(value: unknown, options: RuntimeDebugSerializeOptions): unknown;
/**
 * "First-turn capability online": the agent can actually produce a response.
 *
 * Distinct from `ready` (which is `true` even for stopped/error/paused states —
 * it only negates `starting`/`restarting`). `canRespond` ANDs a live runtime, a
 * `running` state, AND a registered TEXT_GENERATION handler — so it is `false`
 * when no model provider is wired or the sole local handler has no usable weights, and only flips
 * `true` at the exact moment the agent can answer a first turn. This is the
 * signal the UI uses to fade in first-turn capability: the shell paints early
 * (agentState "starting"), and the composer goes live when this flips.
 *
 * The local-inference router counts as a handler to the runtime, but it only
 * dispatches to the other registered text handlers, so a runtime whose text
 * slots hold nothing but the router cannot answer a turn.
 */
export declare function computeCanRespond(runtime: AgentRuntime | null, agentState: string, localModelReadiness: Awaited<ReturnType<typeof readLocalTextModelReadiness>>): boolean;
/** Readiness of this runtime's sole local text provider, without loading models. */
export declare function readLocalTextModelReadiness(runtime: AgentRuntime | null): Promise<{
    provider: "eliza-local-inference";
    status: "available" | "model_not_loaded";
} | null>;
/** One readiness snapshot for HTTP and WebSocket status payloads. */
export declare function responseReadinessFields(runtime: AgentRuntime | null, agentState: string): Promise<{
    localModelReadiness: {
        provider: "eliza-local-inference";
        status: "available" | "model_not_loaded";
    } | null;
    modelReadiness?: CloudModelReadinessView;
    canRespond: boolean;
}>;
/**
 * `{ modelReadiness }` for status payloads when the Cloud model registry is
 * running, so clients can tell an invalid model setting apart from a provider
 * outage or a missing provider.
 */
export declare function cloudModelReadinessField(runtime: AgentRuntime | null): {
    modelReadiness?: CloudModelReadinessView;
};
/**
 * Status projection of the Cloud model registry's text-model readiness
 * (plugins/plugin-elizacloud/src/services/cloud-model-readiness.ts). Read
 * structurally so the status route does not load the Cloud plugin graph.
 */
export type CloudModelReadinessView = {
    status: "available";
    checkedAt: number;
} | {
    status: "unknown";
    reason: string;
    checkedAt: number | null;
} | {
    status: "model_not_available";
    code: "MODEL_NOT_AVAILABLE";
    missing: Array<{
        modelType: "TEXT_SMALL" | "TEXT_LARGE";
        configKey: string | null;
        modelId: string;
    }>;
    message: string;
    checkedAt: number;
};
/**
 * Cached Cloud catalog readiness for the configured TEXT_SMALL/TEXT_LARGE ids,
 * or null when the Cloud model registry is not running. Never performs an
 * inference call; the registry refreshes its catalog in the background.
 */
export declare function readCloudModelReadiness(runtime: AgentRuntime | null): CloudModelReadinessView | null;
/**
 * Handle health / status / runtime introspection routes.
 * Returns `true` if the request was handled.
 */
export declare function handleHealthRoutes(ctx: HealthRouteContext): Promise<boolean>;
export {};
