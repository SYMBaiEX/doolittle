/**
 * First-run and provider-switch configuration mutators for `ElizaConfig`.
 * Translates a chosen connection (Eliza Cloud managed, remote provider, local
 * provider, or subscription) into config slots, `env.vars`, and `process.env`
 * so the runtime routes inference at the selected backend. Also owns the full
 * first-run reset — wiping onboarding-derived config, provider env vars, and
 * stored provider credentials — and the third-party `OPENAI_BASE_URL` guard that
 * keeps openai.com default model ids off non-openai upstreams. Mutations are
 * applied in place; consumed by the first-run / config API routes.
 */
import { type AccountStoragePolicy } from "@elizaos/auth/auth";
import type { DeploymentTargetConfig, LinkedAccountFlagsConfig, ServiceCapability, ServiceRoutingConfig } from "@elizaos/contracts";
import { type ElizaConfig, type FirstRunConnection, type FirstRunCredentialInputs } from "@elizaos/host/protocol";
type MutableElizaConfig = Partial<ElizaConfig> & {
    cloud?: Record<string, unknown>;
    models?: Record<string, unknown>;
    wallet?: {
        rpcProviders?: Record<string, string>;
    };
    deploymentTarget?: DeploymentTargetConfig;
    linkedAccounts?: LinkedAccountFlagsConfig;
    serviceRouting?: ServiceRoutingConfig;
};
export declare const ELIZA_CLOUD_CLI_PROXY_BASE_URL = "https://cloud.eliza.app/api/v1";
export declare function applyCanonicalFirstRunConfig(config: MutableElizaConfig, args: {
    deploymentTarget?: DeploymentTargetConfig | null;
    linkedAccounts?: LinkedAccountFlagsConfig | null;
    serviceRouting?: ServiceRoutingConfig | null;
    clearRoutes?: readonly ServiceCapability[];
}): void;
/**
 * Apply subscription provider configuration to the config object.
 *
 * Sets `agents.defaults.subscriptionProvider` so the task-agent orchestrator
 * knows which subscription is active.
 *
 * Subscriptions are coding-agent credentials only: none has a runtime
 * text handler (Anthropic tokens are restricted to Claude Code CLI by TOS and
 * the Codex CLI chat handler was removed), so `model.primary` is never set.
 *
 * Mutates `config` in place.
 */
export declare function applySubscriptionProviderConfig(config: Partial<ElizaConfig>, provider: string): void;
/**
 * Clear subscription provider configuration from the config object.
 *
 * Removes `agents.defaults.subscriptionProvider` so the runtime
 * doesn't try to auto-detect a subscription provider on restart.
 *
 * Mutates `config` in place.
 */
export declare function clearSubscriptionProviderConfig(config: Partial<ElizaConfig>): void;
/**
 * Clear persisted first-run state that should force the UI back through the
 * first-run setup on the next load/reset.
 */
export declare function clearPersistedFirstRunConfig(config: MutableElizaConfig, storagePolicy: AccountStoragePolicy): void;
export declare function createProviderSwitchConnection(args: {
    provider: string;
    apiKey?: string;
    primaryModel?: string;
}): FirstRunConnection | null;
export declare function applyFirstRunConnectionConfig(config: MutableElizaConfig, connection: FirstRunConnection): Promise<void>;
export declare function applyFirstRunCredentialPersistence(config: MutableElizaConfig, args: {
    credentialInputs?: FirstRunCredentialInputs | null;
    deploymentTarget?: DeploymentTargetConfig | null;
    serviceRouting?: ServiceRoutingConfig | null;
    /** Observe synchronous environment writes without claiming later concurrent changes. */
    observeEnvironmentMutation?: <T>(mutation: () => T) => T;
}): Promise<string | null>;
export {};
