export type { WorkbenchRouteContext } from "./workbench-context.js";
import type { WorkbenchRouteContext } from "./workbench-context.js";
export declare function handleWorkbenchRoutes(ctx: WorkbenchRouteContext): Promise<boolean>;
