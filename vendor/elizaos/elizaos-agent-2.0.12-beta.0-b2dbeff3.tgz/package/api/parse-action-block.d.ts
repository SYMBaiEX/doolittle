/**
 * Local compatibility type for CoordinationLLMResponse — removed from
 * @elizaos/plugin-agent-orchestrator 2.x.
 */
export interface CoordinationLLMResponse {
    action: string;
    reasoning: string;
    response?: string;
    useKeys?: boolean;
    keys?: string[];
    /**
     * Set when `action === "permission_request"`. The chat renderer consumes
     * this payload to render an inline `<PermissionCard>` below the message.
     */
    permissionRequest?: ParsedPermissionRequest;
}
import { type PermissionId } from "@elizaos/core";
/**
 * Parsed shape for the `permission_request` action. The agent emits this
 * inline alongside its natural-language response; the chat surface renders
 * a permission card and (after grant) the agent retries the original action.
 */
export interface ParsedPermissionRequest {
    permission: PermissionId;
    reason: string;
    feature: string;
    fallbackOffered: boolean;
    fallbackLabel?: string;
}
/** Console bridge exposed by PTYService for terminal I/O. */
export interface ConsoleBridge {
    on(event: string, listener: (...args: unknown[]) => void): void;
    off(event: string, listener: (...args: unknown[]) => void): void;
    writeRaw(sessionId: string, data: string): void;
    resize(sessionId: string, cols: number, rows: number): void;
}
/** PTY service interface (accessed via runtime.getService). */
export interface PTYService {
    consoleBridge?: ConsoleBridge;
    listSessions?(): Array<{
        sessionId: string;
        ownerClientId?: string;
    }>;
    stopSession?(sessionId: string): Promise<void>;
}
/**
 * Strip JSON action blocks from text before displaying in chat.
 * Handles both fenced (```json ... ```) and bare JSON formats.
 */
export declare function stripActionBlockFromDisplay(text: string): string;
/**
 * Parse a JSON action block from Eliza's natural language response.
 * Looks for a fenced ```json block first, then bare JSON with "action" key.
 * Returns null if no valid action block is found.
 */
export declare function parseActionBlock(text: string): CoordinationLLMResponse | null;
