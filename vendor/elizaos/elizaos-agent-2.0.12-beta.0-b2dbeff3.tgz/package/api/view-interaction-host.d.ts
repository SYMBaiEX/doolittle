import { type IAgentRuntime, type RoleGateRole } from "@elizaos/core";
import { type ViewInteractResult } from "./pending-request-map.js";
import type { ViewRegistryEntry } from "./view-registry-types.js";
export interface ViewInteractionBinding {
    requestId: string;
    viewId: string;
    viewType: string;
    installationId: string;
}
export type RendererViewInteractResult = ViewInteractResult & Partial<ViewInteractionBinding> & {
    claimId?: string;
};
export declare class ViewInteractionHost {
    readonly runtime: IAgentRuntime;
    private closed;
    private readonly pending;
    private readonly callers;
    private readonly stopSignal;
    private readonly onRuntimeStop;
    constructor(runtime: IAgentRuntime);
    waitFor(requestId: string, clientId: string, entry: ViewRegistryEntry, timeoutMs: number, binding?: {
        ownerId?: string;
        navigation?: boolean;
    }): Promise<ViewInteractResult>;
    /** One renderer may execute a delivered request, even across duplicate sockets. */
    claim(clientId: string, binding: ViewInteractionBinding, roles: RoleGateRole[], ownerId?: string): string | null;
    private matchCaller;
    resolve(clientId: string, result: RendererViewInteractResult, ownerId?: string): boolean;
    cancel(requestId: string, reason: Error): void;
    close(): void;
}
/** The host key is its in-process server state, never a supplied ID. */
export declare function viewInteractionHost(runtime: IAgentRuntime, hostKey: object): ViewInteractionHost;
export declare function closeViewInteractionHost(hostKey: object): void;
export declare function bindViewRequestHost(request: object, hostKey: object): void;
export declare function getViewRequestBroadcast(request: object): ((payload: object) => void) | null;
export declare function setViewsBroadcastWs(hostKey: object, broadcast: ((payload: object) => void) | null, targeted?: ((clientId: string, payload: object) => number) | null): void;
export declare function getViewsBroadcastWs(hostKey: object | undefined): ((payload: object) => void) | null;
export declare function getViewsBroadcastWsToClientId(hostKey: object | undefined): ((clientId: string, payload: object) => number) | null;
