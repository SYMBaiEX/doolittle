import { NOTIFICATION_PUSH_SERVICE_TYPE, NotificationPushService, } from "../services/push/notification-push-service.js";
import { isPushTokenValidationError, } from "../services/push/push-token-registry.js";
const PUSH_TOKENS_PREFIX = "/api/notifications/push-tokens";
function getPushService(state) {
    const svc = state.runtime?.getService(NOTIFICATION_PUSH_SERVICE_TYPE);
    return svc instanceof NotificationPushService ? svc : null;
}
function parsePlatform(value) {
    return value === "ios" || value === "android" ? value : null;
}
export async function handlePushTokenRoute(req, res, pathname, method, state, helpers) {
    if (!pathname.startsWith(PUSH_TOKENS_PREFIX))
        return false;
    const service = getPushService(state);
    const registry = service?.getRegistry();
    if (!registry) {
        helpers.error(res, "push delivery service not ready", 503);
        return true;
    }
    // ── GET /api/notifications/push-tokens ────────────────────────────
    if (method === "GET" && pathname === PUSH_TOKENS_PREFIX) {
        const tokens = await registry.list();
        let ios = 0;
        let android = 0;
        for (const record of tokens) {
            if (record.platform === "ios")
                ios++;
            else
                android++;
        }
        helpers.json(res, { count: tokens.length, platforms: { ios, android } });
        return true;
    }
    // ── POST /api/notifications/push-tokens ───────────────────────────
    if (method === "POST" && pathname === PUSH_TOKENS_PREFIX) {
        const body = await helpers.readJsonBody(req, res, {
            maxBytes: 8 * 1024,
        });
        if (body === null)
            return true;
        const platform = parsePlatform(body.platform);
        if (!platform) {
            helpers.error(res, 'platform must be "ios" or "android"', 400);
            return true;
        }
        const token = typeof body.token === "string" ? body.token.trim() : "";
        if (!token) {
            helpers.error(res, "token is required", 400);
            return true;
        }
        // The registry re-validates the token (byte cap included). A typed
        // validation failure is a client error (400); a durable-write failure
        // propagates and the server boundary maps it to 500.
        try {
            await registry.register(platform, token, body.reminderDataNotifications);
        }
        catch (err) {
            // error-policy:J4 user-facing degrade — only the expected validation
            // shape becomes a 400; every other failure rethrows to the 500 boundary.
            if (isPushTokenValidationError(err)) {
                helpers.error(res, "invalid push token", 400);
                return true;
            }
            throw err;
        }
        helpers.json(res, {
            ok: true,
            deliveryEnabled: service?.isDeliveryEnabled(platform) === true,
        }, 201);
        return true;
    }
    // ── DELETE /api/notifications/push-tokens ─────────────────────────
    if (method === "DELETE" && pathname === PUSH_TOKENS_PREFIX) {
        const body = await helpers.readJsonBody(req, res, {
            maxBytes: 8 * 1024,
        });
        if (body === null)
            return true;
        const token = typeof body.token === "string" ? body.token.trim() : "";
        if (!token) {
            helpers.error(res, "token is required", 400);
            return true;
        }
        return unregisterOrError(registry, token, res, helpers);
    }
    helpers.error(res, "push-token route not found", 404);
    return true;
}
/**
 * Run `registry.unregister`, applying the same byte-bound validation as the
 * register path. A typed validation failure maps to
 * 400; a durable-write failure rethrows to the server's 500 boundary.
 */
async function unregisterOrError(registry, token, res, helpers) {
    try {
        const ok = await registry.unregister(token);
        helpers.json(res, { ok });
    }
    catch (err) {
        // error-policy:J4 user-facing degrade — expected validation shape → 400;
        // anything else rethrows so genuine persistence failures surface as 500.
        if (isPushTokenValidationError(err)) {
            helpers.error(res, "invalid push token", 400);
            return true;
        }
        throw err;
    }
    return true;
}
