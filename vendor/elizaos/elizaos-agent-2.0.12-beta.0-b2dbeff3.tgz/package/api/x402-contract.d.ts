import type { LegacyRouteHandler, PaymentEnabledRoute, Route } from "@elizaos/host/protocol";
export interface X402PluginModule {
    __mobileStub?: boolean;
    createPaymentAwareHandler(route: PaymentEnabledRoute): LegacyRouteHandler;
    isRoutePaymentWrapped(route: unknown): boolean;
    validateX402Startup?(routes: Route[], character: unknown, options: {
        agentId?: string;
    }): {
        valid: boolean;
        errors: string[];
        warnings: string[];
    };
}
/**
 * Load the optional payment plugin for route dispatch. `null` means payment
 * cannot be enforced in this process (package not installed, or mobile stub).
 * Every route dispatcher must then refuse an x402-declared route with
 * {@link X402_ENFORCEMENT_UNAVAILABLE}; a paid route is never served unpaid.
 */
export declare function loadX402PaymentModule(): Promise<X402PluginModule | null>;
/** Response every dispatcher returns for a paid route it cannot gate. */
export declare const X402_ENFORCEMENT_UNAVAILABLE: {
    readonly status: 503;
    readonly body: {
        readonly error: "This route requires x402 payment, but payment enforcement is unavailable on this host.";
        readonly code: "X402_ENFORCEMENT_UNAVAILABLE";
    };
};
