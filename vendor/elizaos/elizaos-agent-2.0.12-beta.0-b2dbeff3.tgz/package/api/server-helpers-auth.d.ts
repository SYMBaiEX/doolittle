import type http from "node:http";
import { type AgentRuntime } from "@elizaos/core";
export declare const CORS_ALLOWED_HEADERS: string;
export declare function isAllowedHost(req: http.IncomingMessage): boolean;
export declare function resolveCorsOrigin(origin?: string): string | null;
/**
 * Browser credentials are narrower than CORS reachability. Cloud and wildcard
 * binds may reflect an origin for explicit bearer-token clients, but ambient
 * cookies are enabled only for configured or app-owned origin classes.
 */
export declare function isCredentialedCorsOrigin(origin: string | undefined): boolean;
export declare function applyCors(req: http.IncomingMessage, res: http.ServerResponse, _pathname: string): boolean;
/**
 * Timing-safe token equality for every agent API credential comparison. Both
 * values are padded to one length so the comparison time does not reveal the
 * expected token's length.
 */
export declare function tokenMatches(expected: string, provided: string): boolean;
export declare function getConfiguredApiToken(): string | undefined;
export declare function extractAuthToken(req: http.IncomingMessage): string | null;
/**
 * Same-machine dashboard trust for the agent server. Delegates to the canonical
 * `@elizaos/agent/api/loopback-trust` parser with the agent's exact policy gates:
 *  - cloudCheck "container": `isCloudProvisionedContainer()` (the flag AND a
 *    provisioning token), NOT the raw `ELIZA_CLOUD_PROVISIONED` flag.
 *  - requireLocalAuthEnv: on-device local agents (Android) set
 *    `ELIZA_REQUIRE_LOCAL_AUTH=1` alongside a per-boot `ELIZA_API_TOKEN`, so
 *    loopback alone is not a trust signal there.
 *  - NO dev-auth bypass: the agent never honours `ELIZA_DEV_AUTH_BYPASS`.
 */
export declare function isTrustedLocalRequest(req: http.IncomingMessage): boolean;
/**
 * True when the request carries a valid `X-Server-Token` matching the
 * configured `AGENT_SERVER_SHARED_SECRET`. When the secret is unset this always
 * returns false, so the header carries no authority and there is no regression
 * for deployments that never configure it.
 */
export declare function isServerTokenAuthorized(req: http.IncomingMessage): boolean;
export declare function isAuthorized(req: http.IncomingMessage): boolean;
/** Exact configured owner API token, without ambient loopback or gateway authority. */
export declare function isDirectOwnerApiTokenAuthorized(req: http.IncomingMessage): boolean;
/**
 * Whether a request is authorized by a registered product boundary-role
 * resolver (#12087 item 12). The trunk holds no product token vocabulary; each
 * product (e.g. WaifuChat) registers a resolver that owns its own token parsing
 * and route allowlist. Returns false when no resolver recognises the request,
 * so the caller falls through to the trunk's own token/loopback auth.
 */
export declare function isBoundaryRoleAuthorized(req: http.IncomingMessage, method: string, pathname: string): boolean;
/** The canonical role at the agent HTTP boundary (#9948 / #12087 Item 13). */
export type BoundaryRole = "OWNER" | "GUEST";
/**
 * #12087 Item 13: the single token→role collapse for agent HTTP routes. An
 * authorized caller (trusted loopback owner or a valid API token) is the OWNER
 * principal; everyone else is GUEST — the server-authoritative unauthenticated
 * tier (#9948). Routes must use this instead of re-deriving `isAuthorized(req) ?
 * "OWNER" : "GUEST"` inline (which drifted to NONE elsewhere). app's
 * resolveBoundaryRole is deliberately not importable from the agent, so this is
 * the agent-local equivalent with the same OWNER/GUEST vocabulary.
 */
export declare function resolveBoundaryRole(req: http.IncomingMessage): BoundaryRole;
export declare function ensureApiTokenForBindHost(host: string): void;
export declare function pairingEnabled(): boolean;
export declare function normalizePairingCode(code: string): string;
export declare function ensurePairingCode(): string | null;
export declare function rateLimitPairing(ip: string | null): boolean;
export declare function getPairingExpiresAt(): number;
export declare function getPairingInstanceId(): string;
export declare function clearPairing(): void;
export declare function normalizeWsClientId(value: unknown): string | null;
export declare function resolveTerminalRunClientId(req: Pick<http.IncomingMessage, "headers">, body: {
    clientId?: unknown;
} | null | undefined): string | null;
export declare function isSharedTerminalClientId(clientId: string): boolean;
interface TerminalRunRequestBody {
    terminalToken?: string;
}
export interface TerminalRunRejection {
    status: 401 | 403;
    reason: string;
}
export declare function resolveTerminalRunRejection(req: http.IncomingMessage, body: TerminalRunRequestBody): TerminalRunRejection | null;
export declare function extractWebSocketHandshakeToken(request: http.IncomingMessage, url: URL): string | null;
export declare function isWebSocketAuthorized(request: http.IncomingMessage, url: URL): boolean;
export interface WebSocketUpgradeRejection {
    status: 401 | 403 | 404;
    reason: string;
}
export declare function resolveWebSocketUpgradeRejection(req: http.IncomingMessage, wsUrl: URL): WebSocketUpgradeRejection | null;
/**
 * Resolve a WebSocket-presented bearer that is NOT the static connection key
 * against the host's session store. Device pairing deliberately mints a
 * revocable machine-session id as the client bearer (#13985); REST accepts it
 * through the host bridge's request authorization, and both WebSocket auth
 * paths (handshake token and in-band `{type:"auth"}`) accept it through this
 * same seam. Fail-closed: a missing bridge method (hostless agent), an
 * unavailable session store, a store failure, or an unknown/expired/revoked
 * session all deny.
 */
export declare function isWebSocketSessionTokenAuthorized(token: string, runtime: AgentRuntime | null): Promise<boolean>;
export declare function markWebSocketUpgradeSessionAuthorized(request: http.IncomingMessage): void;
export declare function isWebSocketUpgradeSessionAuthorized(request: http.IncomingMessage): boolean;
/**
 * Credential-less upgrades are allowed so browser clients can authenticate
 * post-open with `{type:"auth"}` — browsers cannot set Authorization on
 * `new WebSocket(url)`. An unbounded accept was a remote FD-exhaustion DoS:
 * every completed handshake pinned a file descriptor forever. Two bounds now
 * apply: this per-peer cap on concurrent pre-auth sockets, and a post-open
 * auth grace period (enforced in server.ts, cleared on `auth-ok`) after which
 * the server closes a socket that never authenticated.
 */
export declare const WS_AUTH_GRACE_TIMEOUT_MS = 10000;
export declare const MAX_PENDING_WEBSOCKETS_PER_PEER = 16;
/**
 * Reserve a pre-auth slot for the peer; false when the peer is at the cap.
 * Every true return must be paired with {@link releasePendingWebSocket} once
 * the socket authenticates or closes.
 */
export declare function tryAcquirePendingWebSocket(remoteAddress: string | null | undefined): boolean;
export declare function releasePendingWebSocket(remoteAddress: string | null | undefined): void;
export declare function __resetPendingWebSocketsForTests(): void;
/** Current pre-auth socket count for the peer — test/diagnostic visibility. */
export declare function pendingWebSocketCount(remoteAddress: string | null | undefined): number;
export declare function rejectWebSocketUpgrade(socket: import("node:stream").Duplex, statusCode: number, message: string): void;
export {};
