/**
 * Serializes web-conversation topology reconciliation for a running agent.
 *
 * Descriptors capture the exact runtime, topology, room generation, and caller
 * used by a turn. Connection work is single-flight per descriptor and serialized
 * per runtime because every web conversation mutates one shared world. Room
 * generation tokens are globally unique and safely evictable: eviction makes an
 * old descriptor invalid instead of letting a default generation revive it.
 */
import { type AgentRuntime, ElizaError, type RoleGrantSource, type UUID } from "@elizaos/core";
import type { BoundaryWorldRole } from "./boundary-role-resolver.js";
export interface ConversationConnectionDescriptor {
    readonly runtime: AgentRuntime;
    readonly runtimeAgentId: UUID;
    readonly conversationId: string;
    readonly roomId: UUID;
    readonly worldId: UUID;
    readonly messageServerId: UUID;
    readonly channelId: string;
    readonly agentName: string;
    readonly ownerId: UUID;
    readonly callerEntityId: UUID;
    readonly callerRole: BoundaryWorldRole;
    /** Audit source the caller's non-owner world-role grant is recorded with. */
    readonly callerGrantSource: RoleGrantSource;
    readonly callerUserName: string;
    readonly topologyIdentity: string;
    readonly proofIdentity: string;
    readonly topologyGeneration: number;
    readonly roomGeneration: number;
    readonly requestFence?: () => void;
}
/**
 * Captures every mutable input that determines the connection writes. The
 * returned descriptor remains valid only for the generations recorded here.
 */
export declare function captureConversationConnectionDescriptor(input: {
    runtime: AgentRuntime;
    conversationId: string;
    roomId: UUID;
    agentName: string;
    worldId: UUID;
    messageServerId: UUID;
    channelId: string;
    ownerId: UUID;
    callerEntityId: UUID;
    callerRole: BoundaryWorldRole;
    callerGrantSource: RoleGrantSource;
    callerUserName: string;
    requestFence?: () => void;
}): ConversationConnectionDescriptor;
/**
 * Coalesces identical work and serializes shared-world mutations. Callers await
 * this prerequisite before generation; it is not a success cache.
 */
export declare function scheduleConversationConnectionEnsure(descriptor: ConversationConnectionDescriptor, ensure: () => Promise<void>): Promise<void>;
/** Invalidates every descriptor and in-flight ensure for an in-place rename. */
export declare function invalidateConversationConnectionTopology(runtime: AgentRuntime): void;
/** Gives an explicitly created or recreated room a fresh generation token. */
export declare function prepareConversationConnectionRoom(runtime: AgentRuntime, roomId: UUID): void;
/**
 * Invalidates immediately, drains earlier reconciliation, and blocks new work
 * until deletion completes. Retiring the generation makes every descriptor
 * captured before or during deletion permanently stale without retaining a
 * historical tombstone in memory.
 */
export declare function serializeConversationConnectionRoomDeletion(runtime: AgentRuntime, roomId: UUID, deleteRoom: () => Promise<void>): Promise<void>;
/**
 * Rejects a turn when its runtime, topology, or room generation changed after
 * capture, including deletion and in-place character rename.
 */
export declare function assertConversationConnectionRuntime(currentRuntime: AgentRuntime | null, descriptor: ConversationConnectionDescriptor): void;
/** Narrows errors that must terminate the request without a success fallback. */
export declare function isConversationConnectionError(error: unknown): error is ElizaError;
