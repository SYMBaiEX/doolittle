import { type AgentEventPayloadLike } from "../runtime/agent-event-service.js";
import type { ServerState } from "./server-types.js";
export declare function isLifeOpsCloudPluginRoute(pathname: string): boolean;
export declare function maybeRouteAutonomyEventToConversation(state: ServerState, event: AgentEventPayloadLike): Promise<void>;
