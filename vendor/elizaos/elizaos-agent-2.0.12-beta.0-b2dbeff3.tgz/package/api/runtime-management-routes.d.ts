/** Claimed shell round-trip for owner-approved Devices & Runtimes operations. */
import type http from "node:http";
import { type RuntimeManagementRequest } from "@elizaos/contracts";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
import { type RuntimeManagementProposalStore } from "./runtime-management-proposal-store.js";
export interface RuntimeManagementRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    broadcastWs?: (payload: object) => void;
    broadcastWsToClientId?: (clientId: string, payload: object) => number;
    callerAuthorization: AgentHttpRequestAuthorization;
    proposalStore?: RuntimeManagementProposalStore;
}
declare function parseRequest(body: Record<string, unknown>): RuntimeManagementRequest | null;
declare function requestKey(request: RuntimeManagementRequest): string;
declare function purgeExpiredClaims(now?: number): void;
export declare function handleRuntimeManagementRoutes(ctx: RuntimeManagementRouteContext): Promise<boolean>;
export declare const runtimeManagementRouteInternals: {
    claims: Map<string, {
        token: string | null;
        expiresAt: number;
    }>;
    parseRequest: typeof parseRequest;
    purgeExpiredClaims: typeof purgeExpiredClaims;
    requestKey: typeof requestKey;
};
export {};
