import { PostProviderSwitchRequestSchema } from "@elizaos/contracts";
import { logger } from "@elizaos/core";
import { normalizeFirstRunProviderId, } from "@elizaos/host/protocol";
import { resolveDevCloudEnvAuthority } from "@elizaos/plugin-elizacloud/cloud-config/dev-cloud-env-authority";
import { defaultSecretsManager, persistProviderApiKey, } from "../runtime/operations/vault-bridge.js";
import { applyFirstRunConnectionConfig, createProviderSwitchConnection, ELIZA_CLOUD_CLI_PROXY_BASE_URL, } from "./provider-switch-config.js";
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
/** Provider ids that used to select the removed Codex CLI chat handler. */
function isRetiredSubscriptionChatProvider(provider) {
    const normalized = provider.trim().toLowerCase();
    return normalized === "openai-subscription" || normalized === "openai-codex";
}
function readIdempotencyKey(headers) {
    // Node lowercases header names on IncomingMessage.headers.
    const raw = headers["idempotency-key"];
    const value = Array.isArray(raw) ? raw[0] : raw;
    const trimmed = typeof value === "string" ? value.trim() : "";
    return trimmed.length > 0 ? trimmed : undefined;
}
export async function handleProviderSwitchRoutes(ctx) {
    const { req, res, method, pathname, state, json, error, readJsonBody } = ctx;
    if (method === "POST" && pathname === "/api/provider/switch") {
        const rawBody = await readJsonBody(req, res);
        if (rawBody === null)
            return true;
        const parsed = PostProviderSwitchRequestSchema.safeParse(rawBody);
        if (!parsed.success) {
            error(res, parsed.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsed.data;
        const normalizedProvider = normalizeFirstRunProviderId(body.provider);
        if (!normalizedProvider) {
            error(res, isRetiredSubscriptionChatProvider(body.provider)
                ? "The ChatGPT/Codex subscription cannot power chat. Link it under Accounts for coding agents and choose a different chat provider."
                : "Invalid provider", 400);
            return true;
        }
        const trimmedApiKey = body.apiKey;
        const devCloudAuthority = resolveDevCloudEnvAuthority();
        if (normalizedProvider === "elizacloud" && devCloudAuthority) {
            error(res, "Cloud provider activation is owned by the immutable local dev launch target; restart with the intended target and credential.", 409);
            return true;
        }
        try {
            let connection;
            if (normalizedProvider === "elizacloud") {
                connection = {
                    kind: "cloud-managed",
                    cloudProvider: "elizacloud",
                    apiKey: trimmedApiKey,
                };
            }
            else {
                connection = createProviderSwitchConnection({
                    provider: normalizedProvider,
                    apiKey: trimmedApiKey,
                    primaryModel: body.primaryModel,
                });
            }
            if (!connection) {
                error(res, "Invalid provider", 400);
                return true;
            }
            const intent = {
                kind: "provider-switch",
                provider: normalizedProvider,
                primaryModel: body.primaryModel,
            };
            const idempotencyKey = readIdempotencyKey(req.headers);
            const outcome = await ctx.runtimeOperationManager.start({
                intent,
                idempotencyKey,
                prepare: async () => {
                    const config = state.config;
                    let apiKeyRef;
                    if (trimmedApiKey) {
                        const secrets = ctx.secretsManager ?? defaultSecretsManager();
                        try {
                            apiKeyRef = await persistProviderApiKey({
                                secrets,
                                normalizedProvider,
                                apiKey: trimmedApiKey,
                                caller: "provider-switch-route",
                            });
                        }
                        catch (vaultErr) {
                            logger.error(`[api] Vault write failed for provider=${normalizedProvider}: ${vaultErr instanceof Error ? vaultErr.message : String(vaultErr)}`);
                            throw new Error("Vault write failed");
                        }
                    }
                    await applyFirstRunConnectionConfig(config, connection);
                    if (normalizedProvider === "elizacloud" && trimmedApiKey) {
                        process.env.ANTHROPIC_BASE_URL = ELIZA_CLOUD_CLI_PROXY_BASE_URL;
                        process.env.ANTHROPIC_API_KEY = trimmedApiKey;
                        process.env.OPENAI_BASE_URL = ELIZA_CLOUD_CLI_PROXY_BASE_URL;
                        process.env.OPENAI_API_KEY = trimmedApiKey;
                    }
                    ctx.saveElizaConfig(config);
                    return {
                        ...intent,
                        ...(apiKeyRef ? { apiKeyRef } : {}),
                    };
                },
            });
            if (outcome.kind === "accepted") {
                logger.info(`[api] Provider switch accepted: provider=${normalizedProvider} op=${outcome.operation.id}`);
                json(res, {
                    success: true,
                    provider: normalizedProvider,
                    restarting: true,
                    operationId: outcome.operation.id,
                }, 202);
                return true;
            }
            if (outcome.kind === "deduped") {
                const op = outcome.operation;
                logger.info(`[api] Provider switch deduped: provider=${normalizedProvider} op=${op.id} status=${op.status}`);
                json(res, {
                    success: true,
                    provider: normalizedProvider,
                    restarting: op.status === "running" || op.status === "pending",
                    operationId: op.id,
                    deduped: true,
                });
                return true;
            }
            // outcome.kind === "rejected-busy"
            json(res, {
                error: "Provider switch already in progress",
                activeOperationId: outcome.activeOperationId,
            }, 409);
            return true;
        }
        catch (err) {
            logger.error(`[api] Provider switch failed: ${err instanceof Error ? err.stack : err}`);
            error(res, err instanceof Error && err.message === "Vault write failed"
                ? "Vault write failed"
                : "Provider switch failed", 500);
        }
        return true;
    }
    return false;
}
