import { type RouteRequestContext } from "@elizaos/host/protocol";
export interface AuthRouteContext extends RouteRequestContext {
    pairingEnabled: () => boolean;
    ensurePairingCode: () => string | null;
    normalizePairingCode: (code: string) => string;
    rateLimitPairing: (ip: string | null) => boolean;
    getPairingExpiresAt: () => number;
    getPairingInstanceId: () => string;
    clearPairing: () => void;
}
export declare function handleAuthRoutes(ctx: AuthRouteContext): Promise<boolean>;
