/**
 * Canonical plugin-route dispatcher used by both the HTTP server and the
 * in-process (IPC) bridge.
 *
 * Both transports converge on this function so that one route definition in
 * `runtime.routes` serves both worlds:
 *
 *   HTTP (Hono / Node http)  ─┐
 *                              ├─→ dispatchRoute() ─→ Route.routeHandler (new)
 *   IPC (Bun ↔ Swift bridge) ─┘                    └→ Route.handler      (legacy Express shim)
 *
 * The legacy Express-style `handler` field is supported via a synthetic
 * `IncomingMessage` / `ServerResponse` shim that captures the response into
 * a {@link RouteHandlerResult}. New plugin routes should prefer
 * `routeHandler` which returns the result directly.
 */
import { Buffer } from "node:buffer";
import type { IncomingMessage, ServerResponse } from "node:http";
import { type AccessContext, type AgentRuntime, type IAgentRuntime } from "@elizaos/core";
import { type RouteHandlerResult, type RuntimeRouteHostContext } from "@elizaos/host/protocol";
export interface DispatchRouteArgs {
    signal?: AbortSignal;
    runtime: IAgentRuntime | AgentRuntime | null | undefined;
    method: string;
    path: string;
    headers: Record<string, string>;
    query?: Record<string, string | string[]>;
    /** Raw body: string, Buffer, or already-parsed JSON object/array. */
    body?: unknown;
    /** Preserved raw UTF-8 body for webhook HMAC verification (when JSON was parsed). */
    rawBody?: string;
    /** true when invoked in-process via IPC; false when invoked over HTTP. */
    inProcess: boolean;
    /** Select the exact owning server; scoped dispatch cannot use a runtime fallback. */
    hostKey?: object;
    isAuthorized: () => boolean;
    /** true when the transport verified a trusted loopback/local request. */
    isTrustedLocal?: () => boolean;
    /**
     * Requester identity resolved by the authenticated boundary (e.g. a
     * registered TokenRoleResolver principal, #14781). Omitted for the
     * single-owner local boundary, where routes must preserve their existing
     * unfiltered behavior (see `RouteHandlerContext.accessContext`).
     */
    accessContext?: AccessContext;
    /** Optional host context (config, restartRuntime, etc.) — installed on the runtime for the duration of the dispatch. */
    hostContext?: RuntimeRouteHostContext;
    /**
     * Optional incremental sink for a legacy SSE handler's body writes. When set,
     * every `res.write(...)` chunk is forwarded the instant the handler flushes it
     * — so an in-process transport (stdio bridge) delivers token frames as they
     * arrive instead of only after `res.end()`. The buffered `RouteHandlerResult`
     * is still returned on completion (with the full body) for callers that ignore
     * the sink. Unset over HTTP, where the socket already flushes incrementally.
     */
    onChunk?: (chunk: Buffer) => void;
    onHeaders?: (status: number, headers: Record<string, string>) => void;
}
interface CapturedResponse {
    statusCode: number;
    headers: Record<string, string>;
    chunks: Buffer[];
    ended: boolean;
    destroyed?: boolean;
    failure?: Error;
}
/**
 * Builds a synthetic `IncomingMessage` / `ServerResponse` pair that legacy
 * Express-shaped route handlers can write to. The captured response is
 * returned as a {@link RouteHandlerResult}.
 */
export declare function buildLegacyShim(args: {
    method: string;
    path: string;
    headers: Record<string, string>;
    query: Record<string, string | string[]>;
    params: Record<string, string>;
    body: unknown;
    rawBody?: string;
    onChunk?: (chunk: Buffer) => void;
    onHeaders?: (status: number, headers: Record<string, string>) => void;
}): {
    req: IncomingMessage;
    res: ServerResponse;
    captured: CapturedResponse;
};
export declare function capturedToResult(captured: CapturedResponse): RouteHandlerResult;
/**
 * Dispatch a single request against `runtime.routes`. Returns `null` when no
 * matching route is found. The caller is responsible for sending the result
 * back over whatever transport (HTTP response, IPC frame, etc.).
 */
export declare function dispatchRoute(args: DispatchRouteArgs): Promise<RouteHandlerResult | null>;
export {};
