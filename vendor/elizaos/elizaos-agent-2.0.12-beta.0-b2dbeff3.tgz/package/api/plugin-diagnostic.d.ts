/**
 * Merges a plugin-owned static diagnostic descriptor with host-resolved runtime
 * status into the `PluginEntry` shape the dashboard diagnostics card renders.
 * The generic `buildPluginDiagnosticEntry` carries no plugin-specific literals —
 * the descriptor supplies identity, config keys, tags, and prerequisite labels;
 * the status supplies live enabled/configured/capability state.
 * `resolveWalletDiagnosticStatus` is the one wallet-aware resolver, mapping the
 * wallet capability snapshot onto that generic status contract.
 */
import type { AgentRuntime, PluginDiagnosticDescriptor } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { PluginEntry } from "./server-types.js";
/**
 * Runtime-dynamic status the host resolves for a plugin diagnostic descriptor.
 * Merged with the plugin-owned static descriptor to render the diagnostic card.
 */
export interface PluginDiagnosticRuntimeStatus {
    enabled: boolean;
    configured: boolean;
    isActive: boolean;
    autoEnabled: boolean;
    capabilityStatus: NonNullable<PluginEntry["capabilityStatus"]>;
    capabilityReason: string | null;
    /** Satisfied state keyed by `PluginDiagnosticPrerequisite.key`. */
    prerequisiteMet: Record<string, boolean>;
}
/**
 * Generic renderer: merges a plugin-owned static descriptor with host-resolved
 * runtime status into the `PluginEntry` the diagnostics card consumes. No
 * plugin-specific literals live here — the descriptor supplies identity, config
 * keys, tags, and prerequisite labels; the status supplies the live state.
 */
export declare function buildPluginDiagnosticEntry(descriptor: PluginDiagnosticDescriptor, status: PluginDiagnosticRuntimeStatus): PluginEntry;
/**
 * Wallet-specific status resolver: maps the host's wallet capability snapshot
 * onto the generic diagnostic status for the EVM wallet descriptor. This is the
 * only wallet-aware glue; it lives beside the wallet capability engine, not in
 * the generic host router.
 */
export declare function resolveWalletDiagnosticStatus(descriptor: PluginDiagnosticDescriptor, state: {
    config: ElizaConfig;
    runtime: AgentRuntime | null;
}): PluginDiagnosticRuntimeStatus;
