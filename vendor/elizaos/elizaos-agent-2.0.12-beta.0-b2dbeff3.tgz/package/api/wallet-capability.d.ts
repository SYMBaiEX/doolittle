/**
 * Derives the agent's wallet capability status — the single computed shape the
 * dashboard renders to explain what the wallet can and cannot do, so the client
 * never has to reconstruct the gate itself. Resolves the effective wallet source
 * (local / managed / none), network, EVM and Solana addresses, whether
 * @elizaos/plugin-wallet (or a managed EVM bridge, or a live EVM service) is
 * loaded, EVM RPC readiness, connectors-only vs full automation mode, and the EVM
 * signing capability, then folds them into an executionReady flag plus a
 * human-readable executionBlockedReason.
 */
import type { AgentRuntime } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import { type EvmSigningCapabilityKind, resolveEvmSigningCapability } from "../services/evm-signing-capability.js";
import { getWalletAddresses } from "./wallet.js";
export declare const EVM_PLUGIN_PACKAGE = "@elizaos/plugin-wallet";
export interface WalletCapabilityStatus {
    walletSource: "local" | "managed" | "none";
    walletNetwork: "mainnet" | "testnet";
    evmAddress: string | null;
    solanaAddress: string | null;
    hasWallet: boolean;
    hasEvm: boolean;
    localSignerAvailable: boolean;
    rpcReady: boolean;
    automationMode: "full" | "connectors-only";
    pluginEvmLoaded: boolean;
    pluginEvmRequired: boolean;
    executionReady: boolean;
    executionBlockedReason: string | null;
    evmSigningCapability: EvmSigningCapabilityKind;
    evmSigningReason: string;
}
export declare function isPluginLoadedByName(runtime: AgentRuntime | null, pluginName: string): boolean;
export declare function resolveWalletAutomationMode(config: ElizaConfig): "full" | "connectors-only";
export declare function resolvePluginEvmLoaded(runtime: AgentRuntime | null): boolean;
export declare function resolveWalletCapabilityStatus(state: {
    config: ElizaConfig;
    runtime: AgentRuntime | null;
    getWalletAddresses?: typeof getWalletAddresses;
    resolveEvmSigningCapability?: typeof resolveEvmSigningCapability;
}): WalletCapabilityStatus;
