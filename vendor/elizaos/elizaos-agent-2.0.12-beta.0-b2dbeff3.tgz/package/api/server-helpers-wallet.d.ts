/**
 * Wallet export helpers extracted from server.ts.
 */
import type http from "node:http";
import type { WalletExportRejection, WalletExportRequestBody } from "@elizaos/contracts";
export type { WalletExportRejection };
export declare function resolveWalletExportRejection(req: http.IncomingMessage, body: WalletExportRequestBody): WalletExportRejection | null;
