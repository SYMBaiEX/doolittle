import { resolveRegisteredTokenRoleAccess } from "./boundary-role-resolver.js";
import { getAuthenticatedInProcessAuthorization } from "./in-process-request.js";
import { resolveBoundaryRole } from "./server-helpers-auth.js";
export function resolveInboxRequestAuthorization(req, method, pathname, hostAuthorization) {
    // A scoped self-dispatch retains its verified caller; a root helper header
    // cannot replace that identity or promote a narrower role.
    const inherited = getAuthenticatedInProcessAuthorization(req);
    if (inherited)
        return inherited;
    if (resolveBoundaryRole(req) === "OWNER") {
        return { ok: true, role: "OWNER" };
    }
    if (hostAuthorization.ok) {
        return hostAuthorization;
    }
    const registeredAccess = resolveRegisteredTokenRoleAccess(req);
    if (registeredAccess &&
        (registeredAccess.isAdmin ||
            registeredAccess.isRouteInScope(method.toUpperCase(), pathname))) {
        return {
            ok: true,
            role: registeredAccess.worldRole,
            principal: registeredAccess.principal,
        };
    }
    return hostAuthorization;
}
