import type { ElizaConfig } from "@elizaos/host/protocol";
export type WalletPrivateKeyName = "EVM_PRIVATE_KEY" | "SOLANA_PRIVATE_KEY";
/**
 * Stores wallet private keys in the host vault when OS-store mode keeps them
 * out of the on-disk config (boot hydration reads them back from the vault).
 * All-or-nothing: on any failure the prior vault entries are restored.
 */
export declare function persistWalletPrivateKeys(config: ElizaConfig, keys: Partial<Record<WalletPrivateKeyName, string>>, caller: string): Promise<void>;
/**
 * Restores wallet private keys the durable vault already holds into blank env
 * slots before any provisioning decision. In OS-store mode the vault is the
 * only durable copy (config saves strip plaintext keys) and the boot-time
 * vault→env hydrate runs only after the API listener is live, so a first-run
 * wallet request or boot auto-provision that arrives earlier would otherwise
 * see blank env vars, treat the stored — possibly funded — wallet as missing,
 * and overwrite it with freshly generated keys. Only blank env slots are
 * filled, preserving the documented precedence (launch env > vault). Returns
 * true when at least one key was restored.
 */
export declare function restoreWalletPrivateKeysFromVault(config: ElizaConfig): Promise<boolean>;
