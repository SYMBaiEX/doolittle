/**
 * Applies a plugin-config or plugin-set change to a live runtime by the
 * least-disruptive path: in-place `applyPluginConfig` (config_apply), a hot
 * unload+register of the changed packages (plugin_reload), or a full runtime
 * restart when adapter plugins change or lifecycle hooks are unsupported
 * (runtime_reload / restart_required). If a hot reload throws partway, a
 * two-phase rollback unregisters what was newly registered and re-registers
 * what was unloaded, restoring the previous plugin graph. Consumed by the
 * config/plugin mutation routes to keep the in-memory plugin graph consistent.
 */
import { type AgentRuntime } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { ResolvedPlugin } from "../runtime/plugin-types.js";
export type PluginRuntimeApplyMode = "none" | "config_apply" | "plugin_reload" | "runtime_reload" | "restart_required";
export interface PluginRuntimeApplyResult {
    mode: PluginRuntimeApplyMode;
    requiresRestart: boolean;
    restartedRuntime: boolean;
    loadedPackages: string[];
    unloadedPackages: string[];
    reloadedPackages: string[];
    appliedConfigPackage: string | null;
    reason: string;
}
interface ApplyPluginRuntimeMutationOptions {
    runtime: AgentRuntime | null;
    previousConfig: ElizaConfig;
    nextConfig: ElizaConfig;
    previousResolvedPlugins?: ResolvedPlugin[];
    nextResolvedPlugins?: ResolvedPlugin[];
    changedPluginId?: string;
    changedPluginPackage?: string;
    config?: Record<string, string>;
    forceReloadPackages?: string[];
    expectRuntimeGraphChange?: boolean;
    /** Caller permits in-place configuration of an already-registered target; otherwise resolve the graph. */
    configurationOnly?: boolean;
    reason: string;
    restartRuntime?: (reason: string) => Promise<boolean>;
}
export declare function applyPluginRuntimeMutation(options: ApplyPluginRuntimeMutationOptions): Promise<PluginRuntimeApplyResult>;
export {};
