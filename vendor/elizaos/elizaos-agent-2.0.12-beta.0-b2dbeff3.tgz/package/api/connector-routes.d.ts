/**
 * `/api/connectors` route handler: lists configured connectors (merging
 * eliza.json entries with those detected from env vars), upserts a connector
 * config (POST), and removes one (DELETE /:name). Config writes are persisted
 * through saveElizaConfig with in-memory rollback if the disk write throws, so a
 * failed save never reports success. Disconnects may notify an optional host
 * callback. Blocked object keys are rejected to prevent prototype pollution.
 */
import type http from "node:http";
import type { IAgentRuntime } from "@elizaos/core";
import type { ElizaConfig, ReadJsonBodyOptions } from "@elizaos/host/protocol";
export interface ConnectorRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: {
        config: ElizaConfig;
        /** Optional running agent used to report host callback failures. */
        runtime?: IAgentRuntime | null;
    };
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    saveElizaConfig: (config: ElizaConfig) => void;
    redactConfigSecrets: (config: Record<string, unknown>) => Record<string, unknown>;
    isBlockedObjectKey: (key: string) => boolean;
    /**
     * Fail-closed companion to `cloneWithoutBlockedObjectKeys`. The clone throws
     * the walk-budget error rather than returning a partial object, so callers
     * must run this first and reject; otherwise the error escapes to the route
     * kernel and becomes a 500.
     */
    hasBlockedObjectKeyDeep: (value: unknown) => boolean;
    cloneWithoutBlockedObjectKeys: <T>(value: T) => T;
    /** Optional host-supplied callback fired on every disconnect path. */
    onConnectorDisconnect?: (connectorName: string) => Promise<void> | void;
}
export declare function handleConnectorRoutes(ctx: ConnectorRouteContext): Promise<boolean>;
