import { resolveEvmSigningCapability, } from "../services/evm-signing-capability.js";
import { getWalletAddresses } from "./wallet.js";
import { resolveWalletRpcReadiness } from "./wallet-rpc.js";
export const EVM_PLUGIN_PACKAGE = "@elizaos/plugin-wallet";
const EVM_PLUGIN_SERVICE_NAMES = ["evm", "evmService"];
function readPrimaryWalletSource(config, chain) {
    const wallet = config.wallet && typeof config.wallet === "object"
        ? config.wallet
        : null;
    const primary = wallet?.primary && typeof wallet.primary === "object"
        ? wallet.primary
        : null;
    const configured = primary?.[chain];
    if (configured === "local" || configured === "cloud") {
        return configured;
    }
    const envKey = chain === "evm"
        ? process.env.WALLET_SOURCE_EVM
        : process.env.WALLET_SOURCE_SOLANA;
    return envKey === "local" || envKey === "cloud" ? envKey : null;
}
function hasRuntimeEvmService(runtime) {
    if (!runtime ||
        typeof runtime.getService !== "function") {
        const services = runtime?.services;
        if (services &&
            typeof services === "object" &&
            "get" in services &&
            typeof services.get === "function") {
            for (const serviceName of EVM_PLUGIN_SERVICE_NAMES) {
                try {
                    const instances = services.get(serviceName);
                    if ((Array.isArray(instances) && instances.length > 0) ||
                        (!Array.isArray(instances) && Boolean(instances))) {
                        return true;
                    }
                }
                catch {
                    // error-policy:J3 service-registry probe — a lookup that throws means
                    // this provider isn't usable here; treated as absent, try the next.
                }
            }
        }
        return false;
    }
    try {
        const getService = runtime
            .getService;
        for (const serviceName of EVM_PLUGIN_SERVICE_NAMES) {
            try {
                if (getService(serviceName)) {
                    return true;
                }
            }
            catch {
                // error-policy:J3 service-registry probe — a lookup that throws means
                // this provider isn't usable here; treated as absent, try the next.
            }
        }
        return false;
    }
    catch {
        return false;
    }
}
function getRuntimePlugins(runtime) {
    const plugins = runtime?.plugins;
    if (Array.isArray(plugins)) {
        return plugins;
    }
    if (plugins &&
        typeof plugins === "object" &&
        "length" in plugins &&
        typeof plugins.length === "number") {
        return Array.from({ length: plugins.length }, (_, index) => {
            return plugins[index];
        });
    }
    if (plugins &&
        typeof plugins === "object" &&
        Symbol.iterator in plugins &&
        typeof plugins[Symbol.iterator] === "function") {
        try {
            return Array.from(plugins);
        }
        catch {
            return [];
        }
    }
    return [];
}
function getPluginIdentifiers(plugin) {
    if (!plugin || typeof plugin !== "object") {
        return [];
    }
    const record = plugin;
    return ["name", "id", "packageName", "npmName"]
        .map((key) => record[key])
        .filter((value) => typeof value === "string");
}
function isManagedEvmBridgeActive() {
    return Boolean(process.env.ELIZA_MANAGED_EVM_ADDRESS?.trim() ||
        process.env.ELIZA_CLOUD_EVM_ADDRESS?.trim());
}
export function isPluginLoadedByName(runtime, pluginName) {
    const shortId = pluginName.replace("@elizaos/plugin-", "");
    const packageSuffix = `plugin-${shortId}`;
    return getRuntimePlugins(runtime).some((plugin) => {
        return getPluginIdentifiers(plugin).some((identifier) => {
            return (identifier === pluginName ||
                identifier === shortId ||
                identifier === packageSuffix ||
                identifier.endsWith(`/${packageSuffix}`) ||
                identifier.includes(shortId));
        });
    });
}
export function resolveWalletAutomationMode(config) {
    const features = config.features && typeof config.features === "object"
        ? config.features
        : null;
    const agentAutomation = features?.agentAutomation &&
        typeof features.agentAutomation === "object" &&
        !Array.isArray(features.agentAutomation)
        ? features.agentAutomation
        : null;
    return agentAutomation?.mode === "connectors-only"
        ? "connectors-only"
        : "full";
}
export function resolvePluginEvmLoaded(runtime) {
    return (isPluginLoadedByName(runtime, EVM_PLUGIN_PACKAGE) ||
        hasRuntimeEvmService(runtime) ||
        isManagedEvmBridgeActive());
}
export function resolveWalletCapabilityStatus(state) {
    const addrs = state.getWalletAddresses
        ? state.getWalletAddresses(state.runtime?.agentId)
        : getWalletAddresses(state.runtime?.agentId);
    const rpcReadiness = resolveWalletRpcReadiness(state.config);
    const automationMode = resolveWalletAutomationMode(state.config);
    const resolvedEvmSigning = (state.resolveEvmSigningCapability ?? resolveEvmSigningCapability)();
    const localSignerAvailable = resolvedEvmSigning.kind === "local";
    const localSolanaSignerAvailable = Boolean(process.env.SOLANA_PRIVATE_KEY?.trim());
    const hasWallet = Boolean(addrs.evmAddress || addrs.solanaAddress);
    const hasEvm = Boolean(addrs.evmAddress);
    const pluginEvmLoaded = resolvePluginEvmLoaded(state.runtime);
    const pluginEvmRequired = hasEvm || localSignerAvailable;
    const rpcReady = [
        rpcReadiness.bscRpcUrls,
        rpcReadiness.ethereumRpcUrls,
        rpcReadiness.baseRpcUrls,
        rpcReadiness.avalancheRpcUrls,
    ].some((urls) => urls.length > 0);
    const primaryEvmSource = readPrimaryWalletSource(state.config, "evm");
    // The active address of a cloud-primary EVM wallet is the cloud one. Only a
    // Steward signer can act for it; a local key belongs to a different wallet.
    const evmSigning = primaryEvmSource === "cloud" &&
        (resolvedEvmSigning.kind === "local" || resolvedEvmSigning.kind === "none")
        ? {
            kind: "cloud-view-only",
            canSign: false,
            reason: "Cloud wallet is primary (view-only — local signing unavailable)",
        }
        : resolvedEvmSigning;
    const primarySolanaSource = readPrimaryWalletSource(state.config, "solana");
    const hasCloudPrimary = primaryEvmSource === "cloud" || primarySolanaSource === "cloud";
    const hasLocalPrimary = primaryEvmSource === "local" || primarySolanaSource === "local";
    const walletSource = hasCloudPrimary
        ? "managed"
        : localSignerAvailable || localSolanaSignerAvailable || hasLocalPrimary
            ? hasWallet || localSignerAvailable || localSolanaSignerAvailable
                ? "local"
                : "none"
            : hasWallet
                ? "managed"
                : "none";
    let executionBlockedReason = null;
    if (!hasEvm) {
        executionBlockedReason = "No EVM wallet is active yet.";
    }
    else if (evmSigning.kind === "cloud-view-only") {
        // Prefer the explicit capability reason over a generic "plugin not loaded"
        // so the UI can tell users the cloud wallet is visible but not signable.
        executionBlockedReason = evmSigning.reason;
    }
    else if (!rpcReady) {
        executionBlockedReason = "No EVM RPC is configured.";
    }
    else if (!pluginEvmLoaded) {
        executionBlockedReason =
            "@elizaos/plugin-wallet is not loaded, so EVM wallet execution is unavailable.";
    }
    else if (automationMode !== "full") {
        executionBlockedReason =
            "Agent automation is in connectors-only mode, so wallet execution is blocked in chat.";
    }
    return {
        walletSource,
        walletNetwork: rpcReadiness.walletNetwork,
        evmAddress: addrs.evmAddress ?? null,
        solanaAddress: addrs.solanaAddress ?? null,
        hasWallet,
        hasEvm,
        localSignerAvailable,
        rpcReady,
        automationMode,
        pluginEvmLoaded,
        pluginEvmRequired,
        executionReady: executionBlockedReason === null,
        executionBlockedReason,
        evmSigningCapability: evmSigning.kind,
        evmSigningReason: evmSigning.reason,
    };
}
