/**
 * Serves the authenticated context-inspector projection over trajectory-owned
 * content metadata. The route reauthorizes the requested room on every call
 * and emits an allowlisted DTO that cannot carry source text or native IDs.
 */
import type http from "node:http";
import { type AgentRuntime, type TrajectoryDetailRecord, type UUID } from "@elizaos/core";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
export type ContextInspectorCompleteness = "complete" | "partial-recoverable" | "partial-source-loss" | "unavailable";
export type ContextInspectorRetentionState = "policy-managed" | "expires" | "expired" | "unavailable";
export interface ContextInspectorEntry {
    reference: string;
    kind: "file" | "document" | "attachment" | "email" | "memory" | "tool-result";
    range: {
        unit: "line" | "fragment" | "byte";
        start: number;
        end: number;
        total?: number;
    };
    completeness: ContextInspectorCompleteness;
    omissionReason: string | null;
    retentionState: ContextInspectorRetentionState;
}
export interface ContextInspectorBudget {
    usedTokens: number;
    limitTokens: number;
    reservedTokens: number;
    state: "within-budget" | "rejected" | "unavailable";
}
export interface ContextInspectorResponse {
    schemaVersion: "elizaos.context-inspector/v1";
    entries: ContextInspectorEntry[];
    tokenBudgets: ContextInspectorBudget[];
    page: {
        offset: number;
        limit: number;
        hasPrevious: boolean;
        hasMore: boolean;
        nextOffset: number | null;
    };
    state: "available" | "empty";
}
interface ContextInspectorRuntime extends Pick<AgentRuntime, "getRoom" | "getRoomsForParticipant" | "getService"> {
}
export interface ContextInspectorRouteOptions {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    pathname: string;
    method: string;
    url: URL;
    runtime: ContextInspectorRuntime | null;
    authorization: AgentHttpRequestAuthorization;
    resolveConversationRoomId: (conversationId: UUID) => Promise<UUID | null>;
    now?: () => number;
    redactReference?: (reference: string) => string;
}
/** Build the content-free wire projection from already authorized records. */
export declare function buildContextInspectorResponse(input: {
    trajectories: TrajectoryDetailRecord[];
    offset: number;
    limit: number;
    total: number;
    now: number;
    redactReference: (reference: string) => string;
}): ContextInspectorResponse;
/** Handle GET /api/context-inspector after the host's coarse auth gate. */
export declare function handleContextInspectorRoute(options: ContextInspectorRouteOptions): Promise<boolean>;
export {};
