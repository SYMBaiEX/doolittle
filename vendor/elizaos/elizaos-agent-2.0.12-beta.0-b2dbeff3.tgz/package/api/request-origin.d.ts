/**
 * Reconstructs direct and proxy-aware HTTP origins at API request boundaries.
 * Forwarded metadata is opt-in because it is only authoritative behind a
 * configured proxy; comma-separated chains use the client-facing first value.
 */
import type http from "node:http";
/** Empty when the request carries no usable host metadata. */
export declare function resolveDirectRequestOrigin(req: http.IncomingMessage): string;
/**
 * Proxy-aware origin for boundaries that already permit forwarded metadata.
 * Security-sensitive callers should use `resolveDirectRequestOrigin` unless a
 * configured external origin establishes proxy authority.
 */
export declare function resolveRequestOrigin(req: http.IncomingMessage): string;
