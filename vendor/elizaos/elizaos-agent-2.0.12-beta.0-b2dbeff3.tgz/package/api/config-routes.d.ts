/**
 * `/api/config` route handler: serves the redacted Eliza config (GET), applies
 * a validated partial config write (PUT), returns the settings JSON schema
 * (GET /schema), and hot-reloads eliza.json into the running runtime
 * (POST /reload). Sits behind the server's authenticated settings surface and
 * adds its own write-side hardening: an allowlist of top-level keys, prototype-
 * pollution rejection, stripping of step-up/wallet secrets and every key
 * rejected by isBlockedEnvKey
 * so the persistence→restart path cannot be turned into RCE, and terminal-token
 * authorization for stdio MCP servers. Writes split into hot-reloadable keys
 * (applied to state.config live) vs restart-required keys (plugins, providers,
 * models, database); provider API keys are synced into process.env.
 */
import type http from "node:http";
import { type AgentRuntime } from "@elizaos/core";
import { type ElizaConfig, type ReadJsonBodyOptions } from "@elizaos/host/protocol";
export interface ConfigRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    config: ElizaConfig;
    /**
     * Live runtime, when available. Used by POST /api/config/reload to apply
     * hot-reloadable fields (character.name/system/bio, env-derived API keys,
     * feature flags) to the running agent without a full restart.
     */
    runtime?: AgentRuntime | null;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    redactConfigSecrets: (config: Record<string, unknown>) => Record<string, unknown>;
    isBlockedObjectKey: (key: string) => boolean;
    stripRedactedPlaceholderValuesDeep: (value: unknown) => void;
    patchTouchesProviderSelection: (filtered: Record<string, unknown>) => boolean;
    isBlockedEnvKey: (key: string) => boolean;
    CONFIG_WRITE_ALLOWED_TOP_KEYS: Set<string>;
    resolveMcpServersRejection: (servers: Record<string, unknown>) => Promise<string | null>;
    resolveMcpTerminalAuthorizationRejection: (req: http.IncomingMessage, servers: Record<string, unknown>, body: {
        terminalToken?: string;
    }) => {
        reason: string;
        status: number;
    } | null;
}
/** Honest config patches share the canonical blocked-object-key budget. */
export declare const MAX_CONFIG_PATCH_DEPTH = 32;
export declare const MAX_CONFIG_PATCH_NODES = 100000;
/**
 * Reuse the hardened walker in blocked-object-keys.ts (depth 32 / 100k nodes,
 * descriptor-only reads, path-scoped cycle detect, typed unbounded error).
 * Over-budget graphs and nested blocked keys fail closed together.
 */
export declare function configPatchExceedsBound(value: unknown): boolean;
/**
 * Handle configuration routes (GET/PUT /api/config, GET /api/config/schema,
 * POST /api/config/reload). Returns `true` if the request was handled.
 */
export declare function handleConfigRoutes(ctx: ConfigRouteContext): Promise<boolean>;
