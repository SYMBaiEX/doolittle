/**
 * Mounts the destructive agent-admin HTTP routes on the shared route state:
 * POST /api/agent/restart re-initializes the runtime through the injected restart
 * handler and refreshes the reported status, and POST /api/agent/reset stops the
 * runtime, deletes the PGlite data directory (guarded to only ever remove a path
 * whose basename is `.elizadb`), clears the persisted first-run config, and wipes
 * the cloud vault entries so the next boot does not rehydrate a signed-in Eliza
 * Cloud state. Sits behind the authenticated dashboard gate; not public.
 */
import path from "node:path";
import { createRuntimeAccountStoragePolicy } from "@elizaos/auth/auth";
import { ElizaError, normalizeCharacterLanguage, resolveUserPath, } from "@elizaos/core";
import { getDefaultStylePreset, } from "@elizaos/host/protocol";
import { loadElizaConfig, saveElizaConfig } from "../config/config.js";
import { resolveEffectiveDbProvider } from "../runtime/database-selection.js";
import { getAgentHostBridge } from "../runtime/host-bridge.js";
import { removeResetCredentialsFromVault } from "../runtime/operations/vault-bridge.js";
import { detectRuntimeModel } from "./agent-model.js";
import { clearPersistedFirstRunConfig } from "./provider-switch-config.js";
import { quiesceRuntimeBeforeReplacement } from "./runtime-replacement-ownership.js";
function resolveDefaultAgentName(config) {
    const ui = config.ui;
    const agents = config.agents;
    const configuredName = ui?.assistant?.name?.trim() ?? agents?.list?.[0]?.name?.trim();
    if (configuredName) {
        return configuredName;
    }
    return getDefaultStylePreset(normalizeCharacterLanguage(ui?.language)).name;
}
/**
 * The local store that Reset deletes. Reset only erases the default PGlite
 * directory; for any other store it throws before the runtime stops, so the
 * route cannot report a reset that left conversations and memory in place.
 */
export function resolveResetPgliteDataDir(config, defaultWorkspaceDir) {
    const provider = resolveEffectiveDbProvider(config);
    if (provider !== "pglite") {
        throw new ElizaError(`Reset cannot erase the ${provider} database. Erase it with your database tools, or switch to the local database before you reset.`, { code: "AGENT_RESET_DATABASE_UNSUPPORTED" });
    }
    const explicitDataDir = process.env.PGLITE_DATA_DIR?.trim();
    const configuredDataDir = config.database?.pglite?.dataDir?.trim();
    const dataDir = resolveUserPath(explicitDataDir ||
        configuredDataDir ||
        path.join(config.agents?.defaults?.workspace ?? defaultWorkspaceDir, ".elizadb"));
    if (path.basename(dataDir) !== ".elizadb") {
        throw new ElizaError(`Reset will not delete the custom database directory ${dataDir}. Erase it yourself before you reset.`, { code: "AGENT_RESET_DATABASE_UNSUPPORTED" });
    }
    return dataDir;
}
export async function handleAgentAdminRoutes(ctx) {
    const { res, method, pathname, state, onRestart, onRuntimeSwapped, onRuntimeActivated, json, error, resolveStateDir, stateDirExists, removeStateDir, } = ctx;
    if (method === "POST" && pathname === "/api/agent/restart") {
        if (state.runtimeStopPromise) {
            error(res, "Agent stop is still in progress", 409);
            return true;
        }
        if (!onRestart) {
            error(res, "Restart is not supported in this mode (no restart handler registered)", 501);
            return true;
        }
        if (state.agentState === "restarting") {
            error(res, "A restart is already in progress", 409);
            return true;
        }
        const previousState = state.agentState;
        state.agentState = "restarting";
        try {
            const previousRuntime = state.runtime;
            const newRuntime = ctx.restartRequiresRuntimeDisposal
                ? await onRestart({ disposeCurrentBeforeBuild: true })
                : await onRestart();
            if (newRuntime) {
                await quiesceRuntimeBeforeReplacement(previousRuntime, newRuntime);
                state.runtime = newRuntime;
                state.chatConnectionReady = null;
                state.chatConnectionPromise = null;
                state.agentState = "running";
                state.agentName =
                    newRuntime.character.name ?? resolveDefaultAgentName(state.config);
                state.model = detectRuntimeModel(newRuntime);
                state.startedAt = Date.now();
                state.pendingRestartReasons = [];
                onRuntimeSwapped?.();
                await onRuntimeActivated?.(previousRuntime, newRuntime);
                json(res, {
                    ok: true,
                    pendingRestart: false,
                    status: {
                        state: state.agentState,
                        agentName: state.agentName,
                        model: state.model,
                        startedAt: state.startedAt,
                    },
                });
            }
            else {
                if (ctx.restartRequiresRuntimeDisposal)
                    state.runtime = null;
                state.agentState = ctx.restartRequiresRuntimeDisposal
                    ? "error"
                    : previousState;
                error(res, "Restart handler returned null — runtime failed to re-initialize", 500);
            }
        }
        catch (err) {
            // error-policy:J1 expose restart failure without reviving a disposed runtime.
            const message = err instanceof Error ? err.message : String(err);
            if (ctx.restartRequiresRuntimeDisposal)
                state.runtime = null;
            state.agentState = ctx.restartRequiresRuntimeDisposal
                ? "error"
                : previousState;
            error(res, `Restart failed: ${message}`, 500);
        }
        return true;
    }
    if (method === "POST" && pathname === "/api/agent/reset") {
        if (state.runtimeStopPromise) {
            error(res, "Agent stop is still in progress", 409);
            return true;
        }
        try {
            const stateDir = resolveStateDir();
            const config = loadElizaConfig();
            const dataDir = resolveResetPgliteDataDir(config, path.join(stateDir, "workspace"));
            if (state.runtime) {
                await state.runtime.stop({ fast: true });
                state.runtime = null;
            }
            if (stateDirExists(dataDir)) {
                removeStateDir(dataDir);
            }
            clearPersistedFirstRunConfig(config, createRuntimeAccountStoragePolicy(stateDir));
            saveElizaConfig(config);
            // Wipe cloud-related vault entries so the next boot doesn't re-hydrate
            // the user back into a "signed in to Eliza Cloud" state. Without this,
            // /api/agent/reset clears the renderer UI but the vault still holds
            // ELIZAOS_CLOUD_API_KEY → vault-bootstrap rehydrates env on next start
            // → useCloudState reports cloud connected → user sees themselves still
            // logged in even though they just hit "Reset".
            await removeResetCredentialsFromVault(getAgentHostBridge().sharedVault());
            state.agentState = "stopped";
            state.agentName = resolveDefaultAgentName(config);
            state.model = undefined;
            state.startedAt = undefined;
            state.config = config;
            state.chatRoomId = null;
            state.chatUserId = null;
            state.chatConnectionReady = null;
            state.chatConnectionPromise = null;
            state.pendingRestartReasons = [];
            state.conversations?.clear();
            state.activeConversationId = null;
            state.conversationRestorePromise = null;
            json(res, { ok: true });
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            const unsupported = err instanceof ElizaError &&
                err.code === "AGENT_RESET_DATABASE_UNSUPPORTED";
            error(res, `Reset failed: ${message}`, unsupported ? 409 : 500);
        }
        return true;
    }
    return false;
}
