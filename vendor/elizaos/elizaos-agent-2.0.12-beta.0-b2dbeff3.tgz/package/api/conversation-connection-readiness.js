/**
 * Serializes web-conversation topology reconciliation for a running agent.
 *
 * Descriptors capture the exact runtime, topology, room generation, and caller
 * used by a turn. Connection work is single-flight per descriptor and serialized
 * per runtime because every web conversation mutates one shared world. Room
 * generation tokens are globally unique and safely evictable: eviction makes an
 * old descriptor invalid instead of letting a default generation revive it.
 */
import { ElizaError, } from "@elizaos/core";
const MAX_TRACKED_CONVERSATION_ROOMS = 2_048;
const MAX_PENDING_CONNECTION_MUTATIONS = 256;
const CONNECTION_MUTATION_TIMEOUT_MS = 15_000;
const CONNECTION_ERROR_CODES = new Set([
    "CONVERSATION_CONNECTION_INVALIDATED",
    "CONVERSATION_CONNECTION_QUEUE_SATURATED",
    "CONVERSATION_CONNECTION_REFRESH_FAILED",
    "CONVERSATION_CONNECTION_ROOM_BLOCKED",
    "CONVERSATION_CONNECTION_TIMEOUT",
    "CONVERSATION_RUNTIME_CHANGED",
]);
const registries = new WeakMap();
function getRegistry(runtime) {
    let registry = registries.get(runtime);
    if (!registry) {
        registry = {
            topologyIdentity: null,
            topologyGeneration: 0,
            nextRoomGeneration: 0,
            roomGenerations: new Map(),
            inFlightEnsures: new Map(),
            blockedRooms: new Set(),
            stalledMutations: new Set(),
            pendingMutationCount: 0,
            mutationTail: Promise.resolve(),
        };
        registries.set(runtime, registry);
    }
    return registry;
}
function connectionTopologyIdentity(input) {
    return JSON.stringify([
        input.runtimeAgentId,
        input.agentName,
        input.worldId,
        input.messageServerId,
        input.ownerId,
    ]);
}
function connectionProofIdentity(input) {
    return JSON.stringify([
        input.topologyIdentity,
        input.conversationId,
        input.roomId,
        input.channelId,
        input.ownerId,
        input.callerEntityId,
        input.callerRole,
        input.callerGrantSource,
        input.callerUserName,
    ]);
}
function invalidateTopology(registry, nextTopologyIdentity) {
    registry.topologyGeneration += 1;
    registry.topologyIdentity = nextTopologyIdentity;
}
function roomHasInFlightEnsure(registry, roomId) {
    return Array.from(registry.inFlightEnsures.values()).some((entry) => entry.descriptor.roomId === roomId);
}
function pruneRoomGenerations(registry) {
    const candidateCount = registry.roomGenerations.size;
    let inspected = 0;
    while (registry.roomGenerations.size > MAX_TRACKED_CONVERSATION_ROOMS &&
        inspected < candidateCount) {
        const oldestRoomId = registry.roomGenerations.keys().next().value;
        if (typeof oldestRoomId !== "string")
            return;
        inspected += 1;
        if (registry.blockedRooms.has(oldestRoomId) ||
            roomHasInFlightEnsure(registry, oldestRoomId)) {
            const generation = registry.roomGenerations.get(oldestRoomId);
            registry.roomGenerations.delete(oldestRoomId);
            if (generation !== undefined) {
                registry.roomGenerations.set(oldestRoomId, generation);
            }
            continue;
        }
        // Missing is an invalid generation. A later capture allocates a globally
        // unique token, so eviction can never make an old descriptor current.
        registry.roomGenerations.delete(oldestRoomId);
    }
}
function allocateRoomGeneration(registry, roomId) {
    registry.nextRoomGeneration += 1;
    const generation = registry.nextRoomGeneration;
    registry.roomGenerations.delete(roomId);
    registry.roomGenerations.set(roomId, generation);
    pruneRoomGenerations(registry);
    return generation;
}
function currentRoomGeneration(registry, roomId) {
    const generation = registry.roomGenerations.get(roomId);
    if (generation !== undefined) {
        registry.roomGenerations.delete(roomId);
        registry.roomGenerations.set(roomId, generation);
        return generation;
    }
    return allocateRoomGeneration(registry, roomId);
}
function descriptorGenerationsAreCurrent(registry, descriptor) {
    return (registry.topologyIdentity === descriptor.topologyIdentity &&
        registry.topologyGeneration === descriptor.topologyGeneration &&
        registry.roomGenerations.get(descriptor.roomId) ===
            descriptor.roomGeneration);
}
function descriptorIsCurrent(registry, descriptor) {
    return (descriptorGenerationsAreCurrent(registry, descriptor) &&
        !registry.blockedRooms.has(descriptor.roomId));
}
function invalidatedConnectionError(descriptor, cause) {
    return new ElizaError("Conversation connection descriptor was invalidated", {
        code: "CONVERSATION_CONNECTION_INVALIDATED",
        ...(cause !== undefined ? { cause } : {}),
        context: {
            agentId: descriptor.runtimeAgentId,
            conversationId: descriptor.conversationId,
            roomId: descriptor.roomId,
            worldId: descriptor.worldId,
        },
        severity: "ephemeral",
    });
}
function assertDescriptorCurrent(registry, descriptor) {
    if (!descriptorGenerationsAreCurrent(registry, descriptor)) {
        throw invalidatedConnectionError(descriptor);
    }
    if (registry.blockedRooms.has(descriptor.roomId)) {
        throw new ElizaError("Conversation room is being deleted", {
            code: "CONVERSATION_CONNECTION_ROOM_BLOCKED",
            context: {
                agentId: descriptor.runtimeAgentId,
                conversationId: descriptor.conversationId,
                roomId: descriptor.roomId,
            },
            severity: "ephemeral",
        });
    }
}
function mutationUnavailableError(context, code, message) {
    return new ElizaError(message, {
        code,
        context: { ...context },
        severity: "ephemeral",
    });
}
function enqueueConnectionMutation(registry, context, mutation, onTimeout) {
    if (registry.stalledMutations.size > 0) {
        throw mutationUnavailableError(context, "CONVERSATION_CONNECTION_TIMEOUT", "Conversation connection reconciliation is quarantined behind an unsettled write");
    }
    if (registry.pendingMutationCount >= MAX_PENDING_CONNECTION_MUTATIONS) {
        throw mutationUnavailableError(context, "CONVERSATION_CONNECTION_QUEUE_SATURATED", "Conversation connection reconciliation queue is saturated");
    }
    const timeoutError = mutationUnavailableError(context, "CONVERSATION_CONNECTION_TIMEOUT", "Conversation connection reconciliation exceeded its deadline");
    let cancelledBeforeStart = false;
    const execute = async () => {
        if (cancelledBeforeStart)
            throw timeoutError;
        await mutation();
    };
    registry.pendingMutationCount += 1;
    const run = registry.mutationTail.then(execute, execute);
    registry.mutationTail = run.then(() => undefined, () => undefined);
    let observerSettled = false;
    const result = new Promise((resolve, reject) => {
        const deadline = setTimeout(() => {
            if (observerSettled)
                return;
            observerSettled = true;
            cancelledBeforeStart = true;
            onTimeout();
            // The request may fail now, but the raw write keeps exclusive ownership
            // of mutationTail. New mutations fail fast until that I/O truly settles.
            registry.stalledMutations.add(run);
            reject(timeoutError);
        }, CONNECTION_MUTATION_TIMEOUT_MS);
        run.then(() => {
            clearTimeout(deadline);
            if (observerSettled)
                return;
            observerSettled = true;
            resolve();
        }, (error) => {
            clearTimeout(deadline);
            if (observerSettled)
                return;
            observerSettled = true;
            reject(error);
        });
    });
    const releaseMutation = () => {
        registry.pendingMutationCount -= 1;
        registry.stalledMutations.delete(run);
    };
    run.then(releaseMutation, releaseMutation);
    return { raw: run, result };
}
/**
 * Captures every mutable input that determines the connection writes. The
 * returned descriptor remains valid only for the generations recorded here.
 */
export function captureConversationConnectionDescriptor(input) {
    const registry = getRegistry(input.runtime);
    const topologyIdentity = connectionTopologyIdentity({
        runtimeAgentId: input.runtime.agentId,
        agentName: input.agentName,
        worldId: input.worldId,
        messageServerId: input.messageServerId,
        ownerId: input.ownerId,
    });
    if (registry.topologyIdentity === null) {
        registry.topologyIdentity = topologyIdentity;
    }
    else if (registry.topologyIdentity !== topologyIdentity) {
        invalidateTopology(registry, topologyIdentity);
    }
    const proofIdentity = connectionProofIdentity({
        topologyIdentity,
        conversationId: input.conversationId,
        roomId: input.roomId,
        channelId: input.channelId,
        ownerId: input.ownerId,
        callerEntityId: input.callerEntityId,
        callerRole: input.callerRole,
        callerGrantSource: input.callerGrantSource,
        callerUserName: input.callerUserName,
    });
    return Object.freeze({
        runtime: input.runtime,
        runtimeAgentId: input.runtime.agentId,
        conversationId: input.conversationId,
        roomId: input.roomId,
        worldId: input.worldId,
        messageServerId: input.messageServerId,
        channelId: input.channelId,
        agentName: input.agentName,
        ownerId: input.ownerId,
        callerEntityId: input.callerEntityId,
        callerRole: input.callerRole,
        callerGrantSource: input.callerGrantSource,
        callerUserName: input.callerUserName,
        topologyIdentity,
        proofIdentity,
        topologyGeneration: registry.topologyGeneration,
        roomGeneration: currentRoomGeneration(registry, input.roomId),
        ...(input.requestFence ? { requestFence: input.requestFence } : {}),
    });
}
/**
 * Coalesces identical work and serializes shared-world mutations. Callers await
 * this prerequisite before generation; it is not a success cache.
 */
export function scheduleConversationConnectionEnsure(descriptor, ensure) {
    const registry = getRegistry(descriptor.runtime);
    try {
        assertDescriptorCurrent(registry, descriptor);
    }
    catch (error) {
        return Promise.reject(error);
    }
    const existing = registry.inFlightEnsures.get(descriptor.proofIdentity);
    if (existing &&
        existing.descriptor.topologyGeneration === descriptor.topologyGeneration &&
        existing.descriptor.roomGeneration === descriptor.roomGeneration) {
        return existing.promise;
    }
    let run;
    try {
        run = enqueueConnectionMutation(registry, {
            agentId: descriptor.runtimeAgentId,
            conversationId: descriptor.conversationId,
            roomId: descriptor.roomId,
            worldId: descriptor.worldId,
        }, async () => {
            assertDescriptorCurrent(registry, descriptor);
            descriptor.requestFence?.();
            try {
                await ensure();
                descriptor.requestFence?.();
                assertDescriptorCurrent(registry, descriptor);
            }
            catch (error) {
                if (isConversationConnectionError(error)) {
                    throw error;
                }
                if (!descriptorIsCurrent(registry, descriptor)) {
                    throw invalidatedConnectionError(descriptor, error);
                }
                invalidateTopology(registry, registry.topologyIdentity);
                const reason = error instanceof Error ? error.message : String(error);
                throw new ElizaError(`Conversation connection reconciliation failed: ${reason}`, {
                    code: "CONVERSATION_CONNECTION_REFRESH_FAILED",
                    cause: error,
                    context: {
                        agentId: descriptor.runtimeAgentId,
                        conversationId: descriptor.conversationId,
                        roomId: descriptor.roomId,
                        worldId: descriptor.worldId,
                    },
                    severity: "ephemeral",
                });
            }
        }, () => {
            invalidateTopology(registry, registry.topologyIdentity);
        }).result;
    }
    catch (error) {
        return Promise.reject(error);
    }
    let tracked;
    tracked = run.finally(() => {
        if (registry.inFlightEnsures.get(descriptor.proofIdentity)?.promise ===
            tracked) {
            registry.inFlightEnsures.delete(descriptor.proofIdentity);
        }
        pruneRoomGenerations(registry);
    });
    registry.inFlightEnsures.set(descriptor.proofIdentity, {
        descriptor,
        promise: tracked,
    });
    // error-policy:J5 route callers await the returned promise; this observer
    // prevents a rejection from becoming unhandled before a queued caller joins.
    tracked.catch(() => { });
    return tracked;
}
/** Invalidates every descriptor and in-flight ensure for an in-place rename. */
export function invalidateConversationConnectionTopology(runtime) {
    invalidateTopology(getRegistry(runtime), null);
}
/** Gives an explicitly created or recreated room a fresh generation token. */
export function prepareConversationConnectionRoom(runtime, roomId) {
    const registry = getRegistry(runtime);
    registry.blockedRooms.delete(roomId);
    allocateRoomGeneration(registry, roomId);
}
/**
 * Invalidates immediately, drains earlier reconciliation, and blocks new work
 * until deletion completes. Retiring the generation makes every descriptor
 * captured before or during deletion permanently stale without retaining a
 * historical tombstone in memory.
 */
export async function serializeConversationConnectionRoomDeletion(runtime, roomId, deleteRoom) {
    const registry = getRegistry(runtime);
    allocateRoomGeneration(registry, roomId);
    registry.blockedRooms.add(roomId);
    let queued;
    try {
        queued = enqueueConnectionMutation(registry, { agentId: runtime.agentId, roomId }, deleteRoom, () => undefined);
    }
    catch (error) {
        registry.blockedRooms.delete(roomId);
        registry.roomGenerations.delete(roomId);
        throw error;
    }
    const releaseRoom = () => {
        registry.blockedRooms.delete(roomId);
        registry.roomGenerations.delete(roomId);
    };
    queued.raw.then(releaseRoom, releaseRoom);
    await queued.result;
}
/**
 * Rejects a turn when its runtime, topology, or room generation changed after
 * capture, including deletion and in-place character rename.
 */
export function assertConversationConnectionRuntime(currentRuntime, descriptor) {
    if (currentRuntime !== descriptor.runtime) {
        throw new ElizaError("Conversation runtime changed during the turn", {
            code: "CONVERSATION_RUNTIME_CHANGED",
            context: {
                expectedAgentId: descriptor.runtimeAgentId,
                conversationId: descriptor.conversationId,
                roomId: descriptor.roomId,
                currentAgentId: currentRuntime?.agentId,
            },
            severity: "ephemeral",
        });
    }
    descriptor.requestFence?.();
    assertDescriptorCurrent(getRegistry(descriptor.runtime), descriptor);
}
/** Narrows errors that must terminate the request without a success fallback. */
export function isConversationConnectionError(error) {
    return error instanceof ElizaError && CONNECTION_ERROR_CODES.has(error.code);
}
