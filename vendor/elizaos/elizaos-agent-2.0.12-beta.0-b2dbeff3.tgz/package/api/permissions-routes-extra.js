import { logger } from "@elizaos/core";
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
export async function handlePermissionsExtraRoutes(ctx) {
    const { res, method, pathname, state, json, error, readJsonBody } = ctx;
    // ── GET /api/permissions/automation-mode ──────────────────────────────
    if (method === "GET" && pathname === "/api/permissions/automation-mode") {
        const mode = state.agentAutomationMode ?? "full";
        json(res, {
            mode,
            options: ["connectors-only", "full"],
        });
        return true;
    }
    // ── PUT /api/permissions/automation-mode ──────────────────────────────
    if (method === "PUT" && pathname === "/api/permissions/automation-mode") {
        const body = await readJsonBody(ctx.req, res);
        if (!body)
            return true;
        const parsed = ctx.parseAgentAutomationMode(body.mode);
        if (!parsed) {
            error(res, 'Invalid mode. Expected "connectors-only" or "full".', 400);
            return true;
        }
        ctx.persistAgentAutomationMode(state, parsed);
        ctx.saveElizaConfig(state.config);
        json(res, {
            mode: parsed,
            options: ["connectors-only", "full"],
        });
        return true;
    }
    // ── GET /api/permissions/trade-mode ────────────────────────────────────
    if (method === "GET" && pathname === "/api/permissions/trade-mode") {
        const mode = ctx.resolveTradePermissionMode(state.config);
        json(res, {
            tradePermissionMode: mode,
            canUserLocalExecute: ctx.canUseLocalTradeExecution(mode, false),
            canAgentAutoTrade: ctx.canUseLocalTradeExecution(mode, true, undefined, {
                consumeAgentQuota: false,
            }),
        });
        return true;
    }
    // ── PUT /api/permissions/trade-mode ────────────────────────────────────
    if (method === "PUT" && pathname === "/api/permissions/trade-mode") {
        const body = await readJsonBody(ctx.req, res);
        if (!body)
            return true;
        const newMode = body.mode;
        if (newMode !== "user-sign-only" &&
            newMode !== "manual-local-key" &&
            newMode !== "agent-auto") {
            error(res, 'mode must be "user-sign-only", "manual-local-key", or "agent-auto"', 400);
            return true;
        }
        const previousFeatures = state.config.features;
        const features = {
            ...previousFeatures,
            tradePermissionMode: newMode,
        };
        state.config.features = features;
        try {
            ctx.saveElizaConfig(state.config);
        }
        catch (err) {
            // Roll back so the process does not trade under a mode that was never
            // persisted, and report the failure instead of `ok: true`.
            state.config.features = previousFeatures;
            const message = err instanceof Error ? err.message : String(err);
            logger.error(`[api] Trade-mode config save failed: ${message}`);
            error(res, `Failed to save trade permission mode: ${message}`, 500);
            return true;
        }
        json(res, {
            ok: true,
            tradePermissionMode: newMode,
            canUserLocalExecute: ctx.canUseLocalTradeExecution(newMode, false),
            canAgentAutoTrade: ctx.canUseLocalTradeExecution(newMode, true, undefined, { consumeAgentQuota: false }),
        });
        return true;
    }
    return false;
}
