import { NATIVE_NOTIFICATION_PAGE_LIMIT, NotificationNativeError, NotificationService, ServiceType, } from "@elizaos/core";
const NOTIFICATION_RETRY_AFTER_SECONDS = 1;
const CATEGORIES = [
    "reminder",
    "task",
    "workflow",
    "agent",
    "approval",
    "message",
    "health",
    "system",
    "general",
];
const PRIORITIES = ["low", "normal", "high", "urgent"];
/**
 * The dev/test seed spread: every priority tier, a breadth of categories, a
 * long body (exercises the widget's two-line clamp), safe deep links, and a
 * same-groupKey pair (the second collapses onto the first, proving supersede
 * behavior) — so one click paints a realistic, scrollable inbox.
 */
export const DEV_SEED_NOTIFICATIONS = [
    {
        title: "Approval needed: send weekly report",
        body: "The reporting workflow wants to email three recipients on your behalf.",
        category: "approval",
        priority: "urgent",
        source: "dev-seed",
        deepLink: "/chat",
    },
    {
        title: "Reminder: stand-up in 10 minutes",
        body: "Daily stand-up starts at 10:00.",
        category: "reminder",
        priority: "high",
        source: "dev-seed",
    },
    {
        title: "New message from Alice",
        body: "“Did you get a chance to look at the design doc?”",
        category: "message",
        priority: "normal",
        source: "dev-seed",
        deepLink: "/chat",
    },
    {
        title: "Task finished: nightly build",
        body: "All 412 tests passed in 6m 32s.",
        category: "task",
        priority: "normal",
        source: "dev-seed",
    },
    {
        title: "Health check-in",
        body: "You logged 6h 40m of sleep and a short walk this afternoon would close today's movement ring — this body intentionally runs long so list rows exercise their two-line clamp.",
        category: "health",
        priority: "low",
        source: "dev-seed",
    },
    {
        title: "Backup complete",
        body: "Workspace snapshot stored locally.",
        category: "system",
        priority: "low",
        source: "dev-seed",
    },
    {
        title: "Deploy pipeline update",
        body: "Step 2/5: building containers…",
        category: "workflow",
        priority: "normal",
        source: "dev-seed",
        groupKey: "dev-seed:deploy",
    },
    {
        title: "Deploy pipeline update",
        body: "Step 5/5: released to staging.",
        category: "workflow",
        priority: "normal",
        source: "dev-seed",
        groupKey: "dev-seed:deploy",
    },
];
function getService(state) {
    const svc = state.runtime?.getService(ServiceType.NOTIFICATION);
    return svc instanceof NotificationService ? svc : null;
}
function respondServiceUnavailable(res, state, method, pathname, helpers) {
    const runtime = state.runtime;
    if (!runtime) {
        res.setHeader("Retry-After", String(NOTIFICATION_RETRY_AFTER_SECONDS));
        helpers.json(res, {
            error: "Notification service is still starting",
            code: "NOTIFICATION_SERVICE_NOT_READY",
            retryAfter: NOTIFICATION_RETRY_AFTER_SECONDS,
        }, 503);
        return true;
    }
    const availability = NotificationService.getAvailability(runtime);
    if (availability === "disabled") {
        if (method === "GET" && pathname === "/api/notifications") {
            helpers.json(res, {
                notifications: [],
                unreadCount: 0,
                serviceStatus: "disabled",
            });
            return true;
        }
        helpers.json(res, {
            error: "Notification service is disabled",
            code: "NOTIFICATION_SERVICE_DISABLED",
        }, 503);
        return true;
    }
    if (availability === "failed") {
        const recovery = NotificationService.requestRecovery(runtime);
        res.setHeader("Retry-After", String(recovery.retryAfterSeconds));
        helpers.json(res, {
            error: "Notification inbox is temporarily unavailable",
            code: "NOTIFICATION_SERVICE_FAILED",
            retryAfter: recovery.retryAfterSeconds,
        }, 503);
        return true;
    }
    res.setHeader("Retry-After", String(NOTIFICATION_RETRY_AFTER_SECONDS));
    helpers.json(res, {
        error: "Notification service is still starting",
        code: "NOTIFICATION_SERVICE_NOT_READY",
        retryAfter: NOTIFICATION_RETRY_AFTER_SECONDS,
    }, 503);
    return true;
}
function parseLimit(raw) {
    if (raw === null || raw === "")
        return undefined;
    // Strict decimal digits only. Number.parseInt("1e2", 10) === 1 would
    // silently under-read the notification-center page as 1 row.
    if (!/^[1-9]\d*$/.test(raw))
        return null;
    const parsed = Number(raw);
    if (!Number.isSafeInteger(parsed) || parsed <= 0)
        return null;
    return Math.min(parsed, 500);
}
function parseCategory(raw) {
    if (raw && CATEGORIES.includes(raw)) {
        return raw;
    }
    return undefined;
}
/** Native completion closes sequence gaps, so filtered and ambiguous queries are invalid. */
function parseNativeQuery(url) {
    const params = url.searchParams;
    for (const key of [
        "nativeTransport",
        "nativeEpoch",
        "afterSequence",
        "throughSequence",
    ]) {
        if (params.getAll(key).length > 1)
            throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Repeated native query parameter");
    }
    const requested = params.get("nativeTransport");
    if (requested != null && requested !== "true" && requested !== "false")
        throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Invalid nativeTransport");
    if (requested !== "true") {
        if (["nativeEpoch", "afterSequence", "throughSequence"].some((key) => params.has(key)))
            throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Native cursor requires nativeTransport=true");
        return undefined;
    }
    if (params.has("unreadOnly") ||
        params.has("category") ||
        params.getAll("limit").length > 1)
        throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Native pages cannot use filters or repeated limit");
    const query = {};
    for (const key of ["afterSequence", "throughSequence", "limit"]) {
        const raw = params.get(key);
        if (raw == null)
            continue;
        if (!/^(0|[1-9]\d*)$/.test(raw) || !Number.isSafeInteger(Number(raw)))
            throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Native cursors must be safe decimal integers");
        query[key] = Number(raw);
    }
    if (query.limit != null &&
        (query.limit < 1 || query.limit > NATIVE_NOTIFICATION_PAGE_LIMIT))
        throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Native limit must be between 1 and 128");
    const epoch = params.get("nativeEpoch");
    if (epoch != null) {
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(epoch))
            throw new NotificationNativeError("INVALID_NATIVE_NOTIFICATION_CURSOR", "Invalid nativeEpoch");
        query.nativeEpoch = epoch;
    }
    return query;
}
/** Coerce an untrusted request body into a NotificationInput. */
function parseNotificationInput(body) {
    const title = typeof body.title === "string" ? body.title.trim() : "";
    if (!title) {
        return { ok: false, message: "title is required" };
    }
    const category = typeof body.category === "string" &&
        CATEGORIES.includes(body.category)
        ? body.category
        : undefined;
    const priority = typeof body.priority === "string" &&
        PRIORITIES.includes(body.priority)
        ? body.priority
        : undefined;
    const input = {
        title,
        body: typeof body.body === "string" ? body.body.trim() || undefined : undefined,
        category,
        priority,
        source: typeof body.source === "string"
            ? body.source.trim() || undefined
            : undefined,
        deepLink: typeof body.deepLink === "string"
            ? body.deepLink.trim() || undefined
            : undefined,
        groupKey: typeof body.groupKey === "string"
            ? body.groupKey.trim() || undefined
            : undefined,
        icon: typeof body.icon === "string" ? body.icon.trim() || undefined : undefined,
        data: body.data && typeof body.data === "object" && !Array.isArray(body.data)
            ? body.data
            : undefined,
    };
    return { ok: true, input };
}
export async function handleNotificationRoute(req, res, pathname, method, state, helpers) {
    if (!pathname.startsWith("/api/notifications"))
        return false;
    let listRequest;
    if (method === "GET" && pathname === "/api/notifications") {
        const url = new URL(req.url ?? pathname, "http://localhost");
        const requestedUnreadValues = url.searchParams.getAll("unreadOnly");
        const requestedUnread = requestedUnreadValues[0];
        if (requestedUnreadValues.length > 1 ||
            (requestedUnread != null &&
                requestedUnread !== "" &&
                requestedUnread !== "true" &&
                requestedUnread !== "false")) {
            helpers.error(res, "Invalid unreadOnly", 400);
            return true;
        }
        const limit = parseLimit(url.searchParams.get("limit"));
        if (limit === null) {
            helpers.error(res, "limit must be a positive integer", 400);
            return true;
        }
        try {
            listRequest = {
                url,
                limit,
                unreadOnly: requestedUnread === "true",
                nativeQuery: parseNativeQuery(url),
            };
        }
        catch (error) {
            if (!(error instanceof NotificationNativeError))
                throw error;
            helpers.json(res, { error: error.message, code: error.code }, error.status);
            return true;
        }
    }
    const service = getService(state);
    if (!service) {
        return respondServiceUnavailable(res, state, method, pathname, helpers);
    }
    // ── GET /api/notifications ────────────────────────────────────────
    if (listRequest) {
        const { url, limit, unreadOnly, nativeQuery } = listRequest;
        if (nativeQuery) {
            try {
                helpers.json(res, await service.listNativePage(nativeQuery));
            }
            catch (error) {
                if (!(error instanceof NotificationNativeError))
                    throw error;
                helpers.json(res, { error: error.message, code: error.code }, error.status);
            }
            return true;
        }
        const notifications = service.list({
            unreadOnly,
            category: parseCategory(url.searchParams.get("category")),
            limit,
        });
        helpers.json(res, {
            notifications,
            unreadCount: service.getUnreadCount(),
            serviceStatus: "ready",
        });
        return true;
    }
    // ── POST /api/notifications ───────────────────────────────────────
    if (method === "POST" && pathname === "/api/notifications") {
        const body = await helpers.readJsonBody(req, res, {
            maxBytes: 32 * 1024,
        });
        if (body === null)
            return true;
        const parsed = parseNotificationInput(body);
        if (!parsed.ok) {
            helpers.error(res, parsed.message, 400);
            return true;
        }
        const notification = await service.notify(parsed.input);
        helpers.json(res, { notification }, 201);
        return true;
    }
    // ── POST /api/notifications/read-all ──────────────────────────────
    if (method === "POST" && pathname === "/api/notifications/read-all") {
        const changed = await service.markAllRead();
        helpers.json(res, { changed });
        return true;
    }
    // ── POST /api/notifications/dev/seed ──────────────────────────────
    if (method === "POST" && pathname === "/api/notifications/dev/seed") {
        // 404 (not 403) in production so the route's existence isn't advertised.
        if (process.env.NODE_ENV === "production") {
            helpers.error(res, "notification route not found", 404);
            return true;
        }
        const notifications = [];
        for (const input of DEV_SEED_NOTIFICATIONS) {
            notifications.push(await service.notify(input));
        }
        helpers.json(res, { count: notifications.length, notifications }, 201);
        return true;
    }
    // ── POST /api/notifications/:id/read ──────────────────────────────
    const readMatch = pathname.match(/^\/api\/notifications\/([^/]+)\/read$/);
    if (method === "POST" && readMatch) {
        let id;
        try {
            id = decodeURIComponent(readMatch[1]);
        }
        catch {
            // error-policy:J3 untrusted-input sanitizing — malformed percent-encoding is invalid client input
            helpers.error(res, "invalid notification id", 400);
            return true;
        }
        const ok = await service.markRead(id);
        helpers.json(res, { ok });
        return true;
    }
    // ── DELETE /api/notifications ─────────────────────────────────────
    if (method === "DELETE" && pathname === "/api/notifications") {
        await service.clear();
        helpers.json(res, { ok: true });
        return true;
    }
    // ── DELETE /api/notifications/:id ─────────────────────────────────
    const idMatch = pathname.match(/^\/api\/notifications\/([^/]+)$/);
    if (method === "DELETE" && idMatch) {
        let id;
        try {
            id = decodeURIComponent(idMatch[1]);
        }
        catch {
            // error-policy:J3 untrusted-input sanitizing — malformed percent-encoding is invalid client input
            helpers.error(res, "invalid notification id", 400);
            return true;
        }
        const ok = await service.remove(id);
        helpers.json(res, { ok });
        return true;
    }
    helpers.error(res, "notification route not found", 404);
    return true;
}
