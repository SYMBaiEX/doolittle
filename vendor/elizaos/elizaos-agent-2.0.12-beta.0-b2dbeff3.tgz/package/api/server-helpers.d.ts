import type http from "node:http";
import { type AgentRuntime, type ChannelType, type ChatImageAttachment, createMessageMemory, type Media, type UUID } from "@elizaos/core";
import { type ElizaConfig } from "@elizaos/host/protocol";
import { type AgentEventServiceLike } from "../runtime/agent-event-service.js";
import { type CoreManagerLike, type PluginManagerLike } from "../services/plugin-manager-types.js";
import type { ChatAttachmentWithData, ConversationMeta } from "./server-types.js";
export declare function getAgentEventSvc(runtime: AgentRuntime | null): AgentEventServiceLike | null;
export declare function requirePluginManager(runtime: AgentRuntime | null): PluginManagerLike;
export declare function requireCoreManager(runtime: AgentRuntime | null): CoreManagerLike;
export declare function isUuidLike(value: string): value is UUID;
export declare const MAX_DELETED_CONVERSATION_IDS = 5000;
export interface DeletedConversationsStateFile {
    version: 1;
    updatedAt: string;
    ids: string[];
}
export declare function readDeletedConversationIdsFromState(): Set<string>;
export declare function persistDeletedConversationIdsToState(ids: Set<string>): void;
export declare function readOGCodeFromState(): string | null;
export declare function initializeOGCodeInState(): void;
export declare function hasPersistedFirstRunState(config: ElizaConfig): boolean;
/** Resolve the app owner's display name from config, or fall back to "User". */
export declare function resolveAppUserName(config: ElizaConfig): string;
export declare function patchTouchesProviderSelection(patch: Record<string, unknown>): boolean;
/**
 * Preset id to persist when a stream avatar selection is mirrored into
 * eliza.json.
 *
 * avatarIndex is a VRM art-asset index that several personas can share (Eliza
 * and Chen both render asset 1), so the index alone cannot identify a persona.
 * When the config already names a preset consistent with the selected avatar,
 * keep it — deriving a fresh presetId from the index would silently swap the
 * user's persona to whichever preset wins the index lookup.
 */
export declare function resolveMirroredAvatarPresetId(currentPresetId: string | null | undefined, avatarIndex: number, language?: unknown): string | undefined;
export declare function findOwnPackageRoot(startDir: string): string;
export declare function getErrorMessage(err: unknown, fallback?: string): string;
export declare function decodePathComponent(raw: string, res: http.ServerResponse, fieldName: string): string | null;
export declare const IMAGE_ONLY_CHAT_FALLBACK_PROMPT = "Please review the attached file.";
/**
 * Validate uploaded chat attachments (images, audio, video, PDFs, text docs).
 * Returns an error message string, or null if valid. Exported for unit tests.
 */
export declare function validateChatImages(images: unknown): string | null;
export declare function normalizeIncomingChatPrompt(text: string | null | undefined, images: ChatImageAttachment[] | null | undefined): string | null;
export declare function buildChatAttachments(images: ChatImageAttachment[] | undefined): Promise<{
    attachments: ChatAttachmentWithData[] | undefined;
    compactAttachments: Media[] | undefined;
}>;
type MessageMemory = ReturnType<typeof createMessageMemory>;
/**
 * Constructs the in-memory user message (with image data for action handlers)
 * and the persistence-safe counterpart (image data stripped).
 */
export declare function buildUserMessages(params: {
    images: ChatImageAttachment[] | undefined;
    prompt: string;
    userId: UUID;
    agentId: UUID;
    roomId: UUID;
    channelType: ChannelType;
    messageSource?: string;
    metadata?: Record<string, unknown>;
}): Promise<{
    userMessage: MessageMemory;
    messageToStore: MessageMemory;
}>;
type ConversationRoomTitleRef = Pick<ConversationMeta, "id" | "title" | "roomId">;
export declare function persistConversationRoomTitle(runtime: Pick<AgentRuntime, "getRoom" | "updateRoom"> | null | undefined, conversation: ConversationRoomTitleRef): Promise<boolean>;
export {};
