/**
 * HTTP routes for the agent server's local auth boundary: `GET /api/auth/me`
 * reports the caller's identity, session, and server-authoritative boundary
 * role (OWNER for a trusted loopback owner or valid API token, else GUEST with
 * a 401); `GET /api/auth/status` reports whether a token is required and the
 * pairing-code state; `GET /api/auth/pair-code` exposes the current code to
 * operators on loopback or holding the API token (the remote-agent pairing
 * contract in @elizaos/core); `POST /api/auth/pair` exchanges a rate-limited,
 * timing-safe, instance-bound pairing code for the connection token. These are the
 * entry points a client hits before it is authenticated, so they front the
 * rest of the API surface. In app the pair handler is shadowed by the
 * compat route that mints a real machine session.
 */
import crypto from "node:crypto";
import { PostAuthPairRequestSchema, } from "@elizaos/contracts";
import { resolveApiToken, } from "@elizaos/host/protocol";
import { isCloudProvisionedContainer } from "@elizaos/plugin-elizacloud/cloud-config/cloud-provisioning";
import { isAuthorized, isTrustedLocalRequest, resolveBoundaryRole, } from "./server-helpers-auth.js";
function getConfiguredApiToken() {
    // Inbound credential only — see the note on the exported helper in
    // server-helpers-auth.ts for why the legacy plugin key is not accepted here.
    return resolveApiToken(process.env) ?? undefined;
}
export async function handleAuthRoutes(ctx) {
    const { req, res, method, pathname, readJsonBody, json, error, pairingEnabled, ensurePairingCode, normalizePairingCode, rateLimitPairing, getPairingExpiresAt, getPairingInstanceId, clearPairing, } = ctx;
    if (!pathname.startsWith("/api/auth/"))
        return false;
    if (method === "GET" && pathname === "/api/auth/me") {
        const authorized = isAuthorized(req);
        const localAccess = isTrustedLocalRequest(req);
        if (!authorized) {
            json(res, {
                reason: getConfiguredApiToken()
                    ? "remote_auth_required"
                    : "remote_password_not_configured",
                access: {
                    mode: localAccess ? "local" : "remote",
                    passwordConfigured: Boolean(getConfiguredApiToken()),
                    ownerConfigured: false,
                    // #9948 / #12087 Item 13: server-authoritative boundary role from the
                    // single resolveBoundaryRole helper (unauthenticated → GUEST here).
                    role: resolveBoundaryRole(req),
                },
            }, 401);
            return true;
        }
        json(res, {
            identity: {
                id: localAccess ? "local-agent" : "bearer-agent",
                displayName: localAccess ? "Local Agent" : "API User",
                kind: "machine",
            },
            session: {
                id: localAccess ? "local" : "bearer",
                kind: localAccess ? "local" : "machine",
                expiresAt: null,
            },
            access: {
                mode: localAccess ? "local" : "bearer",
                passwordConfigured: !localAccess && Boolean(getConfiguredApiToken()),
                ownerConfigured: false,
                // #9948 / #12087 Item 13: an authorized caller (trusted loopback owner or
                // a valid API token) is the OWNER principal, via the single
                // resolveBoundaryRole helper. The UI consumes this via useRole.
                role: resolveBoundaryRole(req),
            },
        });
        return true;
    }
    if (method === "GET" && pathname === "/api/auth/status") {
        if (isCloudProvisionedContainer()) {
            // Steward-managed cloud containers enforce API auth upstream, but the
            // local pairing flow is intentionally unavailable there. Reporting
            // required=true would strand app clients in PairingView.
            json(res, {
                required: false,
                pairingEnabled: false,
                expiresAt: null,
            });
            return true;
        }
        const required = Boolean(getConfiguredApiToken());
        const enabled = pairingEnabled();
        if (enabled)
            ensurePairingCode();
        json(res, {
            required,
            authenticated: isAuthorized(req),
            pairingEnabled: enabled,
            expiresAt: enabled ? getPairingExpiresAt() : null,
            instanceId: getPairingInstanceId(),
        });
        return true;
    }
    // Operator helper for pairing a device against a standalone agent. Only a
    // trusted loopback operator or a caller already holding the API token may
    // read the code (a hosted agent, e.g. in a dstack CVM, has no reachable
    // loopback). Unauthenticated clients must enter the code they were given.
    if (method === "GET" && pathname === "/api/auth/pair-code") {
        if (!isTrustedLocalRequest(req) && !isAuthorized(req)) {
            error(res, "Pair code requires loopback or the API token", 403);
            return true;
        }
        if (isCloudProvisionedContainer()) {
            error(res, "Pairing disabled", 403);
            return true;
        }
        if (!pairingEnabled()) {
            error(res, "Pairing not enabled", 503);
            return true;
        }
        const code = ensurePairingCode();
        if (!code) {
            error(res, "Pairing not enabled", 503);
            return true;
        }
        json(res, {
            code,
            expiresAt: getPairingExpiresAt(),
            instanceId: getPairingInstanceId(),
        });
        return true;
    }
    if (method === "POST" && pathname === "/api/auth/pair") {
        // NOTE: this handler is shadowed by `handleAuthPairingCompatRoutes` in
        // `@elizaos/app` (the compat route mints a real machine session
        // bound to an identity, which authenticates against
        // `ensureCompatApiAuthorizedAsync`). This agent-only path is kept for
        // standalone agent-server usage; it returns the static connection key,
        // which only authenticates routes that explicitly accept the static
        // token (e.g. `/api/auth/status`). For full route coverage, run via
        // app so the compat handler intercepts first.
        const rawBody = await readJsonBody(req, res);
        if (rawBody === null)
            return true;
        const parsed = PostAuthPairRequestSchema.safeParse(rawBody);
        if (!parsed.success) {
            const issue = parsed.error.issues[0];
            const issuePath = issue?.path.join(".");
            error(res, `Invalid request body at ${issuePath}: ${issue?.message}`, 400);
            return true;
        }
        if (isCloudProvisionedContainer()) {
            error(res, "Pairing disabled", 403);
            return true;
        }
        const token = getConfiguredApiToken();
        if (!token) {
            error(res, "Pairing not enabled", 400);
            return true;
        }
        if (!pairingEnabled()) {
            error(res, "Pairing disabled", 403);
            return true;
        }
        if (!rateLimitPairing(req.socket.remoteAddress ?? null)) {
            error(res, "Too many attempts. Try again later.", 429);
            return true;
        }
        const instanceId = getPairingInstanceId();
        if (parsed.data.instanceId !== undefined &&
            parsed.data.instanceId.toLowerCase() !== instanceId) {
            json(res, {
                error: "Pairing code was issued by a different server instance",
                code: "PAIRING_INSTANCE_MISMATCH",
                instanceId,
            }, 409);
            return true;
        }
        const provided = parsed.data.code.trim();
        // Accept the raw API token itself as a valid "pairing code" — but only
        // from a trusted loopback operator. Remote callers must use the rotating
        // pairing code (real entropy, 10-minute expiry): accepting the static
        // token from any reachable address made pairing an online guessing oracle
        // for weak human-chosen `ELIZA_API_TOKEN` values, bounded only by the
        // per-IP rate limit (W1-038).
        //
        // This path deliberately bypasses the pairing code's expiry window: the
        // token does not rotate, so a holder can pair at any time. It is still
        // gated by `pairingEnabled()`, the cloud-container check, and the
        // per-IP `rateLimitPairing` above, which is what bounds guessing —
        // `timingSafeEqual` only removes the timing side-channel, it does nothing
        // against brute force. The token must therefore carry real entropy; a
        // human-chosen `ELIZA_API_TOKEN` weakens pairing to that token's strength.
        const tokenA = Buffer.from(token, "utf8");
        const tokenB = Buffer.from(provided, "utf8");
        const tokenMatch = isTrustedLocalRequest(req) &&
            tokenA.length === tokenB.length &&
            crypto.timingSafeEqual(tokenA, tokenB);
        if (tokenMatch) {
            const response = { token, instanceId };
            json(res, response);
            return true;
        }
        const normalizedProvided = normalizePairingCode(provided);
        const current = ensurePairingCode();
        if (!current || Date.now() > getPairingExpiresAt()) {
            ensurePairingCode();
            error(res, "Pairing code expired. Check server logs for a new code.", 410);
            return true;
        }
        const expected = normalizePairingCode(current);
        const a = Buffer.from(expected, "utf8");
        const b = Buffer.from(normalizedProvided, "utf8");
        if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
            error(res, "Invalid pairing code", 403);
            return true;
        }
        clearPairing();
        const response = { token, instanceId };
        json(res, response);
        return true;
    }
    return false;
}
