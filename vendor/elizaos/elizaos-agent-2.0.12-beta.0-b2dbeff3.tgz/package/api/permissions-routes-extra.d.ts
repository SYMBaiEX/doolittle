/**
 * Extra `/api/permissions` endpoints beyond the core native-permission set,
 * behind the dashboard control-API auth gate: GET/PUT `automation-mode`
 * (connectors-only vs full agent automation) and GET/PUT `trade-mode`
 * (user-sign-only / manual-local-key / agent-auto). Reads from and mutates the
 * persisted `ElizaConfig`, deriving execution-capability flags and persisting
 * mode changes through injected helpers so the handler stays transport-agnostic.
 */
import type http from "node:http";
import type { TradePermissionMode } from "@elizaos/contracts";
import { type AgentAutomationMode } from "@elizaos/core";
import type { ElizaConfig, ReadJsonBodyOptions } from "@elizaos/host/protocol";
import type { LocalTradeExecutionOptions } from "@elizaos/plugin-wallet/transactions";
export interface PermissionsExtraRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: {
        config: ElizaConfig;
        agentAutomationMode?: AgentAutomationMode;
    };
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    saveElizaConfig: (config: ElizaConfig) => void;
    resolveTradePermissionMode: (config: ElizaConfig) => TradePermissionMode;
    canUseLocalTradeExecution: (mode: TradePermissionMode, isAgent: boolean, log?: (message: string) => void, options?: LocalTradeExecutionOptions) => boolean;
    parseAgentAutomationMode: (value: unknown) => AgentAutomationMode | null;
    persistAgentAutomationMode: (state: {
        config: ElizaConfig;
        agentAutomationMode?: AgentAutomationMode;
    }, mode: AgentAutomationMode) => void;
}
export declare function handlePermissionsExtraRoutes(ctx: PermissionsExtraRouteContext): Promise<boolean>;
