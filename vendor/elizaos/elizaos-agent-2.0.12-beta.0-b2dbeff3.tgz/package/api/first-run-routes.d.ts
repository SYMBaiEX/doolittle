/**
 * First-run onboarding HTTP routes for the local agent server: `GET
 * /api/first-run/status`, `GET /api/first-run/options`, `GET /api/wallet/keys`
 * (first-run only), and `POST /api/first-run`.
 *
 * The POST handler is the single writer that turns the onboarding form into a
 * persisted `ElizaConfig`: character persona, UI preset/avatar/voice/theme,
 * deployment target and service routing, provider credentials, connectors
 * (Telegram/Discord/WhatsApp/Twilio/Blooio), GitHub token, inventory RPC keys,
 * sandbox mode, and the `meta.firstRunComplete` marker; it also mirrors the
 * character onto the live runtime and the agent DB row.
 *
 * Auth boundary: these routes are reachable before first-run state exists.
 * `GET /api/wallet/keys` self-gates to 403 once first-run has persisted, and
 * cloud-provisioned containers short-circuit `status` while seeding default
 * character + voice presets so the frontend hydrates correctly.
 */
import type http from "node:http";
import { type AgentRuntime, type UUID } from "@elizaos/core";
import { type ElizaConfig, type ReadJsonBodyOptions } from "@elizaos/host/protocol";
/** The 409 text for a Cloud inference first-run on an agent with no Cloud key. */
export declare const CLOUD_INFERENCE_NO_API_KEY_ERROR = "Eliza Cloud inference is not available on this agent: it has no Eliza Cloud API key, so it cannot reach Cloud models. Choose another provider.";
/**
 * True when this agent holds the credential plugin-elizacloud authenticates
 * with: the linked key in config, a config env entry, the sealed login secret,
 * or the process environment. Exported for the iOS bridge, which answers
 * `POST /api/first-run` itself and must apply the same check.
 */
export declare function hasCloudApiKeyForInference(config: ElizaConfig): boolean;
export interface FirstRunRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    state: FirstRunServerState;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    isCloudProvisionedContainer: () => boolean;
    hasPersistedFirstRunState: (config: ElizaConfig) => boolean;
    ensureWalletKeysInEnvAndConfig: (config: ElizaConfig) => Promise<boolean>;
    getWalletAddresses: () => {
        evmAddress?: string | null;
        solanaAddress?: string | null;
    };
    pickRandomNames: (count: number) => string[];
    getStylePresets: (lang: string) => unknown[];
    getProviderOptions: () => unknown[];
    getCloudProviderOptions: () => unknown[];
    getModelOptions: () => unknown;
    getInventoryProviderOptions: () => unknown[];
    resolveConfiguredCharacterLanguage: (config: ElizaConfig, req: http.IncomingMessage) => string;
    normalizeCharacterLanguage: (lang: string | undefined) => string;
    readUiLanguageHeader: (req: http.IncomingMessage) => string | null | undefined;
    applyFirstRunVoicePreset: (config: ElizaConfig, body: Record<string, unknown>, language: string) => void;
    saveElizaConfig: (config: ElizaConfig) => void;
}
export interface FirstRunServerState {
    config: ElizaConfig;
    runtime: AgentRuntime | null;
    agentName: string;
    adminEntityId: UUID | null;
    chatUserId: UUID | null;
    chatConnectionReady: unknown;
    chatConnectionPromise: Promise<void> | null;
}
export declare function handleFirstRunRoutes(ctx: FirstRunRouteContext): Promise<boolean>;
