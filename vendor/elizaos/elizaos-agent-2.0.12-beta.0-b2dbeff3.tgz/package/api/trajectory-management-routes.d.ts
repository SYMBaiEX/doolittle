/**
 * Owner-side trajectory management routes for the Trajectories view:
 * GET | PUT /api/trajectories/config, POST /api/trajectories/export and
 * DELETE /api/trajectories. The caller enforces the owner gate that covers
 * every /api/trajectories path before dispatching here. Reads stay with
 * `tryHandleTrajectoryReadRoutes`; both resolve the same "trajectories" service.
 */
import type http from "node:http";
import { type IAgentRuntime } from "@elizaos/core";
/**
 * Returns `true` when the request was answered, `false` when the path/method is
 * not a trajectory management route. Service failures propagate to the caller.
 */
export declare function handleTrajectoryManagementRoutes(options: {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    runtime: IAgentRuntime | null | undefined;
}): Promise<boolean>;
