/**
 * MCP server configuration validation helpers extracted from server.ts.
 */
import type http from "node:http";
import { type TerminalRunRejection } from "./server-helpers-auth.js";
export declare function resolveMcpServersRejection(servers: Record<string, unknown>): Promise<string | null>;
export declare function mcpServersIncludeStdio(servers: Record<string, unknown>): boolean;
/**
 * Stdio MCP config writes can reach child_process.spawn. By default require
 * ELIZA_TERMINAL_RUN_TOKEN; set ELIZA_ALLOW_UNAUTHENTICATED_STDIO_MCP=1 only
 * for intentional local dev (legacy compat passthrough).
 */
export declare function resolveMcpTerminalAuthorizationRejection(req: Pick<http.IncomingMessage, "headers">, servers: Record<string, unknown>, body: {
    terminalToken?: string;
}): TerminalRunRejection | null;
