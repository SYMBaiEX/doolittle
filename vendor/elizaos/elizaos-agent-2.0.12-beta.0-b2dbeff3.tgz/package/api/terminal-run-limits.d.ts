/** Resolve a caller-selected run identity, or generate one for legacy callers. */
export declare function resolveRequestedTerminalRunId(value: string | string[] | undefined): string | null;
export declare function resolveTerminalRunLimits(): {
    maxConcurrent: number;
    maxDurationMs: number;
};
