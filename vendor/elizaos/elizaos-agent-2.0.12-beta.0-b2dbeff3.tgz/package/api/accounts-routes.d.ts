/**
 * Multi-account credentials CRUD + OAuth-from-UI routes.
 *
 * The HTTP surface this exposes (under `/api/accounts/...`) is the
 * source of truth for the React settings page. It joins three sources:
 *
 *   - on-disk credential records under `<stateDir>/auth/...`
 *     (`account-storage.ts`),
 *   - rich `LinkedAccountConfig` records (label / enabled / priority /
 *     health / usage) owned by `AccountPool` in `@elizaos/app`,
 *   - the in-flight OAuth flow registry (`auth/oauth-flow.ts`) used by
 *     the `oauth/start` + SSE `oauth/status` + `oauth/cancel` trio.
 *
 * The pool is the SINGLE source of truth for `LinkedAccountConfig`. We
 * never touch `config.linkedAccounts` from these routes — that field
 * still holds the legacy `LinkedAccountFlagsConfig` (elizacloud
 * is-linked flags) shape for unrelated consumers.
 *
 * Provider-level account selection strategy lives in a dedicated
 * top-level config key, `accountStrategies` (see `applyStrategyPatch`
 * below). It's a separate slot from the per-capability
 * `serviceRouting[capability].strategy` so the UI can express
 * "always prefer my Pro Anthropic account before falling back to my
 * Max one" without having to know which capability each provider powers.
 * Per-strategy knobs live beside it in `accountStrategySettings`.
 */
import { type IAgentRuntime } from "@elizaos/core";
import { type ElizaConfig, type RouteRequestContext } from "@elizaos/host/protocol";
/** Test hook: forget cached install state between tests. */
export declare function __clearSubscriptionCliInstallFailures(): void;
export declare function ensureSubscriptionCli(providerId: "anthropic-subscription" | "openai-codex", deps?: {
    runInstall?: (args: string[]) => Promise<unknown>;
    isAvailable?: (command: string) => Promise<boolean>;
    now?: () => number;
}): Promise<void>;
/** Test-only: drop the cached pool reference between tests. */
export declare function _resetAccountsRoutesPoolCache(): void;
export interface AccountsRouteContext extends RouteRequestContext {
    state: {
        config: ElizaConfig;
        runtime?: Pick<IAgentRuntime, "setSetting"> | null;
    };
    saveConfig: (config: ElizaConfig) => void;
}
export declare function handleAccountsRoutes(ctx: AccountsRouteContext): Promise<boolean>;
/**
 * Re-run the host's pool-to-environment export after a direct-provider account
 * mutation. The export pass is the same one boot runs, so a newly linked,
 * replaced, re-enabled, re-prioritized, disabled, or deleted account changes
 * the live provider credential (and the OpenAI-compatible route for the active
 * backend) without a process restart, and a pool that rejects every account
 * retracts the previously exported value. No route writes provider keys
 * directly.
 */
export declare function syncDirectProviderCredentials(ctx: Pick<AccountsRouteContext, "state">, providerId: string): Promise<void>;
