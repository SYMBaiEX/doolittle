const resolvers = new Map();
/**
 * Register (or replace) a boundary-role resolver. Idempotent per `id`.
 * Returns an unregister function.
 */
export function registerTokenRoleResolver(resolver) {
    resolvers.set(resolver.id, resolver);
    return () => {
        // Only remove if the same instance is still registered (a later
        // re-registration of the same id owns the slot).
        if (resolvers.get(resolver.id) === resolver) {
            resolvers.delete(resolver.id);
        }
    };
}
/** Test/reset hook: drop all registered resolvers. */
export function clearTokenRoleResolvers() {
    resolvers.clear();
}
/** Whether a resolver is registered for the given id. */
export function hasTokenRoleResolver(id) {
    return resolvers.has(id);
}
/**
 * Consult every registered resolver in registration order; return the first
 * non-null {@link BoundaryRoleAccess}, or `null` if none recognise the request.
 * A resolver that throws is treated as a non-match (fail-closed for that
 * resolver, not for the whole gate).
 */
export function resolveRegisteredTokenRoleAccess(req) {
    for (const resolver of resolvers.values()) {
        let access = null;
        try {
            access = resolver.resolve(req);
        }
        catch {
            access = null;
        }
        if (access)
            return access;
    }
    return null;
}
/**
 * The trunk authorization predicate for registered boundary resolvers. A
 * recognised admin is always authorized; a recognised non-admin is authorized
 * only for routes its resolver declares in scope. Unrecognised → false (defer
 * to the trunk's own token/loopback auth).
 */
export function isRegisteredTokenRoleAuthorized(req, method, pathname) {
    const access = resolveRegisteredTokenRoleAccess(req);
    if (!access)
        return false;
    if (access.isAdmin)
        return true;
    return access.isRouteInScope(method.toUpperCase(), pathname);
}
