/**
 * One shared HTTP surface for agent-driven runtime switching (#12178): the
 * MODEL_SWITCH / AGENT_SWITCH actions and the deterministic `/model` command
 * all POST here, so user- and agent-initiated switches run one implementation.
 *
 * Routes:
 *   POST /api/runtime/model-switch         — flip text inference local↔cloud
 *   POST /api/runtime/agent-switch         — repoint the app shell to a saved
 *                                            runtime profile (resolved client-side)
 *   POST /api/runtime/agent-switch/result  — frontend result callback
 *
 * Model switching is applied server-side through the EXISTING local-inference
 * routes over loopback (assignments / routing / active / downloads — no second
 * implementation of any of them), then broadcast as `shell:model-switch` so
 * connected shells can surface a notice. Sanctioned-models-only is enforced
 * here at the boundary: local ids must be curated Eliza-1 release tiers
 * (`DEFAULT_ELIGIBLE_MODEL_IDS`), cloud is exactly
 * `DEFAULT_ELIZA_CLOUD_TEXT_MODEL`.
 *
 * Distinct from `POST /api/provider/switch` (provider-switch-routes.ts): that
 * is the BYOK provider-connection axis — persists an API key to the vault,
 * rewrites the runtime connection config, and restarts the runtime. This
 * route is the lightweight local↔cloud inference-routing axis (dossier §H
 * "hybrid axis"): no restart, no key handling, routing preference only.
 *
 * Agent switching cannot complete server-side: runtime profiles are
 * client-persisted (localStorage registry, see
 * `packages/ui/src/state/agent-profiles.ts`), so the server deliberately owns
 * no profile registry. The route broadcasts `shell:switch-agent` with a
 * request id, the shell resolves the profile and applies it via the canonical
 * `switchRuntimeNonDestructive` (inheriting its remote-trust gate), and
 * reports the outcome back through the result callback — same
 * pending-request pattern as the views interact round-trip.
 */
import type http from "node:http";
export type ModelSwitchTarget = "local" | "cloud";
export type ModelSwitchStatus = "ready" | "loading" | "downloading";
/** Wire response of POST /api/runtime/model-switch. */
export interface ModelSwitchResponse {
    ok: true;
    target: ModelSwitchTarget;
    model: string;
    displayName: string;
    status: ModelSwitchStatus;
    /** Bundle size in GB when status === "downloading" (from the catalog). */
    downloadSizeGb?: number;
}
/** Wire response of POST /api/runtime/agent-switch. */
export interface AgentSwitchResponse {
    ok: boolean;
    profileId?: string;
    profileLabel?: string;
    /**
     * Refusal/failure reason when ok=false:
     * "not-found" | "untrusted-remote" (from the shell's trust gate) or
     * "no-shell" (no connected shell answered in time).
     */
    reason?: string;
}
export interface RuntimeSwitchRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    broadcastWs?: (payload: object) => void;
    /** Test seam; defaults to global fetch against the server's own loopback. */
    loopbackFetch?: typeof fetch;
}
/**
 * Resolve a pending agent switch from the frontend's result callback. Exposed
 * for the route's own result endpoint and for tests.
 */
export declare function resolveAgentSwitchResult(result: {
    requestId: string;
    ok: boolean;
    profileId?: string;
    profileLabel?: string;
    reason?: string;
}): void;
export declare function handleRuntimeSwitchRoutes(ctx: RuntimeSwitchRouteContext): Promise<boolean>;
