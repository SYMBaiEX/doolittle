/**
 * Serializes server values for JavaScript literals embedded in HTML script
 * elements, preserving JSON semantics without allowing an HTML end tag to
 * terminate the script early.
 */
/** Serialize a defined value for interpolation into an inline script. */
export declare function serializeInlineScriptValue(value: unknown): string;
