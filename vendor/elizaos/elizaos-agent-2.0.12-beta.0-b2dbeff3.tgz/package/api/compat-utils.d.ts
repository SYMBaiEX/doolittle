/**
 * Extract a best-effort text string from OpenAI/Anthropic "content" fields.
 * Supports:
 * - string
 * - array of parts: [{ type: "text", text: "..." }, ...]
 * - objects with a `text` string field
 */
export declare function extractCompatTextContent(content: unknown): string;
export type OpenAiChatRole = "system" | "developer" | "user" | "assistant" | "tool" | "function";
export interface OpenAiChatMessage {
    role: OpenAiChatRole;
    content?: unknown;
}
/**
 * For OpenAI-compatible requests, we intentionally reduce "messages" to:
 * - all system/developer messages (joined)
 * - the last user message
 *
 * This keeps the server-side room memory coherent (so stateless clients that
 * resend full history do not cause runaway duplication).
 */
export declare function extractOpenAiSystemAndLastUser(messages: unknown): {
    system: string;
    user: string;
} | null;
export type AnthropicRole = "user" | "assistant";
export interface AnthropicMessage {
    role: AnthropicRole;
    content?: unknown;
}
export declare function extractAnthropicSystemAndLastUser(args: {
    system?: unknown;
    messages: unknown;
}): {
    system: string;
    user: string;
} | null;
/**
 * Resolve a stable room key for compatibility endpoints so manual testing can
 * keep conversation memory when the client provides an identifier.
 *
 * We accept a few common fields without requiring any one client:
 * - OpenAI: body.user (string)
 * - OpenAI: body.metadata.conversation_id
 * - Anthropic: body.metadata.user_id
 * - Anthropic: body.metadata.conversation_id
 */
export declare function resolveCompatRoomKey(body: Record<string, unknown>, fallback?: string): string;
/**
 * Maximum client-supplied conversation-key length embedded verbatim in the
 * room-UUID derivation.
 */
export declare const COMPAT_ROOM_KEY_MAX_LENGTH = 120;
/**
 * Scope a resolved conversation key for the room-UUID derivation without
 * aliasing distinct conversations onto one room.
 *
 * The derivation hashes whatever string it receives, so truncating a longer
 * key to {@link COMPAT_ROOM_KEY_MAX_LENGTH} made any two identifiers sharing a
 * 120-char prefix — JWT-style ids, path-like conversation keys — derive the
 * same roomId and silently share one conversation's memory. Keys within the
 * limit keep their exact historical derivation; longer keys are prefixed with
 * the complete SHA-256 digest of the full key, giving the room derivation a
 * collision-resistant scope. Rooms created before this fix from a >120-char
 * key are not reachable under the new derivation by design: they were already
 * merged with any prefix-sharing sibling.
 */
export declare function scopeCompatRoomKey(rawKey: string): string;
