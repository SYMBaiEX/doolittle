/** Host-owned runtime mode and transient stream settings. */
import type http from "node:http";
export declare function handleHostSettingsRoutes(req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string): Promise<boolean>;
