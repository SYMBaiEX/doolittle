/**
 * Audio PII redaction — execution ops (#14807).
 *
 * Turns merged redaction windows (`@elizaos/core`) into
 * redacted audio bytes with the DURATION PRESERVED, so every transcript word
 * anchor stays valid against the redacted variant:
 *
 *  - **Pure-TS WAV lane** (always available, all platforms): PCM16 sample
 *    zeroing (mute) or in-place 1 kHz sine synthesis (bleep) over the span
 *    windows. Byte length and sample count are untouched, so the duration is
 *    preserved EXACTLY and the output is bit-deterministic — the idempotency
 *    property (same input sha + spans ⇒ same output sha) holds by
 *    construction. The voice pipeline's native capture format is 16 kHz mono
 *    PCM16 WAV, so this lane needs no ffmpeg at all.
 *  - **ffmpeg lane** (desktop/server only — iOS/Android/workers have no
 *    ffmpeg, see `MOBILE_PLATFORM_VALUES` in core's runtime-env): lossy
 *    containers (ogg/opus, m4a/aac, mp3, webm) via the empirically verified
 *    filtergraphs — `volume=0:enable='between(t,S,E)+…'` for mute,
 *    `sine=f=1000` + `amix=duration=first:normalize=0` for bleep — run with
 *    `-bitexact` so the output bytes are deterministic for a given ffmpeg
 *    build. Measured on ffmpeg 8.1.1: WAV exact duration + −91 dB true
 *    silence in the window, OGG/opus exact, M4A/AAC up to one trailing
 *    encoder frame (assert with ±(1024/sampleRate)s tolerance). The sample
 *    count within the stream never changes, so span coordinates stay valid.
 *
 * Missing capability is OBSERVABLE, never silent: redacting a lossy container
 * with no ffmpeg on the host throws a typed `AUDIO_REDACTION_UNSUPPORTED`
 * error (WAV keeps working via the pure-TS lane), and any post-redaction
 * duration drift beyond the per-container tolerance throws
 * `AUDIO_REDACTION_DURATION_DRIFT` instead of storing a variant whose anchors
 * would lie. The ffmpeg/ffprobe child is timed and stdio-capped so a hung
 * binary cannot pin the agent process.
 */
import { type AudioRedactionSpan } from "@elizaos/core";
/** How a window is made inaudible. */
export type AudioRedactionMode = "mute" | "bleep";
/** Bleep tone frequency (both lanes use the same tone). */
export declare const BLEEP_FREQUENCY_HZ = 1000;
/** Bleep amplitude on the pure-TS lane (fraction of full scale). */
export declare const BLEEP_AMPLITUDE = 0.25;
/** AAC encodes in 1024-sample frames; M4A may carry one extra trailing frame. */
export declare const AAC_FRAME_SAMPLES = 1024;
/**
 * Locate ffmpeg: `ELIZA_FFMPEG_PATH` override, else PATH probe (same pattern
 * as the mic recorder resolution in plugin-local-inference). Cached; pass
 * `refresh` to re-probe (tests toggle the env override).
 */
export declare function resolveFfmpegPath(refresh?: boolean): string | null;
/** Locate ffprobe (ships beside ffmpeg; needed to probe lossy containers). */
export declare function resolveFfprobePath(refresh?: boolean): string | null;
/** What this host can redact. WAV/PCM16 always works; lossy needs ffmpeg. */
export interface AudioRedactionCapability {
    /** Pure-TS PCM16 WAV lane — available on every runtime. */
    wavPcm16: true;
    /** Lossy-container lane — requires ffmpeg + ffprobe on the host. */
    lossyContainers: boolean;
    ffmpegPath: string | null;
    ffprobePath: string | null;
}
/** Probe the host's redaction capability (desktop/server has ffmpeg; mobile
 *  and workers do not — their lossy redaction fails typed, never silently). */
export declare function audioRedactionCapability(): AudioRedactionCapability;
/** Parsed PCM16 WAV geometry (throws typed on anything else). */
export interface WavPcm16Info {
    sampleRate: number;
    channels: number;
    /** Byte offset of the first sample in the `data` chunk. */
    dataOffset: number;
    /** Byte length of the `data` chunk. */
    dataBytes: number;
    /** Samples per channel. */
    frameCount: number;
    durationMs: number;
}
/**
 * Strict RIFF/WAVE parse for 16-bit PCM (format tag 1, or EXTENSIBLE with the
 * PCM subformat). Walks the chunk list, so files with LIST/fact chunks parse.
 * Anything else throws `AUDIO_REDACTION_INPUT_INVALID` — the caller may fall
 * back to the ffmpeg lane when the host has one.
 */
export declare function parseWavPcm16(bytes: Buffer): WavPcm16Info;
/**
 * Redact a PCM16 WAV entirely in TypeScript: samples inside each window are
 * zeroed (mute) or replaced with a {@link BLEEP_FREQUENCY_HZ} sine (bleep) on
 * every channel. The buffer geometry is untouched — byte length, sample
 * count, and therefore duration are preserved EXACTLY, and the output is
 * bit-deterministic (the sine phase is anchored to the absolute frame index).
 */
export declare function redactWavPcm16(bytes: Buffer, spans: readonly AudioRedactionSpan[], mode: AudioRedactionMode): Buffer;
/** Probed stream geometry of an audio file. */
export interface ProbedAudio {
    durationMs: number;
    sampleRate: number;
    channels: number;
}
/** Probe duration/rate/channels with ffprobe (throws typed on failure). */
export declare function probeAudioFile(filePath: string): Promise<ProbedAudio>;
/**
 * Allowed |output − input| duration drift for a container. WAV and ogg/opus
 * re-encode to the exact duration (measured); frame-padded encoders (AAC in
 * m4a/mp4, mp3) may append up to one encoder frame — ±(1024/sampleRate)s per
 * the issue's empirical matrix — plus 2 ms of ffprobe float slack.
 */
export declare function durationToleranceMs(ext: string, sampleRate: number): number;
/** Assert the redacted variant kept the original duration (throws typed). */
export declare function assertDurationPreserved(inputDurationMs: number, outputDurationMs: number, ext: string, sampleRate: number): void;
/** Request for {@link redactAudioBytes}. */
export interface RedactAudioRequest {
    /** Original audio bytes (from the content-addressed media store). */
    bytes: Buffer;
    /** Container extension (`wav`, `ogg`, `m4a`, …) — the store's file ext. */
    containerExt: string;
    /** Merged, non-overlapping windows from the span-merge module. */
    spans: readonly AudioRedactionSpan[];
    mode: AudioRedactionMode;
}
/** Result of one redaction op. */
export interface RedactAudioResult {
    bytes: Buffer;
    lane: "pure-ts-wav" | "ffmpeg";
    inputDurationMs: number;
    outputDurationMs: number;
    containerExt: string;
    sampleRate: number;
}
/**
 * Redact the given audio: PCM16 WAV rides the pure-TS lane (deterministic,
 * duration byte-exact, works on every runtime); everything else rides ffmpeg
 * when the host has it and throws `AUDIO_REDACTION_UNSUPPORTED` when it does
 * not (mobile/workers) — observable, never a silent skip. Every path asserts
 * the duration-preservation contract before returning bytes.
 */
export declare function redactAudioBytes(request: RedactAudioRequest): Promise<RedactAudioResult>;
