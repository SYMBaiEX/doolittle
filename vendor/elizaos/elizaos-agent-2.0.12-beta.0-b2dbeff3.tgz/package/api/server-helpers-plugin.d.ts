/**
 * Plugin config/form helpers extracted from server.ts.
 */
import type { ServerState } from "./server-types.js";
export declare function resolvePluginConfigReply(prompt: string, _state: Pick<ServerState, "config" | "runtime">): Promise<string | null>;
export interface PluginConfigMutationRejection {
    field: string;
    message: string;
}
export declare function resolvePluginConfigMutationRejections(pluginParams: Array<{
    key: string;
}>, config: Record<string, unknown>): PluginConfigMutationRejection[];
