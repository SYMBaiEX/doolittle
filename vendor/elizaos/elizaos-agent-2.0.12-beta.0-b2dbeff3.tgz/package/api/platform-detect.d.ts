/**
 * Server-side platform detection for the agent HTTP server.
 *
 * Used by view routes and plugin-install guards to decide whether dynamic
 * code loading is permitted. iOS App Store and Google Play builds prohibit
 * fetching and executing remote JavaScript at runtime.
 */
import type { IncomingMessage } from "node:http";
export type AgentPlatform = "web" | "desktop" | "ios" | "android";
/**
 * Detect the client platform from the incoming HTTP request.
 *
 * Resolution order:
 * 1. `X-Eliza-Platform` header — set by native Capacitor shells.
 * 2. `User-Agent` — Capacitor injects platform markers; Electrobun sets its own.
 * 3. Default: "web".
 */
export declare function detectClientPlatform(req: IncomingMessage): AgentPlatform;
/**
 * Returns true when the platform allows dynamic JS loading at runtime.
 *
 * iOS App Store and Google Play policies prohibit apps from downloading and
 * executing JavaScript not bundled with the binary at submission time.
 */
export declare function isDynamicLoadingAllowed(platform: AgentPlatform): boolean;
