/**
 * MCP server configuration validation helpers extracted from server.ts.
 */
import { validateMcpServerConfig } from "@elizaos/core";
import { readAliasedEnv } from "@elizaos/host/protocol";
import { hasBlockedObjectKeyDeep } from "./blocked-object-keys.js";
import { resolveTerminalRunRejection, } from "./server-helpers-auth.js";
import { isBlockedObjectKey } from "./server-helpers-config.js";
export async function resolveMcpServersRejection(servers) {
    for (const [serverName, serverConfig] of Object.entries(servers)) {
        if (isBlockedObjectKey(serverName)) {
            return `Invalid server name: "${serverName}"`;
        }
        if (!serverConfig ||
            typeof serverConfig !== "object" ||
            Array.isArray(serverConfig)) {
            return `Server "${serverName}" config must be a JSON object`;
        }
        if (hasBlockedObjectKeyDeep(serverConfig)) {
            return `Server "${serverName}" contains blocked object keys`;
        }
        const configError = await validateMcpServerConfig(serverConfig);
        if (configError) {
            return `Server "${serverName}": ${configError}`;
        }
    }
    return null;
}
export function mcpServersIncludeStdio(servers) {
    return Object.values(servers).some((serverConfig) => {
        if (!serverConfig ||
            typeof serverConfig !== "object" ||
            Array.isArray(serverConfig)) {
            return false;
        }
        return serverConfig.type === "stdio";
    });
}
/**
 * Stdio MCP config writes can reach child_process.spawn. By default require
 * ELIZA_TERMINAL_RUN_TOKEN; set ELIZA_ALLOW_UNAUTHENTICATED_STDIO_MCP=1 only
 * for intentional local dev (legacy compat passthrough).
 */
export function resolveMcpTerminalAuthorizationRejection(req, servers, body) {
    if (!mcpServersIncludeStdio(servers)) {
        return null;
    }
    if (process.env.ELIZA_ALLOW_UNAUTHENTICATED_STDIO_MCP === "1") {
        return resolveTerminalRunRejection(req, body);
    }
    const expected = readAliasedEnv("ELIZA_TERMINAL_RUN_TOKEN");
    if (!expected) {
        return {
            status: 403,
            reason: "Stdio MCP server configuration requires ELIZA_TERMINAL_RUN_TOKEN. " +
                "Set ELIZA_ALLOW_UNAUTHENTICATED_STDIO_MCP=1 only for intentional local development.",
        };
    }
    return resolveTerminalRunRejection(req, body);
}
