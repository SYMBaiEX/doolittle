export { deriveEvmAddress, deriveSolanaAddress, generateWalletForChain, generateWalletKeys, setSolanaWalletEnv, syncSolanaPublicKeyEnv, } from "./wallet-keygen.js";
import type { KeyValidationResult, SolanaTokenBalance, WalletAddresses, WalletChain, WalletImportResult } from "@elizaos/contracts";
export type { BscTradeExecuteRequest, BscTradeExecuteResponse, BscTradeExecutionResult, BscTradePreflightRequest, BscTradePreflightResponse, BscTradeQuoteRequest, BscTradeQuoteResponse, BscTradeSide, BscTradeTxStatus, BscTradeTxStatusResponse, BscTransferExecuteRequest, BscTransferExecuteResponse, BscTransferExecutionResult, BscUnsignedApprovalTx, BscUnsignedTradeTx, BscUnsignedTransferTx, EvmChainBalance, EvmTokenBalance, KeyValidationResult, SolanaTokenBalance, TradePermissionMode, WalletAddresses, WalletBalancesResponse, WalletChain, WalletConfigStatus, WalletGenerateResult, WalletImportResult, WalletKeys, WalletTradeLedgerEntry, WalletTradeSource, WalletTradingProfileResponse, WalletTradingProfileSourceFilter, WalletTradingProfileWindow, } from "@elizaos/contracts";
export { computeValueUsd, DEX_PRICE_TIMEOUT_MS, DEXPAPRIKA_CHAIN_MAP, DEXSCREENER_CHAIN_MAP, type DexScreenerPair, type DexTokenMeta, fetchDexPaprikaPrices, fetchDexPrices, fetchDexScreenerPrices, WRAPPED_NATIVE, } from "@elizaos/plugin-wallet/read";
export { type AnkrTokenAsset, DEFAULT_EVM_CHAINS, type EvmProviderKeys, fetchEvmBalances, resolveEvmProviderKeys, } from "./wallet-evm-balance.js";
export declare const MANAGED_EVM_ADDRESS_ENV_KEY = "ELIZA_MANAGED_EVM_ADDRESS";
export declare const MANAGED_SOLANA_ADDRESS_ENV_KEY = "ELIZA_MANAGED_SOLANA_ADDRESS";
export declare const CLOUD_EVM_ADDRESS_ENV_KEY = "ELIZA_CLOUD_EVM_ADDRESS";
export declare const CLOUD_SOLANA_ADDRESS_ENV_KEY = "ELIZA_CLOUD_SOLANA_ADDRESS";
export declare const WALLET_SOURCE_EVM_ENV_KEY = "WALLET_SOURCE_EVM";
export declare const WALLET_SOURCE_SOLANA_ENV_KEY = "WALLET_SOURCE_SOLANA";
/** Ownership token for one constructed runtime's public-address cache writes. */
export interface AgentWalletAddressCacheSession {
    readonly agentId: string;
    readonly generation: symbol;
    readonly activation: "active" | "deferred";
}
/**
 * Start and immediately activate an empty public-address cache generation for
 * a cold runtime. This also invalidates any pending build for the same agent.
 */
export declare function beginAgentWalletAddressCacheSession(agentId: string): AgentWalletAddressCacheSession;
/**
 * Start a replacement runtime's private cache generation without changing the
 * incumbent's active addresses. A newer pending build supersedes the previous
 * one for the same agent.
 */
export declare function beginDeferredAgentWalletAddressCacheSession(agentId: string): AgentWalletAddressCacheSession;
/** Atomically promote the current pending generation and its staged addresses. */
export declare function activateAgentWalletAddressCacheSession(session: AgentWalletAddressCacheSession): boolean;
/** Abandon the current pending generation without changing the incumbent. */
export declare function abandonAgentWalletAddressCacheSession(session: AgentWalletAddressCacheSession): boolean;
/**
 * Publish one agent's public wallet identities to read-only wallet surfaces.
 * Private keys remain in the vault; this cache contains addresses only and
 * therefore does not require the opt-in process-env signing bridge. Returns
 * false without mutation when a replacement runtime has superseded the session.
 */
export declare function cacheAgentWalletAddresses(session: AgentWalletAddressCacheSession, addresses: WalletAddresses): boolean;
export declare function validateEvmPrivateKey(key: string): KeyValidationResult;
export declare function validateSolanaPrivateKey(key: string): KeyValidationResult;
/** Auto-detect chain from key format and validate. */
export declare function validatePrivateKey(key: string): KeyValidationResult;
/** Mask a secret string for safe display (e.g. logs, UI). */
export declare function maskSecret(value: string): string;
/** Validate key, store in process.env. Caller persists to config if needed. */
export declare function importWallet(chain: WalletChain, privateKey: string): WalletImportResult;
export declare const STEWARD_EVM_ADDRESS_ENV_KEY = "STEWARD_EVM_ADDRESS";
export declare const STEWARD_SOLANA_ADDRESS_ENV_KEY = "STEWARD_SOLANA_ADDRESS";
/**
 * Initialise the steward wallet address cache.
 *
 * Call once during server startup.  Fetches addresses from the steward API
 * and writes them to `process.env.STEWARD_EVM_ADDRESS` /
 * `process.env.STEWARD_SOLANA_ADDRESS` so the synchronous
 * `getWalletAddresses()` can use them without hitting the network.
 */
export declare function initStewardWalletCache(): Promise<void>;
/**
 * Derive addresses from env keys.  Works without a running runtime.
 *
 * Resolution order (steward-first):
 *   1. Steward cached addresses  (`STEWARD_EVM_ADDRESS` / `STEWARD_SOLANA_ADDRESS`)
 *   2. Local private key derivation  (`EVM_PRIVATE_KEY` / `SOLANA_PRIVATE_KEY`)
 *   3. The requested agent's public addresses (vault-backed; no private-key export)
 *   4. Managed address env vars  (`ELIZA_MANAGED_EVM_ADDRESS` / `ELIZA_MANAGED_SOLANA_ADDRESS`)
 *
 * Calls without an agent id intentionally skip the agent cache. Environment
 * and source-selected wallets retain their legacy process-wide behavior, but
 * an unscoped caller must never inherit whichever runtime bootstrapped last.
 */
export declare function getWalletAddresses(agentId?: string | null): WalletAddresses;
/**
 * Extended wallet addresses including steward-managed wallets.
 * Calls steward API (async) to discover additional addresses.
 * Key-derived addresses are always preferred; steward addresses fill gaps.
 */
export declare function getWalletAddressesWithSteward(runtimeAgentId?: string | null): Promise<WalletAddresses & {
    stewardEvmAddress?: string | null;
    stewardSolanaAddress?: string | null;
}>;
export declare function fetchSolanaBalances(address: string, heliusKey: string): Promise<{
    solBalance: string;
    solValueUsd: string;
    tokens: SolanaTokenBalance[];
}>;
export declare function fetchSolanaNativeBalanceViaRpc(address: string, rpcUrls: string[]): Promise<{
    solBalance: string;
    solValueUsd: string;
    tokens: SolanaTokenBalance[];
}>;
