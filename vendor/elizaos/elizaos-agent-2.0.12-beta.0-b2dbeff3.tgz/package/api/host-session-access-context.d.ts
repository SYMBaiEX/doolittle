/** Carries a verified host session into plugin disclosure checks without promoting guest sessions to owner authority. */
import { type AccessContext, type IAgentRuntime } from "@elizaos/core";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
export declare function resolveHostSessionAccessContext(authorization: AgentHttpRequestAuthorization, runtime: IAgentRuntime): AccessContext | undefined;
