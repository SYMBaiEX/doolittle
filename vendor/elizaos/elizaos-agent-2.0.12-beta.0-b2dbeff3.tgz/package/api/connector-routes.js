import { PostConnectorRequestSchema } from "@elizaos/contracts";
import { CONNECTOR_ENV_MAP } from "../config/env-vars.js";
function getConfiguredConnectorsFromEnv() {
    const configured = {};
    for (const [connectorName, envMap] of Object.entries(CONNECTOR_ENV_MAP)) {
        const envKeys = new Set(Object.values(envMap));
        if (connectorName === "discord") {
            envKeys.add("DISCORD_BOT_TOKEN");
        }
        const hasAnyEnvValue = [...envKeys].some((envKey) => {
            const value = process.env[envKey];
            return typeof value === "string" && value.trim().length > 0;
        });
        if (hasAnyEnvValue) {
            configured[connectorName] = {
                enabled: true,
                configuredViaEnv: true,
            };
        }
    }
    return configured;
}
function listVisibleConnectors(config) {
    const rawConnectors = config.connectors ??
        config.channels ??
        {};
    const visibleConnectors = rawConnectors &&
        typeof rawConnectors === "object" &&
        !Array.isArray(rawConnectors)
        ? { ...rawConnectors }
        : {};
    for (const [connectorName, summary] of Object.entries(getConfiguredConnectorsFromEnv())) {
        if (!(connectorName in visibleConnectors)) {
            visibleConnectors[connectorName] = summary;
        }
    }
    return visibleConnectors;
}
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
export async function handleConnectorRoutes(ctx) {
    const { req, res, method, pathname, state, json, error, readJsonBody, saveElizaConfig, redactConfigSecrets, isBlockedObjectKey, hasBlockedObjectKeyDeep, cloneWithoutBlockedObjectKeys, onConnectorDisconnect, } = ctx;
    // ── GET /api/connectors ──────────────────────────────────────────────
    if (method === "GET" && pathname === "/api/connectors") {
        json(res, {
            connectors: redactConfigSecrets(listVisibleConnectors(state.config)),
        });
        return true;
    }
    // ── POST /api/connectors ─────────────────────────────────────────────
    if (method === "POST" && pathname === "/api/connectors") {
        const rawBody = await readJsonBody(req, res);
        if (rawBody === null)
            return true;
        const parsed = PostConnectorRequestSchema.safeParse(rawBody);
        if (!parsed.success) {
            error(res, parsed.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const { name: connectorName, config } = parsed.data;
        if (hasBlockedObjectKeyDeep(config)) {
            error(res, "Connector config contains a blocked object key", 400);
            return true;
        }
        // Clone before mutating live config. The guard and clone deliberately use
        // separate bounded walks, so an in-process proxy can still change between
        // them; a clone failure must leave the live map untouched.
        const sanitizedConfig = cloneWithoutBlockedObjectKeys(config);
        const previousConnectors = state.config.connectors;
        const previousConnector = previousConnectors?.[connectorName];
        if (!state.config.connectors)
            state.config.connectors = {};
        state.config.connectors[connectorName] = sanitizedConfig;
        try {
            saveElizaConfig(state.config);
        }
        catch (err) {
            if (previousConnectors === undefined) {
                delete state.config.connectors;
            }
            else if (previousConnector === undefined) {
                delete state.config.connectors[connectorName];
            }
            else {
                state.config.connectors[connectorName] = previousConnector;
            }
            error(res, err instanceof Error
                ? `Failed to save connector config: ${err.message}`
                : "Failed to save connector config", 500);
            return true;
        }
        // Treat this POST as a disconnect only when the incoming payload explicitly
        // sets `enabled: false`. Inspecting the post-write config value instead
        // would fire on every config-only update that omits `enabled` while the
        // connector is active, wrongly purging live connectors.
        const isDisconnect = config.enabled === false;
        if (isDisconnect) {
            if (onConnectorDisconnect) {
                try {
                    await onConnectorDisconnect(connectorName);
                }
                catch (err) {
                    // error-policy:#14415 — host cache-invalidation callback failed; report
                    // rather than swallow so the stale-cache risk is observable.
                    state.runtime?.reportError("connector.disconnect.hostCallback", err, {
                        connector: connectorName,
                        op: "POST-disconnect",
                    });
                }
            }
        }
        json(res, {
            connectors: redactConfigSecrets(state.config.connectors),
        });
        return true;
    }
    // ── DELETE /api/connectors/:name ─────────────────────────────────────
    if (method === "DELETE" && pathname.startsWith("/api/connectors/")) {
        const rawName = pathname.slice("/api/connectors/".length);
        if (rawName.includes("/")) {
            return false;
        }
        let name;
        try {
            name = decodeURIComponent(rawName);
        }
        catch {
            // error-policy:J3 untrusted-input sanitizing — malformed percent-encoding is invalid client input
            error(res, "Invalid connector name encoding", 400);
            return true;
        }
        if (!name || isBlockedObjectKey(name)) {
            error(res, "Missing or invalid connector name", 400);
            return true;
        }
        const previousConnector = state.config.connectors && Object.hasOwn(state.config.connectors, name)
            ? state.config.connectors[name]
            : undefined;
        if (previousConnector !== undefined)
            delete state.config.connectors?.[name];
        const stateConfigRecord = state.config;
        const channels = stateConfigRecord.channels &&
            typeof stateConfigRecord.channels === "object"
            ? stateConfigRecord.channels
            : undefined;
        const previousChannel = channels && Object.hasOwn(channels, name) ? channels[name] : undefined;
        if (channels && previousChannel !== undefined) {
            delete channels[name];
        }
        try {
            saveElizaConfig(state.config);
        }
        catch (err) {
            if (previousConnector !== undefined && state.config.connectors) {
                state.config.connectors[name] = previousConnector;
            }
            if (previousChannel !== undefined && channels) {
                channels[name] = previousChannel;
            }
            error(res, err instanceof Error
                ? `Failed to save connector config: ${err.message}`
                : "Failed to save connector config", 500);
            return true;
        }
        if (onConnectorDisconnect) {
            try {
                await onConnectorDisconnect(name);
            }
            catch (err) {
                // error-policy:#14415 — host cache-invalidation callback failed; report.
                state.runtime?.reportError("connector.disconnect.hostCallback", err, {
                    connector: name,
                    op: "DELETE",
                });
            }
        }
        json(res, {
            connectors: redactConfigSecrets((state.config.connectors ?? {})),
        });
        return true;
    }
    return false;
}
