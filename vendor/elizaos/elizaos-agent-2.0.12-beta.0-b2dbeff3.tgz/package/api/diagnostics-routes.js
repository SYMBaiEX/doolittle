import { PostLogExportRequestSchema } from "@elizaos/contracts";
import { parseClampedInteger } from "@elizaos/core";
function isAutonomyEvent(event) {
    return event.type === "agent_event" || event.type === "heartbeat_event";
}
function defaultInitSse(res) {
    res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
    });
}
function defaultWriteSseData(res, data, event) {
    if (event) {
        res.write(`event: ${event}\n`);
    }
    const safe = data.replace(/\r?\n/g, "\ndata: ");
    res.write(`data: ${safe}\n\n`);
}
function defaultWriteSseJson(res, payload, event) {
    defaultWriteSseData(res, JSON.stringify(payload), event);
}
function parseAuditSince(raw) {
    if (raw == null)
        return {};
    const trimmed = raw.trim();
    if (!trimmed || raw !== trimmed) {
        return {
            error: 'Invalid "since" filter: expected epoch ms or ISO timestamp.',
        };
    }
    // Canonical integer epoch only. Number("1e2") is 100 and Number("Infinity")
    // is Infinity — both used to silently filter the live log viewer (or empty
    // it) instead of rejecting the cursor.
    if (/^-?(0|[1-9]\d*)$/.test(trimmed)) {
        const numeric = Number(trimmed);
        if (Number.isSafeInteger(numeric)) {
            return { value: numeric };
        }
        return {
            error: 'Invalid "since" filter: expected epoch ms or ISO timestamp.',
        };
    }
    // Date.parse("007") / Date.parse("1.5") are implementation-defined and
    // must not become a silent cursor. Only ISO-shaped timestamps fall through.
    if (!/^\d{4}-\d{2}-\d{2}(?:[T\s].*)?$/.test(trimmed)) {
        return {
            error: 'Invalid "since" filter: expected epoch ms or ISO timestamp.',
        };
    }
    const parsed = Date.parse(trimmed);
    if (!Number.isFinite(parsed)) {
        return {
            error: 'Invalid "since" filter: expected epoch ms or ISO timestamp.',
        };
    }
    return { value: parsed };
}
function isTruthyQueryParam(value) {
    if (!value)
        return false;
    const normalized = value.trim().toLowerCase();
    return (normalized === "1" ||
        normalized === "true" ||
        normalized === "yes" ||
        normalized === "on");
}
function applyLogFilter(buffer, filter) {
    let entries = buffer;
    const { source, level, tag, sinceMs } = filter;
    if (source) {
        entries = entries.filter((entry) => entry.source === source);
    }
    if (level) {
        entries = entries.filter((entry) => entry.level === level);
    }
    if (tag) {
        entries = entries.filter((entry) => entry.tags.includes(tag));
    }
    if (sinceMs !== undefined) {
        entries = entries.filter((entry) => entry.timestamp >= sinceMs);
    }
    return entries.slice();
}
function csvEscape(value) {
    if (/[",\n\r]/.test(value)) {
        return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
}
function logsToCsv(entries) {
    const header = "timestamp,level,source,tags,message";
    const lines = entries.map((entry) => {
        const message = typeof entry.message === "string" ? entry.message : "";
        return [
            new Date(entry.timestamp).toISOString(),
            entry.level,
            entry.source,
            entry.tags.join("|"),
            message,
        ]
            .map((field) => csvEscape(String(field)))
            .join(",");
    });
    return [header, ...lines].join("\n");
}
function matchesAuditFilter(entry, filters) {
    if (filters.type && entry.type !== filters.type)
        return false;
    if (filters.severity && entry.severity !== filters.severity)
        return false;
    if (filters.sinceMs !== undefined &&
        Date.parse(entry.timestamp) < filters.sinceMs) {
        return false;
    }
    return true;
}
export async function handleDiagnosticsRoutes(ctx) {
    const { req, res, method, pathname, url, logBuffer, eventBuffer, initSse, writeSseJson, auditEventTypes, auditSeverities, getAuditFeedSize, queryAuditFeed, subscribeAuditFeed, json, } = ctx;
    if (method === "GET" && pathname === "/api/logs") {
        const sinceRaw = url.searchParams.get("since");
        let sinceMs;
        if (sinceRaw) {
            const sinceFilter = parseAuditSince(sinceRaw);
            if (sinceFilter.error) {
                json(res, { error: sinceFilter.error }, 400);
                return true;
            }
            sinceMs = sinceFilter.value;
        }
        const entries = applyLogFilter(logBuffer, {
            source: url.searchParams.get("source") ?? undefined,
            level: url.searchParams.get("level") ?? undefined,
            tag: url.searchParams.get("tag") ?? undefined,
            sinceMs,
        });
        const sources = [...new Set(logBuffer.map((entry) => entry.source))].sort();
        const tags = [...new Set(logBuffer.flatMap((entry) => entry.tags))].sort();
        json(res, { entries, sources, tags });
        return true;
    }
    if (method === "DELETE" && pathname === "/api/logs") {
        const cleared = ctx.clearLogBuffer
            ? ctx.clearLogBuffer()
            : (() => {
                const previous = logBuffer.length;
                logBuffer.length = 0;
                return previous;
            })();
        json(res, { cleared });
        return true;
    }
    if (method === "POST" && pathname === "/api/logs/export") {
        const errorFn = ctx.error;
        if (!ctx.readJsonBody || !errorFn) {
            json(res, { error: "Log export requires JSON body support" }, 500);
            return true;
        }
        const rawExp = await ctx.readJsonBody(req, res);
        if (rawExp === null)
            return true;
        const parsedExp = PostLogExportRequestSchema.safeParse(rawExp);
        if (!parsedExp.success) {
            errorFn(res, parsedExp.error.issues[0]?.message ?? 'format must be "json" or "csv"', 400);
            return true;
        }
        const body = parsedExp.data;
        const formatRaw = body.format;
        let sinceMs;
        if (typeof body.since === "string" && body.since.trim()) {
            const sinceFilter = parseAuditSince(body.since);
            if (sinceFilter.error) {
                errorFn(res, sinceFilter.error, 400);
                return true;
            }
            sinceMs = sinceFilter.value;
        }
        else if (typeof body.since === "number") {
            if (!Number.isSafeInteger(body.since)) {
                errorFn(res, 'Invalid "since" filter: expected epoch ms or ISO timestamp.', 400);
                return true;
            }
            sinceMs = body.since;
        }
        let tag;
        if (Array.isArray(body.tags)) {
            const first = body.tags.find((entry) => typeof entry === "string" && entry.trim().length > 0);
            if (first)
                tag = first.trim();
        }
        else if (typeof body.tags === "string" && body.tags.trim()) {
            tag = body.tags.trim();
        }
        let entries = applyLogFilter(logBuffer, {
            source: typeof body.source === "string" && body.source.trim()
                ? body.source.trim()
                : undefined,
            level: typeof body.level === "string" && body.level.trim()
                ? body.level.trim()
                : undefined,
            tag,
            sinceMs,
        });
        if (typeof body.limit === "number" && Number.isFinite(body.limit)) {
            const cap = Math.max(1, Math.min(10000, Math.floor(body.limit)));
            entries = entries.slice(-cap);
        }
        const stamp = new Date().toISOString().replace(/[:.]/g, "-");
        if (formatRaw === "json") {
            const payload = JSON.stringify({ entries }, null, 2);
            res.writeHead(200, {
                "Content-Type": "application/json; charset=utf-8",
                "Content-Disposition": `attachment; filename="logs-${stamp}.json"`,
                "Content-Length": Buffer.byteLength(payload, "utf-8"),
            });
            res.end(payload);
            return true;
        }
        const csv = logsToCsv(entries);
        res.writeHead(200, {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": `attachment; filename="logs-${stamp}.csv"`,
            "Content-Length": Buffer.byteLength(csv, "utf-8"),
        });
        res.end(csv);
        return true;
    }
    if (method === "GET" && pathname === "/api/agent/events") {
        const limit = parseClampedInteger(url.searchParams.get("limit"), {
            min: 1,
            max: 1000,
            fallback: 200,
        });
        const runIdFilter = url.searchParams.get("runId");
        const fromSeqRaw = url.searchParams.get("fromSeq");
        const fromSeq = parseClampedInteger(fromSeqRaw, {
            min: 0,
        });
        if (fromSeqRaw !== null && fromSeq === undefined) {
            json(res, { error: 'Invalid "fromSeq" filter.' }, 400);
            return true;
        }
        const afterEventId = url.searchParams.get("after");
        let autonomyEvents = eventBuffer.filter(isAutonomyEvent);
        if (runIdFilter) {
            autonomyEvents = autonomyEvents.filter((event) => event.runId === runIdFilter);
        }
        if (fromSeq !== undefined) {
            autonomyEvents = autonomyEvents.filter((event) => typeof event.seq === "number" && event.seq >= fromSeq);
        }
        let startIndex = 0;
        if (afterEventId) {
            const index = autonomyEvents.findIndex((event) => event.eventId === afterEventId);
            if (index >= 0) {
                startIndex = index + 1;
            }
        }
        const events = autonomyEvents.slice(startIndex, startIndex + limit);
        const latestEventId = events.length > 0 ? events[events.length - 1].eventId : null;
        json(res, {
            events,
            latestEventId,
            totalBuffered: autonomyEvents.length,
            replayed: true,
        });
        return true;
    }
    if (method === "GET" && pathname === "/api/security/audit") {
        const typeFilterRaw = url.searchParams.get("type");
        const severityFilterRaw = url.searchParams.get("severity");
        const limitFilter = parseClampedInteger(url.searchParams.get("limit"), {
            min: 1,
            max: 1000,
            fallback: 200,
        });
        const sinceFilter = parseAuditSince(url.searchParams.get("since"));
        if (sinceFilter.error) {
            json(res, { error: sinceFilter.error }, 400);
            return true;
        }
        let typeFilter;
        if (typeFilterRaw) {
            const candidate = typeFilterRaw.trim();
            if (!auditEventTypes.includes(candidate)) {
                json(res, {
                    error: `Invalid "type" filter. Expected one of: ${auditEventTypes.join(", ")}`,
                }, 400);
                return true;
            }
            typeFilter = candidate;
        }
        let severityFilter;
        if (severityFilterRaw) {
            const candidate = severityFilterRaw.trim();
            if (!auditSeverities.includes(candidate)) {
                json(res, {
                    error: `Invalid "severity" filter. Expected one of: ${auditSeverities.join(", ")}`,
                }, 400);
                return true;
            }
            severityFilter = candidate;
        }
        const streamRequested = isTruthyQueryParam(url.searchParams.get("stream")) ||
            (req.headers.accept ?? "").includes("text/event-stream");
        const filter = {
            type: typeFilter,
            severity: severityFilter,
            sinceMs: sinceFilter.value,
        };
        if (!streamRequested) {
            const entries = queryAuditFeed({
                ...filter,
                limit: limitFilter,
            });
            json(res, {
                entries,
                totalBuffered: getAuditFeedSize(),
                replayed: true,
            });
            return true;
        }
        const startSse = initSse ?? defaultInitSse;
        const sendSseJson = writeSseJson ?? defaultWriteSseJson;
        startSse(res);
        sendSseJson(res, {
            type: "snapshot",
            entries: queryAuditFeed({ ...filter, limit: limitFilter }),
            totalBuffered: getAuditFeedSize(),
        });
        const unsubscribe = subscribeAuditFeed((entry) => {
            if (!matchesAuditFilter(entry, filter))
                return;
            sendSseJson(res, { type: "entry", entry });
        });
        let closed = false;
        const close = () => {
            if (closed)
                return;
            closed = true;
            unsubscribe();
            if (!res.writableEnded) {
                res.end();
            }
        };
        req.on("close", close);
        req.on("aborted", close);
        res.on("close", close);
        return true;
    }
    return false;
}
