/**
 * HTTP route handlers for the View Registry API.
 *
 * Mounted on the agent's HTTP server. Serves view metadata, compiled bundles,
 * and hero images contributed by plugins via `Plugin.views`.
 *
 * Routes:
 *   GET  /api/views                    — list all registered views (JSON)
 *   GET  /api/views/platform-info      — platform detection info (JSON)
 *   GET  /api/views/search?q=&limit=   — hybrid keyword+semantic ranked search (JSON)
 *   GET  /api/views/:id                — single view metadata (JSON)
 *   GET/HEAD /api/views/:id/installations/:lease/:type/:kind/:file — published view assets
 *   GET  /api/views/:id/hero           — hero image (image/*)
 *   POST /api/views/:id/navigate       — deliver a shell navigation event (JSON)
 *   POST /api/views/:id/elements       — report the view's addressable element snapshot
 *   POST /api/views/:id/interact       — agent-view interaction (capability dispatch)
 *   POST /api/views/interact-result    — frontend result callback (resolves pending interact)
 */
import { type IAgentRuntime, type RoleGateRole, type ViewType } from "@elizaos/core";
import type { RouteHelpers, RouteRequestMeta } from "@elizaos/host/protocol";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
import { type ViewClientScope } from "../runtime/view-client-context.js";
import { type RendererViewInteractResult } from "./view-interaction-host.js";
import type { ViewRegistryEntry } from "./view-registry-types.js";
/**
 * Parse the view-catalog `viewType` query. Omitted/empty keeps the historical
 * GUI default (`listViews` / `getView` treat undefined as gui). A known
 * modality selects that catalog. Any other token used to fall through to that
 * same GUI catalog, so `viewType=GUI` or `viewType=web` silently served GUI
 * views.
 */
export declare function parseViewTypeParam(value: string | null): {
    ok: true;
    viewType: ViewType | undefined;
} | {
    ok: false;
    message: string;
};
export declare function parseViewTypeValue(value: unknown): {
    ok: true;
    viewType: ViewType | undefined;
} | {
    ok: false;
    message: string;
};
export { getViewsBroadcastWs, getViewsBroadcastWsToClientId, setViewsBroadcastWs, } from "./view-interaction-host.js";
export interface CurrentViewState {
    /** Only a validated native switch acknowledgment may establish this history. */
    navigationConfirmation?: {
        ownerId: string;
        handoffId: string;
        installationId: string;
        /** Alias verified by the prepared route, never supplied by its ack. */
        resolvedAlias?: string;
        previousView?: {
            viewId: string;
            installationId: string;
            resolvedAlias?: string;
        };
    };
    viewId: string;
    viewPath: string | null;
    viewLabel: string;
    viewType: ViewType;
    action?: string;
    views?: string[];
    layout?: string;
    placement?: string;
    /**
     * Sub-section the view is focused on, when the view has addressable
     * sub-sections (Settings = its section id, e.g. "voice"). Carried so the
     * `current_view` provider can report the open subview and the agent can
     * deep-link one via the VIEWS action `subview` param.
     */
    subview?: string;
    /**
     * ISO timestamp of the navigate that *switched* into this view (distinct from
     * `updatedAt`, which also moves on same-view re-stamps). Read by the
     * `current_view` acknowledgement provider to know a switch *just happened*.
     */
    switchedAt?: string;
    /** Who initiated the switch: the agent (default) or the user clicking the UI. */
    source?: "agent" | "user";
    updatedAt: string;
}
/**
 * A view switch is treated as "just happened" for this long after navigate, so
 * the acknowledgement provider only references it on the turn(s) immediately
 * following the switch and never re-acknowledges a stale switch forever.
 */
export declare const VIEW_SWITCH_FRESH_MS = 15000;
/** True when `state` reflects a switch within {@link VIEW_SWITCH_FRESH_MS}. */
export declare function isViewSwitchFresh(state: CurrentViewState | null, now?: number): boolean;
export declare function getCurrentViewState(runtime: IAgentRuntime, scope?: ViewClientScope | undefined): CurrentViewState | null;
export declare function clearCurrentViewState(runtime: IAgentRuntime, scope?: ViewClientScope | undefined): void;
/**
 * Resolve a pending interact request from a WS `view:interact:result` message.
 * Called by the WebSocket message handler in server.ts.
 */
export declare function resolveViewInteractResult(runtime: IAgentRuntime, hostKey: object, clientId: string, result: RendererViewInteractResult): void;
export interface ViewsRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json" | "error"> {
    url: URL;
    hostKey: object;
    developerMode?: boolean;
    /** Broadcast an arbitrary payload to all connected WebSocket clients. */
    broadcastWs?: (payload: object) => void;
    /** Broadcast a payload only to WebSocket clients bound to one client id. */
    broadcastWsToClientId?: (clientId: string, payload: object) => number;
    /** Agent runtime — used by the semantic search endpoint. */
    runtime?: IAgentRuntime | null;
    callerAuthorization?: AgentHttpRequestAuthorization;
}
export declare function handleViewsRoutes(ctx: ViewsRouteContext): Promise<boolean>;
/**
 * Result of dispatching a capability to a view — the union of the two interact
 * paths (a `serverInteract` handler, or a frontend `view:interact` round-trip).
 */
export interface ViewInteractDispatchResult {
    requestId: string;
    success: boolean;
    result?: unknown;
    error?: string;
    failureKind?: "timeout" | "revoked" | "unavailable" | "unknown";
}
interface ViewInteractTransport {
    hostKey?: object;
    broadcastWs?: (payload: object) => void;
    broadcastWsToClientId?: (clientId: string, payload: object) => number;
    clientId?: string | null;
    runtime: IAgentRuntime;
    userRoles?: readonly RoleGateRole[];
    ownerId?: string;
}
/**
 * Dispatch a capability to a view, reusing the established interact semantics.
 * Standard and agent-surface capabilities prefer a mounted caller-targeted
 * frontend because those controls live in the rendered DOM. Nonstandard
 * declared capabilities prefer `serverInteract`. A mixed view falls back to
 * `serverInteract` when no targeted client is mounted, preserving headless
 * callers without sending mutating controls to every connected shell.
 * Shared by POST /:id/activate (CLICK_ELEMENT) and the view-scoped action
 * handler (view-scoped-actions.ts) so neither re-implements the dispatch.
 */
export declare function dispatchViewInteract(entry: ViewRegistryEntry, viewId: string, capability: string, params: Record<string, unknown> | undefined, transport: ViewInteractTransport, timeoutMs?: number): Promise<ViewInteractDispatchResult>;
