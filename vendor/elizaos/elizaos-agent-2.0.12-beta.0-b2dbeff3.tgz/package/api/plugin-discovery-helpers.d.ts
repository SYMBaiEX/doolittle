/**
 * Plugin discovery and categorization helpers.
 *
 * Handles reading the plugins.json manifest, categorizing plugins, building
 * parameter definitions, and aggregating secrets for the plugin management UI.
 */
import { type PluginParamDef } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
export { BLOCKED_ENV_KEY_PREFIXES, BLOCKED_ENV_KEYS, isBlockedEnvKey, } from "../config/blocked-env-keys.js";
import type { PluginEntry } from "./server-types.js";
export declare function getReleaseBundledPluginIds(): Set<string>;
export interface PluginIndexEntry {
    id: string;
    dirName?: string;
    name: string;
    npmName?: string;
    description: string;
    tags?: string[];
    category: "ai-provider" | "connector" | "streaming" | "database" | "app" | "feature";
    envKey: string | null;
    configKeys: string[];
    pluginParameters?: Record<string, Record<string, unknown>>;
    version?: string;
    pluginDeps?: string[];
    configUiHints?: Record<string, Record<string, unknown>>;
    logoUrl?: string;
    icon?: string;
    homepage?: string;
    repository?: string;
    setupGuideUrl?: string;
}
export interface PluginIndex {
    $schema: string;
    generatedAt: string;
    count: number;
    plugins: PluginIndexEntry[];
}
type NormalizedPluginParameter = {
    type: string;
    description: string;
    required: boolean;
    sensitive: boolean;
    default?: string;
    options?: string[];
};
type PluginPackageMetadata = {
    description?: string;
    homepage?: string;
    repository?: string;
    icon?: string | null;
    tags?: string[];
    configKeys?: string[];
    pluginParameters?: Record<string, NormalizedPluginParameter>;
    configUiHints?: Record<string, Record<string, unknown>>;
};
export declare function findPrimaryEnvKey(configKeys: string[]): string | null;
export declare function maskValue(value: string): string;
export declare function buildParamDefs(pluginParams: Record<string, Record<string, unknown>>): PluginParamDef[];
/** Derive a human-readable description from an environment variable key. */
export declare function inferDescription(key: string): string;
/** Extract the plugin/service prefix label from a key by removing a known suffix. */
export declare function prefixLabel(key: string, suffix: string): string;
/**
 * Top-level config keys accepted by `PUT /api/config`.
 * Keep this in sync with ElizaConfig root fields and include both modern and
 * legacy aliases (e.g. `connectors` + `channels`).
 */
export declare const CONFIG_WRITE_ALLOWED_TOP_KEYS: Set<string>;
/**
 * Stream names accepted by `POST /api/agent/event`.
 * Plugins emit events to these streams for the StreamView UI.
 */
export declare const AGENT_EVENT_ALLOWED_STREAMS: Set<string>;
export interface SecretEntry {
    key: string;
    description: string;
    category: string;
    sensitive: boolean;
    required: boolean;
    isSet: boolean;
    maskedValue: string | null;
    usedBy: Array<{
        pluginId: string;
        pluginName: string;
        enabled: boolean;
    }>;
}
export declare function inferSecretCategory(key: string): string;
export declare function aggregateSecrets(plugins: PluginEntry[]): SecretEntry[];
/**
 * Discover user-installed plugins from the Store (not bundled in the manifest).
 * Reads from config.plugins.installs and tries to enrich with package.json metadata.
 */
export declare function discoverInstalledPlugins(config: ElizaConfig, bundledIds: Set<string>): PluginEntry[];
/**
 * Discover available plugins from the bundled plugins.json manifest.
 * Falls back to filesystem scanning for monorepo development.
 */
export declare function discoverPluginsFromManifest(): PluginEntry[];
export declare function categorizePlugin(id: string): "ai-provider" | "connector" | "streaming" | "database" | "feature";
export declare function resolvePluginSetupGuideUrl(id: string): string | undefined;
export declare function normalizeRepositoryUrl(repository: string | {
    type?: string;
    url?: string;
} | null | undefined): string | undefined;
export declare function deriveElizaRepositoryUrl(npmName: string | undefined, dirName: string | undefined): string | undefined;
export declare function normalizePluginMetadataTag(tag: string): string | null;
export declare function normalizePluginMetadataTags(values: unknown): string[];
export declare function mergePluginMetadataTags(...sources: unknown[]): string[];
export declare function pluginIdTags(id: string): string[];
export declare function connectorMetadataTags(id: string): string[];
export declare function resolvePluginDescription(id: string, name: string, category: PluginEntry["category"], description: string | undefined): string;
export declare function resolvePluginTags(id: string, category: PluginEntry["category"], ...sources: unknown[]): string[];
export declare function formatPluginName(id: string): string;
export declare function readBundledPluginPackageMetadata(packageRoot: string, dirName: string | undefined, npmName?: string): PluginPackageMetadata;
