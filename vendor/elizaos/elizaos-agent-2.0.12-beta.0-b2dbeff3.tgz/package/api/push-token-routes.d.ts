/**
 * Push-token routes.
 *
 * HTTP surface for a device to register/unregister its remote-push token so the
 * server can deliver notifications via APNs/FCM while the app is
 * backgrounded/killed. Tokens are owned by the `NotificationPushService`'s
 * `PushTokenRegistry`.
 *
 * Routes (all under /api/notifications/push-tokens so they ride next to the
 * notification rail, but they are handled HERE, not by notification-routes):
 *
 *   POST   /api/notifications/push-tokens
 *     Register (upsert) a device token. Body: { platform: "ios"|"android",
 *     token: string }. Returns `{ ok: true, deliveryEnabled: boolean }`.
 *
 *   DELETE /api/notifications/push-tokens
 *     Unregister a device token from `{ token }`.
 *
 *   GET    /api/notifications/push-tokens
 *     Diagnostics: `{ count, platforms: { ios, android } }`.
 */
import type http from "node:http";
import type { RouteHelpers } from "@elizaos/host/protocol";
export interface PushTokenRouteState {
    runtime: {
        getService: (type: string) => unknown;
    } | null;
}
export declare function handlePushTokenRoute(req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: PushTokenRouteState, helpers: RouteHelpers): Promise<boolean>;
