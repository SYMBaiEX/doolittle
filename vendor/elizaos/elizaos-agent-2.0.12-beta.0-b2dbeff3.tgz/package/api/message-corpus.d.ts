import { ChannelType, type Memory, type UUID } from "@elizaos/core";
export interface MessageCorpusOptions {
    /** Number of conversations to generate. */
    conversationCount?: number;
    /** Messages per conversation (user/assistant alternating). */
    messagesPerConversation?: number;
    /** Months of history to spread conversation start times across. */
    spanMonths?: number;
    /** Derived owner facts written per conversation. */
    factsPerConversation?: number;
    /** RNG seed — same seed + now yields byte-identical text and timestamps. */
    seed?: number;
    /** Anchor timestamp (epoch ms) the span counts back from. */
    now?: number;
}
export interface GeneratedCorpusMessage {
    role: "user" | "assistant";
    text: string;
    createdAt: number;
}
export interface GeneratedCorpusConversation {
    title: string;
    topic: string;
    createdAt: number;
    messages: GeneratedCorpusMessage[];
    facts: Array<{
        text: string;
        createdAt: number;
    }>;
}
export interface GeneratedMessageCorpus {
    conversations: GeneratedCorpusConversation[];
    /** Distinctive per-topic keywords usable as demo search queries. */
    sampleQueries: string[];
    oldestMessageAt: number | null;
    newestMessageAt: number | null;
}
/**
 * Generate a deterministic backdated corpus. Conversation start times are
 * spread oldest-first across the span ending at `now`, so a span of 13+
 * months guarantees material on both sides of a "one year ago" boundary.
 */
export declare function generateMessageCorpus(options?: MessageCorpusOptions): GeneratedMessageCorpus;
/**
 * The narrow runtime surface the seeder writes through. `AgentRuntime`
 * satisfies it structurally; tests can drive it with a real runtime over an
 * in-memory adapter.
 */
export interface MessageCorpusRuntime {
    agentId: UUID;
    character: {
        name?: string;
    };
    ensureConnection(params: {
        entityId: UUID;
        roomId: UUID;
        roomName?: string;
        worldId?: UUID;
        userName?: string;
        source?: string;
        type?: ChannelType | string;
        channelId?: string;
        messageServerId?: UUID;
        metadata?: Record<string, unknown>;
    }): Promise<unknown>;
    createMemory(memory: Memory, tableName: string, unique?: boolean): Promise<UUID>;
}
export interface SeededConversationRef {
    /** Conversation id (the `web-conv-<id>` channel suffix). */
    id: string;
    roomId: UUID;
    title: string;
    topic: string;
    createdAt: number;
    lastMessageAt: number | null;
}
export interface MessageCorpusSeedSummary {
    conversations: SeededConversationRef[];
    messagesCreated: number;
    factsCreated: number;
    oldestMessageAt: number | null;
    newestMessageAt: number | null;
    sampleQueries: string[];
}
export interface MessageCorpusSeedOptions {
    /** Existing owner identity to use instead of the dev seeder's synthetic owner. */
    ownerEntityId?: UUID;
}
/**
 * Land a generated corpus through the runtime as real web-chat conversations:
 * one `web-conv-*` room per conversation in the agent's web-chat world, with
 * the `client_chat` source and the agent as a participant (the shape that
 * `restoreConversationsFromDb` reads), user messages authored
 * by a deterministic simulated-owner entity, assistant messages by the agent,
 * and per-conversation derived facts in the `facts` table — all with the
 * corpus's backdated `createdAt` values.
 */
export declare function seedMessageCorpus(runtime: MessageCorpusRuntime, corpus: GeneratedMessageCorpus, options?: MessageCorpusSeedOptions): Promise<MessageCorpusSeedSummary>;
