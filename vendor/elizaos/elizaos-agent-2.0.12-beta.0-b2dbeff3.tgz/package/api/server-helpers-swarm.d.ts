import { type AgentRuntime, type ISwarmCoordinatorService } from "@elizaos/core";
import type { PTYService } from "./parse-action-block.js";
import type { ServerState } from "./server-types.js";
export declare function routeAutonomyTextToUser(state: ServerState, responseText: string, source?: string, reminderPresentation?: unknown, reminderReference?: {
    ownerType: "occurrence";
    ownerId: string;
    subjectType: "owner";
    scheduledFor: string;
    dueAt: string | null;
}, publishNotification?: (target?: {
    conversationId: string;
    messageId: string;
}) => Promise<unknown>): Promise<void>;
/**
 * Get the SwarmCoordinator from the runtime services (if available).
 */
export declare function getCoordinatorFromRuntime(runtime: AgentRuntime): ISwarmCoordinatorService | null;
export declare function wireCodingAgentBridgesNow(st: ServerState): void;
export declare function wireCodingAgentChatBridge(st: ServerState): boolean;
export declare function wireCodingAgentWsBridge(st: ServerState): boolean;
export declare function wireCodingAgentSwarmSynthesis(st: ServerState): boolean;
/**
 * Handle swarm completion by routing the captured task result to the user.
 */
export declare function handleSwarmSynthesis(st: {
    runtime: AgentRuntime | null;
}, payload: {
    tasks: Array<{
        sessionId: string;
        label: string;
        agentType: string;
        originalTask: string;
        status: string;
        completionSummary: string;
        validationSummary?: string;
        roomId?: string | null;
        workdir?: string;
        replyToExternalMessageId?: string | null;
    }>;
    total: number;
    completed: number;
    stopped: number;
    errored: number;
}, routeMessage?: (text: string, source: string) => Promise<void>): Promise<void>;
export declare function wireCoordinatorEventRouting(st: ServerState): boolean;
export declare function getPtyConsoleBridge(st: ServerState): import("./parse-action-block.js").ConsoleBridge | null;
export declare function getPtyService(st: ServerState): PTYService | null;
