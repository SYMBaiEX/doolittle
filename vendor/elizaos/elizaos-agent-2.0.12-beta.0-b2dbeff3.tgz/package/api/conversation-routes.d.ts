/**
 * Conversation CRUD routes extracted from server.ts.
 *
 * Handles:
 *   POST   /api/conversations            – create
 *   GET    /api/conversations             – list
 *   GET    /api/conversations/messages/search – corpus-wide message search
 *   POST   /api/conversations/dev/seed-messages – dev-only backdated corpus seed
 *   GET    /api/conversations/:id/messages – get messages
 *   POST   /api/conversations/:id/messages/truncate – truncate
 *   DELETE /api/conversations/:id/messages/:messageId – delete one message
 *   POST   /api/conversations/:id/messages/stream   – stream message
 *   POST   /api/conversations/:id/messages           – send message
 *   POST   /api/conversations/:id/greeting            – get/store greeting
 *   PATCH  /api/conversations/:id         – update/rename
 *   DELETE /api/conversations/:id         – delete
 */
import type http from "node:http";
import { type AgentRuntime, type Content, type IAgentRuntime, type AgentLogEntry as LogEntry, type Memory, type ModelAttemptAllowance, type RoleGrantSource, type RoomHandlerLease, type TrustedApiPrincipal, type UUID } from "@elizaos/core";
import { type ElizaConfig, type RouteRequestContext } from "@elizaos/host/protocol";
import { type AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
import { type ConversationConnectionDescriptor } from "./conversation-connection-readiness.js";
import type { ConversationMeta } from "./server-types.js";
import { importSharedTodoCutover } from "./todo-cutover-import.js";
import { type WaifuChatWorldRole } from "./waifu-chat-role-resolver.js";
export interface ConversationRouteState {
    runtime: AgentRuntime | null;
    config: ElizaConfig;
    agentName: string;
    adminEntityId: UUID | null;
    chatUserId: UUID | null;
    logBuffer: LogEntry[];
    conversations: Map<string, ConversationMeta>;
    activeChatTurnCount: number;
    /** Trusted host trial seed. Request metadata cannot create or refill this. */
    voiceModelPolicy?: Readonly<{
        policyId: string;
        sessionId: string;
        ownerId: string;
        agentId: string;
        conversationId: string;
        allowance: ModelAttemptAllowance;
    }>;
    conversationRestorePromise: Promise<void> | null;
    deletedConversationIds: Set<string>;
    broadcastWs: ((data: object) => void) | null;
    /** Wallet trade permission mode for wallet-mode guidance replies. */
    tradePermissionMode?: string;
}
export interface ConversationRouteContext extends RouteRequestContext {
    state: ConversationRouteState;
    callerAuthorization?: AgentHttpRequestAuthorization;
    todoCutoverImporter?: typeof importSharedTodoCutover;
}
export declare function withViewInteractionClient(message: Memory, req: Pick<http.IncomingMessage, "headers">): Memory;
/**
 * Idempotency identity for one chat turn. Exported so the canonical key
 * ordering it depends on can be pinned by test.
 */
export declare function buildConversationChatFingerprint(input: {
    prompt: string;
    images: unknown;
    source: unknown;
    channelType: unknown;
    preferredLanguage: unknown;
    metadata: unknown;
}): string;
export declare function resolveConversationAdminEntityId(state: ConversationRouteState): UUID;
interface ConversationStreamDisconnectTracker {
    signal: AbortSignal;
    authorityReady: Promise<boolean>;
    abort: (reason?: unknown) => void;
    checkConnectionClosed: () => boolean;
    dispose: () => void;
    isAborted: () => boolean;
    markCompleted: () => void;
}
/**
 * The bearer of a revocable, DB-backed paired-device session, or undefined.
 *
 * A device paired with a user code gets a USER machine session. One paired
 * with the operator code gets a machine session bound to the owner identity,
 * so its principal is `owner_session`. Both are paired devices whose turn
 * should outlive a dropped socket. For the owner case the bearer must itself
 * resolve to a live session for the authenticated identity: the static API
 * token, the trusted-local bypass and cookie sessions keep the existing
 * disconnect-as-cancel behavior.
 */
export declare function resolvePairedSessionToken(req: http.IncomingMessage, principal: TrustedApiPrincipal, runtime: AgentRuntime | null | undefined): Promise<string | undefined>;
export declare function createConversationStreamDisconnectTracker({ req, res, conversationId, roomId, continueOnDisconnect, pairedSessionToken, runtime, }: {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    conversationId: string;
    roomId: UUID;
    continueOnDisconnect: boolean;
    pairedSessionToken?: string;
    runtime?: AgentRuntime | null;
}): ConversationStreamDisconnectTracker;
/**
 * The identity a conversation turn acts as: the minted/mapped entity, the
 * boundary role its world grant records, the display name, and the audit
 * source that non-owner grant is written with.
 */
export interface ConversationCaller {
    entityId: UUID;
    role: WaifuChatWorldRole;
    userName: string;
    grantSource: RoleGrantSource;
}
/**
 * Exported for the machine-session conversation-attribution regression suite;
 * runtime callers are the conversation route handlers in this module.
 */
export declare function resolveConversationCaller(req: http.IncomingMessage, state: ConversationRouteState, principal: TrustedApiPrincipal, runtime?: AgentRuntime | null): ConversationCaller;
/**
 * Exported for the machine-session conversation-attribution regression suite;
 * runtime callers are the conversation route handlers in this module.
 */
export declare function ensureConversationRoom(state: ConversationRouteState, runtime: AgentRuntime, conv: ConversationMeta, caller: ConversationCaller): Promise<ConversationConnectionDescriptor>;
export declare function normalizeActionCallbackHistory(value: unknown): string[];
export declare function formatConversationMessageText(text: string, actionCallbackHistory?: readonly string[]): string;
export declare function buildPersistedAssistantContent(text: string, result: {
    actionCallbackHistory?: string[];
    planningAcknowledgment?: string;
    responseContent?: Content | null;
    responseMessages?: Array<{
        id?: string;
        content?: Content;
    }>;
    transcriptVisibility?: "internal";
} | null | undefined, userMessageId?: UUID): Content;
export declare function persistRecentAssistantActionCallbackHistory(runtime: AgentRuntime, roomId: UUID, actionCallbackHistory: readonly string[], sinceMs: number, targetMemoryId?: UUID, roomHandlerLease?: RoomHandlerLease, assertCurrent?: () => void): Promise<boolean>;
export { serializeMessageAttachments } from "./attachment-disclosure.js";
export declare function handleConversationRoutes(ctx: ConversationRouteContext): Promise<boolean>;
/** Bind prompt creation to the admitted runtime across asynchronous restoration. */
export declare function resolvePromptDeliveryRoom(state: ConversationRouteState & {
    activeConversationId?: string | null;
}, runtime: IAgentRuntime): Promise<UUID>;
/**
 * Resolve the owner's canonical app conversation: the active one, else the
 * most recently updated, restoring persisted conversations first. When the
 * agent has no conversation yet, create one through the same room setup as
 * `POST /api/conversations` so owner-addressed deliveries persist durably and
 * are listed when a client connects. Concurrent callers share one creation.
 */
export declare function ensureOwnerConversation(state: ConversationRouteState & {
    activeConversationId?: string | null;
}, runtime: AgentRuntime): Promise<ConversationMeta>;
