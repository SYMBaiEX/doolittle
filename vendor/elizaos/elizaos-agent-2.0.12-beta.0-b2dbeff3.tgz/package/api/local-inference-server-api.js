let routeApiPromise = null;
let voiceRouteApiPromise = null;
/**
 * Load the local-inference route + chat API from the always-real
 * `./local-inference-routes` subpath. A cold-boot import failure must not poison
 * the memo: `??=` would otherwise cache the rejection and fail EVERY dependent
 * route for the process lifetime, so the memo is cleared on reject and the next
 * caller retries once the deferred plugin closure is resolvable.
 */
export function loadLocalInferenceRouteApi() {
    routeApiPromise ??= import(
    /* @vite-ignore */ "@elizaos/plugin-local-inference/local-inference-routes").catch((err) => {
        routeApiPromise = null;
        throw err;
    });
    return routeApiPromise;
}
/**
 * Load the local-inference voice (TTS/ASR/diarization) API from the always-real
 * `./routes` subpath. Same clear-on-reject memo semantics as
 * {@link loadLocalInferenceRouteApi}.
 */
export function loadLocalInferenceVoiceRouteApi() {
    voiceRouteApiPromise ??= import(
    /* @vite-ignore */ "@elizaos/plugin-local-inference/routes").catch((err) => {
        voiceRouteApiPromise = null;
        throw err;
    });
    return voiceRouteApiPromise;
}
