/**
 * Mounts the relationships-graph API behind the authenticated gate:
 * GET /api/relationships/{graph,people,activity}, GET
 * /api/relationships/candidates, POST
 * /api/relationships/candidates/:id/accept|reject, and POST
 * /api/relationships/people/:id/link. Reads snapshots from the core
 * RelationshipsGraphService (lazily enabling the native relationships feature
 * on first use) and mutates identity-merge candidates via propose/accept/reject;
 * returns 503 when the feature is unavailable. The activity feed also folds in
 * recent extracted facts from runtime memory.
 */
import { type IAgentRuntime } from "@elizaos/core";
import type { RouteRequestContext } from "@elizaos/host/protocol";
import { type RelationshipsGraphQuery } from "@elizaos/plugin-assistant";
export interface RelationshipsRouteContext extends RouteRequestContext {
    runtime?: IAgentRuntime | null;
}
export declare function parseRelationshipsQueryInteger(value: string | null, options?: {
    min?: number;
}): number | undefined;
/**
 * Parse the relationships-graph `scope` query. Omitted/empty keeps the
 * historical unfiltered graph (same as `all`). Exact `relevant` / `all`
 * select that slice. Any other token used to fall through to unfiltered,
 * so `scope=RELEVANT` silently showed everyone.
 */
export declare function parseRelationshipsScope(raw: string | null): {
    ok: true;
    scope: "relevant" | "all" | undefined;
} | {
    ok: false;
    message: string;
};
export declare function parseRelationshipsQuery(reqUrl: string | undefined): RelationshipsGraphQuery;
export declare function handleRelationshipsRoutes(ctx: RelationshipsRouteContext): Promise<boolean>;
