/**
 * Built-in view declarations for the core first-party shell pages.
 *
 * These views are part of the main shell bundle — no `bundlePath` and no
 * `bundleUrl` are needed. They are registered in the view registry so
 * GET /api/views returns them, the agent can discover and navigate to them
 * by name, and they appear in the view manager.
 */
import type { ViewDeclaration } from "@elizaos/core";
export declare const BUILTIN_VIEWS: ViewDeclaration[];
