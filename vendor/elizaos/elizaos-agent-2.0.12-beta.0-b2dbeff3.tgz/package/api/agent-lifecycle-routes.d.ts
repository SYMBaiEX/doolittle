/**
 * Mounts the agent lifecycle HTTP routes on the shared route state: POST
 * /api/agent/{start,stop,pause,resume} drive the reported agent-state machine
 * (running/paused/stopped) and its uptime/startedAt, while GET /api/agent/autonomy
 * reads and POST /api/agent/autonomy toggles the autonomy loop — the POST
 * validates its body, calls enable/disableAutonomy on the AUTONOMY_SERVICE_TYPE
 * service when present, and always syncs runtime.enableAutonomy. Sits behind the
 * authenticated dashboard gate; not public.
 *
 * With no live runtime, POST /api/agent/start is a real boot request, not a
 * flag flip: it boots through the host's injected `onRestart` — the same
 * closure POST /api/agent/restart uses, which app's fresh-install
 * deferral funnels into a single-flight boot. Reporting "running" with a null
 * runtime would be fake-ready: a host that cannot boot answers 503, and a
 * failed boot answers 500 with the reported state flipped to "error".
 * POST /api/agent/stop disposes the live runtime, so a stopped agent runs no
 * connectors, autonomy or scheduled tasks. The host owns complete teardown,
 * including its adapter and boot resources; a host without stop and restart
 * handlers answers 501 because it cannot preserve the stop/start contract.
 */
import type { AgentRuntime, UUID } from "@elizaos/core";
import type { RouteHelpers, RouteRequestMeta } from "@elizaos/host/protocol";
type AgentStateStatus = "not_started" | "starting" | "running" | "paused" | "stopped" | "restarting" | "error";
export interface AgentLifecycleRouteState {
    runtime: AgentRuntime | null;
    agentState: AgentStateStatus;
    agentName: string;
    model: string | undefined;
    startedAt: number | undefined;
    chatConnectionReady: {
        userId: UUID;
        roomId: UUID;
        worldId: UUID;
    } | null;
    chatConnectionPromise: Promise<void> | null;
    runtimeStopPromise: Promise<void> | null;
}
export interface AgentLifecycleRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "error" | "json" | "readJsonBody"> {
    state: AgentLifecycleRouteState;
    /**
     * Boots (or reboots) a runtime in-process. Injected by hosts that own a
     * boot path (server-only startEliza, dev supervisor); absent on hosts that
     * cannot boot, where a start request with no runtime must fail honestly.
     */
    onRestart?: (() => Promise<AgentRuntime | null>) | undefined;
    /** Fully disposes a runtime, including host-owned adapters and boot resources. */
    onStop?: ((runtime: AgentRuntime) => Promise<void>) | undefined;
    /** Post-swap rewiring (streams, model broadcast) — mirrors the restart route. */
    onRuntimeSwapped?: (() => void) | undefined;
    onRuntimeActivated?: ((previousRuntime: AgentRuntime | null, activeRuntime: AgentRuntime) => void | Promise<void>) | undefined;
}
export declare function handleAgentLifecycleRoutes(ctx: AgentLifecycleRouteContext): Promise<boolean>;
export {};
