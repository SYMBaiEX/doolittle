/**
 * Mounts the relationships-graph API behind the authenticated gate:
 * GET /api/relationships/{graph,people,activity}, GET
 * /api/relationships/candidates, POST
 * /api/relationships/candidates/:id/accept|reject, and POST
 * /api/relationships/people/:id/link. Reads snapshots from the core
 * RelationshipsGraphService (lazily enabling the native relationships feature
 * on first use) and mutates identity-merge candidates via propose/accept/reject;
 * returns 503 when the feature is unavailable. The activity feed also folds in
 * recent extracted facts from runtime memory.
 */
import { PostRelationshipLinkRequestSchema } from "@elizaos/contracts";
import { compareMemoryIds, ElizaError, } from "@elizaos/core";
import { RELATIONSHIP_MERGE_CANDIDATE_NOT_FOUND, } from "@elizaos/plugin-assistant";
import { decodePathComponent } from "./server-helpers.js";
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isRelationshipsServiceWithGraph(service) {
    return (typeof service === "object" &&
        service !== null &&
        typeof service.getGraphSnapshot ===
            "function" &&
        typeof service.getPersonDetail ===
            "function" &&
        typeof service.getCandidateMerges ===
            "function" &&
        typeof service.acceptMerge === "function" &&
        typeof service.rejectMerge === "function");
}
export function parseRelationshipsQueryInteger(value, options) {
    if (value === null || !/^\d+$/.test(value)) {
        return undefined;
    }
    const parsed = Number(value);
    if (!Number.isSafeInteger(parsed)) {
        return undefined;
    }
    if (typeof options?.min === "number" && parsed < options.min) {
        return undefined;
    }
    return parsed;
}
const RELATIONSHIPS_SCOPE_ERROR = "scope must be one of: all, relevant";
/**
 * Parse the relationships-graph `scope` query. Omitted/empty keeps the
 * historical unfiltered graph (same as `all`). Exact `relevant` / `all`
 * select that slice. Any other token used to fall through to unfiltered,
 * so `scope=RELEVANT` silently showed everyone.
 */
export function parseRelationshipsScope(raw) {
    if (raw === null || raw === "")
        return { ok: true, scope: undefined };
    if (raw === "relevant" || raw === "all") {
        return { ok: true, scope: raw };
    }
    return { ok: false, message: RELATIONSHIPS_SCOPE_ERROR };
}
export function parseRelationshipsQuery(reqUrl) {
    const url = new URL(reqUrl ?? "/api/relationships/graph", "http://localhost");
    const parsedScope = parseRelationshipsScope(url.searchParams.get("scope"));
    const scope = parsedScope.ok ? parsedScope.scope : undefined;
    return {
        search: url.searchParams.get("search"),
        platform: url.searchParams.get("platform"),
        limit: parseRelationshipsQueryInteger(url.searchParams.get("limit"), {
            min: 1,
        }),
        offset: parseRelationshipsQueryInteger(url.searchParams.get("offset"), {
            min: 0,
        }),
        scope,
    };
}
async function getRelationshipsGraphService(runtime) {
    if (!runtime) {
        return null;
    }
    const runtimeWithFeatures = runtime;
    if (typeof runtimeWithFeatures.isRelationshipsEnabled === "function" &&
        !runtimeWithFeatures.isRelationshipsEnabled() &&
        typeof runtimeWithFeatures.enableRelationships === "function") {
        await runtimeWithFeatures.enableRelationships();
    }
    const service = runtime.getService("relationships");
    return isRelationshipsServiceWithGraph(service) ? service : null;
}
function asEvidenceRecord(value) {
    if (value === undefined || value === null) {
        return {};
    }
    if (typeof value !== "object" || Array.isArray(value)) {
        return {};
    }
    try {
        return JSON.parse(JSON.stringify(value));
    }
    catch {
        return {};
    }
}
const ACTIVITY_FACT_PAGE_ROWS = 200;
const ACTIVITY_FACT_MAX_SCAN_ROWS = 5000;
/**
 * Every fact feeds the activity timeline, which is sorted and paged after the
 * merge with people and edges. The facts are read in keyset pages until the
 * table is exhausted; a store larger than the scan budget is refused
 * explicitly, never trimmed to a window that the paging then reports as
 * complete.
 */
async function listActivityFacts(runtime) {
    const facts = [];
    let cursor;
    for (;;) {
        const remaining = ACTIVITY_FACT_MAX_SCAN_ROWS - facts.length;
        if (remaining <= 0) {
            const page = await runtime.getMemories({
                agentId: runtime.agentId,
                tableName: "facts",
                limit: 1,
                cursor,
                includeEmbedding: false,
                orderDirection: "desc",
            });
            if (page.length === 0)
                return facts;
            throw new ElizaError("Relationships activity exceeded its bounded fact scan before completing the timeline", {
                code: "RELATIONSHIPS_ACTIVITY_SCAN_LIMIT",
                context: {
                    scannedRows: facts.length,
                    maxScannedRows: ACTIVITY_FACT_MAX_SCAN_ROWS,
                },
            });
        }
        const queryLimit = Math.min(ACTIVITY_FACT_PAGE_ROWS, remaining);
        const page = await runtime.getMemories({
            agentId: runtime.agentId,
            tableName: "facts",
            limit: queryLimit,
            cursor,
            includeEmbedding: false,
            orderDirection: "desc",
        });
        for (const fact of page) {
            if (!fact.id) {
                throw new ElizaError("A paged fact row did not contain the required id", {
                    code: "RELATIONSHIPS_ACTIVITY_CURSOR_MISSING_ID",
                });
            }
            const next = {
                createdAt: typeof fact.createdAt === "number" ? fact.createdAt : 0,
                id: fact.id,
            };
            if (cursor &&
                (next.createdAt > cursor.createdAt ||
                    (next.createdAt === cursor.createdAt &&
                        compareMemoryIds(next.id, cursor.id) >= 0))) {
                throw new ElizaError("Memory adapter did not advance the requested keyset cursor", {
                    code: "RELATIONSHIPS_ACTIVITY_CURSOR_NO_PROGRESS",
                    context: { cursorId: cursor.id, returnedId: next.id },
                });
            }
            cursor = next;
            facts.push(fact);
        }
        if (page.length < queryLimit)
            return facts;
    }
}
function parseActivityInteger(value, fallback, options) {
    if (value === null) {
        return fallback;
    }
    if (!/^\d+$/.test(value)) {
        return null;
    }
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed) || parsed < options.min) {
        return null;
    }
    return typeof options.max === "number"
        ? Math.min(parsed, options.max)
        : parsed;
}
export async function handleRelationshipsRoutes(ctx) {
    const { req, res, method, pathname, json, error, readJsonBody, runtime } = ctx;
    const isCandidatesRoute = pathname === "/api/relationships/candidates" ||
        pathname.startsWith("/api/relationships/candidates/");
    const isPersonLinkRoute = pathname.startsWith("/api/relationships/people/") &&
        pathname.endsWith("/link");
    if (pathname !== "/api/relationships/graph" &&
        pathname !== "/api/relationships/people" &&
        pathname !== "/api/relationships/activity" &&
        !pathname.startsWith("/api/relationships/people/") &&
        !isCandidatesRoute) {
        return false;
    }
    // GET routes go through the read paths below; merge/link mutations are
    // POST-only and handled before the GET-only fast-fail.
    if (method !== "GET" && method !== "POST") {
        return false;
    }
    if (method === "GET" &&
        (pathname === "/api/relationships/graph" ||
            pathname === "/api/relationships/people")) {
        const url = new URL(req.url ?? pathname, "http://localhost");
        const parsedScope = parseRelationshipsScope(url.searchParams.get("scope"));
        if (!parsedScope.ok) {
            error(res, parsedScope.message, 400);
            return true;
        }
    }
    const relationshipsGraph = await getRelationshipsGraphService(runtime);
    if (!relationshipsGraph) {
        error(res, "Relationships graph service is not available. Make sure the native relationships feature is enabled.", 503);
        return true;
    }
    if (method === "POST") {
        if (pathname === "/api/relationships/candidates") {
            // Read-only on this exact pathname; POST is reserved for nested IDs.
            error(res, "Method not allowed.", 405);
            return true;
        }
        if (pathname.startsWith("/api/relationships/candidates/") &&
            (pathname.endsWith("/accept") || pathname.endsWith("/reject"))) {
            const action = pathname.endsWith("/accept") ? "accept" : "reject";
            const idStart = "/api/relationships/candidates/".length;
            const idEnd = pathname.lastIndexOf("/");
            const candidateId = decodePathComponent(pathname.slice(idStart, idEnd), res, "merge candidate id");
            if (candidateId === null)
                return true;
            if (!UUID_REGEX.test(candidateId)) {
                error(res, "Invalid merge candidate id.", 400);
                return true;
            }
            try {
                if (action === "accept") {
                    await relationshipsGraph.acceptMerge(candidateId);
                }
                else {
                    await relationshipsGraph.rejectMerge(candidateId);
                }
            }
            catch (cause) {
                // error-policy:J1 an unknown candidate id is the caller's 404, not a
                // server failure; every other failure propagates.
                if (cause instanceof ElizaError &&
                    cause.code === RELATIONSHIP_MERGE_CANDIDATE_NOT_FOUND) {
                    error(res, "Merge candidate not found.", 404);
                    return true;
                }
                throw cause;
            }
            json(res, { data: { id: candidateId, status: action } }, 200);
            return true;
        }
        if (isPersonLinkRoute) {
            const idStart = "/api/relationships/people/".length;
            const idEnd = pathname.lastIndexOf("/");
            const sourceEntityId = decodePathComponent(pathname.slice(idStart, idEnd), res, "source entity id");
            if (sourceEntityId === null)
                return true;
            if (!UUID_REGEX.test(sourceEntityId)) {
                error(res, "Invalid source entity id.", 400);
                return true;
            }
            const rawLink = await readJsonBody(req, res);
            if (rawLink === null)
                return true;
            const parsedLink = PostRelationshipLinkRequestSchema.safeParse(rawLink);
            if (!parsedLink.success) {
                error(res, parsedLink.error.issues[0]?.message ?? "targetEntityId is required.", 400);
                return true;
            }
            // UUIDs compare case-insensitively (UUID_REGEX is /i and the schema
            // preserves case), so normalize before the self-link check.
            if (parsedLink.data.targetEntityId.toLowerCase() ===
                sourceEntityId.toLowerCase()) {
                error(res, "A person cannot be linked to themselves.", 400);
                return true;
            }
            const evidence = asEvidenceRecord(parsedLink.data.evidence);
            const candidateId = await relationshipsGraph.proposeMerge(sourceEntityId, parsedLink.data.targetEntityId, evidence);
            json(res, { data: { id: candidateId, status: "pending" } }, 201);
            return true;
        }
        error(res, "Method not allowed.", 405);
        return true;
    }
    if (method === "GET" && pathname === "/api/relationships/candidates") {
        const candidates = await relationshipsGraph.getCandidateMerges();
        json(res, { data: candidates }, 200);
        return true;
    }
    if (pathname === "/api/relationships/graph") {
        const snapshot = await relationshipsGraph.getGraphSnapshot(parseRelationshipsQuery(req.url));
        json(res, { data: snapshot }, 200);
        return true;
    }
    if (pathname === "/api/relationships/people") {
        const snapshot = await relationshipsGraph.getGraphSnapshot(parseRelationshipsQuery(req.url));
        json(res, {
            data: snapshot.people,
            stats: snapshot.stats,
        }, 200);
        return true;
    }
    if (pathname === "/api/relationships/activity") {
        const snapshot = await relationshipsGraph.getGraphSnapshot();
        const activity = [];
        const personByEntityId = new Map();
        for (const person of snapshot.people) {
            personByEntityId.set(person.primaryEntityId, {
                personId: person.primaryEntityId,
                personName: person.displayName,
            });
            for (const memberEntityId of person.memberEntityIds) {
                personByEntityId.set(memberEntityId, {
                    personId: person.primaryEntityId,
                    personName: person.displayName,
                });
            }
        }
        for (const edge of snapshot.relationships) {
            const types = edge.relationshipTypes.join(", ") || "connected";
            activity.push({
                type: "relationship",
                personName: edge.sourcePersonName,
                personId: edge.sourcePersonId,
                summary: `${edge.sourcePersonName} ↔ ${edge.targetPersonName}`,
                detail: `${types} · ${edge.sentiment} · strength ${edge.strength.toFixed(2)} · ${edge.interactionCount} interactions`,
                timestamp: edge.lastInteractionAt ?? null,
            });
        }
        for (const person of snapshot.people) {
            const platforms = person.platforms.join(", ") || "no platform";
            activity.push({
                type: "identity",
                personName: person.displayName,
                personId: person.primaryEntityId,
                summary: person.displayName,
                detail: `${person.memberEntityIds.length} identit${person.memberEntityIds.length === 1 ? "y" : "ies"} on ${platforms} · ${person.factCount} facts`,
                timestamp: person.lastInteractionAt ?? null,
            });
        }
        if (runtime) {
            const recentFacts = await listActivityFacts(runtime);
            for (const fact of recentFacts) {
                const text = typeof fact.content.text === "string" ? fact.content.text.trim() : "";
                if (!text) {
                    continue;
                }
                const person = fact.entityId
                    ? (personByEntityId.get(fact.entityId) ?? null)
                    : null;
                const metadata = fact.metadata && typeof fact.metadata === "object"
                    ? fact.metadata
                    : null;
                const confidence = typeof metadata?.confidence === "number" ? metadata.confidence : null;
                const scopeBase = metadata?.base && typeof metadata.base === "object"
                    ? metadata.base
                    : null;
                const scope = typeof scopeBase?.scope === "string" ? scopeBase.scope : null;
                const detailParts = [text];
                if (scope) {
                    detailParts.push(scope);
                }
                if (confidence !== null) {
                    detailParts.push(`confidence ${confidence.toFixed(2)}`);
                }
                activity.push({
                    type: "fact",
                    personName: person?.personName ?? "Unknown person",
                    personId: person?.personId ?? fact.entityId,
                    summary: person?.personName
                        ? `Fact for ${person.personName}`
                        : "Fact extracted",
                    detail: detailParts.join(" · "),
                    timestamp: typeof fact.createdAt === "number"
                        ? new Date(fact.createdAt).toISOString()
                        : null,
                });
            }
        }
        activity.sort((a, b) => {
            const ta = a.timestamp ? Date.parse(a.timestamp) : 0;
            const tb = b.timestamp ? Date.parse(b.timestamp) : 0;
            return tb - ta;
        });
        const activityUrl = new URL(req.url ?? "/api/relationships/activity", "http://localhost");
        const limit = parseActivityInteger(activityUrl.searchParams.get("limit"), 50, { min: 1, max: 100 });
        const offset = parseActivityInteger(activityUrl.searchParams.get("offset"), 0, { min: 0 });
        if (limit === null || offset === null) {
            error(res, "Invalid relationships activity pagination.", 400);
            return true;
        }
        json(res, {
            activity: activity.slice(offset, offset + limit),
            total: activity.length,
            count: Math.max(0, Math.min(limit, activity.length - offset)),
            offset,
            limit,
            hasMore: offset + limit < activity.length,
        }, 200);
        return true;
    }
    const primaryEntityId = decodePathComponent(pathname.slice("/api/relationships/people/".length), res, "relationships person identifier");
    if (primaryEntityId === null)
        return true;
    if (!UUID_REGEX.test(primaryEntityId)) {
        error(res, "Invalid relationships person identifier.", 400);
        return true;
    }
    const detail = await relationshipsGraph.getPersonDetail(primaryEntityId);
    if (!detail) {
        error(res, "Relationships person not found.", 404);
        return true;
    }
    json(res, { data: detail }, 200);
    return true;
}
