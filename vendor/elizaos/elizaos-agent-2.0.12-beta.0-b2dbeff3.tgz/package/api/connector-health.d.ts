/**
 * Lightweight connector health monitor.
 *
 * Periodically checks whether configured connectors (Discord, Telegram, etc.)
 * still have their corresponding plugin loaded. On status transition to
 * "missing", broadcasts a system-warning via WebSocket.
 */
import { type AgentRuntime } from "@elizaos/core";
export type ConnectorStatus = "ok" | "missing" | "unknown";
export interface ConnectorHealthMonitorOptions {
    runtime: AgentRuntime;
    config: {
        connectors?: Record<string, unknown>;
    };
    broadcastWs: (payload: object) => void;
    intervalMs: number;
}
/**
 * Resolves the owner-facing interval before the API server binds. The monitor
 * receives only this validated number, so its deferred post-listen startup has
 * no configuration failure left for the best-effort boundary to hide.
 */
export declare function resolveConnectorHealthIntervalMs(envVal: string | undefined): number;
/**
 * Maps connector config keys to the service/client name the plugin registers.
 *
 * Kept aligned with CONNECTOR_PLUGINS in plugin-auto-enable.ts — every
 * connector that can be configured should be probeable here so that cloud
 * and local agents get the same health monitoring coverage.
 */
export declare const CONNECTOR_PLUGIN_MAP: Record<string, string>;
export declare class ConnectorHealthMonitor {
    private runtime;
    private config;
    private broadcastWs;
    private intervalMs;
    private timer;
    private statuses;
    constructor(opts: ConnectorHealthMonitorOptions);
    start(): void;
    private reportProbeCycleFailure;
    stop(): void;
    /**
     * Point the checks at the runtime that replaced the old one. An in-process
     * restart swaps the runtime; checking the stopped one reports its leftover
     * services instead of the connectors that are running now.
     */
    setRuntime(runtime: AgentRuntime): void;
    getConnectorStatuses(): Record<string, ConnectorStatus>;
    private getConfiguredConnectors;
    private probeConnector;
    check(): Promise<void>;
}
