import type http from "node:http";
import { type BoundaryWorldRole, type TokenRoleResolver } from "./boundary-role-resolver.js";
/** The waifu resolver's stable registry id. */
export declare const WAIFU_CHAT_RESOLVER_ID = "waifu-chat";
/** Product-specific role vocabulary carried in WaifuChat JWTs. */
export type WaifuChatRole = "admin" | "user" | "guest";
/**
 * Canonical world roles a waifu role maps onto. Kept as a named alias so the
 * mapping table below is self-documenting; structurally identical to
 * {@link BoundaryWorldRole}.
 */
export type WaifuChatWorldRole = BoundaryWorldRole;
/**
 * The frozen waifu-role → canonical-world-role mapping. This is the single
 * source of truth for the WaifuChat role scheme (previously
 * `waifuChatRoleToWorldRole` in the trunk auth helper). Kept as a `const`
 * record so the parity test can assert the table is unchanged.
 */
export declare const WAIFU_CHAT_ROLE_TO_WORLD_ROLE: Readonly<Record<WaifuChatRole, WaifuChatWorldRole>>;
export declare function waifuChatRoleToWorldRole(role: WaifuChatRole): WaifuChatWorldRole;
export interface WaifuChatAccess {
    role: WaifuChatRole;
    walletAddress: string;
    tokenAddress?: string;
    chainId?: number;
    cloudAgentId?: string;
    balanceTokens?: number | null;
}
/**
 * Parse + validate a WaifuChat access JWT and return its canonical access, or
 * `null` if the token is absent, malformed, unsigned/invalid, expired, or fails
 * any configured issuer/audience/token-address/chain/agent-id gate. Moved
 * verbatim from `server-helpers-auth.ts`.
 */
export declare function resolveWaifuChatAccessToken(token: string | null | undefined, nowSeconds?: number): WaifuChatAccess | null;
export declare function resolveWaifuChatAccess(req: http.IncomingMessage): WaifuChatAccess | null;
/**
 * Whether a request is authorized under the WaifuChat scheme. Preserved for
 * back-compat callers; the trunk gate now reaches this through the registered
 * resolver rather than importing it directly.
 */
export declare function isWaifuChatAuthorized(req: http.IncomingMessage, method: string, pathname: string): boolean;
/**
 * The WaifuChat boundary-role resolver. Registering it wires the waifu role
 * scheme into the trunk gate through the extension point.
 */
export declare const waifuChatRoleResolver: TokenRoleResolver;
/**
 * Register the WaifuChat resolver with the trunk boundary-role registry.
 * Idempotent — safe to call from module load and from server setup.
 */
export declare function registerWaifuChatRoleResolver(): () => void;
