import { type AudioRedactionSpan, type RedactionVerifyResult } from "@elizaos/core";
import { type AudioRedactionMode } from "./audio-redaction.js";
/** Inputs that content-address one redaction job. */
export interface AudioRedactionKeyParts {
    /** sha256 of the ORIGINAL bytes (the store hash / capability). */
    originalSha: string;
    /** Merged, non-overlapping windows (labels do not affect the bytes). */
    spans: readonly AudioRedactionSpan[];
    mode: AudioRedactionMode;
    /** Active PII ruleset version — a bump re-redacts deterministically. */
    rulesetVersion: string;
}
/**
 * Derive the content-addressed job key — the audio analog of the text lane's
 * `pii:<sha256>:v<ruleset>` done-marker (#14808), extended with the mode and
 * a hash of the canonical span windows.
 */
export declare function audioRedactionKey(parts: AudioRedactionKeyParts): string;
/** A stored redacted variant handle. */
export interface RedactedAudioVariant {
    /** Served URL of the REDACTED bytes (`/api/media/<sha256'>.<ext>`). */
    url: string;
    /** sha256 of the redacted bytes — the variant's own content address. */
    hash: string;
    fileName: string;
    /** The job key this variant answers. */
    key: string;
    /** True when the variant came from the memo (no recompute). */
    reused: boolean;
}
/**
 * Look up an existing redacted variant for the job key. Returns null when the
 * memo has no entry or the variant bytes were evicted/GC'd — the caller then
 * recomputes via {@link prepareRedactedAudioVariant}, verifies, and publishes
 * via {@link persistVerifiedRedactedAudioVariant}; determinism lands on the
 * same output sha.
 */
export declare function findRedactedAudioVariant(parts: AudioRedactionKeyParts): RedactedAudioVariant | null;
/** Request for {@link prepareRedactedAudioVariant}. */
export interface PrepareRedactedAudioVariantRequest {
    /** The ORIGINAL's stored name (`<sha256>.<ext>`) in the media store. */
    originalFileName: string;
    spans: readonly AudioRedactionSpan[];
    mode: AudioRedactionMode;
    rulesetVersion: string;
}
export interface PreparedRedactedAudioVariant {
    key: string;
    originalSha: string;
    bytes: Buffer;
    mimeType: string;
    lane: "pure-ts-wav" | "ffmpeg";
    inputDurationMs: number;
}
/**
 * Prepare candidate bytes from a stored original without publishing them:
 * read the original and run the duration-preserving redaction op. The caller
 * must verify the candidate and pass it to
 * {@link persistVerifiedRedactedAudioVariant}. Determinism means re-running
 * the identical job yields the identical output sha.
 *
 * The caller wires the returned URL into the artifact record for
 * non-privileged viewers (reference distribution is the permission boundary;
 * the serve path stays capability-addressed). This module never touches
 * records or roles.
 */
export declare function prepareRedactedAudioVariant(request: PrepareRedactedAudioVariantRequest): Promise<PreparedRedactedAudioVariant>;
export declare function persistVerifiedRedactedAudioVariant(prepared: PreparedRedactedAudioVariant, verification: RedactionVerifyResult): RedactedAudioVariant;
