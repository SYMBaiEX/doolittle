/**
 * Awaits server-side resource teardown in reverse registration order. A failed
 * disposer is reported and the remaining resources still close, so shutdown is
 * complete and observable instead of spawning detached cleanup promises.
 */
export function createServerResources(reportFailure) {
    const resources = [];
    let closePromise = null;
    return {
        add(resource) {
            if (closePromise) {
                throw new Error(`Cannot register ${resource.name} after server teardown`);
            }
            resources.push(resource);
        },
        close() {
            closePromise ??= closeServerResources(resources, reportFailure);
            return closePromise;
        },
    };
}
export async function closeServerResources(resources, reportError) {
    for (const resource of [...resources].reverse()) {
        try {
            await resource.dispose();
        }
        catch (error) {
            reportError(resource.name, error);
        }
    }
}
