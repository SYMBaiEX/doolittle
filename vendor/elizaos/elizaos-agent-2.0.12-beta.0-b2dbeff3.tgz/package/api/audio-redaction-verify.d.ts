/**
 * Audio PII redaction — verifier transcriber adapters (#14807).
 *
 * The verifier CONTRACT (and the pure PII-absence / sentinel-presence
 * judgment) lives in `@elizaos/core`, deliberately
 * separable from the span producer so verification can run on a different
 * ASR backend. This module supplies the concrete backends the agent host can
 * offer:
 *
 *  - {@link runtimeTranscriptionTranscriber} — the registered
 *    `ModelType.TRANSCRIPTION` handler (local Phonon-2 on libelizainference, or whichever
 *    provider won registration). A missing handler THROWS through
 *    `useModel`, so the verify step fails, never passes vacuously.
 *  - {@link openAiCompatSttTranscriber} — any self-hosted OpenAI-compatible
 *    `/v1/audio/transcriptions` endpoint (faster-whisper, FunASR, SenseVoice,
 *    the voice-whisper-stt cloud sibling). This is the independent-verifier
 *    lane from the #14807 acceptance note.
 */
import { type IAgentRuntime, type RedactionTranscriber } from "@elizaos/core";
/**
 * Verify through the runtime's registered TRANSCRIPTION model (interim
 * purpose — a verify pass is pipeline-internal, never a billable user
 * transcription). `useModel` throws when no handler is registered or the
 * handler fails (`AsrUnavailableError`), which is exactly the fail-closed
 * behavior the verify step requires.
 */
export declare function runtimeTranscriptionTranscriber(runtime: IAgentRuntime): RedactionTranscriber;
/** Config for an OpenAI-compatible `/v1/audio/transcriptions` verifier. */
export interface OpenAiCompatSttOptions {
    /** Endpoint base, e.g. `https://stt.internal` (no trailing path). */
    baseUrl: string;
    /** Backend model id (e.g. `Systran/faster-whisper-small`). */
    model: string;
    apiKey?: string;
    /** Request timeout; defaults to 120 s (CPU STT on long clips is slow). */
    timeoutMs?: number;
    /** Deterministic transport seam; production uses the pinned Node transport. */
    fetchImpl?: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
}
/**
 * Verifier backend over any self-hosted OpenAI-compatible STT server —
 * multipart `file` + `model` to `/v1/audio/transcriptions`, `{text}` back.
 * Errors (non-2xx, timeout, malformed body) THROW so the verify step fails
 * observably.
 */
export declare function openAiCompatSttTranscriber(options: OpenAiCompatSttOptions): RedactionTranscriber;
