/** Resolve the authenticated caller authority used by inbox connector sends. */
import type http from "node:http";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
export declare function resolveInboxRequestAuthorization(req: http.IncomingMessage, method: string, pathname: string, hostAuthorization: AgentHttpRequestAuthorization): AgentHttpRequestAuthorization;
