export function createRouteKernel(options) {
    return {
        async handle(req, res) {
            try {
                await options.dispatch(req, res);
            }
            catch (error) {
                // error-policy:J1 HTTP is the outermost boundary for route failures.
                await options.translateFailure(error, req, res);
            }
        },
    };
}
