import type { HttpPlugin, Route } from "@elizaos/host/protocol";
export declare const identityPersonLinkRoutes: readonly Route[];
/** Host-owned HTTP compatibility surface; SQL itself registers no routes. */
export declare const identityHttpPlugin: HttpPlugin;
