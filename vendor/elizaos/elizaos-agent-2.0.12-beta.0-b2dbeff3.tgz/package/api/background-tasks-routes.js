import { ServiceType } from "@elizaos/core";
import { BackgroundTaskRunCoordinator } from "../host-use-cases.js";
function isTaskServiceLike(service) {
    return (service !== null &&
        typeof service === "object" &&
        typeof Reflect.get(service, "runDueTasks") === "function");
}
const backgroundTaskRuns = new BackgroundTaskRunCoordinator();
export async function handleBackgroundTasksRoute({ method, pathname, state, json, res, }) {
    if (method.toUpperCase() !== "POST" ||
        pathname !== "/api/background/run-due-tasks") {
        return false;
    }
    const runtime = state.runtime;
    if (!runtime) {
        json(res, {
            ok: false,
            error: "runtime_unavailable",
        }, 503);
        return true;
    }
    const service = runtime.getService(ServiceType.TASK);
    if (!isTaskServiceLike(service)) {
        json(res, {
            ok: false,
            error: "task_service_unavailable",
        }, 503);
        return true;
    }
    try {
        const result = await backgroundTaskRuns.run(service);
        json(res, {
            ok: true,
            ranAt: new Date().toISOString(),
            coalesced: result.coalesced,
        });
    }
    catch (error) {
        json(res, {
            ok: false,
            error: error instanceof Error ? error.message : String(error),
        }, 500);
    }
    return true;
}
