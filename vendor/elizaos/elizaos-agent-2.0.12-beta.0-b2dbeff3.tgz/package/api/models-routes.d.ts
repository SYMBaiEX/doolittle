/**
 * Serves `GET /api/models`, the model-catalog endpoint behind the dashboard
 * control-API auth gate. Returns provider model lists from an on-disk cache:
 * `?provider=` narrows to one provider, `?refresh=true` busts the cache (a
 * single provider's file, or every cached `.json` for an all-providers fetch)
 * before refetching. Every response additionally carries a `catalog` field —
 * the validated provider→model→efforts catalog (model-catalog.ts) that
 * `POST /api/models/config` writes are checked against. Filesystem and fetch
 * access are injected through the route context so the handler stays
 * transport-agnostic and unit-testable.
 */
import type { RouteHelpers, RouteRequestMeta } from "@elizaos/host/protocol";
import { type ModelCatalog } from "./model-catalog.js";
export interface ModelsRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json"> {
    url: URL;
    providerCachePath: (provider: string) => string;
    getOrFetchProvider: (provider: string, force: boolean) => Promise<unknown[]>;
    getOrFetchAllProviders: (force: boolean) => Promise<Record<string, unknown[]>>;
    resolveModelsCacheDir: () => string;
    pathExists: (targetPath: string) => boolean;
    readDir: (targetPath: string) => string[];
    unlinkFile: (targetPath: string) => void;
    joinPath: (left: string, right: string) => string;
    /** Injectable catalog builder for tests; defaults to buildModelCatalog. */
    buildCatalog?: () => ModelCatalog;
}
export declare function handleModelsRoutes(ctx: ModelsRouteContext): Promise<boolean>;
