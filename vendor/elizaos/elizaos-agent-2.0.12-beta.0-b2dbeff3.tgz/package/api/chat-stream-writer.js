export function initSse(res) {
    res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
    });
}
export function writeSse(res, payload) {
    if (res.writableEnded || res.destroyed)
        return;
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
}
/** Emits deltas with geometrically spaced recovery snapshots. */
export function createChatTokenStreamWriter() {
    const provisionalField = (options) => options?.provisional ? { provisional: true } : {};
    // Snapshot spacing grows with the previous full text's UTF-16 length.
    // The 2048-unit floor permits recovery snapshots on short replies while
    // geometric spacing keeps total wire size linear for long replies.
    let bytesSinceSnapshot = 0;
    let lengthAtLastSnapshot = 0;
    return {
        writeChunk(res, chunk, fullText, options) {
            bytesSinceSnapshot += chunk.length;
            if (bytesSinceSnapshot >= Math.max(2048, lengthAtLastSnapshot)) {
                writeSse(res, {
                    type: "token",
                    text: chunk,
                    fullText,
                    ...provisionalField(options),
                });
                bytesSinceSnapshot = 0;
                lengthAtLastSnapshot = fullText.length;
            }
            else {
                writeSse(res, {
                    type: "token",
                    text: chunk,
                    ...provisionalField(options),
                });
            }
        },
        writeSnapshot(res, fullText, options) {
            // No `text` field: the client reads `fullText` as an authoritative
            // replace rather than an append.
            writeSse(res, {
                type: "token",
                fullText,
                ...provisionalField(options),
            });
            bytesSinceSnapshot = 0;
            lengthAtLastSnapshot = fullText.length;
        },
    };
}
export function writeChatStatusSse(res, status) {
    writeSse(res, { type: "status", ...status });
}
export function writeChatToolSse(res, event) {
    writeSse(res, { type: "tool", ...event });
}
export function writeSseData(res, data, event) {
    if (res.writableEnded || res.destroyed)
        return;
    const safeEvent = typeof event === "string" && /^[A-Za-z0-9_.-]+$/.test(event) ? event : null;
    if (safeEvent)
        res.write(`event: ${safeEvent}\n`);
    for (const line of data.split(/\r\n|\r|\n/)) {
        res.write(`data: ${line}\n`);
    }
    res.write("\n");
}
export function writeSseJson(res, payload, event) {
    writeSseData(res, JSON.stringify(payload), event);
}
