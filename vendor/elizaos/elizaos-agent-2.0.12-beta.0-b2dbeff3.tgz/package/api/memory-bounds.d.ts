/**
 * Pure helper functions for bounded in-memory data structures.
 *
 * @module
 */
interface RateLimitEntry {
    count: number;
    resetAt: number;
}
/**
 * Evict expired entries from a rate-limit map when it exceeds `threshold`.
 * Safe to call during iteration (Map spec permits deletion during for-of).
 */
export declare function sweepExpiredEntries(map: Map<string, RateLimitEntry>, now: number, threshold: number): void;
interface CachedFile {
    body: Buffer;
    mtimeMs: number;
}
/**
 * Retrieve a file from a bounded cache, reading from disk on miss.
 * Files larger than `fileSizeLimit` are never cached.
 *
 * @param cache         - The Map serving as the LRU-ish cache.
 * @param filePath      - Absolute path to the file.
 * @param mtimeMs       - File's last-modified time (for invalidation).
 * @param readFile      - Callback that reads the file (injected for testing).
 * @param maxEntries    - Maximum number of cached files.
 * @param fileSizeLimit - Maximum file size (bytes) eligible for caching.
 */
export declare function getOrReadCachedFile(cache: Map<string, CachedFile>, filePath: string, mtimeMs: number, readFile: (p: string) => Buffer, maxEntries: number, fileSizeLimit: number): Buffer;
export {};
