/**
 * HTTP fetch/streaming helpers extracted from server.ts.
 */
import type http from "node:http";
type StreamableServerResponse = Pick<http.ServerResponse, "write" | "once" | "off" | "removeListener" | "writableEnded" | "destroyed">;
export declare function responseContentLength(headers: Pick<Headers, "get">): number | null;
export declare function isAbortError(error: unknown): boolean;
export declare function fetchWithTimeoutGuard(input: string | URL, init: RequestInit, timeoutMs: number): Promise<Response>;
/**
 * Stream a web Response body to an HTTP response while enforcing a strict byte cap.
 * Returns the number of bytes forwarded.
 */
export declare function streamResponseBodyWithByteLimit(upstream: Response, res: StreamableServerResponse, maxBytes: number, timeoutMs?: number): Promise<number>;
export {};
