/**
 * Mounts the plugin-registry read/refresh API behind the authenticated gate:
 * GET /api/registry/plugins (registry entries annotated with installed / loaded
 * / bundled state, installed and latest versions, and release-channel
 * compatibility), GET /api/registry/plugins/:name, GET /api/registry/search,
 * and POST /api/registry/refresh. Reads through the injected plugin manager;
 * upstream failures surface as 502.
 */
import { isValidRegistryPackageName, parseClampedInteger } from "@elizaos/core";
import { decodePathComponent } from "./server-helpers.js";
export async function handleRegistryRoutes(ctx) {
    const { res, method, pathname, url, json, error, getPluginManager, getLoadedPluginNames, getBundledPluginIds, classifyRegistryPluginRelease, } = ctx;
    if (method === "GET" && pathname === "/api/registry/plugins") {
        try {
            const pluginManager = getPluginManager();
            const registry = await pluginManager.refreshRegistry();
            const installed = await pluginManager.listInstalledPlugins();
            const installedNames = new Set(installed.map((plugin) => plugin.name));
            const loadedNames = new Set(getLoadedPluginNames());
            const bundledIds = getBundledPluginIds();
            const plugins = Array.from(registry.values()).map((plugin) => {
                const shortId = plugin.name
                    .replace(/^@[^/]+\/plugin-/, "")
                    .replace(/^@[^/]+\//, "")
                    .replace(/^plugin-/, "");
                const bundled = bundledIds.has(shortId);
                return {
                    ...plugin,
                    installed: installedNames.has(plugin.name),
                    installedVersion: installed.find((entry) => entry.name === plugin.name)?.version ??
                        null,
                    releaseStream: installed.find((entry) => entry.name === plugin.name)
                        ?.releaseStream ?? null,
                    betaVersion: installed.find((entry) => entry.name === plugin.name)
                        ?.betaVersion ?? null,
                    latestVersion: installed.find((entry) => entry.name === plugin.name)
                        ?.latestVersion ??
                        plugin.npm.v2Version ??
                        null,
                    loaded: loadedNames.has(plugin.name) ||
                        loadedNames.has(plugin.name.replace("@elizaos/", "")),
                    bundled,
                    compatibility: classifyRegistryPluginRelease({
                        packageName: plugin.name,
                        bundledPluginIds: bundledIds,
                        kind: plugin.kind,
                    }),
                };
            });
            json(res, { count: plugins.length, plugins });
        }
        catch (err) {
            error(res, `Failed to fetch registry: ${String(err)}`, 502);
        }
        return true;
    }
    if (method === "GET" &&
        pathname.startsWith("/api/registry/plugins/") &&
        pathname.length > "/api/registry/plugins/".length) {
        const name = decodePathComponent(pathname.slice("/api/registry/plugins/".length), res, "plugin name");
        if (name === null)
            return true;
        if (!isValidRegistryPackageName(name)) {
            error(res, "Invalid plugin name", 400);
            return true;
        }
        try {
            const pluginManager = getPluginManager();
            const info = await pluginManager.getRegistryPlugin(name);
            if (!info) {
                error(res, `Plugin "${name}" not found in registry`, 404);
                return true;
            }
            json(res, { plugin: info });
        }
        catch (err) {
            error(res, `Failed to look up plugin: ${String(err)}`, 502);
        }
        return true;
    }
    if (method === "GET" && pathname === "/api/registry/search") {
        const query = url.searchParams.get("q") || "";
        if (!query.trim()) {
            error(res, "Query parameter 'q' is required", 400);
            return true;
        }
        try {
            const limitParam = url.searchParams.get("limit");
            const limit = limitParam
                ? parseClampedInteger(limitParam, { min: 1, max: 50, fallback: 15 })
                : 15;
            const pluginManager = getPluginManager();
            const results = await pluginManager.searchRegistry(query, limit);
            json(res, { query, count: results.length, results });
        }
        catch (err) {
            error(res, `Search failed: ${String(err)}`, 502);
        }
        return true;
    }
    if (method === "POST" && pathname === "/api/registry/refresh") {
        try {
            const pluginManager = getPluginManager();
            const registry = await pluginManager.refreshRegistry();
            json(res, { ok: true, count: registry.size });
        }
        catch (err) {
            error(res, `Refresh failed: ${String(err)}`, 502);
        }
        return true;
    }
    return false;
}
