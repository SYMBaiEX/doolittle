/**
 * Grouped request handlers for several `/api/*` namespaces, invoked by the
 * server's route dispatcher. Covers inbox/notifications/approvals/push-tokens
 * and cloud relay-status; cloud billing/compat/core routes; the compute-use
 * sandbox surface; database routes; the conversation and chat-completions path
 * (`/api/conversations`, `/v1/*`, per-agent `POST /api/agents/:id/message`);
 * and LifeOps runtime plugin routes. The heavy plugin owners
 * (`@elizaos/plugin-computeruse`, `@elizaos/plugin-elizacloud`) load through
 * memoized lazy imports so they stay out of the static boot graph.
 */
import type http from "node:http";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
import { handleChatRoutes } from "./chat-routes.js";
import { type InboxRouteCallerAuthorization } from "./inbox-routes.js";
import type { ServerState } from "./server-types.js";
type ChatRouteArg = Parameters<typeof handleChatRoutes>[0];
interface DispatchRouteHelpers {
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: ChatRouteArg["readJsonBody"];
}
interface DispatchRouteContext extends DispatchRouteHelpers {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    state: ServerState;
    inboxCallerAuthorization?: InboxRouteCallerAuthorization;
    callerAuthorization?: AgentHttpRequestAuthorization;
}
interface CloudAndCoreRouteContext extends DispatchRouteContext {
    restartRuntime: (reason: string) => Promise<boolean>;
    saveConfig: (config: ServerState["config"]) => void;
    isAuthorizedRequest: (req: http.IncomingMessage) => boolean;
}
export declare function handleInboxAndCloudRelayRouteGroup({ req, res, method, pathname, state, json, error, readJsonBody, inboxCallerAuthorization, }: DispatchRouteContext): Promise<boolean>;
export declare function handleCloudAndCoreRouteGroup({ req, res, method, pathname, state, restartRuntime, saveConfig, }: Pick<CloudAndCoreRouteContext, "req" | "res" | "method" | "pathname" | "state" | "restartRuntime" | "saveConfig">): Promise<boolean>;
export declare function handleSandboxRouteGroup({ req, res, method, pathname, state, }: Pick<DispatchRouteContext, "req" | "res" | "method" | "pathname" | "state">): Promise<boolean>;
export declare function handleDatabaseRouteGroup({ req, res, pathname, state, }: Pick<DispatchRouteContext, "req" | "res" | "pathname" | "state">): Promise<boolean>;
export declare function handleConversationRouteGroup({ req, res, method, pathname, state, json, error, readJsonBody, callerAuthorization, }: DispatchRouteContext): Promise<boolean>;
export declare function handleLifeOpsRuntimePluginRoute({ req, res, method, pathname, url, state, isAuthorizedRequest, }: Pick<CloudAndCoreRouteContext, "req" | "res" | "method" | "pathname" | "url" | "state" | "isAuthorizedRequest">): Promise<boolean>;
export {};
