import { logger } from "@elizaos/core";
import { isElizaSettingsDebugEnabled, normalizeDeploymentTargetConfig, normalizeLinkedAccountFlagsConfig, normalizeServiceRoutingConfig, sanitizeForSettingsDebug, settingsDebugCloudSummary, } from "@elizaos/host/protocol";
import { loadElizaConfig, saveElizaConfig } from "../config/config.js";
import { isDevCloudEnvOwnedKey, isDevCloudInternalEnvKey, resolveDevCloudEnvAuthority, } from "../config/dev-cloud-env-authority.js";
import { clearConfigEnvValue, writeConfigEnvValue, } from "../config/env-vars.js";
import { agentIdentityName, buildCharacterFromConfig, } from "../runtime/build-character-config.js";
import { getAgentHostBridge } from "../runtime/host-bridge.js";
import { buildProductCharacterFromConfig } from "../runtime/prepare-product-character-config.js";
import { reconcileConfigEnvSettings, reconcileDirectTextModelSettings, } from "../runtime/runtime-settings.js";
import { hasBlockedObjectKeyDeep, MAX_BLOCKED_OBJECT_DEPTH, MAX_BLOCKED_OBJECT_NODES, } from "./blocked-object-keys.js";
import { replaceConfigInPlace } from "./config-state.js";
import { applyCanonicalFirstRunConfig } from "./provider-switch-config.js";
const DEV_CLOUD_PROVIDER_IDS = new Set([
    "elizacloud",
    "eliza-cloud",
    "@elizaos/plugin-elizacloud",
]);
function isDevCloudProxyRoute(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return false;
    const route = value;
    const backend = typeof route.backend === "string" ? route.backend.trim().toLowerCase() : "";
    return (route.transport === "cloud-proxy" && DEV_CLOUD_PROVIDER_IDS.has(backend));
}
/**
 * Remove only launcher-owned Cloud topology from a generic config patch.
 * Unrelated linked accounts and direct-provider routes remain editable in the
 * same request; the durable Cloud tuple is changed only outside dev authority.
 */
function stripDevCloudAuthorityOwnedTopology(filtered) {
    delete filtered.cloud;
    delete filtered.deploymentTarget;
    const linkedAccounts = filtered.linkedAccounts;
    if (linkedAccounts &&
        typeof linkedAccounts === "object" &&
        !Array.isArray(linkedAccounts)) {
        const accounts = linkedAccounts;
        for (const accountId of Object.keys(accounts)) {
            if (DEV_CLOUD_PROVIDER_IDS.has(accountId.trim().toLowerCase())) {
                delete accounts[accountId];
            }
        }
        if (Object.keys(accounts).length === 0)
            delete filtered.linkedAccounts;
    }
    const serviceRouting = filtered.serviceRouting;
    if (serviceRouting &&
        typeof serviceRouting === "object" &&
        !Array.isArray(serviceRouting)) {
        const routes = serviceRouting;
        for (const capability of Object.keys(routes)) {
            if (isDevCloudProxyRoute(routes[capability]))
                delete routes[capability];
        }
        if (Object.keys(routes).length === 0)
            delete filtered.serviceRouting;
    }
}
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
/**
 * Hot-reloadable top-level config keys. Replacing these in `state.config`
 * is sufficient because downstream readers (TTS routes, feature-flag
 * checks, character-derived prompts) read `state.config` live on each
 * request. Anything not listed here either has no live consumer or
 * requires a full runtime rebuild.
 */
const HOT_RELOADABLE_TOP_KEYS = new Set([
    "agents",
    "ui",
    "messages", // TTS lives under messages.tts
    "features",
    "linkedAccounts",
    "serviceRouting",
    "deploymentTarget",
    "cloud",
    "permissions",
]);
/** Top-level keys whose change forces a full runtime restart. */
const RESTART_REQUIRED_TOP_KEYS = new Set([
    "plugins",
    "providers",
    "models",
    "database",
]);
/** Env-var keys that hold provider API credentials we sync into process.env. */
const PROVIDER_ENV_KEYS = [
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "GOOGLE_GENERATIVE_AI_API_KEY",
    "GROQ_API_KEY",
    "XAI_API_KEY",
    "OPENROUTER_API_KEY",
    "NEARAI_API_KEY",
    "NEARAI_BASE_URL",
    "NEARAI_SMALL_MODEL",
    "NEARAI_LARGE_MODEL",
    "OLLAMA_BASE_URL",
];
/**
 * Read a provider credential from a config record the same way the reload
 * env-sync below does (`env.vars.*` first, legacy direct `env.*` second). A
 * non-empty trimmed string counts as present; anything else is absent.
 */
function readProviderEnvValue(config, key) {
    const envSection = config.env;
    const envVars = envSection?.vars && typeof envSection.vars === "object"
        ? envSection.vars
        : undefined;
    const value = typeof envVars?.[key] === "string"
        ? envVars[key]
        : typeof envSection?.[key] === "string"
            ? envSection[key]
            : undefined;
    return typeof value === "string" && value.trim() ? value.trim() : undefined;
}
function asConfigRecord(value) {
    return value;
}
/**
 * Compute which top-level keys differ between the current in-memory config
 * and a freshly-loaded copy from disk, and bucket them into hot-reloadable
 * vs restart-required.
 */
function computeReloadDiff(current, next) {
    const applied = [];
    const requiresRestart = [];
    const allKeys = new Set([
        ...Object.keys(current),
        ...Object.keys(next),
    ]);
    for (const key of allKeys) {
        const a = JSON.stringify(current[key] ?? null);
        const b = JSON.stringify(next[key] ?? null);
        if (a === b)
            continue;
        if (RESTART_REQUIRED_TOP_KEYS.has(key)) {
            requiresRestart.push(key);
        }
        else if (HOT_RELOADABLE_TOP_KEYS.has(key)) {
            applied.push(key);
        }
        else if (key === "env") {
            // env changes are partly hot (provider API keys) — treat as applied.
            applied.push(key);
        }
        else {
            // Unknown / unmapped top keys: treat as applied (state.config is the
            // single source of truth and is read live by most consumers).
            applied.push(key);
        }
    }
    return { applied, requiresRestart };
}
/**
 * Apply a freshly-loaded config to `state.config` in place, then re-build
 * the runtime character so name/system/bio/style updates land immediately.
 * Provider API keys are synced into process.env so the next model call
 * picks them up.
 */
async function applyReloadedConfig(params) {
    const { state, next, runtime, isBlockedEnvKey } = params;
    const previous = structuredClone(state);
    // Replace top-level keys in the live state.config with the loaded values.
    replaceConfigInPlace(state, next);
    const nextRecord = asConfigRecord(next);
    // Sync provider API keys into process.env (the runtime reads them at
    // request time via getSetting → process.env). Keys removed (or blanked) in
    // the reloaded config are cleared too, so a deleted credential stops being
    // served to provider clients — but only when the previous config owned the
    // live value; an operator-set env var (docker env, shell export) is left
    // alone.
    for (const key of PROVIDER_ENV_KEYS) {
        if (isBlockedEnvKey(key))
            continue;
        const value = readProviderEnvValue(nextRecord, key);
        if (value !== undefined) {
            writeConfigEnvValue(key, value);
        }
        else {
            clearConfigEnvValue(key);
        }
    }
    // Re-derive character fields from the freshly-loaded config and apply
    // them to the live runtime. This propagates renames, system prompt
    // edits, bio/style updates, and topic/adjective changes.
    if (runtime) {
        // The live agent keeps its id after a rename; keep the identity name that
        // id came from instead of the rebuilt one (the new display name).
        const liveIdentityName = agentIdentityName(runtime.character);
        const product = getAgentHostBridge().productCharacter;
        const rebuilt = product &&
            !process.env.SANDBOX_ROUTE_AGENT_ID?.trim() &&
            !process.env.ELIZA_AGENT_CHARACTER_JSON?.trim() &&
            !process.env.ELIZA_CHARACTER_PATH?.trim()
            ? buildProductCharacterFromConfig(next, product)
            : buildCharacterFromConfig(next);
        const character = asConfigRecord(runtime.character);
        const HOT_CHARACTER_FIELDS = [
            "name",
            "username",
            "system",
            "bio",
            "topics",
            "adjectives",
            "style",
            "messageExamples",
            "postExamples",
            "settings",
        ];
        const rebuiltRecord = asConfigRecord(rebuilt);
        for (const field of HOT_CHARACTER_FIELDS) {
            const value = rebuiltRecord[field];
            if (value !== undefined) {
                character[field] = value;
            }
        }
        if (liveIdentityName && liveIdentityName !== rebuilt.name) {
            runtime.character.settings = {
                ...runtime.character.settings,
                identityName: liveIdentityName,
            };
            state.agents ??= {};
            const agentList = state.agents.list ?? [];
            const primaryAgent = agentList[0] ?? { id: "main", default: true };
            if (!primaryAgent.identityName) {
                state.agents.list = [
                    { ...primaryAgent, identityName: liveIdentityName },
                    ...agentList.slice(1),
                ];
                saveElizaConfig(state);
            }
        }
        reconcileConfigEnvSettings(runtime, previous, next);
        reconcileDirectTextModelSettings(runtime, previous, next);
    }
}
/** Honest config patches share the canonical blocked-object-key budget. */
export const MAX_CONFIG_PATCH_DEPTH = MAX_BLOCKED_OBJECT_DEPTH;
export const MAX_CONFIG_PATCH_NODES = MAX_BLOCKED_OBJECT_NODES;
/**
 * Reuse the hardened walker in blocked-object-keys.ts (depth 32 / 100k nodes,
 * descriptor-only reads, path-scoped cycle detect, typed unbounded error).
 * Over-budget graphs and nested blocked keys fail closed together.
 */
export function configPatchExceedsBound(value) {
    return hasBlockedObjectKeyDeep(value);
}
/**
 * Handle configuration routes (GET/PUT /api/config, GET /api/config/schema,
 * POST /api/config/reload). Returns `true` if the request was handled.
 */
export async function handleConfigRoutes(ctx) {
    const { req, res, method, pathname, config, runtime, json, error, readJsonBody, redactConfigSecrets, isBlockedObjectKey, stripRedactedPlaceholderValuesDeep, patchTouchesProviderSelection: _patchTouchesProviderSelection, isBlockedEnvKey, CONFIG_WRITE_ALLOWED_TOP_KEYS, resolveMcpServersRejection, resolveMcpTerminalAuthorizationRejection, } = ctx;
    // ── GET /api/config/schema ───────────────────────────────────────────────
    if (method === "GET" && pathname === "/api/config/schema") {
        const { buildConfigSchema } = await import("../config/schema.js");
        const result = buildConfigSchema();
        json(res, result);
        return true;
    }
    // ── POST /api/config/reload ──────────────────────────────────────────────
    // Re-read eliza.json from disk and apply hot-reloadable fields to the
    // running runtime. Returns the list of fields applied and any fields that
    // still require a full restart (plugin list, provider/model registry,
    // database adapter).
    if (method === "POST" && pathname === "/api/config/reload") {
        if (resolveDevCloudEnvAuthority()) {
            error(res, "Config reload is disabled while the immutable local dev Cloud target owns runtime configuration; restart the development process to reload safely.", 409);
            return true;
        }
        let next;
        try {
            next = loadElizaConfig();
        }
        catch (err) {
            const detail = err instanceof Error ? err.message : String(err);
            error(res, `Config reload failed: ${detail}`, 400);
            return true;
        }
        const currentRecord = asConfigRecord(config);
        const nextRecord = asConfigRecord(next);
        const diff = computeReloadDiff(currentRecord, nextRecord);
        await applyReloadedConfig({
            state: config,
            next,
            runtime,
            isBlockedEnvKey,
        });
        if (isElizaSettingsDebugEnabled()) {
            logger.debug(`[eliza][settings][api] POST /api/config/reload applied=[${diff.applied.join(",")}] requiresRestart=[${diff.requiresRestart.join(",")}]`);
        }
        json(res, {
            reloaded: true,
            applied: diff.applied,
            requiresRestart: diff.requiresRestart,
        });
        return true;
    }
    // ── GET /api/config ──────────────────────────────────────────────────────
    if (method === "GET" && pathname === "/api/config") {
        if (isElizaSettingsDebugEnabled()) {
            const cfg = config;
            const cloud = cfg.cloud;
            logger.debug(`[eliza][settings][api] GET /api/config → respond (redacted) topKeys=${Object.keys(cfg).sort().join(",")} cloud=${JSON.stringify(settingsDebugCloudSummary(cloud))}`);
        }
        json(res, redactConfigSecrets(asConfigRecord(config)));
        return true;
    }
    // ── PUT /api/config ─────────────────────────────────────────────────────
    if (method === "PUT" && pathname === "/api/config") {
        const body = await readJsonBody(req, res);
        if (!body)
            return true;
        if (isElizaSettingsDebugEnabled()) {
            const b = body;
            const cloudBefore = config.cloud;
            logger.debug(`[eliza][settings][api] PUT /api/config ← body topKeys=${Object.keys(b).sort().join(",")} snapshot=${JSON.stringify(sanitizeForSettingsDebug(b))}`);
            logger.debug(`[eliza][settings][api] PUT /api/config state.config.cloud(before)=${JSON.stringify(settingsDebugCloudSummary(cloudBefore))}`);
        }
        // --- Security: validate and safely merge config updates ----------------
        /**
         * Deep-merge `src` into `target`, only touching keys present in `src`.
         * Prevents prototype pollution by rejecting dangerous key names at every
         * level.  Performs a recursive merge for plain objects so that partial
         * updates don't wipe sibling keys.
         */
        function safeMerge(target, src) {
            for (const key of Object.keys(src)) {
                if (isBlockedObjectKey(key))
                    continue;
                const srcVal = src[key];
                const tgtVal = target[key];
                if (srcVal !== null &&
                    typeof srcVal === "object" &&
                    !Array.isArray(srcVal) &&
                    tgtVal !== null &&
                    typeof tgtVal === "object" &&
                    !Array.isArray(tgtVal)) {
                    safeMerge(tgtVal, srcVal);
                }
                else {
                    target[key] = srcVal;
                }
            }
        }
        // Filter to allowed top-level keys, then deep-merge.
        const filtered = {};
        for (const key of Object.keys(body)) {
            if (CONFIG_WRITE_ALLOWED_TOP_KEYS.has(key) && !isBlockedObjectKey(key)) {
                filtered[key] = body[key];
            }
        }
        if (configPatchExceedsBound(filtered)) {
            error(res, "config patch exceeds the nesting-depth limit", 400);
            return true;
        }
        // Capture authority before inspecting the untrusted patch. Persisted/API
        // config must never be able to manufacture the launcher-only marker.
        const devCloudAuthority = resolveDevCloudEnvAuthority();
        if (devCloudAuthority)
            stripDevCloudAuthorityOwnedTopology(filtered);
        // Security: keep auth/step-up secrets out of API-driven config writes so
        // secret rotation remains an out-of-band operation.
        if (filtered.env &&
            typeof filtered.env === "object" &&
            !Array.isArray(filtered.env)) {
            const envPatch = filtered.env;
            // Defense-in-depth: strip step-up secrets from persisted config before
            // merge, even though isBlockedEnvKey also blocks them during process.env
            // sync below. Keeping both guards prevents accidental persistence across
            // the API and environment-sync paths.
            delete envPatch.ELIZA_API_TOKEN;
            delete envPatch.ELIZA_WALLET_EXPORT_TOKEN;
            delete envPatch.ELIZA_TERMINAL_RUN_TOKEN;
            delete envPatch.EVM_PRIVATE_KEY;
            delete envPatch.SOLANA_PRIVATE_KEY;
            delete envPatch.GITHUB_TOKEN;
            if (envPatch.vars &&
                typeof envPatch.vars === "object" &&
                !Array.isArray(envPatch.vars)) {
                const vars = envPatch.vars;
                delete vars.ELIZA_API_TOKEN;
                delete vars.ELIZA_WALLET_EXPORT_TOKEN;
                delete vars.ELIZA_TERMINAL_RUN_TOKEN;
                delete vars.EVM_PRIVATE_KEY;
                delete vars.SOLANA_PRIVATE_KEY;
                delete vars.GITHUB_TOKEN;
            }
            // Defense-in-depth: strip ALL blocked env keys (including prefix-matched
            // families like GIT_CONFIG_KEY_*) from the env patch before safeMerge.
            // The explicit deletes above cover known step-up secrets; this loop
            // catches process-level injection keys (NODE_OPTIONS, LD_PRELOAD, etc.)
            // so they never reach saveElizaConfig() and the persistence→restart RCE
            // chain is closed.
            for (const key of Object.keys(envPatch)) {
                if (key === "vars" || key === "shellEnv")
                    continue;
                if (isBlockedEnvKey(key) || isDevCloudInternalEnvKey(key)) {
                    delete envPatch[key];
                }
            }
            if (envPatch.vars &&
                typeof envPatch.vars === "object" &&
                !Array.isArray(envPatch.vars)) {
                const innerVars = envPatch.vars;
                for (const key of Object.keys(innerVars)) {
                    if (isBlockedEnvKey(key) || isDevCloudInternalEnvKey(key)) {
                        delete innerVars[key];
                    }
                }
            }
            // A launcher authority owns Cloud-prefixed environment fields for the
            // lifetime of this development process. Do not merely suppress their
            // live process.env projection below: persisting a request value would
            // silently replace the operator's durable production/self-hosted config
            // for the next non-authoritative launch. Preserve unrelated env edits in
            // the same request.
            if (devCloudAuthority) {
                for (const key of Object.keys(envPatch)) {
                    if (key !== "vars" && isDevCloudEnvOwnedKey(key)) {
                        delete envPatch[key];
                    }
                }
                if (envPatch.vars &&
                    typeof envPatch.vars === "object" &&
                    !Array.isArray(envPatch.vars)) {
                    const vars = envPatch.vars;
                    for (const key of Object.keys(vars)) {
                        if (isDevCloudEnvOwnedKey(key))
                            delete vars[key];
                    }
                    if (Object.keys(vars).length === 0)
                        delete envPatch.vars;
                }
                if (Object.keys(envPatch).length === 0)
                    delete filtered.env;
            }
        }
        if (filtered.mcp &&
            typeof filtered.mcp === "object" &&
            !Array.isArray(filtered.mcp)) {
            const mcpPatch = filtered.mcp;
            if (mcpPatch.servers !== undefined) {
                if (!mcpPatch.servers ||
                    typeof mcpPatch.servers !== "object" ||
                    Array.isArray(mcpPatch.servers)) {
                    error(res, "mcp.servers must be a JSON object", 400);
                    return true;
                }
                const mcpRejection = await resolveMcpServersRejection(mcpPatch.servers);
                if (mcpRejection) {
                    error(res, mcpRejection, 400);
                    return true;
                }
                const mcpTerminalRejection = resolveMcpTerminalAuthorizationRejection(req, mcpPatch.servers, body);
                if (mcpTerminalRejection) {
                    error(res, `Configuring stdio MCP servers via /api/config requires terminal authorization. ${mcpTerminalRejection.reason}`, mcpTerminalRejection.status);
                    return true;
                }
            }
        }
        // Strip "[REDACTED]" from the whole patch (GET → PUT round-trips).
        stripRedactedPlaceholderValuesDeep(filtered);
        const explicitConnectionRequested = Object.hasOwn(body, "connection");
        const canonicalDeploymentTargetRequested = Object.hasOwn(filtered, "deploymentTarget");
        const canonicalLinkedAccountsRequested = Object.hasOwn(filtered, "linkedAccounts");
        const canonicalServiceRoutingRequested = Object.hasOwn(filtered, "serviceRouting");
        const normalizedDeploymentTarget = canonicalDeploymentTargetRequested
            ? normalizeDeploymentTargetConfig(filtered.deploymentTarget)
            : undefined;
        const normalizedLinkedAccounts = canonicalLinkedAccountsRequested
            ? normalizeLinkedAccountFlagsConfig(filtered.linkedAccounts)
            : undefined;
        const normalizedServiceRouting = canonicalServiceRoutingRequested
            ? normalizeServiceRoutingConfig(filtered.serviceRouting)
            : undefined;
        if (explicitConnectionRequested) {
            error(res, "connection patches are no longer supported; update deploymentTarget, linkedAccounts, and serviceRouting directly", 400);
            return true;
        }
        if (isElizaSettingsDebugEnabled()) {
            logger.debug(`[eliza][settings][api] PUT /api/config filtered topKeys=${Object.keys(filtered).sort().join(",")} snapshot=${JSON.stringify(sanitizeForSettingsDebug(filtered))}`);
        }
        let nextConfig;
        try {
            // structuredClone preserves the complete config graph instead of using
            // a JSON round-trip that would silently drop or rewrite values.
            nextConfig = structuredClone(config);
        }
        catch (err) {
            logger.warn(`[api] Config update staging failed: ${err instanceof Error ? err.message : err}`);
            // error-policy:J1 route boundary translates an internal staging failure.
            error(res, "Config update could not be staged", 500);
            return true;
        }
        safeMerge(asConfigRecord(nextConfig), filtered);
        if (filtered.env &&
            typeof filtered.env === "object" &&
            !Array.isArray(filtered.env)) {
            // Keep the staged config clean: drop empty env.vars entries so we don't
            // persist null/empty-string tombstones forever.
            const cfgEnv = asConfigRecord(nextConfig).env;
            if (cfgEnv && typeof cfgEnv === "object" && !Array.isArray(cfgEnv)) {
                const cfgVars = cfgEnv.vars;
                if (cfgVars && typeof cfgVars === "object" && !Array.isArray(cfgVars)) {
                    for (const [k, v] of Object.entries(cfgVars)) {
                        if (typeof v !== "string" || !v.trim()) {
                            delete cfgVars[k];
                        }
                    }
                }
            }
        }
        if (canonicalDeploymentTargetRequested ||
            canonicalLinkedAccountsRequested ||
            canonicalServiceRoutingRequested) {
            applyCanonicalFirstRunConfig(nextConfig, {
                deploymentTarget: normalizedDeploymentTarget,
                linkedAccounts: normalizedLinkedAccounts,
                serviceRouting: normalizedServiceRouting,
            });
        }
        try {
            saveElizaConfig(nextConfig);
            if (isElizaSettingsDebugEnabled()) {
                const cfg = asConfigRecord(nextConfig);
                const cloud = cfg.cloud;
                logger.debug(`[eliza][settings][api] PUT /api/config → saveElizaConfig OK cloud(after)=${JSON.stringify(settingsDebugCloudSummary(cloud))}`);
            }
        }
        catch (err) {
            logger.warn(`[api] Config save failed: ${err instanceof Error ? err.message : err}`);
            // error-policy:J1 route boundary translates a persistence failure.
            error(res, "Config update could not be persisted", 500);
            return true;
        }
        const previousConfig = structuredClone(config);
        replaceConfigInPlace(config, nextConfig);
        // Synchronise env only after persistence succeeds so a failed write cannot
        // leave process.env ahead of durable and in-memory configuration.
        if (filtered.env &&
            typeof filtered.env === "object" &&
            !Array.isArray(filtered.env)) {
            const envPatch = filtered.env;
            // 1) env.vars.* (preferred)
            const vars = envPatch.vars;
            if (vars && typeof vars === "object" && !Array.isArray(vars)) {
                for (const [k, v] of Object.entries(vars)) {
                    if (isBlockedEnvKey(k) ||
                        isDevCloudInternalEnvKey(k) ||
                        (devCloudAuthority && isDevCloudEnvOwnedKey(k))) {
                        continue;
                    }
                    const str = typeof v === "string" ? v : "";
                    if (str.trim()) {
                        process.env[k] = str;
                    }
                    else {
                        delete process.env[k];
                    }
                }
            }
            // 2) Direct env.* string keys (legacy)
            for (const [k, v] of Object.entries(envPatch)) {
                if (k === "vars" || k === "shellEnv")
                    continue;
                if (isBlockedEnvKey(k) ||
                    isDevCloudInternalEnvKey(k) ||
                    (devCloudAuthority && isDevCloudEnvOwnedKey(k))) {
                    continue;
                }
                if (typeof v !== "string")
                    continue;
                if (v.trim())
                    process.env[k] = v;
                else
                    delete process.env[k];
            }
        }
        if (runtime) {
            reconcileConfigEnvSettings(runtime, previousConfig, config);
            reconcileDirectTextModelSettings(runtime, previousConfig, config);
        }
        json(res, redactConfigSecrets(asConfigRecord(config)));
        return true;
    }
    return false;
}
