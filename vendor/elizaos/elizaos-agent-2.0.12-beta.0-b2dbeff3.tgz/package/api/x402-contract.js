var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
/**
 * Contract consumed from the optional x402 plugin. Keeping this interface in
 * the host avoids an ambient declaration for a package that may be absent and
 * gives every dynamic-loader boundary one versioned shape to validate.
 */
import { logger } from "@elizaos/core";
/**
 * Vet a resolved `@elizaos/plugin-x402` module: return it only when it exposes
 * usable payment helpers, otherwise `null`. The mobile bundle aliases the
 * plugin to a null stub whose exports are no-op proxies (flagged
 * `__mobileStub`), so `createPaymentAwareHandler` would return `undefined`.
 */
function vetX402Module(mod) {
    if (mod == null)
        return null;
    if (mod.__mobileStub)
        return null;
    const candidate = mod;
    if (typeof candidate.createPaymentAwareHandler !== "function" ||
        typeof candidate.isRoutePaymentWrapped !== "function") {
        return null;
    }
    return candidate;
}
let x402PaymentModule = null;
let x402PaymentModulePromise = null;
/**
 * Load the optional payment plugin for route dispatch. `null` means payment
 * cannot be enforced in this process (package not installed, or mobile stub).
 * Every route dispatcher must then refuse an x402-declared route with
 * {@link X402_ENFORCEMENT_UNAVAILABLE}; a paid route is never served unpaid.
 */
export function loadX402PaymentModule() {
    if (x402PaymentModule)
        return Promise.resolve(x402PaymentModule);
    // Variable specifier keeps Vite's import-analysis from eagerly resolving the
    // optional plugin's dist (which is absent in the unit lane / mobile bundle).
    const specifier = "@elizaos/plugin-x402";
    x402PaymentModulePromise ??= import(__rewriteRelativeImportExtension(/* @vite-ignore */ specifier))
        .then((mod) => {
        const vetted = vetX402Module(mod);
        if (vetted)
            x402PaymentModule = vetted;
        return vetted;
    })
        .catch((err) => {
        // The refusal is the response; the load failure is still reported so a
        // broken install is not mistaken for an absent optional plugin.
        logger.warn(`[x402] payment plugin failed to load; x402 routes are refused: ${err instanceof Error ? err.message : String(err)}`);
        return null;
    });
    return x402PaymentModulePromise;
}
/** Response every dispatcher returns for a paid route it cannot gate. */
export const X402_ENFORCEMENT_UNAVAILABLE = {
    status: 503,
    body: {
        error: "This route requires x402 payment, but payment enforcement is unavailable on this host.",
        code: "X402_ENFORCEMENT_UNAVAILABLE",
    },
};
