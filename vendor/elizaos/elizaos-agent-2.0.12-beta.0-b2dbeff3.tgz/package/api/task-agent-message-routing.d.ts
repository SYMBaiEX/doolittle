/**
 * Routes task-agent chat text back to the connector the task originated on.
 * Resolves the swarm coordinator's task context — session id to thread to room —
 * from explicit routing hints, or failing that by matching a `"<label>" needs a
 * provider login` message (or a single in-flight task), then delivers the text
 * through `runtime.sendMessageToTarget` on the resolved room's source connector.
 * Returns false when no room can be resolved.
 */
import { type AgentRuntime } from "@elizaos/core";
export interface TaskAgentChatRouting {
    sessionId?: string;
    threadId?: string;
    roomId?: string | null;
}
type RoutingRuntime = Pick<AgentRuntime, "getRoom" | "getService" | "sendMessageToTarget">;
export declare function routeTaskAgentTextToConnector(runtime: RoutingRuntime | null, text: string, source: string, routing?: TaskAgentChatRouting): Promise<boolean>;
export {};
