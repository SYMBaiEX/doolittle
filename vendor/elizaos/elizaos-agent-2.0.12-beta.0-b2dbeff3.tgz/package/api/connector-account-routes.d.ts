/**
 * Route handler for the connector-account namespace under
 * `/api/connectors/:provider/{accounts,oauth,audit}`: lists/creates/patches/
 * deletes stored connector accounts, drives the OAuth start/status/callback
 * flow, marks a default account, and reads redacted audit events. Every path
 * except the OAuth callback (which arrives from the external provider and is
 * left open) must pass the host `authorize` callback — absent an authorizer the
 * default is Forbidden. Owner-role assignment and privacy escalations require an
 * explicit client confirmation. Server-owned policy fields (owner bindings,
 * access gates, credential refs) are never accepted from HTTP bodies, and
 * secret-shaped metadata keys are stripped on write and redacted on read.
 */
import type http from "node:http";
import type { ReadJsonBodyOptions } from "@elizaos/host/protocol";
export interface ConnectorAccountRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: {
        runtime: import("@elizaos/core").IAgentRuntime | null;
    };
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    authorize?: (request: ConnectorAccountRouteAuthorizationRequest) => boolean | Promise<boolean>;
}
export interface ConnectorAccountRouteAuthorizationRequest {
    provider: string;
    namespace: "accounts" | "oauth" | "audit";
    method: string;
    pathname: string;
    action?: string;
    accountId?: string;
}
export declare function parseAuditLimit(value: string | undefined): number | "invalid";
export declare function handleConnectorAccountRoutes(ctx: ConnectorAccountRouteContext): Promise<boolean>;
