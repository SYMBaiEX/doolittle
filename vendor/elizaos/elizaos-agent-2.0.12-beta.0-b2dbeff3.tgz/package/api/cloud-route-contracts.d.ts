/**
 * Shared TypeScript contracts for the agent-side cloud route handlers: the
 * request-context and route-state shapes (proxy, billing/compat, relay, and
 * status) plus the handler function signatures they dispatch through. Types
 * only — the concrete implementations live in the cloud route modules and the
 * lazily loaded @elizaos/plugin-elizacloud.
 */
import type http from "node:http";
import type { createIntegrationTelemetrySpan } from "@elizaos/core";
import type { RouteHelpers } from "@elizaos/host/protocol";
import type { ServerState } from "./server-types.js";
export interface AgentCloudProxyRouteState {
    config: ServerState["config"];
    runtime: ServerState["runtime"];
}
export interface AgentCloudRouteState extends AgentCloudProxyRouteState {
    cloudManager: ServerState["cloudManager"];
    saveConfig: (config: ServerState["config"]) => void;
    createTelemetrySpan: typeof createIntegrationTelemetrySpan;
    restartRuntime: (reason: string) => Promise<boolean>;
}
export interface AgentCloudRelayRouteState {
    runtime?: {
        getService(type: string): unknown;
        getSetting?: (key: string) => string | number | boolean | null;
    };
}
export interface AgentCloudStatusRouteContext {
    res: http.ServerResponse;
    method: string;
    pathname: string;
    config: ServerState["config"];
    runtime: ServerState["runtime"];
    json: RouteHelpers["json"];
}
export type AgentCloudBillingRouteHandler = (req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: AgentCloudProxyRouteState) => Promise<boolean>;
export type AgentCloudCompatRouteHandler = AgentCloudBillingRouteHandler;
export type AgentCloudRelayRouteHandler = (req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: AgentCloudRelayRouteState, helpers: RouteHelpers) => Promise<boolean>;
export type AgentCloudRouteHandler = (req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: AgentCloudRouteState) => Promise<boolean>;
export type AgentCloudStatusRouteHandler = (ctx: AgentCloudStatusRouteContext) => Promise<boolean>;
