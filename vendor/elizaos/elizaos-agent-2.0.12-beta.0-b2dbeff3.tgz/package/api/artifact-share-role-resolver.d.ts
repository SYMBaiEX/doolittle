import { type UUID } from "@elizaos/core";
import { type TokenRoleResolver } from "./boundary-role-resolver.js";
/** The artifact share resolver's stable registry id. */
export declare const ARTIFACT_SHARE_RESOLVER_ID = "artifact-share-viewer";
/** Roles a share-viewer token may carry — never OWNER/ADMIN; elevated tiers use the trunk boundary. */
export type ArtifactShareViewerRole = "USER" | "GUEST";
/** Validated identity carried by one share-viewer token. */
export interface ArtifactShareViewerAccess {
    entityId: UUID;
    role: ArtifactShareViewerRole;
    /** Expiry, epoch seconds. */
    exp: number;
}
/**
 * Mint a share-viewer token for one entity. Server-side only (tests, and the
 * PERM-UX sharing journey once it lands). Throws when the signing secret is
 * not configured — minting must fail fast rather than emit dead tokens.
 */
export declare function issueArtifactShareViewerToken(input: {
    entityId: UUID;
    role: ArtifactShareViewerRole;
    ttlMs: number;
}, nowMs?: number): string;
/**
 * Parse + validate a share-viewer token: `null` when the secret is unset or
 * the token is absent, malformed, mis-signed, expired, or carries an invalid
 * entity/role. Never throws (resolver contract).
 */
export declare function resolveArtifactShareViewerToken(token: string | null | undefined, nowSeconds?: number): ArtifactShareViewerAccess | null;
/**
 * Read-only artifact route allowlist for share-viewer principals. A viewer
 * token is a disclosure capability, not an account: no mutations, no chat, no
 * admin surface.
 */
export declare function isArtifactShareScopedRoute(method: string, pathname: string): boolean;
/** The artifact share-viewer boundary-role resolver. */
export declare const artifactShareRoleResolver: TokenRoleResolver;
/**
 * Register the artifact share-viewer resolver with the trunk boundary-role
 * registry. Idempotent — safe from module load and server setup.
 */
export declare function registerArtifactShareRoleResolver(): () => void;
