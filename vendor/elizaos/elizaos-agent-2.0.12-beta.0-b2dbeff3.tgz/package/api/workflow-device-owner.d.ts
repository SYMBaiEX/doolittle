import { type IAgentRuntime } from "@elizaos/core";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
/** Bind local OWNER enrollment to the canonical workflow scope without changing
 * the authenticated subject used by phone approvals. No request fields choose it. */
export declare function workflowDeviceOwner(runtime: IAgentRuntime, authorization: AgentHttpRequestAuthorization | undefined, subjectUserId: string): string;
