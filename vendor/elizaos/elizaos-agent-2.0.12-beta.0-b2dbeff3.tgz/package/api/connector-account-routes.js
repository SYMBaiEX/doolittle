/**
 * Route handler for the connector-account namespace under
 * `/api/connectors/:provider/{accounts,oauth,audit}`: lists/creates/patches/
 * deletes stored connector accounts, drives the OAuth start/status/callback
 * flow, marks a default account, and reads redacted audit events. Every path
 * except the OAuth callback (which arrives from the external provider and is
 * left open) must pass the host `authorize` callback — absent an authorizer the
 * default is Forbidden. Owner-role assignment and privacy escalations require an
 * explicit client confirmation. Server-owned policy fields (owner bindings,
 * access gates, credential refs) are never accepted from HTTP bodies, and
 * secret-shaped metadata keys are stripped on write and redacted on read.
 */
import { CONNECTOR_JSON_UNBOUNDED, cloneConnectorJsonObject, DEFAULT_PRIVACY_LEVEL, ElizaError, getConnectorAccountManager, isPrivacyLevel, parseCanonicalInteger, } from "@elizaos/core";
import { extractRows } from "@elizaos/plugin-sql";
import * as zod from "zod";
import { BLOCKED_OBJECT_GRAPH_UNBOUNDED, cloneWithoutBlockedObjectKeys, isBlockedObjectKey, } from "./blocked-object-keys.js";
import { resolveDirectRequestOrigin } from "./request-origin.js";
import { decodePathComponent } from "./server-helpers.js";
const z = zod.z ?? zod;
const CONNECTORS_PREFIX = "/api/connectors/";
const OAUTH_REDIRECT_STATUS = 303;
const metadataSchema = z.record(z.string(), z.unknown()).optional();
const privacyLevelSchema = z.enum([
    "owner_only",
    "team_visible",
    "semi_public",
    "public",
]);
const confirmationSchema = z
    .object({
    role: z.string().trim().min(1).max(80).optional(),
    privacy: z.string().trim().min(1).max(80).optional(),
    publicAcknowledged: z.boolean().optional(),
})
    .optional();
const AUDIT_REDACTED = "[REDACTED]";
/** Served in place of stored metadata whose graph exceeds the bounded walk. */
const AUDIT_UNBOUNDED = "[UNBOUNDED]";
const UNBOUNDED_METADATA_MESSAGE = "Connector account metadata exceeds the bounded walk budget";
const AUDIT_SECRET_KEY_PATTERN = /(access|refresh|id)?_?token|secret|password|credential|authorization|cookie|code[_-]?verifier|codeVerifier|client[_-]?secret|api_?key|private_?key|oauth_?code|state/i;
const CLIENT_RESERVED_METADATA_KEYS = new Set([
    "accessgate",
    "credentialrefs",
    "credentialrefstorage",
    "isdefault",
    "oauthcredentialrefs",
    "oauthcredentialversion",
    "ownerbindingid",
    "owneridentityid",
    "privacy",
    "purpose",
    "role",
    "status",
]);
function configuredConnectorOrigin(ctx) {
    const configuredExternalBase = ctx.state.runtime?.getSetting?.("ELIZA_EXTERNAL_BASE_URL");
    if (typeof configuredExternalBase === "string" &&
        configuredExternalBase.trim()) {
        return configuredExternalBase.trim();
    }
    return resolveDirectRequestOrigin(ctx.req);
}
function nonEmptyMetadataString(metadata, key) {
    const value = metadata?.[key];
    if (typeof value !== "string")
        return undefined;
    const trimmed = value.trim();
    return trimmed || undefined;
}
/**
 * OAuth return targets come from the initiating browser and are persisted in
 * flow metadata. Treat them as untrusted at the callback boundary: only an
 * http(s) target on the exact externally served origin may become a Location
 * header. Root-relative paths are resolved against that same authority.
 */
function resolveSafeConnectorOAuthReturnUrl(value, servedOrigin) {
    if (typeof value !== "string" || !value.trim() || !servedOrigin)
        return null;
    try {
        const served = new URL(servedOrigin);
        if ((served.protocol !== "http:" && served.protocol !== "https:") ||
            served.username !== "" ||
            served.password !== "") {
            return null;
        }
        const target = new URL(value.trim(), served.origin);
        if ((target.protocol !== "http:" && target.protocol !== "https:") ||
            target.username !== "" ||
            target.password !== "" ||
            target.origin !== served.origin) {
            return null;
        }
        return target.toString();
    }
    catch {
        // error-policy:J3 OAuth return targets are untrusted input; malformed or
        // cross-origin values retain the normal JSON callback response.
        return null;
    }
}
function sendConnectorOAuthRedirect(res, location) {
    res.statusCode = OAUTH_REDIRECT_STATUS;
    res.setHeader("Location", location);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.end();
}
const accountInputSchema = z.object({
    id: z.string().trim().min(1).max(200).optional(),
    label: z.string().trim().min(1).max(200).optional(),
    role: z.string().trim().min(1).max(80).optional(),
    purpose: z
        .union([
        z.string().trim().min(1).max(80),
        z.array(z.string().trim().min(1).max(80)).min(1).max(20),
    ])
        .optional(),
    accessGate: z.string().trim().min(1).max(80).optional(),
    status: z.string().trim().min(1).max(80).optional(),
    enabled: z.boolean().optional(),
    privacy: privacyLevelSchema.optional(),
    externalId: z.string().trim().min(1).max(500).optional(),
    displayHandle: z.string().trim().min(1).max(500).optional(),
    ownerBindingId: z.string().trim().min(1).max(200).optional(),
    ownerIdentityId: z.string().trim().min(1).max(200).optional(),
    metadata: metadataSchema,
    confirmation: confirmationSchema,
});
const accountPatchSchema = accountInputSchema
    .omit({ id: true })
    .extend({
    externalId: z
        .union([z.string().trim().min(1).max(500), z.null()])
        .optional(),
    displayHandle: z
        .union([z.string().trim().min(1).max(500), z.null()])
        .optional(),
    ownerBindingId: z
        .union([z.string().trim().min(1).max(200), z.null()])
        .optional(),
    ownerIdentityId: z
        .union([z.string().trim().min(1).max(200), z.null()])
        .optional(),
})
    .refine((value) => Object.keys(value).length > 0, {
    message: "PATCH body must include at least one account field",
});
const oauthStartSchema = z.object({
    redirectUri: z.string().trim().url().optional(),
    accountId: z.string().trim().min(1).max(200).optional(),
    label: z.string().trim().min(1).max(200).optional(),
    scopes: z.array(z.string().trim().min(1).max(120)).max(50).optional(),
    metadata: metadataSchema,
});
function normalizeConnectorAccountRoleValue(value) {
    if (typeof value !== "string" || !value.trim())
        return undefined;
    const normalized = value.trim().toUpperCase();
    switch (normalized) {
        case "OWNER":
            return "OWNER";
        case "AGENT":
        case "SERVICE":
            return "AGENT";
        case "TEAM":
        case "ADMIN":
        case "MEMBER":
        case "VIEWER":
            return "TEAM";
        default:
            return normalized;
    }
}
function isConnectorAccountRoleValue(value) {
    return (typeof value === "string" &&
        ["OWNER", "AGENT", "TEAM"].includes(value.trim().toUpperCase()));
}
function normalizeConnectorAccountStatus(status) {
    switch (status) {
        case "disabled":
        case "revoked":
            return "disconnected";
        default:
            return status;
    }
}
const PRIVACY_RANK = {
    owner_only: 0,
    team_visible: 1,
    semi_public: 2,
    public: 3,
};
function accountPrivacy(account) {
    const value = account.metadata?.privacy;
    return isPrivacyLevel(value) ? value : DEFAULT_PRIVACY_LEVEL;
}
function requiresOwnerRoleConfirmation(existing, requestedRole) {
    return (normalizeConnectorAccountRoleValue(requestedRole) === "OWNER" &&
        normalizeConnectorAccountRoleValue(existing.role) !== "OWNER");
}
function hasOwnerRoleConfirmation(confirmation) {
    return confirmation?.role?.trim().toUpperCase() === "OWNER";
}
function requiresPrivacyConfirmation(existing, requestedPrivacy) {
    return Boolean(requestedPrivacy &&
        PRIVACY_RANK[requestedPrivacy] > PRIVACY_RANK[accountPrivacy(existing)]);
}
function hasPrivacyConfirmation(confirmation, requestedPrivacy) {
    const phrase = confirmation?.privacy?.trim().toUpperCase();
    if (requestedPrivacy === "public") {
        return phrase === "PUBLIC" && confirmation?.publicAcknowledged === true;
    }
    return phrase === "SHARE";
}
const INVALID_CONNECTOR_SCOPED_PATH = Symbol("invalid-connector-scoped-path");
function parseConnectorScopedPath(pathname, res) {
    if (!pathname.startsWith(CONNECTORS_PREFIX)) {
        return null;
    }
    const encodedSegments = pathname
        .slice(CONNECTORS_PREFIX.length)
        .split("/")
        .filter(Boolean);
    const segments = [];
    for (const segment of encodedSegments) {
        const decoded = decodePathComponent(segment, res, "connector route");
        if (decoded === null) {
            return INVALID_CONNECTOR_SCOPED_PATH;
        }
        segments.push(decoded);
    }
    if (segments.length < 2)
        return null;
    const provider = segments[0]?.trim().toLowerCase() ?? "";
    const namespace = segments[1];
    if (!provider ||
        (namespace !== "accounts" && namespace !== "oauth" && namespace !== "audit")) {
        return null;
    }
    return {
        provider,
        namespace,
        rest: segments.slice(2),
    };
}
function isUnauthenticatedOAuthCallback(parsedPath, method) {
    return (parsedPath.namespace === "oauth" &&
        parsedPath.rest[0] === "callback" &&
        (method === "GET" || method === "POST"));
}
function authorizationRequestForPath(parsedPath, method, pathname) {
    const [first, second] = parsedPath.rest;
    const accountId = parsedPath.namespace === "accounts" && first && first !== "events"
        ? first
        : undefined;
    const action = parsedPath.namespace === "accounts"
        ? second
        : parsedPath.namespace === "oauth" || parsedPath.namespace === "audit"
            ? first
            : undefined;
    return {
        provider: parsedPath.provider,
        namespace: parsedPath.namespace,
        method,
        pathname,
        ...(action ? { action } : {}),
        ...(accountId ? { accountId } : {}),
    };
}
function normalizeMetadataKey(key) {
    return key.replace(/[-_\s]/g, "").toLowerCase();
}
function isClientReservedMetadataKey(key) {
    return CLIENT_RESERVED_METADATA_KEYS.has(normalizeMetadataKey(key));
}
/**
 * `metadataSchema` is `z.record(z.string(), z.unknown())`, so a caller-supplied
 * connector-account body may nest arbitrarily. Both metadata walks therefore
 * run on the shared bounded walker exported by `./blocked-object-keys.ts`
 * (depth cap, node budget, path-local WeakSet cycle guard, descriptor-only
 * reflection, typed `BLOCKED_OBJECT_GRAPH_UNBOUNDED` failure) rather than
 * recursing once per nesting level. Blocked keys are dropped by the walker
 * itself; the key policies below carry the connector-specific rules.
 */
function cleanMetadataValue(value) {
    return cloneWithoutBlockedObjectKeys(value, {
        keyAction: (key) => AUDIT_SECRET_KEY_PATTERN.test(key) || isClientReservedMetadataKey(key)
            ? "drop"
            : "keep",
    });
}
function cleanMetadata(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return undefined;
    }
    const cleaned = cleanMetadataValue(value);
    return cleaned;
}
function isUnboundedMetadataGraph(error) {
    return (error instanceof ElizaError &&
        (error.code === BLOCKED_OBJECT_GRAPH_UNBOUNDED ||
            error.code === CONNECTOR_JSON_UNBOUNDED));
}
/**
 * Validate sanitized metadata against the stricter durable-storage projection
 * before the manager can invoke a registered provider callback. The route
 * walker intentionally has a looser budget, so relying on the adapter alone
 * would allow a provider side effect before persistence rejects the patch.
 */
function validatePatchMetadataForStorage(patch) {
    if (patch.metadata === undefined)
        return patch;
    return {
        ...patch,
        metadata: cloneConnectorJsonObject(patch.metadata),
    };
}
function redactAuditMetadata(value) {
    try {
        return cloneWithoutBlockedObjectKeys(value, {
            keyAction: (key) => AUDIT_SECRET_KEY_PATTERN.test(key) ? "redact" : "keep",
            redactedValue: AUDIT_REDACTED,
        });
    }
    catch (error) {
        // error-policy:J4 metadata already at rest may exceed the walk budget (it
        // could have been written before this bound existed, or by an in-process
        // writer that does not pass through this route). Serve an explicit marker
        // so a single stored value cannot 500 every subsequent read; the reader is
        // told the value was withheld rather than handed a silent truncation.
        if (!isUnboundedMetadataGraph(error))
            throw error;
        return AUDIT_UNBOUNDED;
    }
}
function accountPatchFromBody(body, baseMetadata) {
    const purposeValues = Array.isArray(body.purpose)
        ? body.purpose
        : body.purpose
            ? [body.purpose]
            : [];
    const role = normalizeConnectorAccountRoleValue(body.role) ??
        purposeValues
            .map((value) => normalizeConnectorAccountRoleValue(value))
            .find((value) => Boolean(value));
    const purposeValuesWithoutRoles = purposeValues.filter((value) => !isConnectorAccountRoleValue(value));
    const purpose = purposeValuesWithoutRoles.length === 0
        ? undefined
        : Array.isArray(body.purpose)
            ? purposeValuesWithoutRoles
            : purposeValuesWithoutRoles[0];
    const metadata = cleanMetadata(body.metadata);
    const nextMetadata = metadata || body.privacy
        ? {
            ...(baseMetadata ?? {}),
            ...(metadata ?? {}),
            ...(body.privacy ? { privacy: body.privacy } : {}),
        }
        : undefined;
    const status = body.status ??
        (body.enabled === false
            ? "disabled"
            : body.enabled === true
                ? "connected"
                : undefined);
    return {
        label: body.label,
        role,
        purpose,
        status,
        externalId: body.externalId,
        displayHandle: body.displayHandle,
        // Server-owned account policy fields are intentionally not accepted from
        // public HTTP bodies. Providers/pairing flows set owner bindings and access
        // gates after verification through the manager API.
        metadata: nextMetadata,
    };
}
function serializeAccount(account) {
    const metadata = account.metadata ?? {};
    const handle = account.displayHandle ??
        (typeof metadata.handle === "string" ? metadata.handle : undefined);
    return {
        id: account.id,
        provider: account.provider,
        label: account.label ??
            account.displayHandle ??
            account.externalId ??
            account.id,
        role: normalizeConnectorAccountRoleValue(account.role) ?? "OWNER",
        purpose: account.purpose,
        privacy: isPrivacyLevel(metadata.privacy)
            ? metadata.privacy
            : DEFAULT_PRIVACY_LEVEL,
        accessGate: account.accessGate,
        status: normalizeConnectorAccountStatus(account.status),
        externalId: account.externalId,
        handle,
        displayHandle: account.displayHandle,
        ownerBindingId: account.ownerBindingId,
        ownerIdentityId: account.ownerIdentityId,
        isDefault: metadata.isDefault === true && isUsableDefaultAccount(account),
        enabled: account.status !== "disabled" && account.status !== "revoked",
        createdAt: account.createdAt,
        updatedAt: account.updatedAt,
        // The refresh action stores the sync time in metadata; the account card
        // reads it from the top level.
        lastSyncedAt: typeof metadata.lastSyncedAt === "number"
            ? metadata.lastSyncedAt
            : undefined,
        metadata: redactAuditMetadata(metadata),
    };
}
function isUsableDefaultAccount(account) {
    return (account.status === "connected" &&
        account.accessGate !== "disabled" &&
        account.metadata?.disabled !== true);
}
function getDefaultAccountId(accounts) {
    return (accounts.find((account) => account.metadata?.isDefault === true && isUsableDefaultAccount(account))?.id ??
        accounts.find((account) => isUsableDefaultAccount(account))?.id ??
        null);
}
function serializeFlow(flow) {
    return {
        id: flow.id,
        provider: flow.provider,
        state: flow.state,
        status: flow.status,
        accountId: flow.accountId,
        authUrl: flow.authUrl,
        error: flow.error,
        redirectUri: flow.redirectUri,
        createdAt: flow.createdAt,
        updatedAt: flow.updatedAt,
        expiresAt: flow.expiresAt,
        metadata: redactAuditMetadata(flow.metadata),
    };
}
function queryRecord(req) {
    const url = new URL(req.url ?? "/", "http://localhost");
    const record = {};
    for (const [key, value] of url.searchParams.entries()) {
        record[key] = value;
    }
    return record;
}
function sqlQuote(value) {
    return `'${value.replace(/'/g, "''")}'`;
}
export function parseAuditLimit(value) {
    if (!value)
        return 50;
    const parsed = parseCanonicalInteger(value, {
        min: 1,
        max: 100,
        clamp: true,
    });
    return parsed === undefined ? 50 : parsed;
}
function toEpochMillis(value) {
    if (typeof value === "number" && Number.isFinite(value))
        return value;
    if (value instanceof Date)
        return value.getTime();
    if (typeof value === "string" && value.trim()) {
        const parsed = Date.parse(value);
        return Number.isFinite(parsed) ? parsed : undefined;
    }
    return undefined;
}
function serializeAuditEvent(event) {
    const accountId = event.accountId ?? event.account_id ?? null;
    const agentId = event.agentId ?? event.agent_id;
    const actorId = event.actorId ?? event.actor_id ?? null;
    const createdAt = toEpochMillis(event.createdAt ?? event.created_at);
    return {
        id: String(event.id),
        accountId: accountId === null || accountId === undefined ? null : String(accountId),
        agentId: agentId === undefined ? undefined : String(agentId),
        provider: String(event.provider),
        actorId: actorId === null || actorId === undefined ? null : String(actorId),
        action: String(event.action),
        outcome: String(event.outcome),
        metadata: redactAuditMetadata(event.metadata ?? {}),
        createdAt,
    };
}
function isConnectorAccountAuditEventLike(event) {
    if (typeof event !== "object" || event === null || Array.isArray(event)) {
        return false;
    }
    const record = event;
    return (typeof record.id === "string" &&
        typeof record.provider === "string" &&
        typeof record.action === "string" &&
        typeof record.outcome === "string");
}
async function executeRawAuditQuery(adapter, query) {
    const db = adapter.db ?? adapter.getDatabase?.();
    if (!db?.execute)
        return [];
    const { sql } = (await import("drizzle-orm"));
    const result = await db.execute(sql.raw(query));
    return extractRows(result);
}
async function listConnectorAuditEvents(args) {
    const runtimeWithAdapter = args.runtime;
    const adapter = runtimeWithAdapter?.adapter;
    const agentId = typeof runtimeWithAdapter?.agentId === "string"
        ? runtimeWithAdapter.agentId
        : undefined;
    if (!adapter)
        return [];
    if (typeof adapter.listConnectorAccountAuditEvents === "function") {
        return adapter.listConnectorAccountAuditEvents({
            agentId,
            provider: args.provider,
            accountId: args.accountId,
            action: args.action,
            outcome: args.outcome,
            limit: args.limit,
        });
    }
    const conditions = [`provider = ${sqlQuote(args.provider)}`];
    if (agentId)
        conditions.push(`agent_id = ${sqlQuote(agentId)}`);
    if (args.accountId)
        conditions.push(`account_id = ${sqlQuote(args.accountId)}`);
    if (args.action)
        conditions.push(`action = ${sqlQuote(args.action)}`);
    if (args.outcome)
        conditions.push(`outcome = ${sqlQuote(args.outcome)}`);
    const rows = await executeRawAuditQuery(adapter, `SELECT id, account_id, agent_id, provider, actor_id, action, outcome, metadata, created_at
       FROM connector_account_audit_events
      WHERE ${conditions.join(" AND ")}
      ORDER BY created_at DESC, id DESC
      LIMIT ${args.limit}`);
    return rows.filter(isConnectorAccountAuditEventLike);
}
export async function handleConnectorAccountRoutes(ctx) {
    const { req, res, method, pathname, json, error, readJsonBody } = ctx;
    const parsedPath = parseConnectorScopedPath(pathname, res);
    if (parsedPath === INVALID_CONNECTOR_SCOPED_PATH) {
        return true;
    }
    if (!parsedPath) {
        return false;
    }
    const { provider, namespace, rest } = parsedPath;
    if (isBlockedObjectKey(provider)) {
        error(res, "Invalid connector provider", 400);
        return true;
    }
    if (!isUnauthenticatedOAuthCallback(parsedPath, method)) {
        if (!ctx.authorize) {
            error(res, "Forbidden", 403);
            return true;
        }
        const allowed = await ctx.authorize(authorizationRequestForPath(parsedPath, method, pathname));
        if (!allowed) {
            error(res, "Forbidden", 403);
            return true;
        }
    }
    const manager = getConnectorAccountManager(ctx.state.runtime);
    if (namespace === "accounts") {
        if (rest.length === 0 && method === "GET") {
            const accounts = await manager.listAccounts(provider);
            json(res, {
                provider,
                defaultAccountId: getDefaultAccountId(accounts),
                accounts: accounts.map(serializeAccount),
            });
            return true;
        }
        if (rest.length === 0 && method === "POST") {
            const body = await readJsonBody(req, res);
            if (!body)
                return true;
            const parsed = accountInputSchema.safeParse(body);
            if (!parsed.success) {
                error(res, parsed.error.issues[0]?.message ?? "Invalid account body", 400);
                return true;
            }
            if (parsed.data.privacy &&
                parsed.data.privacy !== DEFAULT_PRIVACY_LEVEL &&
                !hasPrivacyConfirmation(parsed.data.confirmation, parsed.data.privacy)) {
                error(res, "Privacy escalation requires confirmation", 403);
                return true;
            }
            let createPatch;
            try {
                createPatch = validatePatchMetadataForStorage(accountPatchFromBody(parsed.data));
            }
            catch (err) {
                // error-policy:J1 route boundary — an over-budget caller body at either
                // the route-walk or durable-storage budget becomes a 400 before any
                // provider callback. Every other error is rethrown.
                if (!isUnboundedMetadataGraph(err))
                    throw err;
                error(res, UNBOUNDED_METADATA_MESSAGE, 400);
                return true;
            }
            const account = await manager.createAccount(provider, {
                ...createPatch,
                ...(parsed.data.id ? { id: parsed.data.id } : {}),
            });
            json(res, serializeAccount(account), 201);
            return true;
        }
        if (rest.length === 1) {
            const accountId = rest[0];
            if (!accountId || isBlockedObjectKey(accountId)) {
                error(res, "Invalid connector account id", 400);
                return true;
            }
            if (method === "GET") {
                const account = await manager.getAccount(provider, accountId);
                if (!account) {
                    error(res, "Connector account not found", 404);
                    return true;
                }
                json(res, serializeAccount(account));
                return true;
            }
            if (method === "PATCH") {
                const body = await readJsonBody(req, res);
                if (!body)
                    return true;
                const parsed = accountPatchSchema.safeParse(body);
                if (!parsed.success) {
                    error(res, parsed.error.issues[0]?.message ?? "Invalid account body", 400);
                    return true;
                }
                const existing = await manager.getAccount(provider, accountId);
                if (!existing) {
                    error(res, "Connector account not found", 404);
                    return true;
                }
                let patch;
                try {
                    patch = validatePatchMetadataForStorage(accountPatchFromBody(parsed.data, existing.metadata));
                }
                catch (err) {
                    // error-policy:J1 route boundary — same pre-provider translation as
                    // the POST path above; every unrelated failure is rethrown.
                    if (!isUnboundedMetadataGraph(err))
                        throw err;
                    error(res, UNBOUNDED_METADATA_MESSAGE, 400);
                    return true;
                }
                if (requiresOwnerRoleConfirmation(existing, patch.role) &&
                    !hasOwnerRoleConfirmation(parsed.data.confirmation)) {
                    error(res, "OWNER role assignment requires confirmation", 403);
                    return true;
                }
                const requestedPrivacy = parsed.data.privacy;
                if (requestedPrivacy &&
                    requiresPrivacyConfirmation(existing, requestedPrivacy) &&
                    !hasPrivacyConfirmation(parsed.data.confirmation, requestedPrivacy)) {
                    error(res, "Privacy escalation requires confirmation", 403);
                    return true;
                }
                const account = await manager.patchAccount(provider, accountId, patch);
                if (!account) {
                    error(res, "Connector account not found", 404);
                    return true;
                }
                json(res, serializeAccount(account));
                return true;
            }
            if (method === "DELETE") {
                const deleted = await manager.deleteAccount(provider, accountId);
                json(res, { deleted });
                return true;
            }
        }
        if (rest.length === 2 && method === "POST") {
            const [accountId, action] = rest;
            if (!accountId || isBlockedObjectKey(accountId)) {
                error(res, "Invalid connector account id", 400);
                return true;
            }
            const account = await manager.getAccount(provider, accountId);
            if (!account) {
                error(res, "Connector account not found", 404);
                return true;
            }
            if (action === "test") {
                const ok = isUsableDefaultAccount(account);
                json(res, {
                    ok,
                    provider,
                    account: serializeAccount(account),
                    status: normalizeConnectorAccountStatus(account.status),
                });
                return true;
            }
            if (action === "refresh") {
                let refreshPatch;
                try {
                    // error-policy:J1 route boundary — the stored row may already sit at
                    // the durable-storage node budget; adding lastSyncedAt tips it over,
                    // and the rejection must land before any registered provider
                    // patchAccount callback fires. Every other error is rethrown.
                    refreshPatch = validatePatchMetadataForStorage({
                        metadata: {
                            ...(account.metadata ?? {}),
                            lastSyncedAt: Date.now(),
                        },
                    });
                }
                catch (err) {
                    if (!isUnboundedMetadataGraph(err))
                        throw err;
                    error(res, UNBOUNDED_METADATA_MESSAGE, 400);
                    return true;
                }
                const refreshed = await manager.patchAccount(provider, accountId, refreshPatch);
                json(res, {
                    ok: true,
                    provider,
                    account: serializeAccount(refreshed ?? account),
                    status: normalizeConnectorAccountStatus((refreshed ?? account).status),
                });
                return true;
            }
            if (action === "default") {
                if (!isUsableDefaultAccount(account)) {
                    error(res, "Only connected, enabled connector accounts can be default", 400);
                    return true;
                }
                const accounts = await manager.listAccounts(provider);
                // Plan-then-execute: construct and validate EVERY affected account's
                // patch before the first provider callback or row write. A later
                // over-budget row must not 400 after earlier rows have already
                // flipped — that would leave the provider's account set in a
                // partially mutated, zero-or-two-default state. Provider/DB failures
                // during execution still follow the manager's explicit partial-failure
                // contract; only deterministic validation is hoisted here.
                const plan = [];
                for (const item of accounts) {
                    const isTarget = item.id === accountId;
                    if (item.metadata?.isDefault === isTarget)
                        continue;
                    let defaultPatch;
                    try {
                        // error-policy:J1 route boundary — same pre-provider validation as
                        // refresh: a listed row near the storage budget must be rejected
                        // here, before ANY provider callback can run. Rethrow otherwise.
                        defaultPatch = validatePatchMetadataForStorage({
                            metadata: {
                                ...(item.metadata ?? {}),
                                isDefault: isTarget,
                            },
                        });
                    }
                    catch (err) {
                        if (!isUnboundedMetadataGraph(err))
                            throw err;
                        error(res, UNBOUNDED_METADATA_MESSAGE, 400);
                        return true;
                    }
                    plan.push({ id: item.id, patch: defaultPatch });
                }
                for (const step of plan) {
                    await manager.patchAccount(provider, step.id, step.patch);
                }
                const updatedAccounts = await manager.listAccounts(provider);
                const updatedAccount = updatedAccounts.find((item) => item.id === accountId) ?? account;
                json(res, {
                    ok: true,
                    provider,
                    account: serializeAccount(updatedAccount),
                    accounts: updatedAccounts.map(serializeAccount),
                    defaultAccountId: accountId,
                });
                return true;
            }
            error(res, "Connector account action not found", 404);
            return true;
        }
        error(res, "Connector account route not found", 404);
        return true;
    }
    if (namespace === "audit") {
        if (rest.length === 1 && rest[0] === "events" && method === "GET") {
            const query = queryRecord(req);
            const accountId = query.accountId?.trim() ?? "";
            const action = query.action?.trim() ?? "";
            const outcome = query.outcome?.trim() ?? "";
            if (outcome && outcome !== "success" && outcome !== "failure") {
                error(res, "outcome must be success or failure", 400);
                return true;
            }
            const limit = parseAuditLimit(query.limit);
            if (limit === "invalid") {
                error(res, "limit must be a canonical positive integer", 400);
                return true;
            }
            const events = await listConnectorAuditEvents({
                runtime: ctx.state.runtime,
                provider,
                accountId: accountId || undefined,
                action: action || undefined,
                outcome: outcome || undefined,
                limit,
            });
            json(res, {
                provider,
                events: events.map(serializeAuditEvent),
            });
            return true;
        }
        error(res, "Connector account audit route not found", 404);
        return true;
    }
    if (namespace === "oauth") {
        const action = rest[0];
        if (action === "start" && rest.length === 1 && method === "POST") {
            const body = await readJsonBody(req, res);
            if (!body)
                return true;
            const parsed = oauthStartSchema.safeParse(body);
            if (!parsed.success) {
                error(res, parsed.error.issues[0]?.message ?? "Invalid OAuth body", 400);
                return true;
            }
            try {
                // A configured external base is the authority behind a reverse proxy.
                // Otherwise use the direct TLS/Host request that passed the server Host
                // gate; arbitrary X-Forwarded-* headers must not bless a callback.
                const servedOrigin = configuredConnectorOrigin(ctx);
                const flow = await manager.startOAuth(provider, {
                    ...parsed.data,
                    ...(servedOrigin ? { servedOrigin } : {}),
                    metadata: cleanMetadata(parsed.data.metadata),
                });
                json(res, { provider, flow: serializeFlow(flow) }, 201);
            }
            catch (err) {
                error(res, err instanceof Error ? err.message : "Failed to start OAuth flow", 400);
            }
            return true;
        }
        if (action === "status" && method === "GET") {
            const query = queryRecord(req);
            const flowId = rest[1] ?? query.flowId ?? query.state;
            if (!flowId) {
                error(res, "Missing flowId or state", 400);
                return true;
            }
            const flow = await manager.getOAuthFlow(provider, flowId);
            if (!flow) {
                error(res, "OAuth flow not found", 404);
                return true;
            }
            json(res, { provider, flow: serializeFlow(flow) });
            return true;
        }
        if (action === "callback" && (method === "GET" || method === "POST")) {
            const query = queryRecord(req);
            const body = method === "POST"
                ? await readJsonBody(req, res)
                : undefined;
            if (method === "POST" && !body)
                return true;
            const state = typeof body?.state === "string" ? body.state : query.state;
            if (!state) {
                error(res, "Missing OAuth state", 400);
                return true;
            }
            try {
                const result = await manager.completeOAuth(provider, {
                    state,
                    code: typeof body?.code === "string" ? body.code : query.code,
                    error: typeof body?.error === "string" ? body.error : query.error,
                    errorDescription: typeof body?.error_description === "string"
                        ? body.error_description
                        : query.error_description,
                    query,
                    body: body ?? undefined,
                });
                const serializedFlow = serializeFlow(result.flow);
                if (method === "GET" && result.flow.status === "completed") {
                    const servedOrigin = configuredConnectorOrigin(ctx);
                    const redirectUrl = resolveSafeConnectorOAuthReturnUrl(result.redirectUrl, servedOrigin) ??
                        resolveSafeConnectorOAuthReturnUrl(nonEmptyMetadataString(result.flow.metadata, "redirectUrl"), servedOrigin);
                    if (redirectUrl) {
                        sendConnectorOAuthRedirect(res, redirectUrl);
                        return true;
                    }
                }
                json(res, {
                    provider,
                    ok: true,
                    flow: {
                        id: serializedFlow.id,
                        status: serializedFlow.status,
                        error: serializedFlow.error,
                    },
                    accountId: result.account?.id ?? result.flow.accountId,
                    redirectUrl: result.redirectUrl,
                });
            }
            catch (err) {
                error(res, err instanceof Error ? err.message : "Failed to complete OAuth flow", 400);
            }
            return true;
        }
        error(res, "Connector OAuth route not found", 404);
        return true;
    }
    return false;
}
