import type http from "node:http";
export interface AvatarRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
}
export declare function handleAvatarRoutes(ctx: AvatarRouteContext): Promise<boolean>;
