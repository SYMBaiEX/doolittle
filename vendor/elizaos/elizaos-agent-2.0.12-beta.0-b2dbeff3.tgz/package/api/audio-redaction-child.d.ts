/**
 * Bounds child-process execution for audio redaction's ffmpeg/ffprobe lane.
 *
 * The timeout and combined stdio budget prevent malformed media or a stuck
 * binary from pinning the agent or growing its memory use without limit.
 * Callers may redirect complete stdout to their own file descriptor; stderr
 * remains bounded and this runner never closes the caller-owned descriptor.
 */
/** Default wall-clock budget for one ffprobe/ffmpeg invocation. */
export declare const AUDIO_REDACTION_CHILD_TIMEOUT_MS = 30000;
/** Combined stdout+stderr budget before the child is killed. */
export declare const MAX_AUDIO_REDACTION_STDIO_BYTES = 1048576;
export type AudioRedactionChildResult = {
    code: number | null;
    stdout: string;
    stderr: string;
};
export type AudioRedactionChildErrorCode = "AUDIO_REDACTION_TIMEOUT" | "AUDIO_REDACTION_STDIO_OVERFLOW";
export declare class AudioRedactionChildError extends Error {
    readonly code: AudioRedactionChildErrorCode;
    constructor(message: string, code: AudioRedactionChildErrorCode);
}
/**
 * Spawn `bin` and collect utf8 stdio until exit, timeout, or the byte cap.
 */
export declare function runAudioRedactionChild(bin: string, args: readonly string[], options?: {
    timeoutMs?: number;
    maxStdioBytes?: number;
    stdoutFd?: number;
}): Promise<AudioRedactionChildResult>;
