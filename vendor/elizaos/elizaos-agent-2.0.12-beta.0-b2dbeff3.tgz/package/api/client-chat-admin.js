/**
 * Resolves the admin/owner entity id for the local client-chat surface. Prefers
 * the runtime's canonical owner id, then a previously resolved id, then the
 * configured `agents.defaults.adminEntityId`, falling back to core's
 * `deterministicOwnerEntityId` (agent-ID seed) — the same fallback LifeOps
 * reads, the scheduler, and the PA routes use — so chat-written owner
 * rows stay visible to every reader. The agent NAME seed survives only for the
 * degenerate no-runtime case. The resolved id is written back onto state as
 * both `adminEntityId` and `chatUserId`.
 */
import { deterministicOwnerEntityId, logger, resolveCanonicalOwnerId, stringToUuid, } from "@elizaos/core";
import { isUuidLike } from "./server-helpers.js";
export function resolveClientChatAdminEntityId(state) {
    const canonicalOwnerId = state.runtime && typeof state.runtime.getSetting === "function"
        ? resolveCanonicalOwnerId(state.runtime)
        : null;
    if (canonicalOwnerId && isUuidLike(canonicalOwnerId)) {
        state.adminEntityId = canonicalOwnerId;
        state.chatUserId = state.adminEntityId;
        return state.adminEntityId;
    }
    if (state.adminEntityId) {
        state.chatUserId = state.adminEntityId;
        return state.adminEntityId;
    }
    const configuredValue = state.config?.agents?.defaults?.adminEntityId;
    const configured = typeof configuredValue === "string" ? configuredValue.trim() : undefined;
    // The deterministic fallback is core's agent-ID seed, shared with LifeOps
    // reads and the scheduler. Seeding by agent NAME here forked the owner
    // `subject_id` between the chat write path and every read path; the name
    // seed remains only for the degenerate no-runtime case.
    const runtimeAgentId = state.runtime && typeof state.runtime.agentId === "string"
        ? state.runtime.agentId
        : null;
    const nextAdminEntityId = configured && isUuidLike(configured)
        ? configured
        : runtimeAgentId
            ? deterministicOwnerEntityId(runtimeAgentId)
            : stringToUuid(`${state.agentName}-admin-entity`);
    if (configured && !isUuidLike(configured)) {
        logger.warn(`[eliza-api] Invalid agents.defaults.adminEntityId "${configured}", using deterministic fallback`);
    }
    state.adminEntityId = nextAdminEntityId;
    state.chatUserId = nextAdminEntityId;
    return nextAdminEntityId;
}
