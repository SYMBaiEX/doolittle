/**
 * Awaits server-side resource teardown in reverse registration order. A failed
 * disposer is reported and the remaining resources still close, so shutdown is
 * complete and observable instead of spawning detached cleanup promises.
 */
export interface ServerResource {
    readonly name: string;
    dispose(): void | Promise<void>;
}
export interface ServerResources {
    add(resource: ServerResource): void;
    close(): Promise<void>;
}
export declare function createServerResources(reportFailure: (resource: string, error: unknown) => void): ServerResources;
export declare function closeServerResources(resources: readonly ServerResource[], reportError: (resource: string, error: unknown) => void): Promise<void>;
