/**
 * Diagnostics and observability HTTP routes for the local control API. Mounts:
 * GET/DELETE `/api/logs` (filtered read + clear of the in-memory log buffer;
 * `since` is a canonical epoch-ms or ISO cursor, same grammar as audit),
 * POST `/api/logs/export` (validated JSON/CSV download), GET `/api/agent/events`
 * (replayable autonomy/heartbeat event feed with runId/seq/after cursors), GET
 * `/api/security/audit` (filtered audit feed as a JSON snapshot or a live SSE
 * stream).
 * All reads come from process-local buffers/feeds supplied by the caller; the
 * export and audit paths validate and clamp every query/body parameter before
 * it is used.
 */
import type http from "node:http";
import type { ReadJsonBodyOptions, RouteHelpers, RouteRequestMeta } from "@elizaos/host/protocol";
interface LogEntryLike {
    timestamp: number;
    level: string;
    message?: string;
    source: string;
    tags: string[];
}
interface StreamEventEnvelopeLike {
    type: string;
    eventId: string;
    runId?: string;
    seq?: number;
}
interface AuditEntryLike {
    timestamp: string;
    type: string;
    summary: string;
    severity: string;
    metadata?: Record<string, string | number | boolean | null>;
}
type DiagnosticsSseInit = (res: http.ServerResponse) => void;
type DiagnosticsSseWriteJson = (res: http.ServerResponse, payload: unknown, event?: string) => void;
export interface DiagnosticsRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json"> {
    url: URL;
    logBuffer: LogEntryLike[];
    /** Drop all entries from the in-memory log buffer. Returns count cleared. */
    clearLogBuffer?: () => number;
    /** Read JSON body for the export endpoint. */
    readJsonBody?: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    error?: (res: http.ServerResponse, message: string, status?: number) => void;
    eventBuffer: StreamEventEnvelopeLike[];
    initSse?: DiagnosticsSseInit;
    writeSseJson?: DiagnosticsSseWriteJson;
    auditEventTypes: readonly string[];
    auditSeverities: readonly string[];
    getAuditFeedSize: () => number;
    queryAuditFeed: (query: {
        type?: string;
        severity?: string;
        sinceMs?: number;
        limit?: number;
    }) => AuditEntryLike[];
    subscribeAuditFeed: (subscriber: (entry: AuditEntryLike) => void) => () => void;
}
export declare function handleDiagnosticsRoutes(ctx: DiagnosticsRouteContext): Promise<boolean>;
export {};
