/**
 * HTTP route `POST /api/background/run-due-tasks` that forces the runtime's TASK
 * service to run its due scheduled tasks on demand (e.g. from an external
 * scheduler or a foreground nudge). Concurrent calls are coalesced through a
 * single in-flight run so overlapping requests share one pass rather than
 * stacking, and learn via the returned `coalesced` flag. Returns 503 when the
 * runtime or task service is unavailable.
 */
import type http from "node:http";
interface BackgroundTasksRuntime {
    getService(serviceType: string): unknown;
}
interface BackgroundTasksRouteState {
    runtime: BackgroundTasksRuntime | null;
}
export interface BackgroundTasksRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: BackgroundTasksRouteState;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
}
export declare function handleBackgroundTasksRoute({ method, pathname, state, json, res, }: BackgroundTasksRouteContext): Promise<boolean>;
export {};
