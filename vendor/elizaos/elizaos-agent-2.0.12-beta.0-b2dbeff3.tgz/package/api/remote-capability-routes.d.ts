/**
 * Mounts the remote-capability router API behind the authenticated gate. POST
 * /api/capability-router/connect validates and connects a remote capability
 * endpoint (direct, or a home-machine / mobile- / desktop-companion
 * provider) or provisions a cloud sandbox, syncs the resulting remote plugins
 * into the runtime, and persists endpoint config, per-endpoint module
 * allowlists, trust policies, and a bounded trust-audit trail to the config env
 * — redacting tokens from responses and from sanitized vars. GET/HEAD
 * /api/capability-router/assets/... proxies remote UI assets, platform-gated for
 * dynamic-loading and path-traversal-guarded. Endpoint baseUrls are SSRF-guarded
 * against private/loopback/link-local/internal targets.
 */
import type http from "node:http";
import { ElizaError, type IAgentRuntime } from "@elizaos/core";
import type { RouteHelpers, RouteRequestMeta } from "@elizaos/host/protocol";
import { type ConnectCloudCapabilitySandboxOptions, type ConnectCloudCapabilitySandboxResult } from "../services/remote-capability-cloud-sandbox.js";
import { type ConnectRemoteCapabilityEndpointProviderOptions, type ConnectRemoteCapabilityEndpointProviderResult } from "../services/remote-capability-endpoint-provider.js";
/**
 * A persisted capability-router config value (endpoints, module allowlists,
 * trust policies or the trust audit trail) exists but cannot be parsed. The
 * connect handler refuses to persist rather than rewriting the value as empty,
 * which would silently erase every stored endpoint, policy and audit record.
 */
export declare class CapabilityRouterPersistedStateError extends ElizaError {
    readonly name = "CapabilityRouterPersistedStateError";
    readonly key: string;
    constructor(key: string, reason: string, options?: {
        cause?: unknown;
    });
}
type JsonBodyReader = <T = Record<string, unknown>>(req: http.IncomingMessage, res: http.ServerResponse, options?: {
    requireObject?: boolean;
}) => Promise<T | null>;
export interface RemoteCapabilityRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json" | "error"> {
    runtime: IAgentRuntime | null;
    config?: CapabilityRouterPersistConfig;
    readJsonBody: JsonBodyReader;
    saveConfig?: (config: CapabilityRouterPersistConfig) => void;
    persistConfigEnv?: (key: string, value: string) => Promise<void>;
    connectEndpointProvider?: <TOptions>(runtime: IAgentRuntime, options: ConnectRemoteCapabilityEndpointProviderOptions<TOptions>) => Promise<ConnectRemoteCapabilityEndpointProviderResult>;
    connectCloudSandbox?: (runtime: IAgentRuntime, options: ConnectCloudCapabilitySandboxOptions) => Promise<ConnectCloudCapabilitySandboxResult>;
}
export declare function handleRemoteCapabilityRoutes(ctx: RemoteCapabilityRouteContext): Promise<boolean>;
type CapabilityRouterPersistConfig = {
    env?: {
        vars?: Record<string, string>;
        [key: string]: unknown;
    };
    [key: string]: unknown;
};
export {};
