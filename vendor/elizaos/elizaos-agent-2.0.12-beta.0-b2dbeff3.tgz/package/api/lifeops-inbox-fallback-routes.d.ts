/**
 * Compatibility fallback route for `GET /api/lifeops/inbox` on the local agent
 * server. When no runtime plugin handled the request, it returns the stable
 * empty inbox wire shape (no messages, no sources, `available: false`, zeroed
 * per-channel counts) after applying the shared `channels` query validation, so
 * builds without `@elizaos/plugin-personal-assistant` render the inbox view
 * instead of looping on a 404.
 */
import type { ServerResponse } from "node:http";
/**
 * Compatibility fallback for `GET /api/lifeops/inbox`.
 *
 * The inbox view is core, but the rich LifeOps inbox cache is still served by
 * `@elizaos/plugin-personal-assistant`. Desktop/cloud-shell builds may load the
 * inbox view without PA; when no plugin route handled the request, return the
 * stable empty wire shape instead of letting the renderer hit a noisy 404 loop.
 *
 * Dispatch placement matters: server.ts calls this after runtime plugin routes,
 * so PA's real route wins whenever it is installed.
 */
export declare function tryHandleLifeOpsInboxFallback(options: {
    pathname: string;
    method: string;
    url: URL;
    res: ServerResponse;
}): boolean;
