/**
 * Model and provider discovery helpers.
 *
 * Handles model listing, provider caching, and inventory (chain/RPC)
 * option resolution.
 */
import fs from "node:fs";
import path from "node:path";
import { ElizaError, logger } from "@elizaos/core";
import { DEFAULT_ELIZA_CLOUD_FREE_TEXT_MODEL, DEFAULT_ELIZA_CLOUD_TEXT_MODEL, isMobilePlatform, } from "@elizaos/host/protocol";
import { resolveModelsCacheDir } from "../config/paths.js";
export const DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS = 10000;
export class ModelCatalogFetchError extends ElizaError {
    name = "ModelCatalogFetchError";
    providerId;
    upstreamStatus;
    constructor(providerId, options = {}) {
        const statusDetail = options.upstreamStatus === undefined
            ? ""
            : ` (upstream returned ${options.upstreamStatus})`;
        super(`Failed to fetch models from ${providerId}${statusDetail}`, {
            code: "MODEL_CATALOG_FETCH_FAILED",
            cause: options.cause,
            context: {
                providerId,
                ...(options.upstreamStatus === undefined
                    ? {}
                    : { upstreamStatus: options.upstreamStatus }),
            },
            severity: "ephemeral",
        });
        this.providerId = providerId;
        this.upstreamStatus = options.upstreamStatus;
    }
}
export function getModelOptions() {
    // All models available via Eliza Cloud.
    // IDs use "provider/model" format to match the cloud API routing.
    // Every tier exposes the full catalog so users can assign any model to any slot.
    const freeDefaultMatchesRecommended = DEFAULT_ELIZA_CLOUD_FREE_TEXT_MODEL === DEFAULT_ELIZA_CLOUD_TEXT_MODEL;
    const allModels = [
        {
            id: DEFAULT_ELIZA_CLOUD_TEXT_MODEL,
            name: "Gemma 4 31B",
            provider: "Cerebras",
            description: "Recommended Cerebras model for Eliza Cloud text tiers.",
            recommended: true,
            ...(freeDefaultMatchesRecommended ? { free: true } : {}),
        },
        ...(freeDefaultMatchesRecommended
            ? []
            : [
                {
                    id: DEFAULT_ELIZA_CLOUD_FREE_TEXT_MODEL,
                    name: "Gemma 4 31B Free",
                    provider: "Cerebras",
                    description: "Free Cerebras model for Eliza Cloud text tiers.",
                    free: true,
                },
            ]),
        // Anthropic
        {
            id: "anthropic/claude-opus-4.7",
            name: "Claude Opus 4.7",
            provider: "Anthropic",
            description: "Most capable Claude model.",
        },
        {
            id: "anthropic/claude-sonnet-4.6",
            name: "Claude Sonnet 4.6",
            provider: "Anthropic",
            description: "Strong planning and reasoning.",
        },
        {
            id: "anthropic/claude-haiku-4.5",
            name: "Claude Haiku 4.5",
            provider: "Anthropic",
            description: "Fast Claude for lightweight tasks.",
        },
        // OpenAI
        {
            id: "openai/gpt-5.5-pro",
            name: "GPT-5.5 Pro",
            provider: "OpenAI",
            description: "Highest-precision GPT-5.5 variant.",
        },
        {
            id: "openai/gpt-5.5",
            name: "GPT-5.5",
            provider: "OpenAI",
            description: "Flagship OpenAI model for coding and reasoning.",
        },
        {
            id: "openai/gpt-5-mini",
            name: "GPT-5.5 Mini",
            provider: "OpenAI",
            description: "High-volume OpenAI mini model.",
        },
        {
            id: "openai/gpt-5.5-nano",
            name: "GPT-5.5 Nano",
            provider: "OpenAI",
            description: "Cheapest GPT-5.5 tier for fast routing and gating.",
        },
        // Google
        {
            id: "google/gemini-3.1-pro-preview",
            name: "Gemini 3.1 Pro Preview",
            provider: "Google",
            description: "Most capable Gemini. 1M context, advanced reasoning.",
        },
        {
            id: "google/gemini-2.5-pro",
            name: "Gemini 2.5 Pro",
            provider: "Google",
            description: "Stable multimodal reasoning.",
        },
        {
            id: "google/gemini-3-flash",
            name: "Gemini 3 Flash",
            provider: "Google",
            description: "Fast next-gen Gemini.",
        },
        {
            id: "google/gemini-3.1-flash-lite-preview",
            name: "Gemini 3.1 Flash Lite Preview",
            provider: "Google",
            description: "Fastest Gemini tier.",
        },
        // DeepSeek
        {
            id: "deepseek/deepseek-r1",
            name: "DeepSeek R1",
            provider: "DeepSeek",
            description: "Reasoning model.",
        },
        {
            id: "deepseek/deepseek-v3.2",
            name: "DeepSeek V3.2",
            provider: "DeepSeek",
            description: "Open and powerful.",
        },
        // Moonshot
        {
            id: "moonshotai/kimi-k2.5",
            name: "Kimi K2.5",
            provider: "Moonshot",
            description: "Multimodal agentic model from Moonshot AI.",
        },
        // Z.AI
        {
            id: "zai/glm-5.1",
            name: "GLM 5.1",
            provider: "Z.AI",
            description: "Latest GLM reasoning model.",
        },
        // MiniMax
        {
            id: "minimax/minimax-m2.7",
            name: "MiniMax M2.7",
            provider: "MiniMax",
            description: "Fast reasoning with strong value.",
        },
        {
            id: "minimax/minimax-m2.5-lightning",
            name: "MiniMax M2.5 Lightning",
            provider: "MiniMax",
            description: "Lowest-latency MiniMax option.",
        },
        // Groq
        {
            id: "groq/openai/gpt-oss-120b",
            name: "GPT-OSS 120B",
            provider: "Groq",
            description: "Approved Groq GPT-OSS default for small and large slots.",
        },
    ];
    return {
        nano: allModels,
        small: allModels,
        medium: allModels,
        large: allModels,
        mega: allModels,
    };
}
export function classifyModel(modelId) {
    const id = modelId.toLowerCase();
    if (id.includes("embed") || id.includes("text-embedding"))
        return "embedding";
    if (id.includes("dall-e") ||
        id.includes("dalle") ||
        id.includes("imagen") ||
        id.includes("stable-diffusion") ||
        id.includes("midjourney") ||
        id.includes("flux"))
        return "image";
    if (id.includes("tts") ||
        id.includes("text-to-speech") ||
        id.includes("eleven_"))
        return "tts";
    if (id.includes("whisper") || id.includes("stt") || id.includes("transcrib"))
        return "stt";
    if (id.includes("moderation") ||
        id.includes("guard") ||
        id.includes("safety"))
        return "other";
    return "chat";
}
/** Map param key → expected model category */
export function paramKeyToCategory(paramKey) {
    const k = paramKey.toUpperCase();
    if (k.includes("EMBEDDING"))
        return "embedding";
    if (k.includes("IMAGE"))
        return "image";
    if (k.includes("TTS"))
        return "tts";
    if (k.includes("STT") || k.includes("TRANSCRIPTION"))
        return "stt";
    return "chat";
}
const MODELS_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const PROVIDER_ENV_KEYS = {
    anthropic: { envKey: "ANTHROPIC_API_KEY" },
    openai: { envKey: "OPENAI_API_KEY" },
    groq: { envKey: "GROQ_API_KEY", baseUrl: "https://api.groq.com/openai/v1" },
    xai: { envKey: "XAI_API_KEY", baseUrl: "https://api.x.ai/v1" },
    openrouter: {
        envKey: "OPENROUTER_API_KEY",
        baseUrl: "https://openrouter.ai/api/v1",
    },
    deepseek: {
        envKey: "DEEPSEEK_API_KEY",
        baseUrl: "https://api.deepseek.com",
    },
    zai: {
        envKey: "ZAI_API_KEY",
        altEnvKeys: ["Z_AI_API_KEY"],
        baseUrl: "https://api.z.ai/api/paas/v4",
    },
    nearai: {
        envKey: "NEARAI_API_KEY",
        baseUrl: "https://cloud-api.near.ai/v1",
    },
    moonshot: {
        envKey: "MOONSHOT_API_KEY",
        altEnvKeys: ["KIMI_API_KEY"],
        baseUrl: "https://api.moonshot.ai/v1",
    },
    "google-genai": {
        envKey: "GOOGLE_GENERATIVE_AI_API_KEY",
        altEnvKeys: ["GOOGLE_API_KEY", "GEMINI_API_KEY"],
    },
    ollama: { envKey: "OLLAMA_BASE_URL" },
};
// ── Per-provider cache read/write ────────────────────────────────────────
/**
 * Canonical provider-id grammar. Cache paths are built by joining
 * `${providerId}.json` under the models cache dir, so anything outside this
 * shape (path separators, `.` segments) is rejected before a filesystem path
 * exists — a `../` id would otherwise traverse out of the cache directory
 * into an arbitrary unlink/read (W1-024).
 */
export const MODEL_PROVIDER_ID_PATTERN = /^[a-z0-9][a-z0-9-]*$/;
export function providerCachePath(providerId) {
    if (!MODEL_PROVIDER_ID_PATTERN.test(providerId)) {
        throw new ElizaError(`Invalid model provider id: ${providerId}`, {
            code: "INVALID_MODEL_PROVIDER_ID",
            context: { providerId },
        });
    }
    const cacheDir = resolveModelsCacheDir();
    const result = path.join(cacheDir, `${providerId}.json`);
    // Defense in depth: the joined path must stay directly inside the cache
    // dir even if the id grammar above is ever loosened.
    if (path.dirname(result) !== cacheDir) {
        throw new ElizaError(`Model provider cache path escapes the cache directory: ${providerId}`, { code: "INVALID_MODEL_PROVIDER_ID", context: { providerId } });
    }
    return result;
}
export function readProviderCache(providerId) {
    try {
        const raw = fs.readFileSync(providerCachePath(providerId), "utf-8");
        const cache = JSON.parse(raw);
        if (cache.version !== 1 || !cache.fetchedAt || !cache.models)
            return null;
        const age = Date.now() - new Date(cache.fetchedAt).getTime();
        if (age > MODELS_CACHE_TTL_MS)
            return null;
        return cache;
    }
    catch {
        return null;
    }
}
export function writeProviderCache(cache) {
    try {
        const dir = resolveModelsCacheDir();
        if (!fs.existsSync(dir))
            fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(providerCachePath(cache.providerId), JSON.stringify(cache, null, 2));
    }
    catch (e) {
        logger.warn(`[model-catalog] Failed to write cache for ${cache.providerId}: ${e instanceof Error ? e.message : e}`);
    }
}
// ── Provider fetchers ────────────────────────────────────────────────────
/** Fetch models from unknown provider's /v1/models endpoint (standard REST). */
export async function fetchModelsREST(providerId, apiKey, baseUrl) {
    try {
        const url = `${baseUrl.replace(/\/+$/, "")}/models`;
        const headers = {};
        if (apiKey)
            headers.Authorization = `Bearer ${apiKey}`;
        const res = await fetch(url, {
            headers,
            signal: AbortSignal.timeout(DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS),
        });
        if (!res.ok) {
            throw new ModelCatalogFetchError(providerId, {
                upstreamStatus: res.status,
            });
        }
        const data = await res.json();
        if (!data ||
            typeof data !== "object" ||
            !("data" in data) ||
            !Array.isArray(data.data)) {
            throw new ModelCatalogFetchError(providerId);
        }
        return data.data
            .map((model) => {
            if (!model ||
                typeof model !== "object" ||
                !("id" in model) ||
                typeof model.id !== "string" ||
                !model.id.trim() ||
                ("name" in model &&
                    model.name != null &&
                    typeof model.name !== "string") ||
                ("type" in model &&
                    model.type != null &&
                    typeof model.type !== "string")) {
                throw new ModelCatalogFetchError(providerId);
            }
            return {
                id: model.id,
                name: "name" in model && typeof model.name === "string"
                    ? model.name
                    : model.id,
                category: "type" in model && typeof model.type === "string" && model.type
                    ? restTypeToCategory(model.type)
                    : classifyModel(model.id),
            };
        })
            .sort((a, b) => a.id.localeCompare(b.id));
    }
    catch (e) {
        const failure = e instanceof ModelCatalogFetchError
            ? e
            : new ModelCatalogFetchError(providerId, { cause: e });
        logger.warn({
            src: "model-catalog",
            providerId,
            upstreamStatus: failure.upstreamStatus,
            error: e instanceof Error ? e.message : String(e),
        }, "Model catalog fetch failed");
        throw failure;
    }
}
export function restTypeToCategory(type) {
    const t = type.toLowerCase();
    if (t.includes("embed"))
        return "embedding";
    if (t === "image" || t.includes("image-generation"))
        return "image";
    if (t.includes("tts") || t.includes("speech"))
        return "tts";
    if (t.includes("stt") || t.includes("transcription") || t.includes("whisper"))
        return "stt";
    if (t === "language" || t === "chat" || t.includes("text"))
        return "chat";
    return classifyModel(type);
}
export async function fetchAnthropicModels(apiKey) {
    try {
        const headers = {
            "anthropic-version": "2023-06-01",
        };
        if (apiKey)
            headers["x-api-key"] = apiKey;
        const res = await fetch("https://api.anthropic.com/v1/models?limit=100", {
            headers,
            signal: AbortSignal.timeout(DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS),
        });
        if (!res.ok) {
            throw new ModelCatalogFetchError("anthropic", {
                upstreamStatus: res.status,
            });
        }
        const data = (await res.json());
        return (data.data ?? [])
            .map((m) => ({
            id: m.id,
            name: m.display_name ?? m.id,
            category: classifyModel(m.id),
        }))
            .sort((a, b) => a.id.localeCompare(b.id));
    }
    catch (e) {
        // error-policy:J4 an unreachable catalog is an explicit empty provider list;
        // a provider that answered with an error status stays a typed catalog
        // failure for the HTTP boundary (models-routes.ts).
        if (e instanceof ModelCatalogFetchError)
            throw e;
        logger.warn(`[model-catalog] Failed to fetch Anthropic models: ${e instanceof Error ? e.message : e}`);
        return [];
    }
}
export async function fetchGoogleModels(apiKey) {
    try {
        const url = apiKey
            ? `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`
            : "https://generativelanguage.googleapis.com/v1beta/models";
        const res = await fetch(url, {
            signal: AbortSignal.timeout(DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS),
        });
        if (!res.ok) {
            throw new ModelCatalogFetchError("google-genai", {
                upstreamStatus: res.status,
            });
        }
        const data = (await res.json());
        return (data.models ?? []).map((m) => {
            const id = m.name.replace("models/", "");
            return {
                id,
                name: m.displayName ?? id,
                category: classifyModel(id),
            };
        });
    }
    catch (e) {
        // error-policy:J4 an unreachable catalog is an explicit empty provider list;
        // a provider that answered with an error status stays a typed catalog
        // failure for the HTTP boundary (models-routes.ts).
        if (e instanceof ModelCatalogFetchError)
            throw e;
        logger.warn(`[model-catalog] Failed to fetch Google models: ${e instanceof Error ? e.message : e}`);
        return [];
    }
}
export async function fetchOllamaModels(baseUrl) {
    try {
        let urlStr = baseUrl.replace(/\/+$/, "");
        if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) {
            urlStr = `http://${urlStr}`;
        }
        // @duplicate-component-audit-allow: Ollama tags is a model catalog lookup, not generation.
        // Cap the probe: Ollama defaults to localhost:11434, which does not exist on
        // most devices (and on mobile the connect stalls on the OS TCP timeout for
        // ~15s). This runs on the API-server startup path, so an unbounded fetch
        // there blocked the whole boot/`server.listen` for ~15s (#11903). A short
        // AbortSignal keeps a missing Ollama a fast, cheap "no models".
        const res = await fetch(`${urlStr}/api/tags`, {
            signal: AbortSignal.timeout(2000),
        });
        if (!res.ok)
            return [];
        const data = (await res.json());
        return (data.models ?? []).map((m) => ({
            id: m.name,
            name: m.name,
            category: classifyModel(m.name),
        }));
    }
    catch (e) {
        const message = `[model-catalog] Failed to fetch Ollama models: ${e instanceof Error ? e.message : e}`;
        // A localhost probe discovers Ollama when it happens to be installed; its
        // absence is the normal case. An operator-supplied endpoint is intentional
        // configuration, so retain an actionable warning for that path.
        if (process.env.OLLAMA_BASE_URL?.trim())
            logger.warn(message);
        else
            logger.debug(message);
        return [];
    }
}
/** Fetch ALL OpenRouter models: chat (/api/v1/models) + embeddings (/api/v1/embeddings/models). */
export async function fetchOpenRouterModels(apiKey) {
    const headers = {};
    if (apiKey)
        headers.Authorization = `Bearer ${apiKey}`;
    // Fetch chat/text models and embedding models in parallel
    const [chatRes, embedRes] = await Promise.all([
        fetch("https://openrouter.ai/api/v1/models?output_modalities=all", {
            headers,
            signal: AbortSignal.timeout(DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS),
        }).catch((error) => {
            // error-policy:J4 the combined catalog can remain partially available.
            logger.warn(`[model-catalog] OpenRouter text catalog unavailable: ${error instanceof Error ? error.message : String(error)}`);
            return null;
        }),
        fetch("https://openrouter.ai/api/v1/embeddings/models", {
            headers,
            signal: AbortSignal.timeout(DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS),
        }).catch((error) => {
            // error-policy:J4 the combined catalog can remain partially available.
            logger.warn(`[model-catalog] OpenRouter embedding catalog unavailable: ${error instanceof Error ? error.message : String(error)}`);
            return null;
        }),
    ]);
    const models = [];
    // Parse chat/text/image models
    if (chatRes?.ok) {
        try {
            const data = (await chatRes.json());
            for (const m of data.data ?? []) {
                const outputs = (m.architecture?.output_modalities ?? []).map((value) => value.toLowerCase());
                const modality = m.architecture?.modality?.toLowerCase() ?? "";
                let category = "chat";
                if (outputs.includes("text") || modality.includes("text->text")) {
                    category = "chat";
                }
                else if (outputs.includes("image"))
                    category = "image";
                else if (outputs.includes("audio"))
                    category = "tts";
                models.push({ id: m.id, name: m.name ?? m.id, category });
            }
        }
        catch (error) {
            // error-policy:J4 invalid text-catalog data leaves embeddings available.
            logger.warn(`[model-catalog] Invalid OpenRouter text catalog: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    // Parse embedding models
    if (embedRes?.ok) {
        try {
            const data = (await embedRes.json());
            for (const m of data.data ?? []) {
                models.push({ id: m.id, name: m.name ?? m.id, category: "embedding" });
            }
        }
        catch (error) {
            // error-policy:J4 invalid embedding data leaves the text catalog available.
            logger.warn(`[model-catalog] Invalid OpenRouter embedding catalog: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    const deduped = Array.from(new Map(models.map((model) => [model.id, model])).values());
    deduped.sort((a, b) => a.id.localeCompare(b.id));
    return deduped;
}
/** Fetch NEAR AI Cloud models from its catalog endpoint. */
export async function fetchNearAIModels(apiKey, baseUrl) {
    try {
        const url = `${baseUrl.replace(/\/+$/, "")}/models`;
        const headers = {};
        if (apiKey)
            headers.Authorization = `Bearer ${apiKey}`;
        const res = await fetch(url, {
            headers,
            signal: AbortSignal.timeout(DEFAULT_MODEL_CATALOG_FETCH_TIMEOUT_MS),
        });
        if (!res.ok) {
            throw new ModelCatalogFetchError("nearai", {
                upstreamStatus: res.status,
            });
        }
        const data = (await res.json());
        return (data.data ?? data.models ?? [])
            .filter((model) => model.is_ready !== false)
            .map((model) => {
            const id = model.id ?? model.modelId;
            if (!id)
                return null;
            const outputs = model.output_modalities ??
                model.architecture?.outputModalities ??
                model.architecture?.output_modalities ??
                model.metadata?.architecture?.outputModalities ??
                model.metadata?.architecture?.output_modalities ??
                [];
            const normalizedOutputs = outputs.map((output) => output.toLowerCase());
            const category = normalizedOutputs.includes("image")
                ? "image"
                : model.type
                    ? restTypeToCategory(model.type)
                    : classifyModel(id);
            return {
                id,
                name: model.name ?? model.metadata?.modelDisplayName ?? id,
                category,
            };
        })
            .filter((model) => model !== null)
            .sort((a, b) => a.id.localeCompare(b.id));
    }
    catch (e) {
        // error-policy:J4 an unreachable catalog is an explicit empty provider list;
        // a provider that answered with an error status stays a typed catalog
        // failure for the HTTP boundary (models-routes.ts).
        if (e instanceof ModelCatalogFetchError)
            throw e;
        logger.warn(`[model-catalog] Failed to fetch NEAR AI models: ${e instanceof Error ? e.message : e}`);
        return [];
    }
}
export async function fetchProviderModels(providerId, apiKey, baseUrl) {
    switch (providerId) {
        case "anthropic":
            return fetchAnthropicModels(apiKey);
        case "google-genai":
            return fetchGoogleModels(apiKey);
        case "ollama":
            return fetchOllamaModels(baseUrl || "http://localhost:11434");
        case "openrouter":
            return fetchOpenRouterModels(apiKey);
        case "openai":
            return fetchModelsREST(providerId, apiKey, baseUrl ?? "https://api.openai.com/v1");
        case "groq":
            return fetchModelsREST(providerId, apiKey, baseUrl ?? "https://api.groq.com/openai/v1");
        case "xai":
            return fetchModelsREST(providerId, apiKey, baseUrl ?? "https://api.x.ai/v1");
        case "deepseek":
            return fetchModelsREST(providerId, apiKey, baseUrl ?? "https://api.deepseek.com");
        case "zai":
            return fetchModelsREST(providerId, apiKey, baseUrl ?? "https://api.z.ai/api/paas/v4");
        case "nearai":
            return fetchNearAIModels(apiKey, baseUrl ?? "https://cloud-api.near.ai/v1");
        case "moonshot":
            return fetchModelsREST(providerId, apiKey, baseUrl ?? "https://api.moonshot.ai/v1");
        default:
            return [];
    }
}
/** Fetch + cache a single provider. Returns cached models or empty array. */
export async function getOrFetchProvider(providerId, force = false) {
    if (!force) {
        const cached = readProviderCache(providerId);
        if (cached)
            return cached.models;
    }
    const cfg = PROVIDER_ENV_KEYS[providerId];
    if (!cfg)
        return [];
    let keyValue = process.env[cfg.envKey]?.trim();
    if (!keyValue && cfg.altEnvKeys) {
        for (const alt of cfg.altEnvKeys) {
            keyValue = process.env[alt]?.trim();
            if (keyValue)
                break;
        }
    }
    let baseUrl = cfg.baseUrl;
    if (providerId === "openai") {
        baseUrl = process.env.OPENAI_BASE_URL?.trim() || undefined;
    }
    if (providerId === "nearai") {
        baseUrl =
            process.env.NEARAI_BASE_URL?.trim() || "https://cloud-api.near.ai/v1";
    }
    // Ollama is a desktop localhost server (default :11434). No phone runs it, and
    // on Android the connect to a dead localhost port blocks ~15s on the OS TCP
    // timeout — AbortSignal.timeout does not interrupt bun's connect there — which,
    // because provider caches warm on the API-server startup path, stalled the
    // entire boot/`server.listen` for ~15s (#11903). Skip the probe on mobile.
    if (providerId === "ollama" && isMobilePlatform())
        return [];
    // Skip remote providers that need an API key when none is configured
    const keylessProviders = new Set(["ollama", "openrouter"]);
    if (!keyValue && !keylessProviders.has(providerId))
        return [];
    const models = await fetchProviderModels(providerId, keyValue ?? "", baseUrl);
    if (models.length > 0) {
        writeProviderCache({
            version: 1,
            providerId,
            fetchedAt: new Date().toISOString(),
            models,
        });
    }
    return models;
}
/** Fetch all configured providers (parallel). Returns map of providerId → models. */
export async function getOrFetchAllProviders(force = false) {
    const result = {};
    const fetches = [];
    for (const providerId of Object.keys(PROVIDER_ENV_KEYS)) {
        fetches.push(getOrFetchProvider(providerId, force)
            .then((models) => {
            if (models.length > 0)
                result[providerId] = models;
        })
            .catch(() => {
            // error-policy:J4 all-provider discovery is best-effort. Individual
            // provider refreshes retain the typed failure for the HTTP boundary.
        }));
    }
    await Promise.all(fetches);
    return result;
}
export { getInventoryProviderOptions } from "./wallet-rpc.js";
