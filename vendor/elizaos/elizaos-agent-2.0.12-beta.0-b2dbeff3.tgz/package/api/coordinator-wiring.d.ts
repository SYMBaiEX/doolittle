/**
 * Polling-based wiring of the swarm-coordinator bridges into the API server's
 * mutable state. Runs fire-and-forget during boot/restart: attempts to wire the
 * chat, WebSocket, event-routing, and swarm-synthesis bridges immediately, then
 * polls `runtime.getService()` for the coding-agent orchestrator's
 * SWARM_COORDINATOR service to appear and retries the still-unwired bridges.
 * Reports degradation precisely — distinguishing "orchestrator not installed"
 * (debug) from "service registered but never became discoverable / ACP stream
 * never bound" (warn + a `system-warning` WS broadcast) — so a dead coding-agent
 * supervision surface is never silently reported as success.
 */
import { type AgentRuntime } from "@elizaos/core";
/**
 * Minimal subset of ServerState needed for coordinator bridge wiring.
 * Avoids importing the full ServerState interface (which is private to server.ts).
 */
export interface WirableState {
    runtime: AgentRuntime | null;
    broadcastWs?: ((data: object) => void) | null;
}
export interface WireCoordinatorOpts<S extends WirableState = WirableState> {
    /** Wire the chat bridge. Returns true on success. */
    wireChatBridge: (state: S) => boolean | Promise<boolean>;
    /** Wire the WebSocket bridge. Returns true on success. */
    wireWsBridge: (state: S) => boolean | Promise<boolean>;
    /** Wire the event-routing bridge. Returns true on success. */
    wireEventRouting: (state: S) => boolean | Promise<boolean>;
    /** Wire the swarm-complete synthesis callback. Returns true on success. */
    wireSwarmSynthesis?: (state: S) => boolean | Promise<boolean>;
    /** Label for log messages (e.g. "boot", "restart"). */
    context: string;
    /** Logger with warn/debug methods. */
    logger: {
        warn: (msg: string) => void;
        debug?: (msg: string) => void;
    };
}
export interface WireResult {
    chat: boolean;
    ws: boolean;
    eventRouting: boolean;
    swarmSynthesis: boolean;
}
/**
 * Wire coordinator bridges using polling-based service discovery.
 *
 * 1. Attempts immediate wiring (coordinator may already be available).
 * 2. If any bridge fails, polls for the coordinator via `runtime.getService()`.
 *    Depending on the installed coding-agent plugin, this is exposed as a
 *    `SWARM_COORDINATOR` service.
 * 3. Once the service appears, retries failed bridges up to MAX_RETRIES.
 * 4. On timeout or exhaustion, broadcasts a system-warning WS event.
 *
 * Safe for fire-and-forget (`void wireCoordinatorBridgesWhenReady(...)`).
 */
export declare function wireCoordinatorBridgesWhenReady<S extends WirableState>(state: S, opts: WireCoordinatorOpts<S>): Promise<WireResult>;
