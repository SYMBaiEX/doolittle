/** Provenance attached by the authenticated native dispatcher; HTTP headers cannot create it. */
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
export declare function markAuthenticatedInProcessRequest(request: object, authorization?: AgentHttpRequestAuthorization): void;
export declare function isAuthenticatedInProcessRequest(request: object): boolean;
/** Original verified principal, never reconstructed from HTTP or model fields. */
export declare function getAuthenticatedInProcessAuthorization(request: object): AgentHttpRequestAuthorization | undefined;
