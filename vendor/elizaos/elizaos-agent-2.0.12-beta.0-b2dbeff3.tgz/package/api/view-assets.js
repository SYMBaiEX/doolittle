/** Installation-owned publication inventory for local view assets. */
import { createHash } from "node:crypto";
import { constants, promises as fs } from "node:fs";
import path from "node:path";
import { ElizaError } from "@elizaos/core";
import { isPathWithinRoot, resolveRealPath } from "./realpath-confinement.js";
const inventories = new WeakMap();
export function validViewAssetPath(value) {
    return (typeof value === "string" &&
        value.length > 0 &&
        !/[\\?#]/u.test(value) &&
        Array.from(value).every((char) => char.charCodeAt(0) > 31 && char.charCodeAt(0) !== 127) &&
        value
            .split("/")
            .every((segment) => segment !== "" && segment !== "." && segment !== ".."));
}
/** Open nonblocking, then verify the descriptor before reading any bytes. */
async function readRegularFile(directory, file) {
    const real = await resolveRealPath(path.resolve(directory, file));
    if (!real || !isPathWithinRoot(real, directory)) {
        throw new ElizaError("View asset resolves outside its publication directory", { code: "VIEW_ASSET_CHANGED", context: { file } });
    }
    const handle = await fs.open(real, constants.O_RDONLY | constants.O_NONBLOCK | constants.O_NOFOLLOW);
    try {
        if (!(await handle.stat()).isFile()) {
            throw new ElizaError("View asset is no longer a regular file", {
                code: "VIEW_ASSET_CHANGED",
                context: { file },
            });
        }
        return await handle.readFile();
    }
    finally {
        await handle.close();
    }
}
export async function captureViewAssetRoot(rootPath) {
    const directory = await fs.realpath(path.dirname(rootPath));
    const rootName = path.basename(rootPath);
    let files = [rootName];
    let explicit = false;
    try {
        const manifest = JSON.parse((await readRegularFile(directory, `${rootName}.assets.json`)).toString("utf8"));
        if (!manifest ||
            typeof manifest !== "object" ||
            !("version" in manifest) ||
            manifest.version !== 1 ||
            !("files" in manifest) ||
            !Array.isArray(manifest.files) ||
            !manifest.files.every(validViewAssetPath)) {
            throw new ElizaError("Expected a version 1 view asset manifest with relative file paths", { code: "VIEW_ASSET_MANIFEST_INVALID", context: { rootName } });
        }
        files = [...new Set([rootName, ...manifest.files])];
        explicit = true;
    }
    catch (error) {
        // error-policy:J2 Invalid manifests retain their cause; absence publishes only the declared root.
        if (error.code !== "ENOENT") {
            throw new ElizaError("Invalid view asset manifest", {
                code: "VIEW_ASSET_MANIFEST_INVALID",
                cause: error,
                context: { rootName },
            });
        }
    }
    const captured = new Map();
    for (const file of files) {
        const bytes = await readRegularFile(directory, file);
        captured.set(file, {
            hash: createHash("sha256").update(bytes).digest("hex"),
            size: bytes.byteLength,
        });
    }
    return { directory, rootName, files: captured, explicit };
}
export function setViewAssets(entry, roots) {
    inventories.set(entry, roots);
}
export function bindViewAssets(source, installed) {
    const inventory = inventories.get(source);
    if (inventory)
        inventories.set(installed, inventory);
}
export function getViewAssetRoot(entry, kind) {
    return inventories.get(entry)?.[kind];
}
export async function readViewAsset(root, file) {
    const asset = root.files.get(file);
    if (!asset)
        throw new ElizaError(root.explicit
            ? "Asset is not published by this installation"
            : "Declare sibling assets in a root-adjacent .assets.json manifest and reinstall the view", { code: "VIEW_ASSET_NOT_PUBLISHED" });
    const bytes = await readRegularFile(root.directory, file);
    if (createHash("sha256").update(bytes).digest("hex") !== asset.hash)
        throw new ElizaError("View asset changed; reinstall the view before loading it", { code: "VIEW_ASSET_CHANGED" });
    return bytes;
}
