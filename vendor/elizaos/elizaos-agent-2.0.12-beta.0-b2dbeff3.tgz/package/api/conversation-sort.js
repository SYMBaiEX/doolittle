/**
 * Total-order comparators used by the conversation HTTP routes to order
 * conversation summaries and message memories.
 *
 * Timestamps reaching these comparators come from persisted rows and untrusted
 * PATCH payloads, so a malformed `updatedAt` string or a non-numeric
 * `createdAt` can produce `NaN`. A comparator that returns `NaN` makes
 * `Array.prototype.sort` implementation-defined, which surfaces as an unstable
 * conversation list. Both comparators therefore coerce a non-finite timestamp
 * to `0` and break the resulting tie on id so the order stays deterministic.
 */
import { compareMemoryIds } from "@elizaos/core";
function finiteOrZero(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : 0;
}
/**
 * Orders conversations newest-updated first. An unparseable `updatedAt` sorts
 * as epoch 0 (oldest) rather than poisoning the comparison with `NaN`.
 */
export function compareConversationsByRecency(a, b) {
    const bVal = finiteOrZero(new Date(b.updatedAt).getTime());
    const aVal = finiteOrZero(new Date(a.updatedAt).getTime());
    return bVal - aVal || a.id.localeCompare(b.id);
}
/**
 * Orders message memories oldest-created first, treating a missing or
 * non-finite `createdAt` as epoch 0 and tie-breaking on UUID order. Locale
 * string compare disagrees with the store for mixed-case ids, so a
 * same-millisecond burst rendered in a different order than it was stored.
 */
export function compareMemoriesByCreatedAt(a, b) {
    const aCreated = finiteOrZero(a.createdAt);
    const bCreated = finiteOrZero(b.createdAt);
    return (aCreated - bCreated ||
        compareMemoryIds(a.id ? String(a.id) : "", b.id ? String(b.id) : ""));
}
