import type { WalletChain, WalletGenerateResult, WalletKeys } from "@elizaos/contracts";
export declare function deriveEvmAddress(privateKeyHex: string): string;
export declare function deriveSolanaAddress(privateKeyString: string): string;
export declare function decodeSolanaBase58(str: string): Buffer;
/** Identifies configuration sentinels that do not represent wallet keys. */
export declare function isWalletKeyPlaceholder(value: string): boolean;
export declare function decodeSolanaPrivateKey(key: string): Buffer;
export declare function generateWalletKeys(): WalletKeys;
export declare function generateWalletForChain(chain: WalletChain): WalletGenerateResult;
export declare function setSolanaWalletEnv(privateKey: string): string | null;
export declare function syncSolanaPublicKeyEnv(privateKey?: string | undefined): string | null;
