/**
 * Owns the authenticated snapshot-v2 HTTP boundary and its backpressure-aware
 * binary response writer. Request identity is validated before headers commit;
 * after commit, any source/transport failure terminates the response so a
 * truncated capture can never be mistaken for a successful terminal frame.
 */
import type http from "node:http";
import type { ElizaConfig } from "@elizaos/host/protocol";
import { type AgentBackupV2CaptureComponentSource, type AgentBackupV2CaptureRuntime } from "../services/agent-backup.js";
export interface AgentBackupV2WritableResponse {
    statusCode: number;
    readonly headersSent?: boolean;
    readonly writableEnded?: boolean;
    setHeader(name: string, value: string): unknown;
    write(chunk: Uint8Array, callback?: (error?: Error | null) => void): boolean;
    end(): unknown;
    destroy(error?: Error): unknown;
    once(event: "drain" | "close" | "error", listener: (...args: unknown[]) => void): unknown;
    off(event: "drain" | "close" | "error", listener: (...args: unknown[]) => void): unknown;
}
export interface AgentBackupV2SnapshotRouteDependencies {
    runtime: AgentBackupV2CaptureRuntime;
    config: ElizaConfig;
    /** Deterministic source injection for real transport tests only. */
    components?: readonly AgentBackupV2CaptureComponentSource[];
    now?: () => number;
}
/** Write one frame at a time and never pull the next frame before `drain`. */
export declare function writeAgentBackupV2StreamResponse(res: AgentBackupV2WritableResponse, frames: AsyncIterable<Uint8Array>, options?: Readonly<{
    signal?: AbortSignal;
    operationId?: string;
}>): Promise<void>;
/** Handle `POST /api/snapshot/v2` after the server's normal auth gate. */
export declare function handleAgentBackupV2SnapshotRequest(req: http.IncomingMessage, res: http.ServerResponse, dependencies: Readonly<AgentBackupV2SnapshotRouteDependencies>): Promise<void>;
