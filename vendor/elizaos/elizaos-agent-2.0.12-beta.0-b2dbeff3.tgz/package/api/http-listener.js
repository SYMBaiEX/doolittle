async function closeSocketServer(server, reportHelperError) {
    await new Promise((resolve) => {
        let settled = false;
        const timeout = setTimeout(resolveOnce, 5_000);
        function resolveOnce() {
            if (settled)
                return;
            settled = true;
            clearTimeout(timeout);
            resolve();
        }
        for (const helper of [
            "closeAllConnections",
            "closeIdleConnections",
        ]) {
            const closeConnections = server[helper];
            if (typeof closeConnections !== "function")
                continue;
            try {
                closeConnections.call(server);
            }
            catch (error) {
                // error-policy:J6 Node and Bun expose these optional helpers with
                // runtime-specific behavior; the normal server close still proceeds.
                reportHelperError(helper, error);
            }
        }
        server.close(resolveOnce);
    });
}
export function listenHttpServer(options) {
    return new Promise((resolve, reject) => {
        let requestedPort = options.port;
        let settled = false;
        const fail = (error) => {
            options.onServerError?.(error);
            void options.closeResources().finally(() => {
                if (!settled) {
                    settled = true;
                    reject(error);
                }
            });
        };
        options.server.on("error", (error) => {
            if (error.code === "EADDRINUSE") {
                const willFallback = requestedPort !== 0 && !options.strictPortBinding;
                options.onPortInUse?.(requestedPort, willFallback);
                if (willFallback) {
                    requestedPort = 0;
                    setImmediate(() => options.server.listen(0, options.host));
                    return;
                }
            }
            fail(error);
        });
        options.server.once("listening", () => {
            const address = options.server.address();
            const actualPort = typeof address === "object" && address ? address.port : requestedPort;
            const actualHost = typeof address === "object" && address ? address.address : options.host;
            options.onListening?.(actualHost, actualPort);
            if (settled)
                return;
            settled = true;
            resolve({
                port: actualPort,
                close: async () => {
                    await Promise.all([
                        options.closeResources(),
                        closeSocketServer(options.server, (helper, error) => options.onCloseHelperError?.(helper, error)),
                    ]);
                },
            });
        });
        options.onBeforeListen?.();
        options.server.listen(options.port, options.host);
    });
}
