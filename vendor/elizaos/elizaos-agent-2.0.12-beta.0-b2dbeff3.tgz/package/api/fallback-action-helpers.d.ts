/**
 * Fallback action parsing + execution helpers.
 *
 * When a response text carries bracketed action tags the planner didn't already
 * execute, these helpers parse the tags and run the matching runtime actions,
 * rewriting their callback output in the character's voice via TEXT_SMALL.
 */
import { type ActionParameters, type AgentRuntime, type createMessageMemory } from "@elizaos/core";
export type FallbackParsedAction = {
    name: string;
    parameters?: ActionParameters;
};
export declare function parseFallbackActionBlocks(value: unknown, _responseText?: string): FallbackParsedAction[];
export declare function executeFallbackParsedActions(runtime: AgentRuntime, message: ReturnType<typeof createMessageMemory>, parsedActions: FallbackParsedAction[], appendIncomingText: (incoming: string) => void, onActionCallback: (actionTag: string, hasText: boolean) => void, options?: {
    abortSignal?: AbortSignal;
    getCurrentText?: () => string;
    onCallbackText?: (incoming: string) => void;
}): Promise<Array<{
    actionName: string;
    success: boolean;
}>>;
