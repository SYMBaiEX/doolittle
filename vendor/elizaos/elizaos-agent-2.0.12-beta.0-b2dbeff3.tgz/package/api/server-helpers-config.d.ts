/**
 * Config redaction, first-run, and skill validation helpers extracted from server.ts.
 */
import type http from "node:http";
import { type ElizaConfig } from "@elizaos/host/protocol";
export { isBlockedObjectKey } from "./blocked-object-keys.js";
/** Honest GET /api/config and /api/connectors payloads are a handful of objects deep. */
export declare const MAX_CONFIG_SECRET_FILTER_DEPTH = 32;
/**
 * Node ceiling across the whole redaction / placeholder-strip walk, including
 * sparse array holes. Well above an ordinary character/config document; bounds
 * synthetic graphs that would otherwise RangeError or hang the authorized
 * config and connector routes.
 */
export declare const MAX_CONFIG_SECRET_FILTER_NODES = 100000;
export declare const CONFIG_SECRET_FILTER_UNBOUNDED = "CONFIG_SECRET_FILTER_UNBOUNDED";
export declare function redactDeep(val: unknown): unknown;
export declare function redactConfigSecrets(config: Record<string, unknown>): Record<string, unknown>;
export declare function isRedactedSecretValue(value: unknown): boolean;
/** Remove UI round-trip placeholders so GET /api/config -> PUT never persists "[REDACTED]". */
export declare function stripRedactedPlaceholderValuesDeep(value: unknown): void;
export declare function validateSkillId(skillId: string, res: http.ServerResponse): string | null;
export declare function readUiLanguageHeader(req: http.IncomingMessage | undefined): string | undefined;
export declare function resolveConfiguredCharacterLanguage(config?: ElizaConfig, req?: http.IncomingMessage): "en" | "zh-CN" | "ko" | "es" | "pt" | "vi" | "tl" | "ja";
export declare function resolveFirstRunStylePreset(body: Record<string, unknown>, language: string): import("@elizaos/host").StylePreset;
export declare function applyFirstRunVoicePreset(config: ElizaConfig, body: Record<string, unknown>, language: string): void;
export declare function resolveDefaultAgentName(config?: ElizaConfig, req?: http.IncomingMessage): string;
export declare function getProviderOptions(): Array<{
    id: string;
    name: string;
    envKey: string | null;
    pluginName: string;
    keyPrefix: string | null;
    description: string;
}>;
export declare function getCloudProviderOptions(): Array<{
    id: string;
    name: string;
    description: string;
}>;
export declare function ensureWalletKeysInEnvAndConfig(config: ElizaConfig): Promise<boolean>;
export declare function isSafeResetStateDir(resolvedState: string, homeDir: string): boolean;
