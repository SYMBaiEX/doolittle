/**
 * Defines the shared completeness and text-integrity contract for captured
 * terminal output at both the HTTP route and action consumer boundaries.
 */
export declare const MAX_TERMINAL_CAPTURE_BYTES: number;
export declare function capturedTerminalOutputIsSafe(stdout: string, stderr: string): boolean;
/** Safe pre-dispatch failures. Messages never contain submitted commands or credentials. */
export declare const TERMINAL_REJECTIONS: {
    readonly TERMINAL_COMMAND_REQUIRED: {
        readonly status: 400;
        readonly message: "A non-empty shell command is required.";
        readonly retryable: true;
    };
    readonly TERMINAL_COMMAND_TOO_LONG: {
        readonly status: 400;
        readonly message: "Command exceeds maximum length (4096 characters). Use the coding tools for longer scripts.";
        readonly retryable: true;
    };
    readonly TERMINAL_COMMAND_SINGLE_LINE_REQUIRED: {
        readonly status: 400;
        readonly message: "Command must be a single line without literal newline, carriage return or NUL characters. Use escaped newlines inside a single-line command, or the coding tools for scripts.";
        readonly retryable: true;
    };
    readonly TERMINAL_AUTHORIZATION_REQUIRED: {
        readonly status: 403;
        readonly message: "Terminal authorization is required. Ask the owner to authorize terminal access; do not bypass this restriction.";
        readonly retryable: false;
    };
    readonly TERMINAL_SHELL_DISABLED: {
        readonly status: 403;
        readonly message: "Shell execution is disabled by host policy. Do not bypass this restriction.";
        readonly retryable: false;
    };
};
export type TerminalRejectionCode = keyof typeof TERMINAL_REJECTIONS;
export declare function terminalRejectionResponse(code: TerminalRejectionCode): {
    error: "A non-empty shell command is required." | "Command exceeds maximum length (4096 characters). Use the coding tools for longer scripts." | "Command must be a single line without literal newline, carriage return or NUL characters. Use escaped newlines inside a single-line command, or the coding tools for scripts." | "Terminal authorization is required. Ask the owner to authorize terminal access; do not bypass this restriction." | "Shell execution is disabled by host policy. Do not bypass this restriction.";
    code: "TERMINAL_COMMAND_REQUIRED" | "TERMINAL_COMMAND_TOO_LONG" | "TERMINAL_COMMAND_SINGLE_LINE_REQUIRED" | "TERMINAL_AUTHORIZATION_REQUIRED" | "TERMINAL_SHELL_DISABLED";
    acceptance: "rejected";
    executionStatus: "not_started";
    retryable: boolean;
};
