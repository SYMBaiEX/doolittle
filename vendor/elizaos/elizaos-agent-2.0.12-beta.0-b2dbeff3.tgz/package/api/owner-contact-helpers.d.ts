/**
 * Shared helper for auto-populating owner contacts when a connector
 * successfully pairs. Called by the per-platform setup routes
 * (whatsapp-routes, telegram-setup-routes, etc.).
 *
 * Writes to `config.agents.defaults.ownerContacts[source]` so LifeOps
 * reminder delivery can immediately find the owner on the newly
 * connected platform without manual configuration.
 */
type MinimalConfig = Record<string, unknown> & {
    agents?: {
        defaults?: {
            ownerContacts?: Record<string, {
                entityId?: string;
                channelId?: string;
                roomId?: string;
            }>;
            [key: string]: unknown;
        };
        [key: string]: unknown;
    };
};
export interface OwnerContactUpdate {
    /** Canonical connector source name (e.g. "telegram", "discord", "whatsapp", "imessage"). */
    source: string;
    /** Platform-specific channel/chat ID (phone number, chat id, etc.). */
    channelId?: string;
    /** Entity UUID in the runtime, if known. */
    entityId?: string;
    /** Room UUID in the runtime, if known. */
    roomId?: string;
}
/**
 * Write (or update) an owner contact entry in the agent config.
 * Returns true if the config was modified.
 */
export declare function setOwnerContact(config: MinimalConfig, update: OwnerContactUpdate): boolean;
export {};
