import type { ViewRegistryEntry } from "./view-registry-types.js";
export type ViewAssetKind = "bundle" | "frame";
interface Asset {
    readonly hash: string;
    readonly size: number;
}
export interface ViewAssetRoot {
    readonly directory: string;
    readonly rootName: string;
    readonly files: ReadonlyMap<string, Asset>;
    readonly explicit: boolean;
}
export declare function validViewAssetPath(value: unknown): value is string;
export declare function captureViewAssetRoot(rootPath: string): Promise<ViewAssetRoot>;
export declare function setViewAssets(entry: ViewRegistryEntry, roots: Partial<Record<ViewAssetKind, ViewAssetRoot>>): void;
export declare function bindViewAssets(source: ViewRegistryEntry, installed: ViewRegistryEntry): void;
export declare function getViewAssetRoot(entry: ViewRegistryEntry, kind: ViewAssetKind): ViewAssetRoot | undefined;
export declare function readViewAsset(root: ViewAssetRoot, file: string): Promise<Buffer>;
export {};
