/**
 * Approval / pending-user-action routes.
 *
 * `GET /api/approvals` is the canonical read surface for work that is blocked
 * on the user. It aggregates legacy owner approval rows, task-based approval
 * records, and pending planner prompts into the shared `PendingUserAction`
 * contract so clients render one list without knowing producer internals.
 */
import { PENDING_USER_ACTION_WEIGHT, resolveOwnerEntityIdOrDefault, ServiceType, } from "@elizaos/core";
import { APPROVAL_EXECUTION_CAPABILITY, APPROVAL_EXECUTION_PROTOCOL_VERSION, APPROVAL_SERVICE, PENDING_PROMPTS_SERVICE, } from "@elizaos/plugin-assistant";
const APPROVAL_STATES = [
    "pending",
    "approved",
    "executing",
    "retryable",
    "reconciliation_required",
    "done",
    "rejected",
    "expired",
];
function isPendingUserActionService(value) {
    return (typeof value === "object" &&
        value !== null &&
        typeof value.listPendingUserActions ===
            "function");
}
function isApprovalTaskService(value) {
    return (typeof value === "object" &&
        value !== null &&
        typeof value.getAllPendingApprovals ===
            "function");
}
function parseLimit(raw) {
    if (raw === null || raw === "")
        return 50;
    // Strict decimal digits only. Number.parseInt("1e3", 10) === 1 would
    // silently under-read a client page size as 1.
    if (!/^[1-9]\d*$/.test(raw))
        return null;
    const parsed = Number(raw);
    if (!Number.isSafeInteger(parsed) || parsed <= 0)
        return null;
    return Math.min(parsed, 500);
}
/**
 * Parse the approvals `state` query. Omitted/empty keeps the pending default.
 * `all` means no state filter. A known lifecycle state selects that queue.
 * Any other token used to fall through to pending, so `state=DONE` or
 * `state=complete` silently listed pending work.
 */
export function parseApprovalState(raw) {
    if (raw === null || raw === "")
        return { ok: true, state: "pending" };
    if (raw === "all")
        return { ok: true, state: null };
    if (APPROVAL_STATES.includes(raw)) {
        return { ok: true, state: raw };
    }
    return {
        ok: false,
        message: `state must be one of: all, ${APPROVAL_STATES.join(", ")}`,
    };
}
function getAgentApprovalQueue(state) {
    const service = state.runtime?.getService(APPROVAL_SERVICE);
    if (!service)
        return null;
    const queue = service.getExecutionCapability(APPROVAL_EXECUTION_PROTOCOL_VERSION, state.runtime?.agentId);
    if (queue.capability !== APPROVAL_EXECUTION_CAPABILITY ||
        queue.protocolVersion !== APPROVAL_EXECUTION_PROTOCOL_VERSION) {
        throw new Error(`[ApprovalRoutes] incompatible approval execution capability: ${String(queue.capability)}@${String(queue.protocolVersion)}`);
    }
    return queue;
}
async function listServicePendingUserActions(state, serviceType) {
    const service = state.runtime?.getService(serviceType);
    if (!isPendingUserActionService(service))
        return [];
    return await service.listPendingUserActions();
}
async function listApprovalTaskActions(state) {
    const service = state.runtime?.getService(ServiceType.APPROVAL);
    if (!isApprovalTaskService(service))
        return [];
    const tasks = await service.getAllPendingApprovals();
    return tasks
        .map(approvalTaskToPendingAction)
        .filter((action) => action !== null);
}
function toIso(value) {
    return value ? value.toISOString() : null;
}
function approvalToDto(approval) {
    return {
        id: approval.id,
        state: approval.state,
        requestedBy: approval.requestedBy,
        subjectUserId: approval.subjectUserId,
        action: approval.action,
        payload: approval.payload,
        channel: approval.channel,
        reason: approval.reason,
        expiresAt: approval.expiresAt.toISOString(),
        resolvedAt: toIso(approval.resolvedAt),
        resolvedBy: approval.resolvedBy,
        resolutionReason: approval.resolutionReason,
        execution: approval.execution
            ? {
                ...approval.execution,
                claimedAt: approval.execution.claimedAt.toISOString(),
                dispatchStartedAt: toIso(approval.execution.dispatchStartedAt),
                reconciledAt: toIso(approval.execution.reconciledAt),
            }
            : null,
        createdAt: approval.createdAt.toISOString(),
        updatedAt: approval.updatedAt.toISOString(),
    };
}
function humanizeAction(action) {
    return action.replace(/_/g, " ");
}
function approvalToPendingUserAction(approval) {
    return {
        id: approval.id,
        kind: "approval",
        source: "approval-queue",
        title: approval.reason || `Approve ${humanizeAction(approval.action)}`,
        description: `${humanizeAction(approval.action)} via ${approval.channel}`,
        options: [
            { id: "approve", label: "Approve" },
            { id: "reject", label: "Reject", isCancel: true },
        ],
        expectedReplyKind: "approval",
        weight: PENDING_USER_ACTION_WEIGHT.approval,
        resolution: {
            target: "approval_service",
            requestId: approval.id,
        },
        data: {
            state: approval.state,
            action: approval.action,
            channel: approval.channel,
            requestedBy: approval.requestedBy,
            subjectUserId: approval.subjectUserId,
        },
        createdAt: approval.createdAt.getTime(),
        expiresAt: approval.expiresAt.getTime(),
    };
}
function parseTaskOptions(task) {
    const raw = task.metadata?.options;
    if (!Array.isArray(raw))
        return undefined;
    const options = [];
    for (const entry of raw) {
        if (typeof entry !== "object" || entry === null)
            continue;
        const record = entry;
        if (typeof record.name !== "string" || record.name.length === 0)
            continue;
        options.push({
            id: record.name,
            label: typeof record.description === "string" && record.description.length > 0
                ? record.description
                : record.name,
            ...(record.isDefault === true ? { isDefault: true } : {}),
            ...(record.isCancel === true ? { isCancel: true } : {}),
        });
    }
    return options.length > 0 ? options : undefined;
}
function resolveTaskCreatedAt(task) {
    const approvalRequest = task.metadata?.approvalRequest;
    if (approvalRequest && typeof approvalRequest === "object") {
        const createdAt = approvalRequest.createdAt;
        if (typeof createdAt === "number" && Number.isFinite(createdAt)) {
            return createdAt;
        }
    }
    return typeof task.createdAt === "number" ? task.createdAt : Date.now();
}
export function approvalTaskToPendingAction(task) {
    if (!task.id || !task.roomId)
        return null;
    return {
        id: task.id,
        kind: "task_approval",
        source: "approval-service",
        title: task.description?.trim() || task.name,
        roomId: task.roomId,
        options: parseTaskOptions(task),
        weight: PENDING_USER_ACTION_WEIGHT.task_approval,
        resolution: {
            target: "approval_service",
            requestId: task.id,
        },
        createdAt: resolveTaskCreatedAt(task),
    };
}
function dedupeAndSortPendingActions(actions) {
    const seen = new Set();
    const deduped = [];
    for (const action of actions) {
        if (seen.has(action.id))
            continue;
        seen.add(action.id);
        deduped.push(action);
    }
    return deduped.sort((a, b) => {
        const aTime = Number.isFinite(a.createdAt) ? a.createdAt : 0;
        const bTime = Number.isFinite(b.createdAt) ? b.createdAt : 0;
        if (bTime !== aTime)
            return bTime - aTime;
        return a.id.localeCompare(b.id);
    });
}
export async function handleApprovalRoute(req, res, pathname, method, state, helpers) {
    if (!pathname.startsWith("/api/approvals"))
        return false;
    if (method !== "GET" || pathname !== "/api/approvals") {
        helpers.error(res, "approval route not found", 404);
        return true;
    }
    const url = new URL(req.url ?? pathname, "http://localhost");
    const limit = parseLimit(url.searchParams.get("limit"));
    if (limit === null) {
        helpers.error(res, "limit must be a positive integer", 400);
        return true;
    }
    const parsedState = parseApprovalState(url.searchParams.get("state"));
    if (!parsedState.ok) {
        helpers.error(res, parsedState.message, 400);
        return true;
    }
    // Device payloads require the enrollment credential and are served only by
    // /api/client-devices; this legacy aggregate has no device authority. They
    // are excluded in the query so they cannot fill the limit and crowd out
    // other pending approvals, and filtered again below as defence in depth.
    const filter = {
        subjectUserId: null,
        state: parsedState.state,
        action: null,
        excludeAction: "device_action",
        limit,
    };
    const queue = getAgentApprovalQueue(state);
    const approvals = queue
        ? (await queue.list(filter)).filter((approval) => approval.action !== "device_action")
        : [];
    const [serviceActions, taskActions, promptActions] = await Promise.all([
        listServicePendingUserActions(state, ServiceType.APPROVAL),
        listApprovalTaskActions(state),
        listServicePendingUserActions(state, PENDING_PROMPTS_SERVICE),
    ]);
    const pending = dedupeAndSortPendingActions([
        ...approvals
            .filter((approval) => approval.state === "pending")
            .map(approvalToPendingUserAction),
        ...serviceActions,
        ...taskActions,
        ...promptActions,
    ]);
    const ownerEntityId = state.runtime?.agentId && typeof state.runtime.getSetting === "function"
        ? resolveOwnerEntityIdOrDefault(state.runtime)
        : null;
    helpers.json(res, {
        ownerEntityId,
        approvals: approvals.map(approvalToDto),
        pending,
        pendingUserActions: pending,
    });
    return true;
}
