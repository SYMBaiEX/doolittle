import { resolveRegisteredTokenRoleAccess } from "./boundary-role-resolver.js";
import { isDirectOwnerApiTokenAuthorized, isServerTokenAuthorized, resolveBoundaryRole, } from "./server-helpers-auth.js";
/** Raw trajectory context is an owner surface, not a session-tier read. */
export function isTrajectoryOwnerRequest(req, method, pathname, hostAuthorization, allowAmbientLocal = true) {
    if (isServerTokenAuthorized(req))
        return false;
    if (hostAuthorization.ok)
        return hostAuthorization.role === "OWNER";
    const access = resolveRegisteredTokenRoleAccess(req);
    if (access) {
        return (access.worldRole === "OWNER" &&
            (access.isAdmin || access.isRouteInScope(method, pathname)));
    }
    if (!allowAmbientLocal)
        return isDirectOwnerApiTokenAuthorized(req);
    return resolveBoundaryRole(req) === "OWNER";
}
