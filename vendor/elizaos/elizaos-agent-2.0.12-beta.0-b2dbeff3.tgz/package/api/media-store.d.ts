import type http from "node:http";
/** Validate the only filename shape accepted by the content-addressed store. */
export declare function isValidStoredMediaFileName(fileName: string): boolean;
/**
 * Matches served media URLs embedded in free text (e.g. a message body that
 * re-shares an image by pasting its capability URL). Shared by the export
 * capture and the orphan-media GC so both agree on what counts as a live
 * text reference; matches are re-validated through `mediaFileNameFromUrl`.
 */
export declare const MEDIA_URL_IN_TEXT_RE: RegExp;
/**
 * MIME types that are safe to render inline in a browser context. Everything
 * else — notably `image/svg+xml`, `application/pdf`, `text/html`, and
 * unknown/active types — is served with `Content-Disposition: attachment` so it
 * can never execute script on the dashboard origin (stored-XSS defence). SVG is
 * deliberately excluded: it is an XML document that can carry `<script>` and
 * event handlers. PDF is excluded for parity: inline plugin/viewer rendering
 * adds script surface the sandboxed CSP cannot fully confine, and these pre-auth
 * capability URLs must never inline-execute active content.
 */
export declare function isInlineSafeMime(mime: string): boolean;
/**
 * Sniff the leading bytes for active XML/HTML markup. Returns the TRUE dangerous
 * mime when the content is SVG or HTML, else null. Used to reconcile a declared
 * "safe image" mime against bytes that are really markup, so the store records
 * (and later serves) the truthful, attachment-served type — defence in depth on
 * top of the strict extension map and the nosniff header.
 */
export declare function sniffMarkupMime(buffer: Buffer): string | null;
export declare const DEFAULT_MEDIA_STORE_MAX_BYTES: number;
/**
 * What the last orphan-GC sweep kept (referenced or pinned names) and when it
 * ran. The size cap may only evict files that sweep saw as unreferenced.
 */
export interface MediaGcSweep {
    at: number;
    kept: ReadonlySet<string>;
}
/**
 * Resolve `ELIZA_MEDIA_STORE_MAX_BYTES`. Unset/empty/invalid tokens keep the
 * 2 GiB default so a silent `Number.parseInt("1e9") === 1` cannot evict the
 * store down to a 1-byte cap.
 */
export declare function resolveMediaStoreMaxBytes(raw: string | undefined): number;
export interface MediaFileStat {
    name: string;
    size: number;
    mtimeMs: number;
}
/**
 * Pure eviction policy: given the current files and a byte cap, return the
 * names to delete (oldest-by-mtime first) so the store drops to 90% of the
 * cap. Returns [] when already within budget. Only files the last GC sweep saw
 * as unreferenced, and that did not change since, are candidates: knowledge
 * originals, meeting recordings and school-calendar sources live here too and
 * cannot be re-created. Before the first sweep nothing is evicted. Exported
 * for unit tests.
 */
export declare function selectMediaToEvict(files: MediaFileStat[], cap: number, sweep: MediaGcSweep | null): string[];
export interface PersistedMedia {
    /** Served URL (`/api/media/<sha256>.<ext>`) for the stored bytes. */
    url: string;
    /** sha256 of the bytes — also the description-cache key. */
    hash: string;
    fileName: string;
}
export interface PersistedPrivateMedia {
    hash: string;
    fileName: string;
}
/**
 * Persist sensitive bytes in the canonical media directory under a filename
 * shape the pre-authenticated `/api/media` route deliberately rejects.
 */
export declare function persistPrivateMediaBytes(buffer: Buffer, mimeType: string): PersistedPrivateMedia;
/** Read private media bytes; public media names and traversal are rejected. */
export declare function readPrivateMediaBytes(fileName: string): Buffer | null;
/** Delete private media bytes after expiry, revocation, or single-use access. */
export declare function deletePrivateMediaFile(fileName: string): boolean;
/** Write bytes to the content-addressed store (idempotent) and return the served URL. */
export declare function persistMediaBytes(buffer: Buffer, mimeType: string): PersistedMedia;
/**
 * Stream bytes into the canonical media store without retaining the complete
 * attachment in memory. The pending file is private and becomes visible only
 * after its content identity and truthful extension are known.
 */
export declare function persistMediaStream(chunks: AsyncIterable<Uint8Array>, mimeType: string): Promise<PersistedMedia>;
/**
 * Read a stored media file's raw bytes by its `<sha256>.<ext>` name, or null if
 * absent. Only the strict content-addressed name pattern is accepted — anything
 * else (traversal segments, or a sibling ledger name like the GC-pin/redaction
 * JSON files) is rejected before the path is even resolved. Used by agent
 * backup/export to bundle referenced media bytes.
 */
export declare function readStoredMediaBytes(fileName: string): Buffer | null;
export interface StoredMediaByteRange {
    bytes: Buffer;
    start: number;
    end: number;
    total: number;
    complete: boolean;
}
/** Read at most 64 KiB from one content-addressed media object without loading its parent. */
export declare function readStoredMediaByteRange(fileName: string, offset: number, limit: number): StoredMediaByteRange | null;
/**
 * Write raw bytes to a stored media file by its `<sha256>.<ext>` name (the name
 * is the content hash, so this is idempotent). Only the strict content-addressed
 * name pattern is accepted — anything else (traversal segments, or a sibling
 * ledger name like the GC-pin/redaction JSON files) is rejected before the path
 * is even resolved. Used by agent restore/import to rehydrate the
 * content-addressed media store.
 */
export declare function writeStoredMediaFile(fileName: string, bytes: Buffer): boolean;
/**
 * Content-integrity check for a stored media file: the store is content-addressed
 * (`<sha256>.<ext>`, the sha256 of the bytes — see how filenames are minted
 * above), so the bytes MUST hash back to the name. Returns true only when
 * `fileName` is a strict content-addressed name AND `sha256(bytes)` equals its
 * 64-hex hash. Used at the restore/import boundary (#9963) to reject corrupt or
 * tampered backup media instead of silently writing bytes under a hash that
 * doesn't match their content — which would poison the dedup/capability
 * invariant the whole store relies on.
 */
export declare function storedMediaContentMatchesName(fileName: string, bytes: Buffer): boolean;
/** Persist a `data:` URL's bytes to the store; returns null for non-data URLs. */
export declare function persistDataUrl(dataUrl: string): PersistedMedia | null;
/** True when a URL already points at this store (no need to re-persist). */
export declare function isStoredMediaUrl(url: string): boolean;
/** Extract the stored filename (`<sha256>.<ext>`) from a served media URL, else null. */
export declare function mediaFileNameFromUrl(url: string): string | null;
/** Stored filenames (`<sha256>.<ext>`) of pinned wallpapers, newest last. */
export declare function readBackgroundPins(): string[];
/** Pin a served wallpaper URL so the orphan GC never collects it. */
export declare function pinBackgroundMedia(url: string): void;
/**
 * Delete stored media files not referenced by any live attachment. `referenced`
 * is the set of `<sha256>.<ext>` filenames still in use (built from message
 * attachment URLs via {@link mediaFileNameFromUrl}); pinned wallpapers (see
 * {@link pinBackgroundMedia} — client-side-only referents) are unioned in
 * here so every GC caller is safe by construction. Files younger than the
 * grace window are kept. Best-effort; returns counts.
 */
export declare function gcUnreferencedMedia(referenced: Set<string>): {
    removed: number;
    scanned: number;
};
/** Mime type a stored `<sha256>.<ext>` name serves as (derived, no index). */
export declare function mimeForStoredMediaFile(fileName: string): string;
/** True when a validated content-addressed name exists in the one media store. */
export declare function storedMediaFileExists(fileName: string): boolean;
export interface MediaFileInfo {
    fileName: string;
    url: string;
    hash: string;
    mimeType: string;
    size: number;
    createdAt: number;
}
/**
 * List every stored media file with derived metadata (size, mime, mtime) for
 * the Files surface. Read-only directory scan; never throws (returns [] on
 * failure). Metadata is derived (no separate index), matching the
 * content-addressed model — original filenames aren't retained here.
 */
export declare function listMediaFiles(): MediaFileInfo[];
/**
 * Delete a stored media file by its strict content-addressed name. Returns true
 * when removed. Validates the name + dir to defend against traversal.
 */
export declare function deleteMediaFile(fileName: string): boolean;
/**
 * Serve a media file for the IN-PROCESS route path (iOS/desktop/Android native
 * scheme handlers, where the WebView reaches the on-device agent over IPC with
 * no HTTP server). Returns a RouteHandlerResult-shaped object with a `Buffer`
 * body; the native bridge base64-encodes it losslessly.
 *
 * Honors a single-range `Range: bytes=…` header so `<audio>`/`<video>` can seek
 * over the native scheme: a satisfiable range yields `206 Partial Content` with
 * `Content-Range` and only the requested byte slice, an out-of-bounds range
 * yields `416`, and no range yields the full `200`. `Accept-Ranges: bytes` is
 * always advertised so the WebView knows seeking is available.
 */
export declare function handleMediaRouteRequest(pathname: string, method: string, rangeHeader?: string): {
    status: number;
    headers: Record<string, string>;
    body?: Buffer;
};
/**
 * Whether stored media requires an authenticated request. True only under the
 * protected profile, where a leaked capability URL must not disclose bytes;
 * ordinary hosts keep pre-auth capability serving.
 */
export declare function isMediaAuthRequired(): boolean;
/**
 * Serve a stored media file for `GET/HEAD /api/media/<name>`. Returns true when
 * the request was handled (including 404/400). Supports HTTP Range so `<video>`
 * / `<audio>` seeking works.
 */
export declare function serveMediaFile(req: http.IncomingMessage, res: http.ServerResponse, pathname: string): boolean;
/**
 * Generate a downscaled thumbnail from raw image bytes and persist it as its
 * own store entry. Returns the thumbnail's served URL, or null when the image
 * isn't thumbnailable / already small / the resizer is unavailable. Best-effort.
 */
export declare function persistImageThumbnail(source: Buffer, srcMimeType: string): Promise<string | null>;
/**
 * Pre-compute a thumbnail for an already-stored image file (e.g. an
 * agent-generated image just persisted from a data: URL). Reads the stored
 * bytes, downscales, and persists the thumbnail. Returns its served URL or null.
 */
export declare function ensureThumbnailForStoredFile(fileName: string): Promise<string | null>;
/** Best-effort: convert a `data:` URL on an attachment to a stored served URL. */
export declare function persistAttachmentUrlIfInline(url: string): string;
