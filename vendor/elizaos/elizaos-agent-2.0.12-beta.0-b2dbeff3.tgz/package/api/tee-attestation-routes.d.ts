import type { Route } from "@elizaos/host/protocol";
export declare const DSTACK_OPERATOR_ATTESTATION_PATH = "/api/tee/dstack/attestation";
/** Domain-separates operator challenges from every other report-data use. */
export declare function dstackOperatorReportData(nonceHex: string): string;
export declare const dstackOperatorAttestationRoute: Route;
