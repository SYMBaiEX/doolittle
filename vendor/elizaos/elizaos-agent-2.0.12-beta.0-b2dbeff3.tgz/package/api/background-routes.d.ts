import type { Route } from "@elizaos/host/protocol";
export declare const backgroundGenerateImageRoute: Route;
/**
 * Re-host a user-picked wallpaper into the content-addressed media store
 * (authenticated write — the same normalization the generate route performs),
 * so the client persists a short, stable `/api/media/<hash>` reference instead
 * of a multi-MB data URL that silently blows the localStorage quota.
 */
export declare const backgroundUploadImageRoute: Route;
