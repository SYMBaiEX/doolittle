/**
 * Runtime wiring for the local media store: a media route so on-device iOS
 * (in-process dispatch, no HTTP server) can serve media (public except under
 * the protected profile), an outgoing hook that
 * persists inline `data:` URLs to the store before they hit the DB/context, and
 * a periodic GC task that sweeps orphaned files.
 *
 * The pure store lives in `./media-store.ts`; this module only connects it to
 * the runtime (routes / pipeline hooks / tasks).
 */
import { type IAgentRuntime, type Memory } from "@elizaos/core";
import type { Route } from "@elizaos/host/protocol";
export declare const DEFAULT_MEDIA_REHOST_FETCH_TIMEOUT_MS = 10000;
/**
 * GET route for stored media. On HTTP platforms with a listening port the
 * `serveMediaFile` handler answers first and this route is never reached; it exists for the port-free native IPC path — iOS/desktop/Android
 * native scheme handlers (`eliza-local-agent://ipc/api/media/…`) that dispatch
 * in-process over `runtime.routes` with no HTTP server. The native bridge
 * base64-encodes the returned `Buffer` body losslessly.
 *
 * The `Range` request header is forwarded so `handleMediaRouteRequest` can
 * answer `206 Partial Content`, which is what lets `<audio>`/`<video>` seek
 * over the native scheme handler.
 *
 * `public` is a getter so it is resolved from the frozen protected-profile
 * capture, not at module load (route registration copies the value). Under
 * the protected profile (`isMediaAuthRequired`) the route is private, so the
 * native dispatcher and the HTTP runtime-route gate require an authorized
 * caller.
 */
export declare const mediaFileRoute: Route;
/**
 * Persist agent-generated / inline `data:` URL attachments to the content-
 * addressed store before the response is delivered + persisted, so a compact
 * served `/api/media/<hash>` URL lands in the message record instead of a
 * multi-KB base64 blob (which would bloat history + the agent's own context),
 * and pre-compute a thumbnail for stored images so the chat tile loads small.
 * Runs on `outgoing_before_deliver`, a mutator phase, so the rewrite propagates
 * to both the wire response and the saved memory.
 */
export declare function registerMediaPipelineHook(runtime: IAgentRuntime): void;
type MediaGcDiagnostics = Pick<IAgentRuntime, "logger" | "reportError">;
export declare function collectReferencedMedia(memories: Memory[], diagnostics?: MediaGcDiagnostics): Set<string>;
/**
 * Register the orphan-media GC worker. Queue-row creation happens after SQL
 * migrations at the awaited startup-maintenance boundary so plugin
 * initialization never launches an unowned database operation.
 */
export declare function registerMediaGcWorker(runtime: IAgentRuntime): void;
/** Ensure the daily media GC has one queue row after SQL is ready. */
export declare function scheduleMediaGc(runtime: IAgentRuntime): Promise<void>;
export {};
