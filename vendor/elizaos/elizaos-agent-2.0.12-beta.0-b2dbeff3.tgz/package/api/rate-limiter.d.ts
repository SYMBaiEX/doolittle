/**
 * Simple in-memory sliding-window rate limiter for API endpoints.
 *
 * Each key (typically `agentId:operationName`) tracks request timestamps
 * within a configurable window. When the count hits the limit, new requests
 * are rejected with a `retryAfterMs` hint.
 *
 * This is intentionally per-process / in-memory. It resets on restart, which
 * is fine for a local-first app — the goal is to prevent runaway scripts and
 * accidental tight loops, not to enforce billing quotas.
 */
export interface RateLimitConfig {
    /** Maximum number of requests allowed within the window. */
    maxRequests: number;
    /** Sliding window size in milliseconds. */
    windowMs: number;
}
export interface RateLimitResult {
    allowed: boolean;
    retryAfterMs: number;
}
/**
 * Check whether a request identified by `key` is within the rate limit
 * defined by `config`. If allowed, the request is recorded in the window.
 */
export declare function checkRateLimit(key: string, config: RateLimitConfig): RateLimitResult;
/** Clear all rate limit state (buckets + sweep clock). Useful in tests. */
export declare function resetRateLimits(): void;
