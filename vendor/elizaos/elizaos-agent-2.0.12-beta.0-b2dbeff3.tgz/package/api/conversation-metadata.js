/**
 * Conversation-metadata sanitization and room-persistence helpers. The
 * untrusted-input boundary is `sanitizeConversationMetadata`, which allowlists
 * the conversation `scope` and `automationType`, coerces id/name fields through
 * a non-empty-string guard, validates the waifu-chat owner wallet as a 0x
 * address, and drops everything else — so a client cannot smuggle an unknown
 * scope or a non-string id into the conversation system. The remaining helpers
 * fold sanitized metadata into a room's `webConversation` record, read it back
 * out (optionally pinned to a conversation id), and classify a scope as
 * automation- or page-scoped.
 */
import { asNonEmptyString, asObjectRecord as asRecord, } from "@elizaos/core";
const VALID_SCOPES = new Set([
    "general",
    "automation-coordinator",
    "automation-workflow",
    "automation-workflow-draft",
    "automation-draft",
    "page-character",
    "page-apps",
    "page-connectors",
    "page-phone",
    "page-plugins",
    "page-settings",
    "page-wallet",
    "page-browser",
    "page-automations",
    "page-knowledge",
    "page-transcripts",
]);
const VALID_AUTOMATION_TYPES = new Set(["coordinator_text", "workflow"]);
const normalizeOptionalString = asNonEmptyString;
export function sanitizeConversationMetadata(value) {
    const record = asRecord(value);
    if (!record) {
        return undefined;
    }
    const scope = normalizeOptionalString(record.scope);
    const automationType = normalizeOptionalString(record.automationType);
    const next = {};
    if (scope && VALID_SCOPES.has(scope)) {
        next.scope = scope;
    }
    if (automationType && VALID_AUTOMATION_TYPES.has(automationType)) {
        next.automationType =
            automationType;
    }
    const taskId = normalizeOptionalString(record.taskId);
    if (taskId)
        next.taskId = taskId;
    const triggerId = normalizeOptionalString(record.triggerId);
    if (triggerId)
        next.triggerId = triggerId;
    const workflowId = normalizeOptionalString(record.workflowId);
    if (workflowId)
        next.workflowId = workflowId;
    const workflowName = normalizeOptionalString(record.workflowName);
    if (workflowName)
        next.workflowName = workflowName;
    const draftId = normalizeOptionalString(record.draftId);
    if (draftId)
        next.draftId = draftId;
    const pageId = normalizeOptionalString(record.pageId);
    if (pageId)
        next.pageId = pageId;
    const sourceConversationId = normalizeOptionalString(record.sourceConversationId);
    if (sourceConversationId)
        next.sourceConversationId = sourceConversationId;
    const terminalBridgeConversationId = normalizeOptionalString(record.terminalBridgeConversationId);
    if (terminalBridgeConversationId) {
        next.terminalBridgeConversationId = terminalBridgeConversationId;
    }
    const waifuChatOwnerWallet = normalizeOptionalString(record.waifuChatOwnerWallet);
    if (waifuChatOwnerWallet &&
        /^0x[a-fA-F0-9]{40}$/.test(waifuChatOwnerWallet)) {
        next.waifuChatOwnerWallet = waifuChatOwnerWallet.toLowerCase();
    }
    const waifuChatRole = normalizeOptionalString(record.waifuChatRole);
    if (waifuChatRole === "admin" ||
        waifuChatRole === "user" ||
        waifuChatRole === "guest") {
        next.waifuChatRole = waifuChatRole;
    }
    return Object.keys(next).length > 0 ? next : undefined;
}
export function buildConversationRoomMetadata(conversation, ownerId, existingMetadata) {
    const base = (asRecord(existingMetadata) ?? {});
    const sanitized = sanitizeConversationMetadata(conversation.metadata);
    const next = {
        ...base,
        ownership: { ownerId },
    };
    if (sanitized) {
        next.webConversation = {
            conversationId: conversation.id,
            ...sanitized,
        };
    }
    else {
        delete next.webConversation;
    }
    return next;
}
export function extractConversationMetadataFromRoom(room, expectedConversationId) {
    const roomMetadata = asRecord(room?.metadata);
    if (!roomMetadata) {
        return undefined;
    }
    const stored = asRecord(roomMetadata.webConversation);
    if (!stored) {
        return undefined;
    }
    const storedConversationId = normalizeOptionalString(stored.conversationId);
    if (expectedConversationId !== undefined &&
        storedConversationId !== expectedConversationId) {
        return undefined;
    }
    return sanitizeConversationMetadata(stored);
}
export function isAutomationConversationMetadata(metadata) {
    return (metadata?.scope === "automation-coordinator" ||
        metadata?.scope === "automation-workflow" ||
        metadata?.scope === "automation-workflow-draft" ||
        metadata?.scope === "automation-draft");
}
export function isPageScopedConversationMetadata(metadata) {
    const scope = metadata?.scope;
    return typeof scope === "string" && scope.startsWith("page-");
}
