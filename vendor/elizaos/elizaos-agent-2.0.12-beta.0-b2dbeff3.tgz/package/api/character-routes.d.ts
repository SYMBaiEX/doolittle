/**
 * HTTP routes for reading and editing the running agent's character. Mounts the
 * `/api/character` surface: GET the merged character, PUT edits (validated,
 * persisted to the agent row so they survive restart, mirrored into the config
 * file, and journaled to character history), GET `/history`, GET `/random-name`,
 * GET `/schema` (the editable-field descriptor the dashboard renders), and POST
 * `/generate` (LLM-authored bio/system/style/examples via TEXT_SMALL). Renaming
 * rewrites speaker names and `{{agentName}}`/`{{name}}` tokens in the message
 * examples so the persona stays self-consistent.
 */
import { type AgentRuntime } from "@elizaos/core";
import type { ElizaConfig, RouteRequestContext } from "@elizaos/host/protocol";
interface CharacterParseIssueLike {
    path: PropertyKey[];
    message: string;
}
interface CharacterParseErrorLike {
    issues: CharacterParseIssueLike[];
}
type CharacterValidationResult = {
    success: true;
    data?: unknown;
} | {
    success: false;
    error: CharacterParseErrorLike;
};
export interface CharacterRouteState {
    runtime: AgentRuntime | null;
    agentName: string;
    config?: ElizaConfig;
}
export interface CharacterRouteContext extends RouteRequestContext {
    state: CharacterRouteState;
    pickRandomNames: (count: number) => string[];
    saveConfig?: (config: ElizaConfig) => void;
    validateCharacter: (body: Record<string, unknown>) => CharacterValidationResult;
}
/** Parse the optional character-history limit without silently truncating input. */
export declare function parseCharacterHistoryLimit(raw: string | null): number | null | undefined;
export declare function handleCharacterRoutes(ctx: CharacterRouteContext): Promise<boolean>;
export {};
