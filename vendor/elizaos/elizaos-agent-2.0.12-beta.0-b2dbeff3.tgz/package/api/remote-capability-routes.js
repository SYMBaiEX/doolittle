import net from "node:net";
import { CAPABILITY_ROUTER_SERVICE_TYPE, CapabilityError, decodeUrlPathComponent, ElizaError, isLoopbackHost, isPrivateIpAddress, logger, normalizeHostLike, } from "@elizaos/core";
import { connectCloudCapabilitySandbox, } from "../services/remote-capability-cloud-sandbox.js";
import { connectRemoteCapabilityEndpointProvider, directRemoteCapabilityEndpointProvider, normalizeEndpointTrustPolicyOptions, } from "../services/remote-capability-endpoint-provider.js";
import { assertCapabilityRouterEndpointIdAllowed, CAPABILITY_ROUTER_ALLOWED_MODULES_SETTING, CAPABILITY_ROUTER_TRUST_POLICY_SETTING, CAPABILITY_ROUTER_URLS_SETTING, CapabilityRouterReservedEndpointIdError, CapabilityRouterSettingError, parseCapabilityRouterEndpointsSetting, parseCapabilityRouterModuleAllowlistSetting, parseCapabilityRouterTrustPolicySetting, serializeCapabilityRouterModuleAllowlistSetting, serializeCapabilityRouterTrustPolicySetting, } from "../services/remote-capability-router-settings.js";
import { desktopCompanionCapabilityEndpointProvider, homeMachineCapabilityEndpointProvider, mobileCompanionCapabilityEndpointProvider, } from "../services/remote-capability-url-endpoint-providers.js";
import { detectClientPlatform, isDynamicLoadingAllowed, } from "./platform-detect.js";
/**
 * A persisted capability-router config value (endpoints, module allowlists,
 * trust policies or the trust audit trail) exists but cannot be parsed. The
 * connect handler refuses to persist rather than rewriting the value as empty,
 * which would silently erase every stored endpoint, policy and audit record.
 */
export class CapabilityRouterPersistedStateError extends ElizaError {
    name = "CapabilityRouterPersistedStateError";
    key;
    constructor(key, reason, options) {
        super(`Persisted ${key} is unreadable (${reason}); refusing to overwrite it. Repair or remove ${key} and retry.`, {
            code: "CAPABILITY_ROUTER_PERSISTED_STATE_CORRUPT",
            cause: options?.cause,
            context: { key, reason },
            severity: "fatal",
        });
        this.key = key;
    }
}
const ENDPOINTS_KEY = CAPABILITY_ROUTER_URLS_SETTING;
const ALLOWED_MODULES_KEY = CAPABILITY_ROUTER_ALLOWED_MODULES_SETTING;
const TRUST_POLICY_KEY = CAPABILITY_ROUTER_TRUST_POLICY_SETTING;
const TRUST_AUDIT_KEY = "ELIZA_CAPABILITY_ROUTER_TRUST_AUDIT";
export async function handleRemoteCapabilityRoutes(ctx) {
    const { req, res, method, pathname, runtime, readJsonBody, json, error } = ctx;
    if (pathname.startsWith("/api/capability-router/assets/")) {
        if (!runtime) {
            error(res, "Agent runtime unavailable", 503);
            return true;
        }
        if (method !== "GET" && method !== "HEAD") {
            error(res, "Method not allowed", 405);
            return true;
        }
        if (!isDynamicLoadingAllowed(detectClientPlatform(req))) {
            error(res, "Dynamic capability asset loading is not permitted on this platform.", 403);
            return true;
        }
        try {
            await serveCapabilityRouterAssetProxy(ctx, runtime);
        }
        catch (err) {
            error(res, err instanceof Error ? err.message : "Failed to load remote asset.", err instanceof CapabilityError ? 502 : 400);
        }
        return true;
    }
    if (pathname !== "/api/capability-router/connect") {
        return false;
    }
    if (method !== "POST") {
        error(res, "Method not allowed", 405);
        return true;
    }
    if (!runtime) {
        error(res, "Agent runtime unavailable", 503);
        return true;
    }
    const body = await readJsonBody(req, res, {
        requireObject: true,
    });
    if (body === null) {
        return true;
    }
    try {
        const unloadMissing = typeof body.unloadMissing === "boolean" ? body.unloadMissing : true;
        const persist = typeof body.persist === "boolean" ? body.persist : true;
        const allowedModuleIds = parseOptionalStringArray(body.allowedModuleIds, "allowedModuleIds");
        const trustPolicy = parseOptionalEndpointTrustPolicy(body.trustPolicy, "trustPolicy");
        const requestTimeoutMs = optionalPositiveInteger(body.requestTimeoutMs, "requestTimeoutMs");
        if (requestTimeoutMs instanceof Error) {
            error(res, requestTimeoutMs.message, 400);
            return true;
        }
        if (body.endpoint !== undefined && body.cloud !== undefined) {
            error(res, "Request body must include only one of 'endpoint' or 'cloud'.", 400);
            return true;
        }
        if (persist && ctx.config) {
            // Fail before connecting (and mutating runtime plugins) when the stored
            // state cannot be merged; persisting would otherwise erase it.
            readPersistedCapabilityRouterState(ctx.config.env?.vars ?? {});
        }
        if (body.endpoint !== undefined) {
            const providerMode = parseEndpointProviderMode(body.provider);
            const endpoint = parseDirectEndpoint(body.endpoint);
            const connectEndpointProvider = ctx.connectEndpointProvider ?? connectRemoteCapabilityEndpointProvider;
            const provider = getEndpointProvider(providerMode);
            const result = await connectEndpointProvider(runtime, {
                provider,
                provisionOptions: buildEndpointProvisionOptions(providerMode, endpoint, allowedModuleIds),
                unloadMissing,
                requestTimeoutMs: requestTimeoutMs ?? 60000,
                ...(allowedModuleIds === undefined ? {} : { allowedModuleIds }),
                ...(trustPolicy === undefined ? {} : { trustPolicy }),
            });
            const persistedEndpoint = result.endpoint ?? endpoint;
            if (persist) {
                await persistEndpoint(ctx, persistedEndpoint, allowedModuleIds, trustPolicy, {
                    mode: providerMode === "direct" ? "endpoint" : providerMode,
                    provider: result.providerId,
                    endpoint: persistedEndpoint,
                    allowedModuleIds,
                    sync: result.sync,
                });
            }
            json(res, {
                success: true,
                mode: providerMode === "direct" ? "endpoint" : providerMode,
                ...(providerMode === "direct" ? {} : { provider: providerMode }),
                endpoint: redactEndpoint(persistedEndpoint),
                persisted: persist,
                sync: serializeSyncResult(result.sync),
            });
            return true;
        }
        if (body.cloud !== undefined) {
            const cloud = parseCloudOptions(body.cloud);
            if (trustPolicy !== undefined && cloud.trustPolicy !== undefined) {
                error(res, "Cloud requests must set trustPolicy either at the top level or inside 'cloud', not both.", 400);
                return true;
            }
            if (allowedModuleIds !== undefined &&
                cloud.allowedModuleIds !== undefined) {
                error(res, "Cloud requests must set allowedModuleIds either at the top level or inside 'cloud', not both.", 400);
                return true;
            }
            const cloudAllowedModuleIds = allowedModuleIds ?? cloud.allowedModuleIds;
            const cloudTrustPolicy = trustPolicy ?? cloud.trustPolicy;
            const connectCloudSandbox = ctx.connectCloudSandbox ?? connectCloudCapabilitySandbox;
            const result = await connectCloudSandbox(runtime, {
                ...cloud,
                unloadMissing,
                ...(cloudAllowedModuleIds === undefined
                    ? {}
                    : { allowedModuleIds: cloudAllowedModuleIds }),
                ...(cloudTrustPolicy === undefined
                    ? {}
                    : { trustPolicy: cloudTrustPolicy }),
                requestTimeoutMs: requestTimeoutMs ?? 60000,
            });
            if (persist) {
                await persistEndpoint(ctx, result.endpoint, cloudAllowedModuleIds, cloudTrustPolicy, {
                    mode: "cloud",
                    provider: result.providerId,
                    endpoint: result.endpoint,
                    allowedModuleIds: cloudAllowedModuleIds,
                    sync: result.sync,
                });
            }
            json(res, {
                success: true,
                mode: "cloud",
                agentId: result.agentId,
                ...(result.jobId === undefined ? {} : { jobId: result.jobId }),
                endpoint: redactEndpoint(result.endpoint),
                persisted: persist,
                sync: serializeSyncResult(result.sync),
            });
            return true;
        }
        error(res, "Request body must include either 'endpoint' or 'cloud'.", 400);
        return true;
    }
    catch (err) {
        if (err instanceof CapabilityRouterReservedEndpointIdError) {
            error(res, err.message, 400);
            return true;
        }
        if (err instanceof CapabilityRouterPersistedStateError) {
            logger.error({
                src: "remote-capability-routes",
                code: err.code,
                key: err.key,
                error: err,
            }, "[capability-router] Refusing to persist over unreadable stored state");
            error(res, err.message, 500);
            return true;
        }
        error(res, err instanceof Error
            ? err.message
            : "Failed to connect capability router endpoint.", 400);
        return true;
    }
}
async function serveCapabilityRouterAssetProxy(ctx, runtime) {
    const { res, pathname, method } = ctx;
    const parsed = parseAssetProxyPath(pathname);
    const router = getRuntimeCapabilityRouter(runtime);
    const asset = await router.plugin.getAsset({
        endpointId: parsed.endpointId,
        moduleId: parsed.moduleId,
        path: parsed.assetPath,
    });
    const body = Buffer.from(asset.bodyBase64, "base64");
    const headers = {
        "Content-Type": asset.contentType,
        "Content-Length": body.byteLength,
        "Cache-Control": "no-cache",
        ...(asset.integrity === undefined
            ? {}
            : { "X-Eliza-Asset-Integrity": asset.integrity }),
    };
    const response = res;
    if (typeof response.writeHead === "function") {
        response.writeHead(200, headers);
    }
    else if (typeof response.setHeader === "function") {
        for (const [key, value] of Object.entries(headers)) {
            response.setHeader(key, value);
        }
    }
    response.end?.(method === "HEAD" ? undefined : body);
}
function parseAssetProxyPath(pathname) {
    const prefix = "/api/capability-router/assets/";
    const remainder = pathname.slice(prefix.length);
    const [encodedEndpointId, encodedModuleId, ...assetParts] = remainder.split("/");
    if (!encodedEndpointId || !encodedModuleId || assetParts.length === 0) {
        throw new Error("Capability asset URL must include endpoint id, module id, and path.");
    }
    const decodeAssetComponent = (raw, fieldName) => {
        const decoded = decodeUrlPathComponent(raw);
        if (!decoded.ok) {
            // error-policy:J3 malformed path encoding is explicit invalid input.
            throw new Error(`Invalid ${fieldName}: malformed URL encoding`);
        }
        return decoded.value;
    };
    const endpointId = decodeAssetComponent(encodedEndpointId, "endpoint id");
    const moduleId = decodeAssetComponent(encodedModuleId, "module id");
    const assetSegments = assetParts.map((part) => decodeAssetComponent(part, "asset path"));
    const hasUnsafeSegment = assetSegments.some((part) => !part || part === "." || part === ".." || part.includes("\\"));
    const assetPath = `/${assetSegments.join("/")}`;
    if (!endpointId.trim() || !moduleId.trim() || assetPath === "/") {
        throw new Error("Capability asset URL must include endpoint id, module id, and path.");
    }
    if (hasUnsafeSegment) {
        throw new Error("Capability asset URL path is not valid.");
    }
    return { endpointId, moduleId, assetPath };
}
function getRuntimeCapabilityRouter(runtime) {
    const router = runtime.getService?.(CAPABILITY_ROUTER_SERVICE_TYPE);
    if (!router) {
        throw new Error("Capability router service is not available.");
    }
    return router;
}
function persistEndpoint(ctx, endpoint, allowedModuleIds, trustPolicy, audit) {
    const config = ctx.config;
    const saveConfig = ctx.saveConfig;
    const persistConfigEnv = ctx.persistConfigEnv;
    if (!config || !saveConfig || !persistConfigEnv) {
        throw new Error("Capability router endpoint persistence is unavailable in this runtime.");
    }
    return persistEndpointInner({ config, saveConfig, persistConfigEnv }, endpoint, allowedModuleIds, trustPolicy, audit);
}
async function persistEndpointInner(ctx, endpoint, allowedModuleIds, trustPolicy, audit) {
    // A provider may assign its own id; never persist one that would be read
    // back as a global trust-policy option.
    assertCapabilityRouterEndpointIdAllowed(endpoint.id, "endpoint.id");
    const env = ctx.config.env ?? {};
    const vars = { ...(env.vars ?? {}) };
    // Read (and validate) every persisted value before the first write so a
    // corrupt value aborts the whole save instead of being overwritten.
    const persisted = readPersistedCapabilityRouterState(vars);
    const endpoints = mergePersistedEndpoints(persisted.endpoints, endpoint);
    const moduleAllowlists = mergePersistedModuleAllowlists(persisted.moduleAllowlists, endpoint.id, allowedModuleIds);
    const persistedTrustPolicy = mergePersistedTrustPolicies(persisted.trustPolicies, endpoint.id, trustPolicy);
    const sanitizedEndpoints = endpoints.map(({ token: _token, ...item }) => item);
    await ctx.persistConfigEnv("ELIZA_CAPABILITY_ROUTER_ENABLED", "true");
    await ctx.persistConfigEnv("ELIZA_CAPABILITY_ROUTER_URLS", JSON.stringify(endpoints));
    vars.ELIZA_CAPABILITY_ROUTER_ENABLED = "true";
    vars.ELIZA_CAPABILITY_ROUTER_URLS = JSON.stringify(sanitizedEndpoints);
    const serializedModuleAllowlists = serializeCapabilityRouterModuleAllowlistSetting(moduleAllowlists);
    if (serializedModuleAllowlists !== undefined) {
        vars.ELIZA_CAPABILITY_ROUTER_ALLOWED_MODULES = serializedModuleAllowlists;
    }
    else {
        delete vars.ELIZA_CAPABILITY_ROUTER_ALLOWED_MODULES;
    }
    const serializedTrustPolicy = serializeCapabilityRouterTrustPolicySetting(persistedTrustPolicy);
    if (serializedTrustPolicy !== undefined) {
        await ctx.persistConfigEnv("ELIZA_CAPABILITY_ROUTER_TRUST_POLICY", serializedTrustPolicy);
        vars.ELIZA_CAPABILITY_ROUTER_TRUST_POLICY = serializedTrustPolicy;
    }
    else {
        delete vars.ELIZA_CAPABILITY_ROUTER_TRUST_POLICY;
    }
    if (audit !== undefined) {
        vars.ELIZA_CAPABILITY_ROUTER_TRUST_AUDIT = JSON.stringify(appendTrustAuditRecord(persisted.trustAudit, audit));
    }
    ctx.config.env = {
        ...env,
        vars,
    };
    ctx.saveConfig(ctx.config);
}
/**
 * Reads every persisted capability-router value. An absent/blank value is
 * empty; a present value that cannot be parsed throws
 * {@link CapabilityRouterPersistedStateError}.
 */
function readPersistedCapabilityRouterState(vars) {
    return {
        endpoints: readPersistedSetting(() => parseCapabilityRouterEndpointsSetting(process.env[ENDPOINTS_KEY] ?? vars[ENDPOINTS_KEY])),
        moduleAllowlists: readPersistedSetting(() => parseCapabilityRouterModuleAllowlistSetting(process.env[ALLOWED_MODULES_KEY] ?? vars[ALLOWED_MODULES_KEY]) ?? { kind: "endpoints", endpoints: {} }),
        trustPolicies: readPersistedSetting(() => parseCapabilityRouterTrustPolicySetting(process.env[TRUST_POLICY_KEY] ?? vars[TRUST_POLICY_KEY]) ?? { global: {}, endpoints: {} }),
        trustAudit: readTrustAuditRecords(process.env[TRUST_AUDIT_KEY] ?? vars[TRUST_AUDIT_KEY]),
    };
}
/**
 * Runs a shared capability-router setting parser, reporting a malformed value
 * as {@link CapabilityRouterPersistedStateError} so the connect handler refuses
 * to overwrite it.
 */
function readPersistedSetting(parse) {
    try {
        return parse();
    }
    catch (err) {
        if (err instanceof CapabilityRouterSettingError) {
            throw new CapabilityRouterPersistedStateError(err.key, err.reason, {
                cause: err,
            });
        }
        throw err;
    }
}
function parsePersistedJson(key, value) {
    try {
        return JSON.parse(value);
    }
    catch (err) {
        throw new CapabilityRouterPersistedStateError(key, "invalid JSON", {
            cause: err,
        });
    }
}
function readTrustAuditRecords(value) {
    if (!value?.trim())
        return [];
    const parsed = parsePersistedJson(TRUST_AUDIT_KEY, value);
    if (!Array.isArray(parsed)) {
        throw new CapabilityRouterPersistedStateError(TRUST_AUDIT_KEY, "expected an array");
    }
    return parsed.map((record, index) => {
        if (!isTrustAuditRecord(record)) {
            throw new CapabilityRouterPersistedStateError(TRUST_AUDIT_KEY, `entry ${index} is not a trust audit record`);
        }
        return record;
    });
}
function appendTrustAuditRecord(existing, audit) {
    return [
        ...existing,
        {
            recordedAt: new Date().toISOString(),
            mode: audit.mode,
            provider: audit.provider,
            endpoint: redactEndpoint(audit.endpoint),
            allowedModuleIds: normalizeStringList(audit.allowedModuleIds ?? []),
            registered: audit.sync.registered.map((plugin) => plugin.name),
            skipped: [...audit.sync.skipped],
            unloaded: [...audit.sync.unloaded],
            trustDecisions: audit.sync.trustDecisions.map((decision) => ({
                ...decision,
            })),
        },
    ];
}
function isTrustAuditRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return false;
    }
    const record = value;
    return (typeof record.recordedAt === "string" &&
        typeof record.mode === "string" &&
        typeof record.provider === "string" &&
        !!record.endpoint &&
        typeof record.endpoint === "object" &&
        Array.isArray(record.allowedModuleIds) &&
        Array.isArray(record.registered) &&
        Array.isArray(record.skipped) &&
        Array.isArray(record.unloaded) &&
        Array.isArray(record.trustDecisions));
}
/**
 * Records this endpoint's allowlist. A stored global array stays global (the
 * runtime unions allowlists across endpoints), extended with any modules this
 * connect allows; per-endpoint entries are replaced or removed.
 */
function mergePersistedModuleAllowlists(existing, endpointId, allowedModuleIds) {
    const normalized = normalizeStringList(allowedModuleIds ?? []);
    if (existing.kind === "global") {
        return {
            kind: "global",
            moduleIds: normalizeStringList([...existing.moduleIds, ...normalized]),
        };
    }
    const next = Object.assign(Object.create(null), existing.endpoints);
    if (normalized.length === 0) {
        delete next[endpointId];
    }
    else {
        next[endpointId] = normalized;
    }
    return { kind: "endpoints", endpoints: next };
}
/** Replaces this endpoint's trust policy; global policy keys are kept as-is. */
function mergePersistedTrustPolicies(existing, endpointId, trustPolicy) {
    const next = Object.assign(Object.create(null), existing.endpoints);
    const normalized = normalizeEndpointTrustPolicyOptions(trustPolicy);
    if (Object.keys(normalized).length === 0) {
        delete next[endpointId];
    }
    else {
        next[endpointId] = normalized;
    }
    return { global: existing.global, endpoints: next };
}
function mergePersistedEndpoints(existing, next) {
    const normalizedNext = {
        ...next,
        baseUrl: next.baseUrl.replace(/\/+$/, ""),
    };
    const byKey = new Map();
    for (const endpoint of existing) {
        const key = endpoint.id || endpoint.baseUrl;
        byKey.set(key, {
            ...endpoint,
            baseUrl: endpoint.baseUrl.replace(/\/+$/, ""),
        });
    }
    byKey.set(normalizedNext.id || normalizedNext.baseUrl, normalizedNext);
    return [...byKey.values()];
}
function parseDirectEndpoint(value) {
    const body = requireObject(value, "endpoint");
    const id = optionalNonEmptyString(body.id, "endpoint.id") ?? "default";
    assertCapabilityRouterEndpointIdAllowed(id, "endpoint.id");
    return {
        id,
        baseUrl: requireHttpUrl(body.baseUrl, "endpoint.baseUrl"),
        ...optionalToken(body.token, "endpoint.token"),
    };
}
function parseEndpointProviderMode(value) {
    if (value === undefined || value === null || value === "")
        return "direct";
    const provider = requireNonEmptyString(value, "provider");
    if (provider === "direct" ||
        provider === "home-machine" ||
        provider === "mobile-companion" ||
        provider === "desktop-companion") {
        return provider;
    }
    throw new Error(`provider must be one of direct, home-machine, mobile-companion, or desktop-companion.`);
}
function getEndpointProvider(providerMode) {
    switch (providerMode) {
        case "direct":
            return directRemoteCapabilityEndpointProvider();
        case "home-machine":
            return homeMachineCapabilityEndpointProvider;
        case "mobile-companion":
            return mobileCompanionCapabilityEndpointProvider;
        case "desktop-companion":
            return desktopCompanionCapabilityEndpointProvider;
    }
}
function buildEndpointProvisionOptions(providerMode, endpoint, allowedModuleIds) {
    if (providerMode === "direct") {
        return {
            endpoint,
            ...(allowedModuleIds === undefined ? {} : { allowedModuleIds }),
        };
    }
    return {
        baseUrl: endpoint.baseUrl,
        endpointId: endpoint.id,
        ...(endpoint.token === undefined ? {} : { token: endpoint.token }),
        ...(allowedModuleIds === undefined ? {} : { allowedModuleIds }),
    };
}
function parseCloudOptions(value) {
    const body = requireObject(value, "cloud");
    const bio = parseOptionalStringArray(body.bio, "cloud.bio");
    const allowedModuleIds = parseOptionalStringArray(body.allowedModuleIds, "cloud.allowedModuleIds");
    const trustPolicy = parseOptionalEndpointTrustPolicy(body.trustPolicy, "cloud.trustPolicy");
    const endpointId = optionalNonEmptyString(body.endpointId, "cloud.endpointId");
    if (endpointId !== undefined) {
        assertCapabilityRouterEndpointIdAllowed(endpointId, "cloud.endpointId");
    }
    const timeoutMs = optionalPositiveInteger(body.timeoutMs, "cloud.timeoutMs");
    if (timeoutMs instanceof Error)
        throw timeoutMs;
    const pollIntervalMs = optionalPositiveInteger(body.pollIntervalMs, "cloud.pollIntervalMs");
    if (pollIntervalMs instanceof Error)
        throw pollIntervalMs;
    return {
        cloudApiBase: requireHttpUrl(body.cloudApiBase, "cloud.cloudApiBase"),
        authToken: requireNonEmptyString(body.authToken, "cloud.authToken"),
        name: requireNonEmptyString(body.name, "cloud.name"),
        ...(bio === undefined ? {} : { bio }),
        ...(endpointId === undefined ? {} : { endpointId }),
        ...optionalToken(body.token, "cloud.token"),
        ...(allowedModuleIds === undefined ? {} : { allowedModuleIds }),
        ...(trustPolicy === undefined ? {} : { trustPolicy }),
        ...(timeoutMs === undefined ? {} : { timeoutMs }),
        ...(pollIntervalMs === undefined ? {} : { pollIntervalMs }),
    };
}
function serializeSyncResult(sync) {
    return {
        registered: sync.registered.map((plugin) => plugin.name),
        unloaded: sync.unloaded,
        skipped: sync.skipped,
        trustDecisions: sync.trustDecisions,
    };
}
function redactEndpoint(endpoint) {
    return {
        id: endpoint.id,
        baseUrl: endpoint.baseUrl,
        hasToken: typeof endpoint.token === "string" && endpoint.token.length > 0,
    };
}
function requireObject(value, field) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error(`${field} must be an object.`);
    }
    return value;
}
function requireNonEmptyString(value, field) {
    if (typeof value !== "string" || value.trim().length === 0) {
        throw new Error(`${field} must be a non-empty string.`);
    }
    return value.trim();
}
function optionalNonEmptyString(value, field) {
    if (value === undefined)
        return undefined;
    return requireNonEmptyString(value, field);
}
function requireHttpUrl(value, field) {
    const text = requireNonEmptyString(value, field).replace(/\/+$/, "");
    let parsed;
    try {
        parsed = new URL(text);
    }
    catch {
        throw new Error(`${field} must be a valid URL.`);
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        throw new Error(`${field} must use http or https.`);
    }
    if (parsed.username || parsed.password) {
        throw new Error(`${field} must not include embedded credentials.`);
    }
    // SSRF guard: a remote-capability endpoint baseUrl is attacker-controlled by
    // any authenticated caller (dedicated agents are reachable from the internet
    // via the cloud proxy), and the router fetches it directly. Block literal
    // private/loopback/link-local IPs and internal hostnames so it can't be aimed
    // at cloud metadata (169.254.169.254) or internal services. Mirrors the host
    // blocklist in runtime/custom-actions.ts. (Does not resolve DNS, so a public
    // name pointing at a private address is not covered here.)
    const host = normalizeHostLike(parsed.hostname);
    if (!host ||
        host === "0.0.0.0" ||
        host === "metadata.google.internal" ||
        host.endsWith(".local") ||
        host.endsWith(".internal") ||
        isLoopbackHost(host) ||
        (net.isIP(host) !== 0 && isPrivateIpAddress(host))) {
        throw new Error(`${field} must not target a private, loopback, link-local, or internal address.`);
    }
    parsed.hash = "";
    parsed.search = "";
    return parsed.toString().replace(/\/+$/, "");
}
function optionalToken(value, field) {
    const token = optionalNonEmptyString(value, field);
    return token === undefined ? {} : { token };
}
function optionalPositiveInteger(value, field) {
    if (value === undefined)
        return undefined;
    if (typeof value !== "number" || !Number.isInteger(value) || value <= 0) {
        return new Error(`${field} must be a positive integer.`);
    }
    return value;
}
function parseOptionalStringArray(value, field) {
    if (value === undefined)
        return undefined;
    if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
        throw new Error(`${field} must be an array of strings.`);
    }
    return normalizeStringList(value);
}
function parseOptionalEndpointTrustPolicy(value, field) {
    if (value === undefined)
        return undefined;
    const body = requireObject(value, field);
    const allowedProvenanceIssuers = parseOptionalStringArray(body.allowedProvenanceIssuers, `${field}.allowedProvenanceIssuers`);
    const trustedProvenancePublicKeys = parseOptionalStringRecord(body.trustedProvenancePublicKeys, `${field}.trustedProvenancePublicKeys`);
    const trustPolicy = normalizeEndpointTrustPolicyOptions({
        ...(allowedProvenanceIssuers === undefined
            ? {}
            : { allowedProvenanceIssuers }),
        ...(trustedProvenancePublicKeys === undefined
            ? {}
            : { trustedProvenancePublicKeys }),
        ...optionalBooleanField(body.requireSignedProvenance, `${field}.requireSignedProvenance`, "requireSignedProvenance"),
        ...optionalBooleanField(body.requireVerifiedProvenance, `${field}.requireVerifiedProvenance`, "requireVerifiedProvenance"),
        ...optionalBooleanField(body.requireProvenanceDigestMatch, `${field}.requireProvenanceDigestMatch`, "requireProvenanceDigestMatch"),
    });
    return Object.keys(trustPolicy).length === 0 ? undefined : trustPolicy;
}
function optionalBooleanField(value, field, key) {
    if (value === undefined)
        return {};
    if (typeof value !== "boolean") {
        throw new Error(`${field} must be a boolean.`);
    }
    return value
        ? { [key]: true }
        : {};
}
function parseOptionalStringRecord(value, field) {
    if (value === undefined)
        return undefined;
    const body = requireObject(value, field);
    const result = Object.create(null);
    for (const [key, entry] of Object.entries(body)) {
        if (typeof entry !== "string") {
            throw new Error(`${field}.${key} must be a string.`);
        }
        const normalizedKey = key.trim();
        const normalizedValue = entry.trim();
        if (normalizedKey && normalizedValue) {
            result[normalizedKey] = normalizedValue;
        }
    }
    return result;
}
function normalizeStringList(values) {
    return [...new Set(values.map((value) => value.trim()).filter(Boolean))];
}
