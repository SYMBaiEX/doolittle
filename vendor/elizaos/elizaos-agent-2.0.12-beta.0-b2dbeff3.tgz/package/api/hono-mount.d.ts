import type { IncomingMessage, ServerResponse } from "node:http";
import { type AccessContext, type IAgentRuntime } from "@elizaos/core";
export declare const DEFAULT_MAX_HONO_BODY_BYTES: number;
export declare function tryHandleHonoRuntimeRoute(options: {
    req: IncomingMessage;
    res: ServerResponse;
    runtime: IAgentRuntime | null | undefined;
    isAuthorized: () => boolean;
    isTrustedLocal?: () => boolean;
    /** Boundary-resolved requester identity for per-viewer DTO selection (#14781). */
    accessContext?: () => AccessContext | undefined;
}): Promise<boolean>;
