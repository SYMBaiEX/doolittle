/**
 * Validated read/write surface for user-configurable models behind the
 * authenticated control API. `POST /api/models/config` checks every request
 * against the provider→model→efforts catalog (model-catalog.ts) before
 * touching config — Codex silently accepts an invalid
 * `model_reasoning_effort`, so this route is the enforcement seam — then
 * persists the selection to all three config seams at once:
 * `config.env.vars[KEY]`, `config.env[KEY]` (the section the orchestrator's
 * `readConfigEnvKey` re-reads per spawn), and `process.env[KEY]`.
 *
 * Chat-brain targets (small/large) require a runtime restart for the model
 * plugin to pick up the new ids, driven through the same idempotent
 * RuntimeOperationManager the provider-switch route uses — the config write
 * happens inside the operation's prepare step so a busy runtime rejects
 * without a half-applied config. Coding targets return without restart:
 * sub-agent spawns re-read the config env on every spawn. A coding write may
 * also be a defaultBackend-only body (no `model`), persisting just
 * ELIZA_DEFAULT_AGENT_TYPE — the application backend selection seam.
 * When a touched key
 * already carried a different process-env value that the config did not put
 * there (systemd service.env, shell export), the response lists it in
 * `conflictingServiceEnvKeys` as an honest warning — a full service restart
 * may resurrect the external value.
 *
 * `GET /api/models/config` reports the current effective value for every key
 * this route owns, with the source that won (`config.env` → `config.env.vars`
 * → `process.env`). `activeChat` names the serving provider only when its
 * runtime handler and direct-provider credential are usable. Unresolved vault
 * references and configured-but-unservable providers omit the field.
 */
import { type AgentRuntime } from "@elizaos/core";
import { type ElizaConfig, type RouteHelpers, type RouteRequestMeta } from "@elizaos/host/protocol";
import type { RuntimeOperationManager } from "../runtime/operations/types.js";
import { type ModelCatalog } from "./model-catalog.js";
export type ModelConfigTarget = "small" | "large" | "coding";
export type CodingBackend = "codex" | "claude" | "eliza-code";
export interface ModelConfigWriteBody {
    target: ModelConfigTarget;
    provider?: string;
    backend?: CodingBackend;
    /** Omittable only for the defaultBackend-only coding switch. */
    model?: string;
    effort?: string;
    /** Optional coding-backend switch, persisted as ELIZA_DEFAULT_AGENT_TYPE. */
    defaultBackend?: CodingBackend;
}
export interface ModelConfigRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json" | "readJsonBody"> {
    state: {
        config: ElizaConfig;
        runtime?: AgentRuntime | null;
    };
    saveElizaConfig: (config: ElizaConfig) => void;
    runtimeOperationManager: RuntimeOperationManager;
    /** Injectable catalog for tests; defaults to the live buildModelCatalog(). */
    catalog?: ModelCatalog;
    /** Injectable process env for tests; defaults to process.env. */
    processEnv?: NodeJS.ProcessEnv;
}
type ChatKeyFamily = "OPENAI" | "ANTHROPIC" | "ELIZAOS_CLOUD";
/**
 * The chat provider actually serving inference right now, resolved from the
 * canonical serviceRouting topology — the same signal the plugin-collector
 * uses to decide which model plugin loads. Cloud-proxy only reports
 * `elizacloud` when the runtime has a registered elizaOSCloud TEXT_SMALL
 * handler. Direct providers additionally require a matching text handler and
 * usable credential; an unresolved vault reference is never serving evidence.
 * `endpoint` is the host that answers, so operator surfaces
 * (/model show, the settings panel) can name what ACTUALLY serves instead
 * of guessing from OPENAI_BASE_URL, which stays pinned in the environment
 * even when cloud-proxy routing makes it inert.
 */
export interface ActiveChatInfo {
    provider: string;
    family: ChatKeyFamily;
    endpoint: string;
}
export declare function resolveActiveChat(config: ElizaConfig, processEnv: NodeJS.ProcessEnv, runtime?: AgentRuntime | null): ActiveChatInfo | null;
/**
 * Handle `GET`/`POST /api/models/config`. Returns true when the request was
 * handled.
 */
export declare function handleModelConfigRoutes(ctx: ModelConfigRouteContext): Promise<boolean>;
export {};
