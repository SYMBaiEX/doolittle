/**
 * Portable server-side image thumbnailing — pure-JS (pngjs + jpeg-js), no
 * native `sharp` (which can't load in the mobile JS bundle) and no jimp (whose
 * `@jimp/*` sub-packages don't resolve cleanly under bun's hoisting). The two
 * codecs are dynamically imported behind an indirected specifier so the mobile
 * bundler doesn't pull them in and every failure path returns null — callers
 * degrade gracefully to serving the full image.
 *
 * Covers PNG + JPEG, which is what agent-generated / connector-ingested images
 * are; browser/webview uploads already thumbnail client-side via `<canvas>` and
 * cover every other format (webp, etc.).
 */
/**
 * Downscale a PNG/JPEG buffer to a ≤512px JPEG thumbnail. Returns null when the
 * input isn't a supported raster, is already within bounds, declares dimensions
 * beyond the decode-time safety bounds, the codecs are unavailable, or decoding
 * fails.
 */
export declare function generateThumbnailBytes(source: Buffer, srcMimeType: string): Promise<{
    buffer: Buffer;
    mimeType: string;
} | null>;
