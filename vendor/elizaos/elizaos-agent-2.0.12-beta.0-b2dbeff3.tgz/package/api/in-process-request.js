const authenticatedInProcessRequests = new WeakMap();
export function markAuthenticatedInProcessRequest(request, authorization) {
    authenticatedInProcessRequests.set(request, authorization);
}
export function isAuthenticatedInProcessRequest(request) {
    return authenticatedInProcessRequests.has(request);
}
/** Original verified principal, never reconstructed from HTTP or model fields. */
export function getAuthenticatedInProcessAuthorization(request) {
    return authenticatedInProcessRequests.get(request);
}
