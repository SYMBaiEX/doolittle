import type { IAgentRuntime } from "@elizaos/core";
import { type DeviceCredential } from "@elizaos/plugin-assistant";
import type { MapsDeviceNavigation } from "@elizaos/plugin-maps/navigation";
type Operation = {
    kind: "select";
    place: Parameters<MapsDeviceNavigation["select"]>[0];
} | {
    kind: "start";
    request: Parameters<MapsDeviceNavigation["start"]>[0];
} | {
    kind: "reroute" | "stop";
};
/** Each call authenticates the current enrollment in the canonical SQL device store. */
export declare function handleMapsNavigationRelay(runtime: IAgentRuntime, credential: DeviceCredential, input: unknown, recheck?: () => Promise<void>): Promise<{
    protocol: number;
    request: null;
} | {
    protocol: number;
    request: {
        id: string;
        expiresAt: number;
        operation: Operation;
    };
}>;
export {};
