import { stringToUuid, validateUuid } from "@elizaos/core";
import { resolveRegisteredTokenRoleAccess } from "./boundary-role-resolver.js";
/**
 * Resolve the per-viewer access context for an HTTP request, or `undefined`
 * for the single-owner boundary (trunk-authorized callers and requests no
 * resolver recognizes — the latter never reach a private route handler anyway,
 * the 401 gate already refused them).
 */
export function resolveHttpAccessContext(req) {
    const access = resolveRegisteredTokenRoleAccess(req);
    if (!access)
        return undefined;
    const requesterEntityId = validateUuid(access.principal) ??
        stringToUuid(`boundary-principal:${access.providerId}:${access.principal}`);
    return {
        requesterEntityId,
        role: access.worldRole,
        isOwner: access.worldRole === "OWNER",
        source: access.providerId,
    };
}
