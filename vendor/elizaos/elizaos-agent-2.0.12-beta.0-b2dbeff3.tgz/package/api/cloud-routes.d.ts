/** Lazy host adapters for cloud routes; implementation belongs to plugin-elizacloud. */
import type { AgentCloudBillingRouteHandler, AgentCloudCompatRouteHandler, AgentCloudRouteHandler } from "./cloud-route-contracts.js";
export interface CloudConfigLike {
    apiKey?: string | null;
    baseUrl?: string | null;
    [key: string]: unknown;
}
export declare const handleCloudBillingRoute: AgentCloudBillingRouteHandler;
export declare const handleCloudCompatRoute: AgentCloudCompatRouteHandler;
export declare const handleCloudRoute: AgentCloudRouteHandler;
export declare function validateCloudBaseUrl(value: string): Promise<string | null>;
