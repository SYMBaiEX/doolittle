/**
 * Dispatches dynamic `/api/apps/<slug>/...` requests to the route module that
 * ships with each installed app package. Reserved top-level slugs (info,
 * installed, launch, …) are excluded so they fall through to their own
 * handlers; for any other slug it lazy-imports the app's route module, resolves
 * its `handleAppRoutes` export, and calls it with a `readJsonBody` pre-bound to the current request.
 */
import type { AppPackageRouteDispatchContext } from "@elizaos/host/protocol";
export declare function handleAppPackageRoutes(ctx: AppPackageRouteDispatchContext): Promise<boolean>;
