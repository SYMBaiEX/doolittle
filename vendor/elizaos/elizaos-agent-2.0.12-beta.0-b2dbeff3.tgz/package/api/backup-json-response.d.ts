/**
 * Streams full-agent backup manifests across the HTTP boundary without asking
 * Node's response writer to materialize one giant outgoing buffer.
 */
import type http from "node:http";
import { ElizaError } from "@elizaos/core";
import type { AgentBackupStateData } from "../services/agent-backup.js";
/**
 * Thrown when the backup download transport dies mid-stream (client disconnect
 * or socket error) instead of parking forever on a `drain` that can never
 * arrive. Mirrors the v2 capture writer's AGENT_BACKUP_V2_CLIENT_DISCONNECTED
 * policy: ephemeral, not a server fault.
 */
export declare class AgentBackupClientDisconnectedError extends ElizaError {
    readonly name = "AgentBackupClientDisconnectedError";
    constructor(message: string, options?: {
        cause?: unknown;
    });
}
/** Writes a restorable snapshot as chunked JSON while honoring backpressure. */
export declare function writeAgentBackupJsonResponse(res: http.ServerResponse, snapshot: AgentBackupStateData): Promise<void>;
