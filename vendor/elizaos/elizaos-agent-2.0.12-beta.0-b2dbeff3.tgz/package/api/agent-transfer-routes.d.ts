import type { AgentRuntime } from "@elizaos/core";
import type { RouteRequestContext } from "@elizaos/host/protocol";
export interface AgentTransferRouteState {
    runtime: AgentRuntime | null;
}
export interface AgentTransferRouteContext extends RouteRequestContext {
    state: AgentTransferRouteState;
    exportAgent: (runtime: AgentRuntime, password: string, options: {
        includeLogs: boolean;
        excludeSecrets: boolean;
    }) => Promise<Buffer>;
    estimateExportSize: (runtime: AgentRuntime) => Promise<unknown>;
    importAgent: (runtime: AgentRuntime, fileBuffer: Buffer, password: string) => Promise<unknown>;
    isAgentExportError: (error: unknown) => boolean;
}
export declare function handleAgentTransferRoutes(ctx: AgentTransferRouteContext): Promise<boolean>;
