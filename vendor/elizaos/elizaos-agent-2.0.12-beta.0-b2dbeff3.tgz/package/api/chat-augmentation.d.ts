/**
 * Adds language guidance and relevant document excerpts to API chat messages
 * before the planner sees them. The serial request path performs only cheap
 * lexical matching; semantic recall remains in the DOCUMENTS provider, where
 * provider composition can run it concurrently. Requester-aware document
 * access controls apply to both paths.
 */
export { userRequestFromAugmentedText } from "@elizaos/core";
import { type AgentRuntime, type createMessageMemory } from "@elizaos/core";
export declare function maybeAugmentChatMessageWithLanguage(message: ReturnType<typeof createMessageMemory>, preferredLanguage?: string): ReturnType<typeof createMessageMemory>;
export interface ChatDocumentAugmentationOptions {
    signal?: AbortSignal;
}
export declare function maybeAugmentChatMessageWithDocuments(runtime: AgentRuntime, message: ReturnType<typeof createMessageMemory>, options?: ChatDocumentAugmentationOptions): Promise<ReturnType<typeof createMessageMemory>>;
