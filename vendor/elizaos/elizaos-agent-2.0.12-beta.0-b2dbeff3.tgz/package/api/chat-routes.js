/**
 * Serves model-compatible chat APIs and adapts runtime replies for host routes.
 * Conversation routes reuse generation, request admission and reply persistence;
 * Node HTTP event framing lives in the dedicated stream writer.
 */
import crypto from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { parseChatFailureKind, parseChatTerminalFailure, } from "@elizaos/contracts";
import { asObjectRecord as asRecord, attestAuthenticatedApiDeliveryAudience, ChannelType, createMessageMemory, ElizaError, EventType, emitInferenceTiming, extractAssistantReplyText, getEntityRole, getInferenceTimer, hasAppliedUserFacingEffectProof, hasAtLeastRole, INFERENCE_MARKS, INSUFFICIENT_CREDITS_REPLY, InferenceTurnTimer, inheritIncomingMessagePersistence, isInsufficientCreditsError, isInsufficientCreditsMessage, isRateLimitError, isTextGenerationModelType, MESSAGE_SOURCE_CLIENT_CHAT, ModelType, markInference, nextInferenceTurnId, normalizeCharacterLanguage, normalizeEffectReceipts, PRIVACY_DENIED_TEXT, readActionReplyFailure, recordOwnerGrant, recordRoleGrant, renderInteractionsAsPlainText, revertedEffectReceiptIds, runWithInferenceTiming, runWithTrajectoryContext, stampAppConversationProvenance, stringToUuid, stripDashboardOnlyMarkers, tagsMayProduceEffects, timeInferenceSpan, toWellFormedUnicode, trackPostDeliveryTask, validateReadView, withRoomDeliverySettlement, } from "@elizaos/core";
import { isLinkedAccountProviderId, readAliasedEnv, } from "@elizaos/host/protocol";
import { bindDeviceRequestedActionPolicy, persistInferenceTimingSummary, shouldSkipResponseMemoryPersistence, } from "@elizaos/plugin-assistant";
import { agentIdentityName } from "../runtime/build-character-config.js";
import { estimateTokenCount, withModelUsageCapture, } from "../runtime/prompt-optimization.js";
import { resolveTrajectoryGrouping } from "../runtime/trajectory-internals.js";
import { startTrajectoryStepInDatabase } from "../runtime/trajectory-storage.js";
import { syncCharacterIntoConfig } from "../services/character-persistence.js";
import { ChatIdempotencyWaitAbortedError, createChatIdempotencyStore, } from "../services/chat-idempotency-service.js";
import { detectRuntimeModel } from "./agent-model.js";
import { cloneWithoutBlockedObjectKeys, hasBlockedObjectKeyDeep, } from "./blocked-object-keys.js";
import { maybeAugmentChatMessageWithDocuments, maybeAugmentChatMessageWithLanguage, } from "./chat-augmentation.js";
import { initSse, writeSseData, writeSseJson } from "./chat-stream-writer.js";
import { isClientVisibleNoResponse, isNoResponsePlaceholder, } from "./chat-text-helpers.js";
import { enrichChatUiViewMetadata } from "./chat-view-metadata.js";
import { resolveClientChatAdminEntityId } from "./client-chat-admin.js";
import { extractAnthropicSystemAndLastUser, extractCompatTextContent, extractOpenAiSystemAndLastUser, resolveCompatRoomKey, scopeCompatRoomKey, } from "./compat-utils.js";
import { executeFallbackParsedActions, parseFallbackActionBlocks, } from "./fallback-action-helpers.js";
import { loadLocalInferenceRouteApi, } from "./local-inference-server-api.js";
import { decodePathComponent, getErrorMessage, normalizeIncomingChatPrompt, resolveAppUserName, validateChatImages, } from "./server-helpers.js";
import { isAuthorized, isServerTokenAuthorized, } from "./server-helpers-auth.js";
import { readUiLanguageHeader } from "./server-helpers-config.js";
import { listViews } from "./views-registry.js";
import { updateWorldMetadataWithRetry } from "./world-metadata-retry.js";
const CHAT_APPEND_ONLY_STREAM_DIVERGENCE = "CHAT_APPEND_ONLY_STREAM_DIVERGENCE";
function createStreamingResponseAbortTracker(req, res, operation) {
    const controller = new AbortController();
    const registrations = [];
    let completed = false;
    const abort = () => {
        if (!completed && !controller.signal.aborted) {
            controller.abort(new Error(`${operation} client disconnected`));
        }
    };
    const register = (source, event, listener) => {
        if (typeof source?.on !== "function")
            return;
        source.on(event, listener);
        registrations.push({ source, event, listener });
    };
    const onResponseClose = () => {
        if (!res.writableEnded)
            abort();
    };
    // IncomingMessage.close describes request-body completion on current Node
    // and Bun releases, not the lifetime of the streamed response. The response
    // and socket events remain live after body parsing and therefore own
    // disconnect cancellation.
    register(req, "aborted", abort);
    register(req, "error", abort);
    register(res, "close", onResponseClose);
    register(res, "error", abort);
    register(req.socket, "close", abort);
    register(req.socket, "error", abort);
    if (req.aborted || req.destroyed || res.destroyed) {
        abort();
    }
    return {
        signal: controller.signal,
        dispose: () => {
            for (const { source, event, listener } of registrations) {
                source.off?.(event, listener);
            }
            registrations.length = 0;
        },
        markCompleted: () => {
            completed = true;
        },
    };
}
let localInferenceChatApiPromise = null;
/**
 * Resolve the plugin-local-inference chat API used to turn a local-inference
 * failure into a user-facing status (download prompts, switch-model hints, …).
 *
 * An error-reporting path must NEVER throw. On any platform the loaded module
 * can carry an `undefined` named export (tree-shake / circular-init artifact) —
 * which previously made the catch blocks throw
 * `getLocalInferenceChatStatus is not a function` and MASK the real error. So
 * validate the loaded functions and fall back to a status derived from the raw
 * error, guaranteeing the actual failure surfaces. The always-real subpath is
 * owned by `./local-inference-server-api.ts`.
 */
function getLocalInferenceChatApi() {
    localInferenceChatApiPromise ??=
        (async () => {
            const fallback = {
                getLocalInferenceChatStatus: async (_intent, error) => ({
                    text: error instanceof Error
                        ? error.message
                        : typeof error === "string" && error
                            ? error
                            : "Local inference is unavailable.",
                    localInference: {},
                }),
                handleLocalInferenceChatCommand: async (_intent, prompt) => ({
                    text: prompt,
                    localInference: {},
                }),
            };
            try {
                const mod = (await loadLocalInferenceRouteApi());
                return {
                    getLocalInferenceChatStatus: typeof mod.getLocalInferenceChatStatus === "function"
                        ? mod.getLocalInferenceChatStatus
                        : fallback.getLocalInferenceChatStatus,
                    handleLocalInferenceChatCommand: typeof mod.handleLocalInferenceChatCommand === "function"
                        ? mod.handleLocalInferenceChatCommand
                        : fallback.handleLocalInferenceChatCommand,
                };
            }
            catch {
                return fallback;
            }
        })();
    return localInferenceChatApiPromise;
}
const CHAT_MAX_BODY_BYTES = 20 * 1024 * 1024; // 20 MB (image-capable)
const chatIdempotency = createChatIdempotencyStore();
export { ChatIdempotencyWaitAbortedError };
/** Join an active keyed turn, replay its durable result, or own a fresh turn. */
export function admitChatMessageId(scope, clientMessageId, options = {}) {
    return chatIdempotency.admit(scope, clientMessageId, options);
}
/** Normalize a raw body value into a usable idempotency key, or `null` when
 *  absent/invalid. Exported for unit testing the dedupe decision in isolation. */
export function normalizeClientMessageId(value) {
    return chatIdempotency.normalize(value);
}
/** Release an active reservation held by the requesting turn. */
export function releaseChatMessageId(scope, clientMessageId, reservation) {
    chatIdempotency.release(scope, clientMessageId, reservation);
}
/**
 * Original arrival timestamp recorded for a `(scope, clientMessageId)` pair,
 * or `null` when the pair is unknown (never seen, expired and swept, or
 * released). A duplicate sighting never refreshes it, so diagnostics and
 * focused cache tests can distinguish the first request from later retries.
 */
export function getChatMessageIdFirstSeenAt(scope, clientMessageId) {
    return chatIdempotency.firstSeenAt(scope, clientMessageId);
}
/**
 * Bind the durable terminal result to the exact client idempotency key.
 *
 * A room-level "latest assistant memory" lookup cannot identify which of two
 * concurrent turns produced a reply. The first request records its result only
 * after that result is durable; a retry can then replay this exact outcome
 * without starting another model turn or borrowing a neighboring turn.
 */
/**
 * A provider wait counts from the failed attempt, so an idempotent replay must
 * not repeat it. Replays keep the typed failure without `rateLimit`.
 */
export function withoutLiveRateLimit(outcome) {
    if (!outcome.terminalFailure?.rateLimit)
        return outcome;
    const { rateLimit: _rateLimit, ...terminalFailure } = outcome.terminalFailure;
    return { ...outcome, terminalFailure };
}
export function setChatMessageIdOutcome(scope, clientMessageId, outcome, reservation) {
    chatIdempotency.settle(scope, clientMessageId, withoutLiveRateLimit(outcome), reservation);
}
/** Return the durable outcome bound to an exact idempotency key, if settled. */
export function getChatMessageIdOutcome(scope, clientMessageId) {
    return chatIdempotency.outcome(scope, clientMessageId);
}
/** Test-only: clear the HTTP chat idempotency cache between cases. */
export function __resetChatDedupeForTests() {
    chatIdempotency.reset();
}
/** Test-only: expose the configured dedupe window without freezing env policy
 *  into the unit fixtures. */
export function __getChatDedupeTtlMsForTests() {
    return chatIdempotency.retentionMs;
}
export function compareCreatedAtAscending(left, right) {
    if (left.createdAt === right.createdAt) {
        return (left.id ?? "").localeCompare(right.id ?? "");
    }
    const leftVal = typeof left.createdAt === "number" && Number.isFinite(left.createdAt)
        ? left.createdAt
        : -1;
    const rightVal = typeof right.createdAt === "number" && Number.isFinite(right.createdAt)
        ? right.createdAt
        : -1;
    return leftVal - rightVal || (left.id ?? "").localeCompare(right.id ?? "");
}
const POST_COMMIT_INTERRUPTED_REPLY = "The action finished before the response was interrupted. It was not run again.";
export function recoverSettledMutatingActionTurn(runtime, settledResults, interruption) {
    const allReceipts = settledResults.flatMap((result) => result.effectReceipts ?? []);
    const revertedReceiptIds = revertedEffectReceiptIds(allReceipts);
    const actionByName = new Map(runtime.actions.map((action) => [action.name, action]));
    const committedResults = settledResults.filter((result) => {
        const receipts = result.effectReceipts ?? [];
        const hasActiveAppliedReceipt = receipts.some((receipt) => receipt.outcome === "applied" &&
            !revertedReceiptIds.has(receipt.receiptId));
        if (receipts.length > 0)
            return hasActiveAppliedReceipt;
        if (result.data?.reconciliationRequired === true &&
            result.data?.retryable === false) {
            return true;
        }
        // Promoted read operations may inherit their mixed-capability parent's
        // write tags. The result's explicit read-only classification overrides
        // that legacy fallback, never receipt or unresolved-commit evidence.
        if (result.data?.readOnlyOperation === true)
            return false;
        const actionName = typeof result.data?.actionName === "string" ? result.data.actionName : "";
        return (result.success !== false &&
            tagsMayProduceEffects(actionByName.get(actionName)?.tags));
    });
    if (committedResults.length === 0)
        return null;
    const replyFailure = settledResults
        .map((result) => readActionReplyFailure(result.replyFailure))
        .find((failure) => failure !== undefined);
    let verifiedResult;
    try {
        verifiedResult = [...committedResults]
            .reverse()
            .find((result) => hasAppliedUserFacingEffectProof(result, allReceipts));
    }
    catch (error) {
        // error-policy:J4 conflicting receipt evidence degrades to the explicit
        // post-commit interruption reply rather than inventing action-specific text.
        runtime.logger.warn({
            src: "eliza-api",
            error: getErrorMessage(error),
        }, "Conflicting action receipts prevented exact post-commit reply recovery");
    }
    const verifiedText = verifiedResult?.userFacingText?.trim();
    const actionNames = Array.from(new Set(committedResults
        .map((result) => typeof result.data?.actionName === "string"
        ? result.data.actionName
        : "")
        .filter((name) => name.length > 0)));
    const text = replyFailure?.message ?? (verifiedText || POST_COMMIT_INTERRUPTED_REPLY);
    const cancelled = !isChatGenerationTimeoutError(interruption.error) &&
        (interruption.signal.aborted ||
            asRecord(interruption.error)?.name === "AbortError");
    return {
        text,
        outcome: cancelled
            ? {
                status: "cancelled",
                reason: "Turn interrupted after a committed action",
                effects: allReceipts,
            }
            : {
                status: "failed",
                error: replyFailure ?? {
                    kind: "handler_error",
                    code: "TURN_INTERRUPTED_AFTER_EFFECT",
                    transient: false,
                    message: text,
                },
                effects: allReceipts,
            },
        actionResults: [...settledResults],
        actionNames,
        ...(replyFailure ? { replyFailure } : {}),
    };
}
function isAppendOnlyStreamDivergenceError(error) {
    return (error instanceof ElizaError &&
        error.code === CHAT_APPEND_ONLY_STREAM_DIVERGENCE);
}
function resolveCallbackMergeMode(content, fallback = "replace") {
    return content.merge === "append" || content.merge === "replace"
        ? content.merge
        : fallback;
}
function normalizeActionCallbackText(text) {
    return text.trim();
}
function isInternalStructuredStreamPayload(value) {
    const record = asRecord(value);
    if (!record)
        return false;
    const type = typeof record.type === "string" ? record.type : "";
    if (type === "tool_call" || type === "tool_result" || type === "tool_error") {
        return true;
    }
    if (type === "evaluation" && asRecord(record.evaluation)) {
        return true;
    }
    if (asRecord(record.toolCall) || asRecord(record.toolResult)) {
        return true;
    }
    const contextEvent = asRecord(record.contextEvent);
    if (contextEvent) {
        const contextType = typeof contextEvent.type === "string" ? contextEvent.type : "";
        if (contextType === "tool" ||
            contextType === "tool_result" ||
            contextType === "tool_error") {
            return true;
        }
    }
    return false;
}
function isInternalStructuredStreamText(text) {
    const trimmed = text.trim();
    if (!trimmed.startsWith("{"))
        return false;
    try {
        return isInternalStructuredStreamPayload(JSON.parse(trimmed));
    }
    catch {
        // error-policy:J3 an unparseable "{"-prefixed chunk is not a structured
        // payload — let it flow to the visible text path, which handles it.
        return false;
    }
}
function firstNonEmptyString(...values) {
    for (const value of values) {
        if (typeof value === "string" && value.trim())
            return value.trim();
    }
    return undefined;
}
/** Coerce a tool-call's arguments (object, JSON string, or absent) into a plain
 *  record for the inline tool row, or undefined when there's nothing to show. */
function normalizeToolArgs(toolCall) {
    const raw = toolCall.arguments ?? toolCall.args ?? toolCall.input;
    const record = asRecord(raw);
    if (record)
        return record;
    if (typeof raw === "string" && raw.trim()) {
        try {
            const parsed = asRecord(JSON.parse(raw));
            if (parsed)
                return parsed;
        }
        catch {
            // error-policy:J3 a non-JSON args string is shown verbatim under `raw`.
            return { raw };
        }
    }
    return undefined;
}
/**
 * Project the runtime's internal planner/tool stream payload — forwarded through
 * `onStreamChunk` as a JSON string, then filtered out of the visible reply by
 * {@link isInternalStructuredStreamText} — onto the two chat surfaces it should
 * drive: the working-indicator phase (`running_tool` / `evaluating`) and, for
 * tool steps, an inline tool-call row. Returns null for payloads with no
 * chat-visible signal (e.g. `context_event`) so the caller drops them (#13535).
 */
export function chatEventsFromStructuredStreamPayload(payload) {
    const record = asRecord(payload);
    if (!record)
        return null;
    const type = typeof record.type === "string" ? record.type : "";
    if (type === "tool_call") {
        const toolCall = asRecord(record.toolCall);
        if (!toolCall)
            return null;
        const toolName = firstNonEmptyString(toolCall.name, toolCall.toolName, toolCall.tool, toolCall.action);
        if (!toolName)
            return null;
        const callId = firstNonEmptyString(toolCall.id, toolCall.toolCallId, record.messageId) ??
            toolName;
        const args = normalizeToolArgs(toolCall);
        return {
            status: { kind: "running_tool", toolName },
            toolEvent: {
                phase: "call",
                callId,
                toolName,
                ...(args ? { args } : {}),
            },
        };
    }
    if (type === "tool_result" || type === "tool_error") {
        const toolCall = asRecord(record.toolCall);
        const toolName = firstNonEmptyString(toolCall?.name, toolCall?.toolName, toolCall?.tool, toolCall?.action) ?? "tool";
        const callId = firstNonEmptyString(record.toolCallId, toolCall?.id, record.messageId) ??
            toolName;
        const statusText = firstNonEmptyString(record.status, toolCall?.status);
        const failed = type === "tool_error" || statusText === "failed";
        const result = record.result ?? toolCall?.result;
        const resultRecord = asRecord(result);
        const transcriptVisibility = resultRecord?.transcriptVisibility === "internal"
            ? "internal"
            : undefined;
        if (failed) {
            return {
                toolEvent: {
                    phase: "error",
                    callId,
                    toolName,
                    ...(transcriptVisibility ? { transcriptVisibility } : {}),
                    error: firstNonEmptyString(result, statusText) ?? "tool failed",
                },
            };
        }
        return {
            toolEvent: {
                phase: "result",
                callId,
                toolName,
                ...(transcriptVisibility ? { transcriptVisibility } : {}),
                result,
            },
        };
    }
    if (type === "evaluation") {
        return { status: { kind: "evaluating" } };
    }
    return null;
}
/** Text-level companion to {@link chatEventsFromStructuredStreamPayload}: parse a
 *  raw stream chunk and, when it is an internal structured payload, return the
 *  chat events it drives. Null when the chunk is visible reply text or an
 *  internal payload with no chat-visible signal. */
function chatEventsFromStructuredStreamText(text) {
    const trimmed = text.trim();
    if (!trimmed.startsWith("{"))
        return null;
    let parsed;
    try {
        parsed = JSON.parse(trimmed);
    }
    catch {
        // error-policy:J3 a non-JSON "{"-chunk is visible text, not a payload.
        return null;
    }
    if (!isInternalStructuredStreamPayload(parsed))
        return null;
    return chatEventsFromStructuredStreamPayload(parsed);
}
function getLatestVisibleResponseMessageText(responseMessages) {
    if (!Array.isArray(responseMessages) || responseMessages.length === 0) {
        return "";
    }
    for (let index = responseMessages.length - 1; index >= 0; index -= 1) {
        const content = responseMessages[index]?.content;
        if (content?.transcriptVisibility === "internal") {
            continue;
        }
        const text = typeof extractCompatTextContent(content) === "string"
            ? extractCompatTextContent(content).trim()
            : "";
        if (!text || isNoResponsePlaceholder(text)) {
            continue;
        }
        return text;
    }
    return "";
}
// ---------------------------------------------------------------------------
// Chat failure / no-response helpers
// ---------------------------------------------------------------------------
// Reserved for path #4 — actual generation throw caught by getChatFailureReply.
// Do NOT use as the generic empty-response fallback; that mislabels every
// IGNORE / empty-action / empty-normalized-text path as a provider failure.
const PROVIDER_ISSUE_CHAT_REPLY = "Sorry, I'm having a provider issue";
const MESSAGE_CONTENT_FAILURE_REPLY = "I couldn't process the stored message content.";
function isMessageContentFailure(err) {
    const code = asRecord(err)?.code;
    return typeof code === "string" && code.startsWith("MESSAGE_CONTENT_");
}
const REPLY_GROUNDING_FAILURE_REPLY = "I couldn't verify my reply against the available results.";
// Shared with the connector failure-reply path in @elizaos/core so every
// delivery surface phrases credit exhaustion identically.
const INSUFFICIENT_CREDITS_CHAT_REPLY = INSUFFICIENT_CREDITS_REPLY;
// A transient 429 (no billing context) — e.g. the shared model key briefly
// over its requests/min under concurrent load. Tell the user it's momentary so
// they retry, instead of the generic "provider issue" which reads as broken.
const RATE_LIMITED_CHAT_REPLY = "I'm being rate-limited right now — give it a few seconds and try again.";
/** Remote/large models can exceed the local default; distinguish from a broken provider. */
const GENERATION_TIMEOUT_CHAT_REPLY = "The model is taking too long to respond — it may still be loading. Wait a moment and try again.";
// Used by paths #1-#3: planner picked IGNORE/NONE/empty REPLY, action ran but
// emitted no text callback, or normalized text became empty. None of these are
// provider failures, so the message must not blame the provider.
const NO_RESPONSE_FALLBACK_REPLY = "I don't have a reply for that — try rephrasing?";
// Routed-model errors raised by the model router when no provider plugin is
// loaded for a requested model class (e.g. TEXT_SMALL). Identifies the OOB
// "no provider configured" case so chat routes can return a structured 503
// instead of a generic 500 — UI clients gate on `error.type === "no_provider"`
// to render a "Connect a provider" CTA instead of an opaque error toast.
const NO_PROVIDER_ERROR_FRAGMENTS = [
    "No provider registered for",
    "No model registered for",
];
const MISSING_DELEGATE_TYPE_PATTERN = /No handler found for delegate type:\s*([A-Z][A-Z0-9_]*)/i;
function isNoProviderError(err) {
    const msg = err instanceof Error ? err.message : typeof err === "string" ? err : "";
    if (NO_PROVIDER_ERROR_FRAGMENTS.some((frag) => msg.includes(frag))) {
        return true;
    }
    const missingDelegateType = msg.match(MISSING_DELEGATE_TYPE_PATTERN)?.[1];
    return isTextGenerationModelType(missingDelegateType);
}
const NO_PROVIDER_CHAT_MESSAGE = "Connect an LLM provider to start chatting. Open Settings → Providers, " +
    "or choose Eliza Cloud during first-run setup.";
const DEFAULT_CHAT_GENERATION_TIMEOUT_MS = 180000;
/** Remote Ollama (Pi → VPS) runs multiple model calls per turn; allow more headroom. */
const REMOTE_CHAT_GENERATION_TIMEOUT_MS = 600000;
const CHAT_GENERATION_TIMEOUT_PATTERN = /chat generation timed out after \d+ms/i;
const NON_EXECUTABLE_FALLBACK_ACTIONS = new Set([
    "REPLY",
    "NONE",
    "IGNORE",
    "PRIVACY_DENIED",
]);
function isExecutableFallbackAction(action) {
    return !NON_EXECUTABLE_FALLBACK_ACTIONS.has(action.name);
}
function classifySyntheticChatFailureText(text) {
    const normalized = text
        .trim()
        .toLowerCase()
        .replace(/[’]/g, "'")
        .replace(/\s+/g, " ");
    if (!normalized)
        return null;
    if (normalized === MESSAGE_CONTENT_FAILURE_REPLY.toLowerCase() ||
        normalized === REPLY_GROUNDING_FAILURE_REPLY.toLowerCase()) {
        return "handler_error";
    }
    if (normalized === PROVIDER_ISSUE_CHAT_REPLY.toLowerCase()) {
        return "provider_issue";
    }
    if (/\bprovider issue\b/.test(normalized)) {
        return "provider_issue";
    }
    if (normalized === NO_RESPONSE_FALLBACK_REPLY.toLowerCase()) {
        return "no_response";
    }
    if (normalized === INSUFFICIENT_CREDITS_CHAT_REPLY.toLowerCase()) {
        return "insufficient_credits";
    }
    if (normalized === RATE_LIMITED_CHAT_REPLY.toLowerCase()) {
        return "rate_limited";
    }
    if (normalized === GENERATION_TIMEOUT_CHAT_REPLY.toLowerCase()) {
        return "generation_timeout";
    }
    if (normalized === NO_PROVIDER_CHAT_MESSAGE.toLowerCase()) {
        return "no_provider";
    }
    if (normalized === "something went wrong on my end. please try again.") {
        return "transient_failure";
    }
    return null;
}
/**
 * Validate an untrusted `accountConnect` payload from a response Content into a
 * strict {@link AccountConnectRequest}. Returns `undefined` when the value is
 * absent, malformed, or carries no valid provider id — a broken/empty request
 * must not surface an empty block on the client.
 */
export function normalizeAccountConnectRequest(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return undefined;
    }
    const record = value;
    if (!Array.isArray(record.providers))
        return undefined;
    const providers = [];
    for (const provider of record.providers) {
        if (isLinkedAccountProviderId(provider) && !providers.includes(provider)) {
            providers.push(provider);
        }
    }
    if (providers.length === 0)
        return undefined;
    const reason = typeof record.reason === "string" && record.reason.trim()
        ? record.reason.trim()
        : undefined;
    return reason ? { providers, reason } : { providers };
}
export function markSyntheticChatFailureContent(content) {
    const text = extractCompatTextContent(content);
    const failureKind = typeof content.failureKind === "string"
        ? content.failureKind
        : classifySyntheticChatFailureText(text);
    if (!failureKind)
        return content;
    const metadata = asRecord(content.metadata);
    return {
        ...content,
        metadata: {
            ...(metadata ? metadata : {}),
            elizaSyntheticFailure: true,
            chatFailureKind: failureKind,
        },
    };
}
/** Keeps append-only delivery truthful when a late typed failure contradicts prose. */
function terminalFailureVisibleText(deliveredText, failure, replyUnavailable = false) {
    const delivered = deliveredText.trimEnd();
    if (!delivered)
        return failure.message;
    if (delivered.includes(failure.message))
        return deliveredText;
    return `${delivered}\n\n${replyUnavailable ? "" : "Task failed: "}${failure.message}`;
}
/** Converts the public DTO to Content's JSON-compatible indexed object shape. */
function terminalFailureContentValue(failure) {
    return {
        kind: failure.kind,
        message: failure.message,
        transient: failure.transient,
        ...(failure.code ? { code: failure.code } : {}),
    };
}
function normalizeActionName(value) {
    return typeof value === "string" ? value.trim().toUpperCase() : "";
}
function ensureMessageMemoryContent(content) {
    return typeof content.text === "string"
        ? { ...content, text: content.text }
        : { ...content, text: "" };
}
function buildRuntimeActionNameLookup(runtime) {
    const lookup = new Map();
    const runtimeActions = Array.isArray(runtime.actions)
        ? runtime.actions
        : [];
    for (const action of runtimeActions) {
        const canonicalName = normalizeActionName(action.name);
        if (!canonicalName) {
            continue;
        }
        lookup.set(canonicalName, canonicalName);
        if (!Array.isArray(action.similes)) {
            continue;
        }
        for (const alias of action.similes) {
            const normalizedAlias = normalizeActionName(alias);
            if (normalizedAlias) {
                lookup.set(normalizedAlias, canonicalName);
            }
        }
    }
    return lookup;
}
/**
 * Returns the action results recorded for `messageId`, or `[]` when the caller
 * asked about no message or the runtime exposes no reader. A reader that throws
 * rejects with `ElizaError` (`ACTION_RESULTS_READ_FAILED`) rather than
 * resolving `[]`: downstream `[]` means "no action succeeded", so a failed read
 * would be reported as unexecuted model actions instead of a read failure.
 */
export function readRuntimeActionResults(runtime, messageId) {
    if (!messageId) {
        return [];
    }
    const getActionResults = runtime.getActionResults;
    if (typeof getActionResults !== "function") {
        return [];
    }
    try {
        // AgentRuntime.getActionResults reads `this.stateCache`; keep the receiver.
        return getActionResults.call(runtime, messageId);
    }
    catch (error) {
        // error-policy:J2 context-adding rethrow — downstream `[]` means "no
        // action succeeded", so swallowing a read failure would make the route
        // fail a completed turn closed with a false "actions were not executed"
        // reply instead of reporting the read failure.
        throw new ElizaError("Failed to read action results for message", {
            code: "ACTION_RESULTS_READ_FAILED",
            cause: error,
            context: { messageId },
        });
    }
}
function readActionResultName(result) {
    if (!result || typeof result !== "object") {
        return "";
    }
    const record = result;
    if (typeof record.actionName === "string") {
        return normalizeActionName(record.actionName);
    }
    const data = record.data && typeof record.data === "object"
        ? record.data
        : null;
    return normalizeActionName(data?.actionName);
}
function listSuccessfulActionNames(runtime, messageId, turnActionResults, actionNameLookup) {
    const successfulNames = new Set();
    for (const result of listSuccessfulActionResults(runtime, messageId, turnActionResults)) {
        const normalizedName = readActionResultName(result);
        if (!normalizedName) {
            continue;
        }
        successfulNames.add(actionNameLookup.get(normalizedName) ?? normalizedName);
    }
    return successfulNames;
}
function listSuccessfulActionResults(runtime, messageId, turnActionResults) {
    return [
        ...(turnActionResults ?? []),
        ...readRuntimeActionResults(runtime, messageId),
    ].filter((result) => {
        if (!result ||
            typeof result !== "object" ||
            result.success !== true) {
            return false;
        }
        return Boolean(readActionResultName(result));
    });
}
function isProgressActionCallback(content) {
    const status = normalizeActionName(content.actionStatus);
    return (status === "PENDING" ||
        status === "QUEUED" ||
        status === "RUNNING" ||
        status === "IN_PROGRESS" ||
        status === "PROGRESS");
}
function sanitizeActionResultValue(value, ancestors = new WeakSet()) {
    if (value === null)
        return null;
    if (typeof value === "boolean")
        return value;
    if (typeof value === "number")
        return Number.isFinite(value) ? value : undefined;
    if (typeof value === "string") {
        return toWellFormedUnicode(value);
    }
    if (Array.isArray(value)) {
        if (ancestors.has(value)) {
            throw new Error("Action result contains a circular array");
        }
        ancestors.add(value);
        try {
            return value
                .map((entry) => sanitizeActionResultValue(entry, ancestors))
                .filter((entry) => entry !== undefined);
        }
        finally {
            ancestors.delete(value);
        }
    }
    if (value && typeof value === "object") {
        if (ancestors.has(value)) {
            throw new Error("Action result contains a circular object");
        }
        ancestors.add(value);
        try {
            const output = {};
            for (const [key, entry] of Object.entries(value)) {
                const safe = sanitizeActionResultValue(entry, ancestors);
                if (safe !== undefined)
                    output[key] = safe;
            }
            return output;
        }
        finally {
            ancestors.delete(value);
        }
    }
    return undefined;
}
function sanitizeActionResultValues(values) {
    if (!values || typeof values !== "object" || Array.isArray(values))
        return undefined;
    const output = {};
    for (const [key, value] of Object.entries(values)) {
        const safe = sanitizeActionResultValue(value);
        if (safe !== undefined)
            output[key] = safe;
    }
    return Object.keys(output).length > 0 ? output : undefined;
}
function summarizeActionResultForClient(result) {
    if (typeof result === "string") {
        const actionName = normalizeActionName(result);
        return actionName ? { actionName, success: true } : null;
    }
    if (!result || typeof result !== "object")
        return null;
    const record = result;
    const data = asRecord(record.data);
    const actionName = (typeof data?.actionName === "string" && data.actionName.trim()) ||
        (typeof record.actionName === "string" && record.actionName.trim()) ||
        undefined;
    // Planner tool results preserve ActionResult.values under data.values.
    // Prefer a direct ActionResult field when present, then recover the canonical
    // planner projection so renderer handoffs survive both execution paths.
    const values = sanitizeActionResultValues(record.values ?? data?.values);
    const text = typeof record.text === "string" && record.text.trim()
        ? String(sanitizeActionResultValue(record.text))
        : undefined;
    const error = typeof record.error === "string" && record.error.trim()
        ? String(sanitizeActionResultValue(record.error))
        : record.error instanceof Error
            ? record.error.message
            : undefined;
    // Opaque reference spelling is provider-owned, never an authorization check.
    // Persist only the validated, current revision-bound read metadata.
    let readData;
    if (record.success === true &&
        actionName === "MESSAGE_READ_MESSAGE" &&
        data &&
        (record.actionName === undefined || record.actionName === actionName)) {
        try {
            const readView = validateReadView(data.readView), control = asRecord(data.control), promptData = asRecord(record.promptData);
            if (promptData &&
                ((promptData.readView !== undefined &&
                    !isDeepStrictEqual(promptData.readView, data.readView)) ||
                    (promptData.control !== undefined &&
                        !isDeepStrictEqual(promptData.control, data.control))))
                throw Error("Conflicting read metadata");
            const safeView = isDeepStrictEqual(data.readView, readView) &&
                readView.reference.kind === "email" &&
                readView.reference.resumability === "restart-safe" &&
                (readView.reference.expiresAt === undefined ||
                    Date.parse(readView.reference.expiresAt) > Date.now()) &&
                typeof readView.reference.revision === "string" &&
                readView.reference.revision === readView.slice.revision;
            if (safeView &&
                readView.slice.completeness === "complete" &&
                data.control === undefined)
                readData = { actionName, readView };
            else if (safeView &&
                readView.slice.completeness === "partial-recoverable" &&
                control &&
                Object.keys(control).sort().join(",") ===
                    "action,expectedRevision,limit,offset,reference,source,unit" &&
                control.action === "read_message" &&
                control.source === "gmail" &&
                control.reference === readView.reference.ref &&
                control.expectedRevision === readView.reference.revision &&
                control.offset === readView.slice.nextOffset &&
                control.unit === readView.slice.range.unit &&
                Number.isSafeInteger(control.limit) &&
                Number(control.limit) > 0 &&
                Number(control.limit) <= 65536)
                readData = { actionName, readView, control: { ...control } };
        }
        catch {
            /* Malformed source metadata never becomes durable read authority. */
        }
    }
    const effectReceipts = normalizeEffectReceipts(record.effectReceipts);
    if (!actionName && !values && !text && !error && effectReceipts.length === 0)
        return null;
    return {
        ...(readData ? { data: readData } : {}),
        ...(effectReceipts.length ? { effectReceipts } : {}),
        ...(actionName ? { actionName } : {}),
        success: Boolean(record.success),
        ...(text ? { text } : {}),
        ...(error ? { error } : {}),
        ...(values ? { values } : {}),
    };
}
export function summarizeRuntimeActionResults(runtime, messageId, turnActionResults) {
    const actionResults = turnActionResults && turnActionResults.length > 0
        ? turnActionResults
        : readRuntimeActionResults(runtime, messageId);
    return actionResults
        .map(summarizeActionResultForClient)
        .filter((entry) => Boolean(entry));
}
function resolveFinalTranscriptVisibility(finalText, actionResults, contents = []) {
    if (!finalText)
        return undefined;
    return contents.some((content) => content?.transcriptVisibility === "internal" &&
        extractCompatTextContent(content) === finalText) ||
        actionResults?.some((result) => result.transcriptVisibility === "internal" && result.text === finalText)
        ? "internal"
        : undefined;
}
function pickInsufficientCreditsChatReply() {
    return INSUFFICIENT_CREDITS_CHAT_REPLY;
}
function findRecentInsufficientCreditsLog(logBuffer, lookbackMs = 60000) {
    const now = Date.now();
    for (let i = logBuffer.length - 1; i >= 0; i--) {
        const entry = logBuffer[i];
        if (now - entry.timestamp > lookbackMs)
            break;
        if (isInsufficientCreditsMessage(entry.message)) {
            return entry;
        }
    }
    return null;
}
export function resolveNoResponseFallback(logBuffer, _runtime, _lang = "en") {
    if (findRecentInsufficientCreditsLog(logBuffer)) {
        return pickInsufficientCreditsChatReply();
    }
    return NO_RESPONSE_FALLBACK_REPLY;
}
function getProviderIssueChatReply() {
    return PROVIDER_ISSUE_CHAT_REPLY;
}
export function isChatGenerationTimeoutError(err) {
    const msg = err instanceof Error ? err.message : typeof err === "string" ? err : "";
    return CHAT_GENERATION_TIMEOUT_PATTERN.test(msg);
}
function isRemoteOllamaEndpointConfigured() {
    const raw = readAliasedEnv("OLLAMA_BASE_URL") ?? readAliasedEnv("OLLAMA_API_ENDPOINT");
    if (!raw?.trim())
        return false;
    try {
        const normalized = raw.trim().replace(/\/api\/?$/i, "");
        const host = new URL(normalized).hostname.toLowerCase();
        return host !== "localhost" && host !== "127.0.0.1" && host !== "::1";
    }
    catch {
        return false;
    }
}
function resolveChatGenerationTimeoutMs(explicit) {
    if (typeof explicit === "number" &&
        Number.isFinite(explicit) &&
        explicit > 0) {
        return Math.max(1, Math.floor(explicit));
    }
    const fromEnv = readAliasedEnv("ELIZA_CHAT_GENERATION_TIMEOUT_MS");
    if (fromEnv) {
        // Number.parseInt stops at the first non-digit, so "60000junk" parsed to
        // a finite 60000 and was accepted as a deliberate setting instead of
        // falling back to the default. Require the whole trimmed value to be
        // decimal, mirroring resolveGenerationTimeoutMs in the discord plugin.
        const text = fromEnv.trim();
        const parsed = /^\+?\d+$/.test(text) ? Number(text) : Number.NaN;
        if (Number.isFinite(parsed) && parsed > 0) {
            return Math.max(1000, parsed);
        }
    }
    if (isRemoteOllamaEndpointConfigured()) {
        return REMOTE_CHAT_GENERATION_TIMEOUT_MS;
    }
    return DEFAULT_CHAT_GENERATION_TIMEOUT_MS;
}
function createChatGenerationTimeoutError(timeoutMs) {
    return new Error(`Chat generation timed out after ${timeoutMs}ms`);
}
/**
 * Run a generation under a wall-clock deadline, cancelling it on expiry.
 *
 * Racing a bare promise against a timer would leave the model call running
 * after the caller has already been told it failed — it would keep holding a
 * provider slot and keep emitting `onChunk` into a turn nobody is reading. So
 * the deadline drives a real `AbortSignal`, chained to any caller-supplied
 * signal, and `run` receives the options with that signal substituted in.
 */
export async function runWithGenerationTimeout(timeoutMs, createError, opts, run) {
    const controller = new AbortController();
    const callerSignal = opts?.abortSignal;
    const abortFromCaller = () => controller.abort(callerSignal?.reason);
    if (callerSignal?.aborted) {
        abortFromCaller();
    }
    else {
        callerSignal?.addEventListener("abort", abortFromCaller, { once: true });
    }
    let timedOut = false;
    const timeoutHandle = setTimeout(() => {
        timedOut = true;
        controller.abort(createError());
    }, timeoutMs);
    try {
        return await run({ ...(opts ?? {}), abortSignal: controller.signal });
    }
    catch (err) {
        // error-policy:J2 the abort surfaces as whatever the generation threw on
        // cancellation; re-key it to the typed deadline error so `classifyChatFailure`
        // reports `generation_timeout` rather than a generic provider issue.
        if (timedOut)
            throw createError();
        throw err;
    }
    finally {
        clearTimeout(timeoutHandle);
        callerSignal?.removeEventListener("abort", abortFromCaller);
    }
}
export function getChatFailureReply(err, logBuffer) {
    if (isMessageContentFailure(err))
        return MESSAGE_CONTENT_FAILURE_REPLY;
    if (asRecord(err)?.code === "REPLY_GROUNDING_FAILED") {
        return REPLY_GROUNDING_FAILURE_REPLY;
    }
    if (isInsufficientCreditsError(err) ||
        findRecentInsufficientCreditsLog(logBuffer)) {
        return pickInsufficientCreditsChatReply();
    }
    if (isNoProviderError(err)) {
        return NO_PROVIDER_CHAT_MESSAGE;
    }
    // After credits (a 429 *with* billing is "top up"): a bare 429 is transient.
    if (isRateLimitError(err)) {
        return RATE_LIMITED_CHAT_REPLY;
    }
    if (isChatGenerationTimeoutError(err)) {
        return GENERATION_TIMEOUT_CHAT_REPLY;
    }
    return getProviderIssueChatReply();
}
export function classifyChatFailure(err, logBuffer) {
    if (isMessageContentFailure(err))
        return "handler_error";
    if (asRecord(err)?.code === "REPLY_GROUNDING_FAILED") {
        return "handler_error";
    }
    if (isInsufficientCreditsError(err) ||
        findRecentInsufficientCreditsLog(logBuffer)) {
        return "insufficient_credits";
    }
    if (isNoProviderError(err)) {
        return "no_provider";
    }
    if (isLocalInferenceError(err)) {
        return "local_inference";
    }
    if (isRateLimitError(err)) {
        return "rate_limited";
    }
    if (isChatGenerationTimeoutError(err)) {
        return "generation_timeout";
    }
    return "provider_issue";
}
function normalizeIntentText(text) {
    return text
        .toLowerCase()
        .replace(/[`"'“”‘’]/g, "")
        .replace(/[_-]+/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}
function hasLocalInferenceTopic(text) {
    return (/\b(local|locally|on device|on-device|device model|local model|local inference|model hub|gguf|llama|inference|provider|runtime)\b/i.test(text) || /\bmodel\s+(?:download|install|load|setup)\b/i.test(text));
}
function isImperativeCloudOrLocalRouting(text) {
    return /^(?:please\s+)?(?:use|switch|prefer|route|go|move)\s+(?:me\s+)?(?:to\s+)?(?:the\s+)?(?:cloud|local|on device|on-device)\b/i.test(text);
}
export function detectLocalInferenceCommandIntent(text, options = {}) {
    const normalized = normalizeIntentText(text);
    if (!normalized)
        return null;
    const explicitContext = options.localInferenceContext === true ||
        hasLocalInferenceTopic(normalized) ||
        isImperativeCloudOrLocalRouting(normalized);
    if (!explicitContext)
        return null;
    if (/\b(?:use|switch|prefer|route|go|move)\s+(?:to\s+)?(?:the\s+)?cloud\b/.test(normalized) ||
        /\bcloud\s+(?:mode|provider|inference|model|routing)\b/.test(normalized)) {
        return "use_cloud";
    }
    if (/\b(?:status|progress|state|ready|loaded|loading|how far|what model)\b/.test(normalized) &&
        (options.localInferenceContext === true ||
            /\b(?:download|model|local|inference|gguf|eliza-1|provider|runtime)\b/.test(normalized))) {
        return "status";
    }
    if (/\b(?:use|switch|prefer|route|go|move)\s+(?:to\s+)?(?:the\s+)?(?:local|on device|on device model)\b/.test(normalized) ||
        /\b(?:local|on device)\s+(?:mode|provider|inference|model|routing)\b/.test(normalized)) {
        return "use_local";
    }
    if (/\b(?:smaller|smallest|tiny|lighter|lightweight|less memory|low ram|low memory)\b/.test(normalized) &&
        /\b(?:switch|use|load|pick|select|change|model)\b/.test(normalized)) {
        return "switch_smaller";
    }
    if (/\b(?:cancel|stop|abort|halt)\b/.test(normalized) &&
        /\b(?:download|model|local|inference)\b/.test(normalized)) {
        return "cancel";
    }
    if (/\b(?:re download|redownload|download again|fresh download)\b/.test(normalized)) {
        return "redownload";
    }
    if (/\b(?:retry|try again|resume|continue|restart)\b/.test(normalized) &&
        /\b(?:download|model|local|inference)\b/.test(normalized)) {
        return normalized.includes("resume") || normalized.includes("continue")
            ? "resume"
            : "retry";
    }
    if (/\b(?:download|install|get|fetch|pull)\b/.test(normalized) &&
        (options.localInferenceContext === true ||
            /\b(?:model|local|inference|gguf|eliza-1)\b/.test(normalized))) {
        return "download";
    }
    return null;
}
export function isLocalInferenceError(err) {
    const message = err instanceof Error ? err.message : typeof err === "string" ? err : "";
    return /\b(?:local inference|local model|on-device|device bridge|llama|gguf|capacitor-llama|no local model|model download|enospc|no space left|disk full)\b/i.test(message);
}
/**
 * Final text projection for chat-shaped API consumers (the trusted-local
 * `POST /api/agents/:id/message` mirror). These callers render plain chat —
 * the dashboard does NOT consume this endpoint (its chat uses the
 * session/chat routes and typed interaction payloads) — so interaction
 * grammar degrades to its text fallbacks and dashboard-only card markers
 * are stripped. Live leak this closes (matrix F2): [CONFIG:owner_finances]
 * and [FOLLOWUPS] blocks delivered verbatim in api replies
 * (tj-a5802a25580840, tj-a76213d5ae7164).
 */
export function renderChatSurfaceText(text) {
    if (!text)
        return text;
    const { text: rendered } = renderInteractionsAsPlainText(text);
    return stripDashboardOnlyMarkers(rendered);
}
export function normalizeChatResponseText(text, logBuffer, runtime) {
    // Both fallback strings can hit this path; either should be re-routed to
    // the insufficient-credits reply when a recent credits log explains why
    // generation produced nothing.
    const visibleText = extractAssistantReplyText(text) ?? text;
    const trimmed = visibleText.trim();
    if ((trimmed === PROVIDER_ISSUE_CHAT_REPLY ||
        trimmed === NO_RESPONSE_FALLBACK_REPLY) &&
        findRecentInsufficientCreditsLog(logBuffer)) {
        return pickInsufficientCreditsChatReply();
    }
    if (!isClientVisibleNoResponse(visibleText))
        return visibleText;
    return resolveNoResponseFallback(logBuffer, runtime);
}
function listResponseActions(responseContent) {
    if (!Array.isArray(responseContent?.actions)) {
        return [];
    }
    return responseContent.actions
        .map((action) => typeof action === "string" ? action.trim().toUpperCase() : "")
        .filter((action) => action.length > 0);
}
export function isIntentionalNoResponseResult(result, candidateText) {
    if (!result)
        return false;
    const actions = listResponseActions(result.responseContent);
    const hasSilentTerminalAction = actions.length === 1 && (actions[0] === "IGNORE" || actions[0] === "STOP");
    const hasNoVisibleText = candidateText.trim().length === 0 ||
        isClientVisibleNoResponse(candidateText);
    return (hasNoVisibleText && (result.didRespond === false || hasSilentTerminalAction));
}
function buildUnexecutedActionPayloadReply(actionNames) {
    const uniqueNames = [
        ...new Set(actionNames.map((name) => normalizeActionName(name)).filter(Boolean)),
    ];
    const actionsLabel = uniqueNames.length > 0 ? uniqueNames.join(", ") : "unknown";
    return [
        "I could not complete that request because the model returned actions that were not executed.",
        `Unexecuted actions: ${actionsLabel}.`,
    ].join("\n");
}
// ---------------------------------------------------------------------------
// SSE helpers
// ---------------------------------------------------------------------------
export { createChatTokenStreamWriter, initSse, writeChatStatusSse, writeChatToolSse, writeSse, writeSseData, writeSseJson, } from "./chat-stream-writer.js";
// ---------------------------------------------------------------------------
// Persistence helpers
// ---------------------------------------------------------------------------
function isDuplicateMemoryError(err) {
    if (!(err instanceof Error))
        return false;
    const msg = err.message.toLowerCase();
    return (msg.includes("duplicate") ||
        msg.includes("already exists") ||
        msg.includes("unique constraint"));
}
export async function persistConversationMemory(runtime, memory, roomHandlerLease, assertCurrent) {
    memory.id ??= crypto.randomUUID();
    const stampedMemory = stampAppConversationProvenance(runtime.agentId, memory);
    try {
        const write = () => {
            assertCurrent?.();
            return runtime.createMemory(stampedMemory, "messages");
        };
        await (roomHandlerLease
            ? runtime.roomHandlerQueue.runInLease(stampedMemory.roomId, roomHandlerLease, write)
            : write());
        assertCurrent?.();
    }
    catch (err) {
        if (isDuplicateMemoryError(err))
            return stampedMemory;
        throw err;
    }
    return stampedMemory;
}
export async function persistExactConversationMemory(runtime, memory, roomHandlerLease, assertCurrent) {
    return (await persistExactConversationMemoryResult(runtime, memory, roomHandlerLease, assertCurrent)).memory;
}
export async function persistExactConversationMemoryResult(runtime, memory, roomHandlerLease, assertCurrent) {
    if (!memory.id) {
        throw new ElizaError("Exact conversation memory is missing its durable id", {
            code: "CONVERSATION_MEMORY_ID_MISSING",
            context: { roomId: memory.roomId },
        });
    }
    const stampedMemory = stampAppConversationProvenance(runtime.agentId, memory);
    const loadExisting = async () => {
        const [existing] = await runtime.getMemoriesByIds([stampedMemory.id], "messages");
        assertCurrent?.();
        return existing ?? null;
    };
    const assertExact = (existing) => {
        if (existing.id === stampedMemory.id &&
            existing.roomId === stampedMemory.roomId &&
            existing.agentId === stampedMemory.agentId &&
            existing.entityId === stampedMemory.entityId &&
            isDeepStrictEqual(existing.content, stampedMemory.content)) {
            return existing;
        }
        throw new ElizaError("Conversation memory id is already bound to different content", {
            code: "CONVERSATION_MEMORY_ID_CONFLICT",
            context: {
                memoryId: stampedMemory.id,
                roomId: stampedMemory.roomId,
                agentId: stampedMemory.agentId,
                entityId: stampedMemory.entityId,
            },
        });
    };
    const existing = await loadExisting();
    if (existing)
        return { created: false, memory: assertExact(existing) };
    try {
        const write = () => {
            assertCurrent?.();
            return runtime.createMemory(stampedMemory, "messages");
        };
        await (roomHandlerLease
            ? runtime.roomHandlerQueue.runInLease(stampedMemory.roomId, roomHandlerLease, write)
            : write());
        assertCurrent?.();
        return { created: true, memory: stampedMemory };
    }
    catch (cause) {
        const raced = await loadExisting();
        if (raced)
            return { created: false, memory: assertExact(raced) };
        throw new ElizaError("Failed to store exact conversation memory", {
            code: "CONVERSATION_MEMORY_WRITE_FAILED",
            cause,
            context: {
                memoryId: stampedMemory.id,
                roomId: stampedMemory.roomId,
            },
        });
    }
}
async function hasRecentAssistantMemory(runtime, roomId, text, sinceMs) {
    const trimmed = text.trim();
    if (!trimmed)
        return false;
    try {
        const recent = await runtime.getMemories({
            roomId,
            tableName: "messages",
            limit: 12,
        });
        return recent.some((memory) => {
            const contentText = memory.content?.text?.trim();
            const createdAt = memory.createdAt ?? 0;
            return (memory.entityId === runtime.agentId &&
                contentText === trimmed &&
                createdAt >= sinceMs - 2000);
        });
    }
    catch (error) {
        // error-policy:J2 context-adding rethrow — this read guards a live chat
        // write; returning false here would persist a duplicate row and re-send a
        // prior turn exactly when storage is unhealthy and retries are likely.
        // Fail closed so the route boundary surfaces a retryable error instead.
        throw new ElizaError("Failed to read recent assistant memory for dedupe", {
            code: "ASSISTANT_DEDUPE_READ_FAILED",
            cause: error,
            context: { roomId },
        });
    }
}
/**
 * Reports whether the recent 12-message read contains a visible assistant
 * reply at or after `sinceMs - 2000`. A failed storage read rejects with `ElizaError`
 * (`ASSISTANT_MEMORY_READ_FAILED`) instead of resolving `false`: `false`
 * means no matching reply in that read, and callers must not catch the
 * rejection and substitute `false`.
 */
export async function hasRecentVisibleAssistantMemorySince(runtime, roomId, sinceMs) {
    return Boolean(await getRecentVisibleAssistantMemoryTextSince(runtime, roomId, sinceMs));
}
/**
 * Returns the newest visible assistant reply text at or after
 * `sinceMs - slackMs` in the recent 12-message read, or `null` when that
 * successful read contains no matching reply. A storage read
 * failure rejects with `ElizaError` (`ASSISTANT_MEMORY_READ_FAILED`) rather
 * than degrading to `null`, which would read as "no prior reply".
 */
export async function getRecentVisibleAssistantMemoryTextSince(runtime, roomId, sinceMs, 
// Pre-arrival slack. The boolean suppression callers keep the conservative
// 2s default (over-matching is safe when the answer is only "suppress").
// The dupe-RETURN callers pass 0: `sinceMs` (dedupe first-seen) and memory
// `createdAt` come from the same process clock, so any reply persisted
// before arrival belongs to a PREVIOUS turn — returning it would ship the
// prior turn's answer to a rapid-fire retry.
slackMs = 2000) {
    return ((await getRecentVisibleAssistantMemorySince(runtime, roomId, sinceMs, slackMs))?.text ?? null);
}
/**
 * Orders candidate assistant turns newest-first, treating a missing or
 * non-finite `createdAt` as epoch zero so a poisoned timestamp can never make
 * the comparator inconsistent, and breaking ties on ascending id so the
 * selected turn is deterministic rather than dependent on storage order.
 */
export function compareAssistantTurnRecencyDescending(a, b) {
    const bCreated = typeof b.createdAt === "number" && Number.isFinite(b.createdAt)
        ? b.createdAt
        : 0;
    const aCreated = typeof a.createdAt === "number" && Number.isFinite(a.createdAt)
        ? a.createdAt
        : 0;
    return (bCreated - aCreated ||
        (a.id ? String(a.id) : "").localeCompare(b.id ? String(b.id) : ""));
}
/**
 * Reads the most recent visible (non-internal) assistant turn at or after
 * `sinceMs - slackMs` among the recent 12 messages, newest first, as
 * `{ id, text }`. Resolves `null` when that successful read has no match; a failed storage read rejects
 * with `ElizaError` (`ASSISTANT_MEMORY_READ_FAILED`) wrapping the cause.
 * Fail closed is the contract: a fabricated "no prior reply" would regenerate
 * and re-send a previous turn's answer on rapid-fire retries. Reachable by
 * external consumers through `@elizaos/agent/api/chat-routes`.
 */
export async function getRecentVisibleAssistantMemorySince(runtime, roomId, sinceMs, slackMs = 2000) {
    try {
        const recent = await runtime.getMemories({
            roomId,
            tableName: "messages",
            limit: 12,
        });
        const persistedAssistantTurn = recent
            .filter((memory) => {
            const content = memory.content;
            const contentText = content.text?.trim();
            const createdAt = memory.createdAt ?? 0;
            return (memory.entityId === runtime.agentId &&
                content.transcriptVisibility !== "internal" &&
                Boolean(contentText) &&
                createdAt >= sinceMs - slackMs);
        })
            .sort(compareAssistantTurnRecencyDescending)[0];
        const text = persistedAssistantTurn?.content?.text?.trim();
        return persistedAssistantTurn?.id && text
            ? { id: persistedAssistantTurn.id, text }
            : null;
    }
    catch (error) {
        // error-policy:J2 context-adding rethrow — null means "no prior reply",
        // so swallowing a storage failure here would regenerate and re-send a
        // prior turn's answer on rapid-fire retries. Fail closed instead.
        throw new ElizaError("Failed to read recent visible assistant memory", {
            code: "ASSISTANT_MEMORY_READ_FAILED",
            cause: error,
            context: { roomId },
        });
    }
}
export async function persistAssistantConversationMemory(runtime, roomId, content, channelType, dedupeSinceMs, 
// Callers that need a deterministic retry key may supply the memory id. The
// returned Memory remains the authority for terminal transport metadata:
// callers emit `done` only after this write resolves and use its durable id
// to reconcile optimistic and proactive-message copies.
memoryId, roomHandlerLease, assertCurrent) {
    const persistedContent = markSyntheticChatFailureContent(typeof content === "string"
        ? {
            text: content,
            source: MESSAGE_SOURCE_CLIENT_CHAT,
            channelType,
        }
        : {
            ...content,
            text: extractCompatTextContent(content),
            source: typeof content.source === "string"
                ? content.source
                : MESSAGE_SOURCE_CLIENT_CHAT,
            channelType: typeof content.channelType === "string"
                ? content.channelType
                : channelType,
        });
    const trimmed = persistedContent.text.trim();
    if (!trimmed)
        return null;
    if (typeof dedupeSinceMs === "number" && !memoryId) {
        const alreadyPersisted = await hasRecentAssistantMemory(runtime, roomId, trimmed, dedupeSinceMs);
        if (alreadyPersisted)
            return null;
    }
    const memory = createMessageMemory({
        id: memoryId ?? crypto.randomUUID(),
        entityId: runtime.agentId,
        agentId: runtime.agentId,
        roomId,
        content: persistedContent,
    });
    return memoryId
        ? await persistExactConversationMemory(runtime, memory, roomHandlerLease, assertCurrent)
        : await persistConversationMemory(runtime, memory, roomHandlerLease, assertCurrent);
}
/**
 * Persist visible callback-delivered replies that the message service did not
 * commit. Exact source-turn IDs distinguish equal replies to different turns;
 * retries reuse the same durable row and reject changed content.
 */
export async function persistUnpersistedChatReply(runtime, message, result, _turnStartedAt) {
    const text = result.text;
    if (!text.trim() ||
        result.transcriptVisibility === "internal" ||
        result.noResponseReason === "ignored" ||
        isNoResponsePlaceholder(text)) {
        return null;
    }
    const persistedIds = new Set(result.persistedResponseMessageIds ?? []);
    const committedByService = (result.responseMessages ?? []).some((memory) => typeof memory.id === "string" &&
        persistedIds.has(memory.id) &&
        memory.entityId === runtime.agentId &&
        memory.roomId === message.roomId &&
        memory.content.text === text);
    if (committedByService)
        return null;
    const responseContent = result.responseContent && typeof result.responseContent === "object"
        ? { ...result.responseContent }
        : { text };
    delete responseContent.transcriptVisibility;
    const inReplyTo = responseContent.inReplyTo ?? message.id;
    const content = {
        ...responseContent,
        text,
        ...(inReplyTo ? { inReplyTo } : {}),
        source: typeof message.content.source === "string"
            ? message.content.source
            : MESSAGE_SOURCE_CLIENT_CHAT,
        channelType: ChannelType.API,
        ...(result.actionCallbackHistory && result.actionCallbackHistory.length > 0
            ? { actionCallbackHistory: [...result.actionCallbackHistory] }
            : {}),
    };
    if (shouldSkipResponseMemoryPersistence({
        content,
        roomId: message.roomId,
        entityId: runtime.agentId,
    })) {
        return null;
    }
    if (!message.id) {
        throw new ElizaError("Callback reply requires its source turn identity", {
            code: "CONVERSATION_MEMORY_ID_MISSING",
            context: { roomId: message.roomId },
        });
    }
    const replyId = stringToUuid(JSON.stringify([
        "compat-callback-reply",
        runtime.agentId,
        message.roomId,
        message.id,
    ]));
    return persistAssistantConversationMemory(runtime, message.roomId, content, ChannelType.API, undefined, replyId);
}
/**
 * Persist the terminal receipt for an aborted (Stop/disconnect) turn before
 * the route releases it. Unlike `persistAssistantConversationMemory` this
 * MUST persist even when no token streamed — a zero-token Stop still owns a
 * durable `interrupted` assistant row, otherwise reload recovery finds a user
 * turn with no terminal receipt and the transport is free to regenerate
 * (#17216). The row carries `content.interrupted: true`, which the GET
 * /messages DTO round-trips so the renderer shows the interrupted state
 * instead of a healthy-looking reply.
 */
export async function persistInterruptedAssistantReceipt(runtime, roomId, partialText, channelType, inReplyTo, memoryId, roomHandlerLease, assertCurrent) {
    const memory = createMessageMemory({
        id: memoryId,
        entityId: runtime.agentId,
        agentId: runtime.agentId,
        roomId,
        content: {
            text: partialText,
            interrupted: true,
            source: MESSAGE_SOURCE_CLIENT_CHAT,
            channelType,
            ...(inReplyTo ? { inReplyTo } : {}),
        },
    });
    return persistExactConversationMemory(runtime, memory, roomHandlerLease, assertCurrent);
}
// ---------------------------------------------------------------------------
// Chat request parsing
// ---------------------------------------------------------------------------
const VALID_CHANNEL_TYPES = new Set(Object.values(ChannelType));
function parseRequestChannelType(value, fallback = ChannelType.DM) {
    if (value === undefined || value === null) {
        return fallback;
    }
    if (typeof value !== "string") {
        return null;
    }
    const normalized = value.trim().toUpperCase();
    if (!VALID_CHANNEL_TYPES.has(normalized)) {
        return null;
    }
    return normalized;
}
export async function readChatRequestPayload(req, res, helpers, 
/** Body size limit. Image-capable endpoints pass CHAT_MAX_BODY_BYTES (20 MB);
 *  legacy/cloud-proxy endpoints that don't process images pass MAX_BODY_BYTES (1 MB). */
maxBytes = CHAT_MAX_BODY_BYTES) {
    const body = await helpers.readJsonBody(req, res, { maxBytes });
    if (!body)
        return null;
    const normalizedPrompt = normalizeIncomingChatPrompt(body.text, body.images);
    if (!normalizedPrompt) {
        helpers.error(res, "text is required");
        return null;
    }
    const channelType = parseRequestChannelType(body.channelType, ChannelType.DM);
    if (!channelType) {
        helpers.error(res, "channelType is invalid", 400);
        return null;
    }
    const imageValidationError = validateChatImages(body.images);
    if (imageValidationError) {
        helpers.error(res, imageValidationError, 400);
        return null;
    }
    const images = Array.isArray(body.images)
        ? body.images.map((img) => ({
            ...img,
            mimeType: img.mimeType.toLowerCase(),
        }))
        : undefined;
    const rawPreferredLanguage = (typeof body.language === "string" && body.language.trim()
        ? body.language
        : undefined) ?? readUiLanguageHeader(req);
    const preferredLanguage = rawPreferredLanguage
        ? normalizeCharacterLanguage(rawPreferredLanguage)
        : undefined;
    const source = typeof body.source === "string" && body.source.trim().length > 0
        ? body.source.trim()
        : undefined;
    const rawMetadata = body.metadata &&
        typeof body.metadata === "object" &&
        !Array.isArray(body.metadata)
        ? body.metadata
        : undefined;
    // Runtime-internal keys: a client could skip the inbound hardening hook, or
    // pair a forged isAutonomous with the autonomy source to unlock private actions.
    if (rawMetadata) {
        delete rawMetadata.isAutonomous;
        delete rawMetadata.skipIncomingMessageHooks;
    }
    const metadata = enrichChatUiViewMetadata(rawMetadata, helpers.runtime
        ? listViews(helpers.runtime, {
            developerMode: true,
            includeAllKinds: true,
            viewType: "gui",
        })
        : []);
    const clientMessageId = normalizeClientMessageId(body.clientMessageId);
    if (body.clientMessageId !== undefined && clientMessageId === null) {
        helpers.error(res, "clientMessageId must be a non-empty string of at most 128 characters", 400);
        return null;
    }
    // Consume this transport command in the authenticated request scope only;
    // it must not become model-facing or persisted message metadata.
    if (body.requestedActionPolicy !== undefined &&
        (!helpers.runtime ||
            !clientMessageId ||
            (channelType !== ChannelType.DM &&
                channelType !== ChannelType.VOICE_DM) ||
            !bindDeviceRequestedActionPolicy(helpers.runtime, body.requestedActionPolicy, clientMessageId))) {
        helpers.error(res, "Requested action policy requires a current authenticated device request", 403);
        return null;
    }
    return {
        prompt: normalizedPrompt,
        channelType,
        images,
        ...(preferredLanguage ? { preferredLanguage } : {}),
        ...(source ? { source } : {}),
        ...(metadata ? { metadata } : {}),
        ...(clientMessageId ? { clientMessageId } : {}),
    };
}
function readMessageTrajectoryStepId(message) {
    const metadata = message.metadata;
    if (!metadata || typeof metadata !== "object")
        return null;
    const stepId = metadata.trajectoryStepId;
    return typeof stepId === "string" && stepId.trim().length > 0
        ? stepId.trim()
        : null;
}
function readMessageTrajectoryGrouping(message) {
    const contentMetadata = asRecord(message.content.metadata) ?? {};
    const evalMetadata = asRecord(contentMetadata.eval) ?? {};
    const messageMetadata = asRecord(message.metadata) ?? {};
    return resolveTrajectoryGrouping({
        ...contentMetadata,
        ...evalMetadata,
        ...messageMetadata,
    });
}
function scheduleMessageTrajectoryGroupingPersistence(runtime, message) {
    const stepId = readMessageTrajectoryStepId(message);
    if (!stepId)
        return;
    const grouping = readMessageTrajectoryGrouping(message);
    if (!grouping.scenarioId && !grouping.batchId)
        return;
    void trackPostDeliveryTask(runtime, "chat:trajectory-grouping", async () => {
        await startTrajectoryStepInDatabase({
            runtime,
            stepId,
            source: typeof message.content.source === "string" &&
                message.content.source.trim().length > 0
                ? message.content.source
                : undefined,
            metadata: {
                ...(grouping.scenarioId ? { scenarioId: grouping.scenarioId } : {}),
                ...(grouping.batchId ? { batchId: grouping.batchId } : {}),
            },
        });
    }, { kind: "diagnostic" });
}
function buildChatUsage(runtime, message, finalText, capturedUsage) {
    const model = capturedUsage?.model ?? detectRuntimeModel(runtime, undefined) ?? undefined;
    if (capturedUsage) {
        return {
            promptTokens: capturedUsage.promptTokens,
            completionTokens: capturedUsage.completionTokens,
            totalTokens: capturedUsage.totalTokens,
            ...(capturedUsage.cacheReadInputTokens !== undefined
                ? { cacheReadInputTokens: capturedUsage.cacheReadInputTokens }
                : {}),
            ...(capturedUsage.cacheCreationInputTokens !== undefined
                ? { cacheCreationInputTokens: capturedUsage.cacheCreationInputTokens }
                : {}),
            ...(capturedUsage.cachedInputTokens !== undefined
                ? { cachedInputTokens: capturedUsage.cachedInputTokens }
                : {}),
            ...(model ? { model } : {}),
            ...(capturedUsage.provider ? { provider: capturedUsage.provider } : {}),
            isEstimated: capturedUsage.isEstimated,
            llmCalls: capturedUsage.llmCalls,
        };
    }
    const promptText = extractCompatTextContent(message.content);
    const promptTokens = estimateTokenCount(promptText);
    const completionTokens = estimateTokenCount(finalText);
    return {
        promptTokens,
        completionTokens,
        totalTokens: promptTokens + completionTokens,
        ...(model ? { model } : {}),
        isEstimated: true,
        llmCalls: 0,
    };
}
// ---------------------------------------------------------------------------
// generateChatResponse
// ---------------------------------------------------------------------------
async function generateChatResponseWithTiming(runtime, message, agentName, opts) {
    const generationAbortController = new AbortController();
    const abortGeneration = (reason) => {
        if (!generationAbortController.signal.aborted) {
            generationAbortController.abort(reason);
        }
    };
    const onExternalAbort = () => {
        abortGeneration(opts?.abortSignal?.reason);
    };
    if (opts?.abortSignal?.aborted) {
        onExternalAbort();
    }
    else {
        opts?.abortSignal?.addEventListener("abort", onExternalAbort, {
            once: true,
        });
    }
    let closeResponseFinalization;
    try {
        generationAbortController.signal.throwIfAborted();
        let responseText = "";
        // Snapshot consumers can replace prior text. Append-only transports need
        // their independently observed prefix so finalization can prove the
        // authoritative reply still matches bytes that have left the process.
        let appendOnlyText = "";
        let firstVisibleReplyMarked = false;
        let forcedWalletExecutionText = false;
        let blockedUnexecutedActionPayload = false;
        let activeStreamSource = "unset";
        let visibleCallbackDeliveries = 0;
        const deliveredActionAttachments = [];
        const deliveredActionCallbacks = [];
        // Snapshot of `responseText` at the moment the first action callback runs.
        // WHY: LLM streaming genuinely appends token deltas. Action handlers that
        // call HandlerCallback multiple times (Discord "progressive message" pattern)
        // send unrelated status strings — merging them with mergeStreamingText would
        // concatenate ("🔍…" + "✨…" + "Now playing…"). We preserve the streamed
        // prefix and replace only the callback suffix so the dashboard SSE client
        // gets snapshot fullText updates (same UX as editing one chat bubble).
        let preCallbackText = null;
        const messageSource = typeof message.content.source === "string" &&
            message.content.source.trim().length > 0
            ? message.content.source
            : "api";
        // De-duped status emitter for the rich indicator. Coalesces repeats of the
        // same phase (an action firing many callbacks should emit one
        // `running_action`, not one per chunk) by tracking the last signature.
        let lastStatusSignature = "";
        let planningAcknowledgment;
        const emitStatus = (status) => {
            if (!opts?.onStatus)
                return;
            const visibleStatus = planningAcknowledgment
                ? { ...status, label: planningAcknowledgment }
                : status;
            const signature = JSON.stringify(visibleStatus);
            if (signature === lastStatusSignature)
                return;
            lastStatusSignature = signature;
            opts.onStatus(visibleStatus);
        };
        // `thinking` is the opening phase: the turn started, the model is being
        // prompted, but no visible text has streamed yet.
        emitStatus({ kind: "thinking" });
        const markFirstVisibleReply = () => {
            if (firstVisibleReplyMarked)
                return;
            firstVisibleReplyMarked = true;
            markInference(INFERENCE_MARKS.firstVisibleReply);
        };
        const emitChunk = (chunk, origin = "model") => {
            if (!chunk)
                return;
            markFirstVisibleReply();
            responseText += chunk;
            if (opts?.onChunk) {
                opts.onChunk(chunk, origin);
                appendOnlyText += chunk;
            }
        };
        const emitSnapshot = (text, origin = "model") => {
            if (!text)
                return;
            // Skip when the snapshot matches the current responseText exactly:
            // re-emitting the same fullText forces clients to re-render an identical
            // bubble (and on-the-wire bytes for nothing).
            if (text === responseText)
                return;
            responseText = text;
            if (opts?.onSnapshot) {
                markFirstVisibleReply();
                opts.onSnapshot(text, origin);
            }
        };
        const claimStreamSource = (source) => {
            if (activeStreamSource === "unset") {
                activeStreamSource = source;
                // The first claim is the thinking→producing transition. Raw LLM tokens
                // are `streaming`; an action handler producing the reply is
                // `running_action` (its name is stamped by recordActionCallback).
                if (source === "onStreamChunk")
                    emitStatus({ kind: "streaming" });
                return true;
            }
            return activeStreamSource === source;
        };
        const appendIncomingText = (chunk, accumulated, origin = "model") => {
            // StreamChunkCallback defines `chunk` as a delta. Structured extractors
            // additionally provide their authoritative accumulation, which lets this
            // boundary recover an actual upstream rewrite without guessing from text
            // overlap. Applying overlap deduplication to genuine deltas corrupts valid
            // boundaries such as "Fast " + "streaming " and repeated tokens.
            if (accumulated === undefined) {
                emitChunk(chunk, origin);
                return;
            }
            if (accumulated === responseText)
                return;
            if (accumulated.startsWith(responseText)) {
                emitChunk(accumulated.slice(responseText.length), origin);
                return;
            }
            emitSnapshot(accumulated, origin);
        };
        const captureCallbackBaseline = () => {
            if (preCallbackText === null) {
                preCallbackText = responseText;
            }
        };
        /** Latest action callback wins: replaces prior callback text, keeps LLM prefix. */
        const replaceCallbackText = (incoming, origin = "action_callback") => {
            captureCallbackBaseline();
            const baseline = preCallbackText ?? "";
            const separator = baseline.length > 0 ? "\n\n" : "";
            const nextText = `${baseline}${separator}${incoming}`;
            // Heuristic: if the new callback text is a true append on top of the
            // currently streamed responseText, emit a delta chunk (cheap on the wire,
            // lets modern SSE clients append without re-rendering the whole bubble)
            // AND a snapshot for legacy clients that only consume `fullText`.
            // Otherwise (structural rewrite — Discord-style "🔍 searching" → "✨ done"
            // or planner restart), snapshot only.
            if (nextText === responseText)
                return;
            if (nextText.startsWith(responseText) &&
                responseText.length > 0 &&
                (opts?.onSnapshot || appendOnlyText === responseText)) {
                const delta = nextText.slice(responseText.length);
                emitChunk(delta, origin);
                // emitChunk already advanced responseText; re-emit snapshot for
                // legacy clients that only handle fullText updates.
                opts?.onSnapshot?.(nextText, origin);
                return;
            }
            emitSnapshot(nextText, origin);
        };
        const applyCallbackTextUpdate = (content, incoming, origin = "action_callback") => {
            captureCallbackBaseline();
            if (resolveCallbackMergeMode(content) === "append") {
                appendIncomingText(incoming, undefined, origin);
                return;
            }
            replaceCallbackText(incoming, origin);
        };
        // Inbound event consumers may persist correlation state or apply
        // turn-shaping policy. Generation cannot safely continue when that
        // prerequisite fails.
        // Stamp the request trace before trajectory listeners mint their own ID.
        // Preserve an existing originating trace on forwarded messages.
        const requestTraceId = getInferenceTimer()?.traceId;
        const originatingTraceId = asRecord(message.metadata)?.traceId;
        if (requestTraceId &&
            !(typeof originatingTraceId === "string" && originatingTraceId.trim())) {
            message.metadata ??= { type: "message" };
            message.metadata.traceId = requestTraceId;
        }
        if (typeof runtime.emitEvent === "function") {
            await timeInferenceSpan("chat:ingress:received-event", () => runtime.emitEvent(EventType.MESSAGE_RECEIVED, {
                message,
                source: messageSource,
            }));
        }
        generationAbortController.signal.throwIfAborted();
        const trajectoryStepId = readMessageTrajectoryStepId(message);
        const trajectoryContext = typeof trajectoryStepId === "string" && trajectoryStepId.trim().length > 0
            ? { trajectoryStepId: trajectoryStepId.trim() }
            : undefined;
        let result;
        let terminalFailure;
        let privacyDenied = false;
        let replyFailure;
        let trajectoryTerminalOwner;
        const settledActionResults = [];
        let capturedUsage = null;
        const recordActionCallback = (actionTag, hasText, text) => {
            const normalizedActionTag = normalizeActionName(actionTag);
            if (!normalizedActionTag) {
                return;
            }
            const normalizedText = hasText && text ? normalizeActionCallbackText(text) : "";
            if (normalizedText &&
                !deliveredActionCallbacks.some((entry) => entry.actionName === normalizedActionTag &&
                    entry.text === normalizedText)) {
                deliveredActionCallbacks.push({
                    actionName: normalizedActionTag,
                    text: normalizedText,
                });
            }
            emitStatus({
                kind: "running_action",
                actionName: normalizedActionTag,
            });
            runtime.logger.info({
                src: "eliza-api",
                action: normalizedActionTag,
                hasText,
            }, `[eliza-api] Action callback fired: ${normalizedActionTag}`);
        };
        const fallbackSuccessfulActionNames = new Set();
        const generationCapture = await withModelUsageCapture(runtime, () => Promise.resolve(runWithTrajectoryContext(trajectoryContext, async () => {
            generationAbortController.signal.throwIfAborted();
            // Plugin-registered chat pre-handlers (generic direct-dispatch
            // extension point): drained by priority before normal action
            // processing; the first non-null result resolves the turn.
            const preHandlerResult = await runtime.drainChatPreHandlers({
                runtime,
                message,
                abortSignal: generationAbortController.signal,
                appendText: replaceCallbackText,
                replaceText: emitSnapshot,
            });
            if (preHandlerResult) {
                // A handler that returns a terminal reply owns completion. A late
                // disconnect must not erase a completed direct dispatch and cause
                // the client retry to execute it again.
                const directText = preHandlerResult.responseText;
                const finalText = isClientVisibleNoResponse(directText)
                    ? directText || "(no response)"
                    : directText;
                result = {
                    outcome: { status: "completed", effects: [] },
                    didRespond: true,
                    responseContent: { text: finalText },
                    responseMessages: [],
                };
                responseText = finalText;
                forcedWalletExecutionText = isClientVisibleNoResponse(directText);
                return;
            }
            generationAbortController.signal.throwIfAborted();
            const languageAugmentedMessage = maybeAugmentChatMessageWithLanguage(message, opts?.preferredLanguage);
            const generationMessage = await timeInferenceSpan("chat:document-augmentation", () => maybeAugmentChatMessageWithDocuments(runtime, languageAugmentedMessage, { signal: generationAbortController.signal }), { phase: "pre-model" });
            inheritIncomingMessagePersistence(message, generationMessage);
            generationAbortController.signal.throwIfAborted();
            try {
                result = await timeInferenceSpan("chat:message-service", async () => runtime.messageService?.handleMessage(runtime, generationMessage, async (content, actionName) => {
                    if (content.transcriptVisibility === "internal") {
                        return [];
                    }
                    const chunk = extractCompatTextContent(content);
                    const visibleChunk = isInternalStructuredStreamText(chunk)
                        ? ""
                        : chunk;
                    const attributedActionName = normalizeActionName(actionName);
                    if (attributedActionName && content.attachments?.length) {
                        deliveredActionAttachments.push(...content.attachments);
                    }
                    const progressCallback = isProgressActionCallback(content);
                    if (!visibleChunk) {
                        if (attributedActionName) {
                            recordActionCallback(attributedActionName, false);
                        }
                        return [];
                    }
                    if (!claimStreamSource("callback")) {
                        if (attributedActionName) {
                            recordActionCallback(attributedActionName, false);
                        }
                        return [];
                    }
                    if (!progressCallback) {
                        visibleCallbackDeliveries += 1;
                    }
                    // Origin discriminates the two deliveries that ride this
                    // one callback: an ACTION's own callback carries its
                    // actionName (provisional status text the final reply may
                    // replace), while the reply handler's terminal delivery
                    // carries none (it IS the turn's reply). Voice clients key
                    // single-utterance behavior off this (see
                    // ChatStreamTextOrigin).
                    applyCallbackTextUpdate(content, visibleChunk, attributedActionName ? "action_callback" : "model");
                    if (attributedActionName) {
                        recordActionCallback(attributedActionName, !progressCallback, progressCallback ? undefined : visibleChunk);
                    }
                    return [];
                }, {
                    abortSignal: generationAbortController.signal,
                    roomHandlerLease: opts?.roomHandlerLease,
                    keepExistingResponses: true,
                    onPlanningAcknowledgment: opts?.onStatus
                        ? (text) => {
                            if (planningAcknowledgment ||
                                generationAbortController.signal.aborted)
                                return;
                            // One transient label survives tool phases without entering
                            // response text or durable terminal persistence.
                            planningAcknowledgment = text;
                            emitStatus({ kind: "thinking" });
                            markInference("chat:planning-acknowledgment");
                        }
                        : undefined,
                    onSettledActionResult: (actionResult) => {
                        settledActionResults.push(actionResult);
                    },
                    onTrajectoryTerminalOwner: (owner) => {
                        trajectoryTerminalOwner = owner;
                    },
                    onStreamChunk: opts?.onChunk
                        ? async (chunk, _messageId, accumulated) => {
                            if (!chunk)
                                return;
                            if (isInternalStructuredStreamText(chunk)) {
                                // A native planner/tool step, not visible reply text:
                                // fork it onto the working indicator + inline tool row
                                // instead of leaking JSON into the bubble.
                                const events = chatEventsFromStructuredStreamText(chunk);
                                if (events?.status)
                                    emitStatus(events.status);
                                if (events?.toolEvent) {
                                    opts?.onToolEvent?.(events.toolEvent);
                                }
                                return;
                            }
                            if (!claimStreamSource("onStreamChunk"))
                                return;
                            appendIncomingText(chunk, accumulated);
                        }
                        : undefined,
                }), { phase: "message" });
            }
            catch (error) {
                // error-policy:J1 this API boundary preserves a proven committed
                // effect while translating later turn failure into a durable reply.
                const recovery = recoverSettledMutatingActionTurn(runtime, settledActionResults, { error, signal: generationAbortController.signal });
                if (!recovery)
                    throw error;
                responseText = recovery.text;
                result = {
                    didRespond: !recovery.replyFailure,
                    responseContent: recovery.replyFailure
                        ? null
                        : {
                            text: recovery.text,
                            ...(recovery.actionNames.length > 0
                                ? { actions: recovery.actionNames }
                                : {}),
                        },
                    responseMessages: [],
                    actionResults: recovery.actionResults,
                    mode: "actions",
                    outcome: recovery.outcome,
                    ...(trajectoryTerminalOwner ? { trajectoryTerminalOwner } : {}),
                };
                runtime.logger.warn({
                    src: "eliza-api",
                    messageId: message.id,
                    roomId: message.roomId,
                    actionNames: recovery.actionNames,
                    error: getErrorMessage(error),
                }, "Recovered a settled mutating action after message processing stopped");
            }
            // A successful return preserves the completed model/message result,
            // but it is not permission to start optional post-processing after a
            // disconnect. The remaining path finalizes that result and only runs
            // new work while the owner signal is live.
            privacyDenied = Boolean(result?.responseContent?.actions?.includes("PRIVACY_DENIED") ||
                asRecord(result?.responseContent?.data)?.privacyDenied === true);
            terminalFailure = parseChatTerminalFailure(!privacyDenied && result?.outcome.status === "failed"
                ? result.outcome.error
                : undefined);
            replyFailure = privacyDenied
                ? undefined
                : result?.actionResults
                    ?.map((actionResult) => readActionReplyFailure(actionResult.replyFailure))
                    .find((failure) => failure !== undefined);
            if (terminalFailure) {
                const failureText = opts?.onChunk && !opts.onSnapshot
                    ? terminalFailureVisibleText(responseText, terminalFailure, replyFailure !== undefined)
                    : terminalFailure.message;
                if (opts?.onSnapshot && !replyFailure) {
                    emitSnapshot(failureText);
                }
                else {
                    responseText = failureText;
                }
            }
            // Ensure MESSAGE_SENT hooks run for API chat flows.
            try {
                const responseMessages = Array.isArray(result?.responseMessages)
                    ? result.responseMessages
                    : [];
                const baseFallbackResponseContent = result?.responseContent &&
                    typeof result.responseContent === "object"
                    ? result.responseContent
                    : responseText
                        ? { text: responseText }
                        : null;
                const fallbackResponseContent = terminalFailure
                    ? {
                        ...(baseFallbackResponseContent ?? {}),
                        text: responseText,
                        failureKind: terminalFailure.kind,
                        terminalFailure: terminalFailureContentValue(terminalFailure),
                        ...(replyFailure
                            ? {
                                elizaSyntheticFailure: true,
                                agentVoiced: false,
                                replyFailure: { ...replyFailure },
                            }
                            : {}),
                    }
                    : baseFallbackResponseContent;
                // Safety net ONLY for flows where the message handler produced no
                // responseMessages of its own. When responseMessages exist the
                // handler already emitted MESSAGE_SENT for each (message.ts), so
                // re-emitting them here double-fires MESSAGE_SENT for one reply
                // (eliza#10313). Emit just the synthetic fallback in the
                // no-responseMessages case.
                const messagesToEmit = responseMessages.length > 0
                    ? []
                    : fallbackResponseContent
                        ? [
                            {
                                id: crypto.randomUUID(),
                                content: fallbackResponseContent,
                            },
                        ]
                        : [];
                if (messagesToEmit.length > 0 &&
                    !generationAbortController.signal.aborted &&
                    typeof runtime.emitEvent === "function") {
                    for (const responseMessage of messagesToEmit) {
                        const memoryLike = createMessageMemory({
                            id: responseMessage.id ??
                                crypto.randomUUID(),
                            roomId: message.roomId,
                            entityId: runtime.agentId,
                            content: markSyntheticChatFailureContent(ensureMessageMemoryContent(responseMessage.content ?? { text: "" })),
                        });
                        memoryLike.metadata = message.metadata;
                        await runtime.emitEvent(EventType.MESSAGE_SENT, {
                            message: memoryLike,
                            source: messageSource,
                            ...((result?.trajectoryTerminalOwner ??
                                trajectoryTerminalOwner) === "run"
                                ? { trajectoryTerminalOwner: "run" }
                                : {}),
                        });
                    }
                }
            }
            catch (err) {
                runtime.logger.warn({
                    err,
                    src: "eliza-api",
                    messageId: message.id,
                    roomId: message.roomId,
                }, "Failed to emit MESSAGE_SENT event");
            }
            // A terminal reply failure must not start new actions after a commit.
            if (result && !terminalFailure && !privacyDenied) {
                const rc = result.responseContent;
                const resultRecord = asRecord(result);
                runtime.logger.info({
                    src: "eliza-api",
                    mode: resultRecord?.mode,
                    actions: rc?.actions,
                    hasText: Boolean(rc?.text),
                }, "[eliza-api] Chat response metadata");
                const rawActionsPayload = rc?.actions ?? resultRecord?.actions;
                const modelText = String(extractCompatTextContent(result.responseContent));
                const parsedFallbackActions = parseFallbackActionBlocks(rawActionsPayload, modelText);
                const actionNameLookup = buildRuntimeActionNameLookup(runtime);
                const successfulActionNames = listSuccessfulActionNames(runtime, typeof message.id === "string" ? message.id : undefined, result.actionResults, actionNameLookup);
                const executableFallbackActions = parsedFallbackActions.filter((action) => {
                    if (!isExecutableFallbackAction(action)) {
                        return false;
                    }
                    const canonicalName = actionNameLookup.get(normalizeActionName(action.name)) ??
                        normalizeActionName(action.name);
                    return !successfulActionNames.has(canonicalName);
                });
                if (executableFallbackActions.length > 0) {
                    const selfControlFallbackActions = executableFallbackActions.filter((action) => {
                        const canonicalName = actionNameLookup.get(normalizeActionName(action.name)) ??
                            normalizeActionName(action.name);
                        return canonicalName === "BLOCK";
                    });
                    let successfulFallbackActions = new Set();
                    if (selfControlFallbackActions.length > 0 &&
                        !generationAbortController.signal.aborted) {
                        const fallbackExecutions = await executeFallbackParsedActions(runtime, message, selfControlFallbackActions, (incoming) => appendIncomingText(incoming, undefined, "action_callback"), recordActionCallback, {
                            abortSignal: generationAbortController.signal,
                            getCurrentText: () => responseText || modelText,
                        });
                        successfulFallbackActions = new Set(fallbackExecutions
                            .filter((execution) => execution.success)
                            .map((execution) => {
                            const normalizedName = normalizeActionName(execution.actionName);
                            return (actionNameLookup.get(normalizedName) ?? normalizedName);
                        })
                            .filter((name) => name.length > 0));
                        for (const actionName of successfulFallbackActions) {
                            fallbackSuccessfulActionNames.add(actionName);
                        }
                    }
                    const remainingExecutableFallbackActions = executableFallbackActions.filter((action) => {
                        const canonicalName = actionNameLookup.get(normalizeActionName(action.name)) ??
                            normalizeActionName(action.name);
                        if (canonicalName === "BLOCK") {
                            return !successfulFallbackActions.has(canonicalName);
                        }
                        return true;
                    });
                    if (remainingExecutableFallbackActions.length > 0) {
                        runtime.logger.error({
                            src: "eliza-api",
                            parsedActions: remainingExecutableFallbackActions.map((a) => a.name),
                        }, "[eliza-api] Unexecuted action payload detected; failing closed");
                        const failureText = buildUnexecutedActionPayloadReply(remainingExecutableFallbackActions.map((action) => action.name));
                        if (opts?.onSnapshot) {
                            emitSnapshot(failureText);
                        }
                        else {
                            responseText = failureText;
                        }
                        blockedUnexecutedActionPayload = true;
                    }
                    if (remainingExecutableFallbackActions.some((action) => normalizeActionName(action.name) === "CHECK_BALANCE")) {
                        forcedWalletExecutionText = true;
                    }
                }
            }
        })));
        capturedUsage = generationCapture.usage;
        closeResponseFinalization = getInferenceTimer()?.openSpan("chat:response-finalization", {
            phase: "post-model",
        });
        const actionNameLookup = buildRuntimeActionNameLookup(runtime);
        const successfulActionNames = listSuccessfulActionNames(runtime, typeof message.id === "string" ? message.id : undefined, result?.actionResults, actionNameLookup);
        for (const actionName of fallbackSuccessfulActionNames) {
            successfulActionNames.add(actionName);
        }
        const responseMessageText = getLatestVisibleResponseMessageText(result?.responseMessages);
        const resultContentCandidates = [
            result?.responseContent,
            ...(result?.responseMessages ?? []).map((entry) => entry.content),
        ];
        const resultText = responseMessageText ||
            extractCompatTextContent(result?.responseContent) ||
            "";
        const resultTextVisibility = resolveFinalTranscriptVisibility(resultText, result?.actionResults, resultContentCandidates);
        // Fallback: if callbacks weren't used for text, stream + return final text.
        if (!terminalFailure &&
            !responseText &&
            resultText &&
            resultTextVisibility !== "internal") {
            if (opts?.onSnapshot) {
                emitSnapshot(resultText);
            }
            else {
                emitChunk(resultText);
            }
        }
        else if (!terminalFailure &&
            visibleCallbackDeliveries === 0 &&
            resultText &&
            resultTextVisibility !== "internal" &&
            resultText !== responseText &&
            resultText.startsWith(responseText)) {
            emitChunk(resultText.slice(responseText.length));
        }
        else if (!terminalFailure &&
            visibleCallbackDeliveries === 0 &&
            resultText &&
            resultTextVisibility !== "internal" &&
            resultText !== responseText &&
            !forcedWalletExecutionText &&
            !blockedUnexecutedActionPayload) {
            if (opts?.onSnapshot) {
                emitSnapshot(resultText);
            }
            else {
                responseText = resultText;
            }
        }
        const noResponseFallback = opts?.resolveNoResponseText?.();
        const normalizedResponseText = terminalFailure
            ? responseText
            : responseText || resultText || "";
        const intentionalNoResponse = isIntentionalNoResponseResult(result, normalizedResponseText);
        const finalText = privacyDenied
            ? PRIVACY_DENIED_TEXT
            : intentionalNoResponse
                ? ""
                : isClientVisibleNoResponse(normalizedResponseText)
                    ? (noResponseFallback ??
                        (normalizedResponseText || responseText || "(no response)"))
                    : normalizedResponseText;
        // A visible action callback and its internal terminal receipt can carry the
        // same canonical text. The receipt stays out of the transcript, but it must
        // not retroactively hide the callback that already owns the turn's response.
        const transcriptVisibility = visibleCallbackDeliveries > 0
            ? undefined
            : resolveFinalTranscriptVisibility(finalText, result?.actionResults, resultContentCandidates);
        if (opts?.onChunk && !opts.onSnapshot && !replyFailure) {
            const authoritativeText = transcriptVisibility === "internal" ? "" : finalText;
            if (!authoritativeText.startsWith(appendOnlyText)) {
                throw new ElizaError("Append-only chat stream diverged from the authoritative final reply", {
                    code: CHAT_APPEND_ONLY_STREAM_DIVERGENCE,
                    severity: "fatal",
                    context: {
                        emittedChars: appendOnlyText.length,
                        finalChars: authoritativeText.length,
                        messageId: message.id,
                        roomId: message.roomId,
                    },
                });
            }
            const remainingText = authoritativeText.slice(appendOnlyText.length);
            if (remainingText) {
                markFirstVisibleReply();
                opts.onChunk(remainingText);
                appendOnlyText += remainingText;
            }
        }
        const responseMessages = Array.isArray(result?.responseMessages)
            ? result.responseMessages
            : [];
        const persistedResponseMessageIds = Array.isArray(result?.persistedResponseMessageIds)
            ? result.persistedResponseMessageIds.filter((id) => typeof id === "string" && id.length > 0)
            : [];
        const terminalFailureKind = terminalFailure?.kind;
        const responseContent = privacyDenied
            ? {
                text: PRIVACY_DENIED_TEXT,
                actions: ["PRIVACY_DENIED"],
                data: { privacyDenied: true },
            }
            : result?.responseContent && typeof result.responseContent === "object"
                ? (() => {
                    const content = {
                        ...result.responseContent,
                        text: finalText,
                        ...(deliveredActionAttachments.length > 0
                            ? {
                                attachments: [
                                    ...(result.responseContent.attachments ?? []),
                                    ...deliveredActionAttachments,
                                ],
                            }
                            : {}),
                        ...(terminalFailureKind
                            ? { failureKind: terminalFailureKind }
                            : {}),
                        ...(replyFailure
                            ? {
                                elizaSyntheticFailure: true,
                                agentVoiced: false,
                                replyFailure: { ...replyFailure },
                            }
                            : {}),
                        ...(terminalFailure
                            ? {
                                terminalFailure: terminalFailureContentValue(terminalFailure),
                            }
                            : {}),
                    };
                    delete content.transcriptVisibility;
                    if (transcriptVisibility) {
                        content.transcriptVisibility = transcriptVisibility;
                    }
                    return content;
                })()
                : finalText
                    ? {
                        text: finalText,
                        ...(deliveredActionAttachments.length > 0
                            ? { attachments: [...deliveredActionAttachments] }
                            : {}),
                        ...(terminalFailureKind
                            ? { failureKind: terminalFailureKind }
                            : {}),
                        ...(replyFailure
                            ? {
                                elizaSyntheticFailure: true,
                                agentVoiced: false,
                                replyFailure: { ...replyFailure },
                            }
                            : {}),
                        ...(terminalFailure
                            ? {
                                terminalFailure: terminalFailureContentValue(terminalFailure),
                            }
                            : {}),
                        ...(transcriptVisibility ? { transcriptVisibility } : {}),
                    }
                    : null;
        const responseRecord = responseContent;
        const accountConnect = normalizeAccountConnectRequest(responseRecord?.accountConnect);
        const localInference = responseRecord?.localInference &&
            typeof responseRecord.localInference === "object"
            ? responseRecord.localInference
            : undefined;
        const responseMetadata = asRecord(responseRecord?.metadata);
        const rawFailureKind = terminalFailureKind
            ? terminalFailureKind
            : typeof responseRecord?.failureKind === "string"
                ? responseRecord.failureKind
                : typeof responseMetadata?.chatFailureKind === "string"
                    ? responseMetadata.chatFailureKind
                    : undefined;
        const failureKind = parseChatFailureKind(rawFailureKind);
        const thought = typeof responseContent?.thought === "string" &&
            responseContent.thought.trim()
            ? responseContent.thought
            : undefined;
        // Denial replaces prose at the assistant boundary, but complete action
        // evidence remains in the runtime. Do not disclose that evidence through
        // the host's secondary client projection (including receipt resource IDs).
        const actionResultSummaries = privacyDenied
            ? []
            : summarizeRuntimeActionResults(runtime, typeof message.id === "string" ? message.id : undefined, result?.actionResults);
        const successfulDeliveredActionCallbacks = deliveredActionCallbacks.filter((entry) => {
            const canonicalName = actionNameLookup.get(entry.actionName) ?? entry.actionName;
            return successfulActionNames.has(canonicalName);
        });
        const actionCallbackHistory = successfulDeliveredActionCallbacks.reduce((history, entry) => {
            if (entry.text && history.at(-1) !== entry.text) {
                history.push(entry.text);
            }
            return history;
        }, []);
        const declaredResultActionNames = new Set((Array.isArray(result?.responseContent?.actions)
            ? result.responseContent.actions
            : [])
            .map((actionName) => {
            const normalizedName = normalizeActionName(actionName);
            return actionNameLookup.get(normalizedName) ?? normalizedName;
        })
            .filter((actionName) => actionName.length > 0));
        const successfulActionMode = result?.mode === "actions" &&
            [...declaredResultActionNames].some((actionName) => successfulActionNames.has(actionName));
        const usedActionCallbacks = successfulDeliveredActionCallbacks.length > 0 || successfulActionMode;
        return {
            text: finalText,
            ...(!privacyDenied && planningAcknowledgment
                ? { planningAcknowledgment }
                : {}),
            agentName,
            ...(!privacyDenied && result?.outcome ? { outcome: result.outcome } : {}),
            ...(transcriptVisibility ? { transcriptVisibility } : {}),
            ...(!privacyDenied && thought ? { thought } : {}),
            ...(intentionalNoResponse
                ? { noResponseReason: "ignored" }
                : {}),
            ...(!privacyDenied && failureKind ? { failureKind } : {}),
            ...(!privacyDenied && terminalFailure ? { terminalFailure } : {}),
            ...(!privacyDenied && accountConnect ? { accountConnect } : {}),
            ...(!privacyDenied && localInference ? { localInference } : {}),
            ...(usedActionCallbacks ? { usedActionCallbacks: true } : {}),
            ...(!privacyDenied && actionCallbackHistory.length > 0
                ? { actionCallbackHistory: [...actionCallbackHistory] }
                : {}),
            ...(actionResultSummaries.length > 0
                ? { actionResults: actionResultSummaries }
                : {}),
            ...(!privacyDenied &&
                replyFailure &&
                result?.replyRecovery &&
                result.actionResults
                ? {
                    replyRecovery: {
                        ...result.replyRecovery,
                        actionResults: result.actionResults,
                    },
                }
                : {}),
            ...(responseContent ? { responseContent } : {}),
            ...(responseMessages.length > 0 ? { responseMessages } : {}),
            ...(persistedResponseMessageIds.length > 0
                ? { persistedResponseMessageIds }
                : {}),
            usage: buildChatUsage(runtime, message, finalText, capturedUsage),
        };
    }
    finally {
        opts?.abortSignal?.removeEventListener("abort", onExternalAbort);
        scheduleMessageTrajectoryGroupingPersistence(runtime, message);
        closeResponseFinalization?.();
    }
}
async function generateOwnedChatResponse(runtime, message, agentName, opts) {
    const timeoutMs = resolveChatGenerationTimeoutMs();
    const existingTimer = getInferenceTimer();
    if (existingTimer) {
        const result = await runWithGenerationTimeout(timeoutMs, () => createChatGenerationTimeoutError(timeoutMs), opts, (timedOpts) => generateChatResponseWithTiming(runtime, message, agentName, timedOpts));
        markInference(INFERENCE_MARKS.responseFinalized);
        return result;
    }
    const timer = opts?.inferenceTimer ??
        new InferenceTurnTimer({
            turnId: nextInferenceTurnId(),
            traceId: opts?.traceId,
            label: "chat-request",
            roomId: message.roomId,
        });
    return runWithInferenceTiming(timer, async () => {
        try {
            const result = await runWithGenerationTimeout(timeoutMs, () => createChatGenerationTimeoutError(timeoutMs), opts, (timedOpts) => generateChatResponseWithTiming(runtime, message, agentName, timedOpts));
            markInference(INFERENCE_MARKS.responseFinalized);
            return result;
        }
        finally {
            const summary = emitInferenceTiming(timer);
            if (summary) {
                void persistInferenceTimingSummary(runtime, message, summary).catch((error) => {
                    // error-policy:J7 latency persistence must not turn a completed
                    // chat response into a failed request.
                    runtime.reportError("ChatRoutes.persistInferenceTimingSummary", error, { messageId: message.id, roomId: message.roomId });
                });
            }
        }
    });
}
export async function generateChatResponse(runtime, message, agentName, opts) {
    const runOwned = async (roomHandlerLease) => {
        return withRoomDeliverySettlement(runtime, message.roomId, roomHandlerLease, async () => {
            const result = await generateOwnedChatResponse(runtime, message, agentName, {
                ...opts,
                roomHandlerLease,
            });
            await opts?.onReplyReady?.(result);
            return result;
        });
    };
    const inheritedLease = runtime.roomHandlerQueue.currentLease(message.roomId);
    const requestedLease = opts?.roomHandlerLease ?? inheritedLease;
    if (requestedLease) {
        if (!runtime.roomHandlerQueue.ownsLease(message.roomId, requestedLease)) {
            throw new ElizaError("Chat generation has no live room ownership", {
                code: "CHAT_ROOM_LEASE_MISMATCH",
                context: { roomId: message.roomId, messageId: message.id },
            });
        }
        if (inheritedLease === requestedLease) {
            return runOwned(requestedLease);
        }
        return runtime.roomHandlerQueue.runInLease(message.roomId, requestedLease, () => runOwned(requestedLease));
    }
    return runtime.roomHandlerQueue.withLease(message.roomId, runOwned, {
        signal: opts?.abortSignal,
    });
}
export async function generateConversationTitle(runtime, userMessage, agentName, options) {
    const modelClass = ModelType.TEXT_SMALL;
    const prompt = `Based on the user's first message in a new chat, generate a very short, concise title (max 4-5 words) for the conversation.
The agent's name is "${agentName}". The title should reflect the topic or intent of the user.
Ideally, the title should fit the persona/vibe of the agent if possible, but clarity is more important.
Do not use quotes. Do not include "Title:" prefix.

User message: "${userMessage}"

Title:`;
    const title = await runtime.useModel(modelClass, {
        prompt,
        temperature: 0.7,
        signal: options?.signal,
    });
    if (!title)
        return null;
    let cleanTitle = title.trim();
    if ((cleanTitle.startsWith('"') && cleanTitle.endsWith('"')) ||
        (cleanTitle.startsWith("'") && cleanTitle.endsWith("'"))) {
        cleanTitle = cleanTitle.slice(1, -1);
    }
    if (!cleanTitle || cleanTitle.length > 50)
        return null;
    return cleanTitle;
}
export function resolveChatAdminEntityId(state) {
    return resolveClientChatAdminEntityId(state);
}
/**
 * Exported for the machine-session role-grant regression suite; runtime callers
 * are the chat POST paths in this module.
 */
export async function ensureCompatChatConnection(state, runtime, 
/** agentIdentityName(runtime.character): stays the same after a rename. */
identityName, channelIdPrefix, roomKey, principal) {
    const ownerPrincipal = principal.kind === "owner_session" || principal.kind === "owner_api_token";
    const userId = ownerPrincipal
        ? ensureAdminEntityIdForChat(state)
        : stringToUuid(`${identityName}:${channelIdPrefix}:external:${principal.principalId}`);
    const principalScopedRoomKey = ownerPrincipal
        ? roomKey
        : `${principal.kind}:${principal.principalId}:${roomKey}`;
    const roomId = stringToUuid(`${identityName}-${channelIdPrefix}-room-${principalScopedRoomKey}`);
    const worldId = stringToUuid(`${identityName}-web-chat-world`);
    const messageServerId = stringToUuid(`${identityName}-web-server`);
    await runtime.ensureConnection({
        entityId: userId,
        roomId,
        worldId,
        userName: resolveAppUserName(state.config),
        source: MESSAGE_SOURCE_CLIENT_CHAT,
        channelId: `${channelIdPrefix}-${principalScopedRoomKey}`,
        type: ChannelType.API,
        messageServerId,
        metadata: ownerPrincipal ? { ownership: { ownerId: userId } } : {},
    });
    if (!ownerPrincipal) {
        if (principal.kind === "service_gateway" && principal.sessionRole) {
            await grantSessionUserWorldRole(runtime, worldId, userId);
        }
        return { userId, roomId, worldId };
    }
    // Ensure world ownership only for a directly authenticated owner principal.
    // Re-applied on a fresh read when the revision moved underneath (the
    // connection bootstrap and deferred boot maintenance write the same world).
    await updateWorldMetadataWithRetry(runtime, worldId, (world) => {
        let needsUpdate = false;
        if (!world.metadata) {
            world.metadata = {};
            needsUpdate = true;
        }
        if (!world.metadata.ownership ||
            typeof world.metadata.ownership !== "object" ||
            world.metadata.ownership.ownerId !== userId) {
            world.metadata.ownership = { ownerId: userId };
            needsUpdate = true;
        }
        // Record the deployed-app owner as an explicit, auditable grant
        // (roles[ownerId]="OWNER" + roleSources[ownerId]="owner") rather than an
        // emergent inference — #9948.
        if (recordOwnerGrant(world.metadata, userId)) {
            needsUpdate = true;
        }
        return needsUpdate;
    });
    return { userId, roomId, worldId };
}
/**
 * Grant-on-first-contact USER world membership for an authenticated
 * machine-session (paired-device) principal's minted external entity, so its
 * turns resolve at least the session's boundary role through
 * `checkSenderRole`/`resolveEntityRole` (which read `world.metadata.roles`).
 *
 * Bounded by construction: the grant is always exactly "USER" with audit
 * source "session", and an existing USER-or-higher grant (e.g. a manual ADMIN
 * grant by the owner) is never overwritten or downgraded.
 *
 * Revocation semantics: the grant itself is durable world metadata, but acting
 * as the granted entity requires re-entering through the HTTP session boundary
 * on every turn — the entity id is derived from the session's auth-identity id,
 * and `resolveTrustedApiPrincipal` only attaches `sessionRole` when the store
 * resolves a live session. A revoked or expired session fails boundary auth
 * (401) or classifies as a plain external principal, which mints a DIFFERENT
 * entity that resolves GUEST; unpairing the device (deleting the identity)
 * removes the only path to the granted entity entirely. New turns therefore
 * never retain elevated attribution after revocation.
 */
async function grantSessionUserWorldRole(runtime, worldId, entityId) {
    const world = await updateWorldMetadataWithRetry(runtime, worldId, (world) => {
        world.metadata ??= {};
        const metadata = world.metadata;
        if (hasAtLeastRole(getEntityRole(metadata, entityId), "USER")) {
            return false;
        }
        return recordRoleGrant(metadata, entityId, "USER", "session");
    });
    if (!world) {
        // ensureConnection creates the world before this runs; a missing world
        // fails closed (the entity stays GUEST) rather than failing the turn.
        runtime.logger.warn({ src: "eliza-api", worldId, entityId }, "[eliza-api] machine-session USER grant skipped: web-chat world missing");
    }
}
function ensureAdminEntityIdForChat(state) {
    return resolveChatAdminEntityId(state);
}
export function resolveTrustedApiPrincipal(req, authorization) {
    if (isServerTokenAuthorized(req)) {
        return {
            kind: "service_gateway",
            principalId: authorization?.principal ?? "shared-server-gateway",
        };
    }
    if (authorization?.ok && authorization.role === "OWNER") {
        return {
            kind: "owner_session",
            principalId: authorization.identityId ??
                authorization.principal ??
                "authenticated-owner-session",
        };
    }
    if (authorization?.ok) {
        const principalId = authorization.identityId ??
            authorization.principal ??
            "authenticated-external-session";
        // A DB-backed machine session (device pairing) authenticates with boundary
        // role USER (roleForIdentityKind: "machine" -> USER). Carry that boundary
        // role on the still-external principal so chat ingress can grant the minted
        // entity USER world membership — clamped to the literal "USER" tier, so
        // this seam can never mint ADMIN/OWNER attribution. Restricted to callers
        // with an `identityId` (a revocable, store-backed session identity):
        // principal-only token authorities and sub-USER boundary roles stay plain
        // external principals.
        if (authorization.identityId &&
            hasAtLeastRole(authorization.role, "USER")) {
            return {
                kind: "service_gateway",
                principalId,
                sessionRole: "USER",
                sessionIdentityId: authorization.identityId,
            };
        }
        return {
            kind: "service_gateway",
            principalId,
        };
    }
    if (isAuthorized(req)) {
        return {
            kind: "owner_api_token",
            principalId: "direct-owner-api",
        };
    }
    return {
        kind: "service_gateway",
        principalId: "non-owner-api",
    };
}
/** @internal Ordinary chat synchronization carries no implicit rename intent. */
export function syncRuntimeCharacterToChatStateConfig(state) {
    if (!state.runtime || !state.config) {
        return;
    }
    syncCharacterIntoConfig(state.config, state.runtime.character, { nameWasExplicitlyEdited: false });
}
// ---------------------------------------------------------------------------
// Main route handler
// ---------------------------------------------------------------------------
export async function handleChatRoutes(ctx) {
    const { req, res, method, pathname, readJsonBody, json, state } = ctx;
    const trustedApiPrincipal = resolveTrustedApiPrincipal(req, ctx.callerAuthorization);
    // ── GET /v1/models (OpenAI compatible) ─────────────────────────────────
    if (method === "GET" && pathname === "/v1/models") {
        const created = Math.floor(Date.now() / 1000);
        const ids = new Set();
        ids.add("eliza");
        if (state.agentName.trim())
            ids.add(state.agentName.trim());
        if (state.runtime?.character.name?.trim())
            ids.add(state.runtime.character.name.trim());
        json(res, {
            object: "list",
            data: Array.from(ids).map((id) => ({
                id,
                object: "model",
                created,
                owned_by: "eliza",
            })),
        });
        return true;
    }
    // ── GET /v1/models/:id (OpenAI compatible) ─────────────────────────────
    if (method === "GET" && /^\/v1\/models\/[^/]+$/.test(pathname)) {
        const created = Math.floor(Date.now() / 1000);
        const raw = pathname.split("/")[3] ?? "";
        const decoded = decodePathComponent(raw, res, "model id");
        if (!decoded)
            return true;
        const id = decoded.trim();
        if (!id) {
            json(res, {
                error: {
                    message: "Model id is required",
                    type: "invalid_request_error",
                },
            }, 400);
            return true;
        }
        json(res, { id, object: "model", created, owned_by: "eliza" });
        return true;
    }
    // ── POST /v1/chat/completions (OpenAI compatible) ──────────────────────
    if (method === "POST" && pathname === "/v1/chat/completions") {
        const body = await readJsonBody(req, res);
        if (!body)
            return true;
        if (hasBlockedObjectKeyDeep(body)) {
            json(res, {
                error: {
                    message: "Request body contains a blocked object key",
                    type: "invalid_request_error",
                },
            }, 400);
            return true;
        }
        const safeBody = cloneWithoutBlockedObjectKeys(body);
        const extracted = extractOpenAiSystemAndLastUser(safeBody.messages);
        if (!extracted) {
            json(res, {
                error: {
                    message: "messages must be an array containing at least one user message",
                    type: "invalid_request_error",
                },
            }, 400);
            return true;
        }
        const roomKey = scopeCompatRoomKey(resolveCompatRoomKey(safeBody));
        const wantsStream = safeBody.stream === true ||
            (req.headers.accept ?? "").includes("text/event-stream");
        const requestedModel = typeof safeBody.model === "string" && safeBody.model.trim()
            ? safeBody.model.trim()
            : null;
        const prompt = extracted.system
            ? `${extracted.system}\n\n${extracted.user}`.trim()
            : extracted.user;
        const created = Math.floor(Date.now() / 1000);
        const id = `chatcmpl-${crypto.randomUUID()}`;
        const model = requestedModel ?? state.agentName;
        if (wantsStream) {
            initSse(res);
            const disconnectTracker = createStreamingResponseAbortTracker(req, res, "OpenAI-compatible stream");
            const sendChunk = (delta, finishReason) => {
                writeSseData(res, JSON.stringify({
                    id,
                    object: "chat.completion.chunk",
                    created,
                    model,
                    choices: [
                        {
                            index: 0,
                            delta,
                            finish_reason: finishReason,
                        },
                    ],
                }));
            };
            try {
                if (!state.runtime) {
                    writeSseData(res, JSON.stringify({
                        error: {
                            message: "Agent is not running",
                            type: "service_unavailable",
                        },
                    }));
                    writeSseData(res, "[DONE]");
                    return true;
                }
                sendChunk({ role: "assistant" }, null);
                let fullText = "";
                let transcriptVisibility;
                {
                    const runtime = state.runtime;
                    if (!runtime)
                        throw new Error("Agent is not running");
                    const agentName = agentIdentityName(runtime.character) ?? "Eliza";
                    const { userId, roomId } = await ensureCompatChatConnection(state, runtime, agentName, "openai-compat", roomKey, trustedApiPrincipal);
                    const message = createMessageMemory({
                        id: crypto.randomUUID(),
                        entityId: userId,
                        agentId: runtime.agentId,
                        roomId,
                        content: {
                            text: prompt,
                            source: "compat_openai",
                            channelType: ChannelType.API,
                        },
                    });
                    await attestAuthenticatedApiDeliveryAudience(runtime, message, trustedApiPrincipal);
                    const turnStartedAt = Date.now();
                    const result = await generateChatResponse(runtime, message, state.agentName, {
                        abortSignal: disconnectTracker.signal,
                        onChunk: (chunk) => {
                            fullText += chunk;
                            if (chunk)
                                sendChunk({ content: chunk }, null);
                        },
                        resolveNoResponseText: () => resolveNoResponseFallback(state.logBuffer, runtime),
                    });
                    await persistUnpersistedChatReply(runtime, message, result, turnStartedAt);
                    transcriptVisibility = result.transcriptVisibility;
                    if (result.localInference && !fullText) {
                        fullText =
                            result.transcriptVisibility === "internal" ? "" : result.text;
                        if (fullText) {
                            sendChunk({ content: fullText }, null);
                        }
                    }
                    syncRuntimeCharacterToChatStateConfig(state);
                }
                const resolved = normalizeChatResponseText(fullText, state.logBuffer, state.runtime);
                if ((fullText.trim().length === 0 || isNoResponsePlaceholder(fullText)) &&
                    resolved.trim() &&
                    transcriptVisibility !== "internal") {
                    sendChunk({ content: resolved }, null);
                }
                sendChunk({}, "stop");
                writeSseData(res, "[DONE]");
            }
            catch (err) {
                if (!disconnectTracker.signal.aborted) {
                    if (isLocalInferenceError(err)) {
                        const { getLocalInferenceChatStatus } = await getLocalInferenceChatApi();
                        const localFailure = await getLocalInferenceChatStatus("status", err);
                        writeSseData(res, JSON.stringify({
                            error: {
                                message: localFailure.text,
                                type: "local_inference",
                                localInference: localFailure.localInference,
                            },
                        }));
                    }
                    else if (isNoProviderError(err)) {
                        writeSseData(res, JSON.stringify({
                            error: {
                                message: NO_PROVIDER_CHAT_MESSAGE,
                                type: "no_provider",
                                code: "NO_PROVIDER_REGISTERED",
                            },
                        }));
                    }
                    else {
                        writeSseData(res, JSON.stringify({
                            error: {
                                message: getErrorMessage(err),
                                type: isAppendOnlyStreamDivergenceError(err)
                                    ? "stream_error"
                                    : "server_error",
                                ...(isAppendOnlyStreamDivergenceError(err)
                                    ? { code: err.code }
                                    : {}),
                            },
                        }));
                    }
                    if (!isAppendOnlyStreamDivergenceError(err)) {
                        writeSseData(res, "[DONE]");
                    }
                }
            }
            finally {
                disconnectTracker.markCompleted();
                disconnectTracker.dispose();
                res.end();
            }
            return true;
        }
        // Non-streaming
        try {
            let responseText;
            let localInference;
            let failureKind;
            let transcriptVisibility;
            {
                if (!state.runtime) {
                    json(res, {
                        error: {
                            message: "Agent is not running",
                            type: "service_unavailable",
                        },
                    }, 503);
                    return true;
                }
                const runtime = state.runtime;
                const agentName = agentIdentityName(runtime.character) ?? "Eliza";
                const { userId, roomId } = await ensureCompatChatConnection(state, runtime, agentName, "openai-compat", roomKey, trustedApiPrincipal);
                const message = createMessageMemory({
                    id: crypto.randomUUID(),
                    entityId: userId,
                    agentId: runtime.agentId,
                    roomId,
                    content: {
                        text: prompt,
                        source: "compat_openai",
                        channelType: ChannelType.API,
                    },
                });
                await attestAuthenticatedApiDeliveryAudience(runtime, message, trustedApiPrincipal);
                const turnStartedAt = Date.now();
                const result = await generateChatResponse(runtime, message, state.agentName, {
                    resolveNoResponseText: () => resolveNoResponseFallback(state.logBuffer, runtime),
                });
                await persistUnpersistedChatReply(runtime, message, result, turnStartedAt);
                syncRuntimeCharacterToChatStateConfig(state);
                transcriptVisibility = result.transcriptVisibility;
                responseText =
                    result.transcriptVisibility === "internal" ? "" : result.text;
                localInference = result.localInference;
                failureKind = result.failureKind;
            }
            if (failureKind === "no_provider") {
                json(res, {
                    error: {
                        message: NO_PROVIDER_CHAT_MESSAGE,
                        type: "no_provider",
                        code: "NO_PROVIDER_REGISTERED",
                    },
                }, 503);
                return true;
            }
            const resolvedText = transcriptVisibility === "internal"
                ? ""
                : normalizeChatResponseText(responseText, state.logBuffer, state.runtime);
            json(res, {
                id,
                object: "chat.completion",
                created,
                model,
                choices: [
                    {
                        index: 0,
                        message: { role: "assistant", content: resolvedText },
                        finish_reason: "stop",
                    },
                ],
                ...(failureKind ? { failureKind } : {}),
                ...(localInference ? { localInference } : {}),
            });
        }
        catch (err) {
            if (isLocalInferenceError(err)) {
                const { getLocalInferenceChatStatus } = await getLocalInferenceChatApi();
                const localFailure = await getLocalInferenceChatStatus("status", err);
                json(res, {
                    error: {
                        message: localFailure.text,
                        type: "local_inference",
                        localInference: localFailure.localInference,
                    },
                }, 503);
            }
            else if (isNoProviderError(err)) {
                json(res, {
                    error: {
                        message: NO_PROVIDER_CHAT_MESSAGE,
                        type: "no_provider",
                        code: "NO_PROVIDER_REGISTERED",
                    },
                }, 503);
            }
            else {
                json(res, { error: { message: getErrorMessage(err), type: "server_error" } }, 500);
            }
        }
        return true;
    }
    // ── POST /v1/messages (Anthropic compatible) ───────────────────────────
    if (method === "POST" && pathname === "/v1/messages") {
        const body = await readJsonBody(req, res);
        if (!body)
            return true;
        if (hasBlockedObjectKeyDeep(body)) {
            json(res, {
                error: {
                    type: "invalid_request_error",
                    message: "Request body contains a blocked object key",
                },
            }, 400);
            return true;
        }
        const safeBody = cloneWithoutBlockedObjectKeys(body);
        const extracted = extractAnthropicSystemAndLastUser({
            system: safeBody.system,
            messages: safeBody.messages,
        });
        if (!extracted) {
            json(res, {
                error: {
                    type: "invalid_request_error",
                    message: "messages must be an array containing at least one user message",
                },
            }, 400);
            return true;
        }
        const roomKey = scopeCompatRoomKey(resolveCompatRoomKey(safeBody));
        const wantsStream = safeBody.stream === true ||
            (req.headers.accept ?? "").includes("text/event-stream");
        const requestedModel = typeof safeBody.model === "string" && safeBody.model.trim()
            ? safeBody.model.trim()
            : null;
        const prompt = extracted.system
            ? `${extracted.system}\n\n${extracted.user}`.trim()
            : extracted.user;
        const id = `msg_${crypto.randomUUID().replace(/-/g, "")}`;
        const model = requestedModel ?? state.agentName;
        if (wantsStream) {
            initSse(res);
            const disconnectTracker = createStreamingResponseAbortTracker(req, res, "Anthropic-compatible stream");
            try {
                if (!state.runtime) {
                    writeSseJson(res, {
                        type: "error",
                        error: {
                            type: "service_unavailable",
                            message: "Agent is not running",
                        },
                    }, "error");
                    return true;
                }
                // Anthropic's wire format reports input_tokens on message_start (the
                // prompt is fully known here) and accumulates output_tokens on the
                // closing message_delta. We don't have a real model-side prompt count
                // before generation, so input_tokens is the same heuristic estimate the
                // rest of this file uses (estimateTokenCount); output_tokens is filled
                // from the real generation result below.
                const inputTokens = estimateTokenCount(prompt);
                writeSseJson(res, {
                    type: "message_start",
                    message: {
                        id,
                        type: "message",
                        role: "assistant",
                        model,
                        content: [],
                        stop_reason: null,
                        stop_sequence: null,
                        usage: { input_tokens: inputTokens, output_tokens: 0 },
                    },
                }, "message_start");
                writeSseJson(res, {
                    type: "content_block_start",
                    index: 0,
                    content_block: { type: "text", text: "" },
                }, "content_block_start");
                let fullText = "";
                let outputTokens = 0;
                let transcriptVisibility;
                const onDelta = (chunk) => {
                    if (!chunk)
                        return;
                    fullText += chunk;
                    writeSseJson(res, {
                        type: "content_block_delta",
                        index: 0,
                        delta: { type: "text_delta", text: chunk },
                    }, "content_block_delta");
                };
                {
                    const runtime = state.runtime;
                    if (!runtime)
                        throw new Error("Agent is not running");
                    const agentName = agentIdentityName(runtime.character) ?? "Eliza";
                    const { userId, roomId } = await ensureCompatChatConnection(state, runtime, agentName, "anthropic-compat", roomKey, trustedApiPrincipal);
                    const message = createMessageMemory({
                        id: crypto.randomUUID(),
                        entityId: userId,
                        agentId: runtime.agentId,
                        roomId,
                        content: {
                            text: prompt,
                            source: "compat_anthropic",
                            channelType: ChannelType.API,
                        },
                    });
                    await attestAuthenticatedApiDeliveryAudience(runtime, message, trustedApiPrincipal);
                    const turnStartedAt = Date.now();
                    const generation = await generateChatResponse(runtime, message, state.agentName, {
                        abortSignal: disconnectTracker.signal,
                        onChunk: onDelta,
                        resolveNoResponseText: () => resolveNoResponseFallback(state.logBuffer, runtime),
                    });
                    await persistUnpersistedChatReply(runtime, message, generation, turnStartedAt);
                    transcriptVisibility = generation.transcriptVisibility;
                    outputTokens = generation.usage?.completionTokens ?? outputTokens;
                    syncRuntimeCharacterToChatStateConfig(state);
                }
                const resolved = normalizeChatResponseText(fullText, state.logBuffer, state.runtime);
                if ((fullText.trim().length === 0 || isNoResponsePlaceholder(fullText)) &&
                    resolved.trim() &&
                    transcriptVisibility !== "internal") {
                    onDelta(resolved);
                }
                writeSseJson(res, { type: "content_block_stop", index: 0 }, "content_block_stop");
                writeSseJson(res, {
                    type: "message_delta",
                    delta: { stop_reason: "end_turn", stop_sequence: null },
                    usage: {
                        output_tokens: outputTokens > 0 ? outputTokens : estimateTokenCount(fullText),
                    },
                }, "message_delta");
                writeSseJson(res, { type: "message_stop" }, "message_stop");
            }
            catch (err) {
                if (!disconnectTracker.signal.aborted) {
                    if (isNoProviderError(err)) {
                        writeSseJson(res, {
                            type: "error",
                            error: {
                                type: "no_provider",
                                code: "NO_PROVIDER_REGISTERED",
                                message: NO_PROVIDER_CHAT_MESSAGE,
                            },
                        }, "error");
                    }
                    else {
                        writeSseJson(res, {
                            type: "error",
                            error: {
                                type: isAppendOnlyStreamDivergenceError(err)
                                    ? "stream_error"
                                    : "server_error",
                                message: getErrorMessage(err),
                                ...(isAppendOnlyStreamDivergenceError(err)
                                    ? { code: err.code }
                                    : {}),
                            },
                        }, "error");
                    }
                }
            }
            finally {
                disconnectTracker.markCompleted();
                disconnectTracker.dispose();
                res.end();
            }
            return true;
        }
        // Non-streaming
        try {
            let responseText;
            let inputTokens = estimateTokenCount(prompt);
            let outputTokens = 0;
            let transcriptVisibility;
            {
                if (!state.runtime) {
                    json(res, {
                        error: {
                            type: "service_unavailable",
                            message: "Agent is not running",
                        },
                    }, 503);
                    return true;
                }
                const runtime = state.runtime;
                const agentName = agentIdentityName(runtime.character) ?? "Eliza";
                const { userId, roomId } = await ensureCompatChatConnection(state, runtime, agentName, "anthropic-compat", roomKey, trustedApiPrincipal);
                const message = createMessageMemory({
                    id: crypto.randomUUID(),
                    entityId: userId,
                    agentId: runtime.agentId,
                    roomId,
                    content: {
                        text: prompt,
                        source: "compat_anthropic",
                        channelType: ChannelType.API,
                    },
                });
                await attestAuthenticatedApiDeliveryAudience(runtime, message, trustedApiPrincipal);
                const turnStartedAt = Date.now();
                const result = await generateChatResponse(runtime, message, state.agentName, {
                    resolveNoResponseText: () => resolveNoResponseFallback(state.logBuffer, runtime),
                });
                await persistUnpersistedChatReply(runtime, message, result, turnStartedAt);
                syncRuntimeCharacterToChatStateConfig(state);
                transcriptVisibility = result.transcriptVisibility;
                responseText =
                    result.transcriptVisibility === "internal" ? "" : result.text;
                if (result.usage) {
                    inputTokens = result.usage.promptTokens;
                    outputTokens = result.usage.completionTokens;
                }
            }
            const resolvedText = transcriptVisibility === "internal"
                ? ""
                : normalizeChatResponseText(responseText, state.logBuffer, state.runtime);
            json(res, {
                id,
                type: "message",
                role: "assistant",
                model,
                content: [{ type: "text", text: resolvedText }],
                stop_reason: "end_turn",
                stop_sequence: null,
                usage: {
                    input_tokens: inputTokens,
                    output_tokens: outputTokens > 0 ? outputTokens : estimateTokenCount(resolvedText),
                },
            });
        }
        catch (err) {
            if (isNoProviderError(err)) {
                json(res, {
                    error: {
                        type: "no_provider",
                        code: "NO_PROVIDER_REGISTERED",
                        message: NO_PROVIDER_CHAT_MESSAGE,
                    },
                }, 503);
            }
            else {
                json(res, { error: { type: "server_error", message: getErrorMessage(err) } }, 500);
            }
        }
        return true;
    }
    // ── POST /api/agents/:id/message ───────────────────────────────────────
    // Local-mode mirror of the cloud agent-server's per-agent message
    // endpoint (`packages/cloud/services/agent-server/src/routes.ts`). Shares the
    // same `generateChatResponse` path as `/v1/chat/completions` so model
    // routing (incl. local-inference TEXT_LARGE handlers) is identical.
    if (method === "POST" && /^\/api\/agents\/[^/]+\/message$/.test(pathname)) {
        const rawId = pathname.split("/")[3] ?? "";
        const decoded = decodePathComponent(rawId, res, "agent id");
        if (!decoded)
            return true;
        const agentIdParam = decoded.trim();
        if (!agentIdParam) {
            json(res, { error: "agent id is required" }, 400);
            return true;
        }
        if (!state.runtime) {
            json(res, { error: "Agent is not running" }, 503);
            return true;
        }
        // Surface a 404 only when the caller targeted an agent that this
        // process doesn't actually run — distinct from "route missing", which
        // is what the original issue (#7680) was reporting.
        if (state.runtime.agentId !== agentIdParam) {
            json(res, { error: "Agent not found" }, 404);
            return true;
        }
        const body = await readJsonBody(req, res);
        if (!body)
            return true;
        if (hasBlockedObjectKeyDeep(body)) {
            json(res, { error: "Request body contains a blocked object key" }, 400);
            return true;
        }
        const safeBody = cloneWithoutBlockedObjectKeys(body);
        const userId = typeof safeBody.userId === "string" && safeBody.userId.trim().length > 0
            ? safeBody.userId.trim()
            : null;
        const text = typeof safeBody.text === "string" && safeBody.text.trim().length > 0
            ? safeBody.text
            : null;
        if (!userId || !text) {
            json(res, { error: "userId and text are required" }, 400);
            return true;
        }
        try {
            const runtime = state.runtime;
            const agentName = agentIdentityName(runtime.character) ?? "Eliza";
            const messagePrincipal = trustedApiPrincipal.kind === "service_gateway"
                ? {
                    // Keep sessionRole/sessionIdentityId: the per-user surrogate is
                    // still a turn of the same authenticated session, and its minted
                    // entity stays scoped under the session's principal id.
                    ...trustedApiPrincipal,
                    principalId: `${trustedApiPrincipal.principalId}:${userId}`,
                }
                : trustedApiPrincipal;
            // Per-user room key — matches cloud `handleMessage`'s
            // `stringToUuid(\`${agentId}:${userId}\`)` shape closely enough that
            // both surfaces produce stable, user-scoped conversation rooms.
            const { roomId, userId: connUserId } = await ensureCompatChatConnection(state, runtime, agentName, "agent-message", scopeCompatRoomKey(`${agentIdParam}:${userId}`), messagePrincipal);
            const message = createMessageMemory({
                id: crypto.randomUUID(),
                entityId: connUserId,
                agentId: runtime.agentId,
                roomId,
                content: {
                    text,
                    source: "agent_message_api",
                    channelType: ChannelType.API,
                },
            });
            await attestAuthenticatedApiDeliveryAudience(runtime, message, messagePrincipal);
            // Answer the HTTP caller the moment the reply is settled. The room's
            // post-delivery tasks (facts extraction, topic stamping, ~3 s) still
            // drain inside generateChatResponse before the next same-room turn, but
            // they are side effects and must not hold the response (live
            // 2026-09-06: API callers waited 9.6-13.9 s for replies that were ready
            // at 4.8-8.6 s; Discord users got the same replies at the callback).
            let responded = false;
            const respond = (result) => {
                if (responded || res.headersSent)
                    return;
                responded = true;
                syncRuntimeCharacterToChatStateConfig(state);
                const resolvedText = result.transcriptVisibility === "internal"
                    ? ""
                    : normalizeChatResponseText(result.text, state.logBuffer, state.runtime);
                json(res, {
                    response: renderChatSurfaceText(resolvedText),
                    agentName: result.agentName,
                    ...(result.failureKind ? { failureKind: result.failureKind } : {}),
                    ...(result.localInference
                        ? { localInference: result.localInference }
                        : {}),
                });
            };
            const turnStartedAt = Date.now();
            const result = await generateChatResponse(runtime, message, state.agentName, {
                resolveNoResponseText: () => resolveNoResponseFallback(state.logBuffer, runtime),
                onReplyReady: async (ready) => {
                    respond(ready);
                },
            });
            await persistUnpersistedChatReply(runtime, message, result, turnStartedAt);
            respond(result);
        }
        catch (err) {
            if (res.headersSent) {
                // error-policy:J7 The reply already reached the caller; a failure in
                // the room's post-delivery drain is diagnostics for the log.
                state.runtime?.logger.warn({
                    src: "eliza-api",
                    route: "POST /api/agents/:id/message",
                    err: getErrorMessage(err),
                }, "[eliza-api] post-delivery drain failed after the reply was sent");
                return true;
            }
            if (isLocalInferenceError(err)) {
                const { getLocalInferenceChatStatus } = await getLocalInferenceChatApi();
                const localFailure = await getLocalInferenceChatStatus("status", err);
                json(res, {
                    error: localFailure.text,
                    type: "local_inference",
                    localInference: localFailure.localInference,
                }, 503);
            }
            else if (isNoProviderError(err)) {
                json(res, {
                    error: NO_PROVIDER_CHAT_MESSAGE,
                    type: "no_provider",
                    code: "NO_PROVIDER_REGISTERED",
                }, 503);
            }
            else {
                // error-policy:J1 Boundary translation; the cause must be visible in
                // the server log, not only in the 500 body (live 2026-09-06: repeated
                // stale-revision 500s with no trace of the throwing writer).
                state.runtime?.logger.warn({
                    src: "eliza-api",
                    route: "POST /api/agents/:id/message",
                    err: getErrorMessage(err),
                    code: err instanceof ElizaError ? err.code : undefined,
                    context: err instanceof ElizaError ? err.context : undefined,
                    // One line: the console transport keeps only the first line of a
                    // multi-line value, which hid every frame.
                    frames: err instanceof Error && err.stack
                        ? err.stack
                            .split("\n")
                            .slice(1, 12)
                            .map((frame) => frame.trim())
                            .join(" <- ")
                        : undefined,
                }, "[eliza-api] compat message route failed");
                json(res, { error: getErrorMessage(err) }, 500);
            }
        }
        return true;
    }
    return false;
}
