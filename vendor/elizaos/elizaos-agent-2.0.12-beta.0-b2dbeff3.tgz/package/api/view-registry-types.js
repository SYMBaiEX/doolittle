/**
 * Shared types for the view registry.
 *
 * Extracted from views-registry.ts to break the views-registry ↔
 * views-search-index circular dependency.
 *
 * @module api/view-registry-types
 */
export {};
