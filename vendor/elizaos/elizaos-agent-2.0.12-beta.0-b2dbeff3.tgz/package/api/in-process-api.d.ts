import type { RouteHandlerResult } from "@elizaos/host/protocol";
import { type DispatchRouteArgs } from "./dispatch-route.js";
import type { RouteKernel } from "./route-kernel.js";
/** Register one existing kernel without allowing another host to replace its identity. */
export declare function registerInProcessApi(runtime: object, kernel: RouteKernel, hostKey?: object): () => void;
/** Use the full server routing and authentication boundary without a TCP listener. */
export declare function dispatchApiRoute(args: DispatchRouteArgs): Promise<RouteHandlerResult>;
