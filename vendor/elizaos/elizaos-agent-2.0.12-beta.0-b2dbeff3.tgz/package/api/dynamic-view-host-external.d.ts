/**
 * Host-external view-bundle factory transform — single source of truth.
 *
 * A plugin view bundle is built with `@elizaos/ui`, `react`, three, … left as
 * *external* bare imports. Those specifiers must resolve to the host shell's own
 * singletons (one React instance, the live app client, plugins registered
 * at runtime), not to a second copy the browser fetches on its own. A separately
 * imported ES module cannot reach the shell's live modules by itself, so at
 * serve time the bundle is wrapped into a **factory**: its bare host-external
 * imports become bindings resolved from an injected `hostImport(specifier)`
 * function, and its trailing `export { … }` list becomes the factory's return
 * namespace. The shell's `DynamicViewLoader` imports the wrapped module, calls
 * the default-exported factory with a `hostImport` closure backed by its
 * host-external importer map, and gets the view namespace back — sharing the
 * host realm without any `globalThis` bridge or import-map indirection.
 *
 * Both the agent bundle route (`views-routes.ts`) and the Playwright UI-smoke
 * stub (`playwright-ui-smoke-api-stub.ts`) apply the identical transform, so it
 * lives here once. Plain ESM (no deps, no build step) so the node-run smoke stub
 * can import it directly by path while the agent bundles it normally. The typed
 * factory/importer contract lives in `@elizaos/core` (`src/views/
 * host-external-contract.ts`); this module is its runtime implementation.
 *
 * The transform relies on the fixed shape the view-bundle build emits (single
 * self-contained ES module, host externals as bare top-level imports, every
 * export collected into one trailing `export { … }` list — see
 * `view-bundle-vite.config.ts` and `view-bundle-single-chunk.test.ts`).
 */
/** Factory parameter name the wrapped bundle resolves host externals through. */
export declare const HOST_IMPORT_PARAM = "__elizaHostImport";
/** @param {string} namedImports @returns {string} */
export declare function convertNamedImportsToDestructuring(namedImports: string): string;
/**
 * Build the binding statements that replace one host-external `import` clause,
 * resolving the module through the injected `hostImport` factory parameter.
 *
 * @param {string} importClause
 * @param {string} specifier
 * @param {number} index
 * @returns {string}
 */
export declare function buildHostExternalImportReplacement(importClause: string, specifier: string, index: number): string;
/**
 * Wrap a served view bundle as a host-external factory module: bind its
 * host-external imports to an injected `hostImport` parameter and return its
 * exports as a namespace. The module's sole export is a default async factory
 * matching the `HostExternalBundleFactory` contract in `@elizaos/core`.
 *
 * @param {string} source
 * @param {readonly string[]} specifiers
 * @returns {string}
 */
export declare function wrapBundleAsHostExternalFactory(source: string, specifiers: readonly string[]): string;
/**
 * Read the host-external specifier list off a served-bundle request URL. The
 * loader sends it (`hostExternalSpecifiers`) alongside `hostExternalRuntime=1`.
 *
 * @param {URL} url
 * @returns {string[]}
 */
export declare function parseHostExternalSpecifiers(url: URL): string[];
