import "./artifact-share-role-resolver.js";
import "./waifu-chat-role-resolver.js";
import http from "node:http";
import { type AgentRuntime, type AgentStartupDiagnostics } from "@elizaos/core";
import { type ElizaConfig } from "@elizaos/host/protocol";
import type { RuntimeOperationManager } from "../runtime/operations/types.js";
import { type ApiStatusComposer } from "./health-routes.js";
import type { ServerState } from "./server-types.js";
export interface RuntimeRestartOptions {
    /**
     * The host must fully dispose the active runtime before opening the replacement.
     * Restore may already have closed its adapter, or the replacement may require
     * exclusive access to the same committed physical store.
     */
    disposeCurrentBeforeBuild?: boolean;
}
export type ApiRequestMiddleware = (req: http.IncomingMessage, res: http.ServerResponse, next: () => Promise<void>) => Promise<void>;
export type ApiServerConfigurator = (server: http.Server) => void | Promise<void>;
/** Mandatory host policy precedes built-in authentication; true grants no identity. */
export type ApiHostAdmission = (request: http.IncomingMessage, boundary: "request" | "upgrade" | "websocket-send" | "websocket-message") => boolean | Promise<boolean>;
export type WebSocketAuthorizer = (request: http.IncomingMessage, url: URL) => boolean | Promise<boolean>;
export declare function startApiServer(opts?: {
    /** Compose product status fields before serialization; does not intercept transport. */
    composeStatus?: ApiStatusComposer;
    port?: number;
    runtime?: AgentRuntime;
    /**
     * Trusted host configuration copied at construction instead of reading disk.
     * Disables reloadConfigFromDisk; hosts must separately restrict mutable
     * configuration and management routes through hostAdmission.
     */
    hostConfig?: ElizaConfig;
    skipDeferredStartupWork?: boolean;
    /**
     * Skip binding a TCP listener. The HTTP `server` object, all routes, and the
     * in-process `dispatchRoute` kernel are still fully wired up — only
     * `server.listen(...)` is not called, so the process opens no port. Used by
     * local-agent IPC transports (stdio bridge / Capacitor / Electrobun RPC) that
     * reach the route kernel without an HTTP socket. Unset/false → identical to
     * the current listening behavior.
     */
    skipListen?: boolean;
    /** Initial state when starting without a runtime (e.g. embedded startup flow). */
    initialAgentState?: "not_started" | "starting" | "stopped" | "error";
    /**
     * Called when the UI requests a restart via `POST /api/agent/restart`.
     * Should stop the current runtime, create a new one, and return it.
     * If omitted the endpoint returns 501 (not supported in this mode).
     */
    onRestart?: (options?: RuntimeRestartOptions) => Promise<AgentRuntime | null>;
    /** Fully disposes a live runtime before the lifecycle route reports stopped. */
    onStop?: (runtime: AgentRuntime) => Promise<void>;
    /** Host-owned session storage while services are stopped. Never used for runtime work. */
    getAuthenticationRuntime?: () => AgentRuntime | null;
    /** A replacement shares the exact physical store and cannot overlap its predecessor. */
    restartRequiresRuntimeDisposal?: boolean;
    /** Runs after the server atomically publishes the replacement runtime. */
    onRuntimeActivated?: (previousRuntime: AgentRuntime | null, activeRuntime: AgentRuntime) => void | Promise<void>;
    /**
     * Runs at the HTTP boundary before the built-in route dispatcher. Hosts use
     * this to add product-specific routes without mutating Node's global HTTP
     * factory or duplicating the agent server.
     */
    requestMiddleware?: ApiRequestMiddleware;
    /**
     * Configures the concrete HTTP server before it starts listening. This is
     * intended for protocol extensions such as WebSocket upgrade handlers.
     */
    configureServer?: ApiServerConfigurator;
    /** Handle a host-owned protocol after mandatory host admission. Return true
     * only after taking ownership of the socket; the host owns protocol auth. */
    handleProtocolUpgrade?: (request: http.IncomingMessage, socket: import("node:stream").Duplex, head: Buffer) => boolean | Promise<boolean>;
    /**
     * Lets a host recognize credentials it owns before the dashboard WebSocket
     * is admitted. The agent server still owns origin/path checks, pending-socket
     * limits, and its static-token fallback; this hook only adds an authenticated
     * principal such as app's revocable machine session.
     */
    authorizeWebSocket?: WebSocketAuthorizer;
    /**
     * Required admission for HTTP, in-process requests, upgrades and each built-in
     * WebSocket application send/message. Queued sends recheck before delivery.
     * Denial cannot fall back to local trust, static tokens or host sessions.
     * Supplying it disables the separately attached mobile device bridge. Trusted
     * configureServer callbacks must not attach independent request/upgrade handlers.
     */
    hostAdmission?: ApiHostAdmission;
}): Promise<{
    port: number;
    close: () => Promise<void>;
    updateRuntime: (rt: AgentRuntime) => void;
    /** The existing serialized lifecycle authority for authenticated host routes. */
    runtimeOperations: Pick<RuntimeOperationManager, "start" | "get">;
    /** Refresh host config after an in-process durable transaction rollback. */
    reloadConfigFromDisk: () => void;
    updateStartup: (update: Partial<AgentStartupDiagnostics> & {
        phase?: string;
        attempt?: number;
        state?: ServerState["agentState"];
    }) => void;
}>;
