/**
 * Resolves the admin/owner entity id for the local client-chat surface. Prefers
 * the runtime's canonical owner id, then a previously resolved id, then the
 * configured `agents.defaults.adminEntityId`, falling back to core's
 * `deterministicOwnerEntityId` (agent-ID seed) — the same fallback LifeOps
 * reads, the scheduler, and the PA routes use — so chat-written owner
 * rows stay visible to every reader. The agent NAME seed survives only for the
 * degenerate no-runtime case. The resolved id is written back onto state as
 * both `adminEntityId` and `chatUserId`.
 */
import { type IAgentRuntime, type UUID } from "@elizaos/core";
type ClientChatAdminState = {
    runtime?: IAgentRuntime | {
        agentId?: UUID;
        getSetting?: (key: string) => unknown;
    } | null;
    adminEntityId?: UUID | null;
    chatUserId?: UUID | null;
    config?: {
        agents?: {
            defaults?: {
                adminEntityId?: string;
            };
        };
    } | null;
    agentName: string;
};
export declare function resolveClientChatAdminEntityId<TState extends ClientChatAdminState>(state: TState): UUID;
export {};
