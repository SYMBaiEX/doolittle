/**
 * Canonical plugin-route dispatcher used by both the HTTP server and the
 * in-process (IPC) bridge.
 *
 * Both transports converge on this function so that one route definition in
 * `runtime.routes` serves both worlds:
 *
 *   HTTP (Hono / Node http)  ─┐
 *                              ├─→ dispatchRoute() ─→ Route.routeHandler (new)
 *   IPC (Bun ↔ Swift bridge) ─┘                    └→ Route.handler      (legacy Express shim)
 *
 * The legacy Express-style `handler` field is supported via a synthetic
 * `IncomingMessage` / `ServerResponse` shim that captures the response into
 * a {@link RouteHandlerResult}. New plugin routes should prefer
 * `routeHandler` which returns the result directly.
 */
import { Buffer } from "node:buffer";
import { EventEmitter } from "node:events";
import { Socket } from "node:net";
import { Readable } from "node:stream";
import { ElizaError, logger, } from "@elizaos/core";
import { assertPublicRouteIntent, getHttpRuntime, setRuntimeRouteHostContext, } from "@elizaos/host/protocol";
import { matchPluginRoutePath } from "./plugin-route-path.js";
import { loadX402PaymentModule, X402_ENFORCEMENT_UNAVAILABLE, } from "./x402-contract.js";
/** Lowercase normalize a header map. */
function normalizeHeaders(headers) {
    const out = {};
    for (const [key, value] of Object.entries(headers)) {
        if (typeof value === "string")
            out[key.toLowerCase()] = value;
    }
    return out;
}
function toIncomingHttpHeaders(headers) {
    const out = {};
    for (const [key, value] of Object.entries(headers)) {
        out[key.toLowerCase()] = value;
    }
    return out;
}
/** Coerce an arbitrary body into the JSON-decoded form Express handlers expect on `req.body`. */
function parseBodyAsJson(body) {
    if (body == null)
        return undefined;
    if (typeof body === "string") {
        const trimmed = body.trim();
        if (!trimmed)
            return undefined;
        try {
            return JSON.parse(trimmed);
        }
        catch {
            return body;
        }
    }
    if (Buffer.isBuffer(body)) {
        const text = body.toString("utf8").trim();
        if (!text)
            return undefined;
        try {
            return JSON.parse(text);
        }
        catch {
            return body;
        }
    }
    return body;
}
/**
 * Cap on the partial-body excerpt carried in a
 * `ROUTE_HANDLER_PARTIAL_WRITE_FAILURE` error context. The full captured body
 * may be arbitrarily large (a failed streaming route); the context exists for
 * diagnosis, not replay, so only a bounded prefix travels with the error.
 * The prefix may still contain response payload — J1 boundaries handling this
 * error must not log the full context verbatim for sensitive routes.
 */
const PARTIAL_BODY_CONTEXT_LIMIT = 512;
function asCapturedServerResponse(res) {
    return res;
}
/**
 * Builds a synthetic `IncomingMessage` / `ServerResponse` pair that legacy
 * Express-shaped route handlers can write to. The captured response is
 * returned as a {@link RouteHandlerResult}.
 */
export function buildLegacyShim(args) {
    const incomingHeaders = toIncomingHttpHeaders(args.headers);
    // Provide a readable stream body so handlers that call req.on('data') still work.
    const bodyText = (() => {
        if (args.body == null)
            return "";
        if (typeof args.body === "string")
            return args.body;
        if (Buffer.isBuffer(args.body))
            return args.body.toString("utf8");
        try {
            return JSON.stringify(args.body);
        }
        catch {
            return "";
        }
    })();
    const readable = Readable.from(bodyText ? [Buffer.from(bodyText, "utf8")] : [], 
    // Reading the request body does not disconnect the IPC response stream.
    { autoDestroy: false });
    const req = readable;
    req.socket = new Socket();
    Object.defineProperty(req.socket, "remoteAddress", { value: "127.0.0.1" });
    req.headers = incomingHeaders;
    req.method = args.method;
    req.url = args.path;
    req.path = args.path;
    req.protocol = "http";
    req.query = args.query;
    req.params = args.params;
    if (typeof args.body === "string") {
        req.rawBody = args.rawBody ?? args.body;
        req.body = parseBodyAsJson(args.body);
    }
    else if (Buffer.isBuffer(args.body)) {
        const text = args.body.toString("utf8");
        req.rawBody = args.rawBody ?? text;
        req.body = parseBodyAsJson(text);
    }
    else {
        req.rawBody = args.rawBody;
        req.body = parseBodyAsJson(args.body);
    }
    req.get = (name) => {
        const v = incomingHeaders[name.toLowerCase()];
        return Array.isArray(v) ? v[0] : v;
    };
    const captured = {
        statusCode: 200,
        headers: {},
        chunks: [],
        ended: false,
    };
    const setHeader = (name, value) => {
        const text = Array.isArray(value) ? value.join(", ") : String(value);
        captured.headers[name.toLowerCase()] = text;
    };
    let headersFlushed = false;
    const flushHeaders = () => {
        if (headersFlushed)
            return;
        headersFlushed = true;
        args.onHeaders?.(captured.statusCode, { ...captured.headers });
    };
    const writeChunk = (chunk) => {
        if (captured.destroyed)
            throw captured.failure;
        if (chunk == null)
            return;
        let buf;
        if (typeof chunk === "string") {
            buf = Buffer.from(chunk, "utf8");
        }
        else if (Buffer.isBuffer(chunk)) {
            buf = chunk;
        }
        else if (chunk instanceof Uint8Array) {
            buf = Buffer.from(chunk);
        }
        else {
            buf = Buffer.from(String(chunk), "utf8");
        }
        flushHeaders();
        captured.chunks.push(buf);
        // Forward to the incremental sink the instant the handler flushes, so an
        // in-process streaming transport can emit token frames as they arrive.
        args.onChunk?.(buf);
    };
    // Build a minimal ServerResponse-ish object. Plugin handlers only reach for
    // this subset (status/json/send/setHeader/end/write/headersSent), so the
    // structural boundary is isolated in asCapturedServerResponse().
    const res = Object.assign(new EventEmitter(), {
        statusCode: 200,
        flushHeaders,
        destroy(error) {
            if (!captured.destroyed) {
                captured.destroyed = true;
                captured.failure =
                    error ??
                        new ElizaError("Local response was destroyed", {
                            code: "LOCAL_RESPONSE_DESTROYED",
                        });
                res.emit("close");
            }
            return asCapturedServerResponse(res);
        },
        writeHead(code, headers) {
            captured.statusCode = code;
            for (const [name, value] of Object.entries(headers ?? {}))
                setHeader(name, value);
            flushHeaders();
            return asCapturedServerResponse(res);
        },
        setHeader,
        getHeader: (name) => captured.headers[name.toLowerCase()],
        removeHeader: (name) => {
            delete captured.headers[name.toLowerCase()];
        },
        write: (chunk) => {
            flushHeaders();
            writeChunk(chunk);
            return true;
        },
        end: (chunk) => {
            if (chunk != null)
                writeChunk(chunk);
            flushHeaders();
            captured.ended = true;
            res.emit("finish");
            return asCapturedServerResponse(res);
        },
        status(code) {
            this.statusCode = code;
            captured.statusCode = code;
            return {
                json(data) {
                    if (captured.ended)
                        return;
                    captured.headers["content-type"] =
                        captured.headers["content-type"] ??
                            "application/json; charset=utf-8";
                    writeChunk(JSON.stringify(data));
                    captured.ended = true;
                },
                send(data) {
                    if (captured.ended)
                        return;
                    if (typeof data === "string" || Buffer.isBuffer(data)) {
                        writeChunk(data);
                    }
                    else {
                        captured.headers["content-type"] =
                            captured.headers["content-type"] ??
                                "application/json; charset=utf-8";
                        writeChunk(JSON.stringify(data));
                    }
                    captured.ended = true;
                },
            };
        },
        json(data) {
            if (captured.ended)
                return res;
            captured.headers["content-type"] =
                captured.headers["content-type"] ?? "application/json; charset=utf-8";
            writeChunk(JSON.stringify(data));
            captured.ended = true;
            return res;
        },
        send(data) {
            if (captured.ended)
                return res;
            if (typeof data === "string" || Buffer.isBuffer(data)) {
                writeChunk(data);
            }
            else if (data != null) {
                captured.headers["content-type"] =
                    captured.headers["content-type"] ?? "application/json; charset=utf-8";
                writeChunk(JSON.stringify(data));
            }
            captured.ended = true;
            return res;
        },
    });
    Object.defineProperties(res, {
        headersSent: { get: () => headersFlushed || captured.ended },
        writableEnded: { get: () => captured.ended },
        destroyed: { get: () => captured.destroyed === true },
    });
    // Mirror statusCode writes from the handler onto the captured value.
    Object.defineProperty(res, "statusCode", {
        get() {
            return captured.statusCode;
        },
        set(v) {
            captured.statusCode = v;
        },
        configurable: true,
    });
    return {
        req,
        res: asCapturedServerResponse(res),
        captured,
    };
}
/**
 * Extract the media-type essence (RFC 9110 §8.3): everything before the first
 * `;` parameter separator, trimmed and lowercased. Media types compare
 * case-insensitively and parameters (`charset=…`, `boundary=…`) never change
 * the underlying type, so classification must ignore both. Header values are
 * normalized to lowercase at capture, but the essence is lowercased here again
 * so the comparison stays correct even for a caller that bypasses capture.
 */
function mediaTypeEssence(contentType) {
    const separatorIndex = contentType.indexOf(";");
    return (separatorIndex === -1 ? contentType : contentType.slice(0, separatorIndex))
        .trim()
        .toLowerCase();
}
export function capturedToResult(captured) {
    if (captured.failure)
        throw captured.failure;
    const buffer = Buffer.concat(captured.chunks);
    // Missing headers are meaningful here because undeclared bodies retain the
    // bridge's historical UTF-8 behavior.
    const contentTypeHeader = captured.headers["content-type"];
    const contentEncodingHeader = captured.headers["content-encoding"];
    const contentEncoding = typeof contentEncodingHeader === "string"
        ? contentEncodingHeader.trim().toLowerCase()
        : undefined;
    if (buffer.length === 0) {
        return {
            status: captured.statusCode || 200,
            headers: captured.headers,
            body: undefined,
        };
    }
    const mediaType = typeof contentTypeHeader === "string"
        ? mediaTypeEssence(contentTypeHeader)
        : undefined;
    const isJson = mediaType !== undefined &&
        (mediaType === "application/json" || mediaType.endsWith("+json"));
    // Content-Encoding describes the bytes on the wire: even a textual media
    // type stays compressed until the receiving stack decodes it, so any
    // non-identity encoding forces byte passthrough — decoding as UTF-8 would
    // make the downstream IPC base64 envelope lossy.
    const isEncoded = contentEncoding !== undefined &&
        contentEncoding !== "" &&
        contentEncoding !== "identity";
    const isTextual = mediaType === undefined ||
        mediaType === "" ||
        mediaType.startsWith("text/") ||
        isJson ||
        mediaType === "application/xml" ||
        mediaType.endsWith("+xml") ||
        mediaType === "application/javascript" ||
        mediaType === "application/x-javascript" ||
        mediaType === "application/x-www-form-urlencoded";
    if (isEncoded || !isTextual) {
        return {
            status: captured.statusCode || 200,
            headers: captured.headers,
            body: buffer,
        };
    }
    const text = buffer.toString("utf8");
    let body = text;
    if (isJson) {
        try {
            body = JSON.parse(text);
        }
        catch (error) {
            // error-policy:J2 context-adding rethrow: a declared-JSON body that does
            // not parse is a route failure; returning the raw text would let a broken
            // handler masquerade as success at every transport boundary.
            throw new ElizaError("legacy route declared JSON but body is malformed", {
                code: "ROUTE_RESPONSE_INVALID_JSON",
                cause: error,
                context: {
                    contentType: contentTypeHeader,
                    status: captured.statusCode,
                    bodyBytes: buffer.length,
                },
            });
        }
    }
    return {
        status: captured.statusCode || 200,
        headers: captured.headers,
        body,
    };
}
/**
 * Dispatch a single request against `runtime.routes`. Returns `null` when no
 * matching route is found. The caller is responsible for sending the result
 * back over whatever transport (HTTP response, IPC frame, etc.).
 */
export async function dispatchRoute(args) {
    args.signal?.throwIfAborted();
    const runtime = args.runtime;
    if (!runtime || !getHttpRuntime(runtime).routes.length)
        return null;
    const method = args.method.toUpperCase();
    const headers = normalizeHeaders(args.headers);
    const query = args.query ?? {};
    for (const route of getHttpRuntime(runtime).routes) {
        assertPublicRouteIntent(route, "runtime.routes");
        if (route.type === "STATIC")
            continue;
        if (route.type !== method)
            continue;
        if (!route.handler && !route.routeHandler)
            continue;
        const params = matchPluginRoutePath(route.path, args.path);
        if (params === null)
            continue;
        if (route.public !== true && !args.isAuthorized()) {
            return {
                status: 401,
                headers: { "content-type": "application/json; charset=utf-8" },
                body: { error: "Unauthorized" },
            };
        }
        const restoreHostContext = args.hostContext
            ? setRuntimeRouteHostContext(runtime, args.hostContext)
            : undefined;
        try {
            // A paid route runs only behind the payment wrapper, which wraps the
            // legacy handler. Without the wrapper (plugin absent, mobile stub, or no
            // legacy handler to wrap) the route is refused, never served unpaid.
            const paid = route.x402 != null;
            const x402 = paid ? await loadX402PaymentModule() : null;
            if (paid && (!x402 || !route.handler)) {
                logger.warn(`[dispatchRoute] refusing x402 route ${method} ${args.path}: payment enforcement unavailable`);
                return {
                    status: X402_ENFORCEMENT_UNAVAILABLE.status,
                    headers: { "content-type": "application/json; charset=utf-8" },
                    body: { ...X402_ENFORCEMENT_UNAVAILABLE.body },
                };
            }
            // New return-shape handler — preferred path.
            if (route.routeHandler && !paid) {
                const ctx = {
                    signal: args.signal ?? new AbortController().signal,
                    body: parseBodyAsJson(args.body),
                    rawBody: args.rawBody,
                    params,
                    query,
                    headers,
                    method,
                    path: args.path,
                    runtime: runtime,
                    inProcess: args.inProcess,
                    isTrustedLocal: args.isTrustedLocal?.() ?? false,
                    ...(args.accessContext ? { accessContext: args.accessContext } : {}),
                };
                return await route.routeHandler(ctx);
            }
            // Legacy Express-shaped handler — run through the synthetic shim so we
            // can capture the response into a structured RouteHandlerResult.
            const legacyHandler = route.handler;
            const effectiveHandler = x402 && !x402.isRoutePaymentWrapped(route)
                ? x402.createPaymentAwareHandler(route)
                : legacyHandler;
            const { req, res, captured } = buildLegacyShim({
                method,
                path: args.path,
                headers,
                query,
                params,
                body: args.body,
                rawBody: args.rawBody,
                onChunk: args.onChunk,
                onHeaders: args.onHeaders,
            });
            try {
                await effectiveHandler(req, res, runtime);
            }
            catch (err) {
                // error-policy:J1 route-dispatch failure translation: a handler that
                // throws before producing any observable output becomes the structured
                // 500 every transport serves; a handler that already wrote or ended is
                // rethrown as a typed failure below — never returned as success.
                if (!captured.ended && captured.chunks.length === 0) {
                    return {
                        status: 500,
                        headers: { "content-type": "application/json; charset=utf-8" },
                        body: {
                            error: err instanceof Error ? err.message : "Internal server error",
                        },
                    };
                }
                // The handler failed after writing: any chunks are already delivered
                // to a streaming consumer via onChunk (that delivery is not retracted),
                // but the buffered result would fabricate a healthy response for a
                // route that broke mid-write. Rethrow typed so every boundary surfaces
                // the failure — HTTP 500 (hono-adapter), `{ok:false}` IPC frame
                // (stdio-bridge kernel), terminal stream error frame (streaming sink).
                const partialBody = Buffer.concat(captured.chunks);
                throw new ElizaError("legacy route handler threw after writing its response", {
                    code: "ROUTE_HANDLER_PARTIAL_WRITE_FAILURE",
                    cause: err,
                    context: {
                        method,
                        path: args.path,
                        status: captured.statusCode,
                        ended: captured.ended,
                        partialBodyBytes: partialBody.length,
                        // Bounded so the log/error-event payload stays small even when a
                        // handler streamed megabytes before failing.
                        partialBodyBase64Prefix: partialBody
                            .subarray(0, PARTIAL_BODY_CONTEXT_LIMIT)
                            .toString("base64"),
                    },
                });
            }
            return capturedToResult(captured);
        }
        finally {
            restoreHostContext?.();
        }
    }
    return null;
}
