import type { IAgentRuntime } from "@elizaos/core";
import type { ViewRegistryEntry } from "./view-registry-types.js";
import type { ViewsRouteContext } from "./views-routes.js";
export declare function handleViewAssetRequest(ctx: ViewsRouteContext, runtime: IAgentRuntime, id: string, resource: string, authorized: (entry: ViewRegistryEntry) => boolean): Promise<boolean>;
