/**
 * Dispatches elizaOS AgentRuntime plugin routes (runtime.routes) on the Eliza
 * raw Node HTTP server. Core registers paths like `/music-player/stream`; without
 * this bridge those handlers never run.
 */
import type { IncomingMessage, ServerResponse } from "node:http";
import type { AgentRuntime } from "@elizaos/core";
import { type RuntimeRouteHostContext } from "@elizaos/host/protocol";
export { matchPluginRoutePath } from "./plugin-route-path.js";
export declare function isPublicRuntimePluginRoute(options: {
    runtime: AgentRuntime | null | undefined;
    method: string;
    pathname: string;
}): boolean;
/**
 * Runs the first matching runtime plugin route. Returns true if matched (even on handler error).
 */
export declare function tryHandleRuntimePluginRoute(options: {
    req: IncomingMessage;
    res: ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    runtime: AgentRuntime | null | undefined;
    isAuthorized: () => boolean;
    hostContext?: RuntimeRouteHostContext;
}): Promise<boolean>;
