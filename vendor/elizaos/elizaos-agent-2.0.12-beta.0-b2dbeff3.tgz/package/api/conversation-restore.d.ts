/**
 * Restore the in-memory web-chat conversation list from database truth.
 *
 * Each web-chat conversation is a room whose `channelId` is
 * `web-conv-{conversationId}`. On boot (or any "relaunch") the server has no
 * in-memory conversation list, so it rebuilds it from those rooms among the
 * agent's client-chat rooms (`getClientChatRooms`), reconstructing each
 * `ConversationMeta` from the persisted room — this is the server-truth
 * source the client thread re-renders from after an app relaunch.
 *
 * Extracted from `server.ts` (was an un-exported boot closure) so the relaunch
 * round-trip can be driven against a real database in tests (#13689): a sent
 * message must survive an app relaunch because it is read back from here, not
 * from optimistic client state. Callers run this as a background boot task and
 * decide how to surface failures at that boundary.
 */
import { type AgentRuntime } from "@elizaos/core";
import type { ConversationMeta } from "./server-types.js";
/** The in-memory conversation registry the restore writes into. */
export interface ConversationRestoreTarget {
    /** Reconstructed conversations are inserted here, keyed by conversation id. */
    conversations: Map<string, ConversationMeta>;
    /** Conversation ids the operator deleted this session — never re-restored. */
    deletedConversationIds: Set<string>;
    /** Optional structured-log sink (server wires this to its `addLog`). */
    log?: (message: string) => void;
}
/** The `channelId` prefix that marks a room as a web-chat conversation. */
export declare const WEB_CONVERSATION_CHANNEL_PREFIX = "web-conv-";
/**
 * Scan the agent's web-chat rooms and rebuild any not-yet-loaded, not-deleted
 * conversations from them. Returns the number restored.
 */
export declare function restoreConversationsFromDb(rt: AgentRuntime, target: ConversationRestoreTarget): Promise<number>;
export declare function restoreConversationFromDb(rt: AgentRuntime, target: ConversationRestoreTarget, convId: string): Promise<ConversationMeta | undefined>;
