/** Trusted launch policy for navigation-only views rendered by a consumer shell. */
import { type ViewDeclaration } from "@elizaos/core";
export declare const NATIVE_VIEW_DECLARATIONS_ENV = "ELIZA_NATIVE_VIEW_DECLARATIONS";
export declare function nativeViewDeclarations(raw: string | undefined, builtins: readonly ViewDeclaration[]): ViewDeclaration[];
