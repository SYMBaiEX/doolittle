/**
 * Pure helpers for the OpenAI- and Anthropic-compatible chat endpoints: flatten
 * a message `content` field (string, part arrays, or `{ text }` objects) to
 * plain text, collapse a request's `messages` to the joined system/developer
 * prompt plus the last user turn (so stateless clients that resend full history
 * do not duplicate server-side room memory), and resolve a stable room key from
 * whichever conversation identifier the client supplied. No I/O — the compat
 * route modules call these to normalize inbound bodies.
 */
import { createHash } from "node:crypto";
import { asObjectRecord as asRecord } from "@elizaos/core";
function readString(value) {
    return typeof value === "string" ? value : "";
}
/**
 * Extract a best-effort text string from OpenAI/Anthropic "content" fields.
 * Supports:
 * - string
 * - array of parts: [{ type: "text", text: "..." }, ...]
 * - objects with a `text` string field
 */
export function extractCompatTextContent(content) {
    if (typeof content === "string")
        return content;
    if (Array.isArray(content)) {
        const chunks = [];
        for (const item of content) {
            const obj = asRecord(item);
            if (!obj)
                continue;
            const type = readString(obj.type);
            if (type && type !== "text")
                continue;
            const text = readString(obj.text);
            if (text)
                chunks.push(text);
        }
        return chunks.join("");
    }
    const obj = asRecord(content);
    if (obj)
        return readString(obj.text);
    return "";
}
/**
 * For OpenAI-compatible requests, we intentionally reduce "messages" to:
 * - all system/developer messages (joined)
 * - the last user message
 *
 * This keeps the server-side room memory coherent (so stateless clients that
 * resend full history do not cause runaway duplication).
 */
export function extractOpenAiSystemAndLastUser(messages) {
    if (!Array.isArray(messages))
        return null;
    let system = "";
    let user = "";
    for (const item of messages) {
        const msg = asRecord(item);
        if (!msg)
            continue;
        const role = readString(msg.role);
        const contentText = extractCompatTextContent(msg.content);
        if (!contentText.trim())
            continue;
        if (role === "system" || role === "developer") {
            system = system
                ? `${system}\n\n${contentText.trim()}`
                : contentText.trim();
            continue;
        }
        if (role === "user") {
            user = contentText.trim();
        }
    }
    if (!user)
        return null;
    return { system, user };
}
export function extractAnthropicSystemAndLastUser(args) {
    if (!Array.isArray(args.messages))
        return null;
    const system = readString(args.system).trim();
    let user = "";
    for (const item of args.messages) {
        const msg = asRecord(item);
        if (!msg)
            continue;
        const role = readString(msg.role);
        if (role !== "user")
            continue;
        const contentText = extractCompatTextContent(msg.content);
        if (!contentText.trim())
            continue;
        user = contentText.trim();
    }
    if (!user)
        return null;
    return { system, user };
}
function readNestedString(obj, key) {
    const raw = obj[key];
    if (typeof raw === "string" && raw.trim())
        return raw.trim();
    return null;
}
/**
 * Resolve a stable room key for compatibility endpoints so manual testing can
 * keep conversation memory when the client provides an identifier.
 *
 * We accept a few common fields without requiring any one client:
 * - OpenAI: body.user (string)
 * - OpenAI: body.metadata.conversation_id
 * - Anthropic: body.metadata.user_id
 * - Anthropic: body.metadata.conversation_id
 */
export function resolveCompatRoomKey(body, fallback = "default") {
    const direct = readNestedString(body, "user");
    if (direct)
        return direct;
    const metadata = asRecord(body.metadata);
    if (metadata) {
        const conv = readNestedString(metadata, "conversation_id") ??
            readNestedString(metadata, "conversationId");
        if (conv)
            return conv;
        const userId = readNestedString(metadata, "user_id");
        if (userId)
            return userId;
    }
    return fallback;
}
/**
 * Maximum client-supplied conversation-key length embedded verbatim in the
 * room-UUID derivation.
 */
export const COMPAT_ROOM_KEY_MAX_LENGTH = 120;
/**
 * Scope a resolved conversation key for the room-UUID derivation without
 * aliasing distinct conversations onto one room.
 *
 * The derivation hashes whatever string it receives, so truncating a longer
 * key to {@link COMPAT_ROOM_KEY_MAX_LENGTH} made any two identifiers sharing a
 * 120-char prefix — JWT-style ids, path-like conversation keys — derive the
 * same roomId and silently share one conversation's memory. Keys within the
 * limit keep their exact historical derivation; longer keys are prefixed with
 * the complete SHA-256 digest of the full key, giving the room derivation a
 * collision-resistant scope. Rooms created before this fix from a >120-char
 * key are not reachable under the new derivation by design: they were already
 * merged with any prefix-sharing sibling.
 */
export function scopeCompatRoomKey(rawKey) {
    if (rawKey.length <= COMPAT_ROOM_KEY_MAX_LENGTH)
        return rawKey;
    const digest = createHash("sha256").update(rawKey, "utf8").digest("hex");
    return `sha256:${digest}`;
}
