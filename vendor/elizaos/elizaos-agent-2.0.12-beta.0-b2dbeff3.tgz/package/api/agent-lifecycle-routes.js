/**
 * Mounts the agent lifecycle HTTP routes on the shared route state: POST
 * /api/agent/{start,stop,pause,resume} drive the reported agent-state machine
 * (running/paused/stopped) and its uptime/startedAt, while GET /api/agent/autonomy
 * reads and POST /api/agent/autonomy toggles the autonomy loop — the POST
 * validates its body, calls enable/disableAutonomy on the AUTONOMY_SERVICE_TYPE
 * service when present, and always syncs runtime.enableAutonomy. Sits behind the
 * authenticated dashboard gate; not public.
 *
 * With no live runtime, POST /api/agent/start is a real boot request, not a
 * flag flip: it boots through the host's injected `onRestart` — the same
 * closure POST /api/agent/restart uses, which app's fresh-install
 * deferral funnels into a single-flight boot. Reporting "running" with a null
 * runtime would be fake-ready: a host that cannot boot answers 503, and a
 * failed boot answers 500 with the reported state flipped to "error".
 * POST /api/agent/stop disposes the live runtime, so a stopped agent runs no
 * connectors, autonomy or scheduled tasks. The host owns complete teardown,
 * including its adapter and boot resources; a host without stop and restart
 * handlers answers 501 because it cannot preserve the stop/start contract.
 */
import { PostAgentAutonomyRequestSchema } from "@elizaos/contracts";
import { AUTONOMY_SERVICE_TYPE } from "@elizaos/plugin-assistant";
import { detectRuntimeModel } from "./agent-model.js";
function isAutonomyToggleService(service) {
    return (typeof service === "object" &&
        service !== null &&
        typeof service.enableAutonomy ===
            "function" &&
        typeof service.disableAutonomy ===
            "function");
}
export async function handleAgentLifecycleRoutes(ctx) {
    const { req, res, method, pathname, state, error, json, readJsonBody } = ctx;
    const runtime = state.runtime;
    if (method === "POST" && pathname === "/api/agent/start") {
        if (state.runtimeStopPromise) {
            error(res, "Agent stop is still in progress", 409);
            return true;
        }
        if (!state.runtime) {
            // A boot is already underway (parallel-bind warming window, an
            // in-flight restart, or the deferred fresh-install boot): starting is
            // idempotent — report the in-progress state and let the client poll
            // /api/status instead of racing a second boot.
            if (state.agentState === "starting" ||
                state.agentState === "restarting") {
                json(res, {
                    ok: true,
                    status: {
                        state: state.agentState,
                        agentName: state.agentName,
                        model: state.model,
                        startedAt: state.startedAt,
                    },
                });
                return true;
            }
            if (!ctx.onRestart) {
                error(res, "Agent runtime is not available and this server cannot boot one on demand", 503);
                return true;
            }
            state.agentState = "starting";
            state.startedAt = Date.now();
            try {
                const previousRuntime = state.runtime;
                const booted = await ctx.onRestart();
                if (!booted) {
                    state.agentState = "error";
                    state.startedAt = undefined;
                    error(res, "Agent start failed — runtime did not initialize", 500);
                    return true;
                }
                state.runtime = booted;
                state.agentState = "running";
                state.agentName = booted.character.name ?? state.agentName;
                state.model = detectRuntimeModel(booted);
                state.startedAt = Date.now();
                ctx.onRuntimeSwapped?.();
                await ctx.onRuntimeActivated?.(previousRuntime, booted);
            }
            catch (err) {
                // error-policy:J1 boundary translation — the boot failure becomes a
                // structured 500 + reported state "error"; never a fake "running".
                state.agentState = "error";
                state.startedAt = undefined;
                error(res, `Agent start failed: ${err instanceof Error ? err.message : String(err)}`, 500);
                return true;
            }
        }
        else {
            // The runtime already exists: only record a fresh start time when this
            // request actually transitions the agent into running (e.g. from paused).
            // Re-starting an already-running agent must not reset the uptime clock.
            if (state.agentState !== "running")
                state.startedAt = Date.now();
            state.agentState = "running";
            state.model = detectRuntimeModel(state.runtime);
        }
        json(res, {
            ok: true,
            status: {
                state: state.agentState,
                agentName: state.agentName,
                model: state.model,
                uptime: state.startedAt ? Date.now() - state.startedAt : 0,
                startedAt: state.startedAt,
            },
        });
        return true;
    }
    if (method === "POST" && pathname === "/api/agent/stop") {
        if (state.runtimeStopPromise) {
            error(res, "Agent stop is already in progress", 409);
            return true;
        }
        if (state.agentState === "starting" || state.agentState === "restarting") {
            error(res, "Agent cannot stop while a start or restart is in progress", 409);
            return true;
        }
        if (state.runtime) {
            // Core stop does not close the database adapter or host boot resources.
            // The host must release everything it owns before this route publishes
            // the runtime-less stopped state.
            const stopRuntime = ctx.onStop;
            if (!stopRuntime || !ctx.onRestart) {
                error(res, "Stop is not supported in this mode: this server cannot fully stop and start the agent", 501);
                return true;
            }
            const stoppedRuntime = state.runtime;
            const stopPromise = Promise.resolve().then(() => stopRuntime(stoppedRuntime));
            state.runtimeStopPromise = stopPromise;
            try {
                await stopPromise;
            }
            catch (err) {
                if (state.runtime === stoppedRuntime) {
                    state.runtime = null;
                    state.chatConnectionReady = null;
                    state.chatConnectionPromise = null;
                }
                state.agentState = "error";
                state.startedAt = undefined;
                state.model = undefined;
                error(res, `Agent stop failed: ${err instanceof Error ? err.message : String(err)}`, 500);
                return true;
            }
            finally {
                if (state.runtimeStopPromise === stopPromise) {
                    state.runtimeStopPromise = null;
                }
            }
            if (state.runtime !== stoppedRuntime) {
                error(res, "Agent runtime changed while stop was in progress", 409);
                return true;
            }
            state.runtime = null;
            state.chatConnectionReady = null;
            state.chatConnectionPromise = null;
        }
        state.agentState = "stopped";
        state.startedAt = undefined;
        state.model = undefined;
        json(res, {
            ok: true,
            status: { state: state.agentState, agentName: state.agentName },
        });
        return true;
    }
    if (method === "POST" && pathname === "/api/agent/pause") {
        state.agentState = "paused";
        json(res, {
            ok: true,
            status: {
                state: state.agentState,
                agentName: state.agentName,
                model: state.model,
                uptime: state.startedAt ? Date.now() - state.startedAt : undefined,
                startedAt: state.startedAt,
            },
        });
        return true;
    }
    if (method === "POST" && pathname === "/api/agent/resume") {
        state.agentState = "running";
        json(res, {
            ok: true,
            status: {
                state: state.agentState,
                agentName: state.agentName,
                model: state.model,
                uptime: state.startedAt ? Date.now() - state.startedAt : undefined,
                startedAt: state.startedAt,
            },
        });
        return true;
    }
    if (method === "GET" && pathname === "/api/agent/autonomy") {
        json(res, { enabled: runtime?.enableAutonomy === true });
        return true;
    }
    if (method === "POST" && pathname === "/api/agent/autonomy") {
        const rawAuto = await readJsonBody(req, res);
        if (rawAuto === null)
            return true;
        const parsedAuto = PostAgentAutonomyRequestSchema.safeParse(rawAuto);
        if (!parsedAuto.success) {
            error(res, parsedAuto.error.issues[0]?.message ?? "enabled must be a boolean", 400);
            return true;
        }
        const enabled = parsedAuto.data.enabled;
        if (!runtime) {
            error(res, "Agent runtime is not available", 503);
            return true;
        }
        // Set the property AND call the service method so the batcher
        // section is actually registered/unregistered.
        const autonomySvc = runtime.getService(AUTONOMY_SERVICE_TYPE);
        if (isAutonomyToggleService(autonomySvc)) {
            if (enabled) {
                await autonomySvc.enableAutonomy();
            }
            else {
                await autonomySvc.disableAutonomy();
            }
        }
        // Always sync the property — enableAutonomy()/disableAutonomy() set it
        // internally, but if the service path wasn't taken, set it directly.
        runtime.enableAutonomy = enabled;
        json(res, { enabled: runtime.enableAutonomy === true });
        return true;
    }
    return false;
}
