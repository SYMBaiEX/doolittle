/**
 * Loopback-only `/pair` relay for standalone agent servers.
 * Remote managed pairing terminates at the Cloud edge; explicit local Docker
 * retains this handler so the one-time token resolves before the SPA fallback.
 *
 * Peer admission when `ELIZA_CLOUD_PAIR_DIRECT_RELAY=1`: loopback peers only,
 * plus any ranges in the optional `ELIZA_CLOUD_PAIR_ALLOWED_PEER_CIDRS`
 * comma-separated CIDR allowlist (default empty). The supported local-Docker
 * deployment publishes the port on the host's loopback, so inside the
 * container the TCP peer is the bridge gateway rather than 127.0.0.1 — set
 * e.g. `ELIZA_CLOUD_PAIR_ALLOWED_PEER_CIDRS=172.17.0.0/16` (default bridge)
 * to admit exactly that gateway range. Every CIDR entry widens token
 * redemption to that LAN/VPC segment, so keep the list as narrow as the
 * deployment allows.
 */
import type http from "node:http";
export declare function __resetCloudPairRateLimitForTests(): void;
export declare function handleStandaloneCloudPairRoute(req: http.IncomingMessage, res: http.ServerResponse): Promise<boolean>;
