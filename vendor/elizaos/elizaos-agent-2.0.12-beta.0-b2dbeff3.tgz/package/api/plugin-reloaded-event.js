/**
 * Builds the `plugin_reloaded` `view:event` broadcast — the shared payload shape
 * (plugin name, source directory, originating source) that tells dashboard
 * clients to refresh a hot-reloaded plugin's views.
 */
export const PLUGIN_RELOADED_VIEW_EVENT_TYPE = "plugin_reloaded";
export function buildPluginReloadedViewEvent({ pluginName, directory, source, }) {
    return {
        type: "view:event",
        viewEventType: PLUGIN_RELOADED_VIEW_EVENT_TYPE,
        payload: {
            pluginName,
            directory,
            source,
        },
    };
}
