import { actorFromAccessContext, isAdminRank } from "@elizaos/core";
/**
 * Select the Files list for one viewer: the single-owner boundary (no
 * context), the agent itself, and OWNER/ADMIN-rank viewers see every stored
 * file; USER/GUEST-tier viewers see the restricted state.
 */
export function selectFilesForViewer(files, accessContext, agentId) {
    if (!accessContext)
        return { files, restricted: false };
    const actor = actorFromAccessContext(accessContext, agentId);
    if (isAdminRank(actor.role) || actor.role === "AGENT") {
        return { files, restricted: false };
    }
    return { files: [], restricted: true };
}
