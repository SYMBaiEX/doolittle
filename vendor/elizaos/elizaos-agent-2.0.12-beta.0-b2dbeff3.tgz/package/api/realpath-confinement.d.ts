/**
 * Canonical path confinement shared by agent HTTP file-serving boundaries.
 *
 * Missing leaves resolve through their deepest existing ancestor. Benign
 * symlink prefixes are followed, while dangling links, loops, permission
 * faults, and other unresolvable paths return `null` so callers fail closed.
 */
/** Resolve an existing path or a missing tail to its canonical spelling. */
export declare function resolveRealPathSync(inputPath: string): string | null;
/** Async counterpart to `resolveRealPathSync` for request handlers. */
export declare function resolveRealPath(inputPath: string): Promise<string | null>;
/** Test canonical containment, optionally accepting the root itself. */
export declare function isPathWithinRoot(candidate: string, root: string, options?: {
    allowRoot?: boolean;
}): boolean;
