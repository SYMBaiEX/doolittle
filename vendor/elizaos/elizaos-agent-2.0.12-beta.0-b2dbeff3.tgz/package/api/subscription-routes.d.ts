import type { AnthropicFlow, CodexFlow } from "@elizaos/auth/auth";
import type { ElizaConfig, RouteRequestContext } from "@elizaos/host/protocol";
type AuthModule = typeof import("@elizaos/auth/auth");
export type SubscriptionAuthApi = Pick<AuthModule, "getSubscriptionStatus" | "exchangeAnthropicAuthorizationCode" | "fetchAnthropicOAuthProfile" | "startAnthropicLogin" | "startCodexLogin" | "submitProviderFlowCode" | "saveCredentials" | "applySubscriptionCredentials" | "deleteCredentials" | "deleteProviderCredentials">;
export interface SubscriptionRouteState {
    config: ElizaConfig;
    _anthropicFlow?: AnthropicFlow;
    _codexFlow?: CodexFlow;
    _codexFlowTimer?: ReturnType<typeof setTimeout>;
}
export interface SubscriptionRouteContext extends RouteRequestContext {
    state: SubscriptionRouteState;
    saveConfig: (config: ElizaConfig) => void;
    loadSubscriptionAuth: () => Promise<SubscriptionAuthApi>;
}
export declare function handleSubscriptionRoutes(ctx: SubscriptionRouteContext): Promise<boolean>;
export {};
