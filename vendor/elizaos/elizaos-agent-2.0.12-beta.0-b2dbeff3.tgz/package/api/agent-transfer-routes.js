import { AGENT_TRANSFER_MAX_PASSWORD_BYTES, AGENT_TRANSFER_MIN_PASSWORD_LENGTH, PostAgentExportRequestSchema, } from "@elizaos/contracts";
import { readRequestBodyBuffer } from "@elizaos/host";
const MAX_IMPORT_BYTES = 512 * 1_048_576;
function readRawBody(req, maxBytes) {
    return readRequestBodyBuffer(req, { maxBytes }).then((body) => {
        if (body === null) {
            throw new Error(`Request body exceeds maximum size (${maxBytes} bytes)`);
        }
        return body;
    });
}
export async function handleAgentTransferRoutes(ctx) {
    const { req, res, method, pathname, state, readJsonBody, json, error, exportAgent, estimateExportSize, importAgent, isAgentExportError, } = ctx;
    if (method === "POST" && pathname === "/api/agent/export") {
        if (!state.runtime) {
            error(res, "Agent is not running — start it before exporting.", 503);
            return true;
        }
        const rawExport = await readJsonBody(req, res);
        if (rawExport === null)
            return true;
        const parsedExport = PostAgentExportRequestSchema.safeParse(rawExport);
        if (!parsedExport.success) {
            error(res, parsedExport.error.issues[0]?.message ??
                `A password of at least ${AGENT_TRANSFER_MIN_PASSWORD_LENGTH} characters is required.`, 400);
            return true;
        }
        const body = parsedExport.data;
        try {
            const fileBuffer = await exportAgent(state.runtime, body.password, {
                includeLogs: body.includeLogs === true,
                excludeSecrets: body.excludeSecrets === true,
            });
            const agentName = (state.runtime.character.name ?? "agent")
                .replace(/[^a-zA-Z0-9_-]/g, "_")
                .toLowerCase();
            const timestamp = new Date()
                .toISOString()
                .replace(/[:.]/g, "-")
                .slice(0, 19);
            const filename = `${agentName}-${timestamp}.eliza-agent`;
            res.statusCode = 200;
            res.setHeader("Content-Type", "application/octet-stream");
            res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
            res.setHeader("Content-Length", fileBuffer.length);
            res.end(fileBuffer);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            if (isAgentExportError(err)) {
                error(res, message, 400);
            }
            else {
                error(res, `Export failed: ${message}`, 500);
            }
        }
        return true;
    }
    if (method === "GET" && pathname === "/api/agent/export/estimate") {
        if (!state.runtime) {
            error(res, "Agent is not running.", 503);
            return true;
        }
        try {
            const estimate = await estimateExportSize(state.runtime);
            json(res, estimate);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            error(res, `Estimate failed: ${message}`, 500);
        }
        return true;
    }
    if (method === "POST" && pathname === "/api/agent/import") {
        if (!state.runtime) {
            error(res, "Agent is not running — start it before importing.", 503);
            return true;
        }
        let rawBody;
        try {
            rawBody = await readRawBody(req, MAX_IMPORT_BYTES);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            error(res, message, 413);
            return true;
        }
        if (rawBody.length < 5) {
            error(res, "Request body is too small — expected password + file data.", 400);
            return true;
        }
        const passwordLength = rawBody.readUInt32BE(0);
        if (passwordLength < AGENT_TRANSFER_MIN_PASSWORD_LENGTH) {
            error(res, `Password must be at least ${AGENT_TRANSFER_MIN_PASSWORD_LENGTH} characters.`, 400);
            return true;
        }
        if (passwordLength > AGENT_TRANSFER_MAX_PASSWORD_BYTES) {
            error(res, `Password is too long (max ${AGENT_TRANSFER_MAX_PASSWORD_BYTES} bytes).`, 400);
            return true;
        }
        if (rawBody.length < 4 + passwordLength + 1) {
            error(res, "Request body is partial — missing file data after password.", 400);
            return true;
        }
        const password = rawBody.subarray(4, 4 + passwordLength).toString("utf-8");
        const fileBuffer = rawBody.subarray(4 + passwordLength);
        try {
            const result = await importAgent(state.runtime, fileBuffer, password);
            json(res, result);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            if (isAgentExportError(err)) {
                error(res, message, 400);
            }
            else {
                error(res, `Import failed: ${message}`, 500);
            }
        }
        return true;
    }
    return false;
}
