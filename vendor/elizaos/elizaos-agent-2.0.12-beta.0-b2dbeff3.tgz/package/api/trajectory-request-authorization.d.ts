import type http from "node:http";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
/** Raw trajectory context is an owner surface, not a session-tier read. */
export declare function isTrajectoryOwnerRequest(req: http.IncomingMessage, method: string, pathname: string, hostAuthorization: AgentHttpRequestAuthorization, allowAmbientLocal?: boolean): boolean;
