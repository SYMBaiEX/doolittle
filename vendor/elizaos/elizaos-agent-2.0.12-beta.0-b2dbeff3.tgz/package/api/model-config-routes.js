/**
 * Validated read/write surface for user-configurable models behind the
 * authenticated control API. `POST /api/models/config` checks every request
 * against the provider→model→efforts catalog (model-catalog.ts) before
 * touching config — Codex silently accepts an invalid
 * `model_reasoning_effort`, so this route is the enforcement seam — then
 * persists the selection to all three config seams at once:
 * `config.env.vars[KEY]`, `config.env[KEY]` (the section the orchestrator's
 * `readConfigEnvKey` re-reads per spawn), and `process.env[KEY]`.
 *
 * Chat-brain targets (small/large) require a runtime restart for the model
 * plugin to pick up the new ids, driven through the same idempotent
 * RuntimeOperationManager the provider-switch route uses — the config write
 * happens inside the operation's prepare step so a busy runtime rejects
 * without a half-applied config. Coding targets return without restart:
 * sub-agent spawns re-read the config env on every spawn. A coding write may
 * also be a defaultBackend-only body (no `model`), persisting just
 * ELIZA_DEFAULT_AGENT_TYPE — the application backend selection seam.
 * When a touched key
 * already carried a different process-env value that the config did not put
 * there (systemd service.env, shell export), the response lists it in
 * `conflictingServiceEnvKeys` as an honest warning — a full service restart
 * may resurrect the external value.
 *
 * `GET /api/models/config` reports the current effective value for every key
 * this route owns, with the source that won (`config.env` → `config.env.vars`
 * → `process.env`). `activeChat` names the serving provider only when its
 * runtime handler and direct-provider credential are usable. Unresolved vault
 * references and configured-but-unservable providers omit the field.
 */
import { ElizaError, logger, ModelType, } from "@elizaos/core";
import { DEFAULT_ELIZA_CLOUD_LARGE_TEXT_MODEL, DEFAULT_ELIZA_CLOUD_TEXT_MODEL, resolveServiceRoutingInConfig, } from "@elizaos/host/protocol";
import { resolveElizaCloudBaseURL } from "@elizaos/plugin-elizacloud/endpoint-config";
import { isCerebrasMode, resolveOpenAIBaseURL } from "@elizaos/plugin-openai";
import { isDevCloudEnvOwnedKey, resolveDevCloudEnvAuthority, } from "../config/dev-cloud-env-authority.js";
import { isVaultRef } from "../runtime/operations/vault-bridge.js";
import { reconcileConfigEnvSettings } from "../runtime/runtime-settings.js";
import { hasCloudTextHandlerRegistered } from "./agent-model.js";
import { buildModelCatalog, CODING_MODEL_DEFAULTS, } from "./model-catalog.js";
const TARGETS = new Set(["small", "large", "coding"]);
const CODING_BACKENDS = new Set([
    "codex",
    "claude",
    "eliza-code",
]);
const CHAT_PROVIDER_KEY_FAMILY = {
    cerebras: "OPENAI",
    elizacloud: "ELIZAOS_CLOUD",
    "claude-chat": "ANTHROPIC",
};
const DEFAULT_ANTHROPIC_BASE_URL = "https://api.anthropic.com/v1";
/**
 * Keep model-status diagnostics loadable in provider-minimal runtime images.
 * Dedicated Cerebras images intentionally omit plugin-anthropic, so this API
 * route cannot statically depend on that optional provider package merely to
 * resolve its base URL. This mirrors plugin-anthropic's pure endpoint policy.
 */
function resolveAnthropicBaseURL(readSetting, options = {}) {
    const mockBaseURL = options.mockBaseURL?.trim();
    if (mockBaseURL)
        return mockBaseURL;
    return (readSetting("ANTHROPIC_BASE_URL")?.trim() || DEFAULT_ANTHROPIC_BASE_URL);
}
// serviceRouting.llmText backend ids → the catalog chat provider that serves
// them. "anthropic" is the provider-switch id; the catalog names that brain
// "claude-chat".
const LLM_BACKEND_TO_CHAT_PROVIDER = {
    cerebras: "cerebras",
    elizacloud: "elizacloud",
    anthropic: "claude-chat",
    openai: "openai",
};
// Model keys are the `powerful` slots of TASK_AGENT_MODEL_PREF_SETTING_KEYS
// (plugin-agent-orchestrator/src/services/task-agent-frameworks.ts) — the keys
// spawns actually read. The effort keys are persisted now; the CLI adapters
// grow their consumers in a follow-on wiring change.
const CODING_BACKEND_SEAMS = {
    codex: {
        modelKey: "ELIZA_CODEX_MODEL_POWERFUL",
        effortKey: "ELIZA_CODEX_EFFORT",
        catalogProvider: "codex",
    },
    claude: {
        modelKey: "ELIZA_CLAUDE_MODEL_POWERFUL",
        effortKey: "ELIZA_CLAUDE_EFFORT",
        catalogProvider: "claude-coding",
    },
    "eliza-code": {
        modelKey: "ELIZA_ELIZAOS_MODEL_POWERFUL",
        effortKey: null,
        catalogProvider: null,
    },
};
// The orchestrator's KNOWN_ADAPTER_TYPES spells the in-house backend
// "elizaos"; persisting the API's "eliza-code" literal would be silently
// dropped by its adapter normalization.
const DEFAULT_BACKEND_PERSISTED_VALUE = {
    codex: "codex",
    claude: "claude",
    "eliza-code": "elizaos",
};
function invalid(message, context) {
    return new ElizaError(message, {
        code: "MODEL_CONFIG_INVALID",
        context,
        severity: "ephemeral",
    });
}
function findEntry(catalog, provider, model) {
    return catalog.providers[provider]?.find((entry) => entry.id === model);
}
// Keep this aligned with MANAGED_CODEX_ACP_EFFORTS in app's
// coding-account-bridge.ts. The model catalog may advertise newer effort
// variants before the managed Codex ACP spawn path supports them end to end;
// accepting one here would persist a selection the coding backend cannot honor.
const MANAGED_CODEX_ACP_EFFORTS = new Set([
    "low",
    "medium",
    "high",
    "xhigh",
]);
function validateEffort(entry, effort) {
    if (entry.efforts.length === 0) {
        throw invalid(`Model "${entry.id}" exposes no effort control`, {
            model: entry.id,
            effort,
        });
    }
    if (!entry.efforts.includes(effort)) {
        throw invalid(`Effort "${effort}" is not supported by model "${entry.id}" (supported: ${entry.efforts.join(", ")})`, { model: entry.id, effort, supported: entry.efforts });
    }
}
function ensureEnvSections(config) {
    const record = config;
    if (!record.env ||
        typeof record.env !== "object" ||
        Array.isArray(record.env)) {
        record.env = {};
    }
    const direct = record.env;
    if (!direct.vars ||
        typeof direct.vars !== "object" ||
        Array.isArray(direct.vars)) {
        direct.vars = {};
    }
    return { direct, vars: direct.vars };
}
function readConfigEnvString(config, key) {
    const env = config.env;
    if (!env || typeof env !== "object" || Array.isArray(env))
        return null;
    const direct = env[key];
    if (typeof direct === "string" && direct.trim()) {
        return { value: direct, source: "config.env" };
    }
    const vars = env.vars;
    if (vars && typeof vars === "object" && !Array.isArray(vars)) {
        const nested = vars[key];
        if (typeof nested === "string" && nested.trim()) {
            return { value: nested, source: "config.env.vars" };
        }
    }
    return null;
}
/**
 * Write one key to all three seams. Returns true when process.env already
 * carried a different value that the config did not put there — i.e. it came
 * from an external source (systemd service.env, shell export) that a full
 * service restart may re-apply over this save.
 */
function writeModelEnvKey(config, processEnv, key, value) {
    const priorProcess = processEnv[key];
    const priorConfig = readConfigEnvString(config, key)?.value;
    const { direct, vars } = ensureEnvSections(config);
    direct[key] = value;
    vars[key] = value;
    processEnv[key] = value;
    return (typeof priorProcess === "string" &&
        priorProcess !== value &&
        priorProcess !== priorConfig);
}
function resolveChatWrites(catalog, body, activeProvider) {
    if (body.backend !== undefined) {
        throw invalid(`backend is a coding-target field; target "${body.target}" selects a chat provider`, { target: body.target, backend: body.backend });
    }
    // parseWriteBody only omits `model` for the defaultBackend-only coding
    // shape; re-assert here so the chat path stays typed on a plain string.
    const model = body.model;
    if (model === undefined) {
        throw invalid("model must be a non-empty string", { model: null });
    }
    let provider = body.provider;
    if (provider !== undefined && !(provider in CHAT_PROVIDER_KEY_FAMILY)) {
        throw invalid(`Unknown chat provider "${provider}" (expected one of: ${Object.keys(CHAT_PROVIDER_KEY_FAMILY).join(", ")})`, { provider });
    }
    if (provider === undefined) {
        const matches = Object.keys(CHAT_PROVIDER_KEY_FAMILY).filter((candidate) => findEntry(catalog, candidate, model)?.roles.includes(body.target));
        if (matches.length === 0) {
            throw invalid(`Unknown model "${model}" for target "${body.target}"`, {
                model,
                target: body.target,
            });
        }
        if (matches.length > 1) {
            // The Cerebras trio is offered by both cerebras (direct) and elizacloud
            // (proxied) — a bare `/model small gemma-4-31b` must land on whichever
            // brain is actually serving chat, not 400 on the overlap.
            if (activeProvider !== undefined && matches.includes(activeProvider)) {
                provider = activeProvider;
            }
            else {
                throw invalid(`Model "${model}" is served by multiple providers (${matches.join(", ")}); specify provider`, { model, providers: matches });
            }
        }
        else {
            provider = matches[0];
        }
    }
    const entry = findEntry(catalog, provider, model);
    if (!entry) {
        throw invalid(`Unknown model "${model}" for provider "${provider}"`, {
            model,
            provider,
        });
    }
    if (!entry.roles.includes(body.target)) {
        throw invalid(`Model "${model}" is not offered for the "${body.target}" role on provider "${provider}"`, { model, provider, target: body.target, roles: entry.roles });
    }
    const family = CHAT_PROVIDER_KEY_FAMILY[provider];
    const targetUpper = body.target.toUpperCase();
    const writes = [
        { key: `${family}_${targetUpper}_MODEL`, value: model },
    ];
    if (body.effort !== undefined) {
        validateEffort(entry, body.effort);
        writes.push(family === "ANTHROPIC"
            ? { key: `ANTHROPIC_EFFORT_${targetUpper}`, value: body.effort }
            : family === "ELIZAOS_CLOUD"
                ? { key: "ELIZAOS_CLOUD_REASONING_EFFORT", value: body.effort }
                : { key: "OPENAI_REASONING_EFFORT", value: body.effort });
    }
    return writes;
}
function resolveCodingWrites(catalog, body) {
    // defaultBackend-only switch: no model seam is touched, so the model-write
    // fields would be silently ignored — reject their presence loudly instead.
    if (body.model === undefined) {
        if (body.backend !== undefined ||
            body.provider !== undefined ||
            body.effort !== undefined) {
            throw invalid("a defaultBackend-only write must not carry backend, provider, or effort", {
                backend: body.backend ?? null,
                provider: body.provider ?? null,
                effort: body.effort ?? null,
            });
        }
        const writes = resolveDefaultBackendWrites(body);
        if (writes.length === 0) {
            // parseWriteBody admits the modelless shape only with a defaultBackend;
            // never let it decay into an applied-but-empty write.
            throw invalid("model must be a non-empty string", { model: null });
        }
        return writes;
    }
    const model = body.model;
    const backend = body.backend;
    if (backend === undefined || !CODING_BACKENDS.has(backend)) {
        throw invalid(`target "coding" requires backend (one of: ${[...CODING_BACKENDS].join(", ")})`, { backend: backend ?? null });
    }
    const seam = CODING_BACKEND_SEAMS[backend];
    if (body.provider !== undefined && body.provider !== seam.catalogProvider) {
        throw invalid(`provider "${body.provider}" does not match coding backend "${backend}"`, { provider: body.provider, backend });
    }
    if (seam.catalogProvider) {
        const entry = findEntry(catalog, seam.catalogProvider, model);
        if (!entry) {
            throw invalid(`Unknown model "${model}" for backend "${backend}"`, {
                model,
                backend,
                provider: seam.catalogProvider,
            });
        }
        if (body.effort !== undefined) {
            validateEffort(entry, body.effort);
            if (backend === "codex" && !MANAGED_CODEX_ACP_EFFORTS.has(body.effort)) {
                throw invalid(`Effort "${body.effort}" is valid for ${entry.id} but not supported by the managed codex-acp contract (supported: ${[...MANAGED_CODEX_ACP_EFFORTS].join(", ")})`, {
                    model: entry.id,
                    effort: body.effort,
                    supported: [...MANAGED_CODEX_ACP_EFFORTS],
                    reason: "codex-acp-contract",
                });
            }
        }
    }
    else if (body.effort !== undefined) {
        throw invalid(`backend "${backend}" has no effort control`, {
            backend,
            effort: body.effort,
        });
    }
    const writes = [{ key: seam.modelKey, value: model }];
    if (body.effort !== undefined && seam.effortKey) {
        writes.push({ key: seam.effortKey, value: body.effort });
    }
    writes.push(...resolveDefaultBackendWrites(body));
    return writes;
}
function resolveDefaultBackendWrites(body) {
    if (body.defaultBackend === undefined)
        return [];
    if (!CODING_BACKENDS.has(body.defaultBackend)) {
        throw invalid(`Unknown defaultBackend "${body.defaultBackend}"`, {
            defaultBackend: body.defaultBackend,
        });
    }
    return [
        {
            key: "ELIZA_DEFAULT_AGENT_TYPE",
            value: DEFAULT_BACKEND_PERSISTED_VALUE[body.defaultBackend],
        },
    ];
}
function parseWriteBody(raw) {
    const target = raw.target;
    if (typeof target !== "string" || !TARGETS.has(target)) {
        throw invalid(`target must be one of: ${[...TARGETS].join(", ")}`, {
            target: target ?? null,
        });
    }
    const model = raw.model;
    // `model` may be omitted only for the defaultBackend-only coding switch;
    // every other shape validates it exactly as before.
    const defaultBackendOnly = target === "coding" &&
        model === undefined &&
        raw.defaultBackend !== undefined;
    if (!defaultBackendOnly && (typeof model !== "string" || !model.trim())) {
        throw invalid("model must be a non-empty string", { model: model ?? null });
    }
    const optionalString = (field) => {
        const value = raw[field];
        if (value === undefined)
            return undefined;
        if (typeof value !== "string" || !value.trim()) {
            throw invalid(`${field} must be a non-empty string when provided`, {
                [field]: value,
            });
        }
        return value.trim();
    };
    const backend = optionalString("backend");
    if (backend !== undefined && !CODING_BACKENDS.has(backend)) {
        throw invalid(`Unknown backend "${backend}" (expected one of: ${[...CODING_BACKENDS].join(", ")})`, { backend });
    }
    const defaultBackend = optionalString("defaultBackend");
    if (defaultBackend !== undefined &&
        !CODING_BACKENDS.has(defaultBackend)) {
        throw invalid(`Unknown defaultBackend "${defaultBackend}" (expected one of: ${[...CODING_BACKENDS].join(", ")})`, { defaultBackend });
    }
    return {
        target: target,
        model: typeof model === "string" ? model.trim() : undefined,
        provider: optionalString("provider"),
        backend: backend,
        effort: optionalString("effort"),
        defaultBackend: defaultBackend,
    };
}
function resolveEffective(config, processEnv, key) {
    const fromConfig = readConfigEnvString(config, key);
    if (fromConfig)
        return fromConfig;
    const fromProcess = processEnv[key];
    if (typeof fromProcess === "string" && fromProcess.trim()) {
        return { value: fromProcess, source: "process.env" };
    }
    return null;
}
function hostOf(value) {
    if (!value)
        return null;
    try {
        return new URL(value).hostname;
    }
    catch {
        // error-policy:J3 a non-URL base value can't name a host; callers fall
        // back to the provider's canonical endpoint.
        return null;
    }
}
function hasTextHandlerRegistered(runtime, provider) {
    try {
        return (runtime.getModelRegistrations?.() ?? []).some((entry) => (entry.modelType === ModelType.TEXT_SMALL ||
            entry.modelType === ModelType.TEXT_LARGE) &&
            entry.provider === provider);
    }
    catch (error) {
        // error-policy:J7 Report diagnostics failure while withholding serving proof.
        runtime.reportError("model-config.serving-truth", error);
        return false;
    }
}
const DIRECT_CHAT_SERVING_REQUIREMENTS = {
    cerebras: {
        credentialKeys: ["CEREBRAS_API_KEY", "OPENAI_API_KEY"],
        runtimeProvider: "openai",
    },
    openai: {
        credentialKeys: ["OPENAI_API_KEY"],
        runtimeProvider: "openai",
    },
    "claude-chat": {
        credentialKeys: ["ANTHROPIC_API_KEY"],
        runtimeProvider: "anthropic",
    },
};
function isUsableProviderCredential(value) {
    return (typeof value === "string" &&
        value.trim().length > 0 &&
        !isVaultRef(value.trim()));
}
function isConfiguredCerebrasMode(runtime, processEnv) {
    try {
        const settingsRuntime = new Proxy(runtime, {
            get(target, property, receiver) {
                if (property !== "getSetting") {
                    return Reflect.get(target, property, receiver);
                }
                return (key) => {
                    const runtimeValue = runtime.getSetting(key);
                    if (runtimeValue !== null && runtimeValue !== undefined) {
                        return runtimeValue;
                    }
                    return processEnv[key] ?? "";
                };
            },
        });
        return isCerebrasMode(settingsRuntime);
    }
    catch (error) {
        // error-policy:J7 Report diagnostics failure while withholding serving proof.
        runtime.reportError("model-config.serving-truth", error);
        return false;
    }
}
function hasDirectProviderServingEvidence(provider, processEnv, runtime) {
    const requirement = DIRECT_CHAT_SERVING_REQUIREMENTS[provider];
    if (!requirement ||
        !hasTextHandlerRegistered(runtime, requirement.runtimeProvider) ||
        (provider === "cerebras" && !isConfiguredCerebrasMode(runtime, processEnv))) {
        return false;
    }
    for (const credentialKey of requirement.credentialKeys) {
        let runtimeCredential;
        try {
            runtimeCredential = runtime.getSetting(credentialKey);
        }
        catch (error) {
            // error-policy:J7 Report credential lookup failure without claiming readiness.
            runtime.reportError("model-config.serving-truth", error, {
                credentialKey,
            });
            return false;
        }
        if (isUsableProviderCredential(runtimeCredential))
            return true;
        if (runtimeCredential !== null && runtimeCredential !== undefined) {
            if (String(runtimeCredential).trim().length > 0)
                return false;
            continue;
        }
        const environmentCredential = processEnv[credentialKey];
        if (isUsableProviderCredential(environmentCredential))
            return true;
        if (environmentCredential?.trim())
            return false;
    }
    return false;
}
export function resolveActiveChat(config, processEnv, runtime) {
    const routing = resolveServiceRoutingInConfig(config);
    const llmText = routing?.llmText;
    const backend = typeof llmText?.backend === "string" ? llmText.backend : undefined;
    const cloudProxyConfigured = llmText?.transport === "cloud-proxy" && backend === "elizacloud";
    let provider;
    if (cloudProxyConfigured) {
        provider =
            runtime && hasCloudTextHandlerRegistered(runtime)
                ? "elizacloud"
                : undefined;
    }
    else if (llmText?.transport === "direct" && backend !== undefined) {
        const candidate = LLM_BACKEND_TO_CHAT_PROVIDER[backend];
        if (candidate === "elizacloud") {
            provider =
                runtime && hasCloudTextHandlerRegistered(runtime)
                    ? candidate
                    : undefined;
        }
        else if (runtime &&
            candidate &&
            hasDirectProviderServingEvidence(candidate, processEnv, runtime)) {
            provider = candidate;
        }
    }
    else if (routing === null) {
        // Legacy/local launches may configure plugin-openai directly from the
        // environment without persisting a serviceRouting block. ELIZA_PROVIDER is
        // itself plugin-openai's explicit routing selector, so it is stronger
        // evidence than guessing from a base URL or credential presence. Preserve
        // the cloud-proxy fall-through above: an unsigned Cloud route must still
        // report no external brain and fall back locally.
        const explicitProvider = resolveEffective(config, processEnv, "ELIZA_PROVIDER")?.value.toLowerCase();
        if (explicitProvider === "cerebras" &&
            runtime &&
            hasDirectProviderServingEvidence("cerebras", processEnv, runtime)) {
            provider = "cerebras";
        }
    }
    const family = provider === "openai"
        ? "OPENAI"
        : provider !== undefined
            ? CHAT_PROVIDER_KEY_FAMILY[provider]
            : undefined;
    if (provider === undefined || family === undefined)
        return null;
    const readSetting = (key) => resolveEffective(config, processEnv, key)?.value;
    const baseURL = family === "ELIZAOS_CLOUD"
        ? resolveElizaCloudBaseURL(readSetting)
        : family === "ANTHROPIC"
            ? resolveAnthropicBaseURL(readSetting, {
                mockBaseURL: processEnv.ELIZA_MOCK_ANTHROPIC_BASE,
            })
            : resolveOpenAIBaseURL((key) => (key === "ELIZA_PROVIDER" ? provider : readSetting(key)), { mockBaseURL: processEnv.ELIZA_MOCK_OPENAI_BASE });
    const endpoint = hostOf(baseURL) ??
        new URL(family === "ELIZAOS_CLOUD"
            ? "https://api.eliza.app/api/v1"
            : family === "ANTHROPIC"
                ? "https://api.anthropic.com/v1"
                : provider === "cerebras"
                    ? "https://api.cerebras.ai/v1"
                    : "https://api.openai.com/v1").hostname;
    return { provider, family, endpoint };
}
function buildEffectiveConfig(config, processEnv, activeChat) {
    const resolve = (key) => resolveEffective(config, processEnv, key);
    // The cloud plugin falls back to a code default when no env pin exists;
    // report it (source "default") only while cloud is the active brain so the
    // panel/show never claim a cloud default is in effect under direct routing.
    const cloudModel = (target) => {
        const pinned = resolve(`ELIZAOS_CLOUD_${target}_MODEL`);
        if (pinned)
            return pinned;
        if (activeChat?.family === "ELIZAOS_CLOUD") {
            return {
                value: target === "LARGE"
                    ? DEFAULT_ELIZA_CLOUD_LARGE_TEXT_MODEL
                    : DEFAULT_ELIZA_CLOUD_TEXT_MODEL,
                source: "default",
            };
        }
        return null;
    };
    const chatKeys = (target) => ({
        [`OPENAI_${target}_MODEL`]: resolve(`OPENAI_${target}_MODEL`),
        [`ANTHROPIC_${target}_MODEL`]: resolve(`ANTHROPIC_${target}_MODEL`),
        [`ELIZAOS_CLOUD_${target}_MODEL`]: cloudModel(target),
        OPENAI_REASONING_EFFORT: resolve("OPENAI_REASONING_EFFORT"),
        [`ANTHROPIC_EFFORT_${target}`]: resolve(`ANTHROPIC_EFFORT_${target}`),
        ELIZAOS_CLOUD_REASONING_EFFORT: resolve("ELIZAOS_CLOUD_REASONING_EFFORT"),
    });
    const codexDefault = CODING_MODEL_DEFAULTS.codex;
    const claudeDefault = CODING_MODEL_DEFAULTS.claude;
    return {
        small: chatKeys("SMALL"),
        large: chatKeys("LARGE"),
        coding: {
            ELIZA_DEFAULT_AGENT_TYPE: resolve("ELIZA_DEFAULT_AGENT_TYPE"),
            ELIZA_CODEX_MODEL_POWERFUL: resolve("ELIZA_CODEX_MODEL_POWERFUL") ??
                (codexDefault ? { value: codexDefault, source: "default" } : null),
            ELIZA_CODEX_EFFORT: resolve("ELIZA_CODEX_EFFORT"),
            ELIZA_CLAUDE_MODEL_POWERFUL: resolve("ELIZA_CLAUDE_MODEL_POWERFUL") ??
                (claudeDefault ? { value: claudeDefault, source: "default" } : null),
            ELIZA_CLAUDE_EFFORT: resolve("ELIZA_CLAUDE_EFFORT"),
            ELIZA_ELIZAOS_MODEL_POWERFUL: resolve("ELIZA_ELIZAOS_MODEL_POWERFUL"),
        },
    };
}
/**
 * Handle `GET`/`POST /api/models/config`. Returns true when the request was
 * handled.
 */
export async function handleModelConfigRoutes(ctx) {
    const { req, res, method, pathname, state, json, readJsonBody } = ctx;
    if (pathname !== "/api/models/config")
        return false;
    const processEnv = ctx.processEnv ?? process.env;
    // Capture launcher ownership before reading the request. The model route may
    // edit non-Cloud providers during local development, but Cloud-prefixed
    // model selections belong to the immutable launch tuple.
    const devCloudAuthority = resolveDevCloudEnvAuthority();
    if (method === "GET") {
        const activeChat = resolveActiveChat(state.config, processEnv, state.runtime ?? null);
        json(res, {
            targets: buildEffectiveConfig(state.config, processEnv, activeChat),
            ...(activeChat ? { activeChat } : {}),
        });
        return true;
    }
    if (method !== "POST")
        return false;
    const raw = await readJsonBody(req, res);
    if (raw === null)
        return true;
    try {
        const body = parseWriteBody(raw);
        const catalog = ctx.catalog ?? buildModelCatalog();
        if (body.target === "coding") {
            const writes = resolveCodingWrites(catalog, body);
            const previousConfig = structuredClone(state.config);
            const conflicts = [];
            for (const write of writes) {
                if (writeModelEnvKey(state.config, processEnv, write.key, write.value)) {
                    conflicts.push(write.key);
                }
            }
            ctx.saveElizaConfig(state.config);
            // No restart: the orchestrator reads runtime settings before the config
            // file, so the runtime copy the old config owned must move with it.
            if (state.runtime) {
                reconcileConfigEnvSettings(state.runtime, previousConfig, state.config);
            }
            logger.info(`[ModelConfigRoutes] coding model config applied: ${writes.map((w) => `${w.key}=${w.value}`).join(" ")}`);
            json(res, {
                applied: true,
                restart: false,
                keys: writes.map((w) => w.key),
                ...(conflicts.length > 0
                    ? { conflictingServiceEnvKeys: conflicts }
                    : {}),
            });
            return true;
        }
        const writes = resolveChatWrites(catalog, body, resolveActiveChat(state.config, processEnv, state.runtime ?? null)
            ?.provider);
        if (devCloudAuthority &&
            writes.some((write) => isDevCloudEnvOwnedKey(write.key))) {
            json(res, {
                error: "Cloud model selection is owned by the immutable local dev launch target; restart with the intended Cloud model configuration.",
            }, 409);
            return true;
        }
        const conflicts = [];
        const outcome = await ctx.runtimeOperationManager.start({
            intent: {
                kind: "restart",
                reason: `model-config: ${body.target} model set to ${body.model}`,
            },
            // Writing inside prepare keeps the config change atomic with operation
            // acceptance: a rejected-busy outcome leaves the config untouched.
            prepare: async () => {
                for (const write of writes) {
                    if (writeModelEnvKey(state.config, processEnv, write.key, write.value)) {
                        conflicts.push(write.key);
                    }
                }
                ctx.saveElizaConfig(state.config);
                return undefined;
            },
        });
        if (outcome.kind === "rejected-busy") {
            json(res, {
                error: "A runtime operation is already in progress",
                activeOperationId: outcome.activeOperationId,
            }, 409);
            return true;
        }
        logger.info(`[ModelConfigRoutes] ${body.target} model config applied: ${writes.map((w) => `${w.key}=${w.value}`).join(" ")} op=${outcome.operation.id}`);
        json(res, {
            applied: outcome.kind === "accepted",
            restart: true,
            operationId: outcome.operation.id,
            keys: writes.map((w) => w.key),
            ...(outcome.kind === "deduped" ? { deduped: true } : {}),
            ...(conflicts.length > 0 ? { conflictingServiceEnvKeys: conflicts } : {}),
        });
        return true;
    }
    catch (err) {
        // error-policy:J1 route transport boundary — translate the typed
        // validation failure into a structured 400 and anything else into a 500.
        if (err instanceof ElizaError) {
            json(res, { error: err.message, code: err.code, context: err.context }, 400);
            return true;
        }
        logger.error(`[ModelConfigRoutes] model config write failed: ${err instanceof Error ? err.stack : String(err)}`);
        json(res, { error: "Model config update failed" }, 500);
        return true;
    }
}
