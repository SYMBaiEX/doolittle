/**
 * Transport and server-state type definitions shared across the agent HTTP API.
 * Defines `ServerState` — the mutable per-process state the route handlers read
 * and mutate (runtime, config, agent lifecycle state, conversations, WebSocket
 * broadcast hooks, connector and pairing sessions) — plus the `PluginEntry` DTO
 * the dashboard renders, conversation/share/attachment shapes, and the
 * connector route-handler signature.
 */
import type http from "node:http";
import type { ConversationMetadata, TradePermissionMode } from "@elizaos/contracts";
import type { AgentAutomationMode, AgentRuntime, AgentStartupDiagnostics, AgentLogEntry as LogEntry, Media, PermissionState, PluginParamDef, SkillEntry, StreamEventEnvelope, UUID } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { CloudManager } from "@elizaos/plugin-elizacloud/host-routes";
import type { SandboxManager } from "../services/sandbox-manager.js";
import type { ConnectorHealthMonitor } from "./connector-health.js";
export type CloudManagerLike = CloudManager | null;
export type AppManagerLike = unknown;
export interface StoppablePairingSession {
    stop: () => void | Promise<void>;
}
export interface TelegramAccountAuthSessionLike {
    stop: () => void | Promise<void>;
}
/** Metadata for a web-chat conversation. */
export interface ConversationMeta {
    id: string;
    title: string;
    roomId: UUID;
    metadata?: ConversationMetadata;
    createdAt: string;
    updatedAt: string;
}
export interface ShareIngestItem {
    id: string;
    source: string;
    title?: string;
    url?: string;
    text?: string;
    suggestedPrompt: string;
    receivedAt: number;
}
/** A connector-registered route handler. Returns `true` if the request was handled. */
export type ConnectorRouteHandler = (req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string) => Promise<boolean>;
export interface PluginEntry {
    id: string;
    name: string;
    description: string;
    tags: string[];
    enabled: boolean;
    configured: boolean;
    envKey: string | null;
    category: "ai-provider" | "connector" | "streaming" | "database" | "app" | "feature";
    /** Where the plugin comes from: "bundled" (ships with Eliza) or "store" (user-installed from registry). */
    source: "bundled" | "store";
    configKeys: string[];
    parameters: PluginParamDef[];
    validationErrors: Array<{
        field: string;
        message: string;
    }>;
    validationWarnings: Array<{
        field: string;
        message: string;
    }>;
    npmName?: string;
    directory?: string | null;
    registryKind?: string;
    origin?: "builtin" | "third-party" | string;
    registrySource?: string;
    support?: "first-party" | "community" | string;
    builtIn?: boolean;
    firstParty?: boolean;
    thirdParty?: boolean;
    status?: string;
    version?: string;
    releaseStream?: "latest" | "beta";
    requestedVersion?: string;
    latestVersion?: string | null;
    betaVersion?: string | null;
    pluginDeps?: string[];
    /** Whether this plugin is currently active in the runtime. */
    isActive?: boolean;
    /** Error message when plugin is enabled/installed but failed to load. */
    loadError?: string;
    /** Server-provided UI hints for plugin configuration fields. */
    configUiHints?: Record<string, Record<string, unknown>>;
    /** Optional icon URL or emoji for the plugin card header. */
    icon?: string | null;
    homepage?: string;
    repository?: string;
    setupGuideUrl?: string;
    autoEnabled?: boolean;
    managementMode?: "standard" | "core-optional";
    capabilityStatus?: "loaded" | "auto-enabled" | "blocked" | "missing-prerequisites" | "disabled";
    capabilityReason?: string | null;
    prerequisites?: Array<{
        label: string;
        met: boolean;
    }>;
}
export interface ServerState {
    runtime: AgentRuntime | null;
    config: ElizaConfig;
    agentState: "not_started" | "starting" | "running" | "paused" | "stopped" | "restarting" | "error";
    agentName: string;
    model: string | undefined;
    startedAt: number | undefined;
    startup: AgentStartupDiagnostics;
    plugins: PluginEntry[];
    skills: SkillEntry[];
    logBuffer: LogEntry[];
    eventBuffer: StreamEventEnvelope[];
    nextEventId: number;
    chatRoomId: UUID | null;
    chatUserId: UUID | null;
    chatConnectionReady: {
        userId: UUID;
        roomId: UUID;
        worldId: UUID;
    } | null;
    chatConnectionPromise: Promise<void> | null;
    /** Serializes host-owned runtime teardown against lifecycle routes. */
    runtimeStopPromise: Promise<void> | null;
    adminEntityId: UUID | null;
    /** Conversation metadata by conversation id. */
    conversations: Map<string, ConversationMeta>;
    /** Active foreground chat turns; proactive interaction comments stay silent while nonzero. */
    activeChatTurnCount: number;
    /** Pending restore of persisted conversations into the in-memory map. */
    conversationRestorePromise: Promise<void> | null;
    /** Tombstones for conversation IDs explicitly deleted by the user. */
    deletedConversationIds: Set<string>;
    /** Cloud manager for Eliza Cloud integration (null when cloud is disabled). */
    cloudManager: CloudManagerLike;
    sandboxManager: SandboxManager | null;
    /** App manager for launching and managing elizaOS apps. */
    appManager: AppManagerLike;
    /** In-memory queue for share ingest items. */
    shareIngestQueue: ShareIngestItem[];
    /** Broadcast current agent status to all WebSocket clients. Set by startApiServer. */
    broadcastStatus: (() => void) | null;
    /** Broadcast an arbitrary JSON message to all WebSocket clients. Set by startApiServer. */
    broadcastWs: ((data: object) => void) | null;
    /** Broadcast a JSON payload to WebSocket clients bound to a specific client id. */
    broadcastWsToClientId: ((clientId: string, data: object) => number) | null;
    /**
     * Broadcast a JSON payload only to WebSocket clients that currently have the
     * given conversation active. Returns the number of clients delivered to.
     * Set by startApiServer.
     */
    broadcastWsToConversation: ((conversationId: string, data: object) => number) | null;
    /**
     * Most-recently-set active conversation across all connections, used as a
     * sensible default for code paths that need *any* active conversation
     * (autonomy routing, swarm synthesis). Per-connection active conversations
     * are tracked inside the WebSocket layer, not here.
     */
    activeConversationId: string | null;
    /** Transient OAuth flow state for subscription auth. */
    _anthropicFlow?: import("@elizaos/auth/auth").AnthropicFlow;
    _codexFlow?: import("@elizaos/auth/auth").CodexFlow;
    _codexFlowTimer?: ReturnType<typeof setTimeout>;
    /** System permission states (cached from the desktop bridge). */
    permissionStates?: Record<string, PermissionState>;
    /** Whether shell access is enabled (can be toggled in UI). */
    shellEnabled?: boolean;
    /** Agent automation permission mode for self-directed config changes. */
    agentAutomationMode?: AgentAutomationMode;
    /** Wallet trade execution permission mode (user-sign/manual/agent-auto). */
    tradePermissionMode?: TradePermissionMode;
    /** Reasons a restart is pending. Empty array = no restart needed. */
    pendingRestartReasons: string[];
    /** Route handlers registered by connector plugins (loaded dynamically). */
    connectorRouteHandlers: ConnectorRouteHandler[];
    /** Connector health monitor for detecting dead connectors. */
    connectorHealthMonitor: ConnectorHealthMonitor | null;
    /** Active WhatsApp pairing sessions (QR code flow). */
    whatsappPairingSessions?: Map<string, StoppablePairingSession>;
    /** Active Telegram account auth session (user-account login flow). */
    telegramAccountAuthSession?: TelegramAccountAuthSessionLike | null;
}
/**
 * Extension of the core Media attachment shape that carries raw image bytes for
 * action handlers (e.g. POST operation=send) while the message is in-memory.
 */
export interface ChatAttachmentWithData extends Media {
    /** Raw base64 image data -- never written to the database. */
    _data: string;
    /** MIME type corresponding to `_data`. */
    _mimeType: string;
}
