/**
 * Buffers structured logs emitted before the API server can expose them.
 * The logger listener API preserves logger ownership and provides an explicit
 * handoff when the server installs its long-lived capture listener.
 */
import { type AgentLogEntry as LogEntry, type LogEntry as StructuredLogEntry } from "@elizaos/core";
/** Converts logger-package entries into the API's stable transport shape. */
export declare function formatStructuredLogEntry(entry: StructuredLogEntry): LogEntry;
/**
 * Subscribes to one logical entry per logger call. The logger currently emits
 * both its invocation entry and Adze's rendered mirror to the global listener;
 * only the invocation entry belongs in the API transport.
 */
export declare function listenForUiLogs(onEntry: (entry: LogEntry) => void): () => void;
/** Starts idempotent capture for the pre-server portion of agent startup. */
export declare function captureEarlyLogs(): void;
/** Drains captured entries and releases the pre-server logger listener. */
export declare function flushEarlyLogs(): LogEntry[];
