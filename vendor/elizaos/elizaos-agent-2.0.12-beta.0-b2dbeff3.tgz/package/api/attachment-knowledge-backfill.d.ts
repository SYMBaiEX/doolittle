/**
 * One-time idempotent backfill for pre-existing knowledge records that predate
 * the attachment→knowledge ingest tagging (#13593). Transcript-mirror documents
 * (tag `transcript`) and meeting mirrors were written before this slice added
 * the room/sender/media-format facets, so a search on `roomId`/`mediaFormat`
 * misses them. This sweep adds:
 *
 *   - `metadata.roomId` (from the record's own `roomId`, when absent), and
 *   - `metadata.mediaFormat = "transcript"` + the `media-format:transcript` tag
 *
 * WITHOUT touching the `transcriptId` / `audioUrl` links (those stay the source
 * of truth). It is idempotent: a record already carrying both facets is skipped,
 * so re-running is a no-op. Runs as a runtime task so it executes once wherever
 * the agent runs and never blocks boot.
 */
import type { IAgentRuntime, Memory } from "@elizaos/core";
/**
 * Compute the patched metadata for a transcript-mirror record, or null when it
 * already carries both the `roomId` and `mediaFormat`/format-tag facets (i.e.
 * nothing to do — the idempotency check).
 */
export declare function computeTranscriptBackfillMetadata(memory: Memory): Record<string, unknown> | null;
/**
 * Scan the documents table and backfill transcript-mirror records missing the
 * room/media-format facets. Returns the number of records updated. Pure sweep:
 * link fields (`transcriptId`, `audioUrl`) are preserved.
 */
export declare function backfillTranscriptKnowledgeTags(runtime: IAgentRuntime): Promise<number>;
/**
 * Register the one-time backfill worker. Task-row creation is deliberately
 * separate because plugin initialization runs before SQL migrations, while the
 * awaited startup-maintenance boundary schedules the row after the database is
 * ready.
 */
export declare function registerAttachmentKnowledgeBackfillWorker(runtime: IAgentRuntime): void;
/** Ensure the idempotent backfill has one queued task after SQL is ready. */
export declare function scheduleAttachmentKnowledgeBackfill(runtime: IAgentRuntime): Promise<void>;
