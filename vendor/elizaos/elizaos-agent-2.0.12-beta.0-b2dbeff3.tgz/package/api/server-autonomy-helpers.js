/**
 * Server-side autonomy helpers for the agent HTTP surface. Recognizes the
 * LifeOps cloud plugin routes, and forwards autonomy assistant-stream agent
 * events into the user's conversation as proactive text — dropping empty
 * payloads, client-chat echoes, and events whose room is already tracked by an
 * open conversation, then handing the rest to routeAutonomyTextToUser.
 */
import { MESSAGE_SOURCE_CLIENT_CHAT, validateUuid } from "@elizaos/core";
import { AUTONOMY_NOTIFICATION_DELIVERY, } from "../runtime/agent-event-service.js";
import { routeAutonomyTextToUser } from "./server-helpers-swarm.js";
export function isLifeOpsCloudPluginRoute(pathname) {
    return (pathname === "/api/cloud/features" ||
        pathname === "/api/cloud/features/sync" ||
        pathname.startsWith("/api/cloud/travel-providers/"));
}
export async function maybeRouteAutonomyEventToConversation(state, event) {
    if (event.stream !== "assistant")
        return;
    const payload = event.data && typeof event.data === "object"
        ? event.data
        : null;
    const text = typeof payload?.text === "string" ? payload.text : "";
    if (!text.trim())
        return;
    const explicitSource = typeof payload?.source === "string" ? payload.source : null;
    const hasExplicitSource = explicitSource !== null && explicitSource.trim().length > 0;
    const source = hasExplicitSource ? explicitSource.trim() : "autonomy";
    if (source === MESSAGE_SOURCE_CLIENT_CHAT)
        return;
    if (!hasExplicitSource && !event.roomId)
        return;
    if (event.roomId &&
        Array.from(state.conversations.values()).some((conversation) => conversation.roomId === event.roomId)) {
        return;
    }
    const handoff = payload?.[AUTONOMY_NOTIFICATION_DELIVERY];
    if (handoff?.routed)
        return handoff.routed;
    const routed = routeAutonomyTextToUser(state, text, source, payload?.reminderPresentation, source === "reminder" &&
        payload?.ownerType === "occurrence" &&
        payload.subjectType === "owner" &&
        validateUuid(payload.ownerId) &&
        typeof payload.scheduledFor === "string" &&
        Number.isFinite(Date.parse(payload.scheduledFor)) &&
        (payload.dueAt === null ||
            (typeof payload.dueAt === "string" &&
                Number.isFinite(Date.parse(payload.dueAt))))
        ? {
            ownerType: "occurrence",
            ownerId: payload.ownerId,
            subjectType: "owner",
            scheduledFor: payload.scheduledFor,
            dueAt: payload.dueAt,
        }
        : undefined, handoff?.publish);
    if (handoff)
        handoff.routed = routed;
    await routed;
}
