export function createServerState(options) {
    const runtime = options.runtime ?? null;
    const hasRuntime = runtime !== null;
    const agentState = hasRuntime
        ? "running"
        : (options.initialAgentState ?? "not_started");
    const startup = agentState === "running"
        ? { phase: "running", attempt: 0 }
        : agentState === "starting"
            ? { phase: "starting", attempt: 0 }
            : { phase: "idle", attempt: 0 };
    return {
        runtime,
        config: options.config,
        agentState,
        agentName: hasRuntime
            ? (runtime.character.name ?? options.resolveAgentName(options.config))
            : options.resolveAgentName(options.config),
        model: hasRuntime
            ? options.detectRuntimeModel(runtime, options.config)
            : undefined,
        startedAt: hasRuntime || agentState === "starting" ? Date.now() : undefined,
        startup,
        plugins: options.plugins,
        skills: [],
        logBuffer: [],
        eventBuffer: [],
        // A dashboard retains its replay cursor across server restarts. Seed the
        // sequence from startup time to avoid resetting to evt-1 and dropping new
        // events as duplicates. This assumes the wall clock has not moved backward
        // and the previous process emitted fewer than 1000 events per millisecond.
        nextEventId: Date.now() * 1000,
        chatRoomId: null,
        chatUserId: null,
        chatConnectionReady: null,
        chatConnectionPromise: null,
        runtimeStopPromise: null,
        adminEntityId: null,
        conversations: new Map(),
        activeChatTurnCount: 0,
        conversationRestorePromise: null,
        deletedConversationIds: options.deletedConversationIds,
        cloudManager: null,
        sandboxManager: null,
        appManager: null,
        shareIngestQueue: [],
        broadcastStatus: null,
        broadcastWs: null,
        broadcastWsToClientId: null,
        broadcastWsToConversation: null,
        activeConversationId: null,
        permissionStates: {},
        shellEnabled: options.config.features?.shellEnabled !== false,
        agentAutomationMode: options.resolveAgentAutomationMode(options.config),
        tradePermissionMode: options.resolveTradePermissionMode(options.config),
        pendingRestartReasons: [],
        connectorRouteHandlers: [],
        connectorHealthMonitor: null,
        whatsappPairingSessions: new Map(),
    };
}
