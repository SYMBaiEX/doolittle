/**
 * Owns TCP listener binding, dynamic-port fallback, and socket shutdown for the
 * agent API. The composition root supplies logging and resource teardown so
 * this transport boundary remains independent of agent features.
 */
import type { Server } from "node:http";
export interface HttpListener {
    port: number;
    close(): Promise<void>;
}
export interface ListenHttpServerOptions {
    server: Server;
    host: string;
    port: number;
    strictPortBinding: boolean;
    closeResources(): Promise<void>;
    onBeforeListen?(): void;
    onPortInUse?(port: number, willFallback: boolean): void;
    onListening?(host: string, port: number): void;
    onServerError?(error: NodeJS.ErrnoException): void;
    onCloseHelperError?(helper: string, error: unknown): void;
}
export declare function listenHttpServer(options: ListenHttpServerOptions): Promise<HttpListener>;
