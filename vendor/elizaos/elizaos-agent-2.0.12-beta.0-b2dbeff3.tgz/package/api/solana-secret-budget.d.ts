/**
 * Character budgets for Solana secrets and addresses. `base58Decode` in
 * `wallet-keygen.ts` does one BigInt multiply per input
 * character; an 88-character 64-byte secret is honest, but a megabyte of
 * alphabet text is quadratic and hangs first-time setup / import /
 * `validatePrivateKey` on the request thread.
 */
/** Ceiling for a Solana secret input, including the supported JSON byte-array form. */
export declare const MAX_SOLANA_SECRET_CHARS = 512;
/** Maximum base58 length of a 64-byte Solana secret; addresses are shorter. */
export declare const MAX_SOLANA_BASE58_CHARS = 88;
export declare const SOLANA_SECRET_TOO_LONG = "Solana secret exceeds 512 characters";
export declare const SOLANA_BASE58_TOO_LONG = "Solana base58 value exceeds 88 characters";
/** Throw before BigInt-per-character decode when `value` cannot be an honest key. */
export declare function assertSolanaSecretCharBudget(value: string): void;
/** Throw before base58 decoding when `value` cannot encode a Solana secret. */
export declare function assertSolanaBase58CharBudget(value: string): void;
