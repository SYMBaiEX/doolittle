/**
 * Canonical runtime-mode resolver (#13725).
 *
 * Eliza ships in three top-level runtime shapes — `local`, `cloud`, `remote`
 * — plus a `local-only` sub-state of `local` that hides every cloud-routed
 * surface. This module is the single source of truth that the API layer,
 * the local-inference service, and the UI bridge all read from.
 *
 * Resolution order (highest precedence first):
 *   1. `config.deploymentTarget.runtime` — the persisted first-run choice.
 *   2. (local only) `config.cloud.enabled === false` collapses `local` to
 *      `local-only`.
 *
 * The `RUNTIME_EXECUTION_MODE` env var family in
 * `@elizaos/host/protocol` is a *different* concept (sandbox
 * vs. yolo execution policy for shell tools); do not conflate.
 */
import { type DeploymentTargetConfig } from "@elizaos/host/protocol";
import * as zod from "zod";
export declare const RUNTIME_MODES: readonly ["local", "local-only", "cloud", "remote"];
export type RuntimeMode = (typeof RUNTIME_MODES)[number];
export interface RuntimeModeSnapshot {
    mode: RuntimeMode;
    deploymentTarget: DeploymentTargetConfig | null;
    /** Present iff `mode === "remote"`. The local-instance HTTP base the
     *  controller proxies to. Cloud/public bases are rejected here too so
     *  stale or hand-edited config cannot turn remote mode into cloud mode. */
    remoteApiBase: string | null;
    /** Populated when a remote target was configured but rejected. */
    remoteApiBaseError: string | null;
    remoteAccessToken: string | null;
}
declare const RuntimeModeConfigSchema: zod.ZodObject<{
    deploymentTarget: zod.ZodOptional<zod.ZodUnknown>;
    cloud: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strip>>;
}, zod.z.core.$loose>;
type RuntimeModeConfigShape = zod.infer<typeof RuntimeModeConfigSchema>;
/**
 * Pure resolver — no I/O. Use this when you already hold the config object
 * (route handlers usually do) so the caller picks the load strategy.
 */
export declare function resolveRuntimeMode(config: RuntimeModeConfigShape | null | undefined): RuntimeModeSnapshot;
/** Test-only: drop the snapshot cache so config edits apply immediately. */
export declare function __resetRuntimeModeSnapshotCacheForTests(): void;
export declare function getRuntimeMode(): RuntimeMode;
/** Disk-backed snapshot (cached; see resolver note above). */
export declare function getRuntimeModeSnapshot(): RuntimeModeSnapshot;
/** True for both `local` and `local-only`. */
export declare function isLocalRuntime(mode: RuntimeMode): boolean;
export interface RemoteApiBaseValidationOk {
    ok: true;
    href: string;
}
export interface RemoteApiBaseValidationErr {
    ok: false;
    error: string;
}
export type RemoteApiBaseValidation = RemoteApiBaseValidationOk | RemoteApiBaseValidationErr;
/**
 * Remote mode is a thin controller for another local/private Eliza instance,
 * never for Eliza Cloud or a public model API. Accept loopback, private
 * RFC1918/CGNAT/link-local hosts, and .local mDNS names.
 */
export declare function validateRemoteApiBase(value: string | null | undefined): RemoteApiBaseValidation;
export declare function isLocalRemoteHost(hostname: string): boolean;
export {};
