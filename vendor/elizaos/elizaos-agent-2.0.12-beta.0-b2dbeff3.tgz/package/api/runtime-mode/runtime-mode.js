/**
 * Canonical runtime-mode resolver (#13725).
 *
 * Eliza ships in three top-level runtime shapes — `local`, `cloud`, `remote`
 * — plus a `local-only` sub-state of `local` that hides every cloud-routed
 * surface. This module is the single source of truth that the API layer,
 * the local-inference service, and the UI bridge all read from.
 *
 * Resolution order (highest precedence first):
 *   1. `config.deploymentTarget.runtime` — the persisted first-run choice.
 *   2. (local only) `config.cloud.enabled === false` collapses `local` to
 *      `local-only`.
 *
 * The `RUNTIME_EXECUTION_MODE` env var family in
 * `@elizaos/host/protocol` is a *different* concept (sandbox
 * vs. yolo execution policy for shell tools); do not conflate.
 */
import { normalizeDeploymentTargetConfig, } from "@elizaos/host/protocol";
import * as zod from "zod";
import { loadEffectiveElizaConfigSnapshot, } from "../../config/config.js";
const z = zod.z ?? zod;
export const RUNTIME_MODES = [
    "local",
    "local-only",
    "cloud",
    "remote",
];
// Strong schema for the slice of `eliza.json` this resolver consumes.
// The shared `DeploymentTargetConfig` is already validated by
// `normalizeDeploymentTargetConfig`, so we keep that field as `unknown`
// and let the normalizer enforce the contract. The `cloud` block is the
// only opaque-typed surface this module needs to read.
const RuntimeModeConfigSchema = z
    .object({
    deploymentTarget: z.unknown().optional(),
    cloud: z
        .object({
        enabled: z.boolean().optional(),
    })
        .optional(),
})
    .passthrough();
function parseRuntimeModeConfig(config) {
    if (config == null)
        return null;
    const parsed = RuntimeModeConfigSchema.safeParse(config);
    // Unknown shape ⇒ behave as "no config" so the resolver returns the
    // default `local` mode rather than throwing. Writers that produce
    // garbage are caught at their own boundary; the resolver stays pure.
    return parsed.success ? parsed.data : null;
}
/**
 * Pure resolver — no I/O. Use this when you already hold the config object
 * (route handlers usually do) so the caller picks the load strategy.
 */
export function resolveRuntimeMode(config) {
    const deploymentTarget = normalizeDeploymentTargetConfig(config?.deploymentTarget);
    if (deploymentTarget?.runtime === "remote") {
        const remoteApiBase = deploymentTarget.remoteApiBase?.trim() || null;
        const remoteValidation = validateRemoteApiBase(remoteApiBase);
        let validatedRemoteApiBase = null;
        let remoteApiBaseError = null;
        if ("href" in remoteValidation) {
            validatedRemoteApiBase = remoteValidation.href;
        }
        else {
            remoteApiBaseError = remoteValidation.error;
        }
        return {
            mode: "remote",
            deploymentTarget,
            remoteApiBase: validatedRemoteApiBase,
            remoteApiBaseError,
            remoteAccessToken: deploymentTarget.remoteAccessToken?.trim() || null,
        };
    }
    if (deploymentTarget?.runtime === "cloud") {
        return {
            mode: "cloud",
            deploymentTarget,
            remoteApiBase: null,
            remoteApiBaseError: null,
            remoteAccessToken: null,
        };
    }
    // Default and explicit `local` — `cloud.enabled === false` collapses
    // to `local-only`. The strong schema above means we can read the
    // field directly without a `typeof === "object"` guard.
    const cloudExplicitlyDisabled = config?.cloud?.enabled === false;
    return {
        mode: cloudExplicitlyDisabled ? "local-only" : "local",
        deploymentTarget: deploymentTarget ?? null,
        remoteApiBase: null,
        remoteApiBaseError: null,
        remoteAccessToken: null,
    };
}
/**
 * Cache the loader-owned effective config revision, not just the canonical
 * file. Identity changes apply immediately; file changes are checked within
 * one second. Unchanged requests never reconstruct the config/include graph.
 */
let cachedSnapshot = null;
let cachedConfig = null;
let cachedStatAtMs = 0;
const SNAPSHOT_STAT_INTERVAL_MS = 1_000;
function resolveSnapshotCached() {
    const now = Date.now();
    const checkFiles = now < cachedStatAtMs || now - cachedStatAtMs >= SNAPSHOT_STAT_INTERVAL_MS;
    try {
        if (cachedSnapshot && cachedConfig?.isCurrent({ checkFiles })) {
            if (checkFiles)
                cachedStatAtMs = now;
            return cachedSnapshot;
        }
        // Invalidate before loading: a missing/malformed source must not cause a
        // later request inside the stat interval to reuse the previous authority.
        cachedConfig = null;
        cachedSnapshot = null;
        const config = loadEffectiveElizaConfigSnapshot();
        cachedSnapshot = resolveRuntimeMode(parseRuntimeModeConfig(config.config));
        cachedConfig = config;
        cachedStatAtMs = now;
        return cachedSnapshot;
    }
    catch (error) {
        // error-policy:J2 preserve loader errors without retaining stale authority.
        cachedConfig = null;
        cachedSnapshot = null;
        throw error;
    }
}
/** Test-only: drop the snapshot cache so config edits apply immediately. */
export function __resetRuntimeModeSnapshotCacheForTests() {
    cachedSnapshot = null;
    cachedConfig = null;
    cachedStatAtMs = 0;
}
export function getRuntimeMode() {
    return resolveSnapshotCached().mode;
}
/** Disk-backed snapshot (cached; see resolver note above). */
export function getRuntimeModeSnapshot() {
    return resolveSnapshotCached();
}
/** True for both `local` and `local-only`. */
export function isLocalRuntime(mode) {
    return mode === "local" || mode === "local-only";
}
/**
 * Remote mode is a thin controller for another local/private Eliza instance,
 * never for Eliza Cloud or a public model API. Accept loopback, private
 * RFC1918/CGNAT/link-local hosts, and .local mDNS names.
 */
export function validateRemoteApiBase(value) {
    const raw = value?.trim();
    if (!raw) {
        return { ok: false, error: "Remote target not configured" };
    }
    let url;
    try {
        url = new URL(raw);
    }
    catch {
        return { ok: false, error: "Remote target must be a valid URL" };
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
        return { ok: false, error: "Remote target must use http or https" };
    }
    if (!isLocalRemoteHost(url.hostname)) {
        return {
            ok: false,
            error: "Remote mode can only target loopback, .local, or private-network Eliza instances",
        };
    }
    url.pathname = url.pathname.replace(/\/+$/, "");
    return { ok: true, href: url.toString() };
}
export function isLocalRemoteHost(hostname) {
    const host = hostname
        .trim()
        .toLowerCase()
        .replace(/^\[(.*)\]$/, "$1");
    if (!host)
        return false;
    if (host === "localhost" || host.endsWith(".localhost"))
        return true;
    if (host.endsWith(".local"))
        return true;
    if (host === "::1")
        return true;
    if (host.startsWith("fe80:"))
        return true;
    const parts = host.split(".");
    if (parts.length !== 4)
        return false;
    const octets = parts.map((p) => Number(p));
    if (!octets.every((n) => Number.isInteger(n) && n >= 0 && n <= 255)) {
        return false;
    }
    const [a, b] = octets;
    if (a === 10)
        return true;
    if (a === 127)
        return true;
    if (a === 169 && b === 254)
        return true;
    if (a === 172 && b >= 16 && b <= 31)
        return true;
    if (a === 192 && b === 168)
        return true;
    if (a === 100 && b >= 64 && b <= 127)
        return true;
    return false;
}
