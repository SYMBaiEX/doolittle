import { sendJsonError } from "@elizaos/host";
import { getHttpRuntime } from "@elizaos/host/protocol";
import { matchPluginRoutePath } from "../plugin-route-path.js";
import { findProtectedNamespace, findRouteModeRule, } from "./route-mode-matrix.js";
import { getRuntimeModeSnapshot, } from "./runtime-mode.js";
function isRuntimeModeList(value) {
    return (Array.isArray(value) &&
        value.every((mode) => mode === "local" ||
            mode === "local-only" ||
            mode === "cloud" ||
            mode === "remote"));
}
export function findRegisteredRouteModeRule(args) {
    const method = args.method.toUpperCase();
    const routes = args.runtime ? getHttpRuntime(args.runtime).routes : undefined;
    if (!routes)
        return null;
    for (const route of routes) {
        if (route.type === "STATIC" || route.type !== method)
            continue;
        if (!isRuntimeModeList(route.modes) || route.modes.length === 0)
            continue;
        if (matchPluginRoutePath(route.path, args.pathname) === null)
            continue;
        return {
            path: route.path,
            method: route.type,
            modes: route.modes,
            reason: route.modeReason ?? "runtime route visibility declaration",
        };
    }
    return null;
}
/**
 * Pure decision core: given the resolved runtime mode and request, decide
 * whether the mode gate hides the route. Exported so the fail-closed drift
 * logic (arch-audit #12633) can be unit-tested without stubbing the
 * disk-backed mode snapshot.
 *
 * Returns `{ hidden: true }` when the caller must respond 404 (hidden), or
 * `{ hidden: false }` to pass through to the handler chain.
 */
export function evaluateRouteModeGate(args) {
    const method = args.method.toUpperCase();
    const rule = findRegisteredRouteModeRule({
        runtime: args.runtime,
        pathname: args.pathname,
        method,
    }) ?? findRouteModeRule(args.pathname, method);
    if (rule) {
        return { hidden: !rule.modes.includes(args.mode) };
    }
    // No explicit rule (neither handler-declared nor static matrix). Fail
    // CLOSED when the path sits inside an owner-declared mode-sensitive
    // namespace: a forgotten sub-route under a gated prefix must hide, never
    // leak in every mode (arch-audit #12633). Everything outside a protected
    // namespace default-allows — the matrix is a targeted gate, not an ACL.
    return { hidden: findProtectedNamespace(args.pathname) !== null };
}
export function applyRouteModeGuard(req, res, runtime, snapshot = getRuntimeModeSnapshot()) {
    const url = new URL(req.url ?? "/", "http://localhost");
    const method = (req.method ?? "GET").toUpperCase();
    const { hidden } = evaluateRouteModeGate({
        pathname: url.pathname,
        method,
        mode: snapshot.mode,
        runtime,
    });
    if (hidden) {
        // Hidden — not forbidden. Don't include the mode or rule reason in the
        // body; cloud mode must not be able to probe local-inference state.
        sendJsonError(res, "Not found", 404);
        return { handled: true, mode: snapshot.mode };
    }
    return { handled: false, mode: snapshot.mode };
}
