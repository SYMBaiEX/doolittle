/**
 * Route-level mode guard.
 *
 * Runs BEFORE handler logic. If the active runtime mode is not in the
 * route's matrix entry, responds with 404 (hidden, not 403 — we do not
 * want cloud mode to be probeable for local-inference state) and returns
 * `true` so the dispatcher stops walking handlers.
 *
 * Config-load failures propagate to the runtime error handler.
 */
import type http from "node:http";
import { type Route } from "@elizaos/host/protocol";
import { type RuntimeMode, type RuntimeModeSnapshot } from "./runtime-mode.js";
export interface ModeGateOutcome {
    /** True when the dispatcher should stop — guard wrote a 404. */
    handled: boolean;
    /** The active runtime mode at gate time. */
    mode: RuntimeMode;
}
export interface RuntimeRouteModeRule {
    path: string;
    method: Route["type"];
    modes: ReadonlyArray<RuntimeMode>;
    reason: string;
}
export type RouteModeRuntimeLike = object;
export declare function findRegisteredRouteModeRule(args: {
    runtime?: RouteModeRuntimeLike | null;
    pathname: string;
    method: string;
}): RuntimeRouteModeRule | null;
/**
 * Pure decision core: given the resolved runtime mode and request, decide
 * whether the mode gate hides the route. Exported so the fail-closed drift
 * logic (arch-audit #12633) can be unit-tested without stubbing the
 * disk-backed mode snapshot.
 *
 * Returns `{ hidden: true }` when the caller must respond 404 (hidden), or
 * `{ hidden: false }` to pass through to the handler chain.
 */
export declare function evaluateRouteModeGate(args: {
    pathname: string;
    method: string;
    mode: RuntimeMode;
    runtime?: RouteModeRuntimeLike | null;
}): {
    hidden: boolean;
};
export declare function applyRouteModeGuard(req: http.IncomingMessage, res: http.ServerResponse, runtime?: RouteModeRuntimeLike | null, snapshot?: RuntimeModeSnapshot): ModeGateOutcome;
