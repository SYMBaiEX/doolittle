/**
 * Inbox routes.
 *
 * Exposes a time-ordered view of messages from every channel the agent
 * participates in and an authenticated reply boundary for connector chats.
 * Dashboard web chat plus every connector plugin (iMessage, Telegram, Discord,
 * WhatsApp, WeChat, etc.) are merged into a single feed so the UI can render an
 * inbox without knowing which rooms each source uses.
 *
 * Why a separate endpoint instead of reusing /api/conversations/:id/messages:
 *
 *   Each connector plugin creates its own rooms keyed by the external
 *   chat id (chat.db chat_identifier for iMessage, chat_id for Telegram,
 *   etc.). The dashboard conversation room is pinned to
 *   `${agentName}-web-chat-room`. A single-room read path can't see
 *   cross-channel traffic, and we don't want to fan out writes to the
 *   web-chat room on every connector dispatch (it would pollute the
 *   dashboard world with entities that don't belong to it and break
 *   the "one conversation = one room" invariant that bootstrap relies
 *   on). The read-side aggregator keeps each connector's world/room
 *   graph intact while still giving the UI a combined feed.
 *
 * Routes:
 *
 *   GET /api/inbox/messages?limit=N&sources=imessage,telegram
 *     Returns the N most recent messages across all agent rooms where
 *     `content.source` is set to a connector tag. `sources` (optional,
 *     comma-separated) filters to a specific subset. Ordered newest
 *     first. Default limit is 100, hard cap 500.
 *
 *   GET /api/inbox/sources
 *     Returns the distinct set of source tags the agent currently has
 *     memories for, so the UI can render a dynamic source filter chip
 *     list without hardcoding connector names.
 *
 *   POST /api/inbox/messages
 *     Sends a reply through a validated connector account. The optional
 *     top-level accountId is promoted into TargetInfo only after server-owned
 *     account policy validation.
 */
import type http from "node:http";
import { type AgentRuntime, type RoleGateRole } from "@elizaos/core";
import type { RouteHelpers } from "@elizaos/host/protocol";
export interface InboxRouteState {
    runtime: AgentRuntime | null;
    callerAuthorization?: InboxRouteCallerAuthorization;
}
export interface InboxRouteCallerAuthorization {
    ok: boolean;
    role: RoleGateRole;
    identityId?: string;
    principal?: string;
}
/**
 * Hard ceiling on the entries a single Discord profile cache may retain.
 *
 * `readCachedValue` is the only place an entry is ever dropped, and it only
 * drops one when that exact key is read back after expiry. That is fine for the
 * room cache (keyed by channel id) and the user cache (keyed by Discord user
 * id), but `discordMessageAuthorProfileCache` is keyed by Discord message id: a
 * key is re-read only while its message is still inside the window
 * `GET /api/inbox/messages` returns. Once the message scrolls out, its entry is
 * unreachable, and past the TTL it is unservable too — yet it stayed resident
 * for the whole life of the agent process, one permanent entry per Discord
 * message the inbox had ever rendered. Sweeping on write bounds every cache
 * regardless of message volume.
 *
 * The ceiling sits well above the 500-row hard cap of one inbox page, so a full
 * page still round-trips entirely from cache.
 */
export declare const MAX_DISCORD_PROFILE_CACHE_ENTRIES = 2048;
/**
 * Route handler entry point. Returns `true` when a route matched and
 * the response has been written; `false` so the caller can continue
 * trying other handlers. Mirrors the handleIMessageRoute pattern.
 */
export declare function handleInboxRoute(req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: InboxRouteState, helpers: RouteHelpers): Promise<boolean>;
