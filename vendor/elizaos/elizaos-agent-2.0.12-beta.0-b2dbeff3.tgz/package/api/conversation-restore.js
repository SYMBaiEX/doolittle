/**
 * Restore the in-memory web-chat conversation list from database truth.
 *
 * Each web-chat conversation is a room whose `channelId` is
 * `web-conv-{conversationId}`. On boot (or any "relaunch") the server has no
 * in-memory conversation list, so it rebuilds it from those rooms among the
 * agent's client-chat rooms (`getClientChatRooms`), reconstructing each
 * `ConversationMeta` from the persisted room — this is the server-truth
 * source the client thread re-renders from after an app relaunch.
 *
 * Extracted from `server.ts` (was an un-exported boot closure) so the relaunch
 * round-trip can be driven against a real database in tests (#13689): a sent
 * message must survive an app relaunch because it is read back from here, not
 * from optimistic client state. Callers run this as a background boot task and
 * decide how to surface failures at that boundary.
 */
import { getClientChatRooms, MESSAGE_SOURCE_CLIENT_CHAT, stringToUuid, } from "@elizaos/core";
import { extractConversationMetadataFromRoom } from "./conversation-metadata.js";
/** The `channelId` prefix that marks a room as a web-chat conversation. */
export const WEB_CONVERSATION_CHANNEL_PREFIX = "web-conv-";
/**
 * Scan the agent's web-chat rooms and rebuild any not-yet-loaded, not-deleted
 * conversations from them. Returns the number restored.
 */
export async function restoreConversationsFromDb(rt, target) {
    const { conversations, deletedConversationIds, log } = target;
    const rooms = await getClientChatRooms(rt);
    if (!rooms.length)
        return 0;
    let restored = 0;
    for (const room of rooms) {
        // channelId is "web-conv-{uuid}" — extract the conversation id
        const channelId = typeof room.channelId === "string" ? room.channelId : "";
        if (!channelId.startsWith(WEB_CONVERSATION_CHANNEL_PREFIX))
            continue;
        const convId = channelId.replace(WEB_CONVERSATION_CHANNEL_PREFIX, "");
        if (!convId || conversations.has(convId))
            continue;
        if (deletedConversationIds.has(convId))
            continue;
        const conv = await conversationMetaFromRoom(rt, room, convId);
        // A delete or another restore can land while the room is read back.
        if (deletedConversationIds.has(convId) || conversations.has(convId))
            continue;
        conversations.set(convId, conv);
        restored++;
    }
    if (restored > 0) {
        log?.(`Restored ${restored} conversation(s) from database`);
    }
    return restored;
}
async function conversationMetaFromRoom(rt, room, convId) {
    const msgs = await rt.getMemories({
        roomId: room.id,
        tableName: "messages",
        limit: 1,
    });
    const updatedAt = msgs.length > 0 && msgs[0].createdAt
        ? new Date(msgs[0].createdAt).toISOString()
        : new Date().toISOString();
    const conversationMetadata = await extractConversationMetadataFromRoom(room, convId);
    return {
        id: convId,
        title: room.name || "Chat",
        roomId: room.id,
        ...(conversationMetadata ? { metadata: conversationMetadata } : {}),
        createdAt: updatedAt,
        updatedAt,
    };
}
export async function restoreConversationFromDb(rt, target, convId) {
    const existing = target.conversations.get(convId);
    if (existing)
        return existing;
    if (target.deletedConversationIds.has(convId))
        return undefined;
    const room = await rt.getRoom(stringToUuid(`${WEB_CONVERSATION_CHANNEL_PREFIX}${convId}`));
    if (!room ||
        room.source !== MESSAGE_SOURCE_CLIENT_CHAT ||
        room.channelId !== `${WEB_CONVERSATION_CHANNEL_PREFIX}${convId}`) {
        return undefined;
    }
    const conv = await conversationMetaFromRoom(rt, room, convId);
    // Re-check after the reads: a DELETE tombstones the id meanwhile, and a
    // concurrent restore of the same id must share one registered object.
    if (target.deletedConversationIds.has(convId))
        return undefined;
    const registered = target.conversations.get(convId);
    if (registered)
        return registered;
    target.conversations.set(convId, conv);
    return conv;
}
