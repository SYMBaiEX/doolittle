/**
 * Conversation-metadata sanitization and room-persistence helpers. The
 * untrusted-input boundary is `sanitizeConversationMetadata`, which allowlists
 * the conversation `scope` and `automationType`, coerces id/name fields through
 * a non-empty-string guard, validates the waifu-chat owner wallet as a 0x
 * address, and drops everything else — so a client cannot smuggle an unknown
 * scope or a non-string id into the conversation system. The remaining helpers
 * fold sanitized metadata into a room's `webConversation` record, read it back
 * out (optionally pinned to a conversation id), and classify a scope as
 * automation- or page-scoped.
 */
import type { ConversationMetadata } from "@elizaos/contracts";
import { type JsonValue, type Room } from "@elizaos/core";
import type { ConversationMeta } from "./server-types.js";
type RoomMetadataRecord = Record<string, JsonValue>;
export declare function sanitizeConversationMetadata(value: unknown): ConversationMetadata | undefined;
export declare function buildConversationRoomMetadata(conversation: Pick<ConversationMeta, "id" | "metadata">, ownerId: string, existingMetadata?: unknown): RoomMetadataRecord;
export declare function extractConversationMetadataFromRoom(room: Pick<Room, "metadata"> | null | undefined, expectedConversationId?: string): ConversationMetadata | undefined;
export declare function isAutomationConversationMetadata(metadata: ConversationMetadata | null | undefined): boolean;
export declare function isPageScopedConversationMetadata(metadata: ConversationMetadata | null | undefined): boolean;
export {};
