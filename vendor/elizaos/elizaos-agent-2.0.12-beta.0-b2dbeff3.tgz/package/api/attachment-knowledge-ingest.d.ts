/**
 * Attachment → knowledge ingest pipeline (#13593, knowledge slice 1).
 *
 * When a chat message with attachments is persisted, each attachment whose
 * bytes already live in the content-addressed media store is mirrored into the
 * documents/knowledge store as a searchable knowledge record, tagged by room,
 * sender, sender role, and media format, and linked back to the sha256 bytes
 * via `metadata.mediaUrl/mediaHash/mediaFileName` (the existing "knowledge
 * record points at media" pattern — no second store, no new tables per #8876).
 *
 * **Scope-by-source-trust (spill guard):** the visibility scope is derived from
 * the SOURCE ROOM's trust, never from an arbitrary caller. An owner/DM chat →
 * `owner-private`; a public/community room (Discord, groups, feeds) →
 * `user-private` scoped to the sender. This is the WRITE-boundary wall that
 * keeps owner-only knowledge from ever being written into a public-room-visible
 * scope; `canReadDocumentMemory` in the documents routes is the second (read)
 * wall.
 *
 * The pure derivations (`mediaFormatFromMimeType`, `resolveIngestScope`) are
 * exported for unit testing; `registerAttachmentKnowledgeIngestHook` wires the
 * pipeline into the runtime via an `after_memory_persisted` hook filtered to
 * the `messages` table.
 */
import type { IAgentRuntime, Memory, UUID } from "@elizaos/core";
import { type ChannelType, ContentType } from "@elizaos/core";
/**
 * Coarse media-format tag derived from an attachment's IANA mime type at read
 * time (#8876: derive format from mimeType, do not persist a new enum). Used
 * both as a knowledge tag (`attachment` + `<format>`) and as the searchable
 * `mediaFormat` facet.
 */
export type MediaFormat = "image" | "audio" | "video" | "pdf" | "text" | "transcript" | "file";
/** The tag every ingested chat attachment carries so it is filterable. */
export declare const ATTACHMENT_DOCUMENT_TAG = "attachment";
/** Tag prefix namespacing the media-format facet on knowledge records. */
export declare const MEDIA_FORMAT_TAG_PREFIX = "media-format:";
/**
 * Derive the coarse media-format tag from an attachment mime type (and its
 * coarse `ContentType` as a fallback signal). PDFs get their own facet since
 * they are the dominant "document" subtype users search for by format; other
 * documents fall back to `text` (text-backed) or `file` (opaque binary).
 */
export declare function mediaFormatFromMimeType(mimeType: string | undefined, contentType?: ContentType | string): MediaFormat;
/** Build the ordered knowledge tag set for an ingested attachment. */
export declare function attachmentKnowledgeTags(format: MediaFormat): string[];
/**
 * Room trust classification used by the spill guard. A DM / SELF / VOICE_DM /
 * API room is a "private" surface (owner's own chat); everything else (GROUP,
 * FORUM, FEED, THREAD, WORLD, …) is a "public"/community surface that must not
 * receive owner-private or global writes.
 *
 * Delegates to the canonical classifier in `document-access.ts` so the ingest
 * spill guard, the send wall, and the active-room surfacing wall can never drift
 * (a channel type omitted from one list but not another silently opened a hole).
 * Re-exported here to keep the existing ingest import surface stable.
 */
export declare function roomIsPrivateSurface(channelType: ChannelType | string | undefined): boolean;
export interface IngestScopeDecision {
    scope: "owner-private" | "user-private";
    /** Set only for `user-private`; the sender the item is scoped to. */
    scopedToEntityId?: UUID;
}
/**
 * Scope-by-source-trust: derive the write scope from the SOURCE room's trust
 * plus whether the sender is the owner. Owner/DM chat → `owner-private`; a
 * public/community room → `user-private` scoped to the sender. NEVER returns
 * `global`/`agent-private` and NEVER returns `owner-private` for a public room,
 * so owner-only knowledge cannot spill into a public-room-visible scope at the
 * write boundary.
 */
export declare function resolveIngestScope(params: {
    channelType: ChannelType | string | undefined;
    senderIsOwner: boolean;
    senderEntityId: UUID;
}): IngestScopeDecision;
/** Minimal document-service surface this pipeline depends on. */
export interface AttachmentIngestDocumentService {
    addDocument(options: {
        agentId?: UUID;
        worldId: UUID;
        roomId: UUID;
        entityId: UUID;
        clientDocumentId: UUID;
        contentType: string;
        originalFilename: string;
        content: string;
        metadata?: Record<string, unknown>;
        scope?: "global" | "owner-private" | "user-private" | "agent-private";
        scopedToEntityId?: UUID;
        addedBy?: UUID;
        addedByRole?: "OWNER" | "ADMIN" | "USER" | "AGENT" | "RUNTIME";
        addedFrom?: string;
    }): Promise<{
        clientDocumentId: string;
        storedDocumentMemoryId: UUID;
        fragmentCount: number;
    }>;
}
export interface IngestAttachmentDeps {
    runtime: IAgentRuntime;
    documents: AttachmentIngestDocumentService;
}
export interface IngestAttachmentResult {
    documentId: UUID;
    mediaFileName: string;
    format: MediaFormat;
    scope: IngestScopeDecision["scope"];
}
/**
 * Ingest every stored attachment on a persisted message as a knowledge record.
 * Returns one result per successfully ingested attachment. Attachments whose
 * bytes are not in the content-addressed store (e.g. unrehosted remote links)
 * are skipped — only durable, servable bytes become knowledge. Any individual
 * ingest failure throws a typed `ElizaError` (fail fast) so an attachment can
 * never silently vanish from knowledge; the caller (pipeline hook) reports it.
 */
export declare function ingestMessageAttachmentsAsKnowledge(deps: IngestAttachmentDeps, message: Memory): Promise<IngestAttachmentResult[]>;
/**
 * Register the attachment→knowledge ingest pipeline. Runs on
 * `after_memory_persisted` for the `messages` table only: after a user message
 * with attachments commits, its store-backed attachments are mirrored into the
 * knowledge store with room/sender/role/media-format tags and a
 * source-trust-derived scope. Idempotency is provided by the documents store's
 * content-addressed id (`generateContentBasedId`): re-ingesting the same body +
 * filename returns the existing document instead of duplicating.
 */
export declare function registerAttachmentKnowledgeIngestHook(runtime: IAgentRuntime): void;
