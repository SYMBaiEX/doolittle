/**
 * Mounts POST /api/provider/switch behind the authenticated API gate. Switches
 * the agent's active model provider: validates the request, writes the provider
 * API key into the vault-backed secrets manager (so the secret never lands on
 * disk in plaintext), applies the first-run connection config, saves it, and
 * drives the switch plus runtime restart through the idempotent
 * RuntimeOperationManager — reporting accepted (202), deduped, or rejected-busy
 * (409). elizacloud is handled as a cloud-managed connection.
 */
import type http from "node:http";
import type { SecretsManager } from "@elizaos/auth/vault";
import { type ElizaConfig, type ReadJsonBodyOptions } from "@elizaos/host/protocol";
import type { RuntimeOperationManager } from "../runtime/operations/types.js";
export interface ProviderSwitchRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    state: {
        config: ElizaConfig;
    };
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    saveElizaConfig: (config: ElizaConfig) => void;
    scheduleRuntimeRestart: (reason: string) => void;
    runtimeOperationManager: RuntimeOperationManager;
    /**
     * Vault-backed secrets manager. Tests inject; production resolves to the
     * OS-keychain default. The route writes the API key here BEFORE
     * constructing the intent so the secret never lands on disk in plaintext
     * inside an operation record.
     */
    secretsManager?: SecretsManager;
}
export declare function handleProviderSwitchRoutes(ctx: ProviderSwitchRouteContext): Promise<boolean>;
