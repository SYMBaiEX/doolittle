/**
 * Grab-bag of local control-API endpoints too small for their own module:
 * process restart (POST /api/restart), the share-sheet ingest queue
 * (POST | GET /api/ingest/share), agent event-stream ingestion into the WS
 * broadcast buffer (POST /api/agent/event and the per-agent
 * /api/agents/:id/event variant), coarse IP-based coordinates for the weather
 * widget's no-permission fallback (GET /api/location/approximate), authorized
 * single-line terminal command execution (POST /api/terminal/run), and
 * custom-action CRUD + NL generation + test (/api/custom-actions...). Terminal
 * runs and shell/code custom actions sit behind the local-code-execution gate
 * and terminal-authorization checks.
 */
import type http from "node:http";
import { type ReadJsonBodyOptions } from "@elizaos/host/protocol";
import type { ServerState } from "./server-types.js";
type TerminalRunRequestBody = {
    command?: string;
    clientId?: unknown;
    terminalToken?: string;
};
type MiscRouteState = Pick<ServerState, "config" | "runtime" | "agentState" | "agentName" | "shellEnabled" | "broadcastWs" | "broadcastWsToClientId" | "nextEventId" | "eventBuffer" | "shareIngestQueue" | "startup" | "broadcastStatus" | "pendingRestartReasons">;
export interface ApproximateLocation {
    lat: number;
    lon: number;
    accuracyMeters: number;
    source: string;
}
/** Exported for tests: drop the module-level cache between cases. */
export declare function resetIpGeoCacheForTests(): void;
declare function resolveTerminalShellCommand(): {
    command: string;
    argsFor: (command: string) => string[];
};
export interface MiscRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    state: MiscRouteState;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    AGENT_EVENT_ALLOWED_STREAMS: Set<string>;
    resolveTerminalRunRejection: (req: http.IncomingMessage, body: TerminalRunRequestBody) => {
        reason: string;
        status: number;
    } | null;
    resolveTerminalRunClientId: (req: http.IncomingMessage, body: TerminalRunRequestBody) => string | null;
    isSharedTerminalClientId: (clientId: string) => boolean;
    activeTerminalRunCount: number;
    setActiveTerminalRunCount: (delta: number) => void;
    /**
     * Atomically reserves one process-wide terminal slot. Production supplies
     * this instead of relying on the count snapshot captured before body parsing.
     */
    tryAcquireTerminalRunSlot?: (scopeId: string, runId: string, maxConcurrent: number) => {
        release: () => void;
    } | {
        rejection: "capacity" | "duplicate" | "registry-capacity";
    };
    /** Test seam for failures before the shell process can be launched. */
    resolveTerminalShellCommand?: typeof resolveTerminalShellCommand;
}
export declare function handleMiscRoutes(ctx: MiscRouteContext): Promise<boolean>;
export {};
