/**
 * Total-order comparators used by the conversation HTTP routes to order
 * conversation summaries and message memories.
 *
 * Timestamps reaching these comparators come from persisted rows and untrusted
 * PATCH payloads, so a malformed `updatedAt` string or a non-numeric
 * `createdAt` can produce `NaN`. A comparator that returns `NaN` makes
 * `Array.prototype.sort` implementation-defined, which surfaces as an unstable
 * conversation list. Both comparators therefore coerce a non-finite timestamp
 * to `0` and break the resulting tie on id so the order stays deterministic.
 */
/** Conversation summary fields the recency comparator depends on. */
export interface ConversationSortInput {
    id: string;
    updatedAt: string;
}
/** Message-memory fields the createdAt comparator depends on. */
export interface MemorySortInput {
    id?: string;
    createdAt?: number;
}
/**
 * Orders conversations newest-updated first. An unparseable `updatedAt` sorts
 * as epoch 0 (oldest) rather than poisoning the comparison with `NaN`.
 */
export declare function compareConversationsByRecency(a: ConversationSortInput, b: ConversationSortInput): number;
/**
 * Orders message memories oldest-created first, treating a missing or
 * non-finite `createdAt` as epoch 0 and tie-breaking on UUID order. Locale
 * string compare disagrees with the store for mixed-case ids, so a
 * same-millisecond burst rendered in a different order than it was stored.
 */
export declare function compareMemoriesByCreatedAt(a: MemorySortInput, b: MemorySortInput): number;
