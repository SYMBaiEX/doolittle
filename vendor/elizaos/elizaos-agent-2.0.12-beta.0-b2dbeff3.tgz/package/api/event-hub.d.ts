/**
 * Buffers versioned server events and targets serialized payloads to connected
 * WebSocket clients. HTTP composition supplies connection ownership maps while
 * route and runtime code consume this small event boundary.
 *
 * Fan-out is bounded per peer without ever skipping a frame on a live socket:
 * a peer keeps receiving every message until it is terminated. Crossing the
 * soft limit only starts a stall clock; the peer is terminated once it stays
 * above the soft limit for the grace period or crosses the hard limit, so its
 * queue is bounded by the hard limit or by the soft limit plus one grace
 * window of traffic, whichever comes first. Loss therefore happens only
 * through termination, which the client observes and recovers from by
 * reconnecting and replaying from the buffer. The liveness sweep pings every
 * tracked socket on an interval and terminates the ones that did not answer,
 * which covers peers that stall without traffic.
 */
import { type StreamEventEnvelope } from "@elizaos/core";
export interface EventSocket {
    readonly readyState: number;
    /** Bytes queued on the transport that the peer has not yet acknowledged. */
    readonly bufferedAmount: number;
    send(message: string): void;
    /** Destroy the transport immediately without a close handshake. */
    terminate(): void;
}
export interface EventHubState {
    eventBuffer: StreamEventEnvelope[];
    nextEventId: number;
}
export interface ApiEventHub {
    broadcast(payload: unknown): void;
    publish(event: Omit<StreamEventEnvelope, "eventId" | "version" | "bufferSeq">): void;
    sendToClient(clientId: string, payload: unknown): number;
    sendToConversation(conversationId: string, payload: unknown): number;
}
/**
 * Agent-event streams that are delivered live and never buffered: they skip
 * the replay buffer (and so diagnostics and reconnect replay) and are not
 * routed into conversations. `voice-transcript` carries interim ASR text
 * (`@elizaos/plugin-local-inference` live-transcript-events), which must not
 * outlive the moment.
 */
export declare const EPHEMERAL_AGENT_EVENT_STREAMS: ReadonlySet<string>;
/**
 * Envelope for an ephemeral agent event. Same shape as a buffered
 * `agent_event`, with `ephemeral: true` and an `eph-<n>` id that is not a
 * replay cursor (no `bufferSeq`).
 */
export declare function buildEphemeralAgentEventEnvelope(event: Omit<StreamEventEnvelope, "eventId" | "version" | "bufferSeq">): StreamEventEnvelope & {
    ephemeral: true;
};
/** Queued bytes above which a peer's grace period starts counting down. */
export declare const EVENT_SOCKET_BACKPRESSURE_SOFT_LIMIT_BYTES: number;
/** Queued bytes above which a peer is terminated on sight. */
export declare const EVENT_SOCKET_BACKPRESSURE_HARD_LIMIT_BYTES: number;
/** How long a peer may stay above the soft limit before it is terminated. */
export declare const EVENT_SOCKET_BACKPRESSURE_GRACE_MS = 10000;
export interface EventSocketBackpressure {
    softLimitBytes: number;
    hardLimitBytes: number;
    graceMs: number;
}
export interface EventSocketBackpressureGuard<Socket extends EventSocket> {
    /** True when the peer remains eligible to receive the next frame. */
    admit(socket: Socket): boolean;
}
export declare function createEventSocketBackpressureGuard<Socket extends EventSocket>(options: {
    clients: Set<Socket>;
    clientIds: WeakMap<Socket, string>;
    reportSendError(error: unknown): void;
    backpressure?: Partial<EventSocketBackpressure>;
    /** Includes bytes waiting outside the transport, such as admission queues. */
    getBufferedAmount?: (socket: Socket) => number;
    /** Clock used for the grace period; injectable for deterministic tests. */
    now?: () => number;
}): EventSocketBackpressureGuard<Socket>;
export declare function createApiEventHub<Socket extends EventSocket>(options: {
    state: EventHubState;
    clients: Set<Socket>;
    clientIds: WeakMap<Socket, string>;
    activeConversations: WeakMap<Socket, string>;
    reportSendError(error: unknown): void;
    /** A host may queue delivery for current admission; counts mean accepted sends. */
    sendMessage?(socket: Socket, message: string): boolean;
    maxBufferedEvents?: number;
    backpressure?: Partial<EventSocketBackpressure>;
    /** Includes bytes waiting outside the transport, such as admission queues. */
    getBufferedAmount?: (socket: Socket) => number;
    /** Clock used for the grace period; injectable for deterministic tests. */
    now?: () => number;
}): ApiEventHub;
/** Interval between liveness pings; a peer has one interval to answer. */
export declare const EVENT_SOCKET_LIVENESS_INTERVAL_MS = 30000;
export interface LivenessSocket {
    readonly readyState: number;
    ping(): void;
    terminate(): void;
    on(event: "pong", listener: () => void): unknown;
    on(event: "close", listener: () => void): unknown;
}
export interface EventSocketLivenessSweep<Socket extends LivenessSocket> {
    /** Start pinging `socket`; tracking ends when it closes or is terminated. */
    track(socket: Socket): void;
    /** Number of sockets currently tracked. */
    readonly size: number;
    /** Clear the interval and forget every socket without touching them. */
    stop(): void;
}
/**
 * Periodic ping/pong sweep over tracked sockets. Each tick terminates every
 * open socket that has not answered the previous tick's ping, then pings the
 * rest. The interval is unref'd so it never holds the process open; `stop`
 * must still be called on dispose so tests and shutdown do not leak it.
 */
export declare function createEventSocketLivenessSweep<Socket extends LivenessSocket>(options: {
    clientIds: WeakMap<Socket, string>;
    intervalMs?: number;
}): EventSocketLivenessSweep<Socket>;
