import { getHttpRuntime, } from "@elizaos/host/protocol";
import { Hono } from "hono";
import { dispatchRoute } from "./dispatch-route.js";
function honoMethod(type) {
    switch (type) {
        case "GET":
            return "get";
        case "POST":
            return "post";
        case "PUT":
            return "put";
        case "PATCH":
            return "patch";
        case "DELETE":
            return "delete";
        default:
            return null;
    }
}
/**
 * Translate an elizaOS route path (which uses `:param` and `:rest*` tokens)
 * to Hono's path syntax. Hono supports `:param` directly; trailing `*` becomes
 * `:param{.+}` in Hono.
 */
function toHonoPath(path) {
    return path
        .split("/")
        .map((seg) => {
        if (seg.startsWith(":") && seg.endsWith("*")) {
            const name = seg.slice(1, -1);
            return `:${name}{.+}`;
        }
        return seg;
    })
        .join("/");
}
async function readBodyForDispatch(request, method) {
    if (method === "GET" || method === "HEAD") {
        return { body: undefined };
    }
    const contentType = request.headers.get("content-type") ?? "";
    if (contentType.includes("application/json")) {
        const text = await request.text();
        if (!text.trim()) {
            return { body: undefined, rawBody: text };
        }
        try {
            return { body: JSON.parse(text), rawBody: text };
        }
        catch {
            return { body: text, rawBody: text };
        }
    }
    const text = await request.text();
    return { body: text, rawBody: text };
}
function headersToRecord(headers) {
    const out = {};
    headers.forEach((value, key) => {
        out[key.toLowerCase()] = value;
    });
    return out;
}
function searchParamsToQuery(url) {
    const out = {};
    for (const key of url.searchParams.keys()) {
        const all = url.searchParams.getAll(key);
        out[key] = all.length <= 1 ? (all[0] ?? "") : all;
    }
    return out;
}
const NULL_BODY_STATUSES = new Set([204, 205, 304]);
/**
 * Mount every `runtime.routes` entry onto the given Hono app.
 *
 * Each registered handler runs the canonical {@link dispatchRoute}; that means
 * the Hono surface and the in-process IPC surface execute the exact same code
 * path against the same route table.
 */
export function mountRoutesOnHono(app, runtime, options) {
    const routes = getHttpRuntime(runtime).routes;
    for (const route of routes) {
        if (!honoMethod(route.type))
            continue;
        if (!route.handler && !route.routeHandler)
            continue;
        const honoPath = toHonoPath(route.path);
        const honoHandler = async (ctx) => {
            const request = ctx.req.raw;
            const url = new URL(request.url);
            const params = ctx.req.param();
            const { body, rawBody } = await readBodyForDispatch(request, request.method);
            const result = await dispatchRoute({
                runtime,
                signal: request.signal,
                method: request.method,
                path: url.pathname,
                headers: headersToRecord(request.headers),
                query: searchParamsToQuery(url),
                body,
                rawBody,
                inProcess: options.inProcess?.(request) ?? false,
                isAuthorized: () => options.isAuthorized(request),
                isTrustedLocal: () => options.isTrustedLocal?.(request) ?? false,
                accessContext: options.resolveAccessContext?.(request),
            }).catch((err) => ({
                status: 500,
                headers: { "content-type": "application/json; charset=utf-8" },
                body: {
                    error: err instanceof Error ? err.message : "Internal server error",
                },
            }));
            if (result === null) {
                // Should be unreachable — Hono only invokes this handler on a match.
                void params;
                return new Response("Not Found", { status: 404 });
            }
            const headers = new Headers(result.headers ?? {});
            if (result.stream) {
                const iterator = result.stream[Symbol.asyncIterator]();
                const encoder = new TextEncoder();
                const body = new ReadableStream({
                    async pull(controller) {
                        try {
                            const next = await iterator.next();
                            if (next.done)
                                controller.close();
                            else
                                controller.enqueue(typeof next.value === "string"
                                    ? encoder.encode(next.value)
                                    : next.value);
                        }
                        catch (error) {
                            // error-policy:J2 Preserve producer failure in the response body stream.
                            controller.error(error);
                        }
                    },
                    async cancel() {
                        await iterator.return?.();
                    },
                });
                return new Response(body, { status: result.status, headers });
            }
            let bodyOut = null;
            // The Fetch Response constructor throws for a body on a null-body status.
            if (result.body == null || NULL_BODY_STATUSES.has(result.status)) {
                bodyOut = null;
            }
            else if (typeof result.body === "string") {
                bodyOut = result.body;
                if (!headers.has("content-type")) {
                    headers.set("content-type", "text/plain; charset=utf-8");
                }
            }
            else if (result.body instanceof Uint8Array) {
                bodyOut = new Uint8Array(result.body);
                if (!headers.has("content-type")) {
                    headers.set("content-type", "application/octet-stream");
                }
            }
            else {
                bodyOut = JSON.stringify(result.body);
                if (!headers.has("content-type")) {
                    headers.set("content-type", "application/json; charset=utf-8");
                }
            }
            return new Response(bodyOut, { status: result.status, headers });
        };
        switch (route.type) {
            case "GET":
                app.get(honoPath, honoHandler);
                break;
            case "POST":
                app.post(honoPath, honoHandler);
                break;
            case "PUT":
                app.put(honoPath, honoHandler);
                break;
            case "PATCH":
                app.patch(honoPath, honoHandler);
                break;
            case "DELETE":
                app.delete(honoPath, honoHandler);
                break;
        }
    }
}
/** Convenience: build a new Hono app already wired to the runtime. */
export function buildHonoAppForRuntime(runtime, options) {
    const app = new Hono();
    mountRoutesOnHono(app, runtime, options);
    return app;
}
