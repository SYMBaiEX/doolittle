/**
 * Authenticates and atomically adopts first-run paid-provider credentials into
 * the host account pool before onboarding configuration is committed.
 */
import type { LinkedAccountConfig } from "@elizaos/contracts";
export interface FirstRunDirectAccountAdoption {
    account: LinkedAccountConfig;
    rollback(): Promise<void>;
}
/** Prove and store one OpenRouter/xAI credential without writing raw config. */
export declare function adoptFirstRunDirectAccount(input: {
    providerId: "openrouter-api" | "xai-api";
    apiKey: string;
}): Promise<FirstRunDirectAccountAdoption>;
