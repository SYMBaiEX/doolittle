import { asObjectRecord as asRecord, logger, stringToUuid, } from "@elizaos/core";
import { getDirectAccountProviderForFirstRunProvider, isCloudInferenceSelectedInConfig, migrateLegacyRuntimeConfig, normalizeDeploymentTargetConfig, normalizeFirstRunCredentialInputs, normalizeLinkedAccountFlagsConfig, normalizeServiceRoutingConfig, PostFirstRunRequestSchema, prepareFirstRunConnectors, } from "@elizaos/host/protocol";
import { getCloudSecret } from "@elizaos/plugin-elizacloud/cloud-config/cloud-secrets";
import { configFileExists, loadElizaConfig } from "../config/config.js";
import { captureDevCloudEnvAuthority, restoreDevCloudEnvAuthority, } from "../config/dev-cloud-env-authority.js";
import { agentIdentityName } from "../runtime/build-character-config.js";
import { resolveDefaultAgentWorkspaceDir } from "../shared/workspace-resolution.js";
import { syncDirectProviderCredentials } from "./accounts-routes.js";
import { adoptFirstRunDirectAccount, } from "./first-run-direct-account.js";
import { applyCanonicalFirstRunConfig, applyFirstRunCredentialPersistence, } from "./provider-switch-config.js";
// ---------------------------------------------------------------------------
// Cloud container character default bootstrapping
// ---------------------------------------------------------------------------
/**
 * Cloud-provisioned containers skip first-run entirely, which means the
 * character preset (ui.presetId, ui.avatarIndex) and the matching TTS voice
 * are never written to the config file.  This helper ensures that the first
 * GET /api/first-run/status from a cloud container writes sensible defaults
 * so the frontend hydrates with the correct character and voice.
 *
 * Only runs once: subsequent requests see ui.presetId already set and bail.
 */
let _cloudDefaultsApplied = false;
function normalizeCanonicalRuntimeConfigForCurrentServer(args) {
    const llmRoute = args.serviceRouting?.llmText;
    if (args.deploymentTarget?.runtime !== "remote" ||
        args.deploymentTarget.provider !== "remote" ||
        llmRoute?.transport !== "remote" ||
        !llmRoute.backend ||
        !args.credentialInputs?.llmApiKey) {
        return {
            deploymentTarget: args.deploymentTarget,
            serviceRouting: args.serviceRouting,
        };
    }
    return {
        deploymentTarget: { runtime: "local" },
        serviceRouting: {
            ...(args.serviceRouting ?? {}),
            llmText: {
                backend: llmRoute.backend,
                transport: "direct",
                ...(llmRoute.primaryModel
                    ? { primaryModel: llmRoute.primaryModel }
                    : {}),
            },
        },
    };
}
/** The 409 text for a Cloud inference first-run on an agent with no Cloud key. */
export const CLOUD_INFERENCE_NO_API_KEY_ERROR = "Eliza Cloud inference is not available on this agent: it has no Eliza Cloud API key, so it cannot reach Cloud models. Choose another provider.";
/**
 * True when this agent holds the credential plugin-elizacloud authenticates
 * with: the linked key in config, a config env entry, the sealed login secret,
 * or the process environment. Exported for the iOS bridge, which answers
 * `POST /api/first-run` itself and must apply the same check.
 */
export function hasCloudApiKeyForInference(config) {
    const configEnv = asRecord(config.env);
    return [
        config.cloud?.apiKey,
        configEnv?.ELIZAOS_CLOUD_API_KEY,
        asRecord(configEnv?.vars)?.ELIZAOS_CLOUD_API_KEY,
        getCloudSecret("ELIZAOS_CLOUD_API_KEY"),
    ].some((value) => typeof value === "string" && value.trim().length > 0);
}
function ensureCloudContainerCharacterDefaults(ctx) {
    if (_cloudDefaultsApplied)
        return;
    let config;
    try {
        config = loadElizaConfig();
    }
    catch {
        return; // No config file yet — nothing to patch
    }
    const ui = (config.ui ?? {});
    if (ui.presetId) {
        // Already has a character preset — previous first-run or manual config
        _cloudDefaultsApplied = true;
        return;
    }
    // Resolve the default style preset for the configured language
    const language = ctx.resolveConfiguredCharacterLanguage(config, ctx.req);
    const presets = ctx.getStylePresets(language);
    const defaultPreset = presets[0];
    if (!defaultPreset) {
        _cloudDefaultsApplied = true;
        return;
    }
    // Apply the default character to config
    if (!config.ui)
        config.ui = {};
    const configUi = config.ui;
    configUi.presetId = defaultPreset.id;
    configUi.avatarIndex = defaultPreset.avatarIndex;
    if (!configUi.assistant || typeof configUi.assistant !== "object") {
        configUi.assistant = {};
    }
    const assistant = configUi.assistant;
    if (!assistant.name) {
        assistant.name = defaultPreset.name;
    }
    // Apply the matching voice preset so TTS uses the correct voice.
    // First try the standard path (requires ELEVENLABS_API_KEY for direct mode).
    ctx.applyFirstRunVoicePreset(config, { presetId: defaultPreset.id, avatarIndex: defaultPreset.avatarIndex }, language);
    // Cloud containers typically use cloud-proxy TTS without a direct API key.
    // If applyFirstRunVoicePreset bailed (no ELEVENLABS_API_KEY), write the
    // voice config anyway so resolveCharacterVoiceConfigFromAppConfig on the
    // client picks up the correct voiceId via the ui.presetId -> preset lookup.
    // The client-side voice resolver reads config.ui.presetId and maps it to the
    // character's voicePresetId, so having presetId set is sufficient.
    // Ensure serviceRouting is set for cloud inference so the cloud topology
    // resolver recognises this as a cloud-inference container and keeps the
    // ELIZAOS_CLOUD_* env vars alive (applyCloudConfigToEnv deletes them when
    // shouldLoadPlugin is false).
    const configRecord = config;
    if (!configRecord.serviceRouting) {
        configRecord.serviceRouting = {
            llmText: { backend: "elizacloud", transport: "cloud-proxy" },
            tts: { backend: "elizacloud", transport: "cloud-proxy" },
        };
    }
    // Ensure agent list has the default character's personality
    if (!config.agents || typeof config.agents !== "object") {
        config.agents = {};
    }
    const agents = config.agents;
    if (!Array.isArray(agents.list) || agents.list.length === 0) {
        agents.list = [{ id: "main", default: true }];
    }
    const agentEntry = agents.list[0];
    if (!agentEntry.name && defaultPreset.name) {
        agentEntry.name = defaultPreset.name;
    }
    if (!agentEntry.bio && defaultPreset.bio) {
        agentEntry.bio = defaultPreset.bio;
    }
    if (!agentEntry.system && defaultPreset.system) {
        agentEntry.system = defaultPreset.system;
    }
    try {
        ctx.saveElizaConfig(config);
        // Keep the live server config in step so the next full save of
        // state.config does not drop these defaults from disk.
        const live = ctx.state.config;
        const saved = config;
        for (const key of ["ui", "messages", "serviceRouting", "agents"]) {
            if (saved[key] !== undefined)
                live[key] = saved[key];
        }
        logger.info(`[first-run] Applied default character preset "${defaultPreset.id}" for cloud container`);
    }
    catch (err) {
        logger.warn(`[first-run] Failed to persist cloud container character defaults: ${err}`);
    }
    _cloudDefaultsApplied = true;
}
function restoreProcessEnvironment(snapshot, ownedSnapshot) {
    const keys = new Set([
        ...Object.keys(snapshot),
        ...Object.keys(ownedSnapshot),
    ]);
    for (const key of keys) {
        const currentPresent = Object.hasOwn(process.env, key);
        const ownedPresent = Object.hasOwn(ownedSnapshot, key);
        if (currentPresent !== ownedPresent ||
            (currentPresent && process.env[key] !== ownedSnapshot[key])) {
            continue;
        }
        const previous = snapshot[key];
        if (previous === undefined)
            delete process.env[key];
        else
            process.env[key] = previous;
    }
}
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
export async function handleFirstRunRoutes(ctx) {
    const { req, res, method, pathname, state, json, error, readJsonBody } = ctx;
    // ── GET /api/first-run/status ──────────────────────────────────────
    if (method === "GET" && pathname === "/api/first-run/status") {
        if (ctx.isCloudProvisionedContainer()) {
            // Ensure the config file has the default character preset + voice so
            // the frontend hydrates with the correct character instead of a bare
            // fallback.  This is idempotent and only writes once.
            ensureCloudContainerCharacterDefaults(ctx);
            json(res, { complete: true, cloudProvisioned: true });
            return true;
        }
        let config = state.config;
        let complete = configFileExists() && ctx.hasPersistedFirstRunState(config);
        if (!complete && configFileExists()) {
            try {
                config = loadElizaConfig();
                complete = ctx.hasPersistedFirstRunState(config);
                if (complete) {
                    state.config = config;
                }
            }
            catch (err) {
                logger.warn(`[eliza-api] Failed to refresh config for first-run status: ${err instanceof Error ? err.message : err}`);
            }
        }
        json(res, { complete });
        return true;
    }
    // ── GET /api/wallet/keys (first-run only) ─────────────────────────
    if (method === "GET" && pathname === "/api/wallet/keys") {
        if (ctx.hasPersistedFirstRunState(state.config)) {
            json(res, { error: "Wallet keys are only available during first-run" }, 403);
            return true;
        }
        logger.warn(`[eliza-api] Wallet keys requested during first-run (ip=${req.socket.remoteAddress ?? "unknown"})`);
        const walletEnvBefore = Object.fromEntries([
            "EVM_PRIVATE_KEY",
            "SOLANA_PRIVATE_KEY",
            "SOLANA_PUBLIC_KEY",
            "WALLET_PUBLIC_KEY",
        ].map((name) => [name, process.env[name]]));
        try {
            if (await ctx.ensureWalletKeysInEnvAndConfig(state.config)) {
                ctx.saveElizaConfig(state.config);
            }
        }
        catch (err) {
            for (const [name, value] of Object.entries(walletEnvBefore)) {
                if (value === undefined)
                    delete process.env[name];
                else
                    process.env[name] = value;
            }
            logger.error(`[eliza-api] Failed to persist first-run wallet keys: ${err}`);
            json(res, { error: "Failed to persist wallet keys" }, 500);
            return true;
        }
        const evmPrivateKey = process.env.EVM_PRIVATE_KEY ?? "";
        const solanaPrivateKey = process.env.SOLANA_PRIVATE_KEY ?? "";
        const addresses = ctx.getWalletAddresses();
        const maskKey = (key) => {
            if (!key || key.length <= 4)
                return key ? "****" : "";
            return `****${key.slice(-4)}`;
        };
        json(res, {
            evmPrivateKey: maskKey(evmPrivateKey),
            evmAddress: addresses.evmAddress ?? "",
            solanaPrivateKey: maskKey(solanaPrivateKey),
            solanaAddress: addresses.solanaAddress ?? "",
        });
        return true;
    }
    // ── GET /api/first-run/options ─────────────────────────────────────
    if (method === "GET" && pathname === "/api/first-run/options") {
        json(res, {
            names: ctx.pickRandomNames(5),
            styles: ctx.getStylePresets(ctx.resolveConfiguredCharacterLanguage(state.config, req)),
            providers: ctx.getProviderOptions(),
            cloudProviders: ctx.getCloudProviderOptions(),
            models: ctx.getModelOptions(),
            inventoryProviders: ctx.getInventoryProviderOptions(),
            sharedStyleRules: "Keep responses brief. Be helpful and concise.",
            githubOAuthAvailable: Boolean(process.env.GITHUB_OAUTH_CLIENT_ID?.trim()),
        });
        return true;
    }
    // ── POST /api/first-run ────────────────────────────────────────────
    if (method === "POST" && pathname === "/api/first-run") {
        const devCloudSnapshot = captureDevCloudEnvAuthority();
        const rawFirstRun = await readJsonBody(req, res);
        if (rawFirstRun === null)
            return true;
        const parsedFirstRun = PostFirstRunRequestSchema.safeParse(rawFirstRun);
        if (!parsedFirstRun.success) {
            error(res, parsedFirstRun.error.issues[0]?.message ?? "Invalid request body", 400);
            return true;
        }
        const body = parsedFirstRun.data;
        let config = state.config;
        try {
            config = loadElizaConfig();
        }
        catch (err) {
            logger.warn(`[eliza-api] Failed to reload config before first-run: ${err instanceof Error ? err.message : String(err)}`);
        }
        // Build first-run against an isolated config snapshot. The live server
        // state remains authoritative until the config file has actually committed.
        config = structuredClone(config);
        const preCommitEnvironment = { ...process.env };
        const connectorPreparation = prepareFirstRunConnectors(config, body);
        if (!connectorPreparation.ok) {
            error(res, connectorPreparation.error, 400);
            return true;
        }
        const configuredLanguage = ctx.normalizeCharacterLanguage(body.language ??
            ctx.readUiLanguageHeader(req) ??
            config.ui?.language);
        if (!config.agents)
            config.agents = {};
        if (!config.agents.defaults)
            config.agents.defaults = {};
        config.agents.defaults.workspace = resolveDefaultAgentWorkspaceDir();
        const firstRunAdminEntityId = stringToUuid(`${body.name.trim()}-admin-entity`);
        config.agents.defaults.adminEntityId = firstRunAdminEntityId;
        if (!config.agents.list)
            config.agents.list = [];
        if (config.agents.list.length === 0) {
            config.agents.list.push({ id: "main", default: true });
        }
        const agent = config.agents.list[0];
        agent.name = body.name.trim();
        // A running agent keeps its id and chat ids when first-run renames it;
        // save the name they came from so the next boot derives the same ids.
        if (state.runtime && !agent.identityName) {
            agent.identityName = agentIdentityName(state.runtime.character);
        }
        agent.workspace = resolveDefaultAgentWorkspaceDir();
        let normalizedMessageExamples;
        if (body.bio)
            agent.bio = body.bio;
        if (body.systemPrompt)
            agent.system = body.systemPrompt;
        if (body.style)
            agent.style = body.style;
        if (body.adjectives)
            agent.adjectives = body.adjectives;
        if (body.topics) {
            agent.topics = body.topics;
        }
        if (body.postExamples)
            agent.postExamples = body.postExamples;
        if (body.messageExamples) {
            const raw = body.messageExamples;
            normalizedMessageExamples = raw.map((item) => {
                if (item &&
                    typeof item === "object" &&
                    "examples" in item) {
                    return item;
                }
                const arr = item;
                return {
                    examples: arr.map((m) => ({
                        name: m.name ?? m.user ?? "",
                        content: m.content,
                    })),
                };
            });
            agent.messageExamples = normalizedMessageExamples;
        }
        if (!config.ui) {
            config.ui = {};
        }
        config.ui.assistant = {
            ...(config.ui.assistant ?? {}),
            name: agent.name,
        };
        if (typeof body.avatarIndex === "number" &&
            Number.isFinite(body.avatarIndex)) {
            config.ui.avatarIndex = Number(body.avatarIndex);
        }
        config.ui.language = configuredLanguage;
        if (typeof body.presetId === "string" && body.presetId.trim()) {
            config.ui.presetId = body.presetId.trim();
        }
        ctx.applyFirstRunVoicePreset(config, body, configuredLanguage);
        // ── Theme preference ──────────────────────────────────────────────────
        if (body.theme) {
            if (!config.ui)
                config.ui = {};
            config.ui.theme = body.theme;
        }
        const explicitDeploymentTargetRequested = Object.hasOwn(body, "deploymentTarget");
        const explicitDeploymentTarget = explicitDeploymentTargetRequested
            ? normalizeDeploymentTargetConfig(body.deploymentTarget)
            : null;
        if (explicitDeploymentTargetRequested && !explicitDeploymentTarget) {
            error(res, "Invalid deploymentTarget", 400);
            return true;
        }
        const explicitLinkedAccountsRequested = Object.hasOwn(body, "linkedAccounts");
        const explicitLinkedAccounts = explicitLinkedAccountsRequested
            ? normalizeLinkedAccountFlagsConfig(body.linkedAccounts)
            : null;
        const explicitServiceRoutingRequested = Object.hasOwn(body, "serviceRouting");
        const explicitServiceRouting = explicitServiceRoutingRequested
            ? normalizeServiceRoutingConfig(body.serviceRouting)
            : null;
        const explicitCredentialInputsRequested = Object.hasOwn(body, "credentialInputs");
        const parsedCredentialInputs = explicitCredentialInputsRequested
            ? normalizeFirstRunCredentialInputs(body.credentialInputs)
            : null;
        if (explicitCredentialInputsRequested && !parsedCredentialInputs) {
            error(res, "Invalid credentialInputs", 400);
            return true;
        }
        const explicitCredentialInputs = devCloudSnapshot && parsedCredentialInputs
            ? { ...parsedCredentialInputs, cloudApiKey: undefined }
            : parsedCredentialInputs;
        const hasCanonicalRuntimeConfig = explicitDeploymentTargetRequested ||
            explicitLinkedAccountsRequested ||
            explicitServiceRoutingRequested ||
            explicitCredentialInputsRequested;
        const normalizedCanonicalRuntimeConfig = normalizeCanonicalRuntimeConfigForCurrentServer({
            deploymentTarget: explicitDeploymentTarget,
            serviceRouting: explicitServiceRouting,
            credentialInputs: explicitCredentialInputs,
        });
        const normalizedDeploymentTarget = normalizedCanonicalRuntimeConfig.deploymentTarget;
        const normalizedServiceRouting = normalizedCanonicalRuntimeConfig.serviceRouting;
        const firstRunDirectAccountProvider = getDirectAccountProviderForFirstRunProvider(normalizedServiceRouting?.llmText?.backend);
        const firstRunAccountCredential = explicitCredentialInputs?.llmApiKey;
        let firstRunAdoption;
        // ── Sandbox mode (from first-run runtime setup: off / light / standard / max)
        const sandboxMode = body.sandboxMode || "off";
        if (sandboxMode !== "off") {
            if (!config.agents)
                config.agents = {};
            if (!config.agents.defaults)
                config.agents.defaults = {};
            if (!config.agents.defaults.sandbox) {
                config.agents.defaults.sandbox = {};
            }
            config.agents.defaults.sandbox.mode = sandboxMode;
            logger.info(`[eliza-api] Sandbox mode set to: ${sandboxMode}`);
        }
        if (hasCanonicalRuntimeConfig) {
            applyCanonicalFirstRunConfig(config, {
                deploymentTarget: normalizedDeploymentTarget,
                linkedAccounts: explicitLinkedAccounts,
                serviceRouting: normalizedServiceRouting,
                clearRoutes: explicitServiceRoutingRequested && !normalizedServiceRouting?.llmText
                    ? ["llmText"]
                    : [],
            });
            try {
                await applyFirstRunCredentialPersistence(config, {
                    credentialInputs: explicitCredentialInputs,
                    deploymentTarget: normalizedDeploymentTarget ??
                        normalizeDeploymentTargetConfig(config.deploymentTarget),
                    serviceRouting: normalizedServiceRouting ??
                        normalizeServiceRoutingConfig(config.serviceRouting),
                });
                delete process.env.ELIZAOS_CLOUD_ENABLED;
                delete process.env.ELIZAOS_CLOUD_NANO_MODEL;
                delete process.env.ELIZAOS_CLOUD_MEDIUM_MODEL;
                delete process.env.ELIZAOS_CLOUD_SMALL_MODEL;
                delete process.env.ELIZAOS_CLOUD_LARGE_MODEL;
                delete process.env.ELIZAOS_CLOUD_MEGA_MODEL;
                delete process.env.ELIZAOS_CLOUD_RESPONSE_HANDLER_MODEL;
                delete process.env.ELIZAOS_CLOUD_SHOULD_RESPOND_MODEL;
                delete process.env.ELIZAOS_CLOUD_ACTION_PLANNER_MODEL;
                delete process.env.ELIZAOS_CLOUD_PLANNER_MODEL;
                if (!isCloudInferenceSelectedInConfig(config)) {
                    delete process.env.ELIZAOS_CLOUD_API_KEY;
                }
            }
            finally {
                if (devCloudSnapshot) {
                    restoreDevCloudEnvAuthority(devCloudSnapshot);
                }
            }
            // Selecting Cloud inference is intent, not proof it can serve. A local
            // agent only reaches Cloud models with its own API key; a renderer-held
            // Cloud session (native direct sign-in) never gives it one. Saving
            // `firstRunComplete` here would report a finished setup whose first chat
            // has no text provider. A Cloud-hosted agent is provisioned with its key.
            if (explicitServiceRoutingRequested &&
                isCloudInferenceSelectedInConfig(config) &&
                normalizeDeploymentTargetConfig(config.deploymentTarget)?.runtime !==
                    "cloud" &&
                !ctx.isCloudProvisionedContainer() &&
                !hasCloudApiKeyForInference(config)) {
                restoreProcessEnvironment(preCommitEnvironment, { ...process.env });
                error(res, CLOUD_INFERENCE_NO_API_KEY_ERROR, 409);
                return true;
            }
            if (config.models && typeof config.models === "object") {
                const legacyModels = config.models;
                delete legacyModels.nano;
                delete config.models.small;
                delete legacyModels.medium;
                delete config.models.large;
                delete legacyModels.mega;
            }
        }
        if (hasCanonicalRuntimeConfig && config.agents.defaults.model) {
            delete config.agents.defaults.model.primary;
        }
        // ── GitHub token ────────────────────────────────────────────────────
        if (body.githubToken &&
            typeof body.githubToken === "string" &&
            body.githubToken.trim()) {
            if (!config.env)
                config.env = {};
            config.env.GITHUB_TOKEN =
                body.githubToken.trim();
            process.env.GITHUB_TOKEN = body.githubToken.trim();
        }
        config.connectors = connectorPreparation.connectors;
        if (Object.keys(connectorPreparation.env).length > 0) {
            config.env ??= {};
            Object.assign(config.env, connectorPreparation.env);
            Object.assign(process.env, connectorPreparation.env);
        }
        const explicitFeatures = asRecord(body.features);
        if (explicitFeatures) {
            config.features = {
                ...(asRecord(config.features) ?? {}),
                ...explicitFeatures,
            };
        }
        // ── Inventory / RPC providers ─────────────────────────────────────────
        if (Array.isArray(body.inventoryProviders)) {
            if (!config.env)
                config.env = {};
            const allInventory = ctx.getInventoryProviderOptions();
            for (const inv of body.inventoryProviders) {
                const chainDef = allInventory.find((ip) => ip.id === inv.chain);
                if (!chainDef)
                    continue;
                const rpcDef = chainDef.rpcProviders.find((rp) => rp.id === inv.rpcProvider);
                if (rpcDef?.envKey && inv.rpcApiKey) {
                    config.env[rpcDef.envKey] = inv.rpcApiKey;
                    process.env[rpcDef.envKey] = inv.rpcApiKey;
                }
            }
        }
        // ── Ensure wallet keys exist so inventory can resolve addresses ───────
        try {
            await ctx.ensureWalletKeysInEnvAndConfig(config);
        }
        catch (err) {
            restoreProcessEnvironment(preCommitEnvironment, { ...process.env });
            logger.error(`[eliza-api] Failed to persist first-run wallet keys: ${err}`);
            error(res, "Failed to persist wallet keys", 500);
            return true;
        }
        if (!config.meta) {
            config.meta = {};
        }
        config.meta.firstRunComplete = true;
        migrateLegacyRuntimeConfig(config);
        let ownedEnvironment = { ...process.env };
        if ((firstRunDirectAccountProvider === "openrouter-api" ||
            firstRunDirectAccountProvider === "xai-api") &&
            firstRunAccountCredential) {
            try {
                // Stage all fallible onboarding preparation before adopting the paid
                // credential. A rejected probe then has no account state to unwind.
                firstRunAdoption = await adoptFirstRunDirectAccount({
                    providerId: firstRunDirectAccountProvider,
                    apiKey: firstRunAccountCredential,
                });
            }
            catch (err) {
                // error-policy:J1 first-run is the HTTP boundary: an unproven paid
                // credential leaves neither config nor transaction-owned env committed.
                restoreProcessEnvironment(preCommitEnvironment, ownedEnvironment);
                const message = err instanceof Error ? err.message : String(err);
                error(res, message, 400);
                return true;
            }
        }
        if (firstRunAdoption) {
            try {
                await syncDirectProviderCredentials({ state: { ...state, config, runtime: null } }, firstRunAdoption.account.providerId);
            }
            catch (err) {
                // error-policy:J1 the account must become the live billing authority
                // before config commit; otherwise retract it and fail onboarding.
                await firstRunAdoption.rollback();
                await syncDirectProviderCredentials({ state: { ...state, runtime: null } }, firstRunAdoption.account.providerId);
                restoreProcessEnvironment(preCommitEnvironment, ownedEnvironment);
                error(res, err instanceof Error ? err.message : "Account activation failed", 500);
                return true;
            }
            ownedEnvironment = { ...process.env };
        }
        try {
            ctx.saveElizaConfig(config);
        }
        catch (err) {
            // error-policy:J6 config commit failed after account adoption; remove the
            // not-yet-authoritative account so retry starts from a clean boundary.
            await firstRunAdoption?.rollback();
            if (firstRunAdoption) {
                await syncDirectProviderCredentials({ state: { ...state, runtime: null } }, firstRunAdoption.account.providerId);
            }
            restoreProcessEnvironment(preCommitEnvironment, ownedEnvironment);
            logger.error(`[eliza-api] Failed to save config after first-run: ${err}`);
            error(res, "Failed to save configuration", 500);
            return true;
        }
        if (!configFileExists()) {
            // error-policy:J6 the save helper returned without producing its durable
            // artifact, so roll back the paired account adoption as well.
            await firstRunAdoption?.rollback();
            if (firstRunAdoption) {
                await syncDirectProviderCredentials({ state: { ...state, runtime: null } }, firstRunAdoption.account.providerId);
            }
            restoreProcessEnvironment(preCommitEnvironment, ownedEnvironment);
            logger.error(`[eliza-api] Config file does not exist after save — first-run data will be lost on restart`);
            error(res, "Configuration file was not persisted to disk", 500);
            return true;
        }
        state.config = config;
        state.agentName = body.name ?? state.agentName;
        state.adminEntityId = firstRunAdminEntityId;
        state.chatUserId = firstRunAdminEntityId;
        state.chatConnectionReady = null;
        state.chatConnectionPromise = null;
        if (firstRunAdoption && state.runtime) {
            await syncDirectProviderCredentials({ state }, firstRunAdoption.account.providerId);
        }
        if (state.runtime) {
            const runtimeCharacter = state.runtime.character;
            const agentTopics = agent.topics;
            runtimeCharacter.name = agent.name ?? runtimeCharacter.name;
            if (Array.isArray(agent.bio)) {
                runtimeCharacter.bio = [...agent.bio];
            }
            if (typeof agent.system === "string" && agent.system) {
                runtimeCharacter.system = agent.system;
            }
            if (Array.isArray(agent.adjectives)) {
                runtimeCharacter.adjectives = [...agent.adjectives];
            }
            if (Array.isArray(agentTopics)) {
                runtimeCharacter.topics = [...agentTopics];
            }
            if (agent.style) {
                runtimeCharacter.style = structuredClone(agent.style);
            }
            if (normalizedMessageExamples) {
                runtimeCharacter.messageExamples = normalizedMessageExamples;
            }
            if (Array.isArray(agent.postExamples)) {
                runtimeCharacter.postExamples = [...agent.postExamples];
            }
            try {
                const persistedAgent = await state.runtime.getAgent(state.runtime.agentId);
                await state.runtime.updateAgent(state.runtime.agentId, {
                    name: runtimeCharacter.name,
                    metadata: {
                        ...persistedAgent?.metadata,
                        character: {
                            name: runtimeCharacter.name,
                            bio: runtimeCharacter.bio,
                            system: runtimeCharacter.system,
                            adjectives: runtimeCharacter.adjectives,
                            topics: runtimeCharacter.topics,
                            style: runtimeCharacter.style,
                            messageExamples: runtimeCharacter.messageExamples,
                            postExamples: runtimeCharacter.postExamples,
                        },
                    },
                });
            }
            catch (err) {
                logger.warn(`[character-db] Failed to persist first-run character to DB: ${err instanceof Error ? err.message : err}`);
            }
        }
        const resolvedRuntime = normalizeDeploymentTargetConfig(config.deploymentTarget)?.runtime ??
            "local";
        logger.info(`[eliza-api] First run complete for agent "${body.name}" (runtime: ${resolvedRuntime})`);
        json(res, { ok: true });
        return true;
    }
    return false;
}
