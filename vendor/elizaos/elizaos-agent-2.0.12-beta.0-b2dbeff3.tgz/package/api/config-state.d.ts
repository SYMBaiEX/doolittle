/** Keeps live configuration references aligned with committed durable state. */
import type { ElizaConfig } from "@elizaos/host/protocol";
/** Replace a live config in place so references held by callers stay valid. */
export declare function replaceConfigInPlace(state: ElizaConfig, next: ElizaConfig): void;
/**
 * The API server registers its in-memory config here. Writers outside the
 * routes (chat actions, character persistence) save straight to disk; the
 * next route save writes the in-memory copy, so they must mirror into it.
 * Bind each reader to its persisted config path. Multiple servers reading the
 * same file stay aligned; independent host/config owners remain isolated.
 */
export declare function setLiveElizaConfigSource(read: () => ElizaConfig, configPath?: string): () => void;
/** Mirror a config just written with saveElizaConfig into the live copy. */
export declare function mirrorSavedConfigToLive(saved: ElizaConfig): void;
