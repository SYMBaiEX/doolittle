import { API_KEY_PREFIX_HINTS } from "@elizaos/host/protocol";
// ---------------------------------------------------------------------------
// Validation logic
// ---------------------------------------------------------------------------
/**
 * Validate a plugin's configuration.
 *
 * Checks all required parameters (from the plugin's package.json metadata)
 * and applies format-specific warnings for known API key patterns.
 *
 * @param pluginId - The plugin identifier (e.g. "anthropic", "discord")
 * @param category - Plugin category
 * @param envKey - Primary environment variable key (legacy, used as fallback)
 * @param configKeys - All known config key names for this plugin
 * @param providedConfig - Config values being set (for PUT validation)
 * @param paramDefs - Full parameter definitions with required/sensitive metadata
 */
export function validatePluginConfig(_pluginId, _category, envKey, configKeys, providedConfig, paramDefs) {
    const errors = [];
    const warnings = [];
    const allowedConfigKeys = new Set(configKeys);
    const canonicalKeyByNormalized = new Map(configKeys.map((key) => [key.trim().toUpperCase(), key]));
    if (providedConfig) {
        for (const key of Object.keys(providedConfig)) {
            if (allowedConfigKeys.has(key))
                continue;
            const canonical = canonicalKeyByNormalized.get(key.trim().toUpperCase());
            if (canonical) {
                errors.push({
                    field: key,
                    message: `${key} does not match declared config key casing; use ${canonical}`,
                });
                continue;
            }
            errors.push({
                field: key,
                message: `${key} is not a declared config key for this plugin`,
            });
        }
    }
    // ── Check all required parameters ─────────────────────────────────────
    if (paramDefs && paramDefs.length > 0) {
        for (const param of paramDefs) {
            if (!param.required)
                continue;
            // Value source: provided config > process.env > undefined
            const value = providedConfig?.[param.key] ?? process.env[param.key];
            if (!value?.trim()) {
                // Required param with a default is a warning, not an error
                if (param.default) {
                    warnings.push({
                        field: param.key,
                        message: `${param.key} is not set (will use default: ${param.default})`,
                    });
                }
                else {
                    errors.push({
                        field: param.key,
                        message: `${param.key} is required but not set`,
                    });
                }
                continue;
            }
            // Format validation for known key patterns
            const hint = API_KEY_PREFIX_HINTS[param.key];
            if (hint && !value.startsWith(hint.prefix)) {
                warnings.push({
                    field: param.key,
                    message: `${hint.label} key should start with "${hint.prefix}" — the current value may be invalid`,
                });
            }
            // Length sanity check for sensitive keys (API keys / tokens)
            if (param.sensitive && value.trim().length < 10) {
                warnings.push({
                    field: param.key,
                    message: `${param.key} looks too short (${value.trim().length} chars)`,
                });
            }
        }
    }
    else if (envKey) {
        // Fallback: no param definitions, but we know the primary env key
        const currentValue = providedConfig?.[envKey] ?? process.env[envKey];
        if (!currentValue?.trim()) {
            errors.push({
                field: envKey,
                message: `${envKey} is required but not set`,
            });
        }
        else {
            const hint = API_KEY_PREFIX_HINTS[envKey];
            if (hint && !currentValue.startsWith(hint.prefix)) {
                warnings.push({
                    field: envKey,
                    message: `${hint.label} key should start with "${hint.prefix}" — the current value may be invalid`,
                });
            }
            // Length sanity check for keys/tokens that look suspiciously short
            if (currentValue.trim().length < 10) {
                warnings.push({
                    field: envKey,
                    message: `${envKey} looks too short (${currentValue.trim().length} chars)`,
                });
            }
        }
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
// ---------------------------------------------------------------------------
// Runtime context validation
// ---------------------------------------------------------------------------
/**
 * Validate a runtime context object for null, undefined, empty, and
 * non-serializable fields.
 *
 * Used after provider + plugin resolution to detect and surface invalid
 * or malformed context early — before it reaches the agent runtime.
 *
 * @param context - The context object to validate.
 * @param maxDepth - Maximum nesting depth to inspect (default: 5).
 */
export function validateRuntimeContext(context, maxDepth = 5) {
    const nullFields = [];
    const undefinedFields = [];
    const emptyFields = [];
    const nonSerializableFields = [];
    function walk(obj, prefix, depth) {
        if (depth > maxDepth)
            return;
        for (const [key, value] of Object.entries(obj)) {
            const path = prefix ? `${prefix}.${key}` : key;
            if (value === null) {
                nullFields.push(path);
                continue;
            }
            if (value === undefined) {
                undefinedFields.push(path);
                continue;
            }
            if (typeof value === "string" && value.trim() === "") {
                emptyFields.push(path);
                continue;
            }
            // Check for non-serializable values
            if (typeof value === "function") {
                nonSerializableFields.push(path);
                continue;
            }
            if (typeof value === "symbol") {
                nonSerializableFields.push(path);
                continue;
            }
            if (typeof value === "bigint") {
                nonSerializableFields.push(path);
                continue;
            }
            // Recurse into plain objects
            if (typeof value === "object" &&
                !Array.isArray(value) &&
                !(value instanceof Date) &&
                !(value instanceof RegExp)) {
                walk(value, path, depth + 1);
            }
        }
    }
    walk(context, "", 0);
    // Check overall serialization
    let serializable = true;
    if (nonSerializableFields.length > 0) {
        serializable = false;
    }
    else {
        try {
            JSON.stringify(context);
        }
        catch {
            serializable = false;
        }
    }
    const valid = nullFields.length === 0 &&
        undefinedFields.length === 0 &&
        emptyFields.length === 0;
    return {
        valid,
        serializable,
        nullFields,
        undefinedFields,
        emptyFields,
        nonSerializableFields,
    };
}
// ---------------------------------------------------------------------------
// Plugin context debug logging
// ---------------------------------------------------------------------------
/**
 * Log the full resolved plugin/provider context for debugging.
 *
 * Prints a structured summary of all loaded plugins, providers,
 * and any validation issues detected in the context.
 *
 * @param plugins - Array of resolved plugin names.
 * @param providers - Array of resolved provider names.
 * @param context - The runtime context object to inspect.
 * @param log - Structured debug logger supplied by the host.
 */
export function debugLogResolvedContext(plugins, providers, context, log) {
    log("[eliza:debug] ══════ Resolved Plugin/Provider Context ══════");
    log(`[eliza:debug] Plugins loaded (${plugins.length}):`);
    for (const name of plugins) {
        log(`[eliza:debug]   • ${name}`);
    }
    log(`[eliza:debug] Providers loaded (${providers.length}):`);
    for (const name of providers) {
        log(`[eliza:debug]   • ${name}`);
    }
    const validation = validateRuntimeContext(context);
    if (validation.valid && validation.serializable) {
        log("[eliza:debug] Context validation: ✓ PASS (all fields valid, serializable)");
    }
    else {
        log("[eliza:debug] Context validation: ✗ ISSUES DETECTED");
        if (validation.nullFields.length > 0) {
            log(`[eliza:debug]   null fields: ${validation.nullFields.join(", ")}`);
        }
        if (validation.undefinedFields.length > 0) {
            log(`[eliza:debug]   undefined fields: ${validation.undefinedFields.join(", ")}`);
        }
        if (validation.emptyFields.length > 0) {
            log(`[eliza:debug]   empty fields: ${validation.emptyFields.join(", ")}`);
        }
        if (validation.nonSerializableFields.length > 0) {
            log(`[eliza:debug]   non-serializable fields: ${validation.nonSerializableFields.join(", ")}`);
        }
    }
    log("[eliza:debug] ══════════════════════════════════════════════");
}
