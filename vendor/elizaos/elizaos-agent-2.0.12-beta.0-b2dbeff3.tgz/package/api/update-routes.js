import { PutUpdateChannelRequestSchema } from "@elizaos/contracts";
// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------
export async function handleUpdateRoutes(ctx) {
    const { req, res, method, pathname, state, json, error, readJsonBody } = ctx;
    // ── GET /api/update/status ───────────────────────────────────────────
    if (method === "GET" && pathname === "/api/update/status") {
        const { VERSION } = await import("../runtime/version.js");
        const { resolveChannel, checkForUpdate, fetchAllChannelVersions, CHANNEL_DIST_TAGS, } = await import("../services/update-checker.js");
        const { isTrustedLocalRequest } = await import("./server-helpers-auth.js");
        const { detectInstallMethod, getUpdateActionPlan } = await import("../services/self-updater.js");
        const channel = resolveChannel(state.config.update);
        const installMethod = detectInstallMethod();
        const updatePlan = getUpdateActionPlan(installMethod, channel, {
            remoteDisplay: !isTrustedLocalRequest(req),
        });
        const [check, versions] = await Promise.all([
            checkForUpdate({ force: req.url?.includes("force=true") }),
            fetchAllChannelVersions(),
        ]);
        if (!check.cached && check.error === null && check.checkedAt) {
            // The checker persisted these to disk. Mirror them into the in-memory
            // config so later saveElizaConfig(state.config) calls keep them.
            state.config.update = {
                ...state.config.update,
                lastCheckAt: check.checkedAt,
                lastCheckVersion: check.latestVersion ?? undefined,
                lastCheckChannel: check.channel,
            };
        }
        json(res, {
            currentVersion: VERSION,
            channel,
            installMethod,
            updateAuthority: updatePlan.authority,
            nextAction: updatePlan.nextAction,
            canAutoUpdate: updatePlan.canAutoUpdate,
            canExecuteUpdate: updatePlan.canExecuteFromContext,
            remoteDisplay: updatePlan.remoteDisplay,
            updateCommand: updatePlan.command,
            updateInstructions: updatePlan.message,
            updateAvailable: check.updateAvailable,
            latestVersion: check.latestVersion,
            channels: {
                stable: versions.stable,
                beta: versions.beta,
                nightly: versions.nightly,
            },
            distTags: CHANNEL_DIST_TAGS,
            lastCheckAt: check.checkedAt ?? state.config.update?.lastCheckAt ?? null,
            error: check.error,
        });
        return true;
    }
    // ── PUT /api/update/channel ────────────────────────────────────────────
    if (method === "PUT" && pathname === "/api/update/channel") {
        const rawCh = await readJsonBody(req, res);
        if (rawCh === null)
            return true;
        const parsedCh = PutUpdateChannelRequestSchema.safeParse(rawCh);
        if (!parsedCh.success) {
            error(res, parsedCh.error.issues[0]?.message ??
                `Invalid channel. Must be stable, beta, or nightly.`);
            return true;
        }
        const ch = parsedCh.data.channel;
        state.config.update = {
            ...state.config.update,
            channel: ch,
            lastCheckAt: undefined,
            lastCheckVersion: undefined,
        };
        ctx.saveElizaConfig(state.config);
        json(res, { channel: ch });
        return true;
    }
    return false;
}
