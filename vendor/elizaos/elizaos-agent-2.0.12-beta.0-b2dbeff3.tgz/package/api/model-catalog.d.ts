export interface ModelCatalogEntry {
    id: string;
    display: string;
    /** Accepted reasoning-effort levels; empty = the model has no effort knob. */
    efforts: string[];
    defaultEffort?: string;
    roles: Array<"small" | "large" | "coding">;
    costHint?: string;
    /** false = listed by the provider but not callable via the API tier. */
    apiSupported?: boolean;
}
export interface ModelCatalog {
    providers: Record<string, ModelCatalogEntry[]>;
}
/**
 * User-approved default coding model per backend. Mirrors
 * `TASK_AGENT_DEFAULT_MODEL_PREFS` in
 * plugins/plugin-agent-orchestrator/src/services/task-agent-frameworks.ts —
 * keep the two in sync when the product default moves.
 */
export declare const CODING_MODEL_DEFAULTS: Readonly<Record<string, string>>;
export interface BuildModelCatalogOptions {
    /** Injectable file read for tests; defaults to fs.readFileSync utf-8. */
    readFile?: (filePath: string) => string;
    /** Injectable env for tests; defaults to process.env (CODEX_HOME lookup). */
    env?: NodeJS.ProcessEnv;
}
/**
 * Build the full provider→model catalog. Pure given its injected reads: the
 * only I/O is the Codex cache lookup, and callers get fresh copies so cached
 * static tables can never be mutated through a response object.
 */
export declare function buildModelCatalog(opts?: BuildModelCatalogOptions): ModelCatalog;
