/**
 * View Registry — discovers, catalogs, and resolves view bundles from plugins.
 *
 * Views are declared by plugins via `Plugin.views`. Each declaration is
 * registered here at plugin load time and assigned runtime URLs. The HTTP
 * layer (`views-routes.ts`) delegates all path resolution back to this module.
 */
import { type IAgentRuntime, type Plugin, type ViewType } from "@elizaos/core";
export type { ViewRegistryEntry } from "./view-registry-types.js";
import { type ViewInstallation } from "./view-installations.js";
import type { ViewRegistryEntry } from "./view-registry-types.js";
export { assertRuntimeViewEntry, beginViewInstallation, closeRuntimeViewRegistry, type ViewInstallation, } from "./view-installations.js";
/** Bind an imported plugin object to the package root that supplied it. */
export declare function bindPluginPackageDirectory(plugin: Plugin, pluginDir: string): void;
/**
 * Package names to probe for a plugin, in preference order. The canonical
 * `@elizaos/plugin-<name>` candidate comes BEFORE the bare short name: a
 * plugin's short name can collide with an unrelated published npm package
 * (e.g. plugin "birdclaw" vs the `birdclaw` CLI on npm), and under Bun a
 * bare-name resolve can hit that package's install cache — registering the
 * view against a directory that isn't this plugin at all.
 */
export declare function pluginPackageNameCandidates(pluginName: string): string[];
/**
 * Resolve the absolute on-disk path for a view bundle.
 * Returns `null` when the entry has no `bundlePath` or no `pluginDir`.
 */
export declare function getBundleDiskPath(entry: Pick<ViewRegistryEntry, "bundlePath" | "pluginDir">): string | null;
/**
 * Resolve the absolute on-disk path for a sandboxed frame document.
 * Returns `null` when the entry has no `framePath` or no `pluginDir`.
 */
export declare function getFrameDiskPath(entry: Pick<ViewRegistryEntry, "framePath" | "pluginDir">): string | null;
/**
 * Resolve the absolute on-disk path for a hero image.
 * Returns `null` when the entry has no `heroImagePath` or no `pluginDir`.
 * This only handles declared paths; for extension-probing see `findHeroOnDisk`.
 */
type HeroLookup = Pick<ViewRegistryEntry, "pluginDir" | "heroImagePath">;
export declare function getHeroDiskPath(entry: HeroLookup): string | null;
/**
 * Find the first existing hero image file for an entry, probing extensions
 * in preference order. Returns the absolute path and its content type, or
 * `null` when nothing is found.
 */
export declare function findHeroOnDisk(entry: HeroLookup): Promise<{
    absolutePath: string;
    contentType: string;
} | null>;
/**
 * Build a branded generated SVG fallback when no hero image is on disk. Shares
 * the exact art (frame, no-blue palette, line-icon glyph) used for the heroes
 * committed into plugins, so a view without a packaged hero still renders a
 * cohesive card instead of a placeholder. `icon` is the view's Lucide icon name,
 * used as a hint to pick the matching glyph.
 */
export declare function generateViewHeroSvg(label: string, icon?: string): string;
/**
 * Register all views declared by `plugin`. Safe to call multiple times for the
 * same plugin — subsequent calls update existing entries.
 *
 * @param plugin    - The Plugin object whose `views` array to register.
 * @param pluginDir - Absolute path to the plugin's package root. When omitted,
 *   the registry attempts to resolve it via `require.resolve`.
 * @param runtime - Runtime object that owns this installation.
 * Embedding indexing is explicit through options.indexEmbeddings.
 */
export declare function registerPluginViews(runtime: IAgentRuntime, plugin: Plugin, options?: {
    pluginDir?: string;
    indexEmbeddings?: boolean;
    installation?: ViewInstallation;
}): Promise<ViewInstallation>;
/** Retired installation handles cannot delete their replacement. */
export declare function unregisterPluginViews(runtime: IAgentRuntime, installation: ViewInstallation): void;
/**
 * Register all built-in first-party shell views.
 *
 * These views are declared in `builtin-views.ts` and live in the main shell
 * bundle — no separate bundle file is required. Called once at server startup
 * before any plugin views are registered. A built-in fallback yields only to
 * its declared package at the same id, path, and modality. Other conflicts
 * keep the existing entry. Unloading the package restores its fallback.
 *
 * Safe to call multiple times — subsequent calls have no additional effect
 * because the conflict guard in `registerPluginViews` keeps the first
 * registration.
 *
 * @param runtime - Optional agent runtime. When provided, embeddings for the
 *   built-in views are queued in the background search index.
 */
export declare function registerBuiltinViews(runtime: IAgentRuntime, options?: {
    indexEmbeddings?: boolean;
}): void;
/**
 * List all registered views.
 *
 * Visibility follows the four-kind taxonomy ({@link resolveViewKind}):
 * `system`/`release` views are always listed. `developer` views are listed
 * only when `developerMode` is true. `preview` views are listed only when
 * `includeAllKinds` is true. The dashboard's `GET /api/views` passes
 * `includeAllKinds: true` so the client receives every view (with its
 * `viewKind`) and applies the user's Settings toggles itself — the server
 * cannot know whether it is talking to a dev build or which toggles are on.
 *
 * @param filter.developerMode - Include `developer`-kind views. Default false.
 * @param filter.includeAllKinds - Include every kind regardless of toggle
 *   (developer + preview). Default false.
 */
export declare function listViews(runtime: IAgentRuntime, filter?: {
    developerMode?: boolean;
    includeAllKinds?: boolean;
    viewType?: ViewType;
}): ViewRegistryEntry[];
/**
 * Look up a single view by its stable id.
 */
export declare function getView(runtime: IAgentRuntime, id: string, filter?: {
    viewType?: ViewType;
}): ViewRegistryEntry | undefined;
