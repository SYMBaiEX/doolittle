import type { RouteRequestContext } from "@elizaos/host/protocol";
/** DTO for the switcher: only the fields the UI renders + switches on. Internal
 * bookkeeping (bookmark, createdAt) is intentionally not surfaced. */
export interface ProjectSummaryDTO {
    id: string;
    name: string;
    localPath: string;
    repoUrl?: string;
    defaultBranch?: string;
    lastOpenedAt: string;
}
export interface ProjectListDTO {
    projects: ProjectSummaryDTO[];
    activeProjectId: string | null;
}
/**
 * Serve the project registry read + switch endpoints. Returns `true` when the
 * request was handled (so the caller stops the route chain), `false` otherwise.
 *
 * `readRegistry` / `activate` are injectable so tests drive the handler without
 * touching a real state dir; production wiring binds the core registry.
 */
export declare function handleProjectRoutes(ctx: RouteRequestContext, deps?: {
    readRegistry?: () => ProjectListDTO;
    activate?: (id: string) => ProjectSummaryDTO | null;
}): Promise<boolean>;
