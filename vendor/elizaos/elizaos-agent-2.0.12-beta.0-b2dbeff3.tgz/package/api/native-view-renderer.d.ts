/** Live, targeted renderer delivery over the existing private resident event feed. */
import type { IAgentRuntime } from "@elizaos/core";
type Renderer = {
    hostKey: object;
    close: () => void;
    send: (frame: object) => boolean;
    ended: Set<() => void>;
};
export declare function bindNativeViewHost(runtime: IAgentRuntime, hostKey: object): () => void;
export declare function registerNativeViewRenderer(runtime: IAgentRuntime, clientId: string, send: Renderer["send"]): () => void;
export declare function hasNativeViewRenderer(runtime: IAgentRuntime, hostKey: object, clientId: string): boolean;
export declare function sendNativeViewFrame(runtime: IAgentRuntime, hostKey: object, clientId: string, frame: object): number;
export declare function onNativeViewDisconnect(runtime: IAgentRuntime, clientId: string, ended: () => void): () => void;
export {};
