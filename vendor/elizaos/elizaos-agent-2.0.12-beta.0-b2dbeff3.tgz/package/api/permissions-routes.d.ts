/**
 * Mounts the `/api/permissions` REST surface behind the dashboard control-API
 * auth gate: GET the full permission map or a single permission, POST refresh,
 * per-permission request and open-settings, and PUT shell-access and
 * client-probed permission state. Reads live state through the runtime's
 * permissions registry when present, falls back to the persisted map or an
 * unavailable-permission stub, and validates client-pushed states (fail
 * closed) before persisting. A `PUT /state` also auto-enables capability
 * plugins whose required permissions are now granted and can schedule a
 * runtime restart. Shell access is surfaced as a synthetic permission derived
 * from config, never probed. `GET /native-projection` additionally projects
 * the personal-data permissions through the shared native capability
 * contract (metadata only; personal payloads never leave the device).
 */
import { type AgentRuntime, type PermissionState } from "@elizaos/core";
import type { RouteRequestContext } from "@elizaos/host/protocol";
interface PermissionAutonomousConfigLike extends Record<string, unknown> {
    features?: {
        shellEnabled?: boolean;
    };
    plugins?: {
        entries?: Record<string, {
            enabled?: boolean;
        }>;
    };
}
export interface PermissionRouteState {
    runtime: AgentRuntime | null;
    config: PermissionAutonomousConfigLike;
    permissionStates?: Record<string, PermissionState>;
    shellEnabled?: boolean;
}
export interface PermissionRouteContext extends RouteRequestContext {
    state: PermissionRouteState;
    saveConfig: (config: PermissionAutonomousConfigLike) => void;
    scheduleRuntimeRestart: (reason: string) => void;
}
export declare function handlePermissionRoutes(ctx: PermissionRouteContext): Promise<boolean>;
export {};
