/**
 * Fallback action parsing + execution helpers.
 *
 * When a response text carries bracketed action tags the planner didn't already
 * execute, these helpers parse the tags and run the matching runtime actions,
 * rewriting their callback output in the character's voice via TEXT_SMALL.
 */
var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
import { executePlannedToolCall, ModelType, } from "@elizaos/core";
import { extractCompatTextContent } from "./compat-utils.js";
async function rewriteFallbackActionText(args) {
    const text = args.text.trim();
    if (!text)
        return args.text;
    const fallback = () => {
        const error = typeof args.content?.error === "string" && args.content.error.trim()
            ? ` It reported: ${args.content.error.trim()}`
            : "";
        return `I ran ${args.actionName} and got a result, but I couldn't format the details cleanly here.${error}`;
    };
    if (args.abortSignal?.aborted ||
        typeof args.runtime.useModel !== "function") {
        return fallback();
    }
    try {
        const raw = await args.runtime.useModel(ModelType.TEXT_SMALL, {
            prompt: [
                "Rewrite this fallback action output in the assistant character's user-facing voice.",
                'Return strict JSON only: {"response":"..."}.',
                "",
                "Rules:",
                "- Preserve status, IDs, names, URLs, counts, errors, warnings, and next steps.",
                "- Do not expose raw JSON, shell output, schema names, stack traces, or internal action plumbing unless an exact value is necessary.",
                "- Do not claim success if the payload says failed or pending.",
                "- Keep it brief and natural.",
                "",
                `Character: ${JSON.stringify({
                    name: args.runtime.character?.name,
                    system: args.runtime.character?.system,
                    bio: args.runtime.character?.bio,
                    style: args.runtime.character?.style,
                })}`,
                `Action: ${JSON.stringify(args.actionName)}`,
                `Payload: ${JSON.stringify(text)}`,
                `Metadata: ${JSON.stringify({
                    source: args.content?.source,
                    actions: args.content?.actions,
                    actionStatus: args.content?.actionStatus,
                    error: args.content?.error,
                })}`,
            ].join("\n"),
            signal: args.abortSignal,
            providerOptions: { eliza: { thinking: "off" } },
        });
        const parsed = JSON.parse(String(raw).trim());
        return typeof parsed.response === "string" && parsed.response.trim()
            ? parsed.response.trim()
            : fallback();
    }
    catch (err) {
        args.runtime.logger.debug({
            src: "eliza-api",
            action: args.actionName,
            err: err instanceof Error ? err.message : String(err),
        }, "[eliza-api] Fallback action voice rewrite failed");
        return fallback();
    }
}
const LIFEOPS_PUBLIC_MODULE = "@elizaos/plugin-personal-assistant";
let ownerBlockFallbackPromise = null;
async function resolveBuiltInFallbackAction(actionName) {
    if (actionName !== "BLOCK") {
        return null;
    }
    if (!ownerBlockFallbackPromise) {
        ownerBlockFallbackPromise = import(__rewriteRelativeImportExtension(/* @vite-ignore */ LIFEOPS_PUBLIC_MODULE))
            .then((mod) => mod)
            .then((mod) => mod.websiteBlockAction ?? null)
            .catch(() => null);
    }
    return ownerBlockFallbackPromise;
}
export function parseFallbackActionBlocks(value, _responseText) {
    const rawValues = [];
    if (typeof value === "string") {
        rawValues.push(value);
    }
    else if (Array.isArray(value)) {
        for (const entry of value) {
            if (typeof entry === "string" && entry.trim().length > 0) {
                rawValues.push(entry);
            }
        }
    }
    const parsed = [];
    for (const raw of rawValues) {
        const normalized = raw.trim().toUpperCase();
        if (/^[A-Z0-9_]+$/.test(normalized)) {
            parsed.push({ name: normalized, parameters: {} });
        }
    }
    return parsed;
}
export async function executeFallbackParsedActions(runtime, message, parsedActions, appendIncomingText, onActionCallback, options) {
    const executionResults = [];
    const runtimeActions = Array.isArray(runtime.actions)
        ? runtime.actions
        : [];
    const lookup = new Map();
    for (const action of runtimeActions) {
        if (typeof action.name === "string")
            lookup.set(action.name.toUpperCase(), action);
        if (!Array.isArray(action.similes))
            continue;
        for (const alias of action.similes) {
            if (typeof alias === "string")
                lookup.set(alias.toUpperCase(), action);
        }
    }
    for (const parsed of parsedActions) {
        if (options?.abortSignal?.aborted)
            break;
        if (parsed.name === "REPLY" ||
            parsed.name === "NONE" ||
            parsed.name === "IGNORE") {
            continue;
        }
        // Prefer the built-in self-control actions for fallback execution.
        // The runtime-registered wrappers can gate these too aggressively during
        // early web-chat ownership bootstrap, while the built-in actions still
        // enforce the actual self-control OWNER/ADMIN check.
        const action = (await resolveBuiltInFallbackAction(parsed.name)) ??
            lookup.get(parsed.name);
        if (options?.abortSignal?.aborted)
            break;
        if (!action || typeof action.handler !== "function")
            continue;
        const actionHandler = action.handler;
        const parsedParameters = { ...(parsed.parameters ?? {}) };
        if (action.name === "BLOCK" && !Object.hasOwn(parsedParameters, "action")) {
            parsedParameters.action = "block";
        }
        let callbackSeen = false;
        const actionValidate = action.validate;
        const abortAwareAction = options?.abortSignal
            ? {
                ...action,
                validate: async (...args) => {
                    options.abortSignal?.throwIfAborted();
                    const valid = actionValidate ? await actionValidate(...args) : true;
                    options.abortSignal?.throwIfAborted();
                    return valid;
                },
                handler: (...args) => {
                    options.abortSignal?.throwIfAborted();
                    return actionHandler(...args);
                },
            }
            : action;
        const actionResult = await executePlannedToolCall(runtime, {
            message,
            activeContexts: action.contexts ?? [],
            callback: async (content, actionName) => {
                const contentRecord = content && typeof content === "object"
                    ? content
                    : {};
                const actionTag = typeof actionName === "string"
                    ? actionName
                    : typeof contentRecord.action === "string"
                        ? contentRecord.action
                        : action.name;
                const chunk = contentRecord && typeof contentRecord === "object"
                    ? extractCompatTextContent(contentRecord)
                    : "";
                callbackSeen = true;
                onActionCallback(actionTag, Boolean(chunk));
                if (chunk) {
                    const voicedChunk = await rewriteFallbackActionText({
                        runtime,
                        actionName: actionTag,
                        text: chunk,
                        content: contentRecord,
                        abortSignal: options?.abortSignal,
                    });
                    (options?.onCallbackText ?? appendIncomingText)(voicedChunk);
                }
                return [];
            },
        }, { name: action.name, params: parsedParameters }, {
            actions: [abortAwareAction],
            abortSignal: options?.abortSignal,
        });
        const actionSucceeded = Boolean(actionResult &&
            typeof actionResult === "object" &&
            "success" in actionResult &&
            actionResult.success === true);
        executionResults.push({
            actionName: typeof action.name === "string" && action.name.trim()
                ? action.name
                : parsed.name,
            success: actionSucceeded,
        });
        if (options?.abortSignal?.aborted && !actionSucceeded)
            break;
        if (!callbackSeen) {
            const currentText = options?.getCurrentText?.() ?? "";
            const fallbackText = actionResult && typeof actionResult === "object"
                ? typeof actionResult.text === "string"
                    ? actionResult.text
                    : ""
                : "";
            const currentTextLooksLikeCompletedWebsiteBlock = /\b(started|starting|blocked|blocking now|website block is active|block is active)\b/i.test(currentText);
            const shouldSuppressSuccessFallbackText = parsed.name === "BLOCK" &&
                actionSucceeded === true &&
                currentTextLooksLikeCompletedWebsiteBlock;
            if (fallbackText) {
                onActionCallback(parsed.name, !shouldSuppressSuccessFallbackText);
                if (!shouldSuppressSuccessFallbackText) {
                    const voicedFallbackText = await rewriteFallbackActionText({
                        runtime,
                        actionName: parsed.name,
                        text: fallbackText,
                        abortSignal: options?.abortSignal,
                    });
                    appendIncomingText(currentText.trim().length > 0
                        ? `\n\n${voicedFallbackText}`
                        : voicedFallbackText);
                }
            }
        }
    }
    return executionResults;
}
