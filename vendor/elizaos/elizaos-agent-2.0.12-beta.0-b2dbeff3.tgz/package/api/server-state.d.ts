/**
 * Constructs the mutable state shared by agent API route adapters. Keeping the
 * initialization contract separate from the HTTP listener makes first-run,
 * runtime-backed, and stopped-server states deterministic and testable.
 */
import type { AgentAutomationMode, AgentRuntime } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { PluginEntry, ServerState } from "./server-types.js";
export type InitialAgentState = Extract<ServerState["agentState"], "not_started" | "starting" | "stopped" | "error">;
export interface CreateServerStateOptions {
    config: ElizaConfig;
    runtime?: AgentRuntime;
    initialAgentState?: InitialAgentState;
    plugins: PluginEntry[];
    deletedConversationIds: Set<string>;
    resolveAgentName(config: ElizaConfig): string;
    detectRuntimeModel(runtime: AgentRuntime | null, config: ElizaConfig): string | undefined;
    resolveAgentAutomationMode(config: ElizaConfig): AgentAutomationMode;
    resolveTradePermissionMode(config: ElizaConfig): ServerState["tradePermissionMode"];
}
export declare function createServerState(options: CreateServerStateOptions): ServerState;
