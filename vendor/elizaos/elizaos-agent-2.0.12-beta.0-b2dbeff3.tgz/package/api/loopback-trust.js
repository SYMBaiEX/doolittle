/** Agent host environment policy for strict same-machine request classification. */
import { isTrustedLocalRequest as classifyLocalRequest } from "@elizaos/core";
import { readAliasedEnv } from "@elizaos/host/protocol";
import { isCloudProvisionedContainer } from "@elizaos/plugin-elizacloud/cloud-config/cloud-provisioning";
export { isLoopbackRemoteAddress, isRemoteAddressInCidrList, proxyClientHeaderBlocksLocalTrust, } from "@elizaos/core";
function cloudBlocksLocalTrust(cloudCheck) {
    if (cloudCheck === "container")
        return isCloudProvisionedContainer();
    return readAliasedEnv("ELIZA_CLOUD_PROVISIONED") === "1";
}
function localAuthRequired(options) {
    if (!options.requireLocalAuthEnv)
        return false;
    if (options.devAuthBypassEnv &&
        process.env.ELIZA_DEV_AUTH_BYPASS === "1" &&
        (process.env.NODE_ENV === "development" || process.env.NODE_ENV === "dev")) {
        return false;
    }
    return process.env.ELIZA_REQUIRE_LOCAL_AUTH === "1";
}
export function isTrustedLocalRequest(req, options) {
    return classifyLocalRequest(req, {
        localAuthRequired: localAuthRequired(options),
        cloudProvisioned: cloudBlocksLocalTrust(options.cloudCheck),
    });
}
