/**
 * Chat-message attachment DTO shaping + per-viewer disclosure selection
 * (#14781) — the use-case layer behind the conversation message-list route.
 * Serialization (which raw `content.attachments` entries become wire DTOs)
 * and disclosure (what THIS viewer may see of them) live here so the route
 * only assembles fields.
 *
 * Disclosure follows the ONE core predicate (`resolveArtifactDisclosure`) fed
 * with the message row's metadata. Chat messages default to scope `"room"`
 * (open): a viewer who can read the conversation sees its attachments, which
 * preserves existing behavior for every unmarked message. Only a message
 * explicitly marked (scope metadata or share grants) narrows: a
 * redacted-grant viewer gets each attachment's PII-scrubbed variant
 * (`Media.redactedUrl`, a separate content-addressed object) flagged
 * `redacted: true` with the original URL and enrichment text withheld; an
 * undisclosed viewer gets nothing.
 */
import type { AccessContext, Memory, UUID } from "@elizaos/core";
/** One chat attachment as served in the message-list DTO. */
export type SerializedMessageAttachment = {
    id: string;
    url: string;
    contentType?: string;
    title?: string;
    description?: string;
    source?: string;
    text?: string;
    mimeType?: string;
    thumbnailUrl?: string;
    /** Reason enrichment could not extract text/description (see Media.notProcessed). */
    notProcessed?: string;
    /** Present (true) when `url` is the PII-scrubbed variant, not the original (#14781). */
    redacted?: true;
};
export declare function serializeMessageAttachments(content: Record<string, unknown> | undefined): SerializedMessageAttachment[] | undefined;
/**
 * Select the attachments DTO of one message row for one viewer. No access
 * context (the single-owner dashboard boundary) serves the full DTO,
 * unchanged. Unknown scope strings fail CLOSED to `owner-private` — a marked
 * row whose marking cannot be read must not widen.
 */
export declare function selectAttachmentsForViewer(row: Pick<Memory, "content" | "metadata" | "entityId">, accessContext: AccessContext | undefined, agentId: UUID): SerializedMessageAttachment[] | undefined;
