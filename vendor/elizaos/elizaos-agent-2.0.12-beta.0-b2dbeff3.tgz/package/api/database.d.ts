import type http from "node:http";
import { type AgentRuntime } from "@elizaos/core";
import { type ElizaConfig } from "@elizaos/host/protocol";
export { stripSqlBlockComments, stripSqlDollarQuotedLiterals, stripSqlLineComments, } from "../shared/sql-sanitizers.js";
/**
 * Parse + clamp the `offset`/`limit` query params for row pagination. The
 * values are interpolated into the SQL `LIMIT ... OFFSET ...` clause, so they
 * MUST come out as safe non-negative integers: `Math.max(0, Number("abc"))` is
 * `NaN` (Math.max propagates NaN), and a raw `Number()` also lets through
 * floats ("1.5") and "Infinity" — all of which previously reached the query
 * text and made the whole request 500. Non-numeric/unsafe input falls back to
 * the defaults; out-of-range integers clamp. Exported for unit tests.
 */
export declare function parseRowsPagination(offsetRaw: string | null, limitRaw: string | null): {
    offset: number;
    limit: number;
};
/**
 * Parse the `order` query for row retrieval. The token is interpolated into
 * `ORDER BY ... ASC|DESC`, so only the Control UI's exact `asc`/`desc`
 * identities are legal. `order=DESC` used to become ASC because only the
 * lowercase `desc` token flipped the direction.
 */
export declare function parseRowsSortOrder(raw: string | null): {
    ok: true;
    order: "ASC" | "DESC";
} | {
    ok: false;
};
/**
 * Route a database API request. Returns true if handled, false if not matched.
 *
 * Expected URL patterns:
 *   GET    /api/database/status
 *   GET    /api/database/config
 *   PUT    /api/database/config
 *   POST   /api/database/test
 *   GET    /api/database/tables
 *   GET    /api/database/tables/:table/rows
 *   POST   /api/database/tables/:table/rows
 *   PUT    /api/database/tables/:table/rows
 *   DELETE /api/database/tables/:table/rows
 *   POST   /api/database/query
 */
export declare function handleDatabaseRoute(req: http.IncomingMessage, res: http.ServerResponse, runtime: AgentRuntime | null, pathname: string, liveConfig?: Pick<ElizaConfig, "database">): Promise<boolean>;
