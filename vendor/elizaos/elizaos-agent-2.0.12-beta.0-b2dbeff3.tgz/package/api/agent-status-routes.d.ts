/**
 * Agent self-status inline route.
 */
import type http from "node:http";
import type { TradePermissionMode } from "@elizaos/contracts";
import type { AgentRuntime } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { LocalTradeExecutionOptions } from "@elizaos/plugin-wallet/transactions";
import type { WalletCapabilityStatus } from "./wallet-capability.js";
export interface AwarenessRegistryLike {
    composeSummary: (runtime: unknown) => Promise<string>;
}
export interface AgentStatusRouteDeps {
    getWalletAddresses: () => {
        evmAddress: string | null;
        solanaAddress: string | null;
    };
    resolveWalletCapabilityStatus: (state: {
        config: ElizaConfig;
        runtime: AgentRuntime | null;
    }) => WalletCapabilityStatus;
    resolveWalletRpcReadiness: (config: ElizaConfig) => {
        managedBscRpcReady: boolean;
    };
    resolveTradePermissionMode: (config: ElizaConfig) => TradePermissionMode;
    canUseLocalTradeExecution: (mode: TradePermissionMode, isAgentRequest: boolean, log?: (message: string) => void, opts?: LocalTradeExecutionOptions) => boolean;
    detectRuntimeModel: (runtime: AgentRuntime | null, config: ElizaConfig) => string | undefined;
    resolveProviderFromModel: (model: string) => string | null;
    getAwarenessRegistry: () => AwarenessRegistryLike | null;
}
export interface AgentStatusRouteState {
    config: ElizaConfig;
    runtime: AgentRuntime | null;
    agentState: string;
    agentName: string;
    model?: string;
    startedAt?: number;
    shellEnabled?: boolean;
}
export interface AgentStatusRouteContext {
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    state: AgentStatusRouteState;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    deps: AgentStatusRouteDeps;
}
export declare function handleAgentStatusRoutes(ctx: AgentStatusRouteContext): Promise<boolean>;
