/**
 * POST /api/interactions/shortcut and /api/interactions/composer — report
 * user UI activity so the agent observes it as first-class interaction context
 * (#8792, #14679).
 *
 * The view-switch half of this contract lives in `views-routes.ts`
 * (`POST /api/views/:id/navigate` → `VIEW_SWITCHED`). This is the keyboard /
 * command-palette half: the client reports a stable `shortcutId` and the route
 * emits `EventType.SHORTCUT_FIRED`, which the proactive-interaction decider
 * consumes (governed by debounce / cooldown / daily-cap / model-judge-silent).
 * The composer half carries only lifecycle metadata (started / paused /
 * abandoned), never draft text, so providers can reason about "user is
 * thinking" without leaking what they have not sent.
 *
 * Emission is fire-and-forget: a dropped event must never break the shortcut the
 * user actually pressed. This route is auth+proxy thin — it records nothing and
 * computes nothing beyond input validation.
 */
import type http from "node:http";
import { type AgentRuntime, EventType } from "@elizaos/core";
declare const COMPOSER_ACTIVITY_TO_EVENT: {
    readonly typing_started: EventType.USER_TYPING_STARTED;
    readonly typing_paused: EventType.USER_TYPING_PAUSED;
    readonly draft_abandoned: EventType.USER_DRAFT_ABANDONED;
};
type ComposerActivity = keyof typeof COMPOSER_ACTIVITY_TO_EVENT;
export interface InteractionsRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    runtime: AgentRuntime | null | undefined;
}
export interface ShortcutInteractionRequest {
    shortcutId: string;
    context?: string;
}
export interface ComposerInteractionRequest {
    activity: ComposerActivity;
    surface: string;
    conversationId?: string;
    draftLength: number;
    idleForMs?: number;
    reason?: "cleared" | "blurred" | "conversation_switched" | "unknown";
    occurredAt: string;
}
/** Parse + validate the shortcut report body; null on anything malformed. */
export declare function parseShortcutBody(raw: string): ShortcutInteractionRequest | null;
/** Parse + validate a composer lifecycle report; null on anything malformed. */
export declare function parseComposerBody(raw: string): ComposerInteractionRequest | null;
export declare function handleInteractionsRoutes(ctx: InteractionsRouteContext): Promise<boolean>;
export {};
