var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
import { bindNativeViewHost, hasNativeViewRenderer, } from "./native-view-renderer.js";
import "./artifact-share-role-resolver.js";
import "./waifu-chat-role-resolver.js";
/**
 * REST API server for the Eliza Control UI.
 *
 * Exposes HTTP endpoints that the UI frontend expects, backed by the
 * elizaOS AgentRuntime. Default port: 2138. In dev mode, the Vite UI
 * dev server proxies /api and /ws here (see packages/app/scripts/dev-ui.ts).
 */
import fs from "node:fs";
import http from "node:http";
import { createIntegrationTelemetrySpan, ElizaError, EventType, formatError, logger, MAX_RESTORABLE_AGENT_BACKUP_BYTES, NotificationService, normalizeCharacterLanguage, resolveOwnerEntityIdOrDefault, resolveStateDir, ServiceType, } from "@elizaos/core";
import { readJsonBody as parseJsonBody, readRequestBody, sendJson, sendJsonError, writeJsonError, writeJsonResponse, } from "@elizaos/host";
import { getHttpRuntime, getStylePresets, isMobilePlatform, readAliasedEnv, resolveApiBindHost, resolveDesktopApiPort, resolveServerOnlyPort, toWorkbenchTodo, } from "@elizaos/host/protocol";
import { tryHandleTrajectoryReadRoutes } from "@elizaos/plugin-assistant";
import { persistConfigEnv } from "@elizaos/plugin-elizacloud/lib/config-env";
import { canUseLocalTradeExecution, resolveTradePermissionMode, } from "@elizaos/plugin-wallet/transactions";
import { WebSocket, WebSocketServer } from "ws";
import { loadElizaConfig, resolveConfigWritePath, saveElizaConfig, } from "../config/config.js";
import { createDevCloudConfigAuthorityView, materializeDevCloudConfigAuthorityView, mergeDevCloudConfigAuthorityMutation, } from "../config/dev-cloud-env-authority.js";
import { isCloudWalletEnabled } from "../config/feature-flags.js";
import { resolveModelsCacheDir } from "../config/paths.js";
import { CharacterSchema } from "../config/zod-schema.js";
import { getAgentEventService } from "../runtime/agent-event-service.js";
import { pickRandomNames } from "../runtime/first-run-names.js";
import { getAgentHostBridge, } from "../runtime/host-bridge.js";
import { resolvePreferredProviderId, resolvePrimaryModel, } from "../runtime/model-resolution.js";
import { defaultClassifier, } from "../runtime/operations/classifier.js";
import { createColdStrategy } from "../runtime/operations/cold-strategy.js";
import { getDefaultHealthChecker } from "../runtime/operations/health.js";
import { DefaultRuntimeOperationManager } from "../runtime/operations/manager.js";
import { createHotStrategy } from "../runtime/operations/reload-hot.js";
import { getDefaultRepository } from "../runtime/operations/repository.js";
import { classifyRegistryPluginRelease } from "../runtime/release-plugin-policy.js";
import { getViewClientScope, runWithViewClient, } from "../runtime/view-client-context.js";
import { AUDIT_EVENT_TYPES, AUDIT_SEVERITIES, getAuditFeedSize, queryAuditFeed, subscribeAuditFeed, } from "../security/audit-log.js";
import { ensureProtectedProfileAdmission } from "../security/protected-profile.js";
import { AgentSnapshotBudgetExceededError, createAgentSnapshot, createLocalAgentBackup, listLocalAgentBackups, PGLITE_SNAPSHOT_UNAVAILABLE_TRANSIENT, PGLITE_SNAPSHOT_UNAVAILABLE_TRANSIENT_CODE, restoreAgentSnapshot, restoreLocalAgentBackup, } from "../services/agent-backup.js";
import { AgentExportError, estimateExportSize, exportAgent, importAgent, } from "../services/agent-export.js";
import { registerClientChatSendHandler } from "../services/client-chat-sender.js";
import { createConfigPluginManager } from "../services/config-plugin-manager.js";
import { isPluginManagerLike, } from "../services/plugin-manager-types.js";
import { PROACTIVE_INTERACTION_SOURCE, registerProactiveInteractionDecider, } from "../services/proactive-interaction-decider.js";
import { ProactiveInteractionGate } from "../services/proactive-interaction-gate.js";
import { executeTriggerTask, getTriggerHealthSnapshot, getTriggerLimit, listTriggerTasks, readTriggerConfig, readTriggerRuns, TRIGGER_TASK_NAME, TRIGGER_TASK_TAGS, taskToTriggerSummary, triggersFeatureEnabled, } from "../triggers/runtime.js";
import { buildTriggerConfig, buildTriggerMetadata, DISABLED_TRIGGER_INTERVAL_MS, normalizeTriggerDraft, } from "../triggers/scheduling.js";
import { detectRuntimeModel, resolveProviderFromModel } from "./agent-model.js";
import { AgentBackupClientDisconnectedError, writeAgentBackupJsonResponse, } from "./backup-json-response.js";
import { handleAgentBackupV2SnapshotRequest } from "./backup-v2-stream-response.js";
import { cloneWithoutBlockedObjectKeys, hasBlockedObjectKeyDeep, } from "./blocked-object-keys.js";
import { resolveRegisteredTokenRoleAccess } from "./boundary-role-resolver.js";
import { handleStandaloneCloudPairRoute } from "./cloud-pair-route.js";
import { replaceConfigInPlace, setLiveElizaConfigSource, } from "./config-state.js";
import { resolveConnectorHealthIntervalMs } from "./connector-health.js";
import { handleContextInspectorRoute } from "./context-inspector-routes.js";
import { restoreConversationsFromDb as restoreConversationsFromDbImpl } from "./conversation-restore.js";
import { resolvePromptDeliveryRoom } from "./conversation-routes.js";
import { wireCoordinatorBridgesWhenReady } from "./coordinator-wiring.js";
import { handleDeviceActionRoutes, requiresDeviceIdentity, } from "./device-action-routes.js";
import { flushEarlyLogs, listenForUiLogs } from "./early-logs.js";
import { buildEphemeralAgentEventEnvelope, createApiEventHub, createEventSocketBackpressureGuard, createEventSocketLivenessSweep, EPHEMERAL_AGENT_EVENT_STREAMS, } from "./event-hub.js";
import { responseReadinessFields, } from "./health-routes.js";
import { resolveHostSessionAccessContext } from "./host-session-access-context.js";
import { resolveHttpAccessContext } from "./http-access-context.js";
import { listenHttpServer } from "./http-listener.js";
import { registerInProcessApi } from "./in-process-api.js";
import { getAuthenticatedInProcessAuthorization } from "./in-process-request.js";
import { resolveInboxRequestAuthorization } from "./inbox-request-authorization.js";
import { loadLocalInferenceRouteApi, loadLocalInferenceVoiceRouteApi, } from "./local-inference-server-api.js";
import { isMediaAuthRequired, serveMediaFile } from "./media-store.js";
import { getModelOptions, getOrFetchAllProviders, getOrFetchProvider, providerCachePath, } from "./model-provider-helpers.js";
import { resolveOptionalPluginImportFailure } from "./optional-plugin-fallback.js";
import { handlePluginDirectoryRoutes } from "./plugin-directory-routes.js";
import { AGENT_EVENT_ALLOWED_STREAMS, CONFIG_WRITE_ALLOWED_TOP_KEYS, discoverPluginsFromManifest, getReleaseBundledPluginIds, isBlockedEnvKey, } from "./plugin-discovery-helpers.js";
import { getPluginInventory, handlePluginInventoryRoutes, } from "./plugin-inventory-routes.js";
import { handlePluginManagementRoutes } from "./plugin-management-routes.js";
import { attachPtySessionWsBridge, cancelPendingPtySessionStop, MAX_PTY_INPUT_MESSAGE_LENGTH, resolvePtyDisconnectGraceMs, schedulePtySessionStopAfterGrace, } from "./pty-ws-bridge.js";
import { maybeCapRequestStorm } from "./request-storm-cap.js";
import { createRouteKernel } from "./route-kernel.js";
import { handleRuntimeManagementRoutes } from "./runtime-management-routes.js";
import { handleRuntimeModePreDispatch, handleRuntimeModeRemoteForward, } from "./runtime-mode/pre-dispatch.js";
import { resolveRuntimeMode, } from "./runtime-mode/runtime-mode.js";
import { quiesceRuntimeBeforeReplacement } from "./runtime-replacement-ownership.js";
import { handleRuntimeSwitchRoutes } from "./runtime-switch-routes.js";
import { isLifeOpsCloudPluginRoute, maybeRouteAutonomyEventToConversation, } from "./server-autonomy-helpers.js";
import { decodePathComponent, hasPersistedFirstRunState, isUuidLike, patchTouchesProviderSelection, readDeletedConversationIdsFromState, } from "./server-helpers.js";
import { applyCors, clearPairing, ensureApiTokenForBindHost, ensurePairingCode, extractWebSocketHandshakeToken, getConfiguredApiToken, getPairingExpiresAt, getPairingInstanceId, isAllowedHost, isAuthorized, isBoundaryRoleAuthorized, isCredentialedCorsOrigin, isServerTokenAuthorized, isSharedTerminalClientId, isTrustedLocalRequest, isWebSocketAuthorized, isWebSocketSessionTokenAuthorized, isWebSocketUpgradeSessionAuthorized, markWebSocketUpgradeSessionAuthorized, normalizePairingCode, normalizeWsClientId, pairingEnabled, rateLimitPairing, rejectWebSocketUpgrade, releasePendingWebSocket, resolveTerminalRunClientId, resolveTerminalRunRejection, resolveWebSocketUpgradeRejection, tokenMatches, tryAcquirePendingWebSocket, WS_AUTH_GRACE_TIMEOUT_MS, } from "./server-helpers-auth.js";
import { applyFirstRunVoicePreset, ensureWalletKeysInEnvAndConfig, getCloudProviderOptions, getProviderOptions, isBlockedObjectKey as isBlockedObjectKeyFromConfig, readUiLanguageHeader, redactConfigSecrets, redactDeep, resolveConfiguredCharacterLanguage, resolveDefaultAgentName, stripRedactedPlaceholderValuesDeep, } from "./server-helpers-config.js";
import { resolveMcpServersRejection, resolveMcpTerminalAuthorizationRejection, } from "./server-helpers-mcp.js";
import { getPtyConsoleBridge, getPtyService, routeAutonomyTextToUser as routeProactiveText, wireCodingAgentChatBridge, wireCodingAgentSwarmSynthesis, wireCodingAgentWsBridge, wireCoordinatorEventRouting, } from "./server-helpers-swarm.js";
import { resolveWalletExportRejection } from "./server-helpers-wallet.js";
import { createConnectorHealthMonitor, handleAccountsRoutes, handleAgentAdminRoutes, handleAgentLifecycleRoutes, handleAgentStatusRoutes, handleAgentTransferRoutes, handleAuthRoutes, handleAvatarRoutes, handleBackgroundTasksRoute, handleBugReportRoutes, handleCharacterRoutes, handleCloudAndCoreRouteGroup, handleConfigRoutes, handleConnectorRoutes, handleConversationRouteGroup, handleDatabaseRouteGroup, handleDiagnosticsRoutes, handleFirstRunRoutes, handleHealthRoutes, handleHostSettingsRoutes, handleInboxAndCloudRelayRouteGroup, handleInteractionsRoutes, handleLifeOpsRuntimePluginRoute, handleMemoryRoutes, handleMiscRoutes, handleModelConfigRoutes, handleModelsRoutes, handlePermissionRoutes, handlePermissionsExtraRoutes, handleProjectRoutes, handleProviderSwitchRoutes, handleRegistryRoutes, handleRelationshipsRoutes, handleRemoteCapabilityRoutes, handleSandboxRouteGroup, handleSubscriptionRoutes, handleTrajectoryManagementRoutes, handleUpdateRoutes, handleViewsRoutes, handleWorkbenchRoutes, isPublicRuntimePluginRoute, registerBuiltinViews, tryHandleHonoRuntimeRoute, tryHandleLifeOpsInboxFallbackLazy, tryHandleRuntimePluginRoute, } from "./server-lazy-routes.js";
import { createServerResources } from "./server-resources.js";
import { createServerState } from "./server-state.js";
import { isAuthProtectedRoute, serveStaticUi } from "./static-file-server.js";
import { isTrajectoryOwnerRequest } from "./trajectory-request-authorization.js";
import { bindViewRequestHost, closeViewInteractionHost, } from "./view-interaction-host.js";
import { registerBuiltinViews as registerRuntimeBuiltinViews } from "./views-registry.js";
import { resolveWalletAutomationMode as resolveAgentAutomationModeFromConfig, resolveWalletCapabilityStatus, } from "./wallet-capability.js";
import { persistWalletPrivateKeys } from "./wallet-key-store.js";
import { applyWalletRpcConfigUpdate, getInventoryProviderOptions, getStoredWalletRpcSelections, resolveWalletNetworkMode, resolveWalletRpcReadiness, } from "./wallet-rpc.js";
import { DEFAULT_REPLAY_LIMIT, parseEventCursor, selectReplayEvents, } from "./ws-event-replay.js";
import { runtimeRoutesNeedX402Validation } from "./x402-route-validation.js";
const MAX_BODY_BYTES = 1024 * 1024; // 1 MB
/**
 * Restore's request-body cap IS the v1 restorable ceiling: anything retained
 * above it can never be restored here (#17172). Shared with the retain side so
 * the two cannot drift.
 */
const MAX_BACKUP_BODY_BYTES = MAX_RESTORABLE_AGENT_BACKUP_BYTES;
const BACKUP_BODY_TOO_LARGE = "Agent backup request body is too large";
import path from "node:path";
let browserPluginModule = null;
let x402PluginModule = null;
let browserPluginModulePromise = null;
let x402PluginModulePromise = null;
// Vite 7's import-analysis eagerly resolves string-literal dynamic imports even
// when a `@vite-ignore` comment is present, throwing "Failed to resolve entry"
// for the optional plugins below whose dist isn't built in the unit Plugin
// Tests lane (any spec that transitively transforms this file then fails to
// collect). Funnel optional plugin loads through a variable specifier so the
// analyzer leaves them as pure runtime imports — the host resolves them from
// node_modules on demand. Mirrors the variable-specifier bundle loader further
// down this file.
function importOptionalPlugin(specifier) {
    return import(__rewriteRelativeImportExtension(/* @vite-ignore */ specifier));
}
async function getBrowserPlugin() {
    if (browserPluginModule)
        return browserPluginModule;
    // The native-client decoder must resolve inside the node_modules-free bundle.
    browserPluginModulePromise ??= import(
    /* @vite-ignore */ "@elizaos/plugin-browser").then((browser) => {
        browserPluginModule = browser;
        return browser;
    });
    return browserPluginModulePromise;
}
/** Bind the live runtime service, not a separately imported plugin module copy. */
const nativeReaderWiredRuntimes = new WeakSet();
function wireNativeBrowserPageReader(runtime) {
    if (!runtime || nativeReaderWiredRuntimes.has(runtime))
        return;
    nativeReaderWiredRuntimes.add(runtime);
    const requestingHost = (clientId) => {
        const scope = getViewClientScope();
        if (!scope ||
            scope.clientId !== clientId ||
            !scope.request?.authorization?.ok ||
            scope.request.runtime !== runtime ||
            scope.request.signal.aborted) {
            throw new ElizaError("Native browser requires the requesting view client", { code: "VIEW_CLIENT_REQUIRED" });
        }
        return scope.hostKey;
    };
    // Context activation can register the plugin long after API startup. Bind
    // each actual service instance when it starts, without eagerly loading it.
    const bindReader = () => {
        const browser = runtime.getService("browser");
        if (!browser || typeof browser.setNativeClientTransport !== "function")
            return;
        browser.setNativeClientTransport({
            executeCommand: async (clientId, command) => {
                const hostKey = requestingHost(clientId);
                const [{ dispatchViewInteract, getViewsBroadcastWsToClientId }, { getView },] = await Promise.all([
                    import("./views-routes.js"),
                    import("./views-registry.js"),
                ]);
                const entry = getView(runtime, "browser", { viewType: "gui" });
                const sendToClient = getViewsBroadcastWsToClientId(hostKey);
                if (!entry || !sendToClient)
                    throw new Error("Native browser control transport is unavailable.");
                const reply = await dispatchViewInteract(entry, "browser", "browser-command", { command }, {
                    clientId,
                    hostKey,
                    broadcastWsToClientId: sendToClient,
                    runtime,
                    userRoles: [getViewClientScope().request.authorization.role],
                    ownerId: getViewClientScope().request.authorization.identityId ??
                        getViewClientScope().request.authorization.principal ??
                        resolveHostSessionAccessContext(getViewClientScope().request.authorization, runtime)?.requesterEntityId,
                });
                if (!reply.success)
                    throw new Error(reply.error ?? "Native browser control failed.");
                return (await getBrowserPlugin()).decodeNativeBrowserCommandResult(command, reply.result);
            },
            navigate: async (clientId, url) => {
                const hostKey = requestingHost(clientId);
                if (hasNativeViewRenderer(runtime, hostKey, clientId))
                    throw new ElizaError("Opening a new destination in this app requires its reviewed device navigation operation", { code: "NATIVE_BROWSER_REVIEW_REQUIRED" });
                const [{ getViewsBroadcastWsToClientId }, { createShellNavigateViewWsFrame },] = await Promise.all([
                    import("./views-routes.js"),
                    import("@elizaos/core"),
                ]);
                const send = getViewsBroadcastWsToClientId(hostKey);
                if (!send ||
                    send(clientId, createShellNavigateViewWsFrame({
                        viewId: "browser",
                        viewType: "gui",
                        viewLabel: "Browser",
                        source: "agent",
                        viewPath: url
                            ? `/browser?browse=${encodeURIComponent(url)}`
                            : "/browser",
                    })) <= 0)
                    throw new Error("The requesting native Browser client is not connected.");
            },
            readPage: async (clientId, selector) => {
                const hostKey = requestingHost(clientId);
                const [{ dispatchViewInteract, getViewsBroadcastWsToClientId }, { getView },] = await Promise.all([
                    import("./views-routes.js"),
                    import("./views-registry.js"),
                ]);
                const entry = getView(runtime, "browser", { viewType: "gui" });
                const sendToClient = getViewsBroadcastWsToClientId(hostKey);
                if (!entry || !sendToClient)
                    throw new Error("Native Browser interaction transport is unavailable.");
                const reply = await dispatchViewInteract(entry, "browser", "get-text", {
                    nativeOnly: true,
                    ...(selector === undefined ? {} : { selector }),
                }, {
                    clientId,
                    hostKey,
                    broadcastWsToClientId: sendToClient,
                    runtime,
                    userRoles: [getViewClientScope().request.authorization.role],
                    ownerId: getViewClientScope().request.authorization.identityId ??
                        getViewClientScope().request.authorization.principal ??
                        resolveHostSessionAccessContext(getViewClientScope().request.authorization, runtime)?.requesterEntityId,
                });
                if (!reply.success)
                    throw new Error(reply.error ?? "Native Browser page read failed.");
                return reply.result;
            },
        });
    };
    runtime.registerEvent(EventType.SERVICE_STARTED, async ({ serviceType }) => {
        if (serviceType === "browser")
            bindReader();
    });
    bindReader();
}
// On mobile the agent bundle aliases `@elizaos/plugin-browser` to a null-stub
// (packages/agent/scripts/mobile-stubs/null-plugin.ts): the module imports fine but its
// workspace functions are absent, so calling one throws an uncaught TypeError
// that surfaces as a 500 (and a raw "X is not a function" in the /browser view).
// The browser workspace is desktop-only, so resolve the plugin only when it
// really implements the requested method and let callers serve an empty payload
// otherwise.
async function resolveDesktopBrowserPlugin(method) {
    if (isMobilePlatform())
        return null;
    const browserPlugin = await getBrowserPlugin();
    if (browserPlugin.__mobileStub)
        return null;
    return typeof browserPlugin[method] === "function" ? browserPlugin : null;
}
function getBrowserWorkspacePlugin() {
    return resolveDesktopBrowserPlugin("getBrowserWorkspaceSnapshot");
}
async function getX402Plugin() {
    if (x402PluginModule)
        return x402PluginModule;
    // x402 is desktop/cloud-only; on mobile it is not in the agent bundle, so the
    // "optional" dynamic import REJECTS (no node_modules). Treat a missing module
    // as "no x402" instead of letting the rejection crash API-server startup —
    // `importOptionalPlugin` is named optional but does not itself swallow.
    x402PluginModulePromise ??= importOptionalPlugin("@elizaos/plugin-x402")
        .then((x402) => {
        x402PluginModule = x402;
        return x402;
    })
        .catch(() => null);
    return x402PluginModulePromise;
}
// Package specifier per optional-plugin key. Kept alongside the import table so
// the unavailable-plugin fallback can key its "is this the plugin package itself
// that's absent (benign) vs a broken transitive import (drift)" decision on the
// real specifier rather than the short key. See optional-plugin-fallback.ts.
const optionalPluginSpecifiers = {
    capacitor: "@elizaos/plugin-native-inference/host-bridge",
    cloud: "@elizaos/plugin-elizacloud",
    imessage: "@elizaos/plugin-imessage",
    mcp: "@elizaos/plugin-mcp",
    workflow: "@elizaos/plugin-workflow/trigger-routes",
};
const optionalPluginImports = {
    // The mobile host has no node_modules. Keep this specifier visible to the
    // bundler, as with the native browser loader above.
    capacitor: () => import(/* @vite-ignore */ "@elizaos/plugin-native-inference/host-bridge"),
    cloud: () => importOptionalPlugin(optionalPluginSpecifiers.cloud),
    imessage: () => importOptionalPlugin(optionalPluginSpecifiers.imessage),
    mcp: () => importOptionalPlugin(optionalPluginSpecifiers.mcp),
    workflow: () => import(/* @vite-ignore */ "@elizaos/plugin-workflow/trigger-routes"),
};
/**
 * Combine the route + voice surfaces from the single subpath-owning loader
 * (`./local-inference-server-api.ts`). The loaders there own the stub/subpath
 * knowledge and each clear their memo on reject, so a cold-boot import failure
 * surfaces here and retries on the next request — the same semantics as before,
 * without this file knowing the plugin's stub layout.
 */
async function getLocalInferenceServerApi() {
    const [routeApi, voiceApi] = await Promise.all([
        loadLocalInferenceRouteApi(),
        loadLocalInferenceVoiceRouteApi(),
    ]);
    return { ...routeApi, ...voiceApi };
}
async function getOptionalPluginApi(key) {
    try {
        return (await optionalPluginImports[key]());
    }
    catch (err) {
        // The plugin is optional and (on mobile) many desktop/cloud plugins — cloud,
        // whatsapp, wallet-adjacent, mcp, streaming, … — are excluded, so their
        // dynamic import REJECTS with a module-resolution error. Without this catch
        // that rejection propagates to the top-level request handler as a 500 on
        // EVERY renderer poll of the plugin's routes. We fall back to a no-op API so
        // route-dispatch blocks (`if (await handleX(...)) return;`) fall through to
        // the normal 404 instead of erroring.
        //
        // resolveOptionalPluginImportFailure distinguishes the EXPECTED
        // module-absent case (quiet debug + fallthrough) from a present-but-broken
        // plugin (a package that resolved but threw at init, or whose accessed
        // export was renamed/removed). The latter is a drift regression the old
        // silent Proxy hid — it now warns so a broken/renamed handler is observable
        // instead of silently 404ing forever. See optional-plugin-fallback.ts.
        return resolveOptionalPluginImportFailure(String(key), err, optionalPluginSpecifiers[key]);
    }
}
let walletApiPromise;
function getWalletApi() {
    walletApiPromise ??= importOptionalPlugin("@elizaos/plugin-wallet").catch((err) => {
        // plugin-wallet is desktop/cloud-only; on mobile it is not in the bundle so
        // this import REJECTS. Cache a no-op fallback so /api/wallet/* falls through
        // to 404 instead of 500ing on every renderer poll. Desktop imports succeed,
        // so this branch never runs there. resolveOptionalPluginImportFailure keeps
        // the benign module-absent case quiet while surfacing a present-but-broken
        // plugin-wallet load (drift) as an observable warning.
        return resolveOptionalPluginImportFailure("@elizaos/plugin-wallet", err, "@elizaos/plugin-wallet");
    });
    return walletApiPromise;
}
let coreWalletApiPromise;
function getCoreWalletApi() {
    coreWalletApiPromise ??= import("./wallet.js");
    return coreWalletApiPromise;
}
function getPluginManagerForState(state) {
    const service = state.runtime?.getService("plugin_manager");
    if (isPluginManagerLike(service)) {
        return service;
    }
    return createConfigPluginManager(() => state.config);
}
/**
 * Read and parse a JSON request body with size limits and error handling.
 * Returns null (and sends a 4xx response) if reading or parsing fails.
 */
async function readJsonBody(req, res, options = {}) {
    return parseJsonBody(req, res, {
        maxBytes: MAX_BODY_BYTES,
        ...options,
    });
}
function isJsonRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isAgentBackupStateData(value) {
    if (!isJsonRecord(value))
        return false;
    return (Array.isArray(value.memories) &&
        isJsonRecord(value.config) &&
        isJsonRecord(value.workspaceFiles) &&
        isJsonRecord(value.manifest));
}
async function readBackupJsonBody(req, res) {
    try {
        const raw = await readRequestBody(req, {
            maxBytes: MAX_BACKUP_BODY_BYTES,
            tooLargeMessage: BACKUP_BODY_TOO_LARGE,
        });
        if (!raw) {
            error(res, "Request body is required", 400);
            return null;
        }
        return JSON.parse(raw);
    }
    catch (err) {
        const tooLarge = formatError(err) === BACKUP_BODY_TOO_LARGE;
        error(res, tooLarge ? BACKUP_BODY_TOO_LARGE : "Invalid backup request body", tooLarge ? 413 : 400);
        return null;
    }
}
let activeTerminalRunCount = 0;
const terminalRunIdReservations = new Map();
const TERMINAL_RUN_ID_RESERVATION_TTL_MS = 24 * 60 * 60 * 1000;
const MAX_TERMINAL_RUN_ID_RESERVATIONS = 65536;
const TERMINAL_RUN_ID_SWEEP_INTERVAL_MS = 60000;
let lastTerminalRunIdSweepAt = 0;
function formatBackupMegabytes(bytes) {
    return (bytes / (1024 * 1024)).toFixed(1);
}
function json(res, data, status = 200) {
    sendJson(res, data, status);
}
function error(res, message, status = 400) {
    sendJsonError(res, message, status);
}
async function handleBuiltinOptionalRoutes(req, res, pathname, method, runtimeAgentId) {
    if (method === "GET" && pathname === "/api/wallet/steward-status") {
        const { getWalletAddresses } = await getCoreWalletApi();
        const addresses = getWalletAddresses(runtimeAgentId);
        json(res, {
            configured: false,
            available: false,
            connected: false,
            error: "Steward wallet service is not loaded.",
            walletAddresses: {
                evm: addresses.evmAddress ?? null,
                solana: addresses.solanaAddress ?? null,
            },
            evmAddress: addresses.evmAddress ?? undefined,
            vaultHealth: "degraded",
        });
        return true;
    }
    if (pathname === "/api/browser-workspace" && method === "GET") {
        const browserPlugin = await getBrowserWorkspacePlugin();
        if (!browserPlugin) {
            json(res, { mode: "web", tabs: [] });
            return true;
        }
        json(res, await browserPlugin.getBrowserWorkspaceSnapshot());
        return true;
    }
    if (pathname === "/api/browser-workspace/command" && method === "POST") {
        const browserPlugin = await getBrowserWorkspacePlugin();
        const body = (await readJsonBody(req, res)) ?? null;
        if (!body?.subaction) {
            error(res, "subaction is required", 400);
            return true;
        }
        if (!browserPlugin) {
            error(res, "Browser workspace is not available on this platform", 503);
            return true;
        }
        json(res, await browserPlugin.executeBrowserWorkspaceCommand(body));
        return true;
    }
    if (pathname === "/api/browser-workspace/tabs" && method === "GET") {
        const browserPlugin = await getBrowserWorkspacePlugin();
        if (!browserPlugin) {
            json(res, { tabs: [] });
            return true;
        }
        json(res, { tabs: await browserPlugin.listBrowserWorkspaceTabs() });
        return true;
    }
    if (pathname === "/api/browser-workspace/tabs" && method === "POST") {
        const browserPlugin = await getBrowserWorkspacePlugin();
        if (!browserPlugin) {
            error(res, "Browser workspace is not available on this platform", 503);
            return true;
        }
        const body = (await readJsonBody(req, res)) ?? {};
        json(res, { tab: await browserPlugin.openBrowserWorkspaceTab(body) });
        return true;
    }
    const tabMatch = pathname.match(/^\/api\/browser-workspace\/tabs\/([^/]+)(?:\/(navigate|eval|show|hide|snapshot))?$/);
    if (!tabMatch) {
        return false;
    }
    const decodedTabId = decodePathComponent(tabMatch[1], res, "browser workspace tab id");
    if (decodedTabId === null)
        return true;
    const tabId = decodedTabId.trim();
    if (!tabId) {
        error(res, "Browser workspace tab id is required", 400);
        return true;
    }
    const action = tabMatch[2] ?? null;
    const browserPlugin = await getBrowserWorkspacePlugin();
    if (!browserPlugin) {
        error(res, "Browser workspace is not available on this platform", 503);
        return true;
    }
    if (!action && method === "DELETE") {
        const closed = await browserPlugin.closeBrowserWorkspaceTab(tabId);
        json(res, { closed }, closed ? 200 : 404);
        return true;
    }
    if (action === "show" && method === "POST") {
        json(res, { tab: await browserPlugin.showBrowserWorkspaceTab(tabId) });
        return true;
    }
    if (action === "hide" && method === "POST") {
        json(res, { tab: await browserPlugin.hideBrowserWorkspaceTab(tabId) });
        return true;
    }
    if (action === "snapshot" && method === "GET") {
        json(res, await browserPlugin.snapshotBrowserWorkspaceTab(tabId));
        return true;
    }
    if (action === "navigate" && method === "POST") {
        const body = (await readJsonBody(req, res)) ?? null;
        if (!body?.url) {
            error(res, "url is required", 400);
            return true;
        }
        json(res, {
            tab: await browserPlugin.navigateBrowserWorkspaceTab({
                id: tabId,
                url: body.url,
            }),
        });
        return true;
    }
    if (action === "eval" && method === "POST") {
        const body = (await readJsonBody(req, res)) ?? null;
        if (!body?.script) {
            error(res, "script is required", 400);
            return true;
        }
        // Mirror the plugin route's opt-in check: eval with a user script
        // stays off unless ELIZA_BROWSER_WORKSPACE_ALLOW_USER_SCRIPT is set.
        // The plugin route runs first when the plugin is registered; this
        // inline path serves the same route when it is not, and must not
        // skip the check. script_forbidden maps to 403, as in the route.
        try {
            browserPlugin.assertBrowserWorkspaceUserScriptAllowed(body.script, "eval", "desktop");
        }
        catch (err) {
            error(res, err instanceof Error ? err.message : "script forbidden", 403);
            return true;
        }
        json(res, {
            value: await browserPlugin.evaluateBrowserWorkspaceTab({
                id: tabId,
                script: body.script,
            }),
        });
        return true;
    }
    return false;
}
const isBlockedObjectKey = isBlockedObjectKeyFromConfig;
// ---------------------------------------------------------------------------
// Automation & agent permission helpers
// ---------------------------------------------------------------------------
const AGENT_AUTOMATION_MODES = new Set([
    "connectors-only",
    "full",
]);
function parseAgentAutomationMode(value) {
    if (typeof value !== "string")
        return null;
    const normalized = value.trim().toLowerCase();
    if (!AGENT_AUTOMATION_MODES.has(normalized)) {
        return null;
    }
    return normalized;
}
function persistAgentAutomationMode(state, mode) {
    state.agentAutomationMode = mode;
    if (!state.config.features) {
        state.config.features = {};
    }
    const features = state.config.features;
    const current = features.agentAutomation;
    const currentObject = current && typeof current === "object" && !Array.isArray(current)
        ? current
        : {};
    features.agentAutomation = {
        ...currentObject,
        enabled: true,
        mode,
    };
}
/**
 * Lazy per-process runtime operation manager. Constructed on first
 * request because it needs the per-server `state` reference + the
 * `onRestart` closure. Cached so subsequent requests see the same
 * active-op slot and execution chain.
 */
let cachedRuntimeOperationManager = null;
function getOrCreateRuntimeOperationManager(state, restartRuntime) {
    if (cachedRuntimeOperationManager)
        return cachedRuntimeOperationManager;
    const repository = getDefaultRepository();
    const healthChecker = getDefaultHealthChecker();
    const coldStrategy = createColdStrategy({
        restartRuntime: async (reason) => {
            const ok = await restartRuntime(reason);
            if (!ok)
                return null;
            return state.runtime;
        },
    });
    const hotStrategy = createHotStrategy({});
    const classifyContext = () => ({
        currentProvider: resolvePreferredProviderId(state.config),
        currentPrimaryModel: resolvePrimaryModel(state.config),
    });
    cachedRuntimeOperationManager = new DefaultRuntimeOperationManager({
        repository,
        runtime: () => state.runtime,
        classifyContext,
        classifier: defaultClassifier,
        healthChecker,
        strategies: { cold: coldStrategy, hot: hotStrategy },
    });
    return cachedRuntimeOperationManager;
}
/** API requests only the owner may make; reads of settings stay open. */
function isOwnerOnlyApiRequest(method, pathname) {
    const write = method !== "GET" && method !== "HEAD";
    const under = (base) => pathname === base || pathname.startsWith(`${base}/`);
    return (
    // The database API exposes the agent's own database over HTTP:
    // table listings and row reads, plus caller-supplied SQL that
    // runs mutations whenever the request sets readOnly to false.
    // Reads disclose the same store the writes mutate, so the whole
    // prefix is owner-only.
    under("/api/database") ||
        under("/api/memory") ||
        under("/api/memories") ||
        // The workbench overview serves every trigger's full instructions,
        // the same content the owner-gated trigger routes protect — so
        // this one aggregate route is owner-only. (The VFS sub-path is
        // gated separately and is untouched here.)
        pathname === "/api/workbench/overview" ||
        // Served by the memory handler from the same stored notes.
        under("/api/context/quick") ||
        // Whole-agent data: export/snapshot carry the memories and secrets,
        // restore/import/reset replace or wipe them.
        under("/api/snapshot") ||
        // The Discord channel-picker reads (guilds, channels, DM
        // recipients) are owner-dashboard data: the subscriptions write
        // is gated, but these GETs pass paired guest sessions through
        // with no check at any layer, so the whole prefix is owner-only.
        under("/api/discord") ||
        pathname === "/api/restore" ||
        // Voice identity reads: the speaker-centroid list, the preset
        // list, and preset sample audio. The writes on these prefixes
        // are already write-gated; the GETs were left open, and plugin
        // dispatch alone only rejects unauthenticated sessions, so a
        // paired guest session reads them. All-method, not write-only.
        under("/api/voice/profiles") ||
        under("/v1/voice/speaker-profiles") ||
        under("/api/backups") ||
        under("/api/agent/export") ||
        // View event broadcast: the frame reaches every connected
        // client and is re-emitted as agent-sourced, so a paired
        // guest must not inject UI events — the same shape as the
        // agent event injection gate.
        pathname === "/api/views/events/broadcast" ||
        // iMessage history, chats, and contacts are owner-private, and send
        // and contact CRUD mutate the owner's identity and address book.
        // The Blooio webhook stays open: it carries no session and is
        // authenticated by its HMAC signature, not the local gate.
        (under("/api/imessage") && pathname !== "/api/imessage/webhook/blooio") ||
        // Custom actions live in the owner's config, are live-registered
        // into the runtime, and their http handlers can carry the owner's
        // webhook secrets — reads disclose them, writes plant persistent
        // actions the owner's agent later invokes.
        under("/api/custom-actions") ||
        // Character experiences: distilled episodic records learned
        // from the owner's conversations (context, outcome, learning,
        // source rooms/messages). The write section gates /api/character
        // for writes, but the experience GETs were left open — the same
        // stored-content class as the owner-gated memory reads.
        under("/api/character/experiences") ||
        // Runtime logs and the security audit feed are the owner's developer /
        // ops surface: they disclose prompts, paths, errors, signing decisions,
        // and secret-token replacement metadata. DELETE /api/logs also lets a
        // caller wipe that evidence. Both paths sit behind the shared session
        // gate only, so a paired USER guest reaches them unless the whole
        // diagnostics surface is owner-only (same class as /api/discord GETs).
        // Exact /api/security/audit covers the JSON snapshot and the live SSE
        // stream on the same path. Do NOT add /api/agent/events here — that
        // REST gate alone was rejected in #37876 because the same events also
        // fan out over WebSocket to USER sockets; fix that surface separately.
        under("/api/logs") ||
        pathname === "/api/security/audit" ||
        (write &&
            [
                "import",
                "reset",
                "start",
                "stop",
                "restart",
                "pause",
                "resume",
                "autonomy",
            ].some((op) => under(`/api/agent/${op}`))) ||
        // Legacy restart endpoint: exits and restarts the whole agent process.
        (write && pathname === "/api/restart") ||
        (write &&
            (pathname.startsWith("/api/wallet/") ||
                // Remote capability-router connect: wires a caller-supplied
                // endpoint's plugins into the runtime and persists it (with token)
                // into owner config by default.
                under("/api/capability-router") ||
                // Local model management: which model serves chat/embedding,
                // routing policy, downloads, and the active model switch.
                under("/api/local-inference") ||
                // Release-channel policy: a silent flip to nightly changes what
                // the owner's next update installs. Status stays a GET read.
                under("/api/update") ||
                // MCP config writes can point the agent at an attacker-controlled
                // remote server; stdio writes are terminal-gated but not role-gated.
                under("/api/mcp") ||
                // Connector setup (Telegram, Discord, iMessage): saves, replaces or
                // clears the owner's connector credentials and sessions.
                under("/api/setup") ||
                // The app-facing runtime switch repoints the owner's text inference,
                // and a local target can start a model download. Its loopback writes
                // carry the owner's self token, so the outer request needs this gate.
                under("/api/runtime/model-switch") ||
                under("/api/config") ||
                under("/api/character") ||
                // Model selection writes into the same config the owner gate protects.
                under("/api/models/config") ||
                // Deleting a stored file removes the owner's attachments for good.
                under("/api/files") ||
                // A GitHub token lets its holder act as the owner on GitHub.
                under("/api/github") ||
                // Shell, trading, automation and computer-use permissions.
                under("/api/permissions") ||
                // Loading code into the running agent process: VFS project
                // writes, compiles, and loads, plus on-disk directory load/unload.
                under("/api/workbench/vfs") ||
                pathname === "/api/plugins/load-from-directory" ||
                pathname === "/api/plugins/unload-from-directory" ||
                // Bot tokens and allowlists of the owner's connectors. The provider's
                // OAuth callback is authenticated by its state/code, not the owner.
                (under("/api/connectors") &&
                    !/^\/api\/connectors\/[^/]+\/oauth\/callback\/?$/.test(pathname)) ||
                // Who receives the model traffic, and with which key.
                pathname === "/api/provider/switch" ||
                // Eliza Cloud connection mutations: disconnect deletes the
                // owner's persisted cloud API key, and login/persist writes a
                // caller-supplied key into it. Exact paths only, not the whole
                // /api/cloud prefix — billing, relay, and container routes are
                // a separate surface, and the GET login-status poll stays open
                // (it requires a session id only a gated POST can mint).
                pathname === "/api/cloud/disconnect" ||
                pathname === "/api/cloud/login" ||
                pathname === "/api/cloud/login/persist" ||
                // Model credentials themselves: adding, editing, deleting an
                // account, or changing the provider strategy, re-routes the
                // owner's model traffic (prompts included) under another key.
                under("/api/accounts") ||
                under("/api/providers") ||
                // Subscription OAuth start/exchange/setup-token and revoke mutate
                // the owner's model credentials and routing the same way.
                under("/api/subscription") ||
                // iMessage connector setup: a guest session could enable or
                // wipe the owner's iMessage connector config. Write-only, so
                // GET /api/setup/imessage/status stays open.
                under("/api/setup/imessage") ||
                // Meeting bots join, transcribe, bill, and stop on the owner's
                // behalf, and Zoom import spends the owner's stored token. The
                // GETs stay open: they are share-viewer routes with per-viewer
                // disclosure, not owner writes.
                under("/api/meetings"))));
}
// One process-wide governance gate shared across runtime (re)registrations, so a
// restart doesn't reset the proactive-comment cooldowns/caps (#8792).
const proactiveInteractionGate = new ProactiveInteractionGate();
function proactiveNotificationGroupKey(offer) {
    if (offer.groupKey)
        return offer.groupKey;
    const basis = (offer.deepLink || offer.title || offer.text)
        .toLowerCase()
        .replace(/[^a-z0-9:/._-]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 72);
    return `proactive-interaction:${basis || "general"}`;
}
async function notifyProactiveInteraction(rt, offer) {
    const service = rt.getService(ServiceType.NOTIFICATION);
    if (!(service instanceof NotificationService)) {
        logger.debug("[proactive-interaction] notification service unavailable; suppressing notify-lane offer");
        return;
    }
    const title = offer.title?.trim() || offer.text;
    await service.notify({
        title,
        body: title === offer.text ? undefined : offer.text,
        category: "agent",
        priority: "low",
        source: PROACTIVE_INTERACTION_SOURCE,
        deepLink: offer.deepLink,
        groupKey: proactiveNotificationGroupKey(offer),
        data: { kind: "proactive-interaction" },
    });
}
/**
 * Wire the proactive-interaction decider (#8792): subscribe to VIEW_SWITCHED and
 * route an admitted, model-judged offer into chat suggestions or low-priority
 * notifications. No-ops when disabled by config/kill-switch.
 */
function wireProactiveInteractionDecider(rt, state) {
    registerProactiveInteractionDecider(rt, {
        gate: proactiveInteractionGate,
        route: (text) => routeProactiveText(state, text, PROACTIVE_INTERACTION_SOURCE),
        notify: (offer) => notifyProactiveInteraction(rt, offer),
        shouldSuppress: () => state.activeChatTurnCount > 0,
    });
}
async function applyRuntimeRestart(state, ctx, reason, options) {
    if (ctx?.restartRequiresRuntimeDisposal) {
        options = { ...options, disposeCurrentBeforeBuild: true };
    }
    if (!ctx?.onRestart) {
        return false;
    }
    if (state.runtimeStopPromise) {
        return false;
    }
    if (state.agentState === "restarting") {
        return false;
    }
    const previousState = state.agentState;
    logger.info(`[eliza-api] Applying runtime reload: ${reason}`);
    state.agentState = "restarting";
    state.startup = { ...state.startup, phase: "restarting" };
    state.broadcastStatus?.();
    try {
        const previousRuntime = state.runtime;
        const newRuntime = await ctx.onRestart(options);
        if (!newRuntime) {
            if (ctx.restartRequiresRuntimeDisposal)
                state.runtime = null;
            state.agentState = options?.disposeCurrentBeforeBuild
                ? "error"
                : previousState;
            if (options?.disposeCurrentBeforeBuild) {
                state.startup = {
                    ...state.startup,
                    phase: "error",
                    lastError: "Runtime replacement failed after the current runtime was disposed",
                    lastErrorAt: Date.now(),
                };
            }
            state.broadcastStatus?.();
            return false;
        }
        registerRuntimeBuiltinViews(newRuntime);
        await quiesceRuntimeBeforeReplacement(previousRuntime, newRuntime);
        state.runtime = newRuntime;
        state.chatConnectionReady = null;
        state.chatConnectionPromise = null;
        state.agentState = "running";
        state.agentName =
            newRuntime.character.name ?? resolveDefaultAgentName(state.config);
        state.model = detectRuntimeModel(newRuntime, state.config);
        state.startedAt = Date.now();
        state.pendingRestartReasons = [];
        ctx.onRuntimeSwapped?.();
        try {
            await ctx.onRuntimeActivated?.(previousRuntime, newRuntime);
        }
        catch (err) {
            // error-policy:J6 the replacement is already active; host cleanup must
            // be observable without reverting a healthy runtime.
            newRuntime.reportError("api.restart.activateRuntime", err);
            logger.warn(`[eliza-api] Post-swap runtime cleanup failed: ${err instanceof Error ? err.message : String(err)}`);
        }
        state.broadcastStatus?.();
        return true;
    }
    catch (err) {
        // error-policy:J1 the runtime operation records a failed restart receipt.
        logger.warn(`[eliza-api] Runtime reload failed: ${err instanceof Error ? err.message : String(err)}`);
        // A failed replacement is an unavailable host, never a live disposed runtime.
        if (ctx.restartRequiresRuntimeDisposal)
            state.runtime = null;
        state.agentState = options?.disposeCurrentBeforeBuild
            ? "error"
            : previousState;
        if (options?.disposeCurrentBeforeBuild) {
            state.startup = {
                ...state.startup,
                phase: "error",
                lastError: "Runtime replacement failed after the current runtime was disposed",
                lastErrorAt: Date.now(),
            };
        }
        state.broadcastStatus?.();
        return false;
    }
}
// Wallet imports/generation share process environment and the host vault.
// Keep rollback inside the same ownership interval as durable config loading.
let walletKeyMutationTail = Promise.resolve();
async function acquireWalletKeyMutation() {
    const previous = walletKeyMutationTail;
    let release;
    walletKeyMutationTail = new Promise((resolve) => {
        release = resolve;
    });
    await previous;
    return release;
}
async function handleRequest(req, res, state, ctx) {
    // Admission and host middleware may await after the dispatcher selects us.
    // Revalidate the original owner before creating a scope for the current runtime.
    const parentScope = getViewClientScope();
    if (getAuthenticatedInProcessAuthorization(req) &&
        (parentScope?.hostKey !== state ||
            !parentScope.request ||
            parentScope.request.signal.aborted ||
            parentScope.request.runtime !== state.runtime)) {
        error(res, "Original authenticated request is no longer active", 403);
        return;
    }
    const rawClientId = req.headers["x-elizaos-client-id"] ?? req.headers["x-eliza-client-id"];
    const clientId = normalizeWsClientId(Array.isArray(rawClientId) ? rawClientId[0] : rawClientId);
    const requestController = new AbortController();
    const request = {
        runtime: state.runtime,
        signal: requestController.signal,
    };
    const scope = {
        hostKey: state,
        ...(clientId ? { clientId } : {}),
        request,
    };
    const retire = () => {
        requestController.abort(new DOMException("The originating HTTP request closed", "AbortError"));
    };
    req.once("aborted", retire);
    res.once("close", retire);
    return runWithViewClient(scope, async () => {
        try {
            await handleRequestForViewClient(req, res, state, ctx);
        }
        finally {
            retire();
            req.removeListener("aborted", retire);
            res.removeListener("close", retire);
        }
    });
}
async function handleRequestForViewClient(req, res, state, ctx) {
    bindViewRequestHost(req, state);
    const authenticationRuntime = () => ctx?.getAuthenticationRuntime
        ? ctx.getAuthenticationRuntime()
        : state.runtime;
    const method = req.method ?? "GET";
    let url;
    try {
        url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
    }
    catch {
        error(res, "Invalid request URL", 400);
        return;
    }
    const pathname = url.pathname;
    const isAuthEndpoint = pathname.startsWith("/api/auth/");
    const isHealthEndpoint = method === "GET" && pathname === "/api/health";
    let isCloudProvisionedContainer = () => false;
    let handleCloudStatusRoutes = async (_args) => false;
    if (
    // plugin-elizacloud is desktop/cloud-only; on mobile its dynamic import
    // does not resolve and the resulting await stalls the whole request (the
    // /api/cloud, /api/coding-agents, and cloud-first-run paths then hang).
    // Skip the import on mobile — the default no-op cloud helpers above keep
    // isCloudProvisioned=false (correct for a local mobile agent) and let the
    // request fall through to its normal handler/404.
    !isMobilePlatform() &&
        (pathname === "/api/first-run/status" ||
            pathname.startsWith("/api/cloud") ||
            pathname.startsWith("/api/coding-agents"))) {
        const cloudApi = await getOptionalPluginApi("cloud");
        isCloudProvisionedContainer = cloudApi.isCloudProvisionedContainer;
        handleCloudStatusRoutes = cloudApi.handleCloudStatusRoutes;
    }
    const isCloudProvisioned = isCloudProvisionedContainer();
    const isCloudFirstRunStatusEndpoint = method === "GET" &&
        pathname === "/api/first-run/status" &&
        isCloudProvisioned;
    // app authenticates the session-tier dashboard reads
    // (/api/cloud/status, /api/cloud/credits) before forwarding into the agent
    // server. They need no dedicated exemption here: app's forwarded
    // requests arrive over trusted loopback and already pass `isAuthorized`,
    // while exempting the paths let ANY unauthenticated caller who could reach
    // the port (LAN/wildcard bind) read the owner's cloud userId, organizationId,
    // and live credit balance (W1-010).
    const isAuthProtectedPath = isAuthProtectedRoute(pathname);
    const requestOrigin = typeof req.headers.origin === "string" ? req.headers.origin : undefined;
    // A same-origin navigation commonly omits Origin. When an Origin is present,
    // ambient cookie authority is available only to the narrower credentialed
    // CORS trust set; arbitrary reflected origins remain bearer-only.
    const allowHostCookieAuth = requestOrigin === undefined || isCredentialedCorsOrigin(requestOrigin);
    let hostSessionAuthorization = {
        ok: false,
        role: "NONE",
    };
    let hostSessionAuthorizationAttempted = false;
    const resolveHostSessionAuthorization = async () => {
        if (hostSessionAuthorizationAttempted)
            return hostSessionAuthorization;
        hostSessionAuthorizationAttempted = true;
        const bridge = getAgentHostBridge();
        const resolveAuthorization = bridge.resolveHttpRequestAuthorization;
        const inherited = getAuthenticatedInProcessAuthorization(req);
        if (inherited)
            hostSessionAuthorization = inherited;
        else if (typeof resolveAuthorization === "function") {
            hostSessionAuthorization = await resolveAuthorization(req, authenticationRuntime(), {
                allowCookieAuth: allowHostCookieAuth,
                allowTrustedLocalBypass: !requiresDeviceIdentity(req, pathname),
                allowBearerAuth: true,
            });
        }
        else {
            const authorize = bridge.isHttpRequestAuthorized;
            // A legacy boolean-only bridge cannot separate cookie from bearer
            // authority. Do not consult it for an explicitly untrusted origin;
            // standalone bearer schemes are evaluated by the normal server gates.
            const authorized = allowHostCookieAuth && typeof authorize === "function"
                ? await authorize(req, authenticationRuntime())
                : false;
            // Legacy boolean-only hosts can still pass the coarse request gate, but
            // cannot claim OWNER authority for a sensitive account-selection action.
            hostSessionAuthorization = {
                ok: authorized,
                role: authorized ? "USER" : "NONE",
            };
        }
        const scope = getViewClientScope();
        if (scope?.hostKey === state &&
            scope.request &&
            !scope.request.signal.aborted &&
            scope.request.runtime === state.runtime) {
            // Keep the same verified caller used by inbox and view routes, including
            // standalone root tokens when no embedding host installs an auth bridge.
            const requestAuthorization = resolveInboxRequestAuthorization(req, method, pathname, hostSessionAuthorization);
            scope.request.authorization = Object.freeze({
                ...requestAuthorization,
                ...(requestAuthorization.externalIdentity
                    ? {
                        externalIdentity: Object.freeze({
                            ...requestAuthorization.externalIdentity,
                        }),
                    }
                    : {}),
            });
        }
        return hostSessionAuthorization;
    };
    const isHostSessionAuthorized = async () => (await resolveHostSessionAuthorization()).ok;
    // A presented gateway proof is an exclusive authentication mode. A valid
    // container bearer must never rescue an invalid/unsupported owner proof.
    if (req.headers["x-eliza-cloud-owner-proof"] !== undefined) {
        const verified = await resolveHostSessionAuthorization();
        if (!verified.ok || !verified.externalIdentity || !verified.identityId) {
            json(res, { error: "Verified Cloud owner session required" }, 401);
            return;
        }
    }
    const canonicalizeRestartReason = (reason) => {
        if (reason === "primary-changed" ||
            reason === "cloud-refreshed" ||
            reason === "Wallet configuration updated") {
            return "Wallet configuration updated";
        }
        return reason;
    };
    const scheduleRuntimeRestart = (reason) => {
        const canonicalReason = canonicalizeRestartReason(reason);
        if (state.pendingRestartReasons.length >= 50) {
            // Prevent unbounded growth — keep only first entry + latest
            state.pendingRestartReasons.splice(1, state.pendingRestartReasons.length - 1);
        }
        if (!state.pendingRestartReasons.includes(canonicalReason)) {
            state.pendingRestartReasons.push(canonicalReason);
        }
        logger.info(`[eliza-api] Restart required: ${canonicalReason} (${state.pendingRestartReasons.length} pending)`);
        state.broadcastWs?.({
            type: "restart-required",
            reasons: [...state.pendingRestartReasons],
        });
    };
    const restartRuntime = (reason, options) => applyRuntimeRestart(state, ctx, reason, options);
    // ── DNS rebinding protection ──────────────────────────────────────────
    // Reject requests whose Host header doesn't match a known loopback
    // hostname.  Without this check an attacker can rebind their domain's
    // DNS to 127.0.0.1 and read the unauthenticated localhost API from a
    // malicious page.
    if (!isAllowedHost(req)) {
        const incomingHost = req.headers.host ?? "your-hostname";
        json(res, {
            error: "Forbidden — invalid Host header",
            hint: `To allow this host, set ELIZA_ALLOWED_HOSTS=${incomingHost} in your environment, or access via http://localhost`,
            docs: "https://docs.eliza.ai/configuration#allowed-hosts",
        }, 403);
        return;
    }
    if (!applyCors(req, res, pathname)) {
        json(res, { error: "Origin not allowed" }, 403);
        return;
    }
    // Cloud SSO popup handoff: GET /pair?token=X must short-circuit BEFORE the
    // static-UI catch-all, otherwise the SPA index.html is served and the user
    // ends up on the password screen.
    //
    // The cloud-SSO handoff route is owned by the app host and injected
    // downward through the agent host bridge (see ../runtime/host-bridge.ts) so
    // agent never imports `@elizaos/app`. A local on-device agent never
    // legitimately serves it, so the bridge omits the handler and the request
    // falls through to the normal pipeline.
    const handleCloudPairRoute = getAgentHostBridge().handleCloudPairRoute;
    if ((typeof handleCloudPairRoute === "function" &&
        (await handleCloudPairRoute(req, res))) ||
        (await handleStandaloneCloudPairRoute(req, res))) {
        return;
    }
    // The packaged desktop runs the agent listener directly, but app owns
    // its browser-session store. The host consumes the one-shot local socket
    // proof here; its handler enforces loopback peer+Host, originlessness,
    // socket ownership, and socket mode before minting anything.
    const handleDesktopAuthBootstrapRoute = getAgentHostBridge().handleDesktopAuthBootstrapRoute;
    if (typeof handleDesktopAuthBootstrapRoute === "function" &&
        (await handleDesktopAuthBootstrapRoute(req, res, state.runtime))) {
        return;
    }
    const handleHostAuthRoutes = getAgentHostBridge().handleAuthRoutes;
    if (handleHostAuthRoutes &&
        (await handleHostAuthRoutes(req, res, state.runtime)))
        return;
    // Serve dashboard static assets before the auth gates. serveStaticUi already
    // refuses /api/, /v1/, and /ws paths, so API endpoints remain protected
    // while steward-managed containers can still reach the built-in dashboard.
    if (method === "GET" || method === "HEAD") {
        if (serveStaticUi(req, res, pathname))
            return;
        // Chat media (uploaded + generated). Content-addressed sha256 filenames act
        // as unguessable capabilities, so media loads from <img>/<audio> without an
        // auth header — same rationale as static assets above. The protected
        // profile serves media only after the auth gate below.
        if (!isMediaAuthRequired() && serveMediaFile(req, res, pathname))
            return;
    }
    // ── Runtime-mode visibility gate ────────────────────────────────────────
    // Enforced here, in the server every host shares, so the bare agent
    // (`bun run start`) honors the same mode contract as the app wrapper:
    // routes outside the active runtime mode return 404 before auth runs
    // (hidden, not probeable). OPTIONS is exempt so CORS preflight keeps its
    // unconditional 204 below.
    if (method !== "OPTIONS" &&
        (await handleRuntimeModePreDispatch(req, res, state.runtime, ctx?.hostRuntimeMode))) {
        return;
    }
    // ── Per-session request-storm cap ───────────────────────────────────────
    // Before auth resolution and route handlers: a bearer session sustaining
    // more than its polling budget gets 429 + Retry-After (see
    // request-storm-cap.ts for the live incident this guards against).
    if (maybeCapRequestStorm(req, res, pathname)) {
        return;
    }
    if (method !== "OPTIONS" &&
        isAuthProtectedPath &&
        !isAuthEndpoint &&
        !isHealthEndpoint &&
        !isCloudFirstRunStatusEndpoint &&
        !isPublicRuntimePluginRoute({
            runtime: state.runtime,
            method,
            pathname,
        }) &&
        !(await isHostSessionAuthorized()) &&
        !isAuthorized(req) &&
        !isBoundaryRoleAuthorized(req, method, pathname)) {
        json(res, { error: "Unauthorized" }, 401);
        return;
    }
    // Protected profile: authenticated media (same-origin <img>/<audio> GETs
    // carry the session cookie, which the gate above accepts without CSRF).
    if ((method === "GET" || method === "HEAD") &&
        isMediaAuthRequired() &&
        serveMediaFile(req, res, pathname)) {
        return;
    }
    // Complete trajectory inputs and outputs belong to the owner's developer
    // surface. Enforce this before forwarding or any plugin route can dispatch.
    if (method !== "OPTIONS" &&
        (pathname === "/api/trajectories" ||
            pathname.startsWith("/api/trajectories/")) &&
        !isTrajectoryOwnerRequest(req, method, pathname, await resolveHostSessionAuthorization())) {
        json(res, { error: "Owner role required" }, 403);
        return;
    }
    // A paired USER session passes the shared gate above. Wallet writes sign,
    // broadcast or replace the owner's keys; config and character writes change
    // what the agent runs and who it sends model traffic to; memories are the
    // owner's private store. Require the owner before any of them dispatch.
    // Once setup is persisted, onboarding rewrites the same owner config,
    // credentials and character, so it is owner-only too. Before setup it stays
    // open, like GET /api/wallet/keys.
    if (method !== "OPTIONS" &&
        (isOwnerOnlyApiRequest(method, pathname) ||
            (method === "POST" &&
                pathname === "/api/first-run" &&
                hasPersistedFirstRunState(state.config))) &&
        !isTrajectoryOwnerRequest(req, method, pathname, await resolveHostSessionAuthorization())) {
        json(res, { error: "Owner role required" }, 403);
        return;
    }
    let automationOwnerEntityId;
    // Trigger definitions and the unified automation feed contain owner-private
    // prompts. Resolve a presented credential without ambient loopback promotion:
    // a paired USER bearer stays USER even when the request arrives locally.
    if (method !== "OPTIONS" &&
        (pathname.startsWith("/api/triggers") || pathname === "/api/automations")) {
        const cookie = req.headers.cookie;
        const registeredAccess = resolveRegisteredTokenRoleAccess(req);
        const hasPresentedCredential = [
            "authorization",
            "x-eliza-token",
            "x-elizaos-token",
            "x-waifu-chat-access-token",
            "x-api-key",
            "x-api-token",
            "x-server-token",
        ].some((name) => Object.hasOwn(req.headers, name)) ||
            (typeof cookie === "string" && /(?:^|;\s*)eliza_session=/.test(cookie)) ||
            registeredAccess !== null;
        const strictResolver = getAgentHostBridge().resolveHttpRequestAuthorization;
        const ownerAuthorization = hasPresentedCredential
            ? strictResolver
                ? await strictResolver(req, authenticationRuntime(), {
                    allowCookieAuth: allowHostCookieAuth,
                    allowTrustedLocalBypass: false,
                    allowBearerAuth: true,
                })
                : { ok: false, role: "NONE" }
            : await resolveHostSessionAuthorization();
        if (!isTrajectoryOwnerRequest(req, method, pathname, ownerAuthorization, !hasPresentedCredential)) {
            json(res, { error: "Owner role required" }, 403);
            return;
        }
        if (state.runtime) {
            const localOwnerEntityId = resolveOwnerEntityIdOrDefault(state.runtime);
            const trustedAccess = ownerAuthorization.ok
                ? resolveHostSessionAccessContext(ownerAuthorization, state.runtime)
                : resolveHttpAccessContext(req);
            const requesterEntityId = trustedAccess?.requesterEntityId ?? localOwnerEntityId;
            // Legacy Node plugin routes cannot carry a distinct requester principal.
            // Keep this owner-only local surface closed to such principals rather than
            // silently reading or mutating the canonical local owner's records.
            if (requesterEntityId !== localOwnerEntityId) {
                json(res, { error: "Owner role required" }, 403);
                return;
            }
            automationOwnerEntityId = requesterEntityId;
        }
    }
    // Remote-mode cloud mutations are forwarded only after the request passes
    // the normal API auth gate; the forwarder attaches the controller's target
    // token, so pre-auth forwarding would let an unauthenticated caller mutate
    // the controlled target.
    if (method !== "OPTIONS" &&
        (await handleRuntimeModeRemoteForward(req, res, ctx?.hostRuntimeMode))) {
        return;
    }
    // CORS preflight
    if (method === "OPTIONS") {
        res.statusCode = 204;
        res.end();
        return;
    }
    if (method === "GET" && pathname === "/api/backups") {
        if (!state.runtime) {
            error(res, "Runtime not ready", 503);
            return;
        }
        try {
            const backups = await listLocalAgentBackups(state.runtime.agentId);
            json(res, { backups });
        }
        catch (err) {
            // error-policy:J1 backup listing can surface filesystem paths in
            // exceptions; keep the original diagnostic in the structured log.
            logger.error({ err }, "[agent-backup] Local backup list failed");
            error(res, "Backup list failed", 500);
        }
        return;
    }
    if (method === "POST" && pathname === "/api/backups") {
        if (!state.runtime) {
            error(res, "Runtime not ready", 503);
            return;
        }
        try {
            const backup = await createLocalAgentBackup(state.runtime, state.config);
            json(res, { backup });
        }
        catch (err) {
            if (err instanceof AgentSnapshotBudgetExceededError) {
                // error-policy:J1 a deterministic size refusal is actionable: retrying
                // the same state cannot succeed, so answer 413 with the typed budget
                // figures (no paths or database diagnostics) instead of a generic 500.
                logger.warn({ err }, "[agent-backup] Local backup refused: agent state exceeds the backup size limit");
                const unit = err.stage === "file count" ? "files" : "bytes";
                const postgres = err.streamedBackupUnsupported === "postgres";
                const base = unit === "files"
                    ? `Agent state has too many files for a local backup (${err.observedBytes} files; the limit is ${err.limitBytes}).`
                    : `Agent state is too large for a local backup (${formatBackupMegabytes(err.observedBytes)} MB; the limit is ${formatBackupMegabytes(err.limitBytes)} MB).`;
                json(res, {
                    error: postgres
                        ? `${base} The streamed (v2) local backup that handles larger agents supports PGlite databases only, and this agent uses Postgres. Retrying will not help; back up the Postgres database with its own tooling.`
                        : `${base} Retrying will not help until ${unit === "files" ? "files are removed from the agent's state" : "the agent's state is smaller"}.`,
                    ...(postgres ? { streamedBackupSupported: false } : {}),
                    code: err.code,
                    stage: err.stage,
                    unit,
                    observed: err.observedBytes,
                    limit: err.limitBytes,
                    retryable: false,
                }, 413);
                return;
            }
            // error-policy:J1 backup adapters can include filesystem and database
            // diagnostics in exceptions; keep the original in the redacting logger.
            logger.error({ err }, "[agent-backup] Local backup failed");
            error(res, "Backup failed", 500);
        }
        return;
    }
    if (method === "POST" && pathname === "/api/backups/restore") {
        if (!state.runtime) {
            error(res, "Runtime not ready", 503);
            return;
        }
        const body = await readBackupJsonBody(req, res);
        if (!body)
            return;
        const bodyRecord = isJsonRecord(body) ? body : null;
        const fileName = typeof bodyRecord?.fileName === "string" ? bodyRecord.fileName : null;
        if (!fileName) {
            error(res, "fileName is required", 400);
            return;
        }
        try {
            const result = await restoreLocalAgentBackup(state.runtime, fileName);
            json(res, result);
        }
        catch (err) {
            // error-policy:J1 decryption, filesystem, and database diagnostics stay
            // internal rather than becoming a public backup oracle.
            logger.error({ err }, "[agent-backup] Local backup restore failed");
            error(res, "Backup restore failed", 500);
        }
        return;
    }
    if (method === "POST" && pathname === "/api/snapshot") {
        if (!state.runtime) {
            error(res, "Runtime not ready", 503);
            return;
        }
        try {
            const snapshot = await createAgentSnapshot(state.runtime, state.config);
            await writeAgentBackupJsonResponse(res, snapshot);
        }
        catch (err) {
            const message = formatError(err);
            if (err instanceof AgentBackupClientDisconnectedError ||
                message === "Agent backup response stream failed") {
                // The download transport died mid-stream (client abort or socket
                // error). The response is already committed and the socket is gone;
                // treat it like the v2 capture boundary's 499/ephemeral path rather
                // than logging a server fault.
                logger.warn({ err: message }, "[agent-backup] Snapshot download aborted");
                return;
            }
            if (message === PGLITE_SNAPSHOT_UNAVAILABLE_TRANSIENT) {
                // Transient teardown race (PGlite closing) — 503 so the caller retries
                // or defers instead of tripping the fail-closed restart gate on a 500
                // (2026-08-11 fleet incident: 500 here wedged healthy agent restarts).
                logger.warn({ err: message }, "[agent-backup] Snapshot temporarily unavailable");
                json(res, {
                    error: PGLITE_SNAPSHOT_UNAVAILABLE_TRANSIENT,
                    code: PGLITE_SNAPSHOT_UNAVAILABLE_TRANSIENT_CODE,
                }, 503);
                return;
            }
            logger.error({ err: message }, "[agent-backup] Snapshot failed");
            if (res.headersSent) {
                // error-policy:J1 Streaming may fail after the response is committed;
                // terminate that transport instead of appending a false JSON error.
                res.destroy(new Error("Snapshot stream failed", { cause: err }));
                return;
            }
            // error-policy:J1 the snapshot boundary preserves diagnostics in the
            // server log while exposing only a stable failure to the API caller.
            error(res, "Snapshot failed", 500);
        }
        return;
    }
    if (method === "POST" && pathname === "/api/snapshot/v2") {
        if (!state.runtime) {
            error(res, "Runtime not ready", 503);
            return;
        }
        await handleAgentBackupV2SnapshotRequest(req, res, {
            runtime: state.runtime,
            config: state.config,
        });
        return;
    }
    if (method === "POST" && pathname === "/api/restore") {
        if (!state.runtime) {
            error(res, "Runtime not ready", 503);
            return;
        }
        const body = await readBackupJsonBody(req, res);
        if (!body)
            return;
        if (!isAgentBackupStateData(body)) {
            error(res, "Invalid backup snapshot payload", 400);
            return;
        }
        try {
            const result = await restoreAgentSnapshot(state.runtime, body);
            const restarted = await restartRuntime("agent backup restored", {
                disposeCurrentBeforeBuild: true,
            });
            if (!restarted) {
                throw new Error("Backup restored, but the runtime could not restart on the restored database");
            }
            json(res, { ...result, requiresRestart: false });
        }
        catch (err) {
            logger.error({
                err: err instanceof Error ? err.message : String(err),
            }, "[agent-backup] Restore failed");
            error(res, err instanceof Error ? err.message : "Restore failed", 500);
        }
        return;
    }
    if ((pathname.startsWith("/api/local-inference") ||
        pathname.startsWith("/api/tts/local-inference") ||
        pathname.startsWith("/api/asr/local-inference") ||
        pathname.startsWith("/api/voice/audio-frames") ||
        pathname === "/api/voice/native-pcm-turn" ||
        pathname === "/api/voice/playback-frames" ||
        pathname === "/api/voice/aec-capture") &&
        (await (async () => {
            const localInferenceServerApi = await getLocalInferenceServerApi();
            if (typeof localInferenceServerApi.handleLocalInferenceRoutes ===
                "function" &&
                (await localInferenceServerApi.handleLocalInferenceRoutes(req, res))) {
                return true;
            }
            // WebView → agent PCM transport for live on-device speaker diarization.
            if (localInferenceServerApi.handleLiveDiarizationRoute &&
                (await localInferenceServerApi.handleLiveDiarizationRoute(req, res, {
                    current: state.runtime,
                }))) {
                return true;
            }
            if (localInferenceServerApi.handleLocalInferenceAsrRoute &&
                (await localInferenceServerApi.handleLocalInferenceAsrRoute(req, res, {
                    current: state.runtime,
                }))) {
                return true;
            }
            return Boolean(localInferenceServerApi.handleLocalInferenceTtsRoute &&
                (await localInferenceServerApi.handleLocalInferenceTtsRoute(req, res, {
                    current: state.runtime,
                })));
        })())) {
        return;
    }
    if (await handleBackgroundTasksRoute({
        req,
        res,
        method,
        pathname,
        state,
        json,
    })) {
        return;
    }
    if (method === "POST" && pathname === "/api/provider/switch") {
        if (await handleProviderSwitchRoutes({
            req,
            res,
            method,
            pathname,
            state,
            json,
            error,
            readJsonBody,
            saveElizaConfig,
            scheduleRuntimeRestart,
            runtimeOperationManager: getOrCreateRuntimeOperationManager(state, restartRuntime),
        })) {
            return;
        }
    }
    if (await handleAuthRoutes({
        req,
        res,
        method,
        pathname,
        readJsonBody,
        json,
        error,
        pairingEnabled,
        ensurePairingCode,
        normalizePairingCode,
        rateLimitPairing,
        getPairingExpiresAt,
        getPairingInstanceId,
        clearPairing,
    })) {
        return;
    }
    if (await handleSubscriptionRoutes({
        req,
        res,
        method,
        pathname,
        state,
        readJsonBody,
        json,
        error,
        saveConfig: saveElizaConfig,
        loadSubscriptionAuth: async () => (await import("@elizaos/auth/auth")),
    })) {
        return;
    }
    if (await handleAccountsRoutes({
        req,
        res,
        method,
        pathname,
        readJsonBody,
        json,
        error,
        state: { config: state.config, runtime: state.runtime },
        saveConfig: saveElizaConfig,
    })) {
        return;
    }
    if (await handleHealthRoutes({
        composeStatus: ctx?.composeStatus,
        req,
        res,
        method,
        pathname,
        url,
        state,
        json,
        error,
    })) {
        return;
    }
    const firstRunGetWalletAddresses = pathname === "/api/wallet/keys"
        ? (await getCoreWalletApi()).getWalletAddresses
        : null;
    const releaseFirstRunWalletKeys = (method === "GET" && pathname === "/api/wallet/keys") ||
        (method === "POST" && pathname === "/api/first-run")
        ? await acquireWalletKeyMutation()
        : undefined;
    try {
        if (await handleFirstRunRoutes({
            req,
            res,
            method,
            pathname,
            url,
            state,
            json,
            error,
            readJsonBody,
            isCloudProvisionedContainer,
            hasPersistedFirstRunState,
            ensureWalletKeysInEnvAndConfig,
            getWalletAddresses: firstRunGetWalletAddresses
                ? () => firstRunGetWalletAddresses(state.runtime?.agentId)
                : () => ({
                    evmAddress: null,
                    solanaAddress: null,
                }),
            pickRandomNames,
            getStylePresets,
            getProviderOptions,
            getCloudProviderOptions,
            getModelOptions,
            getInventoryProviderOptions,
            resolveConfiguredCharacterLanguage,
            normalizeCharacterLanguage,
            readUiLanguageHeader,
            applyFirstRunVoicePreset,
            saveElizaConfig,
        })) {
            return;
        }
    }
    finally {
        releaseFirstRunWalletKeys?.();
    }
    // POST /api/first-run is now handled by first-run-routes.ts above.
    if (await handleAgentLifecycleRoutes({
        req,
        res,
        method,
        pathname,
        state,
        error,
        json,
        readJsonBody,
        // Lets POST /api/agent/start boot a runtime from the runtime-less state
        // (fresh-install deferred boot / stopped host) instead of fake-flipping
        // the reported state to "running" with nothing behind it.
        onRestart: ctx?.onRestart ?? undefined,
        onStop: ctx?.onStop ?? undefined,
        onRuntimeSwapped: ctx?.onRuntimeSwapped,
        onRuntimeActivated: ctx?.onRuntimeActivated,
    })) {
        return;
    }
    if (pathname.startsWith("/api/triggers")) {
        const { handleTriggerRoutes } = await getOptionalPluginApi("workflow");
        const triggerHandled = await handleTriggerRoutes({
            req,
            res,
            method,
            pathname,
            runtime: state.runtime,
            ownerEntityId: automationOwnerEntityId,
            resolvePromptDeliveryRoom: (runtime) => resolvePromptDeliveryRoom(state, runtime),
            localOwnerEntityId: state.runtime
                ? resolveOwnerEntityIdOrDefault(state.runtime)
                : undefined,
            readJsonBody,
            json,
            error,
            executeTriggerTask,
            getTriggerHealthSnapshot,
            getTriggerLimit,
            listTriggerTasks,
            readTriggerConfig,
            readTriggerRuns,
            taskToTriggerSummary,
            triggersFeatureEnabled,
            buildTriggerConfig,
            buildTriggerMetadata,
            normalizeTriggerDraft,
            DISABLED_TRIGGER_INTERVAL_MS,
            TRIGGER_TASK_NAME,
            TRIGGER_TASK_TAGS: [...TRIGGER_TASK_TAGS],
        });
        if (triggerHandled) {
            return;
        }
    }
    // Knowledge routes (/api/knowledge/*) are now provided by the
    // @elizaos/app-knowledge plugin via the runtime route registry.
    if (pathname.startsWith("/api/memory") ||
        pathname.startsWith("/api/memories") ||
        pathname === "/api/context/quick") {
        const memoryHandled = await handleMemoryRoutes({
            req,
            res,
            method,
            pathname,
            url,
            runtime: state.runtime,
            agentName: state.agentName,
            readJsonBody,
            json,
            error,
        });
        if (memoryHandled)
            return;
    }
    if (await handleAgentAdminRoutes({
        req,
        res,
        method,
        pathname,
        state,
        restartRequiresRuntimeDisposal: ctx?.restartRequiresRuntimeDisposal,
        onRestart: ctx?.onRestart ?? undefined,
        onRuntimeSwapped: ctx?.onRuntimeSwapped,
        onRuntimeActivated: ctx?.onRuntimeActivated,
        json,
        error,
        resolveStateDir,
        stateDirExists: fs.existsSync,
        removeStateDir: (resolvedState) => {
            fs.rmSync(resolvedState, { recursive: true, force: true });
        },
    })) {
        return;
    }
    if (await handleAgentTransferRoutes({
        req,
        res,
        method,
        pathname,
        state,
        readJsonBody,
        json,
        error,
        exportAgent,
        estimateExportSize,
        importAgent,
        isAgentExportError: (err) => err instanceof AgentExportError,
    })) {
        return;
    }
    if (await handleCharacterRoutes({
        req,
        res,
        method,
        pathname,
        state,
        readJsonBody,
        json,
        error,
        pickRandomNames,
        saveConfig: saveElizaConfig,
        validateCharacter: (body) => CharacterSchema.safeParse(body),
    })) {
        return;
    }
    // Compatibility route used by legacy health probes and desktop name lookup.
    if (method === "GET" && pathname === "/api/agents") {
        const runtimeAgentId = typeof state.runtime?.agentId === "string" &&
            state.runtime.agentId.trim().length > 0
            ? state.runtime.agentId.trim()
            : null;
        const configuredAgentId = typeof state.config.agents?.list?.[0]?.id === "string" &&
            state.config.agents.list[0].id.trim().length > 0
            ? state.config.agents.list[0].id.trim()
            : null;
        const agentName = state.runtime?.character.name?.trim() ||
            state.agentName.trim() ||
            "Eliza";
        json(res, {
            agents: [
                {
                    id: runtimeAgentId ??
                        configuredAgentId ??
                        "00000000-0000-0000-0000-000000000000",
                    name: agentName,
                    status: state.agentState,
                },
            ],
        });
        return;
    }
    if (await handleModelsRoutes({
        req,
        res,
        method,
        pathname,
        url,
        json,
        providerCachePath,
        getOrFetchProvider,
        getOrFetchAllProviders,
        resolveModelsCacheDir,
        pathExists: fs.existsSync,
        readDir: fs.readdirSync,
        unlinkFile: fs.unlinkSync,
        joinPath: path.join,
    })) {
        return;
    }
    // Gate on the exact path before building the context so the runtime
    // operation manager is not instantiated on unrelated requests.
    if (pathname === "/api/models/config") {
        if (await handleModelConfigRoutes({
            req,
            res,
            method,
            pathname,
            json,
            readJsonBody,
            state: { config: state.config, runtime: state.runtime },
            saveElizaConfig,
            runtimeOperationManager: getOrCreateRuntimeOperationManager(state, restartRuntime),
        })) {
            return;
        }
    }
    if (await handleRegistryRoutes({
        req,
        res,
        method,
        pathname,
        url,
        json,
        error,
        getPluginManager: () => getPluginManagerForState(state),
        getLoadedPluginNames: () => state.runtime?.plugins.map((plugin) => plugin.name) ?? [],
        getBundledPluginIds: () => getReleaseBundledPluginIds(),
        classifyRegistryPluginRelease,
    })) {
        return;
    }
    if (await handleRemoteCapabilityRoutes({
        req,
        res,
        method,
        pathname,
        runtime: state.runtime,
        config: state.config,
        readJsonBody,
        saveConfig: (config) => saveElizaConfig(config),
        persistConfigEnv,
        json,
        error,
    })) {
        return;
    }
    if (handlePluginInventoryRoutes({ method, pathname, res, state, json })) {
        return;
    }
    if ((pathname === "/api/secrets" || pathname.startsWith("/api/plugins/")) &&
        (await handlePluginManagementRoutes({
            req,
            res,
            method,
            pathname,
            state,
            readJsonBody,
            json,
            error,
            getPlugins: async () => getPluginInventory(state),
            isOwner: isTrajectoryOwnerRequest(req, method, pathname, await resolveHostSessionAuthorization()),
            scheduleRuntimeRestart,
            restartRuntime,
        })))
        return;
    // Live-load a plugin from an on-disk directory into the running runtime. This
    // is what makes a freshly scaffolded/edited local plugin (VIEWS/APP create)
    // actually appear without an agent restart — its views register via
    // runtime.registerPlugin. Must run BEFORE the generic /api/plugins/* handler.
    if (await handlePluginDirectoryRoutes({
        req,
        res,
        method,
        pathname,
        state,
        readJsonBody,
        json,
        error,
    })) {
        return;
    }
    // Unload a plugin previously live-loaded from a directory (the symmetric
    // counterpart to load-from-directory). Directly-registered plugins are not
    // known to the plugin-manager, so /api/plugins/uninstall can't remove them —
    // this delegates to runtime.unloadPlugin, which also deregisters its views.
    if (method === "POST" && pathname === "/api/plugins/unload-from-directory") {
        if (!state.runtime) {
            error(res, "Agent runtime is not available", 503);
            return;
        }
        const body = await readJsonBody(req, res);
        if (body === null)
            return;
        const pluginName = typeof body.pluginName === "string" ? body.pluginName.trim() : "";
        if (!pluginName) {
            error(res, "'pluginName' is required", 400);
            return;
        }
        try {
            const { unloadPluginFromDirectory } = await import("../runtime/load-plugin-from-directory.js");
            const result = await unloadPluginFromDirectory({
                runtime: state.runtime,
                pluginName,
            });
            json(res, { ok: result.unloaded, ...result });
        }
        catch (err) {
            // error-policy:J1 plugin-loader diagnostics stay in structured logs;
            // callers receive a stable boundary error rather than exception text.
            logger.error({ err }, "[eliza-api] Plugin unload failed");
            json(res, { ok: false, error: "Plugin could not be unloaded" }, 422);
        }
        return;
    }
    if (await handleDiagnosticsRoutes({
        req,
        res,
        method,
        pathname,
        url,
        logBuffer: state.logBuffer,
        clearLogBuffer: () => {
            const previous = state.logBuffer.length;
            state.logBuffer.length = 0;
            return previous;
        },
        readJsonBody,
        error,
        eventBuffer: state.eventBuffer,
        json,
        auditEventTypes: AUDIT_EVENT_TYPES,
        auditSeverities: AUDIT_SEVERITIES,
        getAuditFeedSize,
        queryAuditFeed: (query) => queryAuditFeed({
            type: AUDIT_EVENT_TYPES.includes(query.type ?? "")
                ? query.type
                : undefined,
            severity: AUDIT_SEVERITIES.includes(query.severity ?? "")
                ? query.severity
                : undefined,
            sinceMs: query.sinceMs,
            limit: query.limit,
        }).map((entry) => ({
            timestamp: entry.timestamp,
            type: entry.type,
            summary: entry.summary,
            severity: entry.severity,
            metadata: entry.metadata,
        })),
        subscribeAuditFeed,
    })) {
        return;
    }
    // ═══════════════════════════════════════════════════════════════════════
    // Bug report routes
    // ═══════════════════════════════════════════════════════════════════════
    if (await handleBugReportRoutes({
        req,
        res,
        method,
        pathname,
        readJsonBody,
        json,
        error,
    })) {
        return;
    }
    // ═══════════════════════════════════════════════════════════════════════
    // Project registry routes (#13776 item 5): list + switch the active project
    // that backs the UI project switcher.
    // ═══════════════════════════════════════════════════════════════════════
    if (await handleProjectRoutes({
        req,
        res,
        method,
        pathname,
        readJsonBody,
        json,
        error,
    })) {
        return;
    }
    // ═══════════════════════════════════════════════════════════════════════
    // Wallet core routes (addresses, balances, generate, config, export)
    // Prefer the local wallet implementation during desktop startup. The
    // wallet route owner must not pull browser/UI-only dependencies into the
    // agent process or block local assistant boot.
    // ═══════════════════════════════════════════════════════════════════════
    // plugin-wallet is desktop/cloud-only; on mobile its import does not resolve
    // and the await stalls /api/wallet/* requests. Skip on mobile → fall through
    // to 404 (the mobile agent has no EVM/Solana wallet surface anyway).
    if (!isMobilePlatform() && pathname.startsWith("/api/wallet/")) {
        const { handleWalletRoutes } = await getWalletApi();
        const { deriveSolanaAddress, fetchEvmBalances, fetchSolanaBalances, fetchSolanaNativeBalanceViaRpc, generateWalletForChain, getWalletAddresses: getCoreWalletAddresses, importWallet, setSolanaWalletEnv, validatePrivateKey, } = await getCoreWalletApi();
        const releaseWalletKeys = method === "POST" &&
            (pathname === "/api/wallet/import" || pathname === "/api/wallet/generate")
            ? await acquireWalletKeyMutation()
            : undefined;
        try {
            const durableWalletConfig = loadElizaConfig();
            const walletUsesCloudNetwork = method === "GET" || pathname === "/api/wallet/refresh-cloud";
            const walletAuthorityView = walletUsesCloudNetwork
                ? createDevCloudConfigAuthorityView(durableWalletConfig)
                : durableWalletConfig;
            const walletConfig = materializeDevCloudConfigAuthorityView(walletAuthorityView);
            const saveWalletConfig = (nextConfig) => {
                const persistable = mergeDevCloudConfigAuthorityMutation(durableWalletConfig, walletAuthorityView, nextConfig);
                saveElizaConfig(persistable);
            };
            if (await handleWalletRoutes({
                req,
                res,
                method,
                pathname,
                config: walletConfig,
                saveConfig: saveWalletConfig,
                ensureWalletKeysInEnvAndConfig,
                resolveWalletExportRejection,
                restartRuntime,
                scheduleRuntimeRestart,
                readJsonBody,
                json,
                error,
                deps: {
                    fetchEvmBalances,
                    fetchSolanaBalances,
                    fetchSolanaNativeBalanceViaRpc,
                    getWalletAddresses: () => getCoreWalletAddresses(state.runtime?.agentId),
                    validatePrivateKey,
                    importWallet,
                    generateWalletForChain,
                    deriveSolanaAddress,
                    setSolanaWalletEnv,
                    resolveWalletRpcReadiness,
                    resolveWalletNetworkMode,
                    getStoredWalletRpcSelections,
                    applyWalletRpcConfigUpdate,
                    resolveWalletCapabilityStatus: (args) => ({
                        ...resolveWalletCapabilityStatus({
                            config: args.config,
                            runtime: args.runtime,
                            getWalletAddresses: () => getCoreWalletAddresses(args.runtime?.agentId),
                        }),
                    }),
                    isCloudWalletEnabled,
                    persistConfigEnv,
                    persistWalletPrivateKeys: (config, keys) => persistWalletPrivateKeys(config, keys, "wallet-routes"),
                    createIntegrationTelemetrySpan: (args) => createIntegrationTelemetrySpan({
                        boundary: "wallet",
                        operation: args.operation,
                    }),
                },
                runtime: state.runtime ?? null,
            })) {
                return;
            }
        }
        finally {
            releaseWalletKeys?.();
        }
    }
    // ═══════════════════════════════════════════════════════════════════════
    //  Agent self-status — delegated to agent-status-routes.ts
    // ═══════════════════════════════════════════════════════════════════════
    if (pathname === "/api/agent/self-status" &&
        (await (async () => {
            const { getWalletAddresses } = await getCoreWalletApi();
            return handleAgentStatusRoutes({
                res,
                method,
                pathname,
                url,
                state: {
                    ...state,
                    config: createDevCloudConfigAuthorityView(state.config),
                },
                json,
                deps: {
                    getWalletAddresses: () => getWalletAddresses(state.runtime?.agentId),
                    resolveWalletCapabilityStatus,
                    resolveWalletRpcReadiness,
                    resolveTradePermissionMode,
                    canUseLocalTradeExecution,
                    detectRuntimeModel,
                    resolveProviderFromModel,
                    getAwarenessRegistry: () => {
                        const service = state.runtime?.getService("AWARENESS_REGISTRY");
                        if (!service || typeof service !== "object")
                            return null;
                        const composeSummary = service.composeSummary;
                        if (typeof composeSummary !== "function")
                            return null;
                        return {
                            composeSummary: (activeRuntime) => Promise.resolve(composeSummary.call(service, activeRuntime)),
                        };
                    },
                },
            });
        })())) {
        return;
    }
    if (await handleUpdateRoutes({
        req,
        res,
        method,
        pathname,
        url,
        state,
        json,
        error,
        readJsonBody,
        saveElizaConfig,
    })) {
        return;
    }
    if (await handleConnectorRoutes({
        req,
        res,
        method,
        pathname,
        state,
        json,
        error,
        readJsonBody,
        saveElizaConfig,
        redactConfigSecrets,
        isBlockedObjectKey,
        hasBlockedObjectKeyDeep,
        cloneWithoutBlockedObjectKeys,
    })) {
        return;
    }
    // ── WhatsApp routes (/api/whatsapp/*) ────────────────────────────────────
    if (pathname.startsWith("/api/client-devices")) {
        const admittedRuntime = state.runtime ?? null;
        const authorization = await resolveHostSessionAuthorization();
        if ((state.runtime ?? null) !== admittedRuntime) {
            error(res, "Agent changed during device admission", 503);
            return;
        }
        await handleDeviceActionRoutes({
            req,
            res,
            method,
            pathname,
            runtime: admittedRuntime,
            authorization,
            assertRuntimeCurrent: () => {
                if (!admittedRuntime || state.runtime !== admittedRuntime)
                    throw new ElizaError("Original read runtime retired", {
                        code: "DEVICE_READ_COMPLETION_RUNTIME_RETIRED",
                    });
            },
            revalidateAuthorization: async () => {
                const denied = {
                    ok: false,
                    role: "NONE",
                };
                if (!admittedRuntime || state.runtime !== admittedRuntime)
                    return denied;
                const resolve = getAgentHostBridge().resolveHttpRequestAuthorization;
                if (!resolve)
                    return denied;
                const fresh = await resolve(req, admittedRuntime, {
                    allowCookieAuth: allowHostCookieAuth,
                    allowTrustedLocalBypass: false,
                    allowBearerAuth: true,
                });
                return state.runtime === admittedRuntime ? fresh : denied;
            },
            json,
            error,
            readJsonBody,
        });
        return;
    }
    // ── Notification + inbox routes (/api/notifications/*, /api/inbox/*) ──
    // Notifications: the unified notification center backed by the runtime
    // NotificationService (see api/notification-routes.ts). Inbox: a
    // cross-channel read-only feed that merges connector messages (imessage,
    // telegram, discord, whatsapp, etc.) into a single time-ordered view.
    let inboxCallerAuthorization;
    if (pathname.startsWith("/api/inbox")) {
        const hostAuthorization = await resolveHostSessionAuthorization();
        inboxCallerAuthorization = resolveInboxRequestAuthorization(req, method, pathname, hostAuthorization);
    }
    if (await handleInboxAndCloudRelayRouteGroup({
        req,
        res,
        method,
        pathname,
        url,
        state,
        json,
        error,
        readJsonBody,
        inboxCallerAuthorization,
    })) {
        return;
    }
    if (await handleAvatarRoutes({
        req,
        res,
        method,
        pathname,
        json,
        error,
    })) {
        return;
    }
    if (pathname === "/api/config" ||
        pathname === "/api/config/schema" ||
        pathname === "/api/config/reload") {
        if (await handleConfigRoutes({
            req,
            res,
            method,
            pathname,
            url,
            config: state.config,
            runtime: state.runtime,
            json,
            error,
            readJsonBody,
            redactConfigSecrets,
            isBlockedObjectKey,
            stripRedactedPlaceholderValuesDeep,
            patchTouchesProviderSelection,
            isBlockedEnvKey,
            CONFIG_WRITE_ALLOWED_TOP_KEYS,
            resolveMcpServersRejection,
            resolveMcpTerminalAuthorizationRejection,
        })) {
            return;
        }
    }
    if (await handlePermissionsExtraRoutes({
        req,
        res,
        method,
        pathname,
        state,
        json,
        error,
        readJsonBody,
        saveElizaConfig,
        resolveTradePermissionMode,
        canUseLocalTradeExecution,
        parseAgentAutomationMode,
        persistAgentAutomationMode,
    })) {
        return;
    }
    if (await handlePermissionRoutes({
        req,
        res,
        method,
        pathname,
        state,
        readJsonBody,
        json,
        error,
        saveConfig: (config) => {
            saveElizaConfig(config);
        },
        scheduleRuntimeRestart,
    })) {
        return;
    }
    if (await handleRelationshipsRoutes({
        req,
        res,
        method,
        pathname,
        runtime: state.runtime ?? undefined,
        readJsonBody,
        json,
        error,
    })) {
        return;
    }
    // Browser workspace routes (/api/browser-workspace/*) are served by the
    // @elizaos/app-browser plugin via Plugin.routes.
    // Agent self-status is handled by handleAgentStatusRoutes above.
    // ═══════════════════════════════════════════════════════════════════════
    // BSC trade routes and wallet trade execute are handled by registered wallet
    // plugin routes when the relevant backend is installed.
    // ═══════════════════════════════════════════════════════════════════════
    if (isLifeOpsCloudPluginRoute(pathname) &&
        (await handleLifeOpsRuntimePluginRoute({
            req,
            res,
            method,
            pathname,
            url,
            state,
            isAuthorizedRequest: isAuthorized,
        }))) {
        return;
    }
    if (await handleCloudAndCoreRouteGroup({
        req,
        res,
        method,
        pathname,
        state,
        restartRuntime,
        saveConfig: saveElizaConfig,
    })) {
        return;
    }
    if (await handleSandboxRouteGroup({ req, res, method, pathname, state })) {
        return;
    }
    if (await handleConversationRouteGroup({
        req,
        res,
        method,
        pathname,
        url,
        state,
        json,
        error,
        readJsonBody,
        callerAuthorization: isServerTokenAuthorized(req)
            ? {
                ok: true,
                role: "USER",
                principal: "shared-server-gateway",
            }
            : await resolveHostSessionAuthorization(),
    })) {
        return;
    }
    if (await handleDatabaseRouteGroup({ req, res, pathname, state })) {
        return;
    }
    if (!state.runtime &&
        method === "GET" &&
        pathname.startsWith("/api/coding-agents")) {
        error(res, "Coding agent runtime unavailable", 503);
        return;
    }
    if (await handleCloudStatusRoutes({
        req,
        res,
        method,
        pathname,
        config: createDevCloudConfigAuthorityView(state.config),
        runtime: state.runtime,
        json,
    })) {
        return;
    }
    // ── Interaction reporting (/api/interactions/shortcut) ────────────────────
    if (await handleInteractionsRoutes({
        req,
        res,
        method,
        pathname,
        json,
        error,
        runtime: state.runtime,
    })) {
        return;
    }
    // ── View routes (/api/views/*) ────────────────────────────────────────────
    const viewsCallerAuthorization = resolveInboxRequestAuthorization(req, method, pathname, await resolveHostSessionAuthorization());
    if (await handleViewsRoutes({
        hostKey: state,
        req,
        res,
        method,
        pathname,
        url,
        json,
        error,
        broadcastWs: state.broadcastWs ?? undefined,
        broadcastWsToClientId: state.broadcastWsToClientId ?? undefined,
        runtime: state.runtime,
        callerAuthorization: viewsCallerAuthorization,
    })) {
        return;
    }
    // ── Runtime switch routes (/api/runtime/model-switch, /agent-switch) ──────
    const runtimeManagementCallerAuthorization = resolveInboxRequestAuthorization(req, method, pathname, await resolveHostSessionAuthorization());
    if (await handleRuntimeManagementRoutes({
        req,
        res,
        method,
        pathname,
        json,
        error,
        broadcastWs: state.broadcastWs ?? undefined,
        broadcastWsToClientId: state.broadcastWsToClientId ?? undefined,
        callerAuthorization: runtimeManagementCallerAuthorization,
    })) {
        return;
    }
    if (await handleRuntimeSwitchRoutes({
        req,
        res,
        method,
        pathname,
        json,
        error,
        broadcastWs: state.broadcastWs ?? undefined,
    })) {
        return;
    }
    if (pathname.startsWith("/api/workbench")) {
        if (await handleWorkbenchRoutes({
            req,
            res,
            method,
            pathname,
            url,
            state,
            json,
            error,
            readJsonBody,
            toWorkbenchTodo,
            decodePathComponent,
            taskToTriggerSummary,
            listTriggerTasks,
        })) {
            return;
        }
    }
    // ═══════════════════════════════════════════════════════════════════════
    // Life-ops routes: now served via lifeopsPlugin.routes (rawPath) on the
    // runtime plugin route system. See app-lifeops/src/routes/plugin.ts.
    // ═══════════════════════════════════════════════════════════════════════
    if (pathname.startsWith("/api/mcp")) {
        const { handleMcpRoutes } = await getOptionalPluginApi("mcp");
        if (await handleMcpRoutes({
            req,
            res,
            method,
            pathname,
            url,
            state,
            // The MCP marketplace route tracks client disconnects until the
            // response write has actually been initiated. Keep these helpers
            // awaitable without changing the fire-and-forget behavior of the
            // other agent routes.
            json: (response, data, status) => writeJsonResponse(response, data, status).catch((err) => {
                logger.warn(`[api] MCP JSON response write failed: ${err}`);
            }),
            error: (response, message, status) => writeJsonError(response, message, status).catch((err) => {
                logger.warn(`[api] MCP JSON error response write failed: ${err}`);
            }),
            readJsonBody,
            saveElizaConfig,
            redactDeep,
            isBlockedObjectKey,
            cloneWithoutBlockedObjectKeys,
            resolveMcpServersRejection,
            resolveMcpTerminalAuthorizationRejection,
            decodePathComponent,
        })) {
            return;
        }
    }
    if (await handleMiscRoutes({
        req,
        res,
        method,
        pathname,
        url,
        state,
        json,
        error,
        readJsonBody,
        AGENT_EVENT_ALLOWED_STREAMS,
        resolveTerminalRunRejection,
        resolveTerminalRunClientId,
        isSharedTerminalClientId,
        activeTerminalRunCount,
        setActiveTerminalRunCount: (delta) => {
            activeTerminalRunCount = Math.max(0, activeTerminalRunCount + delta);
        },
        tryAcquireTerminalRunSlot: (scopeId, runId, maxConcurrent) => {
            const now = Date.now();
            if (now - lastTerminalRunIdSweepAt >= TERMINAL_RUN_ID_SWEEP_INTERVAL_MS ||
                terminalRunIdReservations.size >= MAX_TERMINAL_RUN_ID_RESERVATIONS) {
                for (const [reservedRunId, expiresAt] of terminalRunIdReservations) {
                    if (expiresAt <= now) {
                        terminalRunIdReservations.delete(reservedRunId);
                    }
                }
                lastTerminalRunIdSweepAt = now;
            }
            const reservationKey = `${scopeId}\0${runId}`;
            if (terminalRunIdReservations.has(reservationKey)) {
                return { rejection: "duplicate" };
            }
            if (activeTerminalRunCount >= maxConcurrent) {
                return { rejection: "capacity" };
            }
            if (terminalRunIdReservations.size >= MAX_TERMINAL_RUN_ID_RESERVATIONS) {
                return { rejection: "registry-capacity" };
            }
            terminalRunIdReservations.set(reservationKey, now + TERMINAL_RUN_ID_RESERVATION_TTL_MS);
            activeTerminalRunCount += 1;
            let released = false;
            return {
                release: () => {
                    if (released)
                        return;
                    released = true;
                    activeTerminalRunCount = Math.max(0, activeTerminalRunCount - 1);
                },
            };
        },
    })) {
        return;
    }
    // ── WhatsApp routes (/api/whatsapp/*) ────────────────────────────────────
    // ── elizaOS plugin HTTP routes (runtime.routes, e.g. /music-player/*) ───
    const runtimeRouteConfig = pathname.startsWith("/api/cloud/")
        ? materializeDevCloudConfigAuthorityView(createDevCloudConfigAuthorityView(state.config))
        : state.config;
    if (await tryHandleRuntimePluginRoute({
        req,
        res,
        method,
        pathname,
        url,
        runtime: state.runtime,
        isAuthorized: () => hostSessionAuthorization.ok || isAuthorized(req),
        hostContext: {
            config: runtimeRouteConfig,
            saveConfig: (nextConfig) => {
                const persistable = nextConfig;
                saveElizaConfig(persistable);
                state.config = persistable;
            },
            restartRuntime,
        },
    })) {
        return;
    }
    if (await handleBuiltinOptionalRoutes(req, res, pathname, method, state.runtime?.agentId)) {
        return;
    }
    // ── Connector plugin routes (dynamically registered) ────────────────────
    for (const handler of state.connectorRouteHandlers) {
        const handled = await handler(req, res, pathname, method);
        if (handled)
            return;
    }
    if (await handleHostSettingsRoutes(req, res, pathname, method)) {
        return;
    }
    // The context inspector owns a stricter boundary than the general trajectory
    // viewer: resolve the host principal again for this request and project only
    // allowlisted content metadata. Direct API-token callers are the standalone
    // owner's equivalent authority; scoped boundary-role tokens are deliberately
    // not promoted to inspector access.
    if (pathname === "/api/context-inspector") {
        const hostAuthorization = await resolveHostSessionAuthorization();
        const inspectorAuthorization = hostAuthorization.ok
            ? hostAuthorization
            : isAuthorized(req)
                ? { ok: true, role: "OWNER" }
                : { ok: false, role: "NONE" };
        if (await handleContextInspectorRoute({
            req,
            res,
            pathname,
            method,
            url,
            runtime: state.runtime,
            authorization: inspectorAuthorization,
            resolveConversationRoomId: async (conversationId) => {
                let conversation = state.conversations.get(conversationId);
                if (!conversation && state.conversationRestorePromise) {
                    await state.conversationRestorePromise;
                    conversation = state.conversations.get(conversationId);
                }
                return conversation?.roomId ?? null;
            },
        })) {
            return;
        }
    }
    // ── LifeOps inbox compatibility fallback ────────────────────────────────
    // The inbox view is bundled independently from the PA-owned inbox cache
    // route. When PA is absent, serve an empty wire payload instead of a 404 loop.
    if (await tryHandleLifeOpsInboxFallbackLazy({
        pathname,
        method,
        url,
        res,
    })) {
        return;
    }
    // ── Trajectory management routes (config, export, delete) ───────────────
    // The owner gate above already covers every /api/trajectories method.
    if (await handleTrajectoryManagementRoutes({
        req,
        res,
        method,
        pathname,
        runtime: state.runtime,
    })) {
        return;
    }
    // ── Trajectory read routes (owned by core TrajectoriesService) ──────────
    // Serves GET /api/trajectories[/:id|/stats] from the core TrajectoriesService
    // so the realtime trajectory viewer works from the core service on every
    // platform.
    if (await tryHandleTrajectoryReadRoutes({
        pathname,
        method,
        url,
        runtime: state.runtime,
        res,
    })) {
        return;
    }
    // ── Hono adapter for runtime.routes with `routeHandler` (new shape) ─────
    // Covers any plugin route registered via the new return-shape RouteHandler
    // contract. Legacy Express-shaped `handler` routes are still served by
    // `tryHandleRuntimePluginRoute` above.
    if (await tryHandleHonoRuntimeRoute({
        req,
        res,
        runtime: state.runtime,
        // Mirror the outer 401 gate: a registered boundary-role viewer (e.g. an
        // artifact share-viewer token, #14781) is authorized for its in-scope
        // routes, so the dispatch-level re-check must accept it too — otherwise
        // resolver-authorized requests pass the outer gate and 401 in dispatch.
        isAuthorized: () => hostSessionAuthorization.ok ||
            isAuthorized(req) ||
            isBoundaryRoleAuthorized(req, method, pathname),
        isTrustedLocal: () => isTrustedLocalRequest(req),
        // Session admission and disclosure share the verified host principal.
        // Only trusted local requests retain the plugin's local-owner fallback.
        accessContext: () => {
            if (hostSessionAuthorization.ok && state.runtime) {
                return resolveHostSessionAccessContext(hostSessionAuthorization, state.runtime);
            }
            if (isTrustedLocalRequest(req))
                return undefined;
            const boundaryAccess = resolveHttpAccessContext(req);
            if (boundaryAccess)
                return boundaryAccess;
            // Direct owner API credentials retain their principal at plugin routes.
            // Gateway admission alone never grants owner document access.
            if (state.runtime &&
                isAuthorized(req) &&
                !isServerTokenAuthorized(req)) {
                return {
                    requesterEntityId: resolveOwnerEntityIdOrDefault(state.runtime),
                    role: "OWNER",
                    isOwner: true,
                    source: "owner-api-token",
                };
            }
            return undefined;
        },
    })) {
        return;
    }
    // ── Fallback ────────────────────────────────────────────────────────────
    error(res, "Not found", 404);
}
function strictPortBindingEnabled() {
    const value = process.env.ELIZA_API_STRICT_PORT?.trim().toLowerCase();
    return value === "1" || value === "true" || value === "yes";
}
/**
 * The Character view's FILL_BIO / ADD_STYLE_RULE / ADD_MESSAGE_EXAMPLE are
 * registered per runtime. Deferred startup work only reaches the runtime that
 * exists when the server binds, so a runtime attached later (bind-first hosts,
 * restart, start after stop) needs its own registration.
 */
function registerBuiltinViewScopedActions(runtime, context) {
    if (!runtime)
        return;
    void registerBuiltinViews(runtime).catch((err) => {
        logger.warn(`[eliza-api] Built-in view registration failed ${context}: ${err instanceof Error ? err.message : String(err)}`);
    });
}
export async function startApiServer(opts) {
    // Hosts that listen before startEliza must still pass protected admission.
    await ensureProtectedProfileAdmission();
    // Publish a complete navigation catalog before accepting the first tool turn.
    // Hosts may attach their runtime later; updateRuntime keeps the same fence.
    if (opts?.runtime)
        registerRuntimeBuiltinViews(opts.runtime);
    const apiStartTime = Date.now();
    const hostAdmission = opts?.hostAdmission;
    const hostConfig = opts?.hostConfig === undefined
        ? undefined
        : structuredClone(opts.hostConfig);
    async function admitHostRequest(request, boundary) {
        if (!hostAdmission)
            return null;
        try {
            return (await hostAdmission(request, boundary)) === true ? null : 403;
        }
        catch {
            // error-policy:J1 Admission failure denies access without exposing policy or credentials.
            logger.warn("[eliza-api] Required host admission unavailable");
            return 503;
        }
    }
    // Gated boot profiler (off unless ELIZA_BOOT_PROFILE=1) to time the API-bind
    // critical path. Stderr, since the structured logger level may suppress it.
    const apiLap = (label) => {
        if (process.env.ELIZA_BOOT_PROFILE === "1") {
            process.stderr.write(`[boot-profile] api:${label} +${Date.now() - apiStartTime}ms\n`);
        }
    };
    logger.debug(`[eliza-api] startApiServer called`);
    // Honor ELIZA_API_PORT first (set by the desktop launcher → 31337) so
    // the renderer's hardcoded API base reaches this server. CLI-mode
    // (no ELIZA_API_PORT) keeps the legacy `resolveServerOnlyPort` default
    // of 2138, so this change is transparent for non-desktop users.
    const port = opts?.port ??
        (readAliasedEnv("ELIZA_API_PORT")
            ? resolveDesktopApiPort(process.env)
            : resolveServerOnlyPort(process.env));
    const host = resolveApiBindHost(process.env);
    ensureApiTokenForBindHost(host);
    // Resolve owner configuration before any HTTP server is created or bound.
    // The monitor itself starts later, but its deferred catch must never turn a
    // malformed interval into a healthy-looking default.
    const connectorHealthIntervalMs = resolveConnectorHealthIntervalMs(process.env.CONNECTOR_HEALTH_INTERVAL_MS);
    logger.debug(`[eliza-api] Token check done (${Date.now() - apiStartTime}ms)`);
    let config;
    const configWritePath = resolveConfigWritePath();
    try {
        config = hostConfig ?? loadElizaConfig();
    }
    catch (err) {
        if (err.code !== "ENOENT") {
            // error-policy:J2 only a genuinely absent config is first-run state;
            // malformed or unreadable configuration must fail API startup.
            throw new ElizaError("Failed to load agent API configuration", {
                code: "AGENT_CONFIG_LOAD_FAILED",
                cause: err,
                severity: "fatal",
            });
        }
        logger.info("[eliza-api] No config found; starting in first-run mode");
        config = {};
    }
    logger.debug(`[eliza-api] Config loaded (${Date.now() - apiStartTime}ms)`);
    // Wallet/inventory routes read from process.env at request-time.
    // Hydrate persisted config.env values so addresses remain visible after restarts.
    const persistedEnv = config.env;
    const envKeysToHydrate = [
        "ELIZA_WALLET_OS_STORE",
        "EVM_PRIVATE_KEY",
        "SOLANA_PRIVATE_KEY",
        "ALCHEMY_API_KEY",
        "INFURA_API_KEY",
        "ANKR_API_KEY",
        "HELIUS_API_KEY",
        "BIRDEYE_API_KEY",
        "SOLANA_RPC_URL",
    ];
    for (const key of envKeysToHydrate) {
        const value = persistedEnv?.[key];
        if (typeof value === "string" && value.trim() && !process.env[key]) {
            process.env[key] = value.trim();
        }
    }
    // Optional auto-provision mode for legacy environments. Disabled by default
    // so startup does not silently create new wallets when keys are missing.
    const walletAutoProvisionRaw = process.env.ELIZA_WALLET_AUTO_PROVISION?.trim().toLowerCase();
    const walletAutoProvisionEnabled = walletAutoProvisionRaw === "1" ||
        walletAutoProvisionRaw === "true" ||
        walletAutoProvisionRaw === "on" ||
        walletAutoProvisionRaw === "yes";
    if (walletAutoProvisionEnabled) {
        const releaseWalletKeys = await acquireWalletKeyMutation();
        const walletEnvBefore = Object.fromEntries([
            "EVM_PRIVATE_KEY",
            "SOLANA_PRIVATE_KEY",
            "SOLANA_PUBLIC_KEY",
            "WALLET_PUBLIC_KEY",
        ].map((name) => [name, process.env[name]]));
        try {
            if (await ensureWalletKeysInEnvAndConfig(config)) {
                saveElizaConfig(config);
            }
        }
        catch (err) {
            for (const [name, value] of Object.entries(walletEnvBefore)) {
                if (value === undefined)
                    delete process.env[name];
                else
                    process.env[name] = value;
            }
            logger.error(`[eliza-api] Failed to persist generated wallet keys: ${err instanceof Error ? err.message : err}`);
        }
        finally {
            releaseWalletKeys();
        }
    }
    const blockOnStewardWalletCache = process.env.ELIZA_STEWARD_WALLET_CACHE_BLOCKING?.trim() === "1";
    if (blockOnStewardWalletCache) {
        // Cloud/provisioned environments can opt into strict startup semantics
        // when wallet addresses must be available before the first request.
        const { initStewardWalletCache } = await getCoreWalletApi();
        await initStewardWalletCache();
    }
    // Warn when wallet private keys live in plaintext config and the OS secure
    // store is not enabled.  This nudges operators toward ELIZA_WALLET_OS_STORE=1.
    {
        const hasPlaintextKeys = (typeof persistedEnv?.EVM_PRIVATE_KEY === "string" &&
            persistedEnv.EVM_PRIVATE_KEY.trim()) ||
            (typeof persistedEnv?.SOLANA_PRIVATE_KEY === "string" &&
                persistedEnv.SOLANA_PRIVATE_KEY.trim());
        const osStoreRaw = process.env.ELIZA_WALLET_OS_STORE?.trim().toLowerCase();
        const osStoreEnabled = osStoreRaw === "1" ||
            osStoreRaw === "true" ||
            osStoreRaw === "on" ||
            osStoreRaw === "yes";
        if (hasPlaintextKeys && !osStoreEnabled) {
            logger.warn("[wallet] Private keys are stored in plaintext config. " +
                "Set ELIZA_WALLET_OS_STORE=1 to use the OS secure store instead.");
        }
    }
    const plugins = discoverPluginsFromManifest();
    logger.debug(`[eliza-api] Plugins discovered (${Date.now() - apiStartTime}ms)`);
    const state = createServerState({
        config,
        runtime: opts?.runtime,
        initialAgentState: opts?.initialAgentState,
        plugins,
        deletedConversationIds: readDeletedConversationIdsFromState(),
        resolveAgentName: resolveDefaultAgentName,
        detectRuntimeModel,
        resolveAgentAutomationMode: resolveAgentAutomationModeFromConfig,
        resolveTradePermissionMode,
    });
    const configuredAdminEntityId = config.agents?.defaults?.adminEntityId;
    if (configuredAdminEntityId && isUuidLike(configuredAdminEntityId)) {
        state.adminEntityId = configuredAdminEntityId;
        state.chatUserId = state.adminEntityId;
    }
    else if (configuredAdminEntityId) {
        logger.warn(`[eliza-api] Ignoring invalid agents.defaults.adminEntityId "${configuredAdminEntityId}"`);
    }
    const addLog = (level, message, source = "system", tags = []) => {
        let resolvedSource = source;
        if (source === "auto" || source === "system") {
            const bracketMatch = /^\[([^\]]+)\]\s*/.exec(message);
            if (bracketMatch)
                resolvedSource = bracketMatch[1];
        }
        // Auto-tag based on source when no explicit tags provided
        const resolvedTags = tags.length > 0
            ? tags
            : resolvedSource === "runtime" || resolvedSource === "autonomy"
                ? ["agent"]
                : resolvedSource === "api" || resolvedSource === "websocket"
                    ? ["server"]
                    : resolvedSource === "cloud"
                        ? ["server", "cloud"]
                        : ["system"];
        state.logBuffer.push({
            timestamp: Date.now(),
            level,
            message,
            source: resolvedSource,
            tags: resolvedTags,
        });
    };
    addLog("info", `Discovered ${plugins.length} plugins`, "system", [
        "system",
        "plugins",
    ]);
    let providerCacheWarmupPromise = null;
    let detachApiLogListener = null;
    const captureStructuredLog = (entry) => {
        addLog(entry.level, entry.message, entry.source, entry.tags);
    };
    // Store the restart callback on the state so the route handler can access it.
    const onRestart = opts?.onRestart ?? null;
    const onStop = opts?.onStop ?? null;
    const restartRequiresRuntimeDisposal = opts?.restartRequiresRuntimeDisposal === true;
    const onRuntimeActivated = opts?.onRuntimeActivated;
    logger.debug(`[eliza-api] Creating http server (${Date.now() - apiStartTime}ms)`);
    apiLap("pre-createServer (route imports + middleware setup done)");
    const getAuthenticationRuntime = opts?.getAuthenticationRuntime ?? (() => state.runtime);
    const requestContext = {
        getAuthenticationRuntime,
        composeStatus: opts?.composeStatus,
        hostRuntimeMode: hostConfig === undefined ? undefined : resolveRuntimeMode(hostConfig),
        onRestart,
        onStop,
        restartRequiresRuntimeDisposal,
        onRuntimeActivated,
        onRuntimeSwapped: () => {
            bindInProcessApi();
            registerBuiltinViewScopedActions(state.runtime, "after swap");
            if (state.runtime)
                state.connectorHealthMonitor?.setRuntime(state.runtime);
            bindRuntimeStreams(state.runtime);
            wireModelRegistrationBroadcast(state.runtime);
            wireNativeBrowserPageReader(state.runtime);
            if (state.runtime) {
                // The new runtime has no dashboard chat delivery until it is
                // registered again, as updateRuntime does.
                registerClientChatSendHandler(state.runtime, state);
                wireProactiveInteractionDecider(state.runtime, state);
            }
            void wireCoordinatorBridgesWhenReady(state, {
                wireChatBridge: wireCodingAgentChatBridge,
                wireWsBridge: wireCodingAgentWsBridge,
                wireEventRouting: wireCoordinatorEventRouting,
                wireSwarmSynthesis: wireCodingAgentSwarmSynthesis,
                context: "restart",
                logger,
            });
        },
    };
    const reloadConfigFromDisk = () => {
        if (hostConfig !== undefined) {
            throw new ElizaError("API configuration is owned by the host", {
                code: "API_HOST_CONFIG_RELOAD_DENIED",
            });
        }
        // Config routes clone this durable graph before writing. Operational
        // consumers apply their existing launcher-authority views at read time.
        replaceConfigInPlace(state.config, loadElizaConfig());
    };
    const runtimeOperations = {
        start: async (request) => {
            if (request.intent.kind === "restart" && !onRestart) {
                throw new ElizaError("Runtime restart is not supported by this host", {
                    code: "RUNTIME_RESTART_UNAVAILABLE",
                });
            }
            return getOrCreateRuntimeOperationManager(state, (reason) => applyRuntimeRestart(state, requestContext, reason)).start(request);
        },
        get: (id) => getOrCreateRuntimeOperationManager(state, (reason) => applyRuntimeRestart(state, requestContext, reason)).get(id),
    };
    const routeKernel = createRouteKernel({
        dispatch: async (req, res) => {
            const rejection = await admitHostRequest(req, "request");
            if (rejection !== null) {
                error(res, "Host admission denied", rejection);
                return;
            }
            const dispatch = () => handleRequest(req, res, state, requestContext);
            if (opts?.requestMiddleware) {
                await opts.requestMiddleware(req, res, dispatch);
            }
            else {
                await dispatch();
            }
        },
        translateFailure: (err, _req, res) => {
            const msg = err instanceof Error ? err.message : "internal error";
            logger.error({ err }, `[eliza-api] Request handler failed: ${msg}`);
            addLog("error", msg, "api", ["server", "api"]);
            error(res, msg, 500);
        },
    });
    let unregisterInProcessApi;
    const bindInProcessApi = () => {
        unregisterInProcessApi?.();
        if (state.runtime) {
            const unregisterHost = registerInProcessApi(state.runtime, routeKernel, state);
            const unregisterDefault = opts?.skipListen
                ? registerInProcessApi(state.runtime, routeKernel)
                : undefined;
            const unregisterNative = opts?.skipListen
                ? bindNativeViewHost(state.runtime, state)
                : undefined;
            unregisterInProcessApi = () => {
                unregisterNative?.();
                unregisterHost();
                unregisterDefault?.();
            };
        }
        else
            unregisterInProcessApi = undefined;
    };
    bindInProcessApi();
    const server = http.createServer((req, res) => routeKernel.handle(req, res));
    await opts?.configureServer?.(server);
    // W9-AGENT-01: the WS upgrade handler delegates the device-bridge path to
    // the capacitor bridge's own upgrade listener, so that delegation is only
    // safe once such a listener has REALLY attached here. A settled attach
    // promise is not proof of that: an optional-plugin import rejection resolves
    // through the no-op fallback API, and the bridge attach itself returns early
    // when the bridge is disabled for the platform — in both cases nothing is
    // listening. Use the bridge's explicit attachment result; listener counts
    // are process-global observations and can be changed by unrelated features.
    let deviceBridgeUpgradeHandlerAttached = false;
    let deviceBridgeAttachAllowed = !opts?.skipListen && !hostAdmission;
    server.once("close", () => {
        // The optional plugin import is deliberately deferred beyond bind. If the
        // server closes before it resolves, do not attach the process-global bridge
        // to a dead server and prevent a replacement API server from acquiring it.
        deviceBridgeAttachAllowed = false;
        deviceBridgeUpgradeHandlerAttached = false;
    });
    if (deviceBridgeAttachAllowed &&
        (isMobilePlatform() ||
            process.env.ELIZA_DEVICE_BRIDGE_ENABLED?.trim() === "1")) {
        // Defer to a macrotask: resolving @elizaos/plugin-native-inference (and its
        // device-bridge attach) measured ~15s of blocking on the mobile bundle and
        // — because it sat on the synchronous pre-`server.listen` path — held the
        // whole API bind (and the boot screen) hostage for that entire time (#11903).
        // The bridge only needs to attach a WS upgrade handler to the server object,
        // which works fine once the server is already listening.
        setImmediate(() => {
            void getOptionalPluginApi("capacitor")
                .then(({ attachMobileDeviceBridgeToServer }) => {
                if (!deviceBridgeAttachAllowed)
                    return false;
                return attachMobileDeviceBridgeToServer(server);
            })
                .then((attached) => {
                if (deviceBridgeAttachAllowed) {
                    deviceBridgeUpgradeHandlerAttached = attached === true;
                }
            })
                .catch((err) => {
                logger.warn("[eliza-api] Failed to attach mobile device bridge:", err instanceof Error ? err.message : String(err));
            });
        });
    }
    logger.debug(`[eliza-api] Server created (${Date.now() - apiStartTime}ms)`);
    // requestTimeout bounds receipt of the request body; Node does not apply it
    // to time spent generating the response. Keep that slow-upload protection
    // while leaving the idle socket deadline disabled for long model turns.
    // Generation itself is cancelled by the request owner's AbortSignal.
    server.requestTimeout = 300000;
    server.headersTimeout = 60000;
    server.keepAliveTimeout = 60000;
    server.timeout = 0;
    logger.debug("[eliza-api] Server lifecycle: requestTimeout=300000ms, idleTimeout=disabled, headersTimeout=60000ms, keepAliveTimeout=60000ms");
    const wsClients = new Set();
    const wsClientIds = new WeakMap();
    const wsActiveConversations = new WeakMap();
    const wsRequests = new WeakMap();
    const wsSendQueues = new WeakMap();
    const wsQueuedSendBytes = new WeakMap();
    const reportWebSocketSendError = (err) => {
        logger.error(`[eliza-api] WebSocket send error: ${err instanceof Error ? err.message : err}`);
    };
    const wsBackpressure = createEventSocketBackpressureGuard({
        clients: wsClients,
        clientIds: wsClientIds,
        reportSendError: reportWebSocketSendError,
        getBufferedAmount: (ws) => ws.bufferedAmount + (wsQueuedSendBytes.get(ws) ?? 0),
    });
    const wsSessions = new Map();
    const invalidateSessionSocket = (ws, reason = "session_invalid") => {
        const session = wsSessions.get(ws);
        if (session)
            session.revoked = true;
        wsClients.delete(ws);
        ws.close(1008, reason);
    };
    const validateSessionSocket = async (ws) => {
        const session = wsSessions.get(ws);
        if (!session)
            return true;
        if (session.revoked)
            return false;
        if (session.pending)
            return session.pending;
        if (Date.now() - session.checkedAt < 5_000)
            return true;
        session.pending = (async () => {
            for (;;) {
                const generation = session.generation;
                const authorized = await isWebSocketSessionTokenAuthorized(session.token, getAuthenticationRuntime());
                if (!authorized ||
                    session.revoked ||
                    ws.readyState !== WebSocket.OPEN) {
                    invalidateSessionSocket(ws);
                    return false;
                }
                // A bulk revoke can commit while this read is in flight. Re-read
                // before releasing queued frames; the excepted session stays usable.
                if (generation !== session.generation)
                    continue;
                session.checkedAt = Date.now();
                return true;
            }
        })().finally(() => {
            delete session.pending;
        });
        return session.pending;
    };
    const unsubscribeSessionRevocations = getAgentHostBridge().subscribeSessionRevocations?.((sessionId) => {
        for (const [ws, session] of wsSessions) {
            if (sessionId === session.token)
                invalidateSessionSocket(ws, "session_revoked");
            else if (sessionId === null) {
                // Bulk revoke preserves the excepted session: re-resolve each bearer.
                session.checkedAt = 0;
                session.generation += 1;
                void validateSessionSocket(ws);
            }
        }
    });
    const admitWebSocket = async (ws, request, boundary) => {
        if (ws.readyState !== WebSocket.OPEN)
            return false;
        if (!(await validateSessionSocket(ws)))
            return false;
        const rejection = await admitHostRequest(request, boundary);
        if (rejection !== null) {
            ws.close(rejection === 403 ? 1008 : 1011, "Host admission rejected");
            return false;
        }
        return ws.readyState === WebSocket.OPEN;
    };
    const sendWebSocket = (ws, message) => {
        if (ws.readyState !== WebSocket.OPEN || !wsBackpressure.admit(ws)) {
            return false;
        }
        if (!hostAdmission && !wsSessions.has(ws)) {
            ws.send(message);
            return true;
        }
        const request = wsRequests.get(ws);
        if (!request) {
            ws.close(1008, "Host admission rejected");
            return false;
        }
        // Reappraise at delivery, preserving ordering across status, replay, targeted
        // events and PTY output. Queued frames cannot inherit an earlier approval;
        // their bytes remain visible to the same backpressure guard as ws's native
        // transport buffer until the admission decision completes.
        const messageBytes = Buffer.byteLength(message);
        wsQueuedSendBytes.set(ws, (wsQueuedSendBytes.get(ws) ?? 0) + messageBytes);
        const previous = wsSendQueues.get(ws) ?? Promise.resolve();
        const pending = previous
            .then(async () => {
            try {
                if (await admitWebSocket(ws, request, "websocket-send")) {
                    ws.send(message);
                }
            }
            finally {
                const remaining = (wsQueuedSendBytes.get(ws) ?? 0) - messageBytes;
                if (remaining > 0)
                    wsQueuedSendBytes.set(ws, remaining);
                else
                    wsQueuedSendBytes.delete(ws);
            }
        })
            .catch(() => {
            // error-policy:J1 Close this transport without exposing frame or policy data.
            logger.warn("[eliza-api] Required host WebSocket delivery failed");
            ws.close(1011, "Host admission unavailable");
        });
        wsSendQueues.set(ws, pending);
        return true;
    };
    const eventHub = createApiEventHub({
        state,
        clients: wsClients,
        clientIds: wsClientIds,
        activeConversations: wsActiveConversations,
        sendMessage: sendWebSocket,
        reportSendError: reportWebSocketSendError,
    });
    const broadcastWs = eventHub.broadcast;
    const pushEvent = eventHub.publish;
    let detachRuntimeStreams = null;
    const bindRuntimeStreams = (runtime) => {
        if (detachRuntimeStreams) {
            detachRuntimeStreams();
            detachRuntimeStreams = null;
        }
        let active = true;
        const unsubscribe = [];
        detachRuntimeStreams = () => {
            active = false;
            for (const detach of unsubscribe)
                detach();
        };
        // Registration is lazy: a synchronous lookup can miss the service at
        // startup. Bind each runtime once it loads, and detach on swap or close.
        if (runtime?.hasService("connector-setup")) {
            void runtime
                .getServiceLoadPromise("connector-setup")
                .then((service) => {
                if (!active)
                    return;
                const setup = service;
                setup.setBroadcastWs(broadcastWs);
                setup.setLiveConfig(() => state.config);
                unsubscribe.push(() => {
                    setup.setBroadcastWs(null);
                    setup.setLiveConfig(null);
                });
            })
                .catch((error) => runtime.reportError("api.connectorBroadcast", error));
        }
        const svc = getAgentEventService(runtime);
        if (!svc) {
            if (runtime) {
                logger.warn("[eliza-api] AGENT_EVENT service not found on runtime — event streaming will be unavailable");
            }
            return;
        }
        const unsubAgentEvents = svc.subscribe((event) => {
            if (EPHEMERAL_AGENT_EVENT_STREAMS.has(event.stream)) {
                // Live-only (e.g. interim voice transcripts): no replay buffer, no
                // conversation routing.
                broadcastWs(buildEphemeralAgentEventEnvelope({
                    type: "agent_event",
                    ts: event.ts,
                    runId: event.runId,
                    seq: event.seq,
                    stream: event.stream,
                    sessionKey: event.sessionKey,
                    agentId: event.agentId,
                    roomId: event.roomId,
                    payload: event.data,
                }));
                return;
            }
            pushEvent({
                type: "agent_event",
                ts: event.ts,
                runId: event.runId,
                seq: event.seq,
                stream: event.stream,
                sessionKey: event.sessionKey,
                agentId: event.agentId,
                roomId: event.roomId,
                payload: event.data,
            });
            void maybeRouteAutonomyEventToConversation(state, event).catch((err) => {
                logger.warn(`[autonomy-route] Failed to route proactive event: ${err instanceof Error ? err.message : String(err)}`);
            });
        });
        const unsubHeartbeat = svc.subscribeHeartbeat((event) => {
            pushEvent({
                type: "heartbeat_event",
                ts: event.ts,
                payload: event,
            });
        });
        unsubscribe.push(unsubAgentEvents, unsubHeartbeat);
    };
    // ── Deferred startup work (non-blocking) ────────────────────────────────
    // Keep API startup fast: listen first, then warm optional subsystems.
    const startDeferredStartupWork = async () => {
        providerCacheWarmupPromise ??= getOrFetchAllProviders()
            .then(() => undefined)
            .catch((err) => {
            // error-policy:J7 Background catalog discovery must not stop the API host.
            logger.warn("[api] Provider cache warm-up failed:", err);
            if (opts?.runtime)
                opts.runtime.reportError("api.providerCacheWarmup", err);
        });
        void registerBuiltinViews(state.runtime).catch((err) => {
            logger.warn(`[eliza-api] Built-in view registration failed after listen: ${err instanceof Error ? err.message : String(err)}`);
        });
        if (!blockOnStewardWalletCache) {
            void getCoreWalletApi()
                .then(({ initStewardWalletCache }) => initStewardWalletCache())
                .catch((err) => {
                logger.debug(`[eliza-api] Steward wallet cache init failed after listen: ${err instanceof Error ? err.message : String(err)}`);
            });
        }
        // ── Connector health monitoring ──────────────────────────────────────────
        if (state.runtime && state.config.connectors) {
            try {
                state.connectorHealthMonitor = await createConnectorHealthMonitor({
                    runtime: state.runtime,
                    config: state.config,
                    broadcastWs,
                    intervalMs: connectorHealthIntervalMs,
                });
                state.connectorHealthMonitor.start();
            }
            catch (err) {
                logger.warn(`[eliza-api] Connector health monitor failed after listen: ${err instanceof Error ? err.message : String(err)}`);
            }
        }
    };
    // ── WebSocket Server ─────────────────────────────────────────────────────
    const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
    // A server-level 'error' with no listener crashes the process. Abrupt client
    // disconnects (RST during/after the upgrade handshake) surface here.
    wss.on("error", (err) => {
        logger.warn(`[eliza-api] WebSocketServer error: ${err instanceof Error ? err.message : err}`);
    });
    // Server-side ping/pong: a peer whose TCP window froze (backgrounded app,
    // suspended laptop) never sends a close frame, so without this sweep its
    // socket and everything the hub queues for it would live until the OS
    // gives up on the connection.
    const wsLiveness = createEventSocketLivenessSweep({
        clientIds: wsClientIds,
    });
    /**
     * Per-connection active conversation. Each browser window/client owns its own
     * active conversation, so two windows no longer fight over a single global.
     * `state.activeConversationId` is kept as the "most recent active conversation"
     * default for code paths that legitimately need *any* active conversation
     * (autonomy routing, swarm synthesis) and don't target a specific client.
     */
    /** Per-WS-client PTY output subscriptions: sessionId → unsubscribe */
    const wsClientPtySubscriptions = new WeakMap();
    /**
     * Grace-window reap timers for disconnected PTY owners, keyed by clientId.
     * A WS close/error no longer kills the client's PTY sessions instantly —
     * phone lock, app switch, or a network blip would otherwise nuke a live
     * interactive terminal. The stop is delayed by the grace window and
     * canceled when the same clientId re-authenticates (ownership survives
     * reconnects because sessions are owned by clientId, not by socket).
     */
    const wsPtyPendingStops = new Map();
    const wsPtyDisconnectGraceMs = resolvePtyDisconnectGraceMs(process.env.ELIZA_PTY_WS_DISCONNECT_GRACE_MS);
    /**
     * Short-window idempotency cache for client-tagged WS messages, keyed by
     * `${clientId}:${msgId}`. A message resent after a reconnect (same id) is
     * dropped if seen within the TTL. Entries expire so the map stays bounded.
     */
    const wsSeenMessageIds = new Map();
    const WS_DEDUPE_TTL_MS = 30000;
    let wsSeenLastSweepAt = 0;
    const isDuplicateWsMessage = (clientId, msgId) => {
        if (typeof msgId !== "string" || msgId.length === 0)
            return false;
        const key = `${clientId ?? "anon"}:${msgId}`;
        const now = Date.now();
        // O(1) TTL-aware dedupe: a still-fresh entry means this id was already seen
        // within the window. Correctness no longer depends on first scanning the
        // whole map — the previous full-scan-on-every-message was O(n) per message
        // (O(n^2) under a burst).
        const seenAt = wsSeenMessageIds.get(key);
        if (seenAt !== undefined && now - seenAt <= WS_DEDUPE_TTL_MS)
            return true;
        wsSeenMessageIds.set(key, now);
        // Amortized eviction: sweep expired entries at most once per TTL window
        // instead of on every message; keeps the map bounded without the per-
        // message scan.
        if (now - wsSeenLastSweepAt > WS_DEDUPE_TTL_MS) {
            wsSeenLastSweepAt = now;
            for (const [seenKey, ts] of wsSeenMessageIds) {
                if (now - ts > WS_DEDUPE_TTL_MS)
                    wsSeenMessageIds.delete(seenKey);
            }
        }
        return false;
    };
    bindRuntimeStreams(opts?.runtime ?? null);
    // Wire coding-agent bridges at initial boot (event-driven via getServiceLoadPromise)
    if (opts?.runtime) {
        void wireCoordinatorBridgesWhenReady(state, {
            wireChatBridge: wireCodingAgentChatBridge,
            wireWsBridge: wireCodingAgentWsBridge,
            wireEventRouting: wireCoordinatorEventRouting,
            wireSwarmSynthesis: wireCodingAgentSwarmSynthesis,
            context: "boot",
            logger,
        });
    }
    // The device-bridge WebSocket endpoint delegates authentication to the
    // capacitor bridge's own upgrade handler (a pairing-token check that closes
    // unauthorized sockets with 4001). That delegation is only valid when the
    // bridge can actually be attached: the plugin refuses to attach without a
    // pairing token, so with none configured nothing is listening on the path —
    // fall through to the standard upgrade rejection instead of skipping auth
    // and leaving the socket unanswered (W1-011). The same fail-closed rule
    // applies when delegation is EXPECTED but the deferred attach never landed
    // a listener — an import rejection resolves through the no-op fallback API
    // and a failed attach only logs, so an unconditional early return would
    // leave the raw pre-auth socket unanswered indefinitely, outside the
    // W5-015 pending-socket cap and auth grace period (W9-AGENT-01).
    const isDeviceBridgeDelegationExpected = () => {
        if (!isMobilePlatform() &&
            process.env.ELIZA_DEVICE_BRIDGE_ENABLED?.trim() !== "1") {
            return false;
        }
        // Mirrors the pairing-token env contract enforced by
        // @elizaos/plugin-native-inference/host-bridge's attachMobileDeviceBridgeToServer.
        return Boolean(process.env.ELIZA_DEVICE_PAIRING_TOKEN?.trim() ||
            process.env.ELIZA_DEVICE_BRIDGE_TOKEN?.trim());
    };
    // Requests authenticated by the host hook must remain authenticated when
    // `ws` emits its later connection event. IncomingMessage identity is stable
    // across handleUpgrade, and WeakSet avoids retaining completed requests.
    const hostAuthorizedWebSocketRequests = new WeakSet();
    // Handle upgrade requests for WebSocket
    // Async: the handshake-bearer session lookup below awaits the host's
    // session store. Every throw lands inside the try/catch, so the listener's
    // returned promise never rejects unobserved.
    server.on("upgrade", async (request, socket, head) => {
        // The raw upgrade socket can emit 'error' (client RST mid-handshake) before
        // a WebSocket — and its error handler — exists. Unhandled, it crashes the
        // process. Attach a no-op-ish guard for the whole upgrade window.
        socket.on("error", (err) => {
            logger.warn(`[eliza-api] WS upgrade socket error: ${err instanceof Error ? err.message : err}`);
            try {
                socket.destroy();
            }
            catch {
                // error-policy:J6 best-effort teardown — the socket may already be
                // destroyed after the failed upgrade; nothing more to do.
            }
        });
        try {
            const hostRejection = await admitHostRequest(request, "upgrade");
            if (hostRejection !== null) {
                rejectWebSocketUpgrade(socket, hostRejection, "Host admission denied");
                return;
            }
            if (await opts?.handleProtocolUpgrade?.(request, socket, head))
                return;
            const wsUrl = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
            if (wsUrl.pathname === "/api/local-inference/device-bridge" &&
                isDeviceBridgeDelegationExpected() &&
                deviceBridgeUpgradeHandlerAttached) {
                return;
            }
            let rejection = resolveWebSocketUpgradeRejection(request, wsUrl);
            if (rejection?.status === 401) {
                // Device pairing mints a revocable machine-session id as the client's
                // bearer — never the static connection key (#13985) — so the static
                // check above cannot recognize a paired device. Before letting the
                // 401 stand, resolve the presented handshake bearer through the same
                // host-bridge session seam REST uses. Fail-closed: an absent token or
                // an unknown/expired/revoked session keeps the rejection.
                const handshakeToken = extractWebSocketHandshakeToken(request, wsUrl);
                if (handshakeToken) {
                    // The session lookup is asynchronous store work, so it must sit
                    // behind the same per-peer pre-auth admission cap as post-open
                    // authentication — otherwise repeated invalid bearers from one
                    // remote could fan out unbounded concurrent store lookups. The
                    // slot is held only for the lookup itself; the pre-auth socket
                    // flow below re-acquires its own longer-lived slot.
                    const lookupPeer = request.socket.remoteAddress ?? null;
                    if (!tryAcquirePendingWebSocket(lookupPeer)) {
                        rejectWebSocketUpgrade(socket, 401, "Too many unauthenticated WebSocket connections");
                        return;
                    }
                    try {
                        if (await isWebSocketSessionTokenAuthorized(handshakeToken, getAuthenticationRuntime())) {
                            markWebSocketUpgradeSessionAuthorized(request);
                            rejection = null;
                        }
                    }
                    finally {
                        releasePendingWebSocket(lookupPeer);
                    }
                }
            }
            if (rejection) {
                rejectWebSocketUpgrade(socket, rejection.status, rejection.reason);
                return;
            }
            // The session lookup above yields to the event loop; the client may
            // have gone away in the meantime. Bail before reserving a pre-auth
            // slot that no connection handler would ever release.
            if (socket.destroyed) {
                return;
            }
            // W5-015: an upgrade without handshake credentials is allowed so the
            // client can authenticate post-open, but concurrent pre-auth sockets
            // are capped per peer — an unbounded accept was a remote FD-exhaustion
            // DoS. The slot releases when the socket authenticates or closes (see
            // the connection handler), or in the catch below if the upgrade fails.
            let pendingWsPeer;
            const staticallyAuthorized = isWebSocketAuthorized(request, wsUrl);
            const sessionAuthorized = isWebSocketUpgradeSessionAuthorized(request);
            let hostAuthorized = false;
            if (!staticallyAuthorized &&
                !sessionAuthorized &&
                opts?.authorizeWebSocket) {
                try {
                    hostAuthorized = await opts.authorizeWebSocket(request, wsUrl);
                }
                catch (error) {
                    // error-policy:J1 host authentication is an outer protocol boundary:
                    // fail closed for that credential and retain the bounded post-open
                    // static-token flow instead of crashing the server.
                    logger.error(`[eliza-api] host WebSocket authorization failed: ${error instanceof Error ? error.message : String(error)}`);
                }
            }
            if (hostAuthorized) {
                hostAuthorizedWebSocketRequests.add(request);
            }
            if (!staticallyAuthorized && !sessionAuthorized && !hostAuthorized) {
                const peer = request.socket.remoteAddress ?? null;
                if (!tryAcquirePendingWebSocket(peer)) {
                    rejectWebSocketUpgrade(socket, 401, "Too many unauthenticated WebSocket connections");
                    return;
                }
                pendingWsPeer = peer;
            }
            try {
                wss.handleUpgrade(request, socket, head, (ws) => {
                    // Attach an 'error' listener IMMEDIATELY — before emit('connection')
                    // runs the (long) connection handler that only attaches its own error
                    // listener near the end. A client that RSTs in that window otherwise
                    // emits an unhandled 'error' on the ws and crashes the process.
                    ws.on("error", (err) => {
                        logger.warn(`[eliza-api] WebSocket error: ${err instanceof Error ? err.message : err}`);
                    });
                    wss.emit("connection", ws, request);
                });
            }
            catch (upgradeErr) {
                hostAuthorizedWebSocketRequests.delete(request);
                // error-policy:J2 release the reserved pre-auth slot, then rethrow
                // unchanged into the outer boundary handler.
                if (pendingWsPeer !== undefined) {
                    releasePendingWebSocket(pendingWsPeer);
                }
                throw upgradeErr;
            }
        }
        catch (err) {
            hostAuthorizedWebSocketRequests.delete(request);
            logger.error(`[eliza-api] WebSocket upgrade error: ${err instanceof Error ? err.message : err}`);
            rejectWebSocketUpgrade(socket, 404, "Not found");
        }
    });
    // Handle WebSocket connections
    wss.on("connection", (ws, request) => {
        wsRequests.set(ws, request);
        wsLiveness.track(ws);
        let wsClientId = null;
        let wsUrl;
        try {
            wsUrl = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
            const clientId = normalizeWsClientId(wsUrl.searchParams.get("clientId"));
            if (clientId) {
                wsClientId = clientId;
                wsClientIds.set(ws, clientId);
            }
        }
        catch {
            // Ignore malformed WS URL metadata; auth/path were already validated.
            wsUrl = new URL("ws://localhost/ws");
        }
        const hostAuthorized = hostAuthorizedWebSocketRequests.delete(request);
        let isAuthenticated = hostAuthorized ||
            isWebSocketAuthorized(request, wsUrl) ||
            isWebSocketUpgradeSessionAuthorized(request);
        if (isWebSocketUpgradeSessionAuthorized(request)) {
            const token = extractWebSocketHandshakeToken(request, wsUrl);
            if (token)
                wsSessions.set(ws, {
                    token,
                    checkedAt: 0,
                    revoked: false,
                    generation: 0,
                });
        }
        // Serializes in-band machine-session lookups for this socket (see the
        // auth branch of the message handler).
        let inBandSessionLookupInFlight = false;
        // W5-015: the upgrade handler reserved a pre-auth slot for this socket's
        // peer. It releases on post-open authentication or on close — whichever
        // comes first — and a socket that never authenticates is closed when the
        // grace period expires, so a silent peer can no longer pin a file
        // descriptor indefinitely. The peer is captured now so the release keys
        // on the same bucket even if the socket is already torn down.
        const pendingWsPeer = request.socket?.remoteAddress ?? null;
        let pendingSlotHeld = !isAuthenticated;
        const releasePendingSlot = () => {
            if (!pendingSlotHeld)
                return;
            pendingSlotHeld = false;
            releasePendingWebSocket(pendingWsPeer);
        };
        let authGraceTimer = null;
        const clearAuthGraceTimer = () => {
            if (authGraceTimer) {
                clearTimeout(authGraceTimer);
                authGraceTimer = null;
            }
        };
        if (!isAuthenticated) {
            authGraceTimer = setTimeout(() => {
                authGraceTimer = null;
                logger.warn("[eliza-api] closing WebSocket that did not authenticate within the grace period");
                ws.close(1008, "Unauthorized");
            }, WS_AUTH_GRACE_TIMEOUT_MS);
            // A stuck pre-auth socket must not hold the process open on shutdown.
            authGraceTimer.unref?.();
        }
        // Optional reconnect cursor: a client that tracks the highest buffered
        // event sequence it has applied can pass it back as `?lastEventId=` so the
        // server replays only the envelopes it is missing instead of re-flooding
        // the full tail on every (re)connect (loadperf research 05, Finding 4).
        // Absent/invalid => null => the historical slice(-DEFAULT_REPLAY_LIMIT)
        // behavior, so existing clients are unaffected.
        const replayCursor = parseEventCursor(wsUrl.searchParams.get("lastEventId") ?? wsUrl.searchParams.get("since"));
        const activateAuthenticatedConnection = () => {
            wsClients.add(ws);
            if (wsClientId &&
                cancelPendingPtySessionStop(wsClientId, wsPtyPendingStops)) {
                logger.info(`[eliza-api] client ${wsClientId} reconnected within the PTY grace window; keeping its PTY sessions alive`);
            }
            addLog("info", "WebSocket client connected", "websocket", [
                "server",
                "websocket",
            ]);
            const sendInitialStatus = async () => {
                try {
                    const runtime = state.runtime;
                    const agentState = state.agentState;
                    const readiness = await responseReadinessFields(runtime, agentState);
                    if (!wsClients.has(ws) || !isAuthenticated)
                        return;
                    if (runtime === state.runtime && agentState === state.agentState)
                        sendWebSocket(ws, JSON.stringify({
                            type: "status",
                            state: state.agentState,
                            agentName: state.agentName,
                            model: state.model,
                            // Same server-authoritative readiness signal as broadcastStatus and
                            // /api/status. Without it on the initial-connect status, every WS
                            // (re)connect delivers canRespond: undefined and re-gates the chat
                            // composer back to "waking up" until the next 5s broadcast.
                            ...readiness,
                            startedAt: state.startedAt,
                            startup: state.startup,
                            pendingRestart: state.pendingRestartReasons.length > 0,
                            pendingRestartReasons: state.pendingRestartReasons,
                        }));
                }
                catch (error) {
                    logger.warn({ error, src: "eliza-api" }, "Initial WebSocket status unavailable");
                }
            };
            void sendInitialStatus();
            // Replay stays synchronous so newer live events cannot overtake history
            // while the optional model-readiness probe reads the local registry.
            // Pagination stays synchronous for the same reason: every page must
            // drain before the live subscription attaches, or a live event could
            // be delivered ahead of the history it belongs to.
            try {
                let cursor = replayCursor;
                const maxPages = Math.ceil(state.eventBuffer.length / DEFAULT_REPLAY_LIMIT) + 1;
                for (let page = 0; page < maxPages; page++) {
                    const result = selectReplayEvents(state.eventBuffer, cursor, DEFAULT_REPLAY_LIMIT);
                    for (const event of result.events) {
                        sendWebSocket(ws, JSON.stringify(event));
                    }
                    if (!result.hasMore || result.nextCursor === null)
                        break;
                    cursor = result.nextCursor;
                }
            }
            catch (err) {
                logger.error(`[eliza-api] WebSocket send error: ${err instanceof Error ? err.message : err}`);
            }
        };
        if (isAuthenticated) {
            activateAuthenticatedConnection();
        }
        const currentClientOwnsPtySession = (sessionId) => {
            const service = getPtyService(state);
            const session = service
                ?.listSessions?.()
                .find((candidate) => candidate.sessionId === sessionId);
            if (!session?.ownerClientId)
                return true;
            return Boolean(wsClientId && session.ownerClientId === wsClientId);
        };
        const stopOwnedPtySessions = (reason) => {
            if (!wsClientId)
                return;
            const service = getPtyService(state);
            if (!service?.listSessions || !service.stopSession)
                return;
            const owned = service
                .listSessions()
                .filter((session) => session.ownerClientId === wsClientId);
            for (const session of owned) {
                void service.stopSession(session.sessionId).catch((err) => {
                    logger.warn(`[eliza-api] failed to stop PTY session ${session.sessionId} on ${reason}: ${err instanceof Error ? err.message : err}`);
                });
            }
        };
        /**
         * Reap this client's PTY sessions only after the disconnect grace window,
         * and only if no other live authenticated socket carries the same
         * clientId (multi-tab) and the client hasn't reconnected in the interim.
         */
        const scheduleStopOwnedPtySessions = (reason) => {
            if (!wsClientId)
                return;
            const clientId = wsClientId;
            const clientHasLiveConnection = () => {
                for (const other of wsClients) {
                    if (other !== ws &&
                        other.readyState === 1 &&
                        wsClientIds.get(other) === clientId) {
                        return true;
                    }
                }
                return false;
            };
            schedulePtySessionStopAfterGrace({
                clientId,
                graceMs: wsPtyDisconnectGraceMs,
                pendingStops: wsPtyPendingStops,
                clientHasLiveConnection,
                stopOwnedSessions: () => stopOwnedPtySessions(reason),
            });
        };
        ws.on("message", async (data) => {
            try {
                if ((hostAdmission || wsSessions.has(ws)) &&
                    !(await admitWebSocket(ws, request, "websocket-message")))
                    return;
                const msg = JSON.parse(String(data));
                if (!isAuthenticated) {
                    const expected = getConfiguredApiToken();
                    const providedToken = msg.type === "auth" && typeof msg.token === "string"
                        ? msg.token.trim()
                        : "";
                    let authorized = Boolean(expected && providedToken && tokenMatches(expected, providedToken));
                    if (!authorized && providedToken) {
                        // A paired remote client's bearer is a revocable machine-session
                        // id, never the static connection key (#13985). Resolve it through
                        // the same host-bridge session seam REST uses; unknown, expired,
                        // and revoked sessions fall through to the fail-closed 1008.
                        // At most one store lookup may be in flight per socket: the
                        // lookup is asynchronous, so an attacker spamming auth frames on
                        // one pre-auth socket must not fan out concurrent store work.
                        // Extra frames are dropped; the in-flight lookup's verdict
                        // decides this socket either way.
                        if (inBandSessionLookupInFlight) {
                            return;
                        }
                        inBandSessionLookupInFlight = true;
                        try {
                            authorized = await isWebSocketSessionTokenAuthorized(providedToken, getAuthenticationRuntime());
                            if (authorized)
                                wsSessions.set(ws, {
                                    token: providedToken,
                                    checkedAt: 0,
                                    revoked: false,
                                    generation: 0,
                                });
                        }
                        finally {
                            inBandSessionLookupInFlight = false;
                        }
                        if (isAuthenticated) {
                            // Another frame authenticated this socket while the session
                            // lookup was in flight; this pre-auth frame is spent either way.
                            return;
                        }
                    }
                    if (authorized) {
                        isAuthenticated = true;
                        clearAuthGraceTimer();
                        releasePendingSlot();
                        sendWebSocket(ws, JSON.stringify({ type: "auth-ok" }));
                        activateAuthenticatedConnection();
                    }
                    else {
                        logger.warn("[eliza-api] WebSocket message rejected before auth");
                        ws.close(1008, "Unauthorized");
                    }
                    return;
                }
                if (isDuplicateWsMessage(wsClientIds.get(ws), msg.msgId)) {
                    return;
                }
                if (msg.type === "ping") {
                    sendWebSocket(ws, JSON.stringify({ type: "pong" }));
                }
                else if (msg.type === "active-conversation") {
                    // Per-connection: only this client's active conversation changes.
                    const conversationId = typeof msg.conversationId === "string" ? msg.conversationId : null;
                    if (conversationId) {
                        wsActiveConversations.set(ws, conversationId);
                    }
                    else {
                        wsActiveConversations.delete(ws);
                    }
                    // Keep the global as a sensible "any/most-recent active conversation"
                    // default for non-client-targeted routing (autonomy, swarm synthesis).
                    state.activeConversationId = conversationId;
                }
                else if (msg.type === "pty-subscribe" &&
                    typeof msg.sessionId === "string") {
                    const bridge = getPtyConsoleBridge(state);
                    if (bridge) {
                        if (!currentClientOwnsPtySession(msg.sessionId)) {
                            logger.warn(`[eliza-api] pty-subscribe rejected: client ${wsClientId ?? "unknown"} does not own session ${msg.sessionId}`);
                            return;
                        }
                        let subs = wsClientPtySubscriptions.get(ws);
                        if (!subs) {
                            subs = new Map();
                            wsClientPtySubscriptions.set(ws, subs);
                        }
                        // Don't double-subscribe
                        if (!subs.has(msg.sessionId)) {
                            const targetId = msg.sessionId;
                            // Bridges BOTH `session_output` (→ pty-output) and
                            // `session_exit` (→ pty-exit) so the client can surface a dead
                            // session instead of showing a "ready" pane forever.
                            const detach = attachPtySessionWsBridge({
                                bridge,
                                sessionId: targetId,
                                send: (frame) => {
                                    if (ws.readyState === 1) {
                                        sendWebSocket(ws, JSON.stringify(frame));
                                    }
                                },
                            });
                            subs.set(targetId, detach);
                        }
                    }
                }
                else if (msg.type === "pty-unsubscribe" &&
                    typeof msg.sessionId === "string") {
                    const subs = wsClientPtySubscriptions.get(ws);
                    const unsub = subs?.get(msg.sessionId);
                    if (unsub) {
                        unsub();
                        subs?.delete(msg.sessionId);
                    }
                }
                else if (msg.type === "pty-input" &&
                    typeof msg.sessionId === "string" &&
                    typeof msg.data === "string") {
                    // Only allow input to sessions this client has subscribed to
                    const subs = wsClientPtySubscriptions.get(ws);
                    if (!subs?.has(msg.sessionId)) {
                        logger.warn(`[eliza-api] pty-input rejected: client not subscribed to session ${msg.sessionId}`);
                    }
                    else if (!currentClientOwnsPtySession(msg.sessionId)) {
                        logger.warn(`[eliza-api] pty-input rejected: client ${wsClientId ?? "unknown"} does not own session ${msg.sessionId}`);
                    }
                    else if (msg.data.length > MAX_PTY_INPUT_MESSAGE_LENGTH) {
                        // Per-message DoS cap only — the client chunks large pastes into
                        // <=cap messages (sendPtyInput), so hitting this means a
                        // misbehaving client. Echo a pty-error so the drop isn't silent.
                        logger.warn(`[eliza-api] pty-input rejected: payload too large (${msg.data.length} chars) for session ${msg.sessionId}`);
                        if (ws.readyState === 1) {
                            sendWebSocket(ws, JSON.stringify({
                                type: "pty-error",
                                sessionId: msg.sessionId,
                                code: "input-too-large",
                                message: `pty-input exceeds ${MAX_PTY_INPUT_MESSAGE_LENGTH} chars; send large input in chunks`,
                            }));
                        }
                    }
                    else {
                        const bridge = getPtyConsoleBridge(state);
                        if (bridge) {
                            logger.debug(`[eliza-api] pty-input: session=${msg.sessionId} len=${msg.data.length}`);
                            bridge.writeRaw(msg.sessionId, msg.data);
                        }
                    }
                }
                else if (msg.type === "pty-resize" &&
                    typeof msg.sessionId === "string") {
                    // Only allow resize for sessions this client has subscribed to
                    const subs = wsClientPtySubscriptions.get(ws);
                    if (!subs?.has(msg.sessionId)) {
                        logger.warn(`[eliza-api] pty-resize rejected: client not subscribed to session ${msg.sessionId}`);
                    }
                    else if (!currentClientOwnsPtySession(msg.sessionId)) {
                        logger.warn(`[eliza-api] pty-resize rejected: client ${wsClientId ?? "unknown"} does not own session ${msg.sessionId}`);
                    }
                    else {
                        const bridge = getPtyConsoleBridge(state);
                        if (bridge &&
                            typeof msg.cols === "number" &&
                            typeof msg.rows === "number" &&
                            Number.isFinite(msg.cols) &&
                            Number.isFinite(msg.rows) &&
                            Number.isInteger(msg.cols) &&
                            Number.isInteger(msg.rows) &&
                            msg.cols >= 1 &&
                            msg.cols <= 500 &&
                            msg.rows >= 1 &&
                            msg.rows <= 500) {
                            bridge.resize(msg.sessionId, msg.cols, msg.rows);
                        }
                        else {
                            logger.warn(`[eliza-api] pty-resize rejected: invalid dimensions cols=${msg.cols} rows=${msg.rows}`);
                        }
                    }
                }
                else if (msg.type === "view:interact:result" &&
                    typeof msg.requestId === "string") {
                    void import("./views-routes.js")
                        .then(({ resolveViewInteractResult }) => {
                        if (!state.runtime || !wsClientId)
                            return;
                        resolveViewInteractResult(state.runtime, state, wsClientId, {
                            requestId: msg.requestId,
                            viewId: typeof msg.viewId === "string" ? msg.viewId : undefined,
                            viewType: typeof msg.viewType === "string" ? msg.viewType : undefined,
                            installationId: typeof msg.installationId === "string"
                                ? msg.installationId
                                : undefined,
                            claimId: typeof msg.claimId === "string" ? msg.claimId : undefined,
                            success: msg.success === true,
                            result: msg.result,
                            error: typeof msg.error === "string" ? msg.error : undefined,
                        });
                    })
                        .catch((err) => {
                        logger.error(`[eliza-api] view interaction result error: ${err instanceof Error ? err.message : err}`);
                    });
                }
            }
            catch (err) {
                logger.error(`[eliza-api] WebSocket message error: ${err instanceof Error ? err.message : err}`);
            }
        });
        ws.on("close", () => {
            clearAuthGraceTimer();
            releasePendingSlot();
            wsClients.delete(ws);
            wsSessions.delete(ws);
            wsActiveConversations.delete(ws);
            // Clean up any PTY output subscriptions for this client
            const subs = wsClientPtySubscriptions.get(ws);
            if (subs) {
                for (const unsub of subs.values())
                    unsub();
                subs.clear();
            }
            scheduleStopOwnedPtySessions("websocket close");
            addLog("info", "WebSocket client disconnected", "websocket", [
                "server",
                "websocket",
            ]);
        });
        ws.on("error", (err) => {
            logger.error(`[eliza-api] WebSocket error: ${err instanceof Error ? err.message : err}`);
            clearAuthGraceTimer();
            releasePendingSlot();
            wsClients.delete(ws);
            wsActiveConversations.delete(ws);
            // Clean up PTY subscriptions on error too
            const subs = wsClientPtySubscriptions.get(ws);
            if (subs) {
                for (const unsub of subs.values())
                    unsub();
                subs.clear();
            }
            scheduleStopOwnedPtySessions("websocket error");
        });
    });
    // Broadcast status to all connected WebSocket clients (flattened — PR #36 fix)
    let statusReadinessSequence = 0;
    const broadcastStatus = async () => {
        // The existing five-second status cadence detects revocations/expiry from
        // other processes. One coalesced lookup gates all queued frames per socket.
        for (const session of wsSessions.values())
            session.checkedAt = 0;
        // Skip the payload build + computeCanRespond() when no dashboard is
        // connected. This fires every 5s (statusInterval) plus on every state
        // change for the whole process lifetime; a headless / background agent
        // commonly has zero WS clients, so this was pure idle-CPU waste. A newly
        // connected client gets its authoritative status on connect (see
        // activateAuthenticatedConnection), so nothing depends on this running
        // while the client set is empty.
        if (wsClients.size === 0) {
            return;
        }
        const sequence = ++statusReadinessSequence;
        const runtime = state.runtime;
        const agentState = state.agentState;
        const readiness = await responseReadinessFields(runtime, agentState);
        if (sequence !== statusReadinessSequence ||
            runtime !== state.runtime ||
            agentState !== state.agentState)
            return;
        broadcastWs({
            type: "status",
            state: state.agentState,
            agentName: state.agentName,
            model: state.model,
            // Carry the same server-authoritative readiness signal `/api/status`
            // returns. Without it, every 5s WS status broadcast resets the client's
            // `agentStatus.canRespond` to undefined, re-gating the chat composer back
            // to "waking up" even though the agent is fully ready and replying.
            ...readiness,
            startedAt: state.startedAt,
            startup: state.startup,
            pendingRestart: state.pendingRestartReasons.length > 0,
            pendingRestartReasons: state.pendingRestartReasons,
        });
    };
    // Make broadcastStatus accessible to route handlers via state
    state.broadcastStatus = broadcastStatus;
    // Flip the WS status lane the moment a model handler registers instead of
    // waiting for the next 5s statusInterval tick: `canRespond` turns true when a
    // late-registering provider (deferred wave, first-run configure, runtime
    // plugin install) adds its TEXT_GENERATION handler, and the launcher clears
    // its "Waking…" banner on that signal. A provider registers one handler per
    // model type, so coalesce the burst into a single broadcast per tick.
    const modelBroadcastWiredRuntimes = new WeakSet();
    let modelBroadcastScheduled = false;
    const wireModelRegistrationBroadcast = (rt) => {
        if (!rt || modelBroadcastWiredRuntimes.has(rt))
            return;
        modelBroadcastWiredRuntimes.add(rt);
        rt.registerEvent(EventType.MODEL_REGISTERED, async () => {
            if (modelBroadcastScheduled)
                return;
            modelBroadcastScheduled = true;
            setTimeout(() => {
                modelBroadcastScheduled = false;
                broadcastStatus();
            }, 0);
        });
    };
    wireModelRegistrationBroadcast(state.runtime);
    wireNativeBrowserPageReader(state.runtime);
    state.broadcastWs = (data) => eventHub.broadcast(data);
    state.broadcastWsToClientId = (clientId, data) => eventHub.sendToClient(clientId, data);
    // View interactions originate outside HTTP requests and share the same event
    // hub as route and runtime events.
    void import("./views-routes.js")
        .then(({ setViewsBroadcastWs }) => {
        setViewsBroadcastWs(state, state.broadcastWs ?? null, state.broadcastWsToClientId ?? null);
    })
        .catch((err) => {
        logger.error(`[eliza-api] failed to wire views broadcaster: ${err instanceof Error ? err.message : err}`);
    });
    state.broadcastWsToConversation = (conversationId, data) => eventHub.sendToConversation(conversationId, data);
    // Broadcast status every 5 seconds
    const statusInterval = setInterval(broadcastStatus, 5000);
    /**
     * Restore the in-memory conversation list from the database. The scan/rebuild
     * logic lives in `./conversation-restore.ts` so the relaunch round-trip can be
     * driven against a real DB in tests (#13689); here we just bind it to this
     * server's live `state` + structured log sink.
     */
    const restoreConversationsFromDb = async (rt) => {
        await restoreConversationsFromDbImpl(rt, {
            conversations: state.conversations,
            deletedConversationIds: state.deletedConversationIds,
            log: (message) => addLog("info", message, "system", ["system"]),
        });
    };
    const beginConversationRestore = (rt) => {
        const restorePromise = restoreConversationsFromDb(rt).finally(() => {
            if (state.conversationRestorePromise === restorePromise) {
                state.conversationRestorePromise = null;
            }
        });
        state.conversationRestorePromise = restorePromise;
        return restorePromise;
    };
    /**
     * Load the agent's DB-persisted character data and overlay onto the
     * in-memory runtime.character.  This ensures Character Editor edits
     * survive server restarts without depending on eliza.json persistence.
     */
    const overlayDbCharacter = async (rt, st) => {
        try {
            const dbAgent = await rt.getAgent(rt.agentId);
            const agentRecord = dbAgent && typeof dbAgent === "object" && !Array.isArray(dbAgent)
                ? Object.fromEntries(Object.entries(dbAgent))
                : null;
            const saved = agentRecord?.character;
            if (!saved || typeof saved !== "object")
                return;
            const c = rt.character;
            // Only overlay fields that were explicitly saved (non-empty)
            if (typeof saved.name === "string" && saved.name)
                c.name = saved.name;
            if (Array.isArray(saved.bio) && saved.bio.length > 0) {
                c.bio = saved.bio;
            }
            if (typeof saved.system === "string" && saved.system) {
                c.system = saved.system;
            }
            if (Array.isArray(saved.adjectives)) {
                c.adjectives = saved.adjectives;
            }
            if (Array.isArray(saved.topics)) {
                c.topics = saved.topics;
            }
            if (saved.style && typeof saved.style === "object") {
                c.style = saved.style;
            }
            if (Array.isArray(saved.messageExamples)) {
                c.messageExamples = saved.messageExamples;
            }
            if (Array.isArray(saved.postExamples) && saved.postExamples.length > 0) {
                c.postExamples = saved.postExamples;
            }
            // Update agent name on state
            st.agentName = c.name ?? st.agentName;
            logger.info(`[character-db] Overlaid DB-persisted character "${c.name}" onto runtime`);
        }
        catch (err) {
            logger.warn(`[character-db] Failed to load character from DB: ${err instanceof Error ? err.message : err}`);
        }
    };
    // Restore conversations from DB at initial boot (if runtime was passed in)
    if (opts?.runtime) {
        void beginConversationRestore(opts.runtime).catch((err) => {
            logger.warn("[api] Conversation restore failed:", err);
        });
        void overlayDbCharacter(opts.runtime, state).catch((err) => {
            logger.warn("[api] Character overlay restore failed:", err);
        });
        registerClientChatSendHandler(opts.runtime, state);
        wireProactiveInteractionDecider(opts.runtime, state);
    }
    const assertX402RoutesValid = async (rt) => {
        if (!rt || !runtimeRoutesNeedX402Validation(getHttpRuntime(rt).routes))
            return;
        const agentId = rt.agentId != null && String(rt.agentId).length > 0
            ? String(rt.agentId)
            : undefined;
        const x402 = await getX402Plugin();
        if (!x402)
            return; // x402 module unavailable (e.g. mobile bundle) — nothing to validate
        const { validateX402Startup } = x402;
        if (!validateX402Startup)
            return;
        const result = validateX402Startup(getHttpRuntime(rt).routes, rt.character, {
            agentId,
        });
        if (!result || typeof result !== "object") {
            logger.warn("[x402] startup validator returned no result; skipping x402 route validation");
            return;
        }
        if (!result.valid) {
            throw new Error(`x402 configuration invalid:\n${result.errors.map((e) => `  • ${e}`).join("\n")}`);
        }
        for (const w of result.warnings) {
            logger.warn(`[x402] ${w}`);
        }
    };
    /** Hot-swap the runtime reference (used after an in-process restart). */
    const updateRuntime = (rt) => {
        registerRuntimeBuiltinViews(rt);
        registerBuiltinViewScopedActions(rt, "after update");
        void assertX402RoutesValid(rt).catch((err) => {
            logger.error(`[x402] runtime route validation failed after update: ${err instanceof Error ? err.message : String(err)}`);
        });
        state.runtime = rt;
        bindInProcessApi();
        state.connectorHealthMonitor?.setRuntime(rt);
        state.chatConnectionReady = null;
        state.chatConnectionPromise = null;
        bindRuntimeStreams(rt);
        wireModelRegistrationBroadcast(rt);
        wireNativeBrowserPageReader(rt);
        // AppManager doesn't need a runtime reference
        state.agentState = "running";
        state.agentName =
            rt.character.name ?? resolveDefaultAgentName(state.config);
        state.model = detectRuntimeModel(rt, state.config);
        state.startedAt = Date.now();
        state.startup = {
            phase: "running",
            attempt: 0,
        };
        addLog("info", `Runtime restarted — agent: ${state.agentName}`, "system", [
            "system",
            "agent",
        ]);
        // Restore conversations from DB so they survive restarts
        void beginConversationRestore(rt).catch((err) => {
            logger.warn("[api] Conversation restore failed on restart:", err);
        });
        // Overlay DB-persisted character data (from Character Editor saves)
        void overlayDbCharacter(rt, state).catch((err) => {
            logger.warn("[api] Character overlay restore failed on restart:", err);
        });
        // Broadcast status update immediately after restart
        broadcastStatus();
        // Re-register client_chat send handler on the new runtime
        registerClientChatSendHandler(rt, state);
        wireProactiveInteractionDecider(rt, state);
        // Wire coding-agent bridges (event-driven via getServiceLoadPromise)
        void wireCoordinatorBridgesWhenReady(state, {
            wireChatBridge: wireCodingAgentChatBridge,
            wireWsBridge: wireCodingAgentWsBridge,
            wireEventRouting: wireCoordinatorEventRouting,
            wireSwarmSynthesis: wireCodingAgentSwarmSynthesis,
            context: "restart",
            logger,
        });
    };
    const updateStartup = (update) => {
        const { state: nextState, ...startupUpdate } = update;
        state.startup = {
            ...state.startup,
            ...startupUpdate,
        };
        if (nextState) {
            state.agentState = nextState;
            if (nextState === "error") {
                state.startedAt = undefined;
            }
            else if ((nextState === "starting" || nextState === "running") &&
                !state.startedAt) {
                state.startedAt = Date.now();
            }
        }
        broadcastStatus();
    };
    logger.debug(`[eliza-api] Calling server.listen (${Date.now() - apiStartTime}ms)`);
    let earlyEntries = [];
    try {
        await assertX402RoutesValid(state.runtime);
        // The logger package owns all global and child logger methods. Register the
        // server listener before releasing early capture so startup has no gap.
        detachApiLogListener = listenForUiLogs(captureStructuredLog);
    }
    finally {
        earlyEntries = flushEarlyLogs();
    }
    if (earlyEntries.length > 0) {
        for (const entry of earlyEntries) {
            state.logBuffer.push(entry);
        }
        addLog("info", `Flushed ${earlyEntries.length} early startup log entries`, "system", ["system"]);
    }
    addLog("info", "Structured logger connected — agent logs will stream to the UI", "system", ["system", "agent"]);
    const serverResources = createServerResources((resource, error) => {
        // error-policy:J6 every teardown is attempted and awaited; one failure is
        // reported without abandoning the remaining resources.
        logger.warn({ error, resource }, `[eliza-api] Failed to close ${resource}`);
    });
    for (const resource of [
        {
            name: "session revocation listener",
            dispose: () => unsubscribeSessionRevocations?.(),
        },
        {
            name: "status interval",
            dispose: () => clearInterval(statusInterval),
        },
        {
            name: "API log listener",
            dispose: () => {
                detachApiLogListener?.();
                detachApiLogListener = null;
            },
        },
        {
            name: "connector health monitor",
            dispose: () => {
                state.connectorHealthMonitor?.stop();
                state.connectorHealthMonitor = null;
            },
        },
        {
            name: "provider model cache warm-up",
            dispose: async () => {
                await providerCacheWarmupPromise;
            },
        },
        {
            name: "runtime event streams",
            dispose: () => {
                detachRuntimeStreams?.();
                detachRuntimeStreams = null;
            },
        },
        {
            name: "WebSocket clients",
            dispose: () => {
                wsLiveness.stop();
                for (const ws of wsClients) {
                    if (ws.readyState !== 1 && ws.readyState !== 0)
                        continue;
                    if ("terminate" in ws && typeof ws.terminate === "function") {
                        ws.terminate();
                    }
                    else {
                        ws.close();
                    }
                }
                wsClients.clear();
            },
        },
        {
            name: "WhatsApp pairing sessions",
            dispose: async () => {
                const sessions = [...(state.whatsappPairingSessions?.values() ?? [])];
                state.whatsappPairingSessions?.clear();
                await Promise.all(sessions.map((session) => session.stop()));
            },
        },
        {
            name: "Telegram account session",
            dispose: async () => {
                const session = state.telegramAccountAuthSession;
                state.telegramAccountAuthSession = null;
                await session?.stop();
            },
        },
        {
            name: "WebSocket server",
            dispose: () => new Promise((resolve) => {
                try {
                    wss.close(() => resolve());
                }
                catch {
                    // A no-server WebSocketServer that never accepted a connection
                    // has no asynchronous close work.
                    resolve();
                }
            }),
        },
    ]) {
        serverResources.add(resource);
    }
    const stopServerSideResources = () => {
        closeViewInteractionHost(state);
        unregisterInProcessApi?.();
        return serverResources.close();
    };
    // Local-agent IPC mode: skip binding a TCP listener entirely. Routes and the
    // in-process dispatchRoute kernel are already wired (server built above), so
    // an IPC transport (stdio bridge / Capacitor / Electrobun RPC) can drive them
    // without opening a port.
    if (opts?.skipListen) {
        apiLap("skipListen (no TCP bind)");
        addLog("info", "API server initialized without a TCP listener (skipListen)", "system", ["server", "system"]);
        logger.info("[eliza-api] Started without binding a TCP listener (skipListen; local-agent IPC mode)");
        if (!opts?.skipDeferredStartupWork) {
            void startDeferredStartupWork();
        }
        return {
            port,
            close: stopServerSideResources,
            updateRuntime,
            runtimeOperations,
            reloadConfigFromDisk,
            updateStartup,
        };
    }
    const listener = await listenHttpServer({
        server,
        host,
        port,
        strictPortBinding: strictPortBindingEnabled(),
        closeResources: stopServerSideResources,
        onBeforeListen: () => apiLap("before server.listen"),
        onPortInUse: (occupiedPort, willFallback) => {
            logger.warn(`[eliza-api] Port ${occupiedPort} is already in use. Checking fallback...`);
            if (willFallback) {
                logger.warn("[eliza-api] Retrying with dynamic port (0)...");
            }
            else {
                logger.error(`[eliza-api] Strict port binding is enabled; refusing dynamic fallback from ${occupiedPort}.`);
            }
        },
        onServerError: (err) => {
            if (err.code !== "EADDRINUSE") {
                logger.error(`[eliza-api] Server error: ${err.message} (code: ${err.code})`);
            }
        },
        onListening: (displayHost, actualPort) => {
            apiLap("LISTENING (API bound)");
            logger.debug(`[eliza-api] server.listen callback fired (${Date.now() - apiStartTime}ms)`);
            addLog("info", `API server listening on http://${displayHost}:${actualPort}`, "system", ["server", "system"]);
            // Log to both stdout (for agent.ts port detection) and the in-memory
            // logger. agent.ts watches stdout for "Listening on http://host:PORT"
            // to detect dynamic port reassignment when the default port is in use.
            console.log(`[eliza-api] Listening on http://${displayHost}:${actualPort}`);
            logger.info(`[eliza-api] Listening on http://${displayHost}:${actualPort}`);
            if (!opts?.skipDeferredStartupWork) {
                void startDeferredStartupWork();
            }
        },
        onCloseHelperError: (helper, error) => {
            logger.debug({ error, helper }, `[eliza-api] ${helper} failed`);
        },
    });
    const releaseLiveConfigSource = hostConfig === undefined
        ? setLiveElizaConfigSource(() => state.config, configWritePath)
        : undefined;
    return {
        port: listener.port,
        close: async () => {
            releaseLiveConfigSource?.();
            await listener.close();
        },
        updateRuntime,
        runtimeOperations,
        reloadConfigFromDisk,
        updateStartup,
    };
}
