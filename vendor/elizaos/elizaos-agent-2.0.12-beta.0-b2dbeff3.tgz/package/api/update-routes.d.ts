/**
 * Mounts the self-update HTTP surface: GET /api/update/status reports the current
 * version, resolved release channel, detected install method, and the computed
 * update action plan (authority, next action, command/instructions — with
 * remote-vs-trusted-local display gated by `isTrustedLocalRequest`), plus the
 * latest versions per channel; PUT /api/update/channel switches the
 * stable/beta/nightly channel and persists it. Dispatched behind the API
 * server's auth layer.
 */
import type http from "node:http";
import type { ElizaConfig, ReadJsonBodyOptions } from "@elizaos/host/protocol";
export interface UpdateRouteContext {
    req: http.IncomingMessage;
    res: http.ServerResponse;
    method: string;
    pathname: string;
    url: URL;
    state: {
        config: ElizaConfig;
    };
    json: (res: http.ServerResponse, data: unknown, status?: number) => void;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    saveElizaConfig: (config: ElizaConfig) => void;
}
export declare function handleUpdateRoutes(ctx: UpdateRouteContext): Promise<boolean>;
