import type http from "node:http";
import { type ChatFailureKind, type ChatTerminalFailure, type ChatToolCallEvent, type ChatTurnStatus, type LinkedAccountProviderId } from "@elizaos/contracts";
import { type ActionReplyFailure, type ActionResult, type AgentRuntime, ChannelType, type ChatImageAttachment, type Content, createMessageMemory, type EffectReceipt, InferenceTurnTimer, type AgentLogEntry as LogEntry, type Memory, type MessageReplyRecoveryContext, type ReadView, type RoomHandlerLease, type TrustedApiPrincipal, type TurnOutcome, type UUID } from "@elizaos/core";
import { type ElizaConfig, type ReadJsonBodyOptions, type RouteRequestContext } from "@elizaos/host/protocol";
import type { AgentHttpRequestAuthorization } from "../runtime/host-bridge.js";
import { type ChatIdempotencyAdmission, type ChatIdempotencyReservation, ChatIdempotencyWaitAbortedError } from "../services/chat-idempotency-service.js";
import { type LocalInferenceChatMetadata, type LocalInferenceCommandIntent } from "./local-inference-server-api.js";
/**
 * Short-window idempotency cache for the HTTP chat path, the analogue of the
 * WebSocket `isDuplicateWsMessage` cache in server.ts. Chat sends go over HTTP
 * SSE (not WS), so the WS cache does not cover them. The client stamps a stable
 * `clientMessageId` on every send (`ui/src/api/client-base.ts`); a retried or
 * double-submitted POST carries the same id, and without this guard would start
 * a second LLM turn and persist a duplicate assistant memory (report 05,
 * Finding 1 / W3.1).
 *
 * Keyed by `${conversationOrUserScope}:${clientMessageId}` so a legitimately
 * identical message in a different conversation, or the same text re-sent after
 * the retention window, is NOT suppressed. The map stays bounded via an
 * amortized sweep (at most once per retention window) — the same O(1)-check /
 * amortized-eviction shape as the WS cache. This window only retains keys; it
 * never delays or aborts a response.
 */
export interface ChatMessageIdOutcome {
    text: string;
    agentName: string;
    messageId?: UUID;
    userMessageId?: UUID;
    assistantEphemeral?: boolean;
    historyRefreshRequired?: boolean;
    transcriptVisibility?: "internal";
    thought?: string;
    usage?: ChatGenerationResult["usage"];
    actionResults?: ChatActionResultSummary[];
    failureKind?: ChatFailureKind;
    terminalFailure?: ChatTerminalFailure;
    /** A server-persisted reply can be regenerated without re-running this turn. */
    replyRecoveryAvailable?: true;
    accountConnect?: AccountConnectRequest;
    localInference?: LocalInferenceChatMetadata;
    noResponseReason?: "ignored";
    /**
     * The turn ended by explicit Stop/disconnect abort. `text` carries the
     * partial reply that streamed before the abort (possibly empty for a
     * zero-token Stop) and `messageId` its durable interrupted receipt, so a
     * retried key adopts the interrupted outcome instead of regenerating.
     */
    interrupted?: boolean;
}
export type ChatMessageIdAdmission = ChatIdempotencyAdmission<ChatMessageIdOutcome>;
export type ChatMessageIdReservation = ChatIdempotencyReservation;
export { ChatIdempotencyWaitAbortedError };
/** Join an active keyed turn, replay its durable result, or own a fresh turn. */
export declare function admitChatMessageId(scope: string, clientMessageId: string | null, options?: {
    fingerprint?: string;
    now?: number;
}): ChatMessageIdAdmission;
/** Normalize a raw body value into a usable idempotency key, or `null` when
 *  absent/invalid. Exported for unit testing the dedupe decision in isolation. */
export declare function normalizeClientMessageId(value: unknown): string | null;
/** Release an active reservation held by the requesting turn. */
export declare function releaseChatMessageId(scope: string, clientMessageId: string | null, reservation: ChatMessageIdReservation | null): void;
/**
 * Original arrival timestamp recorded for a `(scope, clientMessageId)` pair,
 * or `null` when the pair is unknown (never seen, expired and swept, or
 * released). A duplicate sighting never refreshes it, so diagnostics and
 * focused cache tests can distinguish the first request from later retries.
 */
export declare function getChatMessageIdFirstSeenAt(scope: string, clientMessageId: string | null): number | null;
/**
 * Bind the durable terminal result to the exact client idempotency key.
 *
 * A room-level "latest assistant memory" lookup cannot identify which of two
 * concurrent turns produced a reply. The first request records its result only
 * after that result is durable; a retry can then replay this exact outcome
 * without starting another model turn or borrowing a neighboring turn.
 */
/**
 * A provider wait counts from the failed attempt, so an idempotent replay must
 * not repeat it. Replays keep the typed failure without `rateLimit`.
 */
export declare function withoutLiveRateLimit(outcome: ChatMessageIdOutcome): ChatMessageIdOutcome;
export declare function setChatMessageIdOutcome(scope: string, clientMessageId: string | null, outcome: ChatMessageIdOutcome, reservation: ChatMessageIdReservation | null): void;
/** Return the durable outcome bound to an exact idempotency key, if settled. */
export declare function getChatMessageIdOutcome(scope: string, clientMessageId: string | null): ChatMessageIdOutcome | null;
/** Test-only: clear the HTTP chat idempotency cache between cases. */
export declare function __resetChatDedupeForTests(): void;
/** Test-only: expose the configured dedupe window without freezing env policy
 *  into the unit fixtures. */
export declare function __getChatDedupeTtlMsForTests(): number;
export declare function compareCreatedAtAscending(left: {
    createdAt?: number;
    id?: string;
}, right: {
    createdAt?: number;
    id?: string;
}): number;
/**
 * "Connect another account" request an assistant turn can carry, emitted by the
 * CONNECT_ACCOUNT action when the user asks to add/log into an additional
 * provider account. Threaded to the client the same way `failureKind` is (a
 * structured field on the turn that round-trips), so the renderer can offer an
 * inline entry point into the existing `AddAccountDialog` flow.
 */
export interface AccountConnectRequest {
    providers: LinkedAccountProviderId[];
    reason?: string;
}
export interface ChatGenerationResult {
    /** Already-delivered progress, retained for display; not final answer text. */
    planningAcknowledgment?: string;
    /** Server-owned execution status, independent of recovered reply delivery. */
    outcome?: TurnOutcome;
    text: string;
    agentName: string;
    /** Machine-only final text that must not render as assistant prose. */
    transcriptVisibility?: "internal";
    /** The agent's internal reasoning for this turn, when the model emitted one. */
    thought?: string;
    noResponseReason?: "ignored";
    failureKind?: ChatFailureKind;
    terminalFailure?: ChatTerminalFailure;
    /** Structured "connect another account" request carried from the CONNECT_ACCOUNT action. */
    accountConnect?: AccountConnectRequest;
    localInference?: LocalInferenceChatMetadata;
    usedActionCallbacks?: boolean;
    actionCallbackHistory?: string[];
    actionResults?: ChatActionResultSummary[];
    /** Server-only complete evidence; never serialize this into a chat DTO. */
    replyRecovery?: MessageReplyRecoveryContext & {
        actionResults: ActionResult[];
    };
    responseContent?: Content | null;
    responseMessages?: Memory[];
    /** Exact response IDs durably committed by the message service before return. */
    persistedResponseMessageIds?: string[];
    usage?: {
        promptTokens: number;
        completionTokens: number;
        totalTokens: number;
        cacheReadInputTokens?: number;
        cacheCreationInputTokens?: number;
        cachedInputTokens?: number;
        model?: string;
        provider?: string;
        isEstimated: boolean;
        llmCalls: number;
    };
}
export interface ChatActionResultSummary {
    /** Validated restart-safe locator metadata; never arbitrary tool payload. */
    data?: {
        actionName: string;
        readView: ReadView;
        control?: Record<string, unknown>;
    };
    effectReceipts?: readonly EffectReceipt[];
    actionName?: string;
    success: boolean;
    text?: string;
    error?: string;
    values?: Record<string, unknown>;
}
/**
 * Where a streamed text emission originated. `"model"` text is (or extends)
 * the turn's final reply; `"action_callback"` text is an in-flight action
 * status delivery that the turn's final reply may replace entirely. Voice
 * clients must not synthesize `"action_callback"` text until the terminal
 * frame confirms it — speech, unlike a chat bubble, cannot be retracted
 * (the "double-speak" defect: ack spoken, then the reply spoken again).
 */
export type ChatStreamTextOrigin = "model" | "action_callback";
export interface ChatGenerateOptions {
    /** Internal host timer begun before room admission; never read from a request body. */
    inferenceTimer?: InferenceTurnTimer;
    onChunk?: (chunk: string, origin?: ChatStreamTextOrigin) => void;
    onSnapshot?: (text: string, origin?: ChatStreamTextOrigin) => void;
    /**
     * Called once the authoritative generation result is settled, before the
     * room's post-delivery bookkeeping is drained. Realtime transports can use
     * this boundary to start delivery without weakening serialized room
     * ownership or skipping trajectory/action-receipt work.
     */
    onReplyReady?: (result: ChatGenerationResult) => void | Promise<void>;
    /**
     * In-flight phase changes for the rich status indicator. Emitted additively
     * alongside `onChunk`/`onSnapshot` — `thinking` before the first visible
     * token, then `streaming` (LLM tokens) or `running_action` (an action handler
     * is producing the reply, carrying `actionName`). Never required for the reply
     * itself; a caller that omits it loses only the status surface.
     */
    onStatus?: (status: ChatTurnStatus) => void;
    /**
     * Inline tool/action-call steps for the chat thread's tool rows (#13535).
     * Forked from the runtime's native planner/tool stream — the same channel the
     * reply streams on — so a `call` is followed by its correlated `result`/
     * `error`. Additive; a caller that omits it loses only the inline tool surface.
     */
    onToolEvent?: (event: ChatToolCallEvent) => void;
    abortSignal?: AbortSignal;
    /** Existing runtime-validated ownership for a host's wider durable turn. */
    roomHandlerLease?: RoomHandlerLease;
    resolveNoResponseText?: () => string;
    preferredLanguage?: string;
    /** Validated upstream correlation id for this complete inference turn. */
    traceId?: string;
}
export declare function recoverSettledMutatingActionTurn(runtime: AgentRuntime, settledResults: readonly ActionResult[], interruption: {
    error: unknown;
    signal: AbortSignal;
}): {
    text: string;
    actionResults: ActionResult[];
    actionNames: string[];
    outcome: TurnOutcome;
    replyFailure?: ActionReplyFailure;
} | null;
/**
 * Project the runtime's internal planner/tool stream payload — forwarded through
 * `onStreamChunk` as a JSON string, then filtered out of the visible reply by
 * {@link isInternalStructuredStreamText} — onto the two chat surfaces it should
 * drive: the working-indicator phase (`running_tool` / `evaluating`) and, for
 * tool steps, an inline tool-call row. Returns null for payloads with no
 * chat-visible signal (e.g. `context_event`) so the caller drops them (#13535).
 */
export declare function chatEventsFromStructuredStreamPayload(payload: unknown): {
    status?: ChatTurnStatus;
    toolEvent?: ChatToolCallEvent;
} | null;
/**
 * Validate an untrusted `accountConnect` payload from a response Content into a
 * strict {@link AccountConnectRequest}. Returns `undefined` when the value is
 * absent, malformed, or carries no valid provider id — a broken/empty request
 * must not surface an empty block on the client.
 */
export declare function normalizeAccountConnectRequest(value: unknown): AccountConnectRequest | undefined;
export declare function markSyntheticChatFailureContent<T extends Content>(content: T): T;
/**
 * Returns the action results recorded for `messageId`, or `[]` when the caller
 * asked about no message or the runtime exposes no reader. A reader that throws
 * rejects with `ElizaError` (`ACTION_RESULTS_READ_FAILED`) rather than
 * resolving `[]`: downstream `[]` means "no action succeeded", so a failed read
 * would be reported as unexecuted model actions instead of a read failure.
 */
export declare function readRuntimeActionResults(runtime: AgentRuntime, messageId: UUID | undefined): unknown[];
export declare function summarizeRuntimeActionResults(runtime: AgentRuntime, messageId: UUID | undefined, turnActionResults?: unknown[]): ChatActionResultSummary[];
export declare function resolveNoResponseFallback(logBuffer: LogEntry[], _runtime?: AgentRuntime | null, _lang?: string): string;
export declare function isChatGenerationTimeoutError(err: unknown): boolean;
/**
 * Run a generation under a wall-clock deadline, cancelling it on expiry.
 *
 * Racing a bare promise against a timer would leave the model call running
 * after the caller has already been told it failed — it would keep holding a
 * provider slot and keep emitting `onChunk` into a turn nobody is reading. So
 * the deadline drives a real `AbortSignal`, chained to any caller-supplied
 * signal, and `run` receives the options with that signal substituted in.
 */
export declare function runWithGenerationTimeout<T>(timeoutMs: number, createError: () => Error, opts: ChatGenerateOptions | undefined, run: (opts: ChatGenerateOptions | undefined) => Promise<T>): Promise<T>;
export declare function getChatFailureReply(err: unknown, logBuffer: LogEntry[]): string;
export declare function classifyChatFailure(err: unknown, logBuffer: LogEntry[]): ChatFailureKind;
export declare function detectLocalInferenceCommandIntent(text: string, options?: {
    localInferenceContext?: boolean;
}): LocalInferenceCommandIntent | null;
export declare function isLocalInferenceError(err: unknown): boolean;
/**
 * Final text projection for chat-shaped API consumers (the trusted-local
 * `POST /api/agents/:id/message` mirror). These callers render plain chat —
 * the dashboard does NOT consume this endpoint (its chat uses the
 * session/chat routes and typed interaction payloads) — so interaction
 * grammar degrades to its text fallbacks and dashboard-only card markers
 * are stripped. Live leak this closes (matrix F2): [CONFIG:owner_finances]
 * and [FOLLOWUPS] blocks delivered verbatim in api replies
 * (tj-a5802a25580840, tj-a76213d5ae7164).
 */
export declare function renderChatSurfaceText(text: string): string;
export declare function normalizeChatResponseText(text: string, logBuffer: LogEntry[], runtime?: AgentRuntime | null): string;
export declare function isIntentionalNoResponseResult(result: {
    didRespond?: boolean;
    responseContent?: Content | null;
} | null | undefined, candidateText: string): boolean;
export { type ChatTokenStreamWriter, type ChatTokenWriteOptions, createChatTokenStreamWriter, initSse, writeChatStatusSse, writeChatToolSse, writeSse, writeSseData, writeSseJson, } from "./chat-stream-writer.js";
export declare function persistConversationMemory(runtime: AgentRuntime, memory: ReturnType<typeof createMessageMemory>, roomHandlerLease?: RoomHandlerLease, assertCurrent?: () => void): Promise<ReturnType<typeof createMessageMemory>>;
export declare function persistExactConversationMemory(runtime: AgentRuntime, memory: ReturnType<typeof createMessageMemory>, roomHandlerLease?: RoomHandlerLease, assertCurrent?: () => void): Promise<ReturnType<typeof createMessageMemory>>;
export declare function persistExactConversationMemoryResult(runtime: AgentRuntime, memory: ReturnType<typeof createMessageMemory>, roomHandlerLease?: RoomHandlerLease, assertCurrent?: () => void): Promise<{
    created: boolean;
    memory: ReturnType<typeof createMessageMemory>;
}>;
/**
 * Reports whether the recent 12-message read contains a visible assistant
 * reply at or after `sinceMs - 2000`. A failed storage read rejects with `ElizaError`
 * (`ASSISTANT_MEMORY_READ_FAILED`) instead of resolving `false`: `false`
 * means no matching reply in that read, and callers must not catch the
 * rejection and substitute `false`.
 */
export declare function hasRecentVisibleAssistantMemorySince(runtime: AgentRuntime, roomId: UUID, sinceMs: number): Promise<boolean>;
/**
 * Returns the newest visible assistant reply text at or after
 * `sinceMs - slackMs` in the recent 12-message read, or `null` when that
 * successful read contains no matching reply. A storage read
 * failure rejects with `ElizaError` (`ASSISTANT_MEMORY_READ_FAILED`) rather
 * than degrading to `null`, which would read as "no prior reply".
 */
export declare function getRecentVisibleAssistantMemoryTextSince(runtime: AgentRuntime, roomId: UUID, sinceMs: number, slackMs?: number): Promise<string | null>;
/**
 * Orders candidate assistant turns newest-first, treating a missing or
 * non-finite `createdAt` as epoch zero so a poisoned timestamp can never make
 * the comparator inconsistent, and breaking ties on ascending id so the
 * selected turn is deterministic rather than dependent on storage order.
 */
export declare function compareAssistantTurnRecencyDescending(a: {
    createdAt?: number;
    id?: string;
}, b: {
    createdAt?: number;
    id?: string;
}): number;
/**
 * Reads the most recent visible (non-internal) assistant turn at or after
 * `sinceMs - slackMs` among the recent 12 messages, newest first, as
 * `{ id, text }`. Resolves `null` when that successful read has no match; a failed storage read rejects
 * with `ElizaError` (`ASSISTANT_MEMORY_READ_FAILED`) wrapping the cause.
 * Fail closed is the contract: a fabricated "no prior reply" would regenerate
 * and re-send a previous turn's answer on rapid-fire retries. Reachable by
 * external consumers through `@elizaos/agent/api/chat-routes`.
 */
export declare function getRecentVisibleAssistantMemorySince(runtime: AgentRuntime, roomId: UUID, sinceMs: number, slackMs?: number): Promise<{
    id: UUID;
    text: string;
} | null>;
export declare function persistAssistantConversationMemory(runtime: AgentRuntime, roomId: UUID, content: string | Content, channelType: ChannelType, dedupeSinceMs?: number, memoryId?: UUID, roomHandlerLease?: RoomHandlerLease, assertCurrent?: () => void): Promise<Memory | null>;
/**
 * Persist visible callback-delivered replies that the message service did not
 * commit. Exact source-turn IDs distinguish equal replies to different turns;
 * retries reuse the same durable row and reject changed content.
 */
export declare function persistUnpersistedChatReply(runtime: AgentRuntime, message: Memory, result: ChatGenerationResult, _turnStartedAt: number): Promise<Memory | null>;
/**
 * Persist the terminal receipt for an aborted (Stop/disconnect) turn before
 * the route releases it. Unlike `persistAssistantConversationMemory` this
 * MUST persist even when no token streamed — a zero-token Stop still owns a
 * durable `interrupted` assistant row, otherwise reload recovery finds a user
 * turn with no terminal receipt and the transport is free to regenerate
 * (#17216). The row carries `content.interrupted: true`, which the GET
 * /messages DTO round-trips so the renderer shows the interrupted state
 * instead of a healthy-looking reply.
 */
export declare function persistInterruptedAssistantReceipt(runtime: AgentRuntime, roomId: UUID, partialText: string, channelType: ChannelType, inReplyTo: UUID | undefined, memoryId: UUID, roomHandlerLease?: RoomHandlerLease, assertCurrent?: () => void): Promise<Memory>;
export declare function readChatRequestPayload(req: http.IncomingMessage, res: http.ServerResponse, helpers: {
    runtime?: AgentRuntime | null;
    readJsonBody: <T extends object>(req: http.IncomingMessage, res: http.ServerResponse, options?: ReadJsonBodyOptions) => Promise<T | null>;
    error: (res: http.ServerResponse, message: string, status?: number) => void;
}, 
/** Body size limit. Image-capable endpoints pass CHAT_MAX_BODY_BYTES (20 MB);
 *  legacy/cloud-proxy endpoints that don't process images pass MAX_BODY_BYTES (1 MB). */
maxBytes?: number): Promise<{
    prompt: string;
    channelType: ChannelType;
    images?: ChatImageAttachment[];
    preferredLanguage?: string;
    source?: string;
    metadata?: Record<string, unknown>;
    /** Client-supplied idempotency key (see `admitChatMessageId`); absent
     *  when the client did not stamp one. */
    clientMessageId?: string;
} | null>;
export declare function generateChatResponse(runtime: AgentRuntime, message: ReturnType<typeof createMessageMemory>, agentName: string, opts?: ChatGenerateOptions): Promise<ChatGenerationResult>;
interface ConversationTitleGenerationOptions {
    signal?: AbortSignal;
}
export declare function generateConversationTitle(runtime: AgentRuntime, userMessage: string, agentName: string, options?: ConversationTitleGenerationOptions): Promise<string | null>;
export interface ChatRouteState {
    runtime: AgentRuntime | null;
    config: ElizaConfig;
    agentName: string;
    logBuffer: LogEntry[];
    chatRoomId: UUID | null;
    chatUserId: UUID | null;
    chatConnectionReady: {
        userId: UUID;
        roomId: UUID;
        worldId: UUID;
    } | null;
    chatConnectionPromise: Promise<void> | null;
    adminEntityId: UUID | null;
    /** Wallet trade permission mode for wallet-mode guidance replies. */
    tradePermissionMode?: string;
}
export interface ChatRouteContext extends RouteRequestContext {
    state: ChatRouteState;
    callerAuthorization?: AgentHttpRequestAuthorization;
}
export declare function resolveChatAdminEntityId(state: ChatRouteState): UUID;
/**
 * Exported for the machine-session role-grant regression suite; runtime callers
 * are the chat POST paths in this module.
 */
export declare function ensureCompatChatConnection(state: ChatRouteState, runtime: AgentRuntime, 
/** agentIdentityName(runtime.character): stays the same after a rename. */
identityName: string, channelIdPrefix: string, roomKey: string, principal: TrustedApiPrincipal): Promise<{
    userId: UUID;
    roomId: UUID;
    worldId: UUID;
}>;
export declare function resolveTrustedApiPrincipal(req: http.IncomingMessage, authorization: AgentHttpRequestAuthorization | undefined): TrustedApiPrincipal;
export declare function handleChatRoutes(ctx: ChatRouteContext): Promise<boolean>;
