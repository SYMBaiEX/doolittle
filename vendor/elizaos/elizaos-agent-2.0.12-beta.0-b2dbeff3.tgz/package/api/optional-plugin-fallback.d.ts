/**
 * Provides an observable fallback for optional-plugin route imports. Packages
 * deliberately absent from mobile builds fall through to the normal 404,
 * while broken transitive imports and missing handler exports warn instead of
 * being misclassified as benign package absence (#12089, #12661).
 */
export { isModuleNotFoundError } from "../utils/module-resolution-error.js";
/**
 * Build the no-op fallback API returned when an optional plugin is unavailable.
 *
 * Handlers still resolve to `() => false` so route-dispatch
 * (`if (await handleX(...)) return;`) falls through to the normal 404 instead of
 * 500ing — but the FIRST access of each distinct handler name emits an
 * observable warning tagged as drift when `observeAccess` is true. That way a
 * present-but-renamed export (mode 2) is surfaced, while the benign
 * module-absent case (mode 1, `observeAccess=false`) stays silent.
 */
export declare function createOptionalPluginFallback<T>(key: string, observeAccess: boolean): T;
/**
 * Classify an optional-plugin import rejection and return the appropriate no-op
 * fallback. Module-not-found → quiet fallthrough (expected bundle exclusion).
 * Any OTHER error → the plugin should have loaded but threw: warn (observable
 * drift) and hand back a fallback whose handler access is also observable.
 */
export declare function resolveOptionalPluginImportFailure<T>(key: string, err: unknown, specifier?: string): T;
