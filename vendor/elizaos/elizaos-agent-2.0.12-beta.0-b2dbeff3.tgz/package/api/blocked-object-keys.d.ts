/**
 * Bounds the blocked-object-key walk used to sanitize OpenAI-compat and
 * connector request JSON. JSON.parse accepts a 20k-deep nest that the previous
 * recursive walk RangeError'd, 500ing `/v1/chat/completions`. Depth, node, and
 * cycle limits are all load-bearing — descriptor-only reads so a getter cannot
 * hang the agent, and sparse holes still consume the node budget.
 */
export declare function isBlockedObjectKey(key: string): boolean;
/** Honest request JSON is a handful of objects deep. */
export declare const MAX_BLOCKED_OBJECT_DEPTH = 32;
/**
 * Node ceiling across the whole walk, including sparse array holes. The chat
 * routes accept large histories and tool schemas, so this must remain well
 * above an ordinary token-sized request while still bounding synthetic sparse
 * arrays passed by in-process callers.
 */
export declare const MAX_BLOCKED_OBJECT_NODES = 100000;
export declare const BLOCKED_OBJECT_GRAPH_UNBOUNDED = "BLOCKED_OBJECT_GRAPH_UNBOUNDED";
/**
 * What the clone does with one own enumerable string key. Blocked keys are
 * always dropped regardless of the policy; the policy only decides the fate of
 * the keys this walk would otherwise have kept.
 */
export type BoundedCloneKeyAction = "keep" | "drop" | "redact";
export interface BoundedCloneOptions {
    /** Defaults to keeping every non-blocked key, i.e. the historical behaviour. */
    keyAction?: (key: string) => BoundedCloneKeyAction;
    /** Substituted for a key whose action is `"redact"`. */
    redactedValue?: unknown;
}
export declare function hasBlockedObjectKeyDeep(value: unknown): boolean;
export declare function cloneWithoutBlockedObjectKeys<T>(value: T, options?: BoundedCloneOptions): T;
