import type http from "node:http";
export declare function resolveUiDir(): string | null;
export declare function sendStaticResponse(req: http.IncomingMessage, res: http.ServerResponse, status: number, headers: Record<string, string | number>, body?: Buffer): void;
/**
 * Serve built dashboard assets from packages/app/web-dist with SPA fallback.
 * Returns true when the request is handled.
 */
export declare function injectApiBaseIntoHtml(html: Buffer, externalBase?: string | null, opts?: {
    apiToken?: string | null;
    webPushVapidPublicKey?: string | null;
}): Buffer;
/**
 * Decide whether to embed the API token into the served dashboard HTML, and
 * return the token to inject (or `null`).
 *
 * The token is the full-capability API token, and the dashboard HTML is served
 * pre-auth, so embedding it is a capability grant. Managed containers never
 * embed it: their browser session must arrive through the scoped pairing
 * handoff. A self-hosted operator can explicitly opt in with
 * `ELIZA_FORCE_INJECT_TOKEN` when an independent auth gate protects the HTML.
 * This MUST NOT be enabled on a directly exposed agent port; we warn once so
 * the risk is observable.
 */
export declare function resolveInjectedDashboardToken(): string | null;
/** Compose the exact SPA document returned by the static dashboard boundary. */
export declare function buildServedDashboardHtml(html: Buffer): Buffer;
export declare function serveStaticUi(req: http.IncomingMessage, res: http.ServerResponse, pathname: string): boolean;
export declare function isAuthProtectedRoute(pathname: string): boolean;
