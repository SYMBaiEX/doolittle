/** Persists one-use runtime mutation proposals with cross-process atomic consumption. */
export interface RuntimeManagementProposal {
    proposalId: string;
    nonce: string;
    clientId: string;
    requestKey: string;
    expiresAt: number;
}
export interface RuntimeManagementProposalStore {
    create(proposal: RuntimeManagementProposal): Promise<void>;
    consume(proposal: RuntimeManagementProposal): Promise<boolean>;
}
export declare class FileRuntimeManagementProposalStore implements RuntimeManagementProposalStore {
    private readonly directory;
    private cleanupDirectory;
    private cleanupTail;
    constructor(stateDirectory?: string);
    private proposalPath;
    private prepareDirectory;
    create(proposal: RuntimeManagementProposal): Promise<void>;
    private readPath;
    private read;
    private cleanupProposalFile;
    private cleanupStaleFilesSerialized;
    private cleanupStaleFiles;
    consume(proposal: RuntimeManagementProposal): Promise<boolean>;
}
