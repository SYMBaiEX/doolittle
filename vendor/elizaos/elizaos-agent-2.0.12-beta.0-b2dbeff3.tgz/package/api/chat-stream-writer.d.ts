/**
 * Frames host chat responses as server-sent events over Node HTTP.
 * Delta chunks, recovery snapshots and provisional status share one protocol.
 * Turn admission and durable delivery remain with routes.
 */
import type http from "node:http";
import type { ChatToolCallEvent, ChatTurnStatus } from "@elizaos/contracts";
export declare function initSse(res: http.ServerResponse): void;
export declare function writeSse(res: http.ServerResponse, payload: Record<string, unknown>): void;
/**
 * Per-write options for the token wire. `provisional: true` marks the carried
 * text as an in-flight action-callback delivery the turn's final reply may
 * replace — voice clients must not synthesize it until the terminal `done`
 * frame (or a later non-provisional frame) confirms it, because speech cannot
 * be retracted the way a re-rendered chat bubble can (the "double-speak"
 * defect). Text bubbles may render it exactly as before.
 */
export interface ChatTokenWriteOptions {
    provisional?: boolean;
}
export interface ChatTokenStreamWriter {
    /** An incremental streamed chunk. `fullText` is the accumulated text so far. */
    writeChunk(res: http.ServerResponse, chunk: string, fullText: string, options?: ChatTokenWriteOptions): void;
    /** An authoritative full-text replace (structured-field rewrite, single-frame
     *  reply). The client treats the carried `fullText` as the new buffer. */
    writeSnapshot(res: http.ServerResponse, fullText: string, options?: ChatTokenWriteOptions): void;
}
/** Emits deltas with geometrically spaced recovery snapshots. */
export declare function createChatTokenStreamWriter(): ChatTokenStreamWriter;
export declare function writeChatStatusSse(res: http.ServerResponse, status: ChatTurnStatus): void;
export declare function writeChatToolSse(res: http.ServerResponse, event: ChatToolCallEvent): void;
export declare function writeSseData(res: http.ServerResponse, data: string, event?: string): void;
export declare function writeSseJson(res: http.ServerResponse, payload: unknown, event?: string): void;
