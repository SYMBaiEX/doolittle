/**
 * Notification routes.
 *
 * HTTP surface over the runtime `NotificationService` so clients can hydrate
 * the notification center on load (WS only carries live events), mark items
 * read, and — for triggers that don't run inside the agent process (external
 * automations, tests) — create a notification.
 *
 * Routes:
 *
 *   GET    /api/notifications?nativeTransport=true&afterSequence=&throughSequence=&nativeEpoch=&limit=
 *     Native keyset pages, oldest-first, with fixed sequence fence and explicit completion.
 *   GET    /api/notifications?unreadOnly=&category=&limit=
 *     List notifications newest-first. Returns `{ notifications, unreadCount }`.
 *
 *   POST   /api/notifications
 *     Create a notification. Body: { title, body?, category?, priority?,
 *     deepLink?, groupKey?, source?, data? }. Returns `{ notification }`.
 *
 *   POST   /api/notifications/read-all
 *     Mark every notification read. Returns `{ changed }`.
 *
 *   POST   /api/notifications/dev/seed
 *     Non-production only (404 in production): seed a fixed demo spread across
 *     every priority and most categories so the dashboard notification center
 *     can be exercised without waiting for real activity. Returns
 *     `{ count, notifications }`.
 *
 *   POST   /api/notifications/:id/read
 *     Mark one notification read. Returns `{ ok }`.
 *
 *   DELETE /api/notifications/:id
 *     Remove one notification. Returns `{ ok }`.
 *
 *   DELETE /api/notifications
 *     Clear the inbox. Returns `{ ok }`.
 */
import type http from "node:http";
import { type NotificationInput, type NotificationServiceLifecycleRuntime } from "@elizaos/core";
import type { RouteHelpers } from "@elizaos/host/protocol";
export interface NotificationRouteState {
    runtime: NotificationServiceLifecycleRuntime | null;
}
/**
 * The dev/test seed spread: every priority tier, a breadth of categories, a
 * long body (exercises the widget's two-line clamp), safe deep links, and a
 * same-groupKey pair (the second collapses onto the first, proving supersede
 * behavior) — so one click paints a realistic, scrollable inbox.
 */
export declare const DEV_SEED_NOTIFICATIONS: readonly NotificationInput[];
export declare function handleNotificationRoute(req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: NotificationRouteState, helpers: RouteHelpers): Promise<boolean>;
