/**
 * Plugin configuration validation.
 *
 * Validates plugin configuration by checking all required parameters
 * from the plugin's agentConfig.pluginParameters definition, plus
 * provider-specific API key format checks.
 *
 * Also provides runtime context validation to detect null, undefined,
 * empty, and non-serializable fields in context objects.
 */
export interface PluginValidationResult {
    /** Whether the plugin configuration is valid (no errors). */
    valid: boolean;
    /** Hard errors that prevent the plugin from working. */
    errors: Array<{
        field: string;
        message: string;
    }>;
    /** Soft warnings that may indicate misconfiguration. */
    warnings: Array<{
        field: string;
        message: string;
    }>;
}
/** Result of runtime context validation. */
export interface RuntimeContextValidationResult {
    /** Whether the context is valid (no null, undefined, or empty fields). */
    valid: boolean;
    /** Whether the context is fully JSON-serializable. */
    serializable: boolean;
    /** Field paths that are null. */
    nullFields: string[];
    /** Field paths that are undefined. */
    undefinedFields: string[];
    /** Field paths that are empty strings. */
    emptyFields: string[];
    /** Field paths that contain non-serializable values (functions, symbols, etc.). */
    nonSerializableFields: string[];
}
/** Parameter definition from agentConfig.pluginParameters in package.json. */
export interface PluginParamInfo {
    key: string;
    required: boolean;
    sensitive: boolean;
    type: string;
    description: string;
    default?: string;
}
/**
 * Validate a plugin's configuration.
 *
 * Checks all required parameters (from the plugin's package.json metadata)
 * and applies format-specific warnings for known API key patterns.
 *
 * @param pluginId - The plugin identifier (e.g. "anthropic", "discord")
 * @param category - Plugin category
 * @param envKey - Primary environment variable key (legacy, used as fallback)
 * @param configKeys - All known config key names for this plugin
 * @param providedConfig - Config values being set (for PUT validation)
 * @param paramDefs - Full parameter definitions with required/sensitive metadata
 */
export declare function validatePluginConfig(_pluginId: string, _category: string, envKey: string | null, configKeys: string[], providedConfig?: Record<string, string>, paramDefs?: PluginParamInfo[]): PluginValidationResult;
/**
 * Validate a runtime context object for null, undefined, empty, and
 * non-serializable fields.
 *
 * Used after provider + plugin resolution to detect and surface invalid
 * or malformed context early — before it reaches the agent runtime.
 *
 * @param context - The context object to validate.
 * @param maxDepth - Maximum nesting depth to inspect (default: 5).
 */
export declare function validateRuntimeContext(context: Record<string, unknown>, maxDepth?: number): RuntimeContextValidationResult;
/**
 * Log the full resolved plugin/provider context for debugging.
 *
 * Prints a structured summary of all loaded plugins, providers,
 * and any validation issues detected in the context.
 *
 * @param plugins - Array of resolved plugin names.
 * @param providers - Array of resolved provider names.
 * @param context - The runtime context object to inspect.
 * @param log - Structured debug logger supplied by the host.
 */
export declare function debugLogResolvedContext(plugins: string[], providers: string[], context: Record<string, unknown>, log: (msg: string) => void): void;
