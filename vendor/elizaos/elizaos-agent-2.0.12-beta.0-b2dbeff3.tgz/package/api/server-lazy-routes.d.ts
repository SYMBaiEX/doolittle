/**
 * Lazy route-group dispatch wrappers for the agent HTTP surface. Each exported
 * `handle*Routes` shim first checks the request method/pathname against a cheap
 * static guard and only on a match dynamically `import()`s the real route
 * module, keeping the ~38 route modules (and the plugins they pull in) out of
 * the static boot graph so each loads on first hit rather than every boot. Also
 * uses the shared plugin-route matcher for lazy-load and public-route gates.
 */
import type { AgentRuntime } from "@elizaos/core";
export declare function isPublicRuntimePluginRoute(options: {
    runtime: AgentRuntime | null | undefined;
    method: string;
    pathname: string;
}): boolean;
export declare const handleAccountsRoutes: (ctx: import("./accounts-routes.js").AccountsRouteContext) => Promise<boolean>;
export declare const handleAgentAdminRoutes: (ctx: import("./agent-admin-routes.js").AgentAdminRouteContext) => Promise<boolean>;
export declare const handleAgentLifecycleRoutes: (ctx: import("./agent-lifecycle-routes.js").AgentLifecycleRouteContext) => Promise<boolean>;
export declare const handleAgentStatusRoutes: (ctx: import("./agent-status-routes.js").AgentStatusRouteContext) => Promise<boolean>;
export declare const handleAgentTransferRoutes: (ctx: import("./agent-transfer-routes.js").AgentTransferRouteContext) => Promise<boolean>;
export declare const handleAppPackageRoutes: (ctx: import("@elizaos/host").AppPackageRouteDispatchContext) => Promise<boolean>;
export declare const handleAuthRoutes: (ctx: import("./auth-routes.js").AuthRouteContext) => Promise<boolean>;
export declare const handleAvatarRoutes: (ctx: import("./avatar-routes.js").AvatarRouteContext) => Promise<boolean>;
export declare const handleInteractionsRoutes: (ctx: import("./interactions-routes.js").InteractionsRouteContext) => Promise<boolean>;
export declare const handleBackgroundTasksRoute: (args_0: import("./background-tasks-routes.js").BackgroundTasksRouteContext) => Promise<boolean>;
export declare const handleBugReportRoutes: (ctx: import("@elizaos/host").RouteRequestContext) => Promise<boolean>;
export declare const handleCharacterRoutes: (ctx: import("./character-routes.js").CharacterRouteContext) => Promise<boolean>;
export declare const handleConfigRoutes: (ctx: import("./config-routes.js").ConfigRouteContext) => Promise<boolean>;
export declare const handleConnectorRoutes: (ctx: import("./connector-routes.js").ConnectorRouteContext) => Promise<boolean>;
export declare const handleDiagnosticsRoutes: (ctx: import("./diagnostics-routes.js").DiagnosticsRouteContext) => Promise<boolean>;
export declare const handleFirstRunRoutes: (ctx: import("./first-run-routes.js").FirstRunRouteContext) => Promise<boolean>;
export declare const handleHealthRoutes: (ctx: import("./health-routes.js").HealthRouteContext) => Promise<boolean>;
export declare const handleMemoryRoutes: (ctx: import("./memory-routes.js").MemoryRouteContext) => Promise<boolean>;
export declare const handleMiscRoutes: (ctx: import("./misc-routes.js").MiscRouteContext) => Promise<boolean>;
export declare const handleTrajectoryManagementRoutes: (options: {
    req: import("node:http").IncomingMessage;
    res: import("node:http").ServerResponse;
    method: string;
    pathname: string;
    runtime: import("@elizaos/core").IAgentRuntime | null | undefined;
}) => Promise<boolean>;
type HostSettingsRoutesModule = typeof import("./host-settings-routes.js");
export declare function handleHostSettingsRoutes(...args: Parameters<HostSettingsRoutesModule["handleHostSettingsRoutes"]>): ReturnType<HostSettingsRoutesModule["handleHostSettingsRoutes"]>;
export declare const handleModelsRoutes: (ctx: import("./models-routes.js").ModelsRouteContext) => Promise<boolean>;
export declare const handleModelConfigRoutes: (ctx: import("./model-config-routes.js").ModelConfigRouteContext) => Promise<boolean>;
type LifeOpsInboxFallbackModule = typeof import("./lifeops-inbox-fallback-routes.js");
export declare function tryHandleLifeOpsInboxFallbackLazy(...args: Parameters<LifeOpsInboxFallbackModule["tryHandleLifeOpsInboxFallback"]>): Promise<boolean>;
export declare const handlePermissionRoutes: (ctx: import("./permissions-routes.js").PermissionRouteContext) => Promise<boolean>;
export declare const handleProjectRoutes: (ctx: import("@elizaos/host").RouteRequestContext, deps?: {
    readRegistry?: () => import("./project-routes.js").ProjectListDTO;
    activate?: (id: string) => import("./project-routes.js").ProjectSummaryDTO | null;
} | undefined) => Promise<boolean>;
export declare const handlePermissionsExtraRoutes: (ctx: import("./permissions-routes-extra.js").PermissionsExtraRouteContext) => Promise<boolean>;
export declare const handleProviderSwitchRoutes: (ctx: import("./provider-switch-routes.js").ProviderSwitchRouteContext) => Promise<boolean>;
export declare const handleRegistryRoutes: (ctx: import("./registry-routes.js").RegistryRouteContext) => Promise<boolean>;
export declare const handleRelationshipsRoutes: (ctx: import("./relationships-routes.js").RelationshipsRouteContext) => Promise<boolean>;
export declare const handleRemoteCapabilityRoutes: (ctx: import("./remote-capability-routes.js").RemoteCapabilityRouteContext) => Promise<boolean>;
export declare const handleInboxAndCloudRelayRouteGroup: RouteDispatchModule["handleInboxAndCloudRelayRouteGroup"];
export declare const handleCloudAndCoreRouteGroup: RouteDispatchModule["handleCloudAndCoreRouteGroup"];
export declare const handleSandboxRouteGroup: RouteDispatchModule["handleSandboxRouteGroup"];
export declare const handleConversationRouteGroup: RouteDispatchModule["handleConversationRouteGroup"];
type RouteDispatchModule = typeof import("./server-route-dispatch.js");
export declare function handleDatabaseRouteGroup(...args: Parameters<RouteDispatchModule["handleDatabaseRouteGroup"]>): ReturnType<RouteDispatchModule["handleDatabaseRouteGroup"]>;
export declare function handleLifeOpsRuntimePluginRoute(...args: Parameters<RouteDispatchModule["handleLifeOpsRuntimePluginRoute"]>): ReturnType<RouteDispatchModule["handleLifeOpsRuntimePluginRoute"]>;
export declare const handleSubscriptionRoutes: (ctx: import("./subscription-routes.js").SubscriptionRouteContext) => Promise<boolean>;
export declare const handleUpdateRoutes: (ctx: import("./update-routes.js").UpdateRouteContext) => Promise<boolean>;
type ViewsRoutesModule = typeof import("./views-routes.js");
export declare function handleViewsRoutes(...args: Parameters<ViewsRoutesModule["handleViewsRoutes"]>): ReturnType<ViewsRoutesModule["handleViewsRoutes"]>;
export declare function registerBuiltinViews(runtime?: import("@elizaos/core").IAgentRuntime | null): Promise<void>;
export declare const handleWorkbenchRoutes: (ctx: import("./workbench-context.js").WorkbenchRouteContext) => Promise<boolean>;
type RuntimePluginRoutesModule = typeof import("./runtime-plugin-routes.js");
export declare function tryHandleRuntimePluginRoute(...args: Parameters<RuntimePluginRoutesModule["tryHandleRuntimePluginRoute"]>): ReturnType<RuntimePluginRoutesModule["tryHandleRuntimePluginRoute"]>;
type HonoMountModule = typeof import("./hono-mount.js");
export declare function tryHandleHonoRuntimeRoute(...args: Parameters<HonoMountModule["tryHandleHonoRuntimeRoute"]>): ReturnType<HonoMountModule["tryHandleHonoRuntimeRoute"]>;
export declare function extractConversationMetadataFromRoom(...args: Parameters<typeof import("./conversation-metadata.js")["extractConversationMetadataFromRoom"]>): Promise<ReturnType<typeof import("./conversation-metadata.js")["extractConversationMetadataFromRoom"]>>;
export declare function createConnectorHealthMonitor(...args: ConstructorParameters<typeof import("./connector-health.js")["ConnectorHealthMonitor"]>): Promise<InstanceType<typeof import("./connector-health.js")["ConnectorHealthMonitor"]>>;
export {};
