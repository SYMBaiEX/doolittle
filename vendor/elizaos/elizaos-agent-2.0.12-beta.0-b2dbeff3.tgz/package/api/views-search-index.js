/**
 * Semantic search index for the view registry.
 *
 * Stores embeddings for each registered view and supports cosine-similarity
 * ranking. Embeddings are computed lazily via `runtime.useModel(TEXT_EMBEDDING)`
 * so startup is never blocked.
 *
 * Usage:
 *   await getViewSearchIndex(runtime).indexView(entry);
 *   const results = await getViewSearchIndex(runtime).search(query, 10);
 */
import { logger, ModelType } from "@elizaos/core";
import { assertRuntimeViewEntry } from "./view-installations.js";
/** Cosine similarity in [−1, 1]; returns 0 for zero-length vectors. */
function cosineSimilarity(a, b) {
    if (a.length === 0 || b.length === 0)
        return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    const len = Math.min(a.length, b.length);
    for (let i = 0; i < len; i++) {
        dot += (a[i] ?? 0) * (b[i] ?? 0);
        normA += (a[i] ?? 0) ** 2;
        normB += (b[i] ?? 0) ** 2;
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
}
/** Build the text to embed for a view. */
export function buildViewEmbeddingText(view) {
    return [
        view.label,
        view.description,
        ...(view.tags ?? []),
        view.capabilities?.map((c) => c.description).join(" ") ?? "",
    ]
        .filter(Boolean)
        .join(" | ");
}
class ViewSearchIndex {
    runtime;
    entries = new Map();
    constructor(runtime) {
        this.runtime = runtime;
    }
    key(viewId, viewType) {
        return `${viewType}:${viewId}`;
    }
    /**
     * Compute and store an embedding for `view`.
     * Returns without indexing when the runtime has no embedding model configured.
     */
    async indexView(view) {
        const runtime = this.runtime;
        const text = buildViewEmbeddingText(view);
        try {
            assertRuntimeViewEntry(runtime, view);
            const result = await runtime.useModel(ModelType.TEXT_EMBEDDING, { text });
            const embedding = Array.isArray(result) ? result : [];
            if (embedding.length === 0) {
                logger.debug({ src: "ViewSearchIndex", viewId: view.id }, "[ViewSearchIndex] Empty embedding returned for view — skipping");
                return;
            }
            assertRuntimeViewEntry(runtime, view);
            this.entries.set(this.key(view.id, view.viewType), {
                viewId: view.id,
                viewType: view.viewType,
                embedding,
                text,
                view,
            });
        }
        catch (err) {
            // error-policy:J4 semantic search explicitly degrades to keyword ranking.
            logger.debug({ src: "ViewSearchIndex", viewId: view.id, err }, "[ViewSearchIndex] Could not embed view — falling back to keyword search");
        }
    }
    /** Remove the index entry for `viewId`. */
    removeView(viewId, viewType) {
        if (viewType) {
            this.entries.delete(this.key(viewId, viewType));
            return;
        }
        for (const [key, entry] of this.entries) {
            if (entry.viewId === viewId)
                this.entries.delete(key);
        }
    }
    /**
     * Rank indexed views by semantic similarity to `query`.
     *
     * @param query   - The user's raw search query.
     * @param runtime - Agent runtime used to embed the query.
     * @param topK    - Maximum number of results to return (default 10).
     * @returns       Array of `{ viewId, score }` sorted descending by score,
     *                where score is cosine similarity in [0, 1].
     *                Returns an empty array when the runtime has no embedding
     *                model, or when `topK` is not a positive safe integer.
     */
    async search(query, topK = 10) {
        const runtime = this.runtime;
        if (this.entries.size === 0)
            return [];
        if (!Number.isSafeInteger(topK) || topK <= 0)
            return [];
        let queryEmbedding;
        try {
            const result = await runtime.useModel(ModelType.TEXT_EMBEDDING, {
                text: query,
            });
            queryEmbedding = Array.isArray(result) ? result : [];
        }
        catch (err) {
            // error-policy:J4 semantic search explicitly degrades to keyword ranking.
            logger.debug({ src: "ViewSearchIndex", err }, "[ViewSearchIndex] Could not embed query — semantic search unavailable");
            return [];
        }
        if (queryEmbedding.length === 0)
            return [];
        const scored = [];
        for (const [key, entry] of this.entries) {
            try {
                assertRuntimeViewEntry(runtime, entry.view);
            }
            catch {
                this.entries.delete(key);
                continue;
            }
            const score = cosineSimilarity(queryEmbedding, entry.embedding);
            scored.push({
                viewId: entry.viewId,
                viewType: entry.viewType,
                score,
            });
        }
        scored.sort((a, b) => {
            const bScore = typeof b.score === "number" && Number.isFinite(b.score) ? b.score : 0;
            const aScore = typeof a.score === "number" && Number.isFinite(a.score) ? a.score : 0;
            return bScore - aScore || a.viewId.localeCompare(b.viewId);
        });
        return scored.slice(0, topK);
    }
    /** Remove all entries (e.g. between test runs). */
    clear() {
        this.entries.clear();
    }
    /** Number of indexed views. */
    get size() {
        return this.entries.size;
    }
}
const runtimeIndexes = new WeakMap();
export function getViewSearchIndex(runtime) {
    let index = runtimeIndexes.get(runtime);
    if (!index) {
        index = new ViewSearchIndex(runtime);
        runtimeIndexes.set(runtime, index);
    }
    return index;
}
