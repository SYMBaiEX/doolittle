import type { IncomingMessage, ServerResponse } from "node:http";
/**
 * Returns true when the request was answered with 429 and dispatch must stop.
 */
export declare function maybeCapRequestStorm(req: IncomingMessage, res: ServerResponse, pathname: string): boolean;
/** Test-only: reset all request-budget state. */
export declare function __resetRequestStormCapForTests(): void;
/** Test-only: inspect bounded in-memory state without exposing session keys. */
export declare function __requestStormCapBucketCountForTests(): number;
