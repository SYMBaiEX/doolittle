async function loadElizaCloudRoutes() {
    return import("@elizaos/plugin-elizacloud");
}
export const handleCloudBillingRoute = async (...args) => {
    const { handleCloudBillingRoute } = await loadElizaCloudRoutes();
    return handleCloudBillingRoute(...args);
};
export const handleCloudCompatRoute = async (...args) => {
    const { handleCloudCompatRoute } = await loadElizaCloudRoutes();
    return handleCloudCompatRoute(...args);
};
export const handleCloudRoute = async (...args) => {
    const { handleCloudRoute } = await loadElizaCloudRoutes();
    return handleCloudRoute(...args);
};
export async function validateCloudBaseUrl(value) {
    const { validateCloudBaseUrl } = await loadElizaCloudRoutes();
    return validateCloudBaseUrl(value);
}
