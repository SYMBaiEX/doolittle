export declare function parseOptionalBooleanQuery(raw: string | null): {
    ok: true;
    value?: boolean;
} | {
    ok: false;
};
