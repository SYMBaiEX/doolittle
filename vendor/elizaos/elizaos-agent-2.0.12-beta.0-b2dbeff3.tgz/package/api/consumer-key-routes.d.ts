/**
 * OWNER-only HTTP boundary for account-pool consumer-key administration
 * (`/api/accounts/consumer-keys*`), backing the dashboard panel for #16478.
 *
 * This is deliberately NOT the loopback broker surface: the broker's
 * `/api/internal/account-pool/v1/*` routes authenticate with the broker bearer
 * secret, which must never reach the renderer. This boundary authorizes the
 * caller with the canonical `resolveBoundaryRole` OWNER check and reaches the
 * host's consumer-key store through the agent host bridge, so the agent never
 * imports `@elizaos/app`.
 *
 * Plaintext keys exist only in the create/rotate response bodies (one-time
 * display); they are never logged, persisted, or echoed anywhere else. On a
 * hostless (standalone) agent the facade is absent and every route answers
 * 501 rather than pretending an empty store exists.
 */
import type { RouteRequestContext } from "@elizaos/host/protocol";
/**
 * Handles `/api/accounts/consumer-keys` routes. Returns false when the path is
 * not part of this surface so the accounts dispatcher continues.
 */
export declare function handleConsumerKeyRoutes(ctx: RouteRequestContext): Promise<boolean>;
