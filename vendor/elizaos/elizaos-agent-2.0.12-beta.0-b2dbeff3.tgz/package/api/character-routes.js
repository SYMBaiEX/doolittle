/**
 * HTTP routes for reading and editing the running agent's character. Mounts the
 * `/api/character` surface: GET the merged character, PUT edits (validated,
 * persisted to the agent row so they survive restart, mirrored into the config
 * file, and journaled to character history), GET `/history`, GET `/random-name`,
 * GET `/schema` (the editable-field descriptor the dashboard renders), and POST
 * `/generate` (LLM-authored bio/system/style/examples via TEXT_SMALL). Renaming
 * rewrites speaker names and `{{agentName}}`/`{{name}}` tokens in the message
 * examples so the persona stays self-consistent.
 */
import { PostCharacterGenerateRequestSchema } from "@elizaos/contracts";
import { ModelType, validateUuid, } from "@elizaos/core";
import { buildCharacterHistorySnapshot, createHistoryWalkContext, isCharacterHistoryUnbounded, listCharacterHistory, readOwnDataValue, recordCharacterHistory, toBoundedCharacterValue, } from "../services/character-history.js";
import { syncCharacterIntoConfig } from "../services/character-persistence.js";
import { invalidateConversationConnectionTopology } from "./conversation-connection-readiness.js";
function experienceService(runtime) {
    return (runtime?.getService("EXPERIENCE") ?? null);
}
function boundedNumber(value, options) {
    if (value === null || value === "")
        return undefined;
    const parsed = Number(value);
    if (!Number.isFinite(parsed) ||
        (options.integer && !Number.isInteger(parsed)) ||
        parsed < options.min ||
        parsed > options.max) {
        return null;
    }
    return parsed;
}
function repeatedOrCsv(params, key) {
    const values = params
        .getAll(key)
        .flatMap((value) => value.split(","))
        .map((value) => value.trim())
        .filter(Boolean);
    return values.length > 0 ? values : undefined;
}
function parseExperienceQuery(url) {
    const limit = boundedNumber(url.searchParams.get("limit"), {
        min: 1,
        max: 500,
        integer: true,
    });
    const offset = boundedNumber(url.searchParams.get("offset"), {
        min: 0,
        max: 100_000,
        integer: true,
    });
    const minImportance = boundedNumber(url.searchParams.get("minImportance"), {
        min: 0,
        max: 1,
    });
    const minConfidence = boundedNumber(url.searchParams.get("minConfidence"), {
        min: 0,
        max: 1,
    });
    if ([limit, offset, minImportance, minConfidence].includes(null)) {
        return { query: {}, offset: 0, error: "Invalid experience query." };
    }
    const queryText = url.searchParams.get("query")?.trim() ||
        url.searchParams.get("q")?.trim() ||
        undefined;
    const type = repeatedOrCsv(url.searchParams, "type");
    const outcome = repeatedOrCsv(url.searchParams, "outcome");
    const domain = repeatedOrCsv(url.searchParams, "domain");
    // The typed UI client emits repeated singular `tag` parameters. Preserve the
    // plural `tags` spelling for existing callers and normalize both forms into
    // one stable, de-duplicated query list.
    const tags = [
        ...(repeatedOrCsv(url.searchParams, "tag") ?? []),
        ...(repeatedOrCsv(url.searchParams, "tags") ?? []),
    ].filter((value, index, values) => values.indexOf(value) === index);
    return {
        query: {
            ...(queryText ? { query: queryText } : {}),
            ...(type ? { type } : {}),
            ...(outcome ? { outcome } : {}),
            ...(domain ? { domain } : {}),
            ...(tags.length > 0 ? { tags } : {}),
            ...(typeof minImportance === "number" ? { minImportance } : {}),
            ...(typeof minConfidence === "number" ? { minConfidence } : {}),
            includeRelated: url.searchParams.get("includeRelated") === "true",
        },
        offset: offset ?? 0,
        ...(typeof limit === "number" ? { limit } : {}),
    };
}
function presentExperience(experience) {
    const { embedding, ...safe } = experience;
    return {
        ...safe,
        embeddingDimensions: Array.isArray(embedding) ? embedding.length : null,
    };
}
/** Parse the optional character-history limit without silently truncating input. */
export function parseCharacterHistoryLimit(raw) {
    if (raw === null)
        return undefined;
    if (!/^\d+$/.test(raw))
        return null;
    const parsed = Number(raw);
    return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}
function replaceCharacterNameTokens(value, nextName) {
    return value
        .replaceAll("{{agentName}}", nextName)
        .replaceAll("{{name}}", nextName);
}
function shouldRewriteExampleSpeakerName(speakerName, previousName) {
    const normalized = speakerName.trim().toLowerCase();
    if (!normalized)
        return false;
    if (normalized === "{{agentname}}" ||
        normalized === "{{name}}" ||
        normalized === "assistant" ||
        normalized === "agent" ||
        normalized === "ai" ||
        normalized === "model") {
        return true;
    }
    if (previousName?.trim()) {
        return normalized === previousName.trim().toLowerCase();
    }
    return false;
}
function isSnapshotRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
/**
 * Rewrite one already-snapshotted example. The input comes from
 * `buildCharacterHistorySnapshot`, so it is inert own data — plain reads,
 * spreads and `.map` here cannot run an accessor or a Proxy trap.
 */
function rewriteSnapshotExample(example, nextName, previousName) {
    const base = isSnapshotRecord(example) ? example : {};
    const speakerName = typeof base.name === "string" ? base.name : "";
    const content = isSnapshotRecord(base.content) ? base.content : {};
    const text = typeof content.text === "string" ? content.text : "";
    return {
        ...base,
        name: shouldRewriteExampleSpeakerName(speakerName, previousName)
            ? nextName
            : replaceCharacterNameTokens(speakerName, nextName),
        content: {
            ...content,
            text: replaceCharacterNameTokens(text, nextName),
        },
    };
}
/**
 * Rewrite speaker names / name tokens on the trusted snapshot only. Staging
 * snapshots first and rewriting second is what keeps the PUT path
 * descriptor-only: nothing here ever touches the submitted graph.
 */
function rewriteSnapshotMessageExamplesForName(messageExamples, nextName, previousName) {
    if (!Array.isArray(messageExamples)) {
        return undefined;
    }
    return messageExamples.map((group) => {
        const examples = isSnapshotRecord(group) && Array.isArray(group.examples)
            ? group.examples
            : [];
        return {
            examples: examples.map((example) => rewriteSnapshotExample(example, nextName, previousName)),
        };
    });
}
/** Character fields `PUT /api/character` may overlay. */
const CHARACTER_PUT_FIELDS = [
    "name",
    "username",
    "bio",
    "system",
    "adjectives",
    "topics",
    "style",
    "messageExamples",
    "postExamples",
];
/** Base-route commit shape for one submitted field, applied to bounded data. */
function shapeSubmittedField(field, value) {
    if (value === undefined)
        return undefined;
    if (field === "name" || field === "username" || field === "system") {
        return String(value);
    }
    if (field === "bio") {
        return Array.isArray(value) ? value : [String(value)];
    }
    return value;
}
/**
 * Stage the next character. Every value crosses the boundary exactly once,
 * through `toBoundedCharacterValue`: a single own-data-descriptor read of the
 * body (falling back to the live character), then one bounded descriptor walk
 * charged to the shared `ctx`. Nothing downstream touches the submitted graph.
 */
function stageCharacterPut(character, body, ctx) {
    const values = {};
    const submitted = new Set();
    for (const field of CHARACTER_PUT_FIELDS) {
        const raw = readOwnDataValue(body, field);
        if (raw != null) {
            submitted.add(field);
            values[field] = shapeSubmittedField(field, toBoundedCharacterValue(raw, ctx));
            continue;
        }
        values[field] = toBoundedCharacterValue(readOwnDataValue(character, field), ctx);
    }
    return { values, submitted };
}
/**
 * Commit the staged DTO onto the live character. Only fields the request
 * submitted are overwritten (plus message examples on a rename), and every
 * committed value is the bounded staged value — never the raw request graph,
 * and never the history snapshot.
 */
function commitStagedCharacter(target, staged) {
    for (const field of CHARACTER_PUT_FIELDS) {
        if (field === "messageExamples")
            continue;
        if (!staged.submitted.has(field))
            continue;
        const value = staged.values[field];
        if (value === undefined)
            continue;
        target[field] = value;
    }
    // Message examples also change on a rename, and the base route clears them
    // when the request submits a non-array, so presence is decided separately.
    if (staged.submitted.has("messageExamples")) {
        target.messageExamples = staged.values.messageExamples;
    }
    else if (staged.submitted.has("name") &&
        staged.values.messageExamples !== undefined) {
        target.messageExamples = staged.values.messageExamples;
    }
}
function syncRuntimeCharacterToConfig(state, saveConfig, nameWasExplicitlyEdited = false) {
    const runtime = state.runtime;
    const config = state.config;
    if (!runtime || !config)
        return;
    syncCharacterIntoConfig(config, runtime.character, {
        nameWasExplicitlyEdited,
    });
    saveConfig?.(config);
}
function buildCharacterSummary(ctx) {
    return [
        ctx.name ? `Name: ${ctx.name}` : "",
        ctx.system ? `System prompt: ${ctx.system}` : "",
        ctx.bio ? `Bio: ${ctx.bio}` : "",
        ctx.topics?.length ? `Topics: ${ctx.topics.join(", ")}` : "",
        ctx.style?.all?.length ? `Style rules: ${ctx.style.all.join("; ")}` : "",
    ]
        .filter(Boolean)
        .join("\n");
}
function buildGeneratePrompt(field, context, mode) {
    const charSummary = buildCharacterSummary(context);
    if (field === "bio") {
        return `Given this character:\n${charSummary}\n\nWrite a concise, compelling bio for this character (3-4 short paragraphs, one per line). Use their current interests and info to expand the bio into something more interesting and unique. Just output the bio lines, nothing else. Match the character's voice and personality.`;
    }
    if (field === "system") {
        return `Given this character:\n${charSummary}\n\nWrite a system prompt that defines how this AI agent should behave. The system prompt should be written in first person, describing the agent's personality, communication style, and core behaviors. Include specific guidelines about tone, language style (formal/casual), and any unique quirks. Keep it concise but comprehensive (2-4 paragraphs). Just output the system prompt text, nothing else.`;
    }
    if (field === "style") {
        const existing = mode === "append" && context.style?.all?.length
            ? `\nExisting style rules (add to these, don't repeat):\n${context.style.all.join("\n")}`
            : "";
        return `Given this character:\n${charSummary}${existing}\n\nGenerate 4-6 communication style rules for this character. Output a JSON object with keys "all", "chat", "post", each containing an array of short rule strings. Just output the JSON, nothing else.`;
    }
    if (field === "chatExamples") {
        return `Given this character:\n${charSummary}\n\nGenerate 3 example chat conversations showing how this character responds. Output strict JSON only, with no markdown fences and no explanation. The JSON must be an array of conversation groups using this exact schema:\n[\n  {\n    "examples": [\n      { "name": "{{user1}}", "content": { "text": "..." } },\n      { "name": "{{agentName}}", "content": { "text": "..." } }\n    ]\n  }\n]\n\nEach conversation should contain 2-4 turns. Use the "name" field, not "user" or "role". Use content.text strings only.`;
    }
    const existing = mode === "append" && context.postExamples?.length
        ? `\nExisting posts (add new ones, don't repeat):\n${context.postExamples.join("\n")}`
        : "";
    return `Given this character:\n${charSummary}${existing}\n\nGenerate 3-5 example social media posts this character would write. Output a JSON array of strings. Just output the JSON array, nothing else.`;
}
const CHARACTER_SCHEMA_FIELDS = [
    {
        key: "name",
        type: "string",
        label: "Name",
        description: "Agent display name",
        maxLength: 100,
    },
    {
        key: "username",
        type: "string",
        label: "Username",
        description: "Agent username for platforms",
        maxLength: 50,
    },
    {
        key: "bio",
        type: "string | string[]",
        label: "Bio",
        description: "Biography — single string or array of points",
    },
    {
        key: "system",
        type: "string",
        label: "System Prompt",
        description: "System prompt defining core behavior",
    },
    {
        key: "adjectives",
        type: "string[]",
        label: "Adjectives",
        description: "Personality adjectives (e.g. curious, witty)",
    },
    {
        key: "topics",
        type: "string[]",
        label: "Topics",
        description: "Conversation topics the agent is knowledgeable about",
    },
    {
        key: "style",
        type: "object",
        label: "Style",
        description: "Communication style guides",
        children: [
            {
                key: "all",
                type: "string[]",
                label: "All",
                description: "Style guidelines for all responses",
            },
            {
                key: "chat",
                type: "string[]",
                label: "Chat",
                description: "Style guidelines for chat responses",
            },
            {
                key: "post",
                type: "string[]",
                label: "Post",
                description: "Style guidelines for social media posts",
            },
        ],
    },
    {
        key: "messageExamples",
        type: "array",
        label: "Message Examples",
        description: "Example conversations demonstrating the agent's voice",
    },
    {
        key: "postExamples",
        type: "string[]",
        label: "Post Examples",
        description: "Example social media posts",
    },
];
export async function handleCharacterRoutes(ctx) {
    const { req, res, method, pathname, state, saveConfig, readJsonBody, json, error, pickRandomNames, validateCharacter, } = ctx;
    if (pathname.startsWith("/api/character/experiences")) {
        const service = experienceService(state.runtime);
        if (!service) {
            error(res, "Experience service is not available.", 503);
            return true;
        }
        const url = new URL(req.url ?? pathname, "http://localhost");
        const parsedQuery = parseExperienceQuery(url);
        if (parsedQuery.error) {
            error(res, parsedQuery.error, 400);
            return true;
        }
        if (method === "GET" && pathname === "/api/character/experiences") {
            const records = await service.listExperiences(parsedQuery.query);
            const page = records.slice(parsedQuery.offset, parsedQuery.limit === undefined
                ? undefined
                : parsedQuery.offset + parsedQuery.limit);
            json(res, { data: page.map(presentExperience), total: records.length });
            return true;
        }
        if (method === "GET" && pathname === "/api/character/experiences/graph") {
            const graph = await service.getExperienceGraph(parsedQuery.query);
            json(res, { data: graph });
            return true;
        }
        if (method === "POST" &&
            pathname === "/api/character/experiences/maintenance") {
            const body = await readJsonBody(req, res);
            if (!body)
                return true;
            const limit = body.limit === undefined
                ? undefined
                : boundedNumber(String(body.limit), {
                    min: 1,
                    max: 10_000,
                    integer: true,
                });
            if (limit === null ||
                (body.deleteDuplicates !== undefined &&
                    typeof body.deleteDuplicates !== "boolean")) {
                error(res, "Invalid experience maintenance options.", 400);
                return true;
            }
            const result = await service.dedupeDuplicateExperiences({
                deleteDuplicates: body.deleteDuplicates === true,
                ...(typeof limit === "number" ? { limit } : {}),
            });
            json(res, { data: result });
            return true;
        }
        const match = /^\/api\/character\/experiences\/([^/]+)$/.exec(pathname);
        if (!match)
            return false;
        let decodedId;
        try {
            decodedId = decodeURIComponent(match[1] ?? "");
        }
        catch {
            // error-policy:J3 Malformed percent-encoding is invalid route input.
            error(res, "Invalid experience id.", 400);
            return true;
        }
        const id = validateUuid(decodedId);
        if (!id) {
            error(res, "Invalid experience id.", 400);
            return true;
        }
        if (method === "GET") {
            const experience = await service.getExperience(id);
            if (!experience) {
                error(res, "Experience not found.", 404);
                return true;
            }
            json(res, { data: presentExperience(experience) });
            return true;
        }
        if (method === "PATCH") {
            const body = await readJsonBody(req, res);
            if (!body)
                return true;
            const allowed = new Set([
                "learning",
                "importance",
                "confidence",
                "tags",
                "keywords",
                "associatedEntityIds",
            ]);
            if (Object.keys(body).some((key) => !allowed.has(key))) {
                error(res, "Unsupported experience update field.", 400);
                return true;
            }
            if (body.learning !== undefined && typeof body.learning !== "string") {
                error(res, "Experience learning must be text.", 400);
                return true;
            }
            for (const key of ["importance", "confidence"]) {
                if (body[key] !== undefined &&
                    (typeof body[key] !== "number" || body[key] < 0 || body[key] > 1)) {
                    error(res, `Experience ${key} must be between 0 and 1.`, 400);
                    return true;
                }
            }
            for (const key of ["tags", "keywords"]) {
                if (body[key] !== undefined &&
                    (!Array.isArray(body[key]) ||
                        body[key].some((value) => typeof value !== "string"))) {
                    error(res, `Experience ${key} must be a list of text values.`, 400);
                    return true;
                }
            }
            if (body.associatedEntityIds !== undefined &&
                (!Array.isArray(body.associatedEntityIds) ||
                    body.associatedEntityIds.some((value) => typeof value !== "string" || !validateUuid(value)))) {
                error(res, "Experience associatedEntityIds must contain UUIDs.", 400);
                return true;
            }
            const experience = await service.updateExperience(id, body);
            if (!experience) {
                error(res, "Experience not found.", 404);
                return true;
            }
            json(res, { data: presentExperience(experience) });
            return true;
        }
        if (method === "DELETE") {
            if (!(await service.deleteExperience(id))) {
                error(res, "Experience not found.", 404);
                return true;
            }
            json(res, { ok: true });
            return true;
        }
    }
    if (method === "GET" && pathname === "/api/character/history") {
        if (!state.runtime) {
            error(res, "Agent runtime not available. Start the agent first.", 503);
            return true;
        }
        const url = new URL(req.url ?? pathname, "http://localhost");
        const limit = parseCharacterHistoryLimit(url.searchParams.get("limit"));
        if (limit === null) {
            error(res, "Invalid character history limit.", 400);
            return true;
        }
        const history = await listCharacterHistory(state.runtime, limit);
        json(res, { history, agentName: state.agentName });
        return true;
    }
    if (method === "GET" && pathname === "/api/character") {
        const runtime = state.runtime;
        if (!runtime) {
            error(res, "Agent runtime not available. Start the agent first.", 503);
            return true;
        }
        const merged = {};
        const character = runtime.character;
        if (character.name)
            merged.name = character.name;
        if (character.username)
            merged.username = character.username;
        if (character.bio)
            merged.bio = character.bio;
        if (character.system)
            merged.system = character.system;
        if (character.adjectives)
            merged.adjectives = character.adjectives;
        if (Array.isArray(character.topics)) {
            merged.topics = character.topics;
        }
        if (character.style)
            merged.style = character.style;
        if (character.messageExamples) {
            merged.messageExamples = character.messageExamples;
        }
        if (character.postExamples) {
            merged.postExamples = character.postExamples;
        }
        json(res, { character: merged, agentName: state.agentName });
        return true;
    }
    if (method === "PUT" && pathname === "/api/character") {
        // A stopped agent has no live character to change, and its saved config
        // is rebuilt on start: answering ok here would drop the edit silently.
        if (!state.runtime) {
            error(res, "Agent runtime not available. Start the agent first.", 503);
            return true;
        }
        const body = await readJsonBody(req, res);
        if (!body)
            return true;
        const result = validateCharacter(body);
        if (!result.success && "error" in result) {
            const issues = result.error.issues.map((issue) => ({
                path: issue.path.join("."),
                message: issue.message,
            }));
            json(res, {
                ok: false,
                error: issues
                    .map((issue) => issue.path ? `${issue.path}: ${issue.message}` : issue.message)
                    .join("; "),
                validationErrors: issues,
            }, 422);
            return true;
        }
        const runtime = state.runtime;
        if (runtime) {
            const character = runtime.character;
            let previousCharacter;
            try {
                previousCharacter = buildCharacterHistorySnapshot(character);
            }
            catch (err) {
                // error-policy:J3 cyclic/over-deep live character is invalid input.
                if (isCharacterHistoryUnbounded(err)) {
                    error(res, "Character payload exceeds the history walk budget", 400);
                    return true;
                }
                throw err;
            }
            const liveCharacterName = readOwnDataValue(character, "name");
            const previousCharacterName = typeof liveCharacterName === "string" ? liveCharacterName : undefined;
            const submittedName = readOwnDataValue(body, "name");
            const nextStoredCharacterName = submittedName != null ? String(submittedName) : previousCharacterName;
            const nextCharacterName = typeof submittedName === "string" && submittedName.trim()
                ? submittedName.trim()
                : previousCharacterName?.trim()
                    ? previousCharacterName.trim()
                    : state.agentName;
            // Stage the whole next character once, under one bounded descriptor walk;
            // the submitted graph is never traversed outside this call. The staged
            // DTO is the value authority for the live character (presence preserved),
            // and the history snapshot is derived from it afterwards.
            let staged;
            let charData;
            try {
                staged = stageCharacterPut(character, body, createHistoryWalkContext());
                if (staged.submitted.has("name") ||
                    staged.submitted.has("messageExamples")) {
                    const rewritten = rewriteSnapshotMessageExamplesForName(staged.values.messageExamples, nextCharacterName, previousCharacterName);
                    if (rewritten !== undefined ||
                        staged.submitted.has("messageExamples")) {
                        staged.values.messageExamples = rewritten;
                    }
                }
                // Derived from staged plain data, so this walk cannot reach the
                // request graph; it re-applies the history-display normalization only.
                charData = buildCharacterHistorySnapshot(staged.values);
            }
            catch (err) {
                // error-policy:J3 Zod-accepted passthrough extras can still overflow.
                if (isCharacterHistoryUnbounded(err)) {
                    error(res, "Character payload exceeds the history walk budget", 400);
                    return true;
                }
                throw err;
            }
            // Persist the staged character BEFORE changing the live character or the
            // config: `updateAgent` reports false when the agent row was not written
            // (for example a restored database that has no row for this agent), and
            // the persistence service already treats that result as a failure. Do not
            // answer "saved" for a write storage never confirmed.
            const storedName = staged.submitted.has("name") && typeof staged.values.name === "string"
                ? staged.values.name
                : character.name;
            try {
                const updated = await runtime.updateAgent(runtime.agentId, {
                    name: storedName,
                    metadata: {
                        ...runtime.character
                            .metadata,
                        character: charData,
                    },
                });
                if (!updated) {
                    error(res, "Character storage update was not confirmed.", 500);
                    return true;
                }
            }
            catch (err) {
                // error-policy:J3 Zod-accepted passthrough extras can still overflow.
                if (isCharacterHistoryUnbounded(err)) {
                    error(res, "Character payload exceeds the history walk budget", 400);
                    return true;
                }
                throw err;
            }
            if (nextStoredCharacterName !== undefined &&
                nextStoredCharacterName !== previousCharacterName) {
                invalidateConversationConnectionTopology(runtime);
            }
            commitStagedCharacter(character, staged);
            try {
                await recordCharacterHistory(runtime, {
                    previousCharacter,
                    nextCharacter: character,
                    source: "manual",
                });
            }
            catch (err) {
                // error-policy:J3 Zod-accepted passthrough extras can still overflow.
                if (isCharacterHistoryUnbounded(err)) {
                    error(res, "Character payload exceeds the history walk budget", 400);
                    return true;
                }
                throw err;
            }
        }
        syncRuntimeCharacterToConfig(state, saveConfig, readOwnDataValue(body, "name") != null);
        const submittedAgentName = readOwnDataValue(body, "name");
        if (submittedAgentName)
            state.agentName = String(submittedAgentName);
        json(res, {
            ok: true,
            character: state.runtime?.character ?? body,
            agentName: state.agentName,
        });
        return true;
    }
    if (method === "GET" && pathname === "/api/character/random-name") {
        const names = pickRandomNames(1);
        json(res, { name: names[0] ?? "Reimu" });
        return true;
    }
    if (method === "POST" && pathname === "/api/character/generate") {
        const rawGen = await readJsonBody(req, res);
        if (rawGen === null)
            return true;
        const parsedGen = PostCharacterGenerateRequestSchema.safeParse(rawGen);
        if (!parsedGen.success) {
            error(res, parsedGen.error.issues[0]?.message ?? "field and context are required", 400);
            return true;
        }
        const body = parsedGen.data;
        const runtime = state.runtime;
        if (!runtime) {
            error(res, "Agent runtime not available. Start the agent first.", 503);
            return true;
        }
        if (body.field !== "bio" &&
            body.field !== "system" &&
            body.field !== "style" &&
            body.field !== "chatExamples" &&
            body.field !== "postExamples") {
            error(res, `Unknown field: ${body.field}`, 400);
            return true;
        }
        const prompt = buildGeneratePrompt(body.field, body.context, body.mode);
        const result = await runtime.useModel(ModelType.TEXT_SMALL, {
            prompt,
            temperature: 0.8,
        });
        json(res, { generated: String(result) });
        return true;
    }
    if (method === "GET" && pathname === "/api/character/schema") {
        json(res, { fields: CHARACTER_SCHEMA_FIELDS });
        return true;
    }
    return false;
}
