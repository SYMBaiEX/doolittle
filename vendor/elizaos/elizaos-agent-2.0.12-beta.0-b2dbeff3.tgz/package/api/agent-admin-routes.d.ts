import { type AgentRuntime, type UUID } from "@elizaos/core";
import { type RouteHelpers, type RouteRequestMeta } from "@elizaos/host/protocol";
import { loadElizaConfig } from "../config/config.js";
import type { RuntimeRestartOptions } from "./server.js";
type AgentStateStatus = "not_started" | "starting" | "running" | "paused" | "stopped" | "restarting" | "error";
export interface AgentAdminRouteState {
    runtime: AgentRuntime | null;
    config: Record<string, unknown>;
    agentState: AgentStateStatus;
    agentName: string;
    model: string | undefined;
    startedAt: number | undefined;
    chatRoomId: UUID | null;
    chatUserId: UUID | null;
    chatConnectionReady: {
        userId: UUID;
        roomId: UUID;
        worldId: UUID;
    } | null;
    chatConnectionPromise: Promise<void> | null;
    runtimeStopPromise: Promise<void> | null;
    pendingRestartReasons: string[];
    conversations?: Map<string, unknown>;
    activeConversationId?: string | null;
    conversationRestorePromise?: Promise<void> | null;
}
export interface AgentAdminRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json" | "error"> {
    state: AgentAdminRouteState;
    onRestart?: ((options?: RuntimeRestartOptions) => Promise<AgentRuntime | null>) | undefined;
    restartRequiresRuntimeDisposal?: boolean;
    onRuntimeSwapped?: () => void;
    onRuntimeActivated?: (previousRuntime: AgentRuntime | null, activeRuntime: AgentRuntime) => void | Promise<void>;
    resolveStateDir: () => string;
    stateDirExists: (resolvedState: string) => boolean;
    removeStateDir: (resolvedState: string) => void;
}
/**
 * The local store that Reset deletes. Reset only erases the default PGlite
 * directory; for any other store it throws before the runtime stops, so the
 * route cannot report a reset that left conversations and memory in place.
 */
export declare function resolveResetPgliteDataDir(config: ReturnType<typeof loadElizaConfig>, defaultWorkspaceDir: string): string;
export declare function handleAgentAdminRoutes(ctx: AgentAdminRouteContext): Promise<boolean>;
export {};
