/**
 * Mounts the plugin-registry read/refresh API behind the authenticated gate:
 * GET /api/registry/plugins (registry entries annotated with installed / loaded
 * / bundled state, installed and latest versions, and release-channel
 * compatibility), GET /api/registry/plugins/:name, GET /api/registry/search,
 * and POST /api/registry/refresh. Reads through the injected plugin manager;
 * upstream failures surface as 502.
 */
import type { RouteHelpers, RouteRequestMeta } from "@elizaos/host/protocol";
import type { RegistryPluginInfo, RegistrySearchResult } from "../services/plugin-manager-types.js";
interface InstalledRegistryPluginLike {
    name: string;
    version?: string | null;
    releaseStream?: "latest" | "beta";
    latestVersion?: string | null;
    betaVersion?: string | null;
}
interface RegistryPluginManagerLike {
    refreshRegistry: () => Promise<Map<string, RegistryPluginInfo>>;
    listInstalledPlugins: () => Promise<InstalledRegistryPluginLike[]>;
    getRegistryPlugin: (name: string) => Promise<RegistryPluginInfo | null>;
    searchRegistry: (query: string, limit: number) => Promise<RegistrySearchResult[]>;
}
export interface RegistryRouteContext extends RouteRequestMeta, Pick<RouteHelpers, "json" | "error"> {
    url: URL;
    getPluginManager: () => RegistryPluginManagerLike;
    getLoadedPluginNames: () => string[];
    getBundledPluginIds: () => Set<string>;
    classifyRegistryPluginRelease: (params: {
        packageName: string;
        bundledPluginIds: ReadonlySet<string>;
        kind?: string;
    }) => unknown;
}
export declare function handleRegistryRoutes(ctx: RegistryRouteContext): Promise<boolean>;
export {};
