/**
 * Hook Loader — load and register hooks into the event system.
 *
 * Orchestrates discovery -> eligibility -> loading -> registration.
 *
 * @module hooks/loader
 */
import type { InternalHooksConfig } from "@elizaos/host/protocol";
import { type DiscoveryOptions } from "./discovery.js";
export interface LoadHooksOptions extends DiscoveryOptions {
    /** Internal hooks configuration. */
    internalConfig?: InternalHooksConfig;
    /** Full Eliza config for eligibility checks. */
    elizaConfig?: Record<string, unknown>;
}
export interface LoadHooksResult {
    /** Total hooks discovered. */
    discovered: number;
    /** Hooks that passed eligibility. */
    eligible: number;
    /** Hooks successfully loaded and registered. */
    registered: number;
    /** Hooks that were skipped (disabled or ineligible). */
    skipped: string[];
    /** Hooks that failed to load. */
    failed: string[];
}
/**
 * Discover, filter, load, and register all hooks.
 *
 * This is the main entry point called during gateway startup.
 */
export declare function loadHooks(options?: LoadHooksOptions): Promise<LoadHooksResult>;
