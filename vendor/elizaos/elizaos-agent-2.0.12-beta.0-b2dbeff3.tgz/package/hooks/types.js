/**
 * Hooks Type Definitions
 *
 * Core types for Eliza's event-driven hooks system.
 *
 * @module hooks/types
 */
export {};
