import type { HookEvent, HookHandler } from "./types.js";
/**
 * Event keys: "command" matches all command events,
 * "command:new" matches only /new.
 */
export declare function registerHook(eventKey: string, handler: HookHandler): void;
export declare function clearHooks(): void;
/** Dispatches to specific ("command:new") then general ("command") handlers. */
export declare function triggerHook(event: HookEvent): Promise<void>;
export declare function createHookEvent(type: HookEvent["type"], action: string, sessionKey: string, context?: Record<string, unknown>): HookEvent;
