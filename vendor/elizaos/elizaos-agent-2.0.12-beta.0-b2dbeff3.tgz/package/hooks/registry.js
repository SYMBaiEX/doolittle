/**
 * In-process registry mapping hook event keys to handler lists, plus the
 * dispatch that fans an event out through them. Keys are matched specific-first
 * ("command:new") then general ("command"); handler failures are isolated and
 * logged rather than thrown, so one bad hook cannot abort the rest.
 * `createHookEvent` builds the payloads that flow through `triggerHook`.
 */
import { logger } from "@elizaos/core";
const registry = new Map();
/**
 * Event keys: "command" matches all command events,
 * "command:new" matches only /new.
 */
export function registerHook(eventKey, handler) {
    const handlers = registry.get(eventKey) ?? [];
    handlers.push(handler);
    registry.set(eventKey, handlers);
}
export function clearHooks() {
    registry.clear();
}
/** Dispatches to specific ("command:new") then general ("command") handlers. */
export async function triggerHook(event) {
    const specificKey = `${event.type}:${event.action}`;
    const generalKey = event.type;
    const handlers = [];
    const specificHandlers = registry.get(specificKey);
    if (specificHandlers) {
        for (const handler of specificHandlers) {
            handlers.push({ key: specificKey, handler });
        }
    }
    const generalHandlers = registry.get(generalKey);
    if (generalHandlers) {
        for (const handler of generalHandlers) {
            handlers.push({ key: generalKey, handler });
        }
    }
    if (handlers.length === 0)
        return;
    const errors = [];
    for (const { key, handler } of handlers) {
        try {
            await handler(event);
        }
        catch (err) {
            const error = err instanceof Error ? err : new Error(String(err));
            logger.error(`[hooks] Handler error for "${key}": ${error.message}`);
            errors.push(error);
        }
    }
    if (errors.length > 0) {
        logger.warn(`[hooks] ${errors.length} hook handler(s) failed — errors were logged above`);
    }
}
export function createHookEvent(type, action, sessionKey, context = {}) {
    return {
        type,
        action,
        sessionKey,
        timestamp: new Date(),
        messages: [],
        context,
    };
}
