/**
 * Discover hooks from workspace, managed state-dir hooks, and bundled dirs.
 * Later sources win on name conflicts.
 */
import type { HookEntry } from "./types.js";
export interface DiscoveryOptions {
    workspacePath?: string;
    bundledDir?: string;
    extraDirs?: string[];
}
/** Precedence: extra (lowest) -> bundled -> managed -> workspace (highest). */
export declare function discoverHooks(options?: DiscoveryOptions): Promise<HookEntry[]>;
