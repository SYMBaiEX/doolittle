/**
 * Discover hooks from workspace, managed state-dir hooks, and bundled dirs.
 * Later sources win on name conflicts.
 */
import { readdir, readFile, stat } from "node:fs/promises";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import { logger, parseFrontmatterDocument, resolveStateDir, } from "@elizaos/core";
const HOOK_MD = "HOOK.md";
const HANDLER_NAMES = [
    "handler.ts",
    "handler.mjs",
    "handler",
    "index.ts",
    "index.mjs",
    "index",
];
function parseFrontmatter(content) {
    const parsed = parseFrontmatterDocument(content);
    if (parsed.kind !== "parsed")
        return null;
    const { name, description, homepage, metadata } = parsed.frontmatter;
    if (typeof name !== "string" || !name.trim())
        return null;
    if (typeof description !== "string")
        return null;
    const result = {
        name: name.trim(),
        description: description.trim(),
    };
    if (typeof homepage === "string")
        result.homepage = homepage.trim();
    if (typeof metadata === "object" &&
        metadata !== null &&
        !Array.isArray(metadata)) {
        result.metadata = metadata;
    }
    return result;
}
function extractMetadata(frontmatter) {
    const meta = frontmatter.metadata?.eliza;
    if (!meta)
        return undefined;
    return {
        always: meta.always,
        hookKey: meta.hookKey,
        emoji: meta.emoji,
        homepage: meta.homepage ?? frontmatter.homepage,
        events: Array.isArray(meta.events) ? meta.events : [],
        export: meta.export,
        os: meta.os,
        requires: meta.requires,
        install: meta.install,
    };
}
async function isDirectory(path) {
    try {
        return (await stat(path)).isDirectory();
    }
    catch {
        return false;
    }
}
async function fileExists(path) {
    try {
        return (await stat(path)).isFile();
    }
    catch {
        return false;
    }
}
async function findHandlerPath(dir) {
    for (const name of HANDLER_NAMES) {
        const p = join(dir, name);
        if (await fileExists(p))
            return p;
    }
    return null;
}
async function loadHookFromDir(dir, source, pluginId) {
    const hookMdPath = join(dir, HOOK_MD);
    if (!(await fileExists(hookMdPath)))
        return null;
    const handlerPath = await findHandlerPath(dir);
    if (!handlerPath) {
        logger.warn(`[hooks] Hook at ${dir} has HOOK.md but no handler`);
        return null;
    }
    try {
        const content = await readFile(hookMdPath, "utf-8");
        const frontmatter = parseFrontmatter(content);
        if (!frontmatter) {
            logger.warn(`[hooks] Invalid frontmatter in ${hookMdPath}`);
            return null;
        }
        const metadata = extractMetadata(frontmatter);
        const hook = {
            name: frontmatter.name,
            description: frontmatter.description,
            source,
            pluginId,
            filePath: hookMdPath,
            baseDir: dir,
            handlerPath,
        };
        return { hook, frontmatter, metadata };
    }
    catch (err) {
        const msg = String(err);
        logger.warn(`[hooks] Error loading hook from ${dir}: ${msg}`);
        return null;
    }
}
async function scanHooksDir(dir, source) {
    if (!(await isDirectory(dir)))
        return [];
    const entries = [];
    try {
        const items = await readdir(dir);
        for (const item of items) {
            const itemPath = join(dir, item);
            if (!(await isDirectory(itemPath)))
                continue;
            const entry = await loadHookFromDir(itemPath, source);
            if (entry) {
                entries.push(entry);
            }
        }
    }
    catch (err) {
        const msg = String(err);
        logger.warn(`[hooks] Error scanning ${dir}: ${msg}`);
    }
    return entries;
}
/** Precedence: extra (lowest) -> bundled -> managed -> workspace (highest). */
export async function discoverHooks(options = {}) {
    const seen = new Map();
    if (options.extraDirs) {
        for (const dir of options.extraDirs) {
            const resolved = resolve(dir.replace(/^~/, homedir()));
            for (const entry of await scanHooksDir(resolved, "eliza-managed")) {
                seen.set(entry.hook.name, entry);
            }
        }
    }
    if (options.bundledDir) {
        for (const entry of await scanHooksDir(options.bundledDir, "eliza-bundled")) {
            seen.set(entry.hook.name, entry);
        }
    }
    const managedDir = join(resolveStateDir(), "hooks");
    for (const entry of await scanHooksDir(managedDir, "eliza-managed")) {
        seen.set(entry.hook.name, entry);
    }
    if (options.workspacePath) {
        const wsHooksDir = join(options.workspacePath.replace(/^~/, homedir()), "hooks");
        for (const entry of await scanHooksDir(wsHooksDir, "eliza-workspace")) {
            seen.set(entry.hook.name, entry);
        }
    }
    const all = Array.from(seen.values());
    logger.info(`[hooks] Discovered ${all.length} hooks`);
    return all;
}
