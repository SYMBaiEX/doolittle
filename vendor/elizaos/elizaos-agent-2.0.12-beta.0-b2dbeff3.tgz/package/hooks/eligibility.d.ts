/**
 * Hook eligibility: checks OS, binary, env, and config requirements.
 */
import type { HookConfig, InternalHooksConfig } from "@elizaos/host/protocol";
import type { ElizaHookMetadata } from "./types.js";
export interface EligibilityResult {
    eligible: boolean;
    missing: string[];
}
export declare function checkEligibility(metadata: ElizaHookMetadata | undefined, hookConfig: HookConfig | undefined, elizaConfig?: Record<string, unknown>): EligibilityResult;
export declare function resolveHookConfig(internalConfig: InternalHooksConfig | undefined, hookKey: string): HookConfig | undefined;
