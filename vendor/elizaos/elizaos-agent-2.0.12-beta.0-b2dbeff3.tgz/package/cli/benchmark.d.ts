import { type ActionResult, type AgentRuntime, type EffectReceipt } from "@elizaos/core";
/** Input task schema accepted from the orchestrator. */
export interface BenchmarkTask {
    id: string;
    type?: string;
    prompt: string;
    context?: Record<string, unknown>;
    expected?: string;
}
/** Output result schema written to stdout. */
export interface BenchmarkResult {
    id: string;
    response: string;
    task_type: string;
    actions_taken: string[];
    duration_ms: number;
    success: boolean;
    turn_completed?: boolean;
    request_fulfilled?: boolean;
    effect_receipts?: readonly EffectReceipt[];
    action_results?: readonly ActionResult[];
    error?: string;
    failure_kind?: string;
    failure_code?: string;
    transient?: boolean;
}
/** Runs one task through the same message service used by interactive hosts. */
export declare function runBenchmarkTask(runtime: AgentRuntime, task: BenchmarkTask, abortSignal: AbortSignal): Promise<BenchmarkResult>;
/** Parse a JSON string into a BenchmarkTask, throwing on invalid input. */
export declare function parseBenchmarkTask(raw: string): BenchmarkTask;
/** Runs line-delimited tasks until input closes or the process owner cancels. */
export declare function runBenchmarkServer(runtime: AgentRuntime, abortSignal: AbortSignal, input?: NodeJS.ReadableStream, output?: (result: BenchmarkResult) => void): Promise<void>;
export interface BenchmarkCommandOptions {
    task?: string;
    server?: boolean;
}
/** Parses the autonomous CLI benchmark flags with the same strictness as Commander. */
export declare function parseBenchmarkCommandOptions(argv: readonly string[], startIndex?: number): BenchmarkCommandOptions;
/** Reads one task from a stream until EOF or owner cancellation. */
export declare function readBenchmarkInput(abortSignal: AbortSignal, input?: NodeJS.ReadableStream): Promise<string>;
/**
 * Entry point for the `benchmark` CLI subcommand.
 */
export declare function runBenchmark(opts: BenchmarkCommandOptions): Promise<void>;
