export declare function runAutonomousCli(argv?: string[]): Promise<void>;
