#!/usr/bin/env node
/**
 * Process entrypoint for the `eliza-autonomous` binary. Before any heavy import
 * it enables Node's persistent V8 compile cache (anchored to the shared state
 * dir) and configures mobile DNS, then pins the mobile/AOSP bundle anchors onto
 * the bootstrap path so tree-shaking cannot drop the on-device inference and
 * device-bridge plugins, and finally hands off to runAutonomousCli(). A fatal
 * boot error is logged to the Android bin-debug file and exits non-zero.
 */
import * as _earlyFs from "node:fs";
import { enableCompileCache } from "node:module";
import { homedir as _earlyHomedir } from "node:os";
import { captureHostExecutionBaseline } from "@elizaos/host";
import { isAndroidMobile, readAliasedEnv } from "@elizaos/host/protocol";
import { configureMobileDnsIfNeeded } from "./runtime/mobile-dns.js";
import { captureProtectedProfile } from "./security/protected-profile-state.js";
// Resolve a branded `<PREFIX>_STATE_DIR` / `<PREFIX>_PLATFORM` through the
// boot-config alias table — the reader path, with no process.env mirror
// (issue #13423). `@elizaos/core` is already a transitive static import via
// `./cli/index.ts`, so this adds no new module to the boot graph; before the
// alias table is seeded these fall back to the raw ELIZA_ value.
// Establish the host executable-search authority before the CLI dynamically
// imports runtime configuration or any plugin code.
captureHostExecutionBaseline();
// Capture the protected profile from the entry environment before any command
// can load configuration that mutates process.env.
captureProtectedProfile();
// Enable Node 22.8+'s persistent V8 compile cache before any heavy import so
// the 2nd+ cold boot skips recompiling the ~70k LOC of transpiled plugin
// source. Anchored to <stateDir>/cache/node-compile — the SAME dir the dev
// orchestrator pins via NODE_COMPILE_CACHE (dev-ui.ts) — so the packaged CLI
// path and the dev path share one warm cache instead of two.
//
// When NODE_COMPILE_CACHE is already set (dev path), Node enables the cache
// from the env var before any user code runs, so we skip — calling it again
// would be redundant. Wrapped defensively: a missing API (older Node) or any
// failure must never break boot.
(() => {
    try {
        if (typeof enableCompileCache !== "function" ||
            process.env.NODE_COMPILE_CACHE?.trim()) {
            return;
        }
        const xdgStateHome = process.env.XDG_STATE_HOME?.trim();
        // `process.env.HOME` is unset on Windows; `os.homedir()` returns
        // `%USERPROFILE%` there and `$HOME` on POSIX, so this cache anchors
        // identically to the rest of the codebase (see state-dir.ts).
        const home = process.env.HOME?.trim() || _earlyHomedir();
        const resolvedStateDir = readAliasedEnv("ELIZA_STATE_DIR") ||
            (xdgStateHome
                ? `${xdgStateHome}/eliza`
                : home
                    ? `${home}/.local/state/eliza`
                    : undefined);
        if (resolvedStateDir) {
            enableCompileCache(`${resolvedStateDir}/cache/node-compile`);
        }
        else {
            enableCompileCache();
        }
    }
    catch {
        // V8 compile cache is a pure boot-time optimization; ignore any failure.
    }
})();
// Early diagnostic logger for Android: captures errors before the fs shim runs.
// Uses raw node:fs so the shim can't interfere. Writes to $ELIZA_STATE_DIR/bin-debug.log.
const _binDebugLog = isAndroidMobile()
    ? (() => {
        const xdgStateHome = process.env.XDG_STATE_HOME ??
            `${process.env.HOME ?? "/data/local/tmp"}/.local/state`;
        const stateDir = readAliasedEnv("ELIZA_STATE_DIR") || `${xdgStateHome}/eliza`;
        const logPath = `${stateDir}/bin-debug.log`;
        try {
            _earlyFs.mkdirSync(stateDir, { recursive: true });
        }
        catch {
            // error-policy:J7 early Android diagnostics cannot depend on the logger;
            // failure to create the diagnostic directory is observed by the later
            // fatal stderr path.
        }
        return (msg) => {
            try {
                _earlyFs.appendFileSync(logPath, `${new Date().toISOString()} ${msg}\n`);
            }
            catch {
                // error-policy:J7 the raw diagnostic sink must never mask the boot
                // error it is attempting to record.
            }
        };
    })()
    : () => { };
_binDebugLog(`[bin.ts] started ELIZA_PLATFORM=${readAliasedEnv("ELIZA_PLATFORM") ?? "(unset)"} ELIZA_STATE_DIR=${readAliasedEnv("ELIZA_STATE_DIR") ?? "(unset)"}`);
// Mobile devices ship no /etc/resolv.conf, so the musl bun agent can't resolve
// DNS — every outbound fetch (cloud, model catalog, connectors) fails until we
// point the resolver at public nameservers. No-op off-device. Runs at module
// eval, before the runtime boots or any fetch fires.
configureMobileDnsIfNeeded();
async function bootstrapMobileEntrypoint() {
    if (isAndroidMobile()) {
        _binDebugLog("[bin.ts] entering android block");
        try {
            // Bundle anchor: evaluating this literal-specifier import forces
            // @elizaos/plugin-native-inference into the mobile bundle. Its exports
            // are re-imported and consumed by the runtime independently
            // (eliza.ts ensureAospLocalInferenceHandlers; plugin-local-inference's
            // registerAospLlamaLoader), so nothing is captured here.
            await import(/* @vite-ignore */ "@elizaos/plugin-native-inference");
        }
        catch (e) {
            // Android-only local inference is optional outside the privileged AOSP build.
            _binDebugLog(`[bin.ts] aosp-local-inference init error (ok): ${e instanceof Error ? e.message : String(e)}`);
        }
        try {
            await import("./runtime/android-app-plugins.js");
            _binDebugLog("[bin.ts] android-app-plugins loaded ok");
        }
        catch (e) {
            // Android-only app plugins not bundled in this build; plugin-resolver.ts
            // returns null for these IDs and the rest of the runtime is unaffected.
            _binDebugLog(`[bin.ts] android-app-plugins init error (ok): ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    if (process.env.ELIZA_DEVICE_BRIDGE_ENABLED === "1") {
        try {
            // Bundle anchor only: eliza.ts imports and calls
            // ensureMobileDeviceBridgeInferenceHandlers on the runtime.
            await import("@elizaos/plugin-native-inference/mobile-device-bridge-bootstrap");
        }
        catch {
            // Device bridge is explicitly opt-in; absence just leaves cloud/local-model
            // provider selection to the runtime.
        }
    }
    _binDebugLog("[bin.ts] pre-runAutonomousCli");
    const { runAutonomousCli } = await import("./cli/index.js");
    await runAutonomousCli();
}
bootstrapMobileEntrypoint().catch((error) => {
    const msg = error instanceof Error ? (error.stack ?? error.message) : String(error);
    _binDebugLog(`[bin.ts] FATAL runAutonomousCli threw: ${msg}`);
    console.error("[eliza-autonomous] Failed to start:", msg);
    process.exit(1);
});
