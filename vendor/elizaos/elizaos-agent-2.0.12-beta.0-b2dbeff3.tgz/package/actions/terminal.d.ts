/**
 * Executes one explicit shell command through the local terminal API and
 * converts its bounded output into planner-visible data and an attachment.
 * Every dispatch carries a fresh run identity; transport ambiguity preserves
 * that identity so callers can reconcile the effect instead of retrying it.
 */
import { type Action } from "@elizaos/core";
export declare const terminalAction: Action;
