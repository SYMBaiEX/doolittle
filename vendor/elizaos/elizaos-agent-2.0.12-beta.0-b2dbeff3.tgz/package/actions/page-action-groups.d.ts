/** Owner-only delegation to registered actions in the requested page context. */
import type { Action, AgentContext } from "@elizaos/core";
type PageActionGroup = Action & {
    actionGroup: {
        contexts: AgentContext[];
    };
};
export declare const pageDelegateAction: PageActionGroup;
export {};
