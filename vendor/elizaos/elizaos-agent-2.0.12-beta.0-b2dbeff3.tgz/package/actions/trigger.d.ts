import { type Action, type Memory } from "@elizaos/core";
declare const TRIGGER_OPS: readonly ["create", "update", "delete", "run", "toggle", "list"];
/**
 * The trigger the user named in a request the planner sent without any
 * target ("delete the landlord trigger" arrived as `{action: "delete"}`,
 * live 2026-09-14, and the not-found text became the delivered reply
 * although the retry deleted it). The words after the leading verb, minus
 * the generic nouns; undefined when nothing usable remains.
 */
export declare function impliedTriggerQuery(message: Memory | undefined): string | undefined;
export declare const triggerAction: Action;
export { TRIGGER_OPS };
