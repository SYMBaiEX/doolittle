/**
 * Polymorphic DATABASE action.
 *
 * Single action that dispatches across the database introspection ops:
 *   - list_tables    : enumerate user tables with row counts and columns.
 *   - get_table      : page rows from a specific table (limit/offset/sort).
 *   - query          : execute raw SQL (read-only by default).
 *   - search_vectors : embed text and return top-k semantic memory matches.
 *
 * All ops talk directly to the in-process runtime adapter (Drizzle ORM via
 * `runtime.adapter.db`) and `runtime.searchMemories` / `runtime.useModel`.
 * No HTTP. The previous LIST_DATABASE_TABLES / GET_TABLE_DATA /
 * EXECUTE_DATABASE_QUERY / SEARCH_VECTORS actions hit /api/database/* — that
 * server route layer is still used by the dashboard UI but is now bypassed
 * for the agent's own tool surface.
 */
import { logger, ModelType, toWellFormedUnicode, } from "@elizaos/core";
import { checkReadOnly } from "../security/sql-readonly-guard.js";
import { parseRequestedSchema, qualifiedTable, quoteIdent, resolveTableSchema, } from "../shared/database-table.js";
// ---------------------------------------------------------------------------
// Op dispatch
// ---------------------------------------------------------------------------
const DATABASE_OPS = [
    "list_tables",
    "get_table",
    "query",
    "search_vectors",
];
function isDatabaseOp(value) {
    return (typeof value === "string" &&
        DATABASE_OPS.includes(value));
}
function getParams(options) {
    const opts = options;
    return opts?.parameters ?? {};
}
function hasDrizzleDb(adapter) {
    return (typeof adapter === "object" &&
        adapter !== null &&
        typeof adapter.db?.execute ===
            "function");
}
let cachedSqlHelper = null;
async function getDrizzleSql() {
    if (cachedSqlHelper)
        return cachedSqlHelper;
    const drizzle = (await import("drizzle-orm"));
    cachedSqlHelper = drizzle.sql;
    return cachedSqlHelper;
}
function isQueryRow(value) {
    return typeof value === "object" && value !== null;
}
async function executeRawSql(runtime, sqlText) {
    const sql = await getDrizzleSql();
    if (!hasDrizzleDb(runtime.adapter)) {
        throw new Error("Runtime adapter does not expose a Drizzle database");
    }
    const db = runtime.adapter.db;
    const result = await db.execute(sql.raw(sqlText));
    const rows = Array.isArray(result.rows) ? result.rows.filter(isQueryRow) : [];
    const columns = result.fields?.map((f) => f.name) ??
        (rows.length > 0 ? Object.keys(rows[0]) : []);
    return { rows, columns };
}
function parseOptionalPositiveInteger(value, name) {
    if (value === undefined)
        return undefined;
    if (!Number.isSafeInteger(value) || value <= 0) {
        throw new Error(`${name} must be a positive integer`);
    }
    return value;
}
function parseOptionalNonNegativeInteger(value, name) {
    if (value === undefined)
        return undefined;
    if (!Number.isSafeInteger(value) || value < 0) {
        throw new Error(`${name} must be a non-negative integer`);
    }
    return value;
}
// ---------------------------------------------------------------------------
// Vector search category (kept as a separate runtime registration so the
// shared search surface can route to vectors).
// ---------------------------------------------------------------------------
const VECTOR_SEARCH_DEFAULT_TABLE = "messages";
const VECTOR_SEARCH_ALLOWED_TABLES = new Set([
    "messages",
    "memories",
    "facts",
    "documents",
    "document_fragments",
]);
const VECTOR_SEARCH_CATEGORY = {
    category: "vectors",
    label: "Vector store",
    description: "Search semantically similar memory/vector rows.",
    contexts: ["admin", "documents"],
    filters: [
        {
            name: "table",
            label: "Table",
            description: "Memory table to search. Conversation turns use messages. Document content embeddings use document_fragments; documents stores document headers. One of: messages, memories, facts, documents, document_fragments.",
            type: "enum",
            options: [...VECTOR_SEARCH_ALLOWED_TABLES].map((value) => ({
                label: value,
                value,
            })),
        },
        {
            name: "threshold",
            label: "Threshold",
            description: "Minimum similarity threshold from 0 to 1.",
            type: "number",
        },
    ],
    resultSchemaSummary: "VectorSearchHit[] with id, text, similarity, roomId, entityId, createdAt, and tableName.",
    capabilities: ["semantic", "embeddings", "database"],
    source: "agent:database",
};
function hasSearchCategory(runtime, category) {
    try {
        runtime.getSearchCategory(category, { includeDisabled: true });
        return true;
    }
    catch {
        return false;
    }
}
export function registerVectorSearchCategory(runtime) {
    if (!hasSearchCategory(runtime, VECTOR_SEARCH_CATEGORY.category)) {
        runtime.registerSearchCategory(VECTOR_SEARCH_CATEGORY);
    }
}
// ---------------------------------------------------------------------------
// Op handlers
// ---------------------------------------------------------------------------
async function opListTables(runtime, params) {
    const tablesResult = await executeRawSql(runtime, `SELECT
       t.table_schema AS schema,
       t.table_name AS name
     FROM information_schema.tables t
     WHERE t.table_schema NOT IN ('pg_catalog', 'information_schema')
       AND t.table_type = 'BASE TABLE'
     ORDER BY t.table_schema, t.table_name`);
    const columnsResult = await executeRawSql(runtime, `SELECT
       c.table_schema AS schema,
       c.table_name AS table_name,
       c.column_name AS name,
       c.data_type AS type,
       (c.is_nullable = 'YES') AS nullable,
       c.column_default AS default_value,
       COALESCE(
         (SELECT true
          FROM information_schema.table_constraints tc
          JOIN information_schema.key_column_usage kcu
            ON tc.constraint_name = kcu.constraint_name
           AND tc.table_schema = kcu.table_schema
          WHERE tc.constraint_type = 'PRIMARY KEY'
            AND tc.table_schema = c.table_schema
            AND tc.table_name = c.table_name
            AND kcu.column_name = c.column_name),
         false
       ) AS is_primary_key
     FROM information_schema.columns c
     WHERE c.table_schema NOT IN ('pg_catalog', 'information_schema')
     ORDER BY c.table_schema, c.table_name, c.ordinal_position`);
    const columnsByTable = new Map();
    for (const row of columnsResult.rows) {
        const key = JSON.stringify([row.schema, row.table_name]);
        const cols = columnsByTable.get(key) ?? [];
        cols.push({
            name: String(row.name),
            type: String(row.type),
            nullable: Boolean(row.nullable),
            defaultValue: row.default_value != null ? String(row.default_value) : null,
            isPrimaryKey: Boolean(row.is_primary_key),
        });
        columnsByTable.set(key, cols);
    }
    const allTables = tablesResult.rows.map((row) => ({
        name: String(row.name),
        schema: String(row.schema),
    }));
    const filter = params.filter?.trim().toLowerCase() ?? "";
    const includeEmpty = params.includeEmpty ?? true;
    const named = filter
        ? allTables.filter((table) => `${table.schema}.${table.name}`.toLowerCase().includes(filter))
        : allTables;
    // Count the table itself. pg_stat_user_tables.n_live_tup is a statistic: on
    // PGlite it reads 0 for every table after a restart, so it reported full
    // tables as "0 rows" and includeEmpty:false dropped them.
    const counted = [];
    for (const table of named) {
        const countResult = await executeRawSql(runtime, `SELECT count(*) AS total FROM ${qualifiedTable(table.schema, table.name)}`);
        counted.push({
            ...table,
            rowCount: Number(countResult.rows[0]?.total),
            columns: columnsByTable.get(JSON.stringify([table.schema, table.name])) ?? [],
        });
    }
    const tables = includeEmpty
        ? counted
        : counted.filter((table) => table.rowCount > 0);
    const lines = tables.map((t) => `- ${t.schema}.${t.name} (${t.columns.length} cols, ${t.rowCount} rows)`);
    // Both branches used to hide the narrowing above: "No tables found." read as
    // an empty database and "Found 7 table(s)" read as the whole schema while
    // `allTables` held the real count. Name what narrowed it and how to widen.
    const narrowings = [];
    if (filter)
        narrowings.push(`schema or name contains "${filter}"`);
    if (!includeEmpty)
        narrowings.push("includeEmpty:false (zero-row tables dropped)");
    const widen = includeEmpty
        ? "drop the filter"
        : filter
            ? "drop the filter or pass includeEmpty:true"
            : "pass includeEmpty:true";
    const scopeNote = narrowings.length === 0
        ? ""
        : ` (narrowed by ${narrowings.join(" and ")}; ${allTables.length} table(s) exist before filtering — ${widen} to see them all)`;
    return {
        success: true,
        text: lines.length
            ? `Found ${tables.length} table(s)${scopeNote}:\n${lines.join("\n")}`
            : `No tables found${scopeNote}.`,
        values: { count: tables.length, totalBeforeFilter: allTables.length },
        data: {
            actionName: "DATABASE",
            op: "list_tables",
            tables,
            filter,
            includeEmpty,
            totalBeforeFilter: allTables.length,
        },
    };
}
async function resolveGetTableSchema(runtime, tableName, requestedSchema) {
    const parsed = parseRequestedSchema(requestedSchema);
    if (!parsed.ok)
        return {
            ok: false,
            text: "schema must name a non-system database schema.",
            reason: "INVALID_SCHEMA",
        };
    const execute = (query) => executeRawSql(runtime, query);
    const schema = await resolveTableSchema(execute, tableName, parsed.schema);
    if (schema !== null)
        return { ok: true, schema, tableName };
    // Preserve a visible literal dotted name before accepting a simple copied schema.table.
    const qualified = parsed.schema === null
        ? /^([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)$/.exec(tableName)
        : null;
    if (qualified) {
        const namedSchema = await resolveTableSchema(execute, qualified[2], qualified[1]);
        if (namedSchema !== null)
            return { ok: true, schema: namedSchema, tableName: qualified[2] };
    }
    return {
        ok: false,
        text: `Table "${parsed.schema === null ? tableName : `${parsed.schema}.${tableName}`}" not found.`,
        reason: "TABLE_NOT_FOUND",
    };
}
async function opGetTable(runtime, params) {
    const requestedName = params.tableName;
    if (!requestedName) {
        return {
            success: false,
            text: "tableName is required for action=get_table.",
            values: { error: "DATABASE_GET_TABLE_FAILED", reason: "MISSING_TABLE" },
        };
    }
    const resolved = await resolveGetTableSchema(runtime, requestedName, params.schema);
    if (!resolved.ok) {
        return {
            success: false,
            text: resolved.text,
            values: {
                error: "DATABASE_GET_TABLE_FAILED",
                reason: resolved.reason,
            },
        };
    }
    const tableName = resolved.tableName;
    const safe = tableName.replace(/'/g, "''");
    const safeSchema = resolved.schema.replace(/'/g, "''");
    const relation = qualifiedTable(resolved.schema, tableName);
    const limit = parseOptionalPositiveInteger(params.limit, "limit");
    const offset = parseOptionalNonNegativeInteger(params.offset, "offset") ?? 0;
    const sortDir = params.sortDir === "desc" ? "DESC" : "ASC";
    let validSort = "";
    if (params.sortBy) {
        const cols = await executeRawSql(runtime, `SELECT column_name FROM information_schema.columns
       WHERE table_name = '${safe}'
         AND table_schema = '${safeSchema}'
       ORDER BY ordinal_position`);
        const columnNames = cols.rows.map((r) => String(r.column_name));
        // An unknown sort column used to be dropped, and the rows came back in
        // primary-key order under a success text.
        if (!columnNames.includes(params.sortBy)) {
            return {
                success: false,
                text: `sortBy "${params.sortBy}" is not a column of "${resolved.schema}.${tableName}". Columns: ${columnNames.join(", ")}.`,
                values: {
                    error: "DATABASE_GET_TABLE_FAILED",
                    reason: "UNKNOWN_SORT_COLUMN",
                },
            };
        }
        validSort = params.sortBy;
    }
    // OFFSET pages are separate queries. A sort column with ties, or no sort,
    // lets rows trade places between pages. The primary key makes the order
    // total. The probe uses the same relation an unqualified FROM resolves: a
    // same-named table in another schema would otherwise add columns this read
    // does not have. A table with no primary key falls back to its physical row id.
    const pkResult = await executeRawSql(runtime, `SELECT kcu.column_name
     FROM information_schema.table_constraints tc
     JOIN information_schema.key_column_usage kcu
       ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
      AND tc.table_name = kcu.table_name
     WHERE tc.constraint_type = 'PRIMARY KEY'
       AND tc.table_name = '${safe}'
       AND tc.table_schema = '${safeSchema}'
     ORDER BY kcu.ordinal_position`);
    const primaryKey = [];
    for (const row of pkResult.rows) {
        const name = String(row.column_name ?? "");
        if (name.length > 0 && !primaryKey.includes(name))
            primaryKey.push(name);
    }
    const tieBreak = primaryKey.length
        ? primaryKey.map((column) => quoteIdent(column))
        : ["tableoid", "ctid"];
    const orderTerms = [
        ...(validSort ? [quoteIdent(validSort)] : []),
        ...tieBreak.filter((term) => !validSort || term !== quoteIdent(validSort)),
    ].map((term) => `${term} ${sortDir}`);
    const orderClause = `ORDER BY ${orderTerms.join(", ")}`;
    const countResult = await executeRawSql(runtime, `SELECT count(*) AS total FROM ${relation}`);
    const total = Number(countResult.rows[0]?.total ?? 0);
    const result = await executeRawSql(runtime, `SELECT * FROM ${relation} ${orderClause}${limit === undefined ? "" : ` LIMIT ${limit}`}${offset === 0 ? "" : ` OFFSET ${offset}`}`);
    const qualifiedName = `${resolved.schema}.${tableName}`;
    return {
        success: true,
        text: `Returned ${result.rows.length} row(s) from "${qualifiedName}" (total: ${total}).`,
        values: { rowCount: result.rows.length, total },
        data: {
            actionName: "DATABASE",
            op: "get_table",
            tableName,
            schema: resolved.schema,
            rows: result.rows,
            columns: result.columns,
            total,
            offset,
            ...(limit === undefined ? {} : { limit }),
            ...(validSort
                ? { sortBy: validSort, sortDir: sortDir === "DESC" ? "desc" : "asc" }
                : {}),
        },
    };
}
async function opQuery(runtime, params) {
    const sqlText = params.sql?.trim();
    if (!sqlText) {
        return {
            success: false,
            text: "sql is required for action=query.",
            values: { error: "DATABASE_QUERY_FAILED", reason: "MISSING_SQL" },
        };
    }
    const allowWrites = params.allowWrites === true;
    if (!allowWrites) {
        const guard = checkReadOnly(sqlText);
        if (!guard.ok) {
            const reason = "reason" in guard ? guard.reason : "not read-only";
            return {
                success: false,
                text: `Query rejected: ${reason}`,
                values: { error: "DATABASE_QUERY_FAILED", reason: "MUTATION_BLOCKED" },
                data: { actionName: "DATABASE", op: "query" },
            };
        }
    }
    const start = Date.now();
    const result = await executeRawSql(runtime, sqlText);
    const durationMs = Date.now() - start;
    return {
        success: true,
        text: `Query returned ${result.rows.length} row(s) in ${durationMs}ms.`,
        values: { rowCount: result.rows.length, allowWrites, durationMs },
        data: {
            actionName: "DATABASE",
            op: "query",
            result: {
                columns: result.columns,
                rows: result.rows,
                rowCount: result.rows.length,
                durationMs,
            },
        },
    };
}
async function opSearchVectors(runtime, params) {
    registerVectorSearchCategory(runtime);
    const query = params.query?.trim();
    if (!query) {
        return {
            success: false,
            text: "query is required for action=search_vectors.",
            values: {
                error: "DATABASE_SEARCH_VECTORS_FAILED",
                reason: "MISSING_QUERY",
            },
        };
    }
    const table = params.table?.trim() || VECTOR_SEARCH_DEFAULT_TABLE;
    if (!VECTOR_SEARCH_ALLOWED_TABLES.has(table)) {
        return {
            success: false,
            text: `table "${table}" is not searchable. Allowed: ${[...VECTOR_SEARCH_ALLOWED_TABLES].join(", ")}.`,
            values: {
                error: "DATABASE_SEARCH_VECTORS_FAILED",
                reason: "TABLE_NOT_ALLOWED",
            },
        };
    }
    if (params.limit === undefined) {
        return {
            success: false,
            text: "limit is required for vector search because top-k retrieval must be explicitly requested.",
            values: {
                error: "DATABASE_SEARCH_VECTORS_FAILED",
                reason: "MISSING_EXPLICIT_LIMIT",
            },
        };
    }
    const limit = parseOptionalPositiveInteger(params.limit, "limit");
    if (limit === undefined) {
        throw new Error("limit validation failed");
    }
    const embeddingResult = await runtime.useModel(ModelType.TEXT_EMBEDDING, {
        text: query,
    });
    const embedding = Array.isArray(embeddingResult)
        ? embeddingResult
        : (embeddingResult?.embedding ?? null);
    if (!embedding || embedding.length === 0) {
        return {
            success: false,
            text: "Embedding model returned no vector.",
            values: {
                error: "DATABASE_SEARCH_VECTORS_FAILED",
                reason: "NO_EMBEDDING",
            },
        };
    }
    const matches = await runtime.searchMemories({
        embedding,
        // Intentionally NO `query` here. Passing `query` makes runtime.searchMemories
        // pipe the vector hits through rerankMemories → BM25, which DROPS every
        // candidate with zero stemmed-keyword overlap (search.ts: `if (score <= 0)
        // continue`). That turns "rerank" into a keyword FILTER: a semantic search
        // like "automobile purchase" returns nothing for a stored "I bought a new
        // car", and attachment-only memories (no content.text) are always dropped —
        // defeating the whole point of a vector search. This IS a vector search, so
        // the adapter's cosine-similarity order is authoritative. Mirrors the same
        // deliberate omission in core/features/documents/service.ts, which documents
        // this exact trap.
        tableName: table,
        limit,
        ...(typeof params.threshold === "number"
            ? { match_threshold: params.threshold }
            : {}),
    });
    const results = matches.map((m) => {
        const content = m.content;
        return {
            id: m.id ?? null,
            text: content?.text ?? "",
            similarity: m.similarity ?? null,
            roomId: m.roomId,
            entityId: m.entityId,
            createdAt: m.createdAt ?? null,
            tableName: table,
        };
    });
    const lines = results.map((hit, i) => {
        const score = typeof hit.similarity === "number" ? hit.similarity.toFixed(3) : "n/a";
        const snippet = toWellFormedUnicode(hit.text).replace(/\s+/g, " ");
        return `${i + 1}. [${score}] ${snippet}`;
    });
    return {
        success: true,
        text: results.length === 0
            ? `No matches for "${query}" in ${table}.`
            : [`Top ${results.length} match(es) in ${table}:`, ...lines].join("\n"),
        values: { count: results.length, table },
        data: {
            actionName: "DATABASE",
            op: "search_vectors",
            query,
            table,
            limit,
            results,
        },
    };
}
// ---------------------------------------------------------------------------
// Action
// ---------------------------------------------------------------------------
async function databaseHandler(runtime, options) {
    const params = getParams(options);
    const op = params.action ?? params.subaction ?? params.op;
    if (!isDatabaseOp(op)) {
        return {
            success: false,
            text: `action is required and must be one of: ${DATABASE_OPS.join(", ")}.`,
            values: {
                error: "DATABASE_INVALID",
                received: typeof op === "string" ? op : null,
            },
        };
    }
    try {
        switch (op) {
            case "list_tables":
                return await opListTables(runtime, params);
            case "get_table":
                return await opGetTable(runtime, params);
            case "query":
                return await opQuery(runtime, params);
            case "search_vectors":
                return await opSearchVectors(runtime, params);
        }
    }
    catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        logger.warn(`[DATABASE] op=${op} failed: ${msg}`);
        return {
            success: false,
            text: `DATABASE op "${op}" failed: ${msg}`,
            values: { error: `DATABASE_${op.toUpperCase()}_FAILED` },
        };
    }
}
export const databaseAction = {
    name: "DATABASE",
    contexts: ["admin", "agent_internal", "documents", "memory"],
    roleGate: { minRole: "OWNER" },
    similes: [
        // Old leaf action names (kept so older inbound callers still resolve)
        "LIST_DATABASE_TABLES",
        "GET_TABLE_DATA",
        "EXECUTE_DATABASE_QUERY",
        "SEARCH_VECTORS",
        // Common aliases
        "LIST_TABLES",
        "SHOW_TABLES",
        "DB_TABLES",
        "READ_TABLE",
        "SELECT_TABLE",
        "BROWSE_TABLE",
        "RUN_QUERY",
        "SQL_QUERY",
        "DB_QUERY",
        "VECTOR_SEARCH",
        "EMBEDDING_SEARCH",
        "SIMILARITY_SEARCH",
    ],
    description: "Inspect or query the agent's database. Ops: list_tables, get_table, query (read-only by default), search_vectors (semantic memory search).",
    descriptionCompressed: "database list_tables|get_table|query(read-only default)|search_vectors",
    routingHint: "inspect the agent's RAW database — list/read tables, run read-only SQL, or vector/similarity search over stored rows -> DATABASE; for the agent's own conversational memory records about the user -> MEMORY (action=search); for the user's stored files -> FILES; for open-web lookups -> WEB_SEARCH. NEVER use DATABASE to take, store, or read a NOTE for the user ('make a note', 'note to self', 'what notes do i have') — notes are memory records and belong to MEMORY; hand-written INSERTs against the memories table fail on schema mismatch and lose the user's note.",
    validate: async (runtime) => {
        registerVectorSearchCategory(runtime);
        return true;
    },
    handler: async (runtime, _message, _state, options) => databaseHandler(runtime, options),
    parameters: [
        {
            name: "action",
            description: `Action to perform. One of: ${DATABASE_OPS.join(", ")}.`,
            required: true,
            schema: { type: "string", enum: [...DATABASE_OPS] },
        },
        {
            name: "filter",
            description: "list_tables: case-insensitive substring on schema.table or the table name.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "includeEmpty",
            description: "list_tables: include zero-row tables (default true).",
            required: false,
            schema: { type: "boolean", default: true },
        },
        {
            name: "tableName",
            description: "get_table: table name, or schema.table copied from list_tables.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "schema",
            description: "get_table: schema that owns the table. Required when the same name exists in more than one schema. Plugin tables such as todos.todos are outside search_path.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "limit",
            description: "get_table: optional positive integer page size; omit to return the complete table. search_vectors: required positive integer top-k requested by the caller.",
            required: false,
            schema: { type: "number" },
        },
        {
            name: "offset",
            description: "get_table: row offset for pagination.",
            required: false,
            schema: { type: "number" },
        },
        {
            name: "sortBy",
            description: "get_table: column name to sort by.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "sortDir",
            description: "get_table: sort direction.",
            required: false,
            schema: { type: "string", enum: ["asc", "desc"] },
        },
        {
            name: "sql",
            description: "query: SQL text. Read-only unless allowWrites:true.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "allowWrites",
            description: "query: permit mutations (INSERT/UPDATE/DELETE/DDL).",
            required: false,
            schema: { type: "boolean", default: false },
        },
        {
            name: "query",
            description: "search_vectors: text to embed and search.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "table",
            description: "search_vectors: memory table. Use messages for conversation turns and document_fragments for document content embeddings; documents contains headers. Tables: messages, memories, facts, documents, document_fragments.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "threshold",
            description: "search_vectors: minimum similarity (0-1).",
            required: false,
            schema: { type: "number" },
        },
    ],
    examples: [
        [
            {
                name: "{{name1}}",
                content: { text: "What tables are in your database?" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Found N table(s)...",
                    action: "DATABASE",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Run SELECT count(*) FROM memories" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Query returned 1 row(s).",
                    action: "DATABASE",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Find memories similar to 'birthday plans'." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Top match(es)...",
                    action: "DATABASE",
                },
            },
        ],
    ],
};
