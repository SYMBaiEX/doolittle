/**
 * Polymorphic DATABASE action.
 *
 * Single action that dispatches across the database introspection ops:
 *   - list_tables    : enumerate user tables with row counts and columns.
 *   - get_table      : page rows from a specific table (limit/offset/sort).
 *   - query          : execute raw SQL (read-only by default).
 *   - search_vectors : embed text and return top-k semantic memory matches.
 *
 * All ops talk directly to the in-process runtime adapter (Drizzle ORM via
 * `runtime.adapter.db`) and `runtime.searchMemories` / `runtime.useModel`.
 * No HTTP. The previous LIST_DATABASE_TABLES / GET_TABLE_DATA /
 * EXECUTE_DATABASE_QUERY / SEARCH_VECTORS actions hit /api/database/* — that
 * server route layer is still used by the dashboard UI but is now bypassed
 * for the agent's own tool surface.
 */
import { type Action, type IAgentRuntime } from "@elizaos/core";
export declare function registerVectorSearchCategory(runtime: IAgentRuntime): void;
export declare const databaseAction: Action;
