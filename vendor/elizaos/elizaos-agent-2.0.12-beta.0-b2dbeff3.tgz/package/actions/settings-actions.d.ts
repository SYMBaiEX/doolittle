/**
 * Applies owner-authorized provider, capability, identity, backend routing,
 * and world-settings updates from structured action parameters.
 */
import { type Action, type IAgentRuntime } from "@elizaos/core";
export declare const SETTINGS_OPS: readonly ["update_ai_provider", "toggle_capability", "set_owner_name", "set", "show_backends", "set_backend"];
export type SettingsOp = (typeof SETTINGS_OPS)[number];
export declare function trimToString(value: unknown, max: number): string | undefined;
interface CodingAxisRouting {
    default?: string;
    byTag?: Record<string, string>;
    /** Operator lock-list constraining every resolved backend (orchestrator-side). */
    allow?: string[];
}
export declare function normalizeCodingBackend(value: unknown): string | undefined;
export declare function readBackendRouting(config: {
    env?: Record<string, unknown>;
}): CodingAxisRouting;
export declare function hasLoadedTextProvider(runtime: IAgentRuntime, provider: string): boolean;
export declare const settingsAction: Action;
export {};
