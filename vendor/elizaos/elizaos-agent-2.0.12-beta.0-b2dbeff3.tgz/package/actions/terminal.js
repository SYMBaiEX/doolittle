/**
 * Executes one explicit shell command through the local terminal API and
 * converts its bounded output into planner-visible data and an attachment.
 * Every dispatch carries a fresh run identity; transport ambiguity preserves
 * that identity so callers can reconcile the effect instead of retrying it.
 */
import { createHash, randomUUID } from "node:crypto";
import { buildReadView, ContentType, ElizaError, logger, redactSensitiveText, stringToUuid, } from "@elizaos/core";
import { buildStoreVariantBlockedMessage, isLocalCodeExecutionAllowed, } from "@elizaos/host";
import { readAliasedEnv, resolveSelfApiBaseUrl } from "@elizaos/host/protocol";
import { capturedTerminalOutputIsSafe, TERMINAL_REJECTIONS, } from "../api/terminal-output-contract.js";
import { resolveTerminalRunLimits } from "../api/terminal-run-limits.js";
import { normalizeTerminalCommand } from "../utils/terminal-command.js";
const TERMINAL_ACTION_NAME = "TERMINAL_SHELL";
const TERMINAL_TRANSPORT_GRACE_MS = 10_000;
// Four MiB of control-heavy output can expand to six JSON bytes per source
// byte. Bound the envelope before parsing while preserving the route's exact
// complete-output contract.
const MAX_TERMINAL_RESPONSE_BYTES = 25 * 1024 * 1024;
function callerAbortSignal(options) {
    const signal = options?.abortSignal;
    return signal instanceof AbortSignal ? signal : undefined;
}
/** @internal Exported for deterministic transport-boundary tests. */
export function resolveTerminalTransportTimeoutMs() {
    return resolveTerminalRunLimits().maxDurationMs + TERMINAL_TRANSPORT_GRACE_MS;
}
async function cancelResponseBody(body, reason) {
    if (!body)
        return;
    try {
        await body.cancel(reason);
    }
    catch (error) {
        // error-policy:J6 response cancellation is teardown-only; the original
        // bounded-read failure remains authoritative.
        logger.warn({ error }, "[terminal] Failed to cancel response body");
    }
}
async function readTerminalResponseJson(response, signal) {
    const declaredLength = response.headers.get("content-length");
    if (declaredLength !== null) {
        if (!/^\d+$/u.test(declaredLength)) {
            await cancelResponseBody(response.body, "Terminal response had an invalid Content-Length");
            throw new ElizaError("Terminal response had an invalid Content-Length", {
                code: "TERMINAL_RESPONSE_INVALID",
                severity: "fatal",
            });
        }
        if (Number(declaredLength) > MAX_TERMINAL_RESPONSE_BYTES) {
            await cancelResponseBody(response.body, "Terminal response exceeded the byte limit");
            throw new ElizaError("Terminal response exceeded the byte limit", {
                code: "TERMINAL_RESPONSE_INVALID",
                severity: "fatal",
            });
        }
    }
    if (!response.body) {
        throw new ElizaError("Terminal response omitted its body", {
            code: "TERMINAL_RESPONSE_INVALID",
            severity: "fatal",
        });
    }
    const reader = response.body.getReader();
    const chunks = [];
    let totalBytes = 0;
    let onAbort;
    const aborted = new Promise((_resolve, reject) => {
        onAbort = () => {
            reject(signal.reason ??
                new DOMException("Terminal request aborted", "AbortError"));
        };
        signal.addEventListener("abort", onAbort, { once: true });
    });
    try {
        signal.throwIfAborted();
        while (true) {
            const { done, value } = await Promise.race([reader.read(), aborted]);
            if (done)
                break;
            if (!value || value.byteLength === 0)
                continue;
            totalBytes += value.byteLength;
            if (totalBytes > MAX_TERMINAL_RESPONSE_BYTES) {
                await reader.cancel("Terminal response exceeded the byte limit");
                throw new ElizaError("Terminal response exceeded the byte limit", {
                    code: "TERMINAL_RESPONSE_INVALID",
                    severity: "fatal",
                });
            }
            chunks.push(value);
        }
    }
    catch (error) {
        if (signal.aborted) {
            try {
                await reader.cancel(signal.reason);
            }
            catch (cancelError) {
                // error-policy:J6 response cancellation is teardown-only; preserve the
                // caller or transport abort reason.
                logger.warn({ error: cancelError }, "[terminal] Failed to cancel aborted response body");
            }
            throw signal.reason ?? error;
        }
        throw error;
    }
    finally {
        if (onAbort)
            signal.removeEventListener("abort", onAbort);
        reader.releaseLock();
    }
    let text;
    try {
        const bytes = new Uint8Array(totalBytes);
        let offset = 0;
        for (const chunk of chunks) {
            bytes.set(chunk, offset);
            offset += chunk.byteLength;
        }
        text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    }
    catch (error) {
        // error-policy:J2 malformed transport bytes become a typed boundary error.
        throw new ElizaError("Terminal response was not valid UTF-8", {
            code: "TERMINAL_RESPONSE_INVALID",
            cause: error,
            severity: "fatal",
        });
    }
    try {
        return JSON.parse(text);
    }
    catch (error) {
        // error-policy:J2 the terminal boundary requires a structured response;
        // preserve the parser error for the runtime's action failure channel.
        throw new ElizaError("Terminal execution response was not valid JSON", {
            code: "TERMINAL_RESPONSE_INVALID",
            cause: error,
            severity: "fatal",
        });
    }
}
function readStringValue(value) {
    return typeof value === "string" && value.trim() ? value.trim() : undefined;
}
function isJsonRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function hasNestedExecutionEnvelope(value) {
    for (const key of ["data", "result", "output"]) {
        if (isJsonRecord(value[key]))
            return true;
    }
    return false;
}
function parseJsonArguments(value) {
    if (typeof value !== "string" || !value.trim()) {
        return undefined;
    }
    try {
        const parsed = JSON.parse(value);
        if (isJsonRecord(parsed)) {
            return parsed;
        }
    }
    catch {
        // error-policy:J3 planner arguments are untrusted input. Invalid JSON is
        // treated as an absent wrapper so the explicit typed parameters still win.
    }
    return undefined;
}
/**
 * Extract a command from handler options and message text.
 *
 * Resolution order:
 *   1. `parameters.command` — explicit parameter
 *   2. `parameters.shellCommand` — explicit alias
 *   3. `parameters.arguments` — MCP-style JSON string like `{"command":"ls"}`
 */
function getCommand(options) {
    const params = (options?.parameters ?? {});
    const argumentParams = parseJsonArguments(params.arguments);
    // The planner must extract the command as an explicit `command` param.
    // We intentionally do not fall back to regex-scraping the message text or
    // keyword-matching the request for hardcoded commands ("free -h" for
    // "memory", etc.) — that would be intent classification in the handler
    // instead of in the LLM planner, which bypasses the LLM's judgment on
    // safety, scope, and argument construction.
    return (readStringValue(params.command) ??
        readStringValue(params.shellCommand) ??
        readStringValue(argumentParams?.command) ??
        readStringValue(argumentParams?.shellCommand));
}
function resolveTerminalInput(options) {
    const command = getCommand(options);
    return {
        command: command ? normalizeTerminalCommand(command) : undefined,
    };
}
function normalizeCapturedRun(command, value, expectedRunId) {
    if (!isJsonRecord(value)) {
        throw new ElizaError("Terminal response was not an object", {
            code: "TERMINAL_RESPONSE_INVALID",
            severity: "fatal",
        });
    }
    const runId = readStringValue(value.runId);
    if (value.ok !== true ||
        !runId ||
        (expectedRunId !== undefined && runId !== expectedRunId) ||
        typeof value.exitCode !== "number" ||
        !Number.isSafeInteger(value.exitCode) ||
        typeof value.stdout !== "string" ||
        typeof value.stderr !== "string" ||
        typeof value.timedOut !== "boolean" ||
        typeof value.truncated !== "boolean" ||
        "error" in value ||
        !capturedTerminalOutputIsSafe(value.stdout, value.stderr) ||
        (value.maxDurationMs !== undefined &&
            (typeof value.maxDurationMs !== "number" ||
                !Number.isSafeInteger(value.maxDurationMs) ||
                value.maxDurationMs < 1))) {
        throw new ElizaError("Terminal response omitted required execution proof", {
            code: "TERMINAL_RESPONSE_INVALID",
            context: {
                hasRunId: Boolean(runId),
                ...(expectedRunId !== undefined
                    ? { expectedRunId, receivedRunId: runId }
                    : {}),
                hasExitCode: typeof value.exitCode === "number" &&
                    Number.isInteger(value.exitCode),
            },
            severity: "fatal",
        });
    }
    if (value.truncated !== false || hasNestedExecutionEnvelope(value)) {
        throw new ElizaError("Terminal response contained incomplete stdout or stderr", {
            code: "TERMINAL_OUTPUT_INCOMPLETE",
            context: { acceptance: "accepted", runId },
            severity: "fatal",
        });
    }
    if (value.timedOut) {
        throw new ElizaError("Terminal response timed out before complete output was proven", {
            code: "TERMINAL_OUTPUT_INCOMPLETE",
            context: { acceptance: "accepted", runId },
            severity: "fatal",
        });
    }
    return {
        command,
        runId,
        exitCode: value.exitCode,
        stdout: value.stdout,
        stderr: value.stderr,
        timedOut: value.timedOut,
        truncated: false,
        maxDurationMs: typeof value.maxDurationMs === "number" &&
            Number.isFinite(value.maxDurationMs)
            ? value.maxDurationMs
            : undefined,
    };
}
function formatOutputBlock(content) {
    return content.trimEnd() || "(empty)";
}
function buildCommandArtifactContent(result) {
    return [
        `Command: ${result.command}`,
        `Exit code: ${result.exitCode}`,
        result.timedOut
            ? `Timed out: yes${typeof result.maxDurationMs === "number" ? ` (${result.maxDurationMs} ms limit)` : ""}`
            : "Timed out: no",
        "",
        "STDOUT:",
        formatOutputBlock(result.stdout),
        "",
        "STDERR:",
        formatOutputBlock(result.stderr),
    ]
        .filter(Boolean)
        .join("\n");
}
function terminalAttachmentReadView(outputAttachment) {
    if (!outputAttachment?.memoryId)
        return undefined;
    const content = outputAttachment.attachment.text ?? "";
    const byteLength = Buffer.byteLength(content);
    const digest = createHash("sha256").update(content).digest("hex");
    return buildReadView({
        reference: {
            kind: "attachment",
            ref: outputAttachment.attachment.id,
            revision: outputAttachment.memoryId,
        },
        slice: {
            range: {
                unit: "byte",
                start: 0,
                end: byteLength,
                total: byteLength,
            },
            hasPrevious: false,
            hasMore: false,
            revision: outputAttachment.memoryId,
            completeness: "complete",
            sliceSha256: digest,
            sourceSha256: digest,
        },
    });
}
/** @internal Exported for deterministic boundary tests. */
export function completeOutputBlock(content) {
    return formatOutputBlock(content.trimEnd());
}
/** @internal Exported for deterministic boundary tests. */
export function normalizeTerminalOutput(text) {
    return text;
}
async function createCommandOutputAttachment(runtime, message, result) {
    if (!runtime?.createMemory) {
        return undefined;
    }
    const attachmentId = stringToUuid(`terminal-output:${message.id ?? message.roomId}:${result.runId}:${Date.now()}`);
    const title = `Shell output: ${result.command}`;
    const attachment = {
        id: attachmentId,
        url: `memory://terminal-output/${attachmentId}`,
        title,
        source: TERMINAL_ACTION_NAME,
        description: `Complete captured stdout/stderr for \`${result.command}\` (exit ${result.exitCode}).`,
        text: buildCommandArtifactContent(result),
        contentType: ContentType.DOCUMENT,
    };
    try {
        const memoryId = await runtime.createMemory({
            id: stringToUuid(`terminal-output-memory:${attachmentId}`),
            entityId: runtime.agentId,
            agentId: runtime.agentId,
            roomId: message.roomId,
            createdAt: Date.now(),
            content: {
                text: `Stored terminal output attachment ${attachment.id}: ${attachment.title}`,
                source: TERMINAL_ACTION_NAME,
                attachments: [attachment],
            },
        }, "messages");
        return { attachment, memoryId };
    }
    catch (error) {
        // error-policy:J4 the execution result and inline output remain explicit
        // while attachment persistence degrades to an unpersisted attachment.
        logger.warn(`[terminal] Failed to store shell output attachment (${error instanceof Error ? error.message : String(error)})`);
        return { attachment };
    }
}
function terminalEffectReceipt(result, outputAttachment, observedAt) {
    const base = {
        receiptId: `terminal-run:${result.runId}`,
        operation: "system.shell.execute",
        resource: { kind: "terminal.run", id: result.runId },
        artifacts: outputAttachment
            ? [
                {
                    kind: "terminal.output",
                    id: outputAttachment.attachment.id,
                    ...(outputAttachment.memoryId
                        ? { version: outputAttachment.memoryId }
                        : {}),
                },
            ]
            : [],
        idempotency: { key: result.runId, replayed: false },
        observedAt,
    };
    if (result.exitCode === 0 && !result.timedOut) {
        return {
            ...base,
            outcome: "applied",
            commit: {
                kind: "provider_accepted",
                id: result.runId,
                committedAt: observedAt,
            },
        };
    }
    return {
        ...base,
        outcome: "failed",
        failure: {
            code: result.timedOut
                ? "TERMINAL_EXECUTION_TIMED_OUT"
                : "TERMINAL_EXECUTION_FAILED",
            retryable: false,
            acceptance: result.timedOut ? "unknown" : "rejected",
        },
    };
}
/**
 * One projection boundary for every terminal consumer: runtime-known secrets
 * first (character-configured values), then shape-based tools redaction
 * (Bearer, CLI flags, URI userinfo, token prefixes). Lightweight/test runtimes
 * may stub `redactSecrets` as identity, so the pattern pass remains required.
 */
function redactCapturedTerminalText(runtime, text) {
    return redactSensitiveText(runtime.redactSecrets(text), { mode: "tools" });
}
function buildCapturedResponseText(result, outputAttachment) {
    const outputContent = buildCommandArtifactContent(result);
    return [
        `Shell command completed: \`${result.command}\``,
        `Exit code: ${result.exitCode}`,
        result.timedOut
            ? `Timed out${typeof result.maxDurationMs === "number" ? ` after ${result.maxDurationMs} ms` : ""}.`
            : "",
        outputAttachment
            ? `Full output attachment: ${outputAttachment.attachment.id} (${outputAttachment.attachment.title})`
            : "",
        outputAttachment?.memoryId
            ? `Attachment memory: ${outputAttachment.memoryId}`
            : outputAttachment
                ? "Attachment memory could not be persisted; full output is still present in this action result."
                : "No attachment was stored for this output.",
        "",
        "Output preview:",
        completeOutputBlock(outputContent),
        "",
        "Next-step contract for the planner:",
        "- Decide whether to reply to the user, stay silent, or continue with another action.",
        "- If the output should be kept for this task, call SAVE_ATTACHMENT_TO_CLIPBOARD with the attachmentId above.",
        "- If replying, answer naturally from the output instead of echoing this report.",
    ]
        .filter(Boolean)
        .join("\n");
}
export const terminalAction = {
    name: TERMINAL_ACTION_NAME,
    contexts: ["terminal", "code", "files", "admin"],
    roleGate: { minRole: "OWNER" },
    // Declared shell-direct behavior class (see SHELL_DIRECT_ACTION_TAGS in
    // core/services/message/direct-action-heuristics). The core message pipeline
    // resolves shell-direct routing/termination off these tags first, so this
    // action can rename itself without breaking the pipeline; the legacy name/
    // simile list remains only as a covered compatibility fallback.
    tags: [
        "domain:system",
        "resource:shell",
        "capability:execute",
        "effect:receipt-required",
    ],
    similes: ["RUN_IN_TERMINAL", "EXECUTE_COMMAND", "TERMINAL", "RUN_SHELL"],
    description: "Run a single explicit shell command that the user provided directly. " +
        "Only use when the user gives a specific command like 'run ls -la' or 'execute npm install'. " +
        "Do NOT use for building projects, creating websites, or multi-step work — discover the appropriate coding-task action instead. " +
        "The command must be one line (maximum 4096 characters), with no literal newline, carriage return or NUL; use escaped newlines or coding tools for scripts. " +
        "The command output is captured as a document attachment for native planner follow-up. After the run, decide whether to reply, stay silent, continue with another action, or save the attachment via the clipboard plugin.",
    descriptionCompressed: "run one explicit shell command; discover coding-task actions for multi-step development",
    routingHint: "run ONE explicit user-provided command and capture its output as an attachment in the terminal view -> TERMINAL_SHELL; general shell/build/history or scripted commands -> SHELL (coding-tools); multi-step dev work -> discover coding-task actions; MCP tools -> MCP",
    validate: async () => isLocalCodeExecutionAllowed(),
    handler: async (runtime, message, _state, options) => {
        if (!isLocalCodeExecutionAllowed()) {
            return {
                success: false,
                text: buildStoreVariantBlockedMessage("Terminal commands"),
                data: {
                    actionName: TERMINAL_ACTION_NAME,
                    suppressPostActionContinuation: true,
                    terminal: { storeBuildBlocked: true },
                },
            };
        }
        const input = resolveTerminalInput(options);
        const command = input.command;
        if (!command) {
            return {
                success: false,
                text: "A non-empty shell command is required.",
                error: "TERMINAL_COMMAND_REQUIRED",
            };
        }
        const terminalToken = readAliasedEnv("ELIZA_TERMINAL_RUN_TOKEN");
        const headers = {
            "Content-Type": "application/json",
        };
        if (terminalToken) {
            headers["X-Eliza-Terminal-Token"] = terminalToken;
        }
        const runId = `run-${randomUUID()}`;
        headers["X-Eliza-Terminal-Run-Id"] = runId;
        const callerSignal = callerAbortSignal(options);
        callerSignal?.throwIfAborted();
        const transportTimeoutMs = resolveTerminalTransportTimeoutMs();
        const transportSignal = AbortSignal.timeout(transportTimeoutMs);
        const requestSignal = callerSignal
            ? AbortSignal.any([callerSignal, transportSignal])
            : transportSignal;
        let response;
        try {
            response = await fetch(`${resolveSelfApiBaseUrl(process.env)}/api/terminal/run`, {
                method: "POST",
                headers,
                body: JSON.stringify({
                    command,
                    clientId: "runtime-terminal-action",
                    captureOutput: true,
                    ...(terminalToken ? { terminalToken } : {}),
                }),
                signal: requestSignal,
            });
        }
        catch (error) {
            // error-policy:J2 once dispatch begins, a transport failure cannot prove
            // whether the server accepted the command. Preserve the client-selected
            // run identity so the caller can reconcile the operation before retrying.
            throw new ElizaError("Terminal execution outcome is unknown", {
                code: "TERMINAL_REQUEST_OUTCOME_UNKNOWN",
                context: {
                    acceptance: "unknown",
                    runId,
                    transportTimeoutMs,
                },
                cause: error,
                severity: "fatal",
            });
        }
        if (!response.ok) {
            // Trust only the host's typed pre-dispatch contract, never raw error prose.
            // Untyped/proxy errors can follow an accepted command: retain its identity
            // and forbid automatic retry until the effect has been reconciled.
            let rejected;
            try {
                rejected = await readTerminalResponseJson(response, requestSignal);
            }
            catch {
                // A malformed rejection cannot prove non-execution. Fall through to the
                // typed unknown-outcome failure below, preserving the run ID for reconciliation.
                rejected = null;
            }
            callerSignal?.throwIfAborted();
            if (rejected &&
                typeof rejected === "object" &&
                !Array.isArray(rejected) &&
                typeof rejected.code === "string" &&
                Object.hasOwn(TERMINAL_REJECTIONS, rejected.code) &&
                rejected.acceptance === "rejected" &&
                rejected.executionStatus === "not_started") {
                const code = rejected.code;
                const definition = TERMINAL_REJECTIONS[code];
                const statusMatches = response.status === definition.status ||
                    (code === "TERMINAL_AUTHORIZATION_REQUIRED" &&
                        response.status === 401);
                if (statusMatches)
                    return {
                        success: false,
                        error: code,
                        text: definition.message,
                        modelReplyRequired: true,
                        failureProvenance: {
                            kind: "handler_error",
                            boundary: "handler",
                            code,
                            retryable: definition.retryable,
                        },
                        data: {
                            actionName: TERMINAL_ACTION_NAME,
                            runId,
                            status: response.status,
                            acceptance: "rejected",
                            executionStatus: "not_started",
                        },
                    };
            }
            throw new ElizaError("Terminal execution outcome is unknown; reconcile the run before retrying", {
                code: "TERMINAL_REQUEST_OUTCOME_UNKNOWN",
                context: {
                    status: response.status,
                    acceptance: "unknown",
                    executionStatus: "unknown",
                    runId,
                },
                severity: "fatal",
            });
        }
        let responseBody;
        try {
            responseBody = await readTerminalResponseJson(response, requestSignal);
        }
        catch (error) {
            // error-policy:J2 an accepted request with an unreadable, cancelled, or
            // malformed result may already have executed. Bind every such ambiguity
            // to the dispatched run identity instead of presenting a safe retry.
            throw new ElizaError("Terminal execution outcome is unknown", {
                code: "TERMINAL_REQUEST_OUTCOME_UNKNOWN",
                context: {
                    acceptance: "unknown",
                    runId,
                    transportTimeoutMs,
                },
                cause: error,
                severity: "fatal",
            });
        }
        let rawRun;
        try {
            rawRun = normalizeCapturedRun(command, responseBody, runId);
        }
        catch (error) {
            if (error instanceof ElizaError &&
                error.code === "TERMINAL_OUTPUT_INCOMPLETE") {
                throw error;
            }
            // error-policy:J2 a 2xx body that cannot prove the bound run's terminal
            // result is still an ambiguous effect, not a safely retryable parse error.
            throw new ElizaError("Terminal execution outcome is unknown", {
                code: "TERMINAL_REQUEST_OUTCOME_UNKNOWN",
                context: {
                    acceptance: "unknown",
                    runId,
                    transportTimeoutMs,
                },
                cause: error,
                severity: "fatal",
            });
        }
        // Sanitize once before constructing model text, bounded action data, the
        // user-facing relay, attachments, or persisted attachment memory.
        const capturedRun = {
            ...rawRun,
            command: redactCapturedTerminalText(runtime, rawRun.command),
            stdout: redactCapturedTerminalText(runtime, rawRun.stdout),
            stderr: redactCapturedTerminalText(runtime, rawRun.stderr),
        };
        const completeRun = {
            ...capturedRun,
            stdout: normalizeTerminalOutput(capturedRun.stdout),
            stderr: normalizeTerminalOutput(capturedRun.stderr),
        };
        const outputAttachment = await createCommandOutputAttachment(runtime, message, capturedRun);
        const readView = terminalAttachmentReadView(outputAttachment);
        const observedAt = new Date().toISOString();
        const effectReceipt = terminalEffectReceipt(capturedRun, outputAttachment, observedAt);
        const succeeded = effectReceipt.outcome === "applied" && capturedRun.exitCode === 0;
        return {
            // A ReadView always describes the exact canonical page in `text`. When
            // persistence failed there is no restart-safe view, so retain the legacy
            // self-contained report as the explicit non-recoverable fallback.
            text: readView
                ? (outputAttachment?.attachment.text ?? "")
                : buildCapturedResponseText(capturedRun, outputAttachment),
            success: succeeded,
            modelReplyRequired: true,
            effectReceipts: [effectReceipt],
            ...(succeeded
                ? {}
                : {
                    error: effectReceipt.outcome === "failed"
                        ? effectReceipt.failure.code
                        : "TERMINAL_EXECUTION_FAILED",
                }),
            data: {
                actionName: TERMINAL_ACTION_NAME,
                ...completeRun,
                outputAttachment: outputAttachment?.attachment,
                outputAttachmentMemoryId: outputAttachment?.memoryId,
                suppressVisibleCallback: true,
            },
            // Complete command/stdout/stderr remain in text; data and attachments stay
            // intact in recordings. The model receives their identities once.
            promptDataMode: "replace-data",
            promptData: {
                actionName: TERMINAL_ACTION_NAME,
                ...(outputAttachment
                    ? { outputAttachmentId: outputAttachment.attachment.id }
                    : {}),
                ...(outputAttachment?.memoryId
                    ? { outputAttachmentMemoryId: outputAttachment.memoryId }
                    : {}),
                ...(readView ? { readView } : {}),
                terminal: {
                    runId: capturedRun.runId,
                    exitCode: capturedRun.exitCode,
                    timedOut: capturedRun.timedOut,
                    truncated: capturedRun.truncated,
                    ...(capturedRun.maxDurationMs !== undefined
                        ? { maxDurationMs: capturedRun.maxDurationMs }
                        : {}),
                    outputReferenceAvailable: Boolean(readView),
                },
            },
        };
    },
    parameters: [
        {
            name: "command",
            description: "One shell command, at most 4096 characters; no literal newline, carriage return or NUL. Use escaped newlines or coding tools for scripts.",
            required: true,
            schema: { type: "string" },
        },
    ],
    examples: [
        [
            {
                name: "{{name1}}",
                content: {
                    text: "Run ls -la in my home directory.",
                },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "The directory listing completed. It shows the current files and folders in your home directory.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: {
                    text: "Execute `git status` and save the output so I can look at it later.",
                },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "The `git status` output was captured. I saved the full output as an attachment and can keep it in the clipboard if it is useful for the next step.",
                },
            },
        ],
    ],
};
