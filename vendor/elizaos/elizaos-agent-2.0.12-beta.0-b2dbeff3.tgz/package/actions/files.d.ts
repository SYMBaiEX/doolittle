/**
 * Registers the FILES agent action, giving an owner-role agent read/CRUD access
 * to the content-addressed media store through the runtime's IFileStorageService
 * (ServiceType.REMOTE_FILES): list (every file, optional query), get
 * (details + served URL by filename), and delete (confirm-gated).
 */
import type { Action } from "@elizaos/core";
/**
 * FILES action: gives the agent read/CRUD access to the content-addressed file
 * store via {@link IFileStorageService}. op:list shows every stored file
 * (optional query); op:get returns a file's details + served URL by
 * fileName; op:delete removes a file (requires confirm:true).
 */
export declare const filesAction: Action;
