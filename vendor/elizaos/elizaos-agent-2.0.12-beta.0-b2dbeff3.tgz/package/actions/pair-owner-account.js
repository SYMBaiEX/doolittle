import { logger } from "@elizaos/core";
import { hasOwnerAccess } from "../security/access.js";
import { resolveOwnerBindingService, } from "../services/owner-binding.js";
const PAIR_OWNER_ACCOUNT = "PAIR_OWNER_ACCOUNT";
/** Connectors that ship a pairing command today, with the command to run. */
const PAIRABLE_CONNECTORS = [
    {
        connector: "discord",
        displayName: "Discord",
        command: "/eliza-pair",
        terms: ["discord"],
    },
    {
        connector: "telegram",
        displayName: "Telegram",
        command: "/eliza_pair",
        terms: ["telegram"],
    },
];
/** Verbs that signal a link/pair/verify intent. */
const PAIR_INTENT_TERMS = [
    "link",
    "pair",
    "bind",
    "verify",
    "connect",
    "prove",
];
function normalize(text) {
    return text.toLowerCase();
}
/** The pairable connector named in the text, or null when none/ambiguous. */
export function resolveRequestedPairConnector(text) {
    const normalized = normalize(text);
    const mentioned = PAIRABLE_CONNECTORS.filter((entry) => entry.terms.some((term) => normalized.includes(term)));
    return mentioned.length === 1 ? (mentioned[0] ?? null) : null;
}
/**
 * True when the message expresses intent to pair/link an owner platform
 * account. Requires both a pair-style verb AND a supported connector name so
 * unrelated "link this doc" / "connect the printer" text does not match.
 */
export function messageWantsOwnerPairing(text) {
    const normalized = normalize(text);
    const hasVerb = PAIR_INTENT_TERMS.some((term) => normalized.includes(term));
    if (!hasVerb)
        return false;
    return PAIRABLE_CONNECTORS.some((entry) => entry.terms.some((term) => normalized.includes(term)));
}
function failure(text, error) {
    return {
        success: false,
        text,
        values: { success: false, error },
        data: { actionName: PAIR_OWNER_ACCOUNT, error },
    };
}
export const pairOwnerAccountAction = {
    name: PAIR_OWNER_ACCOUNT,
    contexts: ["settings", "messaging"],
    roleGate: { minRole: "OWNER" },
    similes: [
        "LINK_MY_DISCORD",
        "LINK_MY_TELEGRAM",
        "PAIR_DISCORD_ACCOUNT",
        "PAIR_TELEGRAM_ACCOUNT",
        "VERIFY_OWNER_ACCOUNT",
        "BIND_OWNER_ACCOUNT",
    ],
    description: "Link the app owner's Discord or Telegram account to their owner " +
        "identity. Issues a one-time pairing code and tells the owner which " +
        "command to run on the platform; once verified, messages from that " +
        "platform account are recognized as the owner. Owner-only.",
    validate: async (_runtime, message, _state, _options) => {
        const text = typeof message.content.text === "string" ? message.content.text : "";
        if (!text.trim())
            return false;
        return messageWantsOwnerPairing(text);
    },
    handler: async (runtime, message, _state, _options, callback) => {
        // Defense in depth: the roleGate already scopes planner exposure, but the
        // pairing code grants OWNER to whoever redeems it, so the handler itself
        // must refuse any sender that does not resolve to the owner.
        if (!(await hasOwnerAccess(runtime, message))) {
            const text = "Only the app owner can link an owner account. Ask the owner to run this from their own chat.";
            if (callback) {
                await callback({ text, action: PAIR_OWNER_ACCOUNT });
            }
            return failure(text, "NOT_OWNER");
        }
        const messageText = typeof message.content.text === "string" ? message.content.text : "";
        const target = resolveRequestedPairConnector(messageText);
        if (!target) {
            const names = PAIRABLE_CONNECTORS.map((c) => c.displayName).join(" or ");
            const text = `Which account should I link — ${names}?`;
            if (callback) {
                await callback({ text, action: PAIR_OWNER_ACCOUNT });
            }
            return failure(text, "CONNECTOR_AMBIGUOUS");
        }
        const service = resolveOwnerBindingService(runtime);
        if (!service) {
            const text = "Owner pairing is not available right now (the pairing service is not running).";
            if (callback) {
                await callback({ text, action: PAIR_OWNER_ACCOUNT });
            }
            return failure(text, "SERVICE_UNAVAILABLE");
        }
        let issued;
        try {
            issued = service.beginOwnerBind({ connector: target.connector });
        }
        catch (err) {
            // error-policy:J4 explicit user-facing degrade — the one expected
            // failure is "no canonical owner configured", surfaced as a designed
            // unavailable reply; every failure is also reported for repair.
            runtime.reportError("agent:pair-owner-account", err, {
                connector: target.connector,
            });
            const text = "I couldn't issue a pairing code. Finish app setup first so an owner identity exists, then try again.";
            if (callback) {
                await callback({ text, action: PAIR_OWNER_ACCOUNT });
            }
            return failure(text, "ISSUE_FAILED");
        }
        const minutes = Math.round((issued.expiresAt - Date.now()) / 60_000);
        const replyText = `Here's your ${target.displayName} pairing code: **${issued.code}**\n\n` +
            `Run \`${target.command} ${issued.code}\` ${target.connector === "discord"
                ? "in any server or DM with me on Discord"
                : "in your Telegram chat with me"}. The code is single-use and expires in ${minutes > 0 ? minutes : 5} minutes. ` +
            "Don't share it — whoever redeems it is recognized as the owner.";
        if (callback) {
            await callback({ text: replyText, action: PAIR_OWNER_ACCOUNT });
        }
        logger.info({
            src: "agent:pair-owner-account",
            agentId: runtime.agentId,
            connector: target.connector,
        }, "Issued owner pairing code via chat");
        return {
            success: true,
            text: replyText,
            values: { success: true, connector: target.connector },
            data: {
                actionName: PAIR_OWNER_ACCOUNT,
                connector: target.connector,
                expiresAt: issued.expiresAt,
            },
        };
    },
    examples: [
        [
            {
                name: "{{name1}}",
                content: { text: "link my discord account" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Here's your Discord pairing code: **123456** — run `/eliza-pair 123456` in any server or DM with me on Discord.",
                    action: PAIR_OWNER_ACCOUNT,
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "pair my telegram so you know it's me" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Here's your Telegram pairing code: **654321** — run `/eliza_pair 654321` in your Telegram chat with me.",
                    action: PAIR_OWNER_ACCOUNT,
                },
            },
        ],
    ],
};
