/**
 * Registers the PLUGIN agent action — owner-only, package-level lifecycle for
 * plugins and connectors. Manager-backed ops (install/uninstall/update/sync/
 * eject/reinject) go through the plugin_manager service; configure/read_config/
 * toggle/list/disconnect hit the local /api/plugins compat routes because their
 * orchestration lives in @elizaos/app, which this layer cannot import.
 */
import { type Action } from "@elizaos/core";
export declare const pluginAction: Action;
/** Authored package-operation schemas; account lifecycle remains CONNECTOR-owned. */
export declare function pluginOperationSchemaOverrides(): {
    [k: string]: {
        parameters: {
            required: boolean;
            name: string;
            description: string;
            descriptionCompressed?: string;
            compressedDescription?: string;
            subactions?: readonly string[];
            requiredForSubactions?: readonly string[];
            legacyRequiredAlternatives?: readonly string[];
            aliases?: readonly string[];
            modelOmissionSentinels?: readonly string[];
            schema: import("@elizaos/core").ActionParameterSchema;
            examples?: import("@elizaos/core").ActionParameterExampleValue[];
        }[];
    };
};
