/**
 * PAIR_OWNER_ACCOUNT — the owner-side entry point of the connector
 * owner-pairing flow. When the app owner asks to link/verify their Discord or
 * Telegram account ("link my discord", "pair my telegram account"), this
 * action issues a one-time 6-digit code via {@link OwnerBindingService} and
 * replies with the exact connector command to run (`/eliza-pair <code>` on
 * Discord, `/eliza_pair <code>` on Telegram). The connector relays the code
 * back to the `OWNER_BIND_VERIFY` service, which binds the proven platform
 * identity to the canonical owner entity — after which role resolution treats
 * that platform user as OWNER everywhere.
 *
 * Authorization is double-gated: the declared `roleGate` keeps the action out
 * of non-owner planner surfaces, and the handler re-checks `hasOwnerAccess`
 * so a bypassed gate still fails closed. The code is revealed only in the
 * reply to the requesting (owner) surface, never pushed to the connector.
 */
import type { Action } from "@elizaos/core";
import { type OwnerBindConnector } from "../services/owner-binding.js";
/** Connectors that ship a pairing command today, with the command to run. */
declare const PAIRABLE_CONNECTORS: ReadonlyArray<{
    connector: OwnerBindConnector;
    displayName: string;
    /** Exact command the owner runs on the platform (naming differs because
     *  Telegram bot commands cannot contain hyphens). */
    command: string;
    /** Terms in the owner's message that select this connector. */
    terms: readonly string[];
}>;
/** The pairable connector named in the text, or null when none/ambiguous. */
export declare function resolveRequestedPairConnector(text: string): (typeof PAIRABLE_CONNECTORS)[number] | null;
/**
 * True when the message expresses intent to pair/link an owner platform
 * account. Requires both a pair-style verb AND a supported connector name so
 * unrelated "link this doc" / "connect the printer" text does not match.
 */
export declare function messageWantsOwnerPairing(text: string): boolean;
export declare const pairOwnerAccountAction: Action;
export {};
