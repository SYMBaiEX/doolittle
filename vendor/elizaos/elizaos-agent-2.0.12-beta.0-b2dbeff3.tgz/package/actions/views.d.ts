import { type Action, type IAgentRuntime } from "@elizaos/core";
import { type ViewRegistryEntry } from "../api/views-registry.js";
export interface ViewNavigationDelivery {
    runtime: IAgentRuntime;
    view: ViewRegistryEntry;
    clientId: string;
    handoffId: string;
    completedAction: boolean;
    delivery: "completed-action" | "originating-client";
    resolvedAlias?: string;
    apiBase: string;
    signal?: AbortSignal;
    isAuthorized: () => boolean;
}
export type DeliverViewNavigation = (input: ViewNavigationDelivery) => Promise<{
    status: number;
    body: unknown;
}>;
/** Hosts may provide delivery without replacing owner, registry or receipt checks.
 * A preparation-only host must return the same exact prepared binding; this
 * action never treats preparation as confirmation that navigation occurred. */
export declare function createViewsAction(deliver?: DeliverViewNavigation): Action;
export declare const viewsAction: Action;
