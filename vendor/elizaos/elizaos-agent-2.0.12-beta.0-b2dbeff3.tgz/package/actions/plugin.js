/**
 * Registers the PLUGIN agent action — owner-only, package-level lifecycle for
 * plugins and connectors. Manager-backed ops (install/uninstall/update/sync/
 * eject/reinject) go through the plugin_manager service; configure/read_config/
 * toggle/list/disconnect hit the local /api/plugins compat routes because their
 * orchestration lives in @elizaos/app, which this layer cannot import.
 */
import { ElizaError, logger, } from "@elizaos/core";
import { createSelfApiRequestHeaders, requireRestartHandler, resolveSelfApiBaseUrl, } from "@elizaos/host/protocol";
import { isPluginManagerLike, } from "../services/plugin-manager-types.js";
const PLUGIN_OPS = [
    "install",
    "uninstall",
    "update",
    "sync",
    "eject",
    "reinject",
    "configure",
    "read_config",
    "toggle",
    "list",
    "disconnect",
];
const PLUGIN_TYPES = ["plugin", "connector"];
const RELEASE_STREAMS = ["latest", "beta"];
const LIST_STATUSES = ["enabled", "disabled", "active", "inactive"];
async function readMutationResponse(resp) {
    try {
        const data = await resp.json();
        return data && typeof data === "object" && !Array.isArray(data)
            ? data
            : {};
    }
    catch {
        // error-policy:J3 An unreadable response does not acknowledge a mutation.
        return {};
    }
}
function mutationAcknowledged(data) {
    return ((data.ok === true || data.success === true) &&
        data.ok !== false &&
        data.success !== false);
}
// `telegram` is the bot connector. It has no entry here: the personal-account
// cancel route does not stop the bot, so it takes the plugin-disable path.
const CONNECTOR_DISCONNECT_PATHS = {
    "telegram-account": "/api/setup/telegram-account/cancel",
    whatsapp: "/api/whatsapp/disconnect",
    "discord-local": "/api/setup/discord/cancel",
};
function getApiBase() {
    return resolveSelfApiBaseUrl(process.env);
}
function getPluginManager(runtime) {
    const svc = runtime.getService("plugin_manager");
    return isPluginManagerLike(svc) ? svc : null;
}
function fail(text, error) {
    return { success: false, text, data: { error } };
}
function normalizeNpmName(pluginId) {
    return pluginId.startsWith("@") ? pluginId : `@elizaos/plugin-${pluginId}`;
}
function normalizeConfig(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return null;
    }
    const out = {};
    for (const [key, raw] of Object.entries(value)) {
        if (typeof key !== "string" || key.length === 0)
            continue;
        if (typeof raw === "string") {
            out[key] = raw;
        }
        else if (typeof raw === "number" || typeof raw === "boolean") {
            out[key] = String(raw);
        }
    }
    return out;
}
function resolveTargetId(params) {
    return params.pluginId?.trim() || params.connectorId?.trim() || "";
}
function resolveListFilter(params) {
    if (params.filter && typeof params.filter === "object") {
        return params.filter;
    }
    return {
        status: params.status,
        configured: params.configured,
        search: params.search,
    };
}
// ---------------------------------------------------------------------------
// Op handlers
// ---------------------------------------------------------------------------
async function doInstall(mgr, params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_INSTALL_FAILED");
    const npmName = normalizeNpmName(pluginId);
    const result = await mgr.installPlugin(npmName);
    if (!result.success) {
        return fail(`Failed to install ${pluginId}: ${result.error ?? "unknown error"}`, "PLUGIN_INSTALL_FAILED");
    }
    return {
        success: true,
        text: `Plugin ${result.pluginName}@${result.version} installed successfully.${result.requiresRestart ? " The agent will restart to load it." : ""}`,
        data: { actionName: "PLUGIN", op: "install", pluginId, npmName, ...result },
    };
}
async function doUninstall(mgr, params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_UNINSTALL_FAILED");
    const npmName = normalizeNpmName(pluginId);
    const result = await mgr.uninstallPlugin(npmName);
    if (!result.success) {
        return fail(`Failed to uninstall ${pluginId}: ${result.error ?? "unknown error"}`, "PLUGIN_UNINSTALL_FAILED");
    }
    return {
        success: true,
        text: `Plugin ${result.pluginName} uninstalled successfully.${result.requiresRestart ? " The agent will restart to drop it." : ""}`,
        data: {
            actionName: "PLUGIN",
            op: "uninstall",
            pluginId,
            npmName,
            ...result,
        },
    };
}
async function doUpdate(mgr, params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_UPDATE_FAILED");
    if (typeof mgr.updatePlugin !== "function") {
        return fail("Plugin manager does not support updates.", "PLUGIN_UPDATE_FAILED");
    }
    const npmName = normalizeNpmName(pluginId);
    const stream = params.stream;
    const options = stream !== undefined ? { releaseStream: stream } : undefined;
    const result = await mgr.updatePlugin(npmName, undefined, options);
    if (!result.success) {
        return fail(`Failed to update ${pluginId}: ${result.error ?? "unknown error"}`, "PLUGIN_UPDATE_FAILED");
    }
    return {
        success: true,
        text: `Plugin ${result.pluginName}@${result.version} updated successfully.${result.requiresRestart ? " The agent will restart to load the new version." : ""}`,
        data: {
            actionName: "PLUGIN",
            op: "update",
            pluginId,
            npmName,
            stream,
            ...result,
        },
    };
}
async function doSync(mgr, params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_SYNC_FAILED");
    const result = await mgr.syncPlugin(pluginId);
    if (!result.success) {
        return fail(`Failed to sync ${pluginId}: ${result.error ?? "unknown error"}.`, "PLUGIN_SYNC_FAILED");
    }
    return {
        success: true,
        text: `Synced ${result.pluginName}.`,
        data: { actionName: "PLUGIN", op: "sync", pluginId, ...result },
    };
}
async function doEject(runtime, mgr, params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_EJECT_FAILED");
    const restart = requireRestartHandler();
    const result = await mgr.ejectPlugin(pluginId);
    if (!result.success) {
        return fail(`Failed to eject ${pluginId}: ${result.error ?? "unknown error"}`, "PLUGIN_EJECT_FAILED");
    }
    setTimeout(() => {
        void Promise.resolve()
            .then(() => restart(`Plugin ${result.pluginName} ejected`))
            .catch((error) => {
            // error-policy:J7 observe deferred host failures after the plugin mutation.
            logger.error({ error, pluginId }, "[plugin:eject] Deferred restart failed");
            runtime.reportError("plugin.eject.restart", error);
        });
    }, 1_000);
    return {
        success: true,
        text: `Ejected ${result.pluginName} to ${result.ejectedPath}. Restarting to load local source.`,
        data: { actionName: "PLUGIN", op: "eject", pluginId, ...result },
    };
}
async function doReinject(runtime, mgr, params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_REINJECT_FAILED");
    const restart = requireRestartHandler();
    const result = await mgr.reinjectPlugin(pluginId);
    if (!result.success) {
        return fail(`Failed to reinject ${pluginId}: ${result.error ?? "unknown error"}`, "PLUGIN_REINJECT_FAILED");
    }
    setTimeout(() => {
        void Promise.resolve()
            .then(() => restart(`Plugin ${result.pluginName} reinjected`))
            .catch((error) => {
            // error-policy:J7 observe deferred host failures after the plugin mutation.
            logger.error({ error, pluginId }, "[plugin:reinject] Deferred restart failed");
            runtime.reportError("plugin.reinject.restart", error);
        });
    }, 1_000);
    return {
        success: true,
        text: `Removed ejected plugin ${result.pluginName}. Restarting to load npm version.`,
        data: { actionName: "PLUGIN", op: "reinject", pluginId, ...result },
    };
}
// configure / read_config / toggle: orchestration (vault mirror, runtime
// mutation, drift reconciliation) is in @elizaos/app which the agent
// layer cannot import. Hit the local /api/plugins compat routes instead.
async function doConfigure(params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_CONFIGURE_FAILED");
    const config = normalizeConfig(params.config);
    if (!config || Object.keys(config).length === 0) {
        return fail("Missing or empty config object.", "PLUGIN_CONFIGURE_FAILED");
    }
    const base = getApiBase();
    const resp = await fetch(`${base}/api/plugins/${encodeURIComponent(pluginId)}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            ...createSelfApiRequestHeaders(),
        },
        body: JSON.stringify({ config }),
        signal: AbortSignal.timeout(60_000),
    });
    let data;
    try {
        const parsed = await resp.json();
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
            throw new Error("Save response was not a JSON object.");
        }
        data = parsed;
    }
    catch {
        // error-policy:J3 untrusted save-response parse — a 200 with a proxy
        // HTML page, empty body, or truncated payload does not acknowledge a save,
        // so fail closed instead of reporting a successful save.
        logger.warn(`[plugin:configure] Save response was not JSON (${resp.status}).`);
        return fail(`Failed to save config for ${pluginId}: Save failed (${resp.status}).`, "PLUGIN_CONFIGURE_FAILED");
    }
    if (!resp.ok ||
        (data.ok !== true && data.success !== true) ||
        data.success === false ||
        data.ok === false) {
        const errMsg = data.error || data.message || `Save failed (${resp.status}).`;
        logger.warn(`[plugin:configure] ${errMsg}`);
        return fail(`Failed to save config for ${pluginId}: ${errMsg}`, "PLUGIN_CONFIGURE_FAILED");
    }
    // Auto-test connection (best-effort, surface result in text).
    let testSummary = "";
    try {
        const testResp = await fetch(`${base}/api/plugins/${encodeURIComponent(pluginId)}/test`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                ...createSelfApiRequestHeaders(),
            },
            signal: AbortSignal.timeout(30_000),
        });
        const testData = (await testResp.json().catch(() => ({})));
        if (testResp.ok && testData.success) {
            testSummary = ` Connection test passed (${testData.durationMs ?? 0}ms).`;
        }
        else if (testResp.ok && testData.success === false) {
            testSummary = ` Connection test failed: ${testData.error ?? "unknown"}.`;
        }
    }
    catch (testErr) {
        testSummary = ` Connection test skipped: ${testErr instanceof Error ? testErr.message : "unknown error"}.`;
    }
    const restartNote = data.requiresRestart
        ? " The agent will restart to apply the change."
        : "";
    const updatedKeys = Object.keys(config).sort().join(", ");
    return {
        success: true,
        text: `Updated ${pluginId} config (${updatedKeys}).${restartNote}${testSummary}`,
        data: {
            actionName: "PLUGIN",
            op: "configure",
            pluginId,
            updatedKeys: Object.keys(config),
            ...data,
        },
    };
}
async function doReadConfig(params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_READ_CONFIG_FAILED");
    const base = getApiBase();
    const resp = await fetch(`${base}/api/plugins`, {
        headers: createSelfApiRequestHeaders(),
        signal: AbortSignal.timeout(15_000),
    });
    if (!resp.ok) {
        return fail(`Failed to fetch plugins list: HTTP ${resp.status}`, "PLUGIN_READ_CONFIG_FAILED");
    }
    const listData = (await resp.json());
    const plugins = listData.plugins;
    const lower = pluginId.toLowerCase();
    const plugin = plugins.find((p) => p.id === pluginId || p.npmName === pluginId) ??
        plugins.find((p) => p.id.toLowerCase().includes(lower) ||
            p.name.toLowerCase().includes(lower));
    if (!plugin) {
        return fail(`Plugin "${pluginId}" not found.`, "PLUGIN_READ_CONFIG_NOT_FOUND");
    }
    const lines = [
        `Plugin: ${plugin.name} (${plugin.id})`,
        `Status: ${plugin.enabled ? "enabled" : "disabled"} | configured: ${plugin.configured}`,
    ];
    if (plugin.version)
        lines.push(`Version: ${plugin.version}`);
    if (plugin.description)
        lines.push(`Description: ${plugin.description}`);
    if (plugin.loadError)
        lines.push(`Load error: ${plugin.loadError}`);
    if (plugin.parameters && plugin.parameters.length > 0) {
        lines.push("\nParameters:");
        for (const param of plugin.parameters) {
            const required = param.required ? " [required]" : "";
            const sensitive = param.sensitive ? " [sensitive]" : "";
            const setValue = param.isSet
                ? param.sensitive
                    ? " = ***"
                    : ` = ${param.currentValue ?? "(empty)"}`
                : " (not set)";
            lines.push(`  ${param.key}${required}${sensitive}${setValue}`);
        }
    }
    else if (plugin.configKeys && plugin.configKeys.length > 0) {
        lines.push(`\nConfig keys: ${plugin.configKeys.join(", ")}`);
    }
    return {
        success: true,
        text: lines.join("\n"),
        values: {
            pluginId: plugin.id,
            enabled: plugin.enabled,
            configured: plugin.configured,
        },
        data: {
            actionName: "PLUGIN",
            op: "read_config",
            plugin: {
                id: plugin.id,
                name: plugin.name,
                description: plugin.description,
                enabled: plugin.enabled,
                configured: plugin.configured,
                version: plugin.version ?? null,
                loadError: plugin.loadError ?? null,
                parameters: plugin.parameters.map((p) => ({
                    key: p.key,
                    required: p.required ?? false,
                    sensitive: p.sensitive ?? false,
                    isSet: p.isSet ?? false,
                    currentValue: p.sensitive ? null : (p.currentValue ?? null),
                })),
            },
        },
    };
}
async function doToggle(params) {
    const pluginId = resolveTargetId(params);
    if (!pluginId)
        return fail("Missing pluginId.", "PLUGIN_TOGGLE_FAILED");
    const enabled = params.enabled;
    if (typeof enabled !== "boolean") {
        return fail("Missing 'enabled' boolean parameter.", "PLUGIN_TOGGLE_FAILED");
    }
    const base = getApiBase();
    const resp = await fetch(`${base}/api/plugins/${encodeURIComponent(pluginId)}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            ...createSelfApiRequestHeaders(),
        },
        body: JSON.stringify({ enabled }),
        signal: AbortSignal.timeout(60_000),
    });
    const data = await readMutationResponse(resp);
    if (!resp.ok || !mutationAcknowledged(data)) {
        const errMsg = data.error || data.message || `Toggle failed (${resp.status}).`;
        logger.warn(`[plugin:toggle] ${errMsg}`);
        return fail(`Failed to ${enabled ? "enable" : "disable"} ${pluginId}: ${errMsg}`, "PLUGIN_TOGGLE_FAILED");
    }
    const restartNote = data.requiresRestart
        ? " The agent will restart to apply the change."
        : "";
    return {
        success: true,
        text: `Plugin ${pluginId} ${enabled ? "enabled" : "disabled"}.${restartNote}`,
        data: {
            actionName: "PLUGIN",
            op: "toggle",
            pluginId,
            enabled,
            ...data,
        },
    };
}
async function fetchPluginsList(base) {
    const resp = await fetch(`${base}/api/plugins`, {
        headers: createSelfApiRequestHeaders(),
        signal: AbortSignal.timeout(15_000),
    });
    if (!resp.ok) {
        throw new Error(`/api/plugins returned ${resp.status}`);
    }
    const data = (await resp.json());
    return Array.isArray(data.plugins) ? data.plugins : [];
}
function applyListFilter(entries, filter) {
    const search = filter.search?.trim().toLowerCase() ?? "";
    return entries.filter((entry) => {
        if (search) {
            const haystack = `${entry.id} ${entry.name} ${entry.description}`.toLowerCase();
            if (!haystack.includes(search))
                return false;
        }
        if (typeof filter.configured === "boolean") {
            if (Boolean(entry.configured) !== filter.configured)
                return false;
        }
        switch (filter.status) {
            case "enabled":
                return entry.enabled;
            case "disabled":
                return !entry.enabled;
            case "active":
                return Boolean(entry.isActive);
            case "inactive":
                return !entry.isActive;
            default:
                return true;
        }
    });
}
/**
 * Renders the active narrowings of a list request as readable text. `filter`
 * is an object, so interpolating it directly printed "[object Object]" and
 * comparing it to "all" was never true — the named filter has to be legible
 * for "retry without it" to mean anything. Empty string means nothing narrowed.
 */
function describeListFilter(filter) {
    const parts = [];
    if (filter.status)
        parts.push(`status=${filter.status}`);
    if (typeof filter.configured === "boolean") {
        parts.push(`configured=${filter.configured}`);
    }
    const search = filter.search?.trim();
    if (search)
        parts.push(`search="${search}"`);
    return parts.join(", ");
}
async function doList(params) {
    const base = getApiBase();
    const filter = resolveListFilter(params);
    const type = params.type ?? "connector";
    let entries;
    try {
        entries = await fetchPluginsList(base);
    }
    catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        logger.error(`[plugin:list] ${msg}`);
        return fail(`Failed to list ${type}s: ${msg}`, "PLUGIN_LIST_FAILED");
    }
    const scoped = type === "connector"
        ? entries.filter((entry) => entry.category === "connector")
        : entries;
    const filtered = applyListFilter(scoped, filter);
    const label = type === "connector" ? "Connectors" : "Plugins";
    const narrowing = describeListFilter(filter);
    const plural = scoped.length === 1 ? "" : "s";
    if (filtered.length === 0) {
        // Name the scope that produced the emptiness. "No connectors match the
        // requested filter" reads as "you have no connectors" once the model
        // paraphrases it: a live turn answered "what apps or connectors am I
        // connected to" with "You're not connected to anything right now" while
        // Discord was actively delivering that very reply. An empty result has to
        // carry what it was narrowed by, and how to widen it.
        const scopeNote = narrowing
            ? `${narrowing}; ${scoped.length} ${type}${plural} exist before filtering`
            : `${scoped.length} ${type}${plural} exist but none are listed under this view`;
        return {
            success: true,
            text: `No ${type}s match the requested filter (${scopeNote}). This is a filtered view, not a statement that none exist — retry with no filter to see every ${type}.`,
            data: {
                actionName: "PLUGIN",
                op: "list",
                type,
                filter,
                totalBeforeFilter: scoped.length,
                count: 0,
                entries: [],
            },
        };
    }
    const lines = filtered.map((entry) => {
        const status = entry.enabled ? "enabled" : "disabled";
        const active = entry.isActive ? " active" : "";
        const configured = entry.configured ? " configured" : " unconfigured";
        return `- ${entry.name} [${entry.id}] (${status}${active},${configured})`;
    });
    // Same disclosure on the populated branch: a filtered subset rendered under
    // a bare "Connectors (1):" header reads as the whole roster, and the model
    // told a user they had one connector while eleven more sat in `scoped`.
    const header = scoped.length > filtered.length
        ? `${label} (${filtered.length} of ${scoped.length}; narrowed by ${narrowing} — retry with no filter to see all ${scoped.length}):`
        : `${label} (${filtered.length}):`;
    return {
        success: true,
        text: [header, ...lines].join("\n"),
        data: {
            actionName: "PLUGIN",
            op: "list",
            type,
            count: filtered.length,
            totalBeforeFilter: scoped.length,
            entries: filtered,
            filter,
        },
    };
}
async function doDisconnect(params) {
    const connectorId = resolveTargetId(params);
    if (!connectorId)
        return fail("Missing connector id.", "PLUGIN_DISCONNECT_FAILED");
    const base = getApiBase();
    const dedicatedPath = CONNECTOR_DISCONNECT_PATHS[connectorId.toLowerCase()];
    if (dedicatedPath) {
        const resp = await fetch(`${base}${dedicatedPath}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                ...createSelfApiRequestHeaders(),
            },
            signal: AbortSignal.timeout(30_000),
        });
        const data = await readMutationResponse(resp);
        const acknowledged = dedicatedPath === "/api/setup/telegram-account/cancel"
            ? data.connector === "telegram-account" &&
                data.state === "idle" &&
                data.ok !== false &&
                data.success !== false
            : dedicatedPath === "/api/setup/discord/cancel"
                ? data.connector === "discord" && data.state === "idle"
                : mutationAcknowledged(data);
        if (!resp.ok || !acknowledged) {
            const errMsg = data.error || data.message || `Disconnect failed (${resp.status}).`;
            logger.warn(`[plugin:disconnect] ${errMsg}`);
            return fail(`Failed to disconnect ${connectorId}: ${errMsg}`, "PLUGIN_DISCONNECT_FAILED");
        }
        return {
            success: true,
            text: data.message ?? `Disconnected ${connectorId}.`,
            data: {
                actionName: "PLUGIN",
                op: "disconnect",
                connectorId,
                endpoint: dedicatedPath,
                ...data,
            },
        };
    }
    // Fallback: disable the plugin so its sender stops.
    const resp = await fetch(`${base}/api/plugins/${encodeURIComponent(connectorId)}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            ...createSelfApiRequestHeaders(),
        },
        body: JSON.stringify({ enabled: false }),
        signal: AbortSignal.timeout(60_000),
    });
    const data = await readMutationResponse(resp);
    if (!resp.ok || !mutationAcknowledged(data)) {
        const errMsg = data.error || data.message || `Disconnect failed (${resp.status}).`;
        return fail(`Failed to disconnect ${connectorId}: ${errMsg}`, "PLUGIN_DISCONNECT_FAILED");
    }
    const restartNote = data.requiresRestart
        ? " The agent will restart to drop the session."
        : "";
    return {
        success: true,
        text: `Disconnected ${connectorId} by disabling the connector.${restartNote}`,
        data: {
            actionName: "PLUGIN",
            op: "disconnect",
            connectorId,
            fallback: "plugin-disable",
            ...data,
        },
    };
}
// ---------------------------------------------------------------------------
// Action
// ---------------------------------------------------------------------------
const PLUGIN_MANAGER_OPS = new Set([
    "install",
    "uninstall",
    "update",
    "sync",
    "eject",
    "reinject",
]);
export const pluginAction = {
    name: "PLUGIN",
    contexts: ["admin", "settings", "connectors", "secrets", "code", "files"],
    roleGate: { minRole: "OWNER" },
    similes: [
        // Legacy plugin-lifecycle action names kept as aliases
        "INSTALL_PLUGIN",
        "UNINSTALL_PLUGIN",
        "UPDATE_PLUGIN",
        "SYNC_PLUGIN",
        "EJECT_PLUGIN",
        "REINJECT_PLUGIN",
        "CONFIGURE_PLUGIN",
        "READ_PLUGIN_CONFIG",
        "TOGGLE_PLUGIN",
        // Legacy connector-control action names kept as aliases
        "CONFIGURE_CONNECTOR",
        "SAVE_CONNECTOR_CONFIG",
        "SET_CONNECTOR_ENABLED",
        "TOGGLE_CONNECTOR",
        "DISCONNECT_CONNECTOR",
        "LIST_CONNECTORS",
        // Intermediate parent action, kept as an alias
        "CONNECTOR",
        // Coarse aliases planners may emit
        "PLUGIN_LIFECYCLE",
        "MANAGE_PLUGIN",
        "MANAGE_CONNECTOR",
    ],
    description: "Install / uninstall / configure / eject plugins and connectors at the " +
        "**package** level. ops: install, uninstall, update (refresh to latest), " +
        "sync (pull upstream into ejected source), eject (clone source locally), " +
        "reinject (drop ejected copy and use npm), configure (save key/value " +
        "config + auto-test), read_config (return current state), toggle " +
        "(enable/disable), list (enumerate plugins or connectors with optional " +
        "filter), disconnect (sign out connector and drop session). type only " +
        "scopes list: type='connector' (default) lists plugins in the 'connector' " +
        "category, type='plugin' lists every installed plugin. Connector " +
        "operations here manage the **package** and its config only, not account " +
        "state. For **account**-level connector lifecycle (log " +
        "in, log out, verify account, list account status), use the `CONNECTOR` " +
        "action instead.",
    descriptionCompressed: "plugin/connector package install|uninstall|update|sync|eject|configure|toggle|list",
    validate: async (runtime, _message, _state, options) => {
        const params = (options?.parameters ??
            {});
        const op = params.action ?? params.subaction ?? params.op;
        // The app runtime always has local plugin/connector config routes, but the
        // package-lifecycle ops additionally need the optional plugin_manager
        // service. With no params yet, expose PLUGIN so settings/connectors turns can
        // choose it and the handler can validate the concrete operation.
        return (!op || !PLUGIN_MANAGER_OPS.has(op) || getPluginManager(runtime) !== null);
    },
    handler: async (runtime, _message, _state, options) => {
        const params = (options?.parameters ??
            {});
        const op = params.action ?? params.subaction ?? params.op;
        if (!op || !PLUGIN_OPS.includes(op)) {
            return fail(`action is required and must be one of ${PLUGIN_OPS.join(", ")}.`, "PLUGIN_INVALID");
        }
        try {
            if (PLUGIN_MANAGER_OPS.has(op)) {
                const mgr = getPluginManager(runtime);
                if (!mgr) {
                    return fail("Plugin manager service is not available.", `PLUGIN_${op.toUpperCase()}_FAILED`);
                }
                switch (op) {
                    case "install":
                        return await doInstall(mgr, params);
                    case "uninstall":
                        return await doUninstall(mgr, params);
                    case "update":
                        return await doUpdate(mgr, params);
                    case "sync":
                        return await doSync(mgr, params);
                    case "eject":
                        return await doEject(runtime, mgr, params);
                    case "reinject":
                        return await doReinject(runtime, mgr, params);
                }
            }
            switch (op) {
                case "configure":
                    return await doConfigure(params);
                case "read_config":
                    return await doReadConfig(params);
                case "toggle":
                    return await doToggle(params);
                case "list":
                    return await doList(params);
                case "disconnect":
                    return await doDisconnect(params);
            }
            return fail(`Unhandled op '${op}'.`, "PLUGIN_INVALID");
        }
        catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            logger.warn(`[plugin:${op}] failed: ${msg}`);
            return fail(`Failed to ${op}: ${msg}`, `PLUGIN_${op.toUpperCase()}_FAILED`);
        }
    },
    parameters: [
        {
            name: "action",
            description: "Operation to perform.",
            required: true,
            schema: { type: "string", enum: [...PLUGIN_OPS] },
        },
        {
            name: "type",
            description: "list scope. 'connector' (default) = only plugins in the 'connector' category (discord, telegram, slack, etc.); 'plugin' = every installed plugin. Other operations ignore it.",
            required: false,
            schema: { type: "string", enum: [...PLUGIN_TYPES] },
        },
        {
            name: "pluginId",
            description: "Plugin id or npm package (e.g. 'discord' or '@elizaos/plugin-discord'). Required for everything except 'list'.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "connectorId",
            description: "Connector id (alias of pluginId; e.g. 'discord', 'telegram', 'whatsapp'). Use this when type=connector.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "config",
            description: "configure: object of key/value strings to save. Keys are plugin parameter names; values are their new settings.",
            required: false,
            // A bare object schema is closed by the validator and would reject
            // every config key, so the map shape is declared. Values match what
            // normalizeConfig accepts.
            schema: {
                type: "object",
                additionalProperties: {
                    anyOf: [
                        { type: "string" },
                        { type: "number" },
                        { type: "boolean" },
                    ],
                },
            },
        },
        {
            name: "enabled",
            description: "toggle: true to enable, false to disable.",
            required: false,
            schema: { type: "boolean" },
        },
        {
            name: "stream",
            description: "update: release stream to pull from ('latest' or 'beta'). Defaults to the plugin's current stream.",
            required: false,
            schema: { type: "string", enum: [...RELEASE_STREAMS] },
        },
        {
            name: "status",
            description: "list filter: only return entries with this status (enabled/disabled/active/inactive).",
            required: false,
            schema: { type: "string", enum: [...LIST_STATUSES] },
        },
        {
            name: "configured",
            description: "list filter: when true, only configured entries; when false, only unconfigured.",
            required: false,
            schema: { type: "boolean" },
        },
        {
            name: "search",
            description: "list filter: case-insensitive substring match against id/name/description.",
            required: false,
            schema: { type: "string" },
        },
    ],
    examples: [
        [
            {
                name: "{{name1}}",
                content: { text: "Install the telegram plugin." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Plugin @elizaos/plugin-telegram@1.4.0 installed successfully. The agent will restart to load it.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Set the discord bot token to xyz." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Updated discord config (DISCORD_API_TOKEN). The agent will restart to apply the change.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Show me the discord plugin config." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Plugin: Discord (discord)\nStatus: enabled | configured: true",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Disable the discord plugin." },
            },
            {
                name: "{{agentName}}",
                content: { text: "Plugin discord disabled." },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Pull the latest into my forked discord plugin." },
            },
            {
                name: "{{agentName}}",
                content: { text: "Synced @elizaos/plugin-discord." },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Fork the telegram plugin locally." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Ejected @elizaos/plugin-telegram. Restarting to load local source.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Which connectors are set up?" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Connectors (2):\n- Discord [discord] (enabled active, configured)\n- Telegram [telegram] (disabled, unconfigured)",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Sign out of telegram." },
            },
            {
                name: "{{agentName}}",
                content: { text: "Disconnected telegram." },
            },
        ],
    ],
};
/** Authored package-operation schemas; account lifecycle remains CONNECTOR-owned. */
export function pluginOperationSchemaOverrides() {
    const target = ["type", "pluginId", "connectorId"];
    const operations = {
        install: target,
        uninstall: target,
        update: [...target, "stream"],
        sync: target,
        eject: target,
        reinject: target,
        configure: [...target, "config"],
        read_config: target,
        toggle: [...target, "enabled"],
        list: ["type", "status", "configured", "search"],
        disconnect: target,
    };
    const byName = new Map(pluginAction.parameters?.map((parameter) => [parameter.name, parameter]));
    return Object.fromEntries(Object.entries(operations).map(([operation, names]) => [
        operation,
        {
            parameters: names.map((name) => {
                const parameter = byName.get(name);
                if (!parameter)
                    throw new ElizaError(`PLUGIN ${operation}: missing parameter ${name}`, {
                        code: "PLUGIN_OPERATION_SCHEMA_INVALID",
                        context: { operation, parameter: name },
                    });
                // Either target alias is valid. Requiring pluginId would break connectorId callers.
                return {
                    ...parameter,
                    required: name === "config" || name === "enabled",
                };
            }),
        },
    ]));
}
