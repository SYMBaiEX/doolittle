/**
 * LOGS — polymorphic action for log inspection.
 *
 *   search    → GET /api/logs   (filter by source/level/tag/since; HTTP because the log
 *                                buffer lives on server state, not the runtime)
 *   delete    → DELETE /api/logs (clears the in-memory log buffer; HTTP for the same reason)
 */
import { type Action } from "@elizaos/core";
export declare const logsAction: Action;
