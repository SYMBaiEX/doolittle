/**
 * Applies owner-authorized provider, capability, identity, backend routing,
 * and world-settings updates from structured action parameters.
 */
import { findWorldsForOwner, getSalt, logger, ModelType, saltWorldSettings, toWellFormedUnicode, unsaltWorldSettings, } from "@elizaos/core";
import { FIRST_RUN_PROVIDER_CATALOG, getFirstRunProviderOption, normalizeFirstRunProviderId, } from "@elizaos/host/protocol";
import { resolveDevCloudEnvAuthority } from "@elizaos/plugin-elizacloud/cloud-config/dev-cloud-env-authority";
import { mirrorSavedConfigToLive } from "../api/config-state.js";
import { applyFirstRunConnectionConfig, createProviderSwitchConnection, } from "../api/provider-switch-config.js";
import { loadElizaConfig, saveElizaConfig } from "../config/config.js";
import { fetchConfiguredOwnerName, persistConfiguredOwnerName, } from "../services/owner-name.js";
// ── Op catalog ────────────────────────────────────────────────────────────
export const SETTINGS_OPS = [
    "update_ai_provider",
    "toggle_capability",
    "set_owner_name",
    "set",
    "show_backends",
    "set_backend",
];
// Coding sub-agent adapters the orchestrator can route to. Mirrors
// KNOWN_ADAPTER_TYPES in plugin-agent-orchestrator (kept as a literal here so
// @elizaos/agent does not depend on the orchestrator plugin).
// Keep in sync with CODING_AGENT_BACKENDS and normalizeTaskAgentAdapter in
// the orchestrator: kimi and grok were added there but this mirror was not
// updated, so set_backend rejected backends the orchestrator can route to.
const CODING_BACKENDS = [
    "elizaos",
    "pi-agent",
    "claude",
    "codex",
    "kimi",
    "grok",
];
const CODING_BACKEND_ALIASES = {
    "eliza-os": "elizaos",
    eliza: "elizaos",
    pi: "pi-agent",
    "pi agent": "pi-agent",
    "claude-code": "claude",
    "claude code": "claude",
    openai: "codex",
    "openai-codex": "codex",
    "openai codex": "codex",
    "kimi-code": "kimi",
    "kimi code": "kimi",
    moonshot: "kimi",
    "grok-build": "grok",
    "grok build": "grok",
    xai: "grok",
    "x-ai": "grok",
};
const DIFFICULTY_TAGS = ["simple", "moderate", "hard"];
const BRAIN_MODEL_KEYS = [
    ModelType.TEXT_NANO,
    ModelType.TEXT_SMALL,
    ModelType.TEXT_MEDIUM,
    ModelType.TEXT_LARGE,
    ModelType.TEXT_MEGA,
    ModelType.RESPONSE_HANDLER,
    ModelType.ACTION_PLANNER,
    ModelType.TEXT_REASONING_SMALL,
    ModelType.TEXT_REASONING_LARGE,
    ModelType.TEXT_COMPLETION,
];
// ── Constants ────────────────────────────────────────────────────────────
const PROVIDER_API_KEY_MAX_LENGTH = 512;
const MODEL_SLOT_MAX_LENGTH = 256;
const CAPABILITY_KEYS = ["wallet", "browser", "computerUse"];
const MODEL_SLOTS = ["nano", "small", "medium", "large", "mega"];
// ── Helpers ──────────────────────────────────────────────────────────────
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isCapabilityKey(value) {
    return (typeof value === "string" &&
        CAPABILITY_KEYS.includes(value));
}
export function trimToString(value, max) {
    if (typeof value !== "string")
        return undefined;
    const trimmed = toWellFormedUnicode(value.trim());
    if (!trimmed)
        return undefined;
    return trimmed.length <= max ? trimmed : undefined;
}
function fail(error, text, extra) {
    return {
        text,
        success: false,
        values: { success: false, error },
        data: { actionName: "SETTINGS", error, ...(extra ?? {}) },
    };
}
function ok(text, data) {
    return {
        text,
        success: true,
        values: { success: true },
        data: { actionName: "SETTINGS", ...data },
    };
}
function readParams(options) {
    const raw = options?.parameters;
    return isRecord(raw) ? raw : {};
}
// ── op: update_ai_provider ────────────────────────────────────────────────
/**
 * The chat provider ids `normalizeFirstRunProviderId` accepts, as advertised
 * to the planner. Subscription entries are coding-agent credentials and do not
 * set the chat route, so they are not offered as an AI provider.
 */
const AI_PROVIDER_IDS = FIRST_RUN_PROVIDER_CATALOG.filter((provider) => provider.authMode !== "subscription")
    .map((provider) => provider.id)
    .join(", ");
async function handleUpdateAiProvider(params) {
    const rawProvider = params.provider;
    if (typeof rawProvider !== "string" || !rawProvider.trim()) {
        return fail("MISSING_PROVIDER", "SETTINGS update_ai_provider requires a `provider` (e.g. anthropic, openai, elizacloud).");
    }
    const normalizedProvider = normalizeFirstRunProviderId(rawProvider);
    if (!normalizedProvider) {
        return fail("UNKNOWN_PROVIDER", `Unknown AI provider: ${rawProvider}. Use one from the first-run catalog (${AI_PROVIDER_IDS}).`, { provider: rawProvider });
    }
    const devCloudAuthority = resolveDevCloudEnvAuthority();
    if (normalizedProvider === "elizacloud" && devCloudAuthority) {
        return fail("DEV_CLOUD_AUTHORITY_ACTIVE", "Cloud provider activation is owned by the immutable local dev launch target; restart with the intended target and credential.", { provider: normalizedProvider, authority: devCloudAuthority });
    }
    const apiKey = trimToString(params.apiKey, PROVIDER_API_KEY_MAX_LENGTH);
    const modelConfigs = isRecord(params.modelConfigs)
        ? params.modelConfigs
        : null;
    const primaryModel = trimToString(modelConfigs?.primary ?? modelConfigs?.large, MODEL_SLOT_MAX_LENGTH);
    const config = loadElizaConfig();
    const connection = normalizedProvider === "elizacloud"
        ? {
            kind: "cloud-managed",
            cloudProvider: "elizacloud",
            ...(apiKey ? { apiKey } : {}),
        }
        : createProviderSwitchConnection({
            provider: normalizedProvider,
            ...(apiKey ? { apiKey } : {}),
            ...(primaryModel ? { primaryModel } : {}),
        });
    if (!connection) {
        return fail("INVALID_PROVIDER", `Failed to build provider switch connection for ${normalizedProvider}.`, { provider: normalizedProvider });
    }
    try {
        await applyFirstRunConnectionConfig(config, connection);
        if (modelConfigs) {
            const models = (config.models ?? {});
            for (const slot of MODEL_SLOTS) {
                const value = trimToString(modelConfigs[slot], MODEL_SLOT_MAX_LENGTH);
                if (value)
                    models[slot] = value;
            }
            config.models = models;
        }
        saveElizaConfig(config);
        mirrorSavedConfigToLive(config);
    }
    catch (err) {
        logger.error({ error: err instanceof Error ? err.stack : String(err) }, "[SETTINGS] update_ai_provider failed");
        return fail("SETTINGS_UPDATE_AI_PROVIDER_FAILED", `Failed to apply provider config: ${err instanceof Error ? err.message : String(err)}`);
    }
    const providerOption = getFirstRunProviderOption(normalizedProvider);
    return ok(`Switched AI provider to ${providerOption?.name ?? normalizedProvider}. Restart the agent to load the new provider.`, {
        op: "update_ai_provider",
        provider: normalizedProvider,
        providerName: providerOption?.name ?? normalizedProvider,
        ...(primaryModel ? { primaryModel } : {}),
        requiresRestart: true,
    });
}
// ── op: toggle_capability ────────────────────────────────────────────────
function handleToggleCapability(params) {
    const capability = params.capability;
    if (!isCapabilityKey(capability)) {
        return fail("UNKNOWN_CAPABILITY", `Unknown capability: ${String(capability)}. Must be one of: ${CAPABILITY_KEYS.join(", ")}.`, { allowed: [...CAPABILITY_KEYS] });
    }
    if (typeof params.enabled !== "boolean") {
        return fail("MISSING_ENABLED", "SETTINGS toggle_capability requires `enabled: boolean`.");
    }
    const enabled = params.enabled;
    try {
        const config = loadElizaConfig();
        const ui = isRecord(config.ui) ? config.ui : {};
        const capabilities = isRecord(ui.capabilities) ? ui.capabilities : {};
        capabilities[capability] = enabled;
        ui.capabilities = capabilities;
        config.ui = ui;
        saveElizaConfig(config);
        mirrorSavedConfigToLive(config);
    }
    catch (err) {
        logger.error({ error: err instanceof Error ? err.stack : String(err) }, "[SETTINGS] toggle_capability failed");
        return fail("SETTINGS_TOGGLE_CAPABILITY_FAILED", `Failed to persist capability toggle: ${err instanceof Error ? err.message : String(err)}`);
    }
    return ok(`Capability ${capability} is now ${enabled ? "enabled" : "disabled"}.`, { op: "toggle_capability", capability, enabled });
}
// ── op: set_owner_name ───────────────────────────────────────────────────
async function handleSetOwnerName(params) {
    const raw = typeof params.name === "string"
        ? toWellFormedUnicode(params.name.trim())
        : "";
    const name = raw;
    if (!name) {
        return fail("INVALID_PARAMETERS", "SETTINGS set_owner_name requires a non-empty `name` parameter.");
    }
    const previous = await fetchConfiguredOwnerName();
    const saved = await persistConfiguredOwnerName(name);
    if (!saved) {
        return fail("SETTINGS_SET_OWNER_NAME_FAILED", `Failed to persist owner name "${name}".`, { name });
    }
    return ok(previous
        ? `Owner name updated from "${previous}" to "${name}".`
        : `Owner name set to "${name}".`, { op: "set_owner_name", name, previous: previous ?? null });
}
function normalizeSettingValue(value) {
    if (typeof value === "string" || typeof value === "boolean")
        return value;
    if (typeof value === "number" || typeof value === "bigint")
        return String(value);
    return null;
}
function readSettingUpdates(params) {
    const updates = [];
    const push = (rawKey, rawValue) => {
        const key = typeof rawKey === "string" ? rawKey.trim() : "";
        const value = normalizeSettingValue(rawValue);
        if (key && value !== null)
            updates.push({ key, value });
    };
    if (typeof params.key === "string" && params.value !== undefined) {
        push(params.key, params.value);
    }
    if (Array.isArray(params.updates)) {
        for (const entry of params.updates) {
            if (isRecord(entry))
                push(entry.key, entry.value);
        }
    }
    return updates;
}
async function handleSet(runtime, ownerEntityId, params) {
    const updates = readSettingUpdates(params);
    if (!updates.length) {
        return fail("INVALID_PARAMETERS", "SETTINGS set requires `key` + `value`, or an `updates: [{ key, value }]` array.");
    }
    if (!ownerEntityId) {
        return fail("NO_OWNER_ENTITY", "SETTINGS set requires the calling message's entityId to resolve the owner world.");
    }
    const worlds = await findWorldsForOwner(runtime, ownerEntityId);
    const world = worlds?.find((w) => w.metadata?.settings);
    if (!world) {
        return fail("NO_OWNER_WORLD", "No world with a settings registry was found for the calling owner.");
    }
    const salt = getSalt();
    const rawSettings = world.metadata?.settings;
    const worldSettings = rawSettings
        ? unsaltWorldSettings(rawSettings, salt)
        : undefined;
    if (!worldSettings) {
        return fail("NO_SETTINGS_REGISTRY", "The owner world has no settings registry.");
    }
    const registry = worldSettings.settings ?? {};
    const next = { ...registry };
    const applied = [];
    const skipped = [];
    for (const update of updates) {
        const setting = next[update.key];
        if (!setting) {
            skipped.push({ key: update.key, reason: "UNKNOWN_KEY" });
            continue;
        }
        if (setting.dependsOn.length) {
            const depsMet = setting.dependsOn.every((dep) => next[dep] && next[dep].value !== null);
            if (!depsMet) {
                skipped.push({ key: update.key, reason: "DEPENDENCY_NOT_MET" });
                continue;
            }
        }
        next[update.key] = { ...setting, value: update.value };
        applied.push(update);
        if (typeof setting.onSetAction === "function") {
            setting.onSetAction(update.value);
        }
    }
    if (!applied.length) {
        return fail("NO_VALID_UPDATES", "No valid setting updates were applied.", {
            skipped,
        });
    }
    const merged = { ...worldSettings, settings: next };
    if (!world.metadata)
        world.metadata = {};
    world.metadata.settings = saltWorldSettings(merged, salt);
    try {
        await runtime.updateWorld(world);
    }
    catch (err) {
        logger.error({
            error: err instanceof Error ? err.stack : String(err),
            worldId: world.id,
        }, "[SETTINGS] set failed to persist world settings");
        return fail("SETTINGS_SET_FAILED", `Failed to persist setting updates: ${err instanceof Error ? err.message : String(err)}`);
    }
    return ok(`Updated ${applied.length} setting${applied.length === 1 ? "" : "s"}.`, {
        op: "set",
        applied,
        skipped,
        worldId: world.id,
    });
}
export function normalizeCodingBackend(value) {
    if (typeof value !== "string")
        return undefined;
    const v = value.trim().toLowerCase().replace(/_/g, "-");
    if (!v)
        return undefined;
    const resolved = CODING_BACKEND_ALIASES[v] ?? v;
    return CODING_BACKENDS.includes(resolved)
        ? resolved
        : undefined;
}
/** Parse a `{ coding: {...} }`-shaped routing object into a CodingAxisRouting. */
function parseCodingAxisObject(parsed) {
    const coding = isRecord(parsed) && isRecord(parsed.coding) ? parsed.coding : {};
    const out = {};
    if (typeof coding.default === "string")
        out.default = coding.default;
    if (isRecord(coding.byTag)) {
        const byTag = {};
        for (const [k, val] of Object.entries(coding.byTag)) {
            if (typeof val === "string")
                byTag[k.toLowerCase()] = val;
        }
        if (Object.keys(byTag).length > 0)
            out.byTag = byTag;
    }
    if (Array.isArray(coding.allow)) {
        const allow = coding.allow.filter((v) => typeof v === "string");
        out.allow = allow;
    }
    return out;
}
export function readBackendRouting(config) {
    const raw = config.env?.ELIZA_BACKEND_ROUTING;
    let parsed;
    if (typeof raw === "string") {
        try {
            parsed = JSON.parse(raw);
        }
        catch {
            parsed = undefined;
        }
    }
    else {
        parsed = raw;
    }
    return parseCodingAxisObject(parsed);
}
export function hasLoadedTextProvider(runtime, provider) {
    const models = runtime.models;
    if (!(models instanceof Map))
        return false;
    return BRAIN_MODEL_KEYS.some((key) => models.get(key)?.some((handler) => handler.provider === provider));
}
/**
 * The EFFECTIVE coding routing the orchestrator actually uses — its resolver
 * reads `character.settings.routing.coding` first, then the
 * `ELIZA_BACKEND_ROUTING` config-env JSON. Mirror that precedence so show/set
 * report and mutate what truly takes effect (a character-declared policy would
 * otherwise silently shadow a config-env write).
 */
function readEffectiveCodingRouting(runtime, config) {
    const fromCharacter = parseCodingAxisObject(runtime.character?.settings?.routing);
    if (fromCharacter.default ||
        fromCharacter.byTag ||
        fromCharacter.allow !== undefined) {
        return { routing: fromCharacter, source: "character" };
    }
    const fromEnv = readBackendRouting(config);
    if (fromEnv.default || fromEnv.byTag || fromEnv.allow !== undefined) {
        return { routing: fromEnv, source: "env" };
    }
    return { routing: {}, source: "none" };
}
function handleShowBackends(runtime) {
    const config = loadElizaConfig();
    const { routing: coding } = readEffectiveCodingRouting(runtime, config);
    const brain = (typeof runtime.getSetting === "function"
        ? runtime.getSetting("ELIZA_BRAIN_PROVIDER")
        : null) ?? null;
    const codingLines = [
        `- coding default: ${coding.default ?? "(operator pin / planner choice)"}`,
    ];
    if (coding.byTag && Object.keys(coding.byTag).length > 0) {
        for (const [tag, backend] of Object.entries(coding.byTag)) {
            codingLines.push(`- coding when ${tag}: ${backend}`);
        }
    }
    if (coding.allow && coding.allow.length > 0) {
        codingLines.push(`- coding allowed (lock-list): ${coding.allow.join(", ")}`);
    }
    const text = [
        "Current backend routing:",
        ...codingLines,
        `- chat brain: ${brain || "(boot default)"}`,
    ].join("\n");
    return ok(text, {
        op: "show_backends",
        coding,
        brain,
    });
}
function handleSetBackend(runtime, params) {
    const axisRaw = typeof params.axis === "string" ? params.axis.trim().toLowerCase() : "";
    const axis = axisRaw === "brain" ? "brain" : "coding";
    if (axis === "brain") {
        const provider = trimToString(params.backend, 64)?.toLowerCase();
        if (!provider) {
            return fail("SETTINGS_BACKEND_INVALID", "set_backend for the brain needs a `backend` provider id (e.g. anthropic, openai, cerebras).");
        }
        if (!hasLoadedTextProvider(runtime, provider)) {
            return fail("SETTINGS_BACKEND_UNAVAILABLE", `Cannot set chat brain to \`${provider}\`: no loaded text-generation handler is registered for that provider.`, { provider });
        }
        const config = loadElizaConfig();
        config.env = { ...(config.env ?? {}), ELIZA_BRAIN_PROVIDER: provider };
        saveElizaConfig(config);
        mirrorSavedConfigToLive(config);
        // Immediate effect: the runtime's useModel override reads this via getSetting.
        runtime.setSetting?.("ELIZA_BRAIN_PROVIDER", provider);
        return ok(`Chat brain provider set to \`${provider}\`. It takes effect on the next message and stays until the AI provider is changed.`, { op: "set_backend", axis: "brain", provider });
    }
    const backend = normalizeCodingBackend(params.backend);
    if (!backend) {
        return fail("SETTINGS_BACKEND_INVALID", `set_backend for coding needs a known \`backend\`. One of: ${CODING_BACKENDS.join(", ")}.`, { provided: params.backend ?? null });
    }
    const tagRaw = typeof params.tag === "string" ? params.tag.trim().toLowerCase() : "";
    const tag = DIFFICULTY_TAGS.includes(tagRaw)
        ? tagRaw
        : "";
    const config = loadElizaConfig();
    // Start from the EFFECTIVE routing (character first, else env) so we mutate
    // whatever currently wins and preserve any operator allow lock-list.
    const { routing: coding } = readEffectiveCodingRouting(runtime, config);
    if (coding.allow !== undefined) {
        const allowed = coding.allow
            .map((value) => normalizeCodingBackend(value))
            .filter((value) => Boolean(value));
        if (!allowed.includes(backend)) {
            return fail("SETTINGS_BACKEND_DISALLOWED", `Cannot route coding tasks to \`${backend}\`: it is outside the configured coding backend allow-list.`, { backend, allow: allowed });
        }
    }
    if (tag) {
        coding.byTag = { ...(coding.byTag ?? {}), [tag]: backend };
    }
    else {
        coding.default = backend;
    }
    // Persist to the config-env JSON for durability across restarts.
    config.env = {
        ...(config.env ?? {}),
        ELIZA_BACKEND_ROUTING: JSON.stringify({ coding }),
    };
    saveElizaConfig(config);
    mirrorSavedConfigToLive(config);
    // Also write through to the in-memory character at the HIGHEST precedence the
    // orchestrator reads. Without this, a character that already declares
    // routing.coding would shadow the config-env write and the command would
    // report success with zero effect. Mutating the live character makes the
    // change effective on the next spawn with no restart, shadow-proof.
    const character = runtime.character;
    if (character) {
        character.settings ??= {};
        const settings = character.settings;
        settings.routing ??= {};
        settings.routing.coding = coding;
    }
    const scope = tag ? `${tag} coding tasks` : "coding tasks (default)";
    return ok(`Routing ${scope} to \`${backend}\`. Takes effect on the next sub-agent spawn — no restart.`, { op: "set_backend", axis: "coding", backend, tag: tag || null });
}
// ── Action ───────────────────────────────────────────────────────────────
export const settingsAction = {
    name: "SETTINGS",
    contexts: ["general", "settings", "admin", "system", "agent_internal"],
    contextGate: { anyOf: ["general", "settings", "admin", "system"] },
    roleGate: { minRole: "OWNER" },
    similes: [
        "CHANGE_SETTING",
        "UPDATE_SETTINGS",
        "SETTINGS_WRITE",
        "TOGGLE_SETTING",
        // Old leaf action names
        "UPDATE_AI_PROVIDER",
        "TOGGLE_CAPABILITY",
        "SET_USER_NAME",
        "SET_OWNER_NAME",
        "UPDATE_OWNER_NAME",
        // Common aliases
        "REMEMBER_NAME",
        "SAVE_NAME",
        "SET_NAME",
        // Backend routing control
        "SET_BACKEND",
        "SET_CODING_BACKEND",
        "SET_BRAIN_BACKEND",
        "SHOW_BACKENDS",
        "ROUTE_BACKEND",
    ],
    description: "Owner-only settings action. Update the AI provider, toggle a capability, set the owner display name, write world settings, inspect backend routing, or select the backend for coding tasks and chat. Use action=update_ai_provider|toggle_capability|set_owner_name|set|show_backends|set_backend.",
    descriptionCompressed: "owner settings: provider, capability, display name, world settings, backend routing",
    routingHint: "Use SETTINGS for provider, capability, owner name, world settings, and backend routing changes. Use VIEWS to open a settings page.",
    validate: async () => true,
    parameters: [
        {
            name: "action",
            description: `Operation discriminator. One of: ${SETTINGS_OPS.join(", ")}.`,
            required: true,
            schema: { type: "string", enum: [...SETTINGS_OPS] },
        },
        {
            name: "provider",
            description: `[update_ai_provider] AI provider id (${AI_PROVIDER_IDS}).`,
            required: false,
            schema: { type: "string" },
        },
        {
            name: "apiKey",
            description: "[update_ai_provider] Optional API key for the provider.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "modelConfigs",
            description: "[update_ai_provider] Optional model slot overrides — `nano|small|medium|large|mega` or `primary`.",
            required: false,
            schema: {
                type: "object",
                properties: Object.fromEntries(["primary", ...MODEL_SLOTS].map((slot) => [
                    slot,
                    { type: "string" },
                ])),
            },
        },
        {
            name: "capability",
            description: `[toggle_capability] Capability key. One of: ${CAPABILITY_KEYS.join(", ")}.`,
            required: false,
            schema: { type: "string", enum: [...CAPABILITY_KEYS] },
        },
        {
            name: "enabled",
            description: "[toggle_capability] Boolean enable flag.",
            required: false,
            schema: { type: "boolean" },
        },
        {
            name: "name",
            description: "[set_owner_name] New owner display name, preserved in full after trimming outer whitespace.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "axis",
            description: "[set_backend] Which backend to change: 'coding' (the coding sub-agent, default) or 'brain' (the chat/planner model).",
            required: false,
            schema: { type: "string", enum: ["coding", "brain"] },
        },
        {
            name: "backend",
            description: "[set_backend] The backend to route to. For coding: elizaos, pi-agent, claude, codex, kimi, or grok. For brain: a loaded provider id (e.g. anthropic, openai, cerebras).",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "tag",
            description: "[set_backend, coding only] Optional difficulty this routing applies to: 'simple', 'moderate', or 'hard'. Omit to set the default coding backend for all difficulties.",
            required: false,
            schema: { type: "string", enum: [...DIFFICULTY_TAGS] },
        },
        {
            name: "key",
            description: "[set] Setting registry key.",
            required: false,
            schema: { type: "string" },
        },
        {
            name: "value",
            description: "[set] Setting value (string | boolean | number).",
            required: false,
            schema: {
                anyOf: [
                    { type: "string" },
                    { type: "number" },
                    { type: "boolean" },
                ],
            },
        },
        {
            name: "updates",
            description: "[set] Optional array of `{ key, value }` for bulk writes.",
            required: false,
            schema: {
                type: "array",
                items: {
                    type: "object",
                    properties: {
                        key: { type: "string" },
                        value: {
                            anyOf: [
                                { type: "string" },
                                { type: "number" },
                                { type: "boolean" },
                            ],
                        },
                    },
                    required: ["key", "value"],
                },
            },
        },
    ],
    handler: async (runtime, message, _state, options, callback) => {
        const params = readParams(options);
        const op = params.action ?? params.subaction ?? params.op;
        switch (op) {
            case "update_ai_provider":
                return handleUpdateAiProvider(params);
            case "toggle_capability":
                return handleToggleCapability(params);
            case "set_owner_name":
                return handleSetOwnerName(params);
            case "set":
                return handleSet(runtime, message.entityId, params);
            case "show_backends":
                return handleShowBackends(runtime);
            case "set_backend":
                return handleSetBackend(runtime, params);
            default:
                return fail("SETTINGS_INVALID", `SETTINGS requires \`action\`. One of: ${SETTINGS_OPS.join(", ")}.`, { op: typeof op === "string" ? op : null });
        }
    },
    examples: [
        [
            {
                name: "{{name1}}",
                content: { text: "Switch to Anthropic with my API key sk-ant-xxx." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Switched AI provider to Anthropic. Restart the agent to load the new provider.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Turn off the wallet capability." },
            },
            {
                name: "{{agentName}}",
                content: { text: "Capability wallet is now disabled." },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "Change my display name to Sam." },
            },
            {
                name: "{{agentName}}",
                content: { text: 'Owner name set to "Sam".' },
            },
        ],
    ],
};
