export declare const contactAction: import("@elizaos/core").Action, registerEntitySearchCategory: (runtime: import("@elizaos/core").IAgentRuntime) => void;
