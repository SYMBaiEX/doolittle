/**
 * CONNECT_ACCOUNT — surface the in-chat "add another account" entry point.
 *
 * When the user asks to add / connect / log into another AI provider account
 * ("add another claude account", "connect a second codex account", "sign in
 * with a different account"), this action emits an `accountConnect` structured
 * field on the assistant turn. The chat renderer turns that into the
 * `AccountConnectBlock` (per-provider count + "Add account") which opens the
 * existing, already-audited `AddAccountDialog` OAuth / API-key flow. The action
 * does NOT create or manage credentials itself — it only offers the shortcut.
 *
 * Provider ids are sourced from SUBSCRIPTION_PROVIDER_METADATA; only providers
 * whose availability is "available" are offered. Claude → "anthropic-subscription",
 * Codex → "openai-codex". When the user doesn't name a provider, both are offered.
 */
import type { Action } from "@elizaos/core";
/**
 * Subscription providers that can be connected in-chat, in offer order. Only
 * providers whose availability is "available" and whose add-account surface is
 * an OAuth login are offered here — the two we can drive end-to-end from the
 * chat block (Claude subscription + OpenAI Codex).
 */
declare const CONNECTABLE_PROVIDERS: readonly ["anthropic-subscription", "openai-codex"];
type ConnectableProvider = (typeof CONNECTABLE_PROVIDERS)[number];
/**
 * True when the message expresses intent to add/connect another provider
 * account. Requires both an add-style verb AND an account/provider anchor so
 * unrelated "add a reminder" / "connect to the wifi" text does not match.
 */
export declare function messageWantsAccountConnect(text: string): boolean;
/** Resolve which connectable providers the user meant from their text. */
export declare function resolveRequestedProviders(text: string): ConnectableProvider[];
export declare const connectAccountAction: Action;
export {};
