import { resolveActionContexts } from "@elizaos/core";
const PAGE_KEYS = [
    "browser",
    "wallet",
    "settings",
    "connectors",
    "automation",
    "phone",
    "owner",
];
const PAGE_CONTEXTS = {
    browser: ["browser"],
    wallet: ["wallet"],
    settings: ["settings"],
    connectors: ["connectors"],
    automation: ["automation"],
    phone: ["phone"],
    owner: [
        "tasks",
        "calendar",
        "email",
        "contacts",
        "health",
        "subscriptions",
        "screen_time",
        "automation",
        "messaging",
    ],
};
const ALL_PAGE_CONTEXTS = Array.from(new Set(PAGE_KEYS.flatMap((page) => PAGE_CONTEXTS[page])));
function normalizeActionName(value) {
    return value.trim().toUpperCase();
}
function normalizeContext(context) {
    return `${context}`.toLowerCase();
}
function readPageKey(value) {
    if (typeof value !== "string")
        return undefined;
    const normalized = value.trim().toLowerCase();
    return PAGE_KEYS.includes(normalized)
        ? normalized
        : undefined;
}
function readParameters(options) {
    const parameters = options?.parameters ?? {};
    const explicitPage = typeof parameters.page === "string" ? parameters.page : undefined;
    const explicitAction = typeof parameters.action === "string" ? parameters.action : undefined;
    const childParameters = {};
    for (const [key, value] of Object.entries(parameters)) {
        if (key === "page" || key === "action")
            continue;
        childParameters[key] = value;
    }
    return {
        page: explicitPage,
        action: explicitAction,
        parameters: childParameters,
    };
}
function isPageDelegate(action) {
    return Array.isArray(action.actionGroup?.contexts);
}
function actionMatchesName(action, name) {
    if (normalizeActionName(action.name) === name) {
        return true;
    }
    return (action.similes ?? []).some((simile) => normalizeActionName(simile) === name);
}
function actionMatchesContexts(action, allowedContexts) {
    return resolveActionContexts(action).some((context) => allowedContexts.has(normalizeContext(context)));
}
/**
 * Names of the child actions actually registered for a page's context set.
 * Fed back on a failed dispatch so the planner corrects to a real capability
 * instead of blind-guessing further child names (observed live: CREATE_HABIT →
 * CREATE_REMINDER → SET_HABIT, three dead iterations with zero information).
 */
function availablePageChildActionNames(runtime, contexts) {
    const allowedContexts = new Set(contexts.map(normalizeContext));
    const names = new Set();
    for (const action of runtime.actions) {
        if (isPageDelegate(action))
            continue;
        if (!actionMatchesContexts(action, allowedContexts))
            continue;
        names.add(normalizeActionName(action.name));
    }
    return [...names].sort();
}
function findChildAction(runtime, actionName, contexts) {
    const normalizedName = normalizeActionName(actionName);
    const allowedContexts = new Set(contexts.map(normalizeContext));
    for (const action of runtime.actions) {
        if (isPageDelegate(action)) {
            continue;
        }
        if (!actionMatchesName(action, normalizedName)) {
            continue;
        }
        if (!actionMatchesContexts(action, allowedContexts)) {
            continue;
        }
        return action;
    }
    return null;
}
function readAliasedDiscriminator(action, requestedActionName) {
    const canonicalName = normalizeActionName(action.name);
    const requestedName = normalizeActionName(requestedActionName);
    const candidates = [];
    if (requestedName.startsWith(`${canonicalName}_`)) {
        candidates.push(requestedName.slice(canonicalName.length + 1));
    }
    if (requestedName.endsWith(`_${canonicalName}`)) {
        candidates.push(requestedName.slice(0, -(canonicalName.length + 1)));
    }
    if (candidates.length === 0)
        return undefined;
    const discriminator = action.parameters?.find((parameter) => parameter.name === "action");
    return discriminator?.schema.enum?.find((value) => typeof value === "string" &&
        candidates.includes(normalizeActionName(value)));
}
function findStructurallyAliasedChildAction(runtime, actionName, contexts) {
    const allowedContexts = new Set(contexts.map(normalizeContext));
    for (const action of runtime.actions) {
        if (isPageDelegate(action) ||
            !actionMatchesContexts(action, allowedContexts)) {
            continue;
        }
        const discriminator = readAliasedDiscriminator(action, actionName);
        if (discriminator)
            return { action, discriminator };
    }
    return null;
}
function prepareAliasedChildParameters(action, explicit, discriminator, message) {
    const declaredNames = new Set((action.parameters ?? []).map((parameter) => parameter.name));
    const parameters = {};
    for (const [key, value] of Object.entries(explicit ?? {})) {
        if (action.allowAdditionalParameters || declaredNames.has(key)) {
            parameters[key] = value;
        }
    }
    parameters.action = discriminator;
    // A generated definition is not an authoritative create request. Umbrella
    // actions that accept seedPrompt must regenerate from the user's actual words
    // so a delegated alias cannot smuggle an invented graph past validation.
    const messageText = typeof message.content.text === "string" ? message.content.text.trim() : "";
    if (discriminator === "create" &&
        declaredNames.has("seedPrompt") &&
        messageText.length > 0) {
        parameters.seedPrompt = messageText;
    }
    return parameters;
}
export const pageDelegateAction = {
    name: "PAGE_DELEGATE",
    similes: [
        "PAGE_ACTIONS",
        "BROWSER_TOOLS",
        "WALLET_TOOLS",
        "CHARACTER_TOOLS",
        "SETTINGS_TOOLS",
        "CONNECTOR_TOOLS",
        "AUTOMATION_TOOLS",
        "PHONE_TOOLS",
        "OWNER_TOOLS",
        "PERSONAL_ASSISTANT_ACTIONS",
    ],
    // Automation owns canonical umbrella actions (WORKFLOW, TRIGGER, and
    // SCHEDULED_TASKS). Exposing this second umbrella in the same retrieval
    // context makes the planner choose a page wrapper and invent child names.
    // The fallback handler still accepts automation aliases from general chat,
    // but automation-planned turns see the domain actions directly.
    contexts: [
        "general",
        ...ALL_PAGE_CONTEXTS.filter((context) => context !== "automation"),
    ],
    actionGroup: { contexts: ALL_PAGE_CONTEXTS },
    roleGate: { minRole: "OWNER" },
    allowAdditionalParameters: true,
    description: `Owner-only main-chat parent action. Routes a request to a child action under one of the page contexts (${PAGE_KEYS.join(", ")}). Call shape: { page: "<PAGE>", action: "<CHILD_NAME>", ...child fields }. The child action's parameter names go at the top level alongside \`page\` and \`action\` — for example, to navigate the browser: \`{ "page": "browser", "action": "BROWSER", "subaction": "navigate", "url": "https://example.com" }\`. Page-scoped chats expose the child actions directly without going through PAGE_DELEGATE.`,
    descriptionCompressed: "PAGE_DELEGATE {page browser|wallet|settings|connectors|phone|owner, action CHILD}",
    routingHint: 'main-chat browser/wallet/settings/connectors/phone/owner data operations -> PAGE_DELEGATE. Workflow lifecycle requests must call WORKFLOW directly with its action parameter; never wrap them in PAGE_DELEGATE or invent WORKFLOW_CREATE/CREATE_WORKFLOW. Do not use PAGE_DELEGATE for UI view/window/panel/app navigation, opening/closing views, view manager, split/tile layout, or notes/calendar/notepad view switching; those belong to VIEWS. Browser web navigation still uses {page:"browser", action:"BROWSER_OPEN", url} or {page:"browser", action:"BROWSER", subaction:"open", url}.',
    validate: async () => true,
    handler: async (runtime, message, state, options, callback) => {
        const params = readParameters(options);
        const page = readPageKey(params.page);
        if (!page) {
            return {
                success: false,
                text: `PAGE_DELEGATE requires a page parameter (one of: ${PAGE_KEYS.join(", ")}).`,
            };
        }
        const requestedAction = params.action?.trim();
        if (!requestedAction) {
            return {
                success: false,
                text: `PAGE_DELEGATE requires an action parameter naming the child action to run on the ${page} page.`,
            };
        }
        const childContexts = PAGE_CONTEXTS[page];
        let childAction = findChildAction(runtime, requestedAction, childContexts);
        let childParameters = params.parameters ?? {};
        let aliasedDiscriminator;
        if (childAction) {
            aliasedDiscriminator = readAliasedDiscriminator(childAction, requestedAction);
        }
        else {
            const structurallyAliased = findStructurallyAliasedChildAction(runtime, requestedAction, childContexts);
            if (structurallyAliased) {
                childAction = structurallyAliased.action;
                aliasedDiscriminator = structurallyAliased.discriminator;
            }
        }
        if (!childAction) {
            // Structured, non-retryable failure: the same page+action combination
            // cannot succeed later this turn (registration does not change
            // mid-turn), and listing what IS registered turns the next planner
            // iteration into a correction instead of another guess.
            const availableActions = availablePageChildActionNames(runtime, childContexts);
            return {
                success: false,
                text: `${requestedAction} is not available on the ${page} page.` +
                    (availableActions.length > 0
                        ? ` Actions available on the ${page} page: ${availableActions.join(", ")}.`
                        : ` No child actions are registered for the ${page} page in this deployment.`),
                data: {
                    actionName: "PAGE_DELEGATE",
                    code: "PAGE_CHILD_UNAVAILABLE",
                    page,
                    requestedAction,
                    availableActions,
                    retryable: false,
                },
            };
        }
        if (!(await childAction.validate(runtime, message, state))) {
            return {
                success: false,
                text: `${childAction.name} is not available for this request.`,
                data: {
                    actionName: "PAGE_DELEGATE",
                    code: "PAGE_CHILD_VALIDATE_REJECTED",
                    page,
                    requestedAction: childAction.name,
                    retryable: false,
                },
            };
        }
        if (aliasedDiscriminator) {
            childParameters = prepareAliasedChildParameters(childAction, params.parameters, aliasedDiscriminator, message);
        }
        const childCallback = callback
            ? (response, actionName) => callback(response, actionName ?? childAction.name)
            : undefined;
        return ((await childAction.handler(runtime, message, state, {
            ...options,
            parameters: childParameters,
        }, childCallback)) ?? {
            success: true,
            text: `${childAction.name} completed.`,
        });
    },
    parameters: [
        {
            name: "page",
            description: "Page context to dispatch under. Selects the allowed child-action context set.",
            required: true,
            schema: { type: "string", enum: [...PAGE_KEYS] },
        },
        {
            name: "action",
            description: "Child action name to run. PAGE_DELEGATE consumes `action`, so the child never receives it: select a child operation with the <CHILD>_<operation> name, e.g. WALLET_TOKEN_INFO, SETTINGS_UPDATE_AI_PROVIDER, PLUGIN_LIST, CHARACTER_MODIFY. A bare child name (e.g. BROWSER) runs the child with only the other top-level fields.",
            required: true,
            schema: { type: "string" },
        },
    ],
    examples: [
        [
            {
                name: "{{name1}}",
                content: { text: "Open example.com in the browser." },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Routing to BROWSER for navigation.",
                    actions: ["PAGE_DELEGATE"],
                    thought: "Owner asked for a browser navigation; PAGE_DELEGATE dispatches to the BROWSER child action under the browser page.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "What is the price of SOL?" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Looking up SOL.",
                    actions: ["PAGE_DELEGATE"],
                    thought: "Token price request maps to the wallet page; PAGE_DELEGATE dispatches to the WALLET_TOKEN_INFO child.",
                },
            },
        ],
        [
            {
                name: "{{name1}}",
                content: { text: "What's on my calendar tomorrow?" },
            },
            {
                name: "{{agentName}}",
                content: {
                    text: "Pulling tomorrow's events.",
                    actions: ["PAGE_DELEGATE"],
                    thought: "Calendar query falls under the owner page; PAGE_DELEGATE dispatches to the CALENDAR_FEED child.",
                },
            },
        ],
    ],
};
