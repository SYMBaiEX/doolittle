import { MESSAGE_SOURCE_CLIENT_CHAT, resolveCanonicalOwnerIdForMessage, } from "@elizaos/core";
import { hasAdminAccess } from "../security/access.js";
function memoryCreatedAt(memory) {
    return typeof memory.createdAt === "number" ? memory.createdAt : 0;
}
function memoryText(memory) {
    return typeof memory.content.text === "string" ? memory.content.text : "";
}
/**
 * Fetch recent messages from the owner's client_chat rooms.
 * Returns messages newest-first.
 */
async function fetchOwnerChatMessages(runtime, adminEntityId) {
    const roomIds = await runtime.getRoomsForParticipant(adminEntityId);
    if (roomIds.length === 0)
        return [];
    // Resolve rooms and filter to client_chat source
    const rooms = await runtime.getRoomsByIds(roomIds);
    const roomById = new Map(rooms.map((room) => [room.id, room]));
    const roomResults = roomIds.map((id) => roomById.get(id));
    const chatRooms = roomResults.filter((r) => r != null && r.source === MESSAGE_SOURCE_CLIENT_CHAT);
    if (chatRooms.length === 0)
        return [];
    // Collect every matching client_chat room id.
    const targetRoomIds = chatRooms.map((r) => r.id);
    const memories = await runtime.getMemoriesByRoomIds({
        tableName: "messages",
        roomIds: targetRoomIds,
    });
    // Sort newest-first (getMemoriesByRoomIds default may vary)
    memories.sort((a, b) => {
        const ta = memoryCreatedAt(a);
        const tb = memoryCreatedAt(b);
        return tb - ta;
    });
    return memories;
}
function formatMessages(messages, agentId) {
    if (messages.length === 0)
        return "";
    // Display oldest-first for natural reading order
    const ordered = [...messages].reverse();
    const lines = ordered.map((m) => {
        const sender = m.entityId === agentId ? "Agent" : "Owner";
        const text = memoryText(m);
        return `[${sender}] ${text}`;
    });
    return `# Recent Owner Conversation (Eliza App)\n${lines.join("\n")}`;
}
export const adminPanelProvider = createAdminPanelProvider();
export function createAdminPanelProvider() {
    return {
        name: "adminPanel",
        description: "Surfaces the owner's recent Eliza app chat so the agent has context across platforms.",
        descriptionCompressed: "surface owner recent Eliza app chat agent context across platform",
        dynamic: true,
        position: 14,
        // `admin` only: this is the complete owner app conversation (64K chars
        // live on 2026-09-05). A settings turn ("remember I prefer…", "change my
        // response style") does not need it, and RECENT_CONVERSATIONS already
        // carries cross-room continuity in manifest form.
        contexts: ["admin"],
        contextGate: { anyOf: ["admin"] },
        cacheStable: false,
        cacheScope: "turn",
        roleGate: { minRole: "ADMIN" },
        async get(runtime, message, _state) {
            const empty = {
                text: "",
                values: { hasAdminChat: false },
                data: { messageCount: 0 },
            };
            if (!(await hasAdminAccess(runtime, message))) {
                return empty;
            }
            const adminEntityId = await resolveCanonicalOwnerIdForMessage(runtime, message);
            if (!adminEntityId) {
                return empty;
            }
            const messages = await fetchOwnerChatMessages(runtime, adminEntityId);
            const text = formatMessages(messages, runtime.agentId);
            return {
                text,
                values: { hasAdminChat: messages.length > 0 },
                data: { messageCount: messages.length },
            };
        },
    };
}
