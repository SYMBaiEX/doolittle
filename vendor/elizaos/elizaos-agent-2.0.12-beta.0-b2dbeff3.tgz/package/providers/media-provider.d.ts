import { type AudioGenerationOptions, type AudioGenerationProvider, type AudioGenerationResult, type ImageGenerationOptions, type ImageGenerationProvider, type MediaImageGenerationResult as ImageGenerationResult, type MediaProviderResult, type VideoGenerationOptions, type VideoGenerationProvider, type VideoGenerationResult, type VisionAnalysisOptions, type VisionAnalysisProvider, type VisionAnalysisResult } from "@elizaos/host/protocol";
export type { AudioGenerationOptions, AudioGenerationProvider, AudioGenerationResult, ImageGenerationOptions, ImageGenerationProvider, MediaImageGenerationResult as ImageGenerationResult, MediaProviderResult, VideoGenerationOptions, VideoGenerationProvider, VideoGenerationResult, VisionAnalysisOptions, VisionAnalysisProvider, VisionAnalysisResult, } from "@elizaos/host/protocol";
export { fetchMediaProviderResponse as fetchWithTimeout } from "@elizaos/host/protocol";
export { AnthropicVisionProvider } from "@elizaos/plugin-anthropic/direct-media";
export { OpenAIImageProvider, OpenAIVideoProvider, OpenAIVisionProvider, } from "@elizaos/plugin-openai/direct-media";
/**
 * Media Provider Abstraction Layer
 *
 * Provides a single interface for media generation across multiple providers:
 * - Image Generation: FAL.ai, OpenAI (DALL-E), Google (Imagen), xAI
 * - Video Generation: FAL.ai, OpenAI (Sora), Google (Veo), Eliza Cloud
 * - Audio Generation: Suno, ElevenLabs (SFX), Eliza Cloud
 * - Vision (Analysis): OpenAI, Google, Anthropic, xAI, Eliza Cloud
 *
 * Follows the same pattern as TTS provider selection:
 * - "cloud" mode uses Eliza Cloud (no API key needed)
 * - "own-key" mode uses the user's own API keys
 */
import type { AudioGenConfig, ImageConfig, MediaConfig, VideoConfig, VisionConfig } from "@elizaos/contracts";
export declare class FalImageProvider implements ImageGenerationProvider {
    name: string;
    private apiKey;
    private model;
    private baseUrl;
    constructor(config: NonNullable<ImageConfig["fal"]>);
    generate(options: ImageGenerationOptions): Promise<MediaProviderResult<ImageGenerationResult>>;
}
export declare class FalVideoProvider implements VideoGenerationProvider {
    name: string;
    private apiKey;
    private model;
    private baseUrl;
    constructor(config: NonNullable<VideoConfig["fal"]>);
    generate(options: VideoGenerationOptions): Promise<MediaProviderResult<VideoGenerationResult>>;
}
export declare class GoogleImageProvider implements ImageGenerationProvider {
    name: string;
    private apiKey;
    private model;
    private aspectRatio;
    constructor(config: NonNullable<ImageConfig["google"]>);
    generate(options: ImageGenerationOptions): Promise<MediaProviderResult<ImageGenerationResult>>;
}
export declare class GoogleVideoProvider implements VideoGenerationProvider {
    name: string;
    private apiKey;
    private model;
    constructor(config: NonNullable<VideoConfig["google"]>);
    generate(options: VideoGenerationOptions): Promise<MediaProviderResult<VideoGenerationResult>>;
    private pollOperation;
}
export declare class GoogleVisionProvider implements VisionAnalysisProvider {
    name: string;
    private apiKey;
    private model;
    constructor(config: NonNullable<VisionConfig["google"]>);
    analyze(options: VisionAnalysisOptions): Promise<MediaProviderResult<VisionAnalysisResult>>;
}
export declare class XAIImageProvider implements ImageGenerationProvider {
    name: string;
    private apiKey;
    private model;
    constructor(config: NonNullable<ImageConfig["xai"]>);
    generate(options: ImageGenerationOptions): Promise<MediaProviderResult<ImageGenerationResult>>;
}
export declare class XAIVisionProvider implements VisionAnalysisProvider {
    name: string;
    private apiKey;
    private model;
    constructor(config: NonNullable<VisionConfig["xai"]>);
    analyze(options: VisionAnalysisOptions): Promise<MediaProviderResult<VisionAnalysisResult>>;
}
export declare class FalAudioProvider implements AudioGenerationProvider {
    name: string;
    private apiKey;
    private model;
    private baseUrl;
    private secondsStart?;
    private secondsTotal?;
    private steps?;
    private timeoutMs;
    private extraInput?;
    constructor(config: NonNullable<AudioGenConfig["fal"]>);
    generate(options: AudioGenerationOptions): Promise<MediaProviderResult<AudioGenerationResult>>;
}
export declare class ElevenLabsAudioProvider implements AudioGenerationProvider {
    name: string;
    private apiKey;
    private baseUrl;
    private config;
    private timeoutMs;
    constructor(config: NonNullable<AudioGenConfig["elevenlabs"]>);
    generate(options: AudioGenerationOptions): Promise<MediaProviderResult<AudioGenerationResult>>;
    private headers;
    private generateSoundEffect;
    private generateMusic;
    private generateSpeech;
}
export declare class SunoAudioProvider implements AudioGenerationProvider {
    name: string;
    private apiKey;
    private model;
    private baseUrl;
    constructor(config: NonNullable<AudioGenConfig["suno"]>);
    generate(options: AudioGenerationOptions): Promise<MediaProviderResult<AudioGenerationResult>>;
}
export interface MediaProviderFactoryOptions {
    elizaCloudBaseUrl?: string;
    elizaCloudApiKey?: string;
    /** When true, factories will NOT fall back to ElizaCloud providers. */
    cloudMediaDisabled?: boolean;
}
export declare function createImageProvider(config: ImageConfig | undefined, options: MediaProviderFactoryOptions): ImageGenerationProvider;
export declare function createVideoProvider(config: VideoConfig | undefined, options: MediaProviderFactoryOptions): VideoGenerationProvider;
export declare function createAudioProvider(config: AudioGenConfig | undefined, options: MediaProviderFactoryOptions): AudioGenerationProvider;
export declare function createVisionProvider(config: VisionConfig | undefined, options: MediaProviderFactoryOptions): VisionAnalysisProvider;
export interface MediaProviders {
    image: ImageGenerationProvider;
    video: VideoGenerationProvider;
    audio: AudioGenerationProvider;
    vision: VisionAnalysisProvider;
}
export declare function createMediaProviders(config: MediaConfig | undefined, options: MediaProviderFactoryOptions): MediaProviders;
