/**
 * Pending-permissions provider.
 *
 * Position `-5` — runs after the dynamic skill provider (`-10`) but before
 * neutral-priority providers so the planner sees pending permission state
 * alongside the active skill match.
 *
 * Surfaces only when `registry.pending()` is non-empty so we never bloat the
 * prompt for the steady state. Each line names the permission, current status,
 * and the most recent feature that was blocked. Denied-age labels fail closed
 * on non-finite timestamps so provider text never shows "NaN days ago".
 */
import { type PermissionState, type Provider } from "@elizaos/core";
export declare function formatPendingPermissionLine(state: PermissionState, now: number): string;
export declare function buildPendingPermissionsContext(states: PermissionState[], now?: number): string;
export declare const pendingPermissionsProvider: Provider;
