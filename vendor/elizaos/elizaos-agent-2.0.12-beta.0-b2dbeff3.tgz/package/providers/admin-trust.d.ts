/**
 * Provider that flags whether the current speaker is the canonical agent OWNER,
 * signalling that their contact/identity claims may be treated as trusted. Emits
 * the resolved owner id and speaker role, revealing the owner id only to
 * admin-visible callers. Gated to ADMIN.
 */
import type { Provider } from "@elizaos/core";
export declare const adminTrustProvider: Provider;
export declare function createAdminTrustProvider(): Provider;
