import { stringToUuid, toWellFormedUnicode } from "@elizaos/core";
import { extractConversationMetadataFromRoom, isAutomationConversationMetadata, } from "../api/conversation-metadata.js";
import { hasAdminAccess } from "../security/access.js";
import { formatRelativeTimestampPrefix, formatSpeakerLabel, } from "../shared/conversation-format.js";
/**
 * Normalizes a memory timestamp for ordering. A missing or non-finite
 * `createdAt` (NaN reaches this provider when a storage row carries an
 * unparseable timestamp) would otherwise make every comparison return NaN,
 * which the sort treats as "equal" and leaves the transcript in whatever order
 * storage returned it. Collapsing those to 0 keeps the ordering total so the
 * oldest-first transcript stays deterministic.
 */
export function safeCreatedAt(createdAt) {
    return Number.isFinite(createdAt) ? createdAt : 0;
}
export const automationTerminalBridgeProvider = {
    name: "automation-terminal-bridge",
    description: "Recent messages from the linked terminal conversation for the current automation room.",
    descriptionCompressed: "recent message link terminal conversation current automation room",
    dynamic: true,
    position: 5,
    contexts: ["automation", "agent_internal"],
    contextGate: { anyOf: ["automation", "agent_internal"] },
    cacheStable: false,
    cacheScope: "turn",
    roleGate: { minRole: "ADMIN" },
    async get(runtime, message) {
        if (!(await hasAdminAccess(runtime, message))) {
            return { text: "", values: {}, data: {} };
        }
        try {
            const currentRoom = await runtime.getRoom(message.roomId);
            const metadata = extractConversationMetadataFromRoom(currentRoom);
            if (!isAutomationConversationMetadata(metadata)) {
                return { text: "", values: {}, data: {} };
            }
            const terminalConversationId = metadata?.terminalBridgeConversationId;
            if (!terminalConversationId) {
                return { text: "", values: {}, data: {} };
            }
            const sourceRoomId = stringToUuid(`web-conv-${terminalConversationId}`);
            if (sourceRoomId === message.roomId) {
                return { text: "", values: {}, data: {} };
            }
            const memories = await runtime.getMemories({
                roomId: sourceRoomId,
                tableName: "messages",
            });
            const visibleMessages = memories
                .filter((entry) => entry.content.text)
                .sort((left, right) => safeCreatedAt(left.createdAt) - safeCreatedAt(right.createdAt));
            if (visibleMessages.length === 0) {
                return { text: "", values: {}, data: {} };
            }
            const lines = ["Linked terminal conversation:"];
            for (const mem of visibleMessages) {
                const speaker = formatSpeakerLabel(runtime, mem);
                const age = formatRelativeTimestampPrefix(mem.createdAt);
                const text = toWellFormedUnicode(mem.content.text ?? "");
                lines.push(`${age}${speaker}: ${text}`);
            }
            return {
                text: lines.join("\n"),
                values: {
                    terminalBridgeConversationId: terminalConversationId,
                    terminalBridgeMessageCount: visibleMessages.length,
                },
                data: {
                    conversationId: terminalConversationId,
                    messages: visibleMessages.map((entry) => ({
                        id: entry.id,
                        roomId: entry.roomId,
                        entityId: entry.entityId,
                        text: entry.content.text,
                        createdAt: entry.createdAt,
                    })),
                },
            };
        }
        catch (error) {
            // error-policy:J4 a failed room or history read must not read as "no
            // linked conversation": surface it and tell the model the bridge is
            // missing.
            runtime.reportError("AutomationTerminalBridgeProvider.get", error, {
                roomId: message.roomId,
            });
            return {
                text: "The linked terminal conversation is unavailable because its history read failed. Do not infer that the operator left no instructions; state the gap.",
                values: { terminalBridgeUnavailable: true },
                data: { terminalBridgeUnavailable: true },
            };
        }
    },
};
