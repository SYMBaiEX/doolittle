/**
 * Escalation trigger provider.
 *
 * Monitors conditions that may warrant escalating to the owner and injects
 * escalation context into the agent's prompt when triggers are detected.
 *
 * Checks:
 * 1. Active (unresolved) escalation in progress
 * 2. Owner inactive for 24+ hours (only during autonomous agent loops)
 * 3. Pending identity verification relationships for the current entity
 */
import { logger, resolveCanonicalOwnerIdForMessage } from "@elizaos/core";
import { hasAdminAccess } from "../security/access.js";
// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
/** Hours of owner inactivity before suggesting a check-in. */
const OWNER_INACTIVE_HOURS = 24;
const URGENCY_ORDER = {
    high: 3,
    medium: 2,
    low: 1,
};
const EMPTY = {
    text: "",
    values: { hasEscalationTriggers: false },
    data: {},
};
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
/**
 * Check when the owner last sent a message across their rooms.
 * Returns 0 if no messages found.
 *
 * Asks for exactly what it needs: the newest owner message per
 * room. Fetching every room's whole history to compute one
 * timestamp grows without bound, and a plain scan cap would be
 * wrong here — if the owner's last message fell beyond the
 * newest N messages, the cap would report no owner message at
 * all and suppress the true inactivity trigger.
 */
async function findLastOwnerMessageTimestamp(runtime, ownerEntityId) {
    const roomIds = await runtime.getRoomsForParticipant(ownerEntityId);
    if (roomIds.length === 0)
        return 0;
    const perRoom = await Promise.all(roomIds.map((roomId) => runtime.getMemories({
        tableName: "messages",
        roomId: roomId,
        authorEntityIds: [ownerEntityId],
        orderDirection: "desc",
        limit: 1,
    })));
    let latest = 0;
    for (const [newest] of perRoom) {
        if (newest?.createdAt != null && newest.createdAt > latest) {
            latest = newest.createdAt;
        }
    }
    return latest;
}
// ---------------------------------------------------------------------------
// Trigger checks
// ---------------------------------------------------------------------------
async function checkActiveEscalation(runtime, triggers) {
    try {
        const { EscalationService } = await import("../services/escalation.js");
        const active = EscalationService.getActiveEscalationSync(runtime);
        if (active && !active.resolved) {
            triggers.push({
                type: "active_escalation",
                message: `Active escalation in progress (step ${active.currentStep + 1}): "${active.reason}". Channels notified: ${active.channelsSent.join(", ")}. Owner has not responded yet.`,
                urgency: "high",
            });
        }
    }
    catch (err) {
        logger.debug(`[escalation-trigger] Could not check active escalation: ${String(err)}`);
    }
}
async function checkOwnerInactivity(runtime, message, triggers) {
    // Only run during autonomous agent loops (agent talking to itself).
    if (message.entityId !== runtime.agentId)
        return;
    const ownerEntityId = await resolveCanonicalOwnerIdForMessage(runtime, message);
    if (!ownerEntityId)
        return;
    const lastOwnerMessage = await findLastOwnerMessageTimestamp(runtime, ownerEntityId);
    if (lastOwnerMessage === 0)
        return;
    const hoursSinceOwner = (Date.now() - lastOwnerMessage) / (1000 * 60 * 60);
    if (hoursSinceOwner > OWNER_INACTIVE_HOURS) {
        triggers.push({
            type: "owner_inactive",
            message: `Owner last seen ${Math.round(hoursSinceOwner)} hours ago. Consider checking in if there are pending items.`,
            urgency: "low",
        });
    }
}
async function checkPendingVerifications(runtime, message, triggers) {
    try {
        const relationships = await runtime.getRelationships({
            entityIds: [message.entityId],
            tags: ["identity_link"],
        });
        const pending = relationships.filter((r) => {
            const meta = r.metadata;
            return meta?.status === "proposed";
        });
        if (pending.length > 0) {
            triggers.push({
                type: "pending_verifications",
                message: `${pending.length} identity verification(s) pending for the current user. You can ask them to confirm or have an admin verify.`,
                urgency: "medium",
            });
        }
    }
    catch {
        // Silently skip if relationships unavailable
    }
}
// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------
export const escalationTriggerProvider = createEscalationTriggerProvider();
export function createEscalationTriggerProvider() {
    return {
        name: "escalationTrigger",
        description: "Monitors conditions that may warrant escalating to the owner. Injects escalation context when triggers are detected.",
        descriptionCompressed: "monitor condition warrant escalat owner inject escalation context trigger detect",
        dynamic: true,
        position: 15,
        contexts: ["general"],
        contextGate: { anyOf: ["general"] },
        cacheStable: false,
        cacheScope: "turn",
        roleGate: { minRole: "USER" },
        async get(runtime, message, _state) {
            const triggers = [];
            const isAdminViewer = await hasAdminAccess(runtime, message);
            if (isAdminViewer) {
                await Promise.all([
                    checkActiveEscalation(runtime, triggers),
                    checkOwnerInactivity(runtime, message, triggers),
                    checkPendingVerifications(runtime, message, triggers),
                ]);
            }
            else {
                await checkPendingVerifications(runtime, message, triggers);
            }
            if (triggers.length === 0) {
                return EMPTY;
            }
            const lines = triggers.map((t) => `- [${t.urgency.toUpperCase()}] ${t.message}`);
            const text = `# Escalation Context\n${lines.join("\n")}`;
            const highestUrgency = triggers.reduce((max, t) => {
                return (URGENCY_ORDER[t.urgency] ?? 0) > (URGENCY_ORDER[max] ?? 0)
                    ? t.urgency
                    : max;
            }, "low");
            return {
                text,
                values: {
                    hasEscalationTriggers: true,
                    triggerCount: triggers.length,
                    highestUrgency,
                },
                data: { triggers },
            };
        },
    };
}
