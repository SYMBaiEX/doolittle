/**
 * World creation role backfill provider.
 *
 * Problem: When a new connector creates a new world after roles bootstrap,
 * the owner's role is not set in that world because `ensureOwnerRole()` only
 * runs at boot.
 *
 * Solution: On every message, if the current world has an ownerId but no
 * OWNER role entry, backfill it. This is idempotent -- after the first backfill,
 * later runs on the same world have nothing to update.
 *
 * Runs as a lightweight provider with a high position number (early/low
 * priority) so it does not add latency to prompt construction. Produces no
 * visible text in the agent context.
 */
import { type Provider } from "@elizaos/core";
export declare const roleBackfillProvider: Provider;
