/**
 * Live-state renderers for the per-view dashboard surfaces (wallet, character,
 * browser, apps, automations, knowledge, transcripts). Each renderer pulls real
 * state — from the local agent API or the runtime's own stores — and formats a
 * compact, agent-readable brief for a given `ConversationScope`.
 *
 * A leaf module by design: it depends only on `@elizaos/core`, `@elizaos/core`,
 * and API-layer types, never on providers or services. Both the page-scoped
 * context provider (`page-scoped-context.ts`) and the proactive-interaction
 * decider (`../services/proactive-interaction-decider.ts`) consume it, so keeping
 * it a leaf avoids a providers ↔ services import cycle (#13587).
 *
 * Doctrine: never fabricate a zero. When a fetch fails, renderers return an
 * explicit "unavailable" line (agent-visible, not silence) and route the failure
 * through `runtime.reportError`; a genuinely empty result renders a designed
 * empty brief, distinct from an unreachable one.
 */
import type { ConversationScope } from "@elizaos/contracts";
import { type IAgentRuntime } from "@elizaos/core";
/**
 * Render the live-state brief for a `ConversationScope`. Returns null for scopes
 * that carry no live-state surface (connectors/plugins/settings today), which
 * callers render as "no live state" rather than an error.
 */
export declare function renderLiveStateForScope(runtime: IAgentRuntime, scope: ConversationScope): Promise<string | null>;
/**
 * Live-state brief for the proactive-interaction judge, keyed by view id.
 * Returns null when the view has no live-state surface. Shared with the
 * page-scoped context provider through {@link renderLiveStateForScope}; kept in
 * this leaf module so the decider (services) can reach it without a providers ↔
 * services import cycle (#13587).
 */
export declare function renderViewLiveStateForJudge(runtime: IAgentRuntime, viewId: string): Promise<string | null>;
