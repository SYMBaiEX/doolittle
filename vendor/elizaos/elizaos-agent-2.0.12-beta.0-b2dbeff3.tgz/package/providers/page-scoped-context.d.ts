/**
 * Provider that injects operational context for a page-scoped dashboard chat —
 * the per-view chat surfaces (Browser, Character, Apps, Connectors, Plugins,
 * Settings, Automations, Wallet, and the automation-draft room). For the
 * conversation's scope it emits a static "brief" describing that view's action
 * vocabulary and guardrails, appends live state pulled from the local agent API
 * (running apps, wallet balances, browser tabs/bridge, character summary,
 * automation tasks), and a short tail of the originating main-chat conversation.
 * Gated to OWNER (enforced by applyPluginRoleGating). Subsection and
 * provider-boundary failures degrade gracefully and are routed to reportError so
 * they still surface through the RECENT_ERRORS provider.
 */
import { type Memory, type Provider, type UUID } from "@elizaos/core";
export declare function pruneMainChatTail(memories: Memory[], agentId: UUID, now: number): Memory[];
export declare const pageScopedContextProvider: Provider;
