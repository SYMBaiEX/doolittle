/**
 * Provider that recalls conversation snippets relevant to the current message,
 * re-ranked by similarity, from across all platforms. It combines a lexical
 * "hash memory" scan (mirroring the /api/memory/remember writer, so recall works
 * even when no embedding model is registered) with semantic search over the
 * shared per-turn recall-query embed; on embed failure it fails open to the
 * lexical hits alone. The two sources are independent and run concurrently, and
 * result-room tags resolve through one batched room read — this provider sits
 * on the composeState critical path of every reply, so it must not serialize
 * independent round-trips. Current-room messages are filtered out to avoid
 * echo, and hash-memory hits win on id overlap. Gated to USER.
 */
import { buildAccessContext, ChannelType, filterByAccessContext, getUserMessageText, getValidationKeywordTerms, markOwnerExclusiveDisclosureUsed, OWNER_PRIVATE_DESTINATION_DISCLOSURE_BASIS, recordOwnerExclusiveSuppression, revalidateOwnerExclusiveDisclosure, searchCanonicalConversationMemories, stringToUuid, } from "@elizaos/core";
import { embedRecallQuery, getEvaluatorProgressState, HISTORY_RETENTION_EVALUATOR, historyRetentionContext, priorDialogueOriginalText, renderProviderOriginalMessages, visibleHistoryEventIds, } from "@elizaos/plugin-assistant";
import { extractConversationMetadataFromRoom, isAutomationConversationMetadata, } from "../api/conversation-metadata.js";
import { HASH_MEMORY_SOURCE, rankByKeyword } from "../api/memory-routes.js";
import { agentIdentityName } from "../runtime/build-character-config.js";
import { formatRelativeTimestampPrefix, formatSpeakerLabel, roomSourceTag, } from "../shared/conversation-format.js";
const MATCH_THRESHOLD = 0.7;
// rankByKeyword returns a [0,1] max-normalized BM25 score. Require a hit to be at
// least half as relevant as the best match in the scan; BM25's IDF already
// down-weights common stop words ("you"/"are"), so weak/stop-word-only matches
// score far below a real hit and fall under this floor.
const MIN_HASH_MEMORY_SCORE = 0.5;
// Only a complete standalone greeting skips optional cross-room similarity
// search. This does not route the turn or remove current-room history. Short
// substantive queries (names, IDs) and greetings followed by requests still
// use recall; unknown languages/forms conservatively keep the retrieval path.
function isStandaloneGreeting(text) {
    return /^(?:(?:hi|hey|hello)(?: there)?|good morning|good afternoon|good evening|hola|bonjour|salut|hallo|こんにちは|你好)[\s.!！?？]*$/iu.test(text.trim());
}
function memoryText(memory) {
    return typeof memory.content.text === "string" ? memory.content.text : "";
}
function memoryCreatedAt(memory) {
    return typeof memory.createdAt === "number" ? memory.createdAt : 0;
}
// /api/memory/remember writes lexical "hash memories" into the messages table at
// a fixed room with content.source === "hash_memory" and NO embedding. When no
// TEXT_EMBEDDING model is registered (cloud agents booting without embed), the
// semantic searchMemories path never surfaces them, so mirror the writer here
// with a lexical scan + score.
async function loadHashMemories(runtime, query, accessContext) {
    const agentName = agentIdentityName(runtime.character)?.trim() || "Eliza";
    const roomId = stringToUuid(`${agentName}-hash-memory-room`);
    const memories = await runtime.getMemories({
        roomId,
        tableName: "messages",
        includeEmbedding: false,
        accessContext,
    });
    // Only hash memories are candidates; rank them together so BM25's IDF is
    // computed over the hash-memory corpus.
    const hashMemories = memories.filter((memory) => memory.content?.source ===
        HASH_MEMORY_SOURCE);
    return rankByKeyword(query, hashMemories, memoryText)
        .filter(({ score }) => score >= MIN_HASH_MEMORY_SCORE)
        .sort((left, right) => {
        if (right.score !== left.score)
            return right.score - left.score;
        return memoryCreatedAt(right.item) - memoryCreatedAt(left.item);
    })
        .map(({ item }) => item);
}
export const relevantConversationsProvider = {
    name: "relevant-conversations",
    description: "Semantically relevant conversation snippets from across all platforms, re-ranked by similarity to the current message.",
    descriptionCompressed: "relevant conversation snippets across platforms; rerank by current message",
    dynamic: true,
    position: 6,
    relevanceKeywords: getValidationKeywordTerms("provider.relevantConversations.relevance", {
        includeAllLocales: true,
    }),
    contexts: ["memory", "messaging"],
    contextGate: { anyOf: ["memory", "messaging"] },
    cacheStable: false,
    cacheScope: "turn",
    roleGate: { minRole: "USER" },
    async get(runtime, message, _state) {
        const text = getUserMessageText(message);
        if (!text.trim() || isStandaloneGreeting(text)) {
            return { text: "", values: {}, data: {} };
        }
        try {
            const currentRoom = await runtime.getRoom(message.roomId);
            if (isAutomationConversationMetadata(extractConversationMetadataFromRoom(currentRoom))) {
                return { text: "", values: {}, data: {} };
            }
            // Access-context resolution is required for both recall branches. If it
            // fails, the wholesale outer J4 boundary reports and suppresses the
            // provider instead of letting lexical and semantic recall disagree.
            const accessContext = await buildAccessContext(runtime, message);
            // This provider deliberately excludes the current room below, so every
            // result it could render is a cross-room disclosure. Fail closed before
            // lexical reads or embedding work unless the live destination is a
            // revalidated owner-private audience. The canonical search repeats this
            // check as defense in depth at the storage boundary.
            const disclosure = await revalidateOwnerExclusiveDisclosure(runtime, message);
            if (!disclosure.allowed ||
                disclosure.basis !== OWNER_PRIVATE_DESTINATION_DISCLOSURE_BASIS) {
                if (!disclosure.allowed) {
                    recordOwnerExclusiveSuppression(message, disclosure.reason);
                }
                return { text: "", values: {}, data: {} };
            }
            // The two recall sources are independent, so they run concurrently:
            // the lexical hash-memory scan overlaps the shared recall-query embed
            // and canonical semantic search instead of adding to the reply critical
            // path. Either branch still fails into the same wholesale outer degrade.
            const [hashMemories, semanticRecall] = await Promise.all([
                loadHashMemories(runtime, text, accessContext),
                (async () => {
                    const embedding = await embedRecallQuery(runtime, text);
                    if (!embedding || embedding.length === 0)
                        return null;
                    return searchCanonicalConversationMemories({
                        runtime,
                        embedding,
                        query: text,
                        agentId: runtime.agentId,
                        deliveryMessage: message,
                        matchThreshold: MATCH_THRESHOLD,
                        includeEmbedding: false,
                        excludeRoomIds: [message.roomId],
                    });
                })(),
            ]);
            const semanticMemories = semanticRecall?.items.map((item) => item.memory) ?? [];
            // Filter out messages from the current conversation to avoid echo and dedupe
            // by id (hash memories prepended so they win on overlap).
            const currentRoomId = message.roomId;
            const readable = filterByAccessContext([...hashMemories, ...semanticMemories], accessContext, runtime.agentId);
            const seenIds = new Set();
            const filtered = readable.filter((memory) => {
                if (!memory.content.text || memory.roomId === currentRoomId)
                    return false;
                if (!memory.id)
                    return true;
                if (seenIds.has(memory.id))
                    return false;
                seenIds.add(memory.id);
                return true;
            });
            if (filtered.some((memory) => memory.content?.source ===
                HASH_MEMORY_SOURCE)) {
                markOwnerExclusiveDisclosureUsed(message);
            }
            if (filtered.length === 0 &&
                semanticRecall?.availability === "unavailable") {
                return {
                    text: "Relevant past conversations are unavailable because matching messages were withheld by access policy.",
                    values: {
                        relevantConversationCount: 0,
                        relevantConversationAvailability: "unavailable",
                    },
                    data: {
                        messages: [],
                        withheld: semanticRecall.withheld,
                        availability: semanticRecall.availability,
                    },
                };
            }
            if (filtered.length === 0) {
                return { text: "", values: {}, data: {} };
            }
            // Resolve room details for source tags in ONE batched read. The
            // per-result getRoom loop this replaces paid one adapter round-trip per
            // distinct room every turn (the runtime's room memo TTL is shorter than
            // a turn gap), serially on the compose critical path.
            const roomCache = new Map();
            const roomIds = [];
            for (const mem of filtered) {
                if (mem.roomId && !roomCache.has(mem.roomId)) {
                    roomCache.set(mem.roomId, null);
                    roomIds.push(mem.roomId);
                }
            }
            try {
                for (const room of await runtime.getRoomsByIds(roomIds)) {
                    if (room.id)
                        roomCache.set(room.id, room);
                }
            }
            catch (error) {
                // error-policy:J4 room source tags degrade to untagged, but the
                // cosmetic lookup failure remains visible through diagnostics.
                runtime.reportError("RelevantConversationsProvider.roomTags", error, {
                    roomIds,
                });
            }
            const availability = semanticRecall?.availability === "partial" ||
                semanticRecall?.availability === "unavailable"
                ? "partial"
                : "complete";
            const originalMessages = {
                header: availability === "partial"
                    ? "Relevant past conversations (partial; some matching messages were withheld by access policy):"
                    : "Relevant past conversations:",
                sources: filtered.map((mem, index) => {
                    const room = roomCache.get(mem.roomId) ?? null;
                    const body = memoryText(mem);
                    const original = priorDialogueOriginalText(mem);
                    const quoteable = original !== undefined &&
                        original === body &&
                        original.length > 0 &&
                        !!mem.id &&
                        !!mem.agentId;
                    return {
                        id: `${quoteable ? "recalled" : "record"}${index + 1}`,
                        prefix: `${roomSourceTag(room)} ${formatRelativeTimestampPrefix(mem.createdAt)}${formatSpeakerLabel(runtime, mem)}: `,
                        ...(quoteable ? { originalText: body } : { text: body }),
                        memoryId: mem.id ?? null,
                        agentId: mem.agentId ?? null,
                        roomId: mem.roomId,
                        entityId: mem.entityId,
                        createdAt: typeof mem.createdAt === "number" ? mem.createdAt : null,
                    };
                }),
            };
            // The checkpoint is an internal index, never a disclosure grant. Validate
            // its original room snapshot, then only defer records already admitted
            // above. No body read for index validation enters the provider output.
            const deferred = new Set();
            if (accessContext.role === "OWNER" &&
                accessContext.worldId &&
                message.content.channelType !== ChannelType.VOICE_DM &&
                currentRoom?.type !== ChannelType.VOICE_DM) {
                await Promise.all(roomIds.map(async (roomId) => {
                    const room = roomCache.get(roomId);
                    if (!room ||
                        room.worldId !== accessContext.worldId ||
                        ![
                            ChannelType.DM,
                            ChannelType.API,
                            ChannelType.SELF,
                            ChannelType.VOICE_DM,
                        ].some((type) => type === room.type))
                        return;
                    try {
                        const sourceMessage = { ...message, roomId };
                        const checkpoint = await getEvaluatorProgressState(runtime, sourceMessage, HISTORY_RETENTION_EVALUATOR);
                        if (!checkpoint)
                            return;
                        const originals = await runtime.getMemories({
                            agentId: runtime.agentId,
                            roomId,
                            tableName: "messages",
                            unique: false,
                            includeEmbedding: false,
                            orderDirection: "asc",
                        });
                        const context = historyRetentionContext(runtime, sourceMessage, originals);
                        const visible = visibleHistoryEventIds(context, {
                            agentId: runtime.agentId,
                            roomId,
                            entityId: message.entityId,
                            roles: ["OWNER"],
                        }, checkpoint);
                        if (!visible)
                            return;
                        const originalIds = new Set(context.events.map((event) => event.id));
                        const byId = new Map(originals.map((original) => [original.id, original]));
                        const roomDeferred = [];
                        for (const memory of filtered) {
                            if (!memory.id || memory.roomId !== roomId)
                                continue;
                            const original = byId.get(memory.id);
                            if (!original ||
                                original.entityId !== memory.entityId ||
                                original.roomId !== memory.roomId ||
                                original.createdAt !== memory.createdAt ||
                                JSON.stringify(original.content) !==
                                    JSON.stringify(memory.content) ||
                                JSON.stringify(original.metadata) !==
                                    JSON.stringify(memory.metadata))
                                continue;
                            const eventId = `history:${memory.id}`;
                            if (originalIds.has(eventId) && !visible.has(eventId))
                                roomDeferred.push(memory.id);
                        }
                        for (const id of roomDeferred)
                            deferred.add(id);
                    }
                    catch (error) {
                        // error-policy:J4 Optional index failure preserves full admitted recall.
                        runtime.reportError("RelevantConversationsProvider.retention", error, { roomId });
                    }
                }));
            }
            const fullText = renderProviderOriginalMessages(originalMessages);
            const discoveryText = deferred.size
                ? renderProviderOriginalMessages({
                    ...originalMessages,
                    sources: originalMessages.sources.filter((_, index) => !deferred.has(filtered[index].id ?? "")),
                }) +
                    "\nOther reviewed conversation originals are deferred, not absent. Request relevant-conversations for complete recalled originals when a fact, correction, quotation or dependency is missing. Retention is not proof of relevance or permission."
                : undefined;
            return {
                text: fullText,
                ...(discoveryText && discoveryText.length < fullText.length
                    ? { discoveryText }
                    : {}),
                reviewableSources: {
                    notice: originalMessages.header,
                    sources: originalMessages.sources.map((source, index) => ({
                        id: source.id,
                        text: `${source.prefix}${memoryText(filtered[index])}`,
                        ...(source.originalText !== undefined
                            ? { originalText: source.originalText }
                            : {}),
                        metadata: {
                            recordId: source.memoryId,
                            roomId: source.roomId,
                            entityId: source.entityId,
                            createdAt: source.createdAt,
                        },
                    })),
                },
                values: {
                    relevantConversationCount: filtered.length,
                    relevantConversationAvailability: availability,
                },
                data: {
                    originalMessages,
                    messages: filtered.map((m) => ({
                        id: m.id,
                        roomId: m.roomId,
                        entityId: m.entityId,
                        text: m.content.text,
                        createdAt: m.createdAt,
                    })),
                    withheld: semanticRecall?.withheld ?? [],
                    availability,
                },
            };
        }
        catch (error) {
            // error-policy:J4 expose retrieval failure before a direct response can mistake it for empty history.
            runtime.reportError("RelevantConversationsProvider", error, {
                entityId: message.entityId,
                roomId: message.roomId,
            });
            return {
                text: "Relevant cross-room recall is unavailable because retrieval failed. Do not infer that no prior discussion exists; use an authorized recall tool if available or state the gap.",
                values: {},
                data: { recallUnavailable: true },
            };
        }
    },
};
