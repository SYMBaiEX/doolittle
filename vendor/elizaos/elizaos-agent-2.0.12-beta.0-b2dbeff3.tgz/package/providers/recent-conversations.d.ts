/**
 * Exposes the complete authorized cross-platform conversation history inline,
 * with a room index for exact storage-backed reads when a permitted
 * memory-read action exists. Current dialogue stays in RECENT_MESSAGES;
 * relevant-conversations independently recalls matching historical evidence.
 * No authorized body is replaced by the index, shortened or dropped under an
 * estimated budget; a genuine model input boundary rejects explicitly.
 * Automation/page rooms are excluded and owner-private disclosure is checked
 * before identity expansion or history reads.
 */
import { type Provider } from "@elizaos/core";
export declare const recentConversationsProvider: Provider;
