/**
 * Escalation trigger provider.
 *
 * Monitors conditions that may warrant escalating to the owner and injects
 * escalation context into the agent's prompt when triggers are detected.
 *
 * Checks:
 * 1. Active (unresolved) escalation in progress
 * 2. Owner inactive for 24+ hours (only during autonomous agent loops)
 * 3. Pending identity verification relationships for the current entity
 */
import type { Provider } from "@elizaos/core";
export declare const escalationTriggerProvider: Provider;
export declare function createEscalationTriggerProvider(): Provider;
