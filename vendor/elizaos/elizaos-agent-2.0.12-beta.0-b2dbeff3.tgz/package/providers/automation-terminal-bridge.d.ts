/**
 * Provider that injects recent messages from the terminal conversation linked
 * to the current automation room, giving an automation-context agent visibility
 * into the operator-facing terminal side. Reads the linked conversation id from
 * the room's automation metadata, loads that room's latest messages, and renders
 * them oldest-first. Gated to ADMIN and scoped to the automation /
 * agent_internal contexts.
 */
import type { Provider } from "@elizaos/core";
/**
 * Normalizes a memory timestamp for ordering. A missing or non-finite
 * `createdAt` (NaN reaches this provider when a storage row carries an
 * unparseable timestamp) would otherwise make every comparison return NaN,
 * which the sort treats as "equal" and leaves the transcript in whatever order
 * storage returned it. Collapsing those to 0 keeps the ordering total so the
 * oldest-first transcript stays deterministic.
 */
export declare function safeCreatedAt(createdAt: number | undefined): number;
export declare const automationTerminalBridgeProvider: Provider;
