/**
 * Provider that surfaces the owner's recent Eliza-app (client_chat)
 * conversation into the agent's context so it carries continuity across
 * platforms. Resolves the canonical owner, scans their most-active client_chat
 * rooms, and renders the complete conversation oldest-first. Gated to ADMIN —
 * returns empty for callers without admin access.
 */
import type { Provider } from "@elizaos/core";
export declare const adminPanelProvider: Provider;
export declare function createAdminPanelProvider(): Provider;
