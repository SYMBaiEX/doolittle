/**
 * Provider that recalls conversation snippets relevant to the current message,
 * re-ranked by similarity, from across all platforms. It combines a lexical
 * "hash memory" scan (mirroring the /api/memory/remember writer, so recall works
 * even when no embedding model is registered) with semantic search over the
 * shared per-turn recall-query embed; on embed failure it fails open to the
 * lexical hits alone. The two sources are independent and run concurrently, and
 * result-room tags resolve through one batched room read — this provider sits
 * on the composeState critical path of every reply, so it must not serialize
 * independent round-trips. Current-room messages are filtered out to avoid
 * echo, and hash-memory hits win on id overlap. Gated to USER.
 */
import { type Provider } from "@elizaos/core";
export declare const relevantConversationsProvider: Provider;
