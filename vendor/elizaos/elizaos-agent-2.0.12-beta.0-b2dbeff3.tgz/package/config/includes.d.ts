/**
 * $include directive for modular configs.
 *
 * ```json5
 * { "$include": "./base.json5" }
 * { "$include": ["./a.json5", "./b.json5"] }
 * ```
 *
 * Included files are byte-capped on an opened handle before allocation and
 * share an aggregate graph budget so startup cannot be pinned by breadth.
 */
export declare const INCLUDE_KEY = "$include";
export declare const MAX_INCLUDE_DEPTH = 10;
export type IncludeResolver = {
    readFile: (path: string) => string;
    parseJson: (raw: string) => unknown;
};
export declare class ConfigIncludeError extends Error {
    readonly includePath: string;
    readonly cause?: Error | undefined;
    constructor(message: string, includePath: string, cause?: Error | undefined);
}
export declare class CircularIncludeError extends ConfigIncludeError {
    readonly chain: string[];
    constructor(chain: string[]);
}
export declare function deepMerge(target: unknown, source: unknown): unknown;
export declare function resolveConfigIncludes(obj: unknown, configPath: string, resolver?: IncludeResolver, onReadFile?: (filePath: string) => void): unknown;
