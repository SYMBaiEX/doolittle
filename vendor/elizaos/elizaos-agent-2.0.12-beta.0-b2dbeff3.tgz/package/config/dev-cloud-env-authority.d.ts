/**
 * Internal contract stamped by the app development launchers. Persisted
 * account/config state must not replace the Cloud environment selected for a
 * local development process.
 */
import { type DevCloudEnvAuthority } from "@elizaos/plugin-elizacloud/cloud-config/dev-cloud-env-authority";
export declare const DEV_CLOUD_ENV_AUTHORITY_KEY: "ELIZA_DEV_CLOUD_ENV_AUTHORITY";
export type { DevCloudEnvAuthority };
/**
 * Persisted environment fields whose launch-time values outrank config/vault
 * state. Keep this Cloud-specific: generic model aliases such as SMALL_MODEL
 * still belong to direct/local providers when the dev target is offline.
 */
export declare const DEV_CLOUD_ENV_OWNED_KEYS: readonly ["STEWARD_API_URL", "STEWARD_TENANT_ID", "STEWARD_AGENT_ID", "ELIZA_STEWARD_AGENT_ID", "STEWARD_API_KEY", "STEWARD_AGENT_TOKEN", "STEWARD_TRADE_SESSION_ID", "STEWARD_HYPERLIQUID_TRADE_SESSION_ID", "STEWARD_POLYMARKET_TRADE_SESSION_ID", "ELIZA_DEV_CLOUD_API_KEY", "ELIZAOS_CLOUD_API_KEY", "ELIZAOS_CLOUD_SERVICE_KEY", "ELIZA_CLOUD_API_KEY", "ELIZA_CLOUD_SERVICE_KEY", "ELIZA_CLOUD_SERVICE_TOKEN", "ELIZA_CLOUD_SESSION_TOKEN", "ELIZA_CLOUD_TOKEN", "ELIZACLOUD_API_KEY", "ELIZACLOUD_TOKEN", "ELIZAOS_CLOUD_BASE_URL", "ELIZAOS_CLOUD_API_BASE_URL", "ELIZAOS_CLOUD_REQUEST_BASE_URL", "ELIZAOS_CLOUD_URL", "ELIZAOS_CLOUD_BROWSER_BASE_URL", "ELIZAOS_CLOUD_BROWSER_EMBEDDING_URL", "ELIZAOS_CLOUD_EMBEDDING_API_KEY", "ELIZAOS_CLOUD_EMBEDDING_URL", "ELIZAOS_CLOUD_ENABLED", "ELIZA_CLOUD_PROVISIONED", "ELIZAOS_CLOUD_AGENT_ID", "ELIZA_CLOUD_AGENT_ID", "WAIFU_ELIZA_CLOUD_AGENT_ID", "ELIZA_CLOUD_API_BASE_URL", "ELIZA_CLOUD_API_BASE", "ELIZA_CLOUD_API_URL", "ELIZA_CLOUD_BASE", "ELIZA_CLOUD_BASE_URL", "ELIZA_CLOUD_LOCAL_API_URL", "ELIZA_CLOUD_LOCAL_APP_URL", "ELIZA_CLOUD_OPENAI_BASE_URL", "ELIZA_CLOUD_PUBLIC_URL", "ELIZA_CLOUD_ROUTE_BASE", "ELIZA_CLOUD_URL", "ELIZA_CLOUD_WEB_URL", "ELIZA_CLOUD_WRITE_BASE_URL", "ELIZACLOUD_API_BASE_URL", "ELIZACLOUD_API_URL", "ELIZACLOUD_DEFAULT_URL", "ELIZA_CLOUD_SANDBOX_API_BASE_URL", "ELIZA_CLOUD_SANDBOX_BASE_URL", "ELIZA_CLOUD_SANDBOX_ACCESS_URL", "ELIZA_CLOUD_REMOTE_RUNNER_URL", "ELIZA_CLOUD_RUNNER_URL", "ELIZA_CLOUD_AUTH_TOKEN", "ELIZA_CLOUD_SANDBOX_TOKEN", "ELIZAOS_CLOUD_USE_INFERENCE", "ELIZAOS_CLOUD_USE_TTS", "ELIZAOS_CLOUD_USE_STT", "ELIZAOS_CLOUD_USE_MEDIA", "ELIZAOS_CLOUD_USE_EMBEDDINGS", "ELIZAOS_CLOUD_USE_RPC", "ELIZAOS_CLOUD_NANO_MODEL", "ELIZAOS_CLOUD_SMALL_MODEL", "ELIZAOS_CLOUD_MEDIUM_MODEL", "ELIZAOS_CLOUD_LARGE_MODEL", "ELIZAOS_CLOUD_MEGA_MODEL", "ELIZAOS_CLOUD_RESPONSE_HANDLER_MODEL", "ELIZAOS_CLOUD_SHOULD_RESPOND_MODEL", "ELIZAOS_CLOUD_ACTION_PLANNER_MODEL", "ELIZAOS_CLOUD_PLANNER_MODEL", "ELIZAOS_CLOUD_RESPONSE_MODEL", "ELIZAOS_CLOUD_MEDIA_DESCRIPTION_MODEL"];
/**
 * applyCloudConfigToEnv also writes compatibility model aliases and derived
 * disabled flags. Snapshot them so the authority wrapper can restore the exact
 * launcher process environment without treating them as Cloud-owned config.
 */
export declare const DEV_CLOUD_ENV_RESTORE_KEYS: readonly ["STEWARD_API_URL", "STEWARD_TENANT_ID", "STEWARD_AGENT_ID", "ELIZA_STEWARD_AGENT_ID", "STEWARD_API_KEY", "STEWARD_AGENT_TOKEN", "STEWARD_TRADE_SESSION_ID", "STEWARD_HYPERLIQUID_TRADE_SESSION_ID", "STEWARD_POLYMARKET_TRADE_SESSION_ID", "ELIZA_DEV_CLOUD_API_KEY", "ELIZAOS_CLOUD_API_KEY", "ELIZAOS_CLOUD_SERVICE_KEY", "ELIZA_CLOUD_API_KEY", "ELIZA_CLOUD_SERVICE_KEY", "ELIZA_CLOUD_SERVICE_TOKEN", "ELIZA_CLOUD_SESSION_TOKEN", "ELIZA_CLOUD_TOKEN", "ELIZACLOUD_API_KEY", "ELIZACLOUD_TOKEN", "ELIZAOS_CLOUD_BASE_URL", "ELIZAOS_CLOUD_API_BASE_URL", "ELIZAOS_CLOUD_REQUEST_BASE_URL", "ELIZAOS_CLOUD_URL", "ELIZAOS_CLOUD_BROWSER_BASE_URL", "ELIZAOS_CLOUD_BROWSER_EMBEDDING_URL", "ELIZAOS_CLOUD_EMBEDDING_API_KEY", "ELIZAOS_CLOUD_EMBEDDING_URL", "ELIZAOS_CLOUD_ENABLED", "ELIZA_CLOUD_PROVISIONED", "ELIZAOS_CLOUD_AGENT_ID", "ELIZA_CLOUD_AGENT_ID", "WAIFU_ELIZA_CLOUD_AGENT_ID", "ELIZA_CLOUD_API_BASE_URL", "ELIZA_CLOUD_API_BASE", "ELIZA_CLOUD_API_URL", "ELIZA_CLOUD_BASE", "ELIZA_CLOUD_BASE_URL", "ELIZA_CLOUD_LOCAL_API_URL", "ELIZA_CLOUD_LOCAL_APP_URL", "ELIZA_CLOUD_OPENAI_BASE_URL", "ELIZA_CLOUD_PUBLIC_URL", "ELIZA_CLOUD_ROUTE_BASE", "ELIZA_CLOUD_URL", "ELIZA_CLOUD_WEB_URL", "ELIZA_CLOUD_WRITE_BASE_URL", "ELIZACLOUD_API_BASE_URL", "ELIZACLOUD_API_URL", "ELIZACLOUD_DEFAULT_URL", "ELIZA_CLOUD_SANDBOX_API_BASE_URL", "ELIZA_CLOUD_SANDBOX_BASE_URL", "ELIZA_CLOUD_SANDBOX_ACCESS_URL", "ELIZA_CLOUD_REMOTE_RUNNER_URL", "ELIZA_CLOUD_RUNNER_URL", "ELIZA_CLOUD_AUTH_TOKEN", "ELIZA_CLOUD_SANDBOX_TOKEN", "ELIZAOS_CLOUD_USE_INFERENCE", "ELIZAOS_CLOUD_USE_TTS", "ELIZAOS_CLOUD_USE_STT", "ELIZAOS_CLOUD_USE_MEDIA", "ELIZAOS_CLOUD_USE_EMBEDDINGS", "ELIZAOS_CLOUD_USE_RPC", "ELIZAOS_CLOUD_NANO_MODEL", "ELIZAOS_CLOUD_SMALL_MODEL", "ELIZAOS_CLOUD_MEDIUM_MODEL", "ELIZAOS_CLOUD_LARGE_MODEL", "ELIZAOS_CLOUD_MEGA_MODEL", "ELIZAOS_CLOUD_RESPONSE_HANDLER_MODEL", "ELIZAOS_CLOUD_SHOULD_RESPOND_MODEL", "ELIZAOS_CLOUD_ACTION_PLANNER_MODEL", "ELIZAOS_CLOUD_PLANNER_MODEL", "ELIZAOS_CLOUD_RESPONSE_MODEL", "ELIZAOS_CLOUD_MEDIA_DESCRIPTION_MODEL", "ELIZA_DEV_SOURCE", "ELIZA_DEV_CLOUD_ENV_AUTHORITY", "ELIZA_DEV_CLOUD_TARGET", "ELIZA_CLOUD_TTS_DISABLED", "ELIZA_CLOUD_MEDIA_DISABLED", "ELIZA_CLOUD_EMBEDDINGS_DISABLED", "ELIZA_CLOUD_RPC_DISABLED", "NANO_MODEL", "SMALL_MODEL", "MEDIUM_MODEL", "LARGE_MODEL", "MEGA_MODEL"];
export type DevCloudEnvSnapshot = Readonly<{
    authority: DevCloudEnvAuthority;
    values: Readonly<Record<string, string | undefined>>;
}>;
/** Ignore the marker outside a launcher-owned development process. */
export declare function resolveDevCloudEnvAuthority(env?: NodeJS.ProcessEnv): DevCloudEnvAuthority | null;
export declare function isDevCloudEnvOwnedKey(key: string): boolean;
/** Internal launcher markers must never be fabricated by persisted config. */
export declare function isDevCloudInternalEnvKey(key: string): boolean;
export declare function captureDevCloudEnvAuthority(env?: NodeJS.ProcessEnv): DevCloudEnvSnapshot | null;
/** Restore the exact launcher-owned tuple after config/vault projection. */
export declare function restoreDevCloudEnvAuthority(snapshot: DevCloudEnvSnapshot, env?: NodeJS.ProcessEnv): void;
/**
 * Remove persisted Cloud ownership from the in-memory config and project only
 * the launcher-selected connection. This never writes the sanitized view back
 * to disk; it protects the current local-development process only.
 */
export declare function applyDevCloudConfigAuthority(config: Record<string, unknown>, env?: NodeJS.ProcessEnv): DevCloudEnvSnapshot | null;
/**
 * Exact per-runtime settings that outrank DB-persisted AgentRuntime values.
 * AgentRuntime's initialization merge deliberately lets constructor settings
 * override DB values without writing those overrides back to the database.
 */
export declare function createDevCloudRuntimeSettingsAuthorityOverlay(env?: NodeJS.ProcessEnv, config?: unknown): Record<string, string>;
/** Build an ephemeral runtime view without altering the persistable config. */
export declare function createDevCloudConfigAuthorityView<T extends object>(config: T, env?: NodeJS.ProcessEnv): T;
export declare function isDevCloudConfigAuthorityView(value: object): boolean;
/**
 * Deliberately turn a mutated authority view into a persistable snapshot.
 * Only explicit Cloud mutation routes should call this; ordinary persistence
 * continues to reject marked ephemeral views.
 */
export declare function materializeDevCloudConfigAuthorityView<T extends object>(config: T): T;
/**
 * Apply only mutations made after an authority view was created onto the
 * durable source config. This is for mixed read/write routes (wallet refresh):
 * the network read sees staging, while an unrelated persisted production or
 * self-hosted Cloud topology is neither contacted nor overwritten.
 */
export declare function mergeDevCloudConfigAuthorityMutation<T extends object>(durable: T, authorityViewBeforeMutation: T, authorityViewAfterMutation: T): T;
