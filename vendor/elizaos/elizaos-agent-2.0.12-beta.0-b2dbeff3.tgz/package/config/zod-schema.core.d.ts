/**
 * Shared zod schema building blocks composed by the other config schemas.
 * Covers the model layer (provider/model definitions, API dialects, per-model
 * cost and context-window shapes), group/DM policy enums, identity, TTS, media
 * understanding and media generation (image/video/audio/vision), CLI-backend
 * definitions, message queue/debounce/retry, markdown rendering, and shared
 * refinement helpers (`requireOpenAllowFrom`, `normalizeAllowFrom`) reused to
 * gate an "open" DM policy behind an explicit `allowFrom: ["*"]`.
 */
import { ModelDefinitionInputSchema } from "@elizaos/host/protocol";
import * as zod from "zod";
export declare const ModelApiSchema: zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>;
export declare const ModelCompatSchema: zod.ZodOptional<zod.ZodObject<{
    supportsStore: zod.ZodOptional<zod.ZodBoolean>;
    supportsDeveloperRole: zod.ZodOptional<zod.ZodBoolean>;
    supportsReasoningEffort: zod.ZodOptional<zod.ZodBoolean>;
    maxTokensField: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"max_completion_tokens">, zod.ZodLiteral<"max_tokens">]>>;
}, zod.z.core.$strict>>;
type ValidatedModelDefinition = zod.infer<typeof ModelDefinitionInputSchema>;
/** Apply agent-runtime defaults only after shared input validation succeeds. */
export declare function materializeRuntimeModelDefinition(input: ValidatedModelDefinition): {
    reasoning: boolean;
    input: ("image" | "text")[];
    cost: {
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    };
    contextWindow: number;
    id: string;
    name: string;
    api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
    maxTokens?: number | undefined;
    headers?: Record<string, string> | undefined;
    compat?: {
        supportsStore?: boolean | undefined;
        supportsDeveloperRole?: boolean | undefined;
        supportsReasoningEffort?: boolean | undefined;
        maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
    } | undefined;
};
export declare const ModelDefinitionSchema: zod.ZodPipe<zod.ZodObject<{
    id: zod.ZodString;
    name: zod.ZodString;
    api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
    reasoning: zod.ZodOptional<zod.ZodBoolean>;
    input: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"text">, zod.ZodLiteral<"image">]>>>;
    cost: zod.ZodOptional<zod.ZodObject<{
        input: zod.ZodOptional<zod.ZodNumber>;
        output: zod.ZodOptional<zod.ZodNumber>;
        cacheRead: zod.ZodOptional<zod.ZodNumber>;
        cacheWrite: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    contextWindow: zod.ZodOptional<zod.ZodNumber>;
    maxTokens: zod.ZodOptional<zod.ZodNumber>;
    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    compat: zod.ZodOptional<zod.ZodObject<{
        supportsStore: zod.ZodOptional<zod.ZodBoolean>;
        supportsDeveloperRole: zod.ZodOptional<zod.ZodBoolean>;
        supportsReasoningEffort: zod.ZodOptional<zod.ZodBoolean>;
        maxTokensField: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"max_completion_tokens">, zod.ZodLiteral<"max_tokens">]>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>, zod.ZodTransform<{
    reasoning: boolean;
    input: ("image" | "text")[];
    cost: {
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    };
    contextWindow: number;
    id: string;
    name: string;
    api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
    maxTokens?: number | undefined;
    headers?: Record<string, string> | undefined;
    compat?: {
        supportsStore?: boolean | undefined;
        supportsDeveloperRole?: boolean | undefined;
        supportsReasoningEffort?: boolean | undefined;
        maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
    } | undefined;
}, {
    id: string;
    name: string;
    api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
    reasoning?: boolean | undefined;
    input?: ("image" | "text")[] | undefined;
    cost?: {
        input?: number | undefined;
        output?: number | undefined;
        cacheRead?: number | undefined;
        cacheWrite?: number | undefined;
    } | undefined;
    contextWindow?: number | undefined;
    maxTokens?: number | undefined;
    headers?: Record<string, string> | undefined;
    compat?: {
        supportsStore?: boolean | undefined;
        supportsDeveloperRole?: boolean | undefined;
        supportsReasoningEffort?: boolean | undefined;
        maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
    } | undefined;
}>>;
export declare const ModelProviderSchema: zod.ZodObject<{
    baseUrl: zod.ZodString;
    apiKey: zod.ZodOptional<zod.ZodString>;
    auth: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"api-key">, zod.ZodLiteral<"aws-sdk">, zod.ZodLiteral<"oauth">, zod.ZodLiteral<"token">]>>;
    api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    authHeader: zod.ZodOptional<zod.ZodBoolean>;
    models: zod.ZodArray<zod.ZodPipe<zod.ZodObject<{
        id: zod.ZodString;
        name: zod.ZodString;
        api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
        reasoning: zod.ZodOptional<zod.ZodBoolean>;
        input: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"text">, zod.ZodLiteral<"image">]>>>;
        cost: zod.ZodOptional<zod.ZodObject<{
            input: zod.ZodOptional<zod.ZodNumber>;
            output: zod.ZodOptional<zod.ZodNumber>;
            cacheRead: zod.ZodOptional<zod.ZodNumber>;
            cacheWrite: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        contextWindow: zod.ZodOptional<zod.ZodNumber>;
        maxTokens: zod.ZodOptional<zod.ZodNumber>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        compat: zod.ZodOptional<zod.ZodObject<{
            supportsStore: zod.ZodOptional<zod.ZodBoolean>;
            supportsDeveloperRole: zod.ZodOptional<zod.ZodBoolean>;
            supportsReasoningEffort: zod.ZodOptional<zod.ZodBoolean>;
            maxTokensField: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"max_completion_tokens">, zod.ZodLiteral<"max_tokens">]>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>, zod.ZodTransform<{
        reasoning: boolean;
        input: ("image" | "text")[];
        cost: {
            input: number;
            output: number;
            cacheRead: number;
            cacheWrite: number;
        };
        contextWindow: number;
        id: string;
        name: string;
        api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
        maxTokens?: number | undefined;
        headers?: Record<string, string> | undefined;
        compat?: {
            supportsStore?: boolean | undefined;
            supportsDeveloperRole?: boolean | undefined;
            supportsReasoningEffort?: boolean | undefined;
            maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
        } | undefined;
    }, {
        id: string;
        name: string;
        api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
        reasoning?: boolean | undefined;
        input?: ("image" | "text")[] | undefined;
        cost?: {
            input?: number | undefined;
            output?: number | undefined;
            cacheRead?: number | undefined;
            cacheWrite?: number | undefined;
        } | undefined;
        contextWindow?: number | undefined;
        maxTokens?: number | undefined;
        headers?: Record<string, string> | undefined;
        compat?: {
            supportsStore?: boolean | undefined;
            supportsDeveloperRole?: boolean | undefined;
            supportsReasoningEffort?: boolean | undefined;
            maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
        } | undefined;
    }>>>;
}, zod.z.core.$strict>;
export declare const BedrockDiscoverySchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    region: zod.ZodOptional<zod.ZodString>;
    providerFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    refreshInterval: zod.ZodOptional<zod.ZodNumber>;
    defaultContextWindow: zod.ZodOptional<zod.ZodNumber>;
    defaultMaxTokens: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const ModelsConfigSchema: zod.ZodOptional<zod.ZodObject<{
    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"merge">, zod.ZodLiteral<"replace">]>>;
    providers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        baseUrl: zod.ZodString;
        apiKey: zod.ZodOptional<zod.ZodString>;
        auth: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"api-key">, zod.ZodLiteral<"aws-sdk">, zod.ZodLiteral<"oauth">, zod.ZodLiteral<"token">]>>;
        api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        authHeader: zod.ZodOptional<zod.ZodBoolean>;
        models: zod.ZodArray<zod.ZodPipe<zod.ZodObject<{
            id: zod.ZodString;
            name: zod.ZodString;
            api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
            reasoning: zod.ZodOptional<zod.ZodBoolean>;
            input: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"text">, zod.ZodLiteral<"image">]>>>;
            cost: zod.ZodOptional<zod.ZodObject<{
                input: zod.ZodOptional<zod.ZodNumber>;
                output: zod.ZodOptional<zod.ZodNumber>;
                cacheRead: zod.ZodOptional<zod.ZodNumber>;
                cacheWrite: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            contextWindow: zod.ZodOptional<zod.ZodNumber>;
            maxTokens: zod.ZodOptional<zod.ZodNumber>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            compat: zod.ZodOptional<zod.ZodObject<{
                supportsStore: zod.ZodOptional<zod.ZodBoolean>;
                supportsDeveloperRole: zod.ZodOptional<zod.ZodBoolean>;
                supportsReasoningEffort: zod.ZodOptional<zod.ZodBoolean>;
                maxTokensField: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"max_completion_tokens">, zod.ZodLiteral<"max_tokens">]>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>, zod.ZodTransform<{
            reasoning: boolean;
            input: ("image" | "text")[];
            cost: {
                input: number;
                output: number;
                cacheRead: number;
                cacheWrite: number;
            };
            contextWindow: number;
            id: string;
            name: string;
            api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
            maxTokens?: number | undefined;
            headers?: Record<string, string> | undefined;
            compat?: {
                supportsStore?: boolean | undefined;
                supportsDeveloperRole?: boolean | undefined;
                supportsReasoningEffort?: boolean | undefined;
                maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
            } | undefined;
        }, {
            id: string;
            name: string;
            api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
            reasoning?: boolean | undefined;
            input?: ("image" | "text")[] | undefined;
            cost?: {
                input?: number | undefined;
                output?: number | undefined;
                cacheRead?: number | undefined;
                cacheWrite?: number | undefined;
            } | undefined;
            contextWindow?: number | undefined;
            maxTokens?: number | undefined;
            headers?: Record<string, string> | undefined;
            compat?: {
                supportsStore?: boolean | undefined;
                supportsDeveloperRole?: boolean | undefined;
                supportsReasoningEffort?: boolean | undefined;
                maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
            } | undefined;
        }>>>;
    }, zod.z.core.$strict>>>;
    bedrockDiscovery: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        region: zod.ZodOptional<zod.ZodString>;
        providerFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        refreshInterval: zod.ZodOptional<zod.ZodNumber>;
        defaultContextWindow: zod.ZodOptional<zod.ZodNumber>;
        defaultMaxTokens: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const GroupChatSchema: zod.ZodOptional<zod.ZodObject<{
    mentionPatterns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const DmConfigSchema: zod.ZodObject<{
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>;
export declare const IdentitySchema: zod.ZodOptional<zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    theme: zod.ZodOptional<zod.ZodString>;
    emoji: zod.ZodOptional<zod.ZodString>;
    avatar: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const QueueModeSchema: zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>;
export declare const QueueDropSchema: zod.ZodUnion<readonly [zod.ZodLiteral<"old">, zod.ZodLiteral<"new">, zod.ZodLiteral<"summarize">]>;
export declare const ReplyToModeSchema: zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>;
export declare const GroupPolicySchema: zod.ZodEnum<{
    disabled: "disabled";
    open: "open";
    allowlist: "allowlist";
}>;
export declare const DmPolicySchema: zod.ZodEnum<{
    pairing: "pairing";
    disabled: "disabled";
    open: "open";
    allowlist: "allowlist";
}>;
export declare const BlockStreamingCoalesceSchema: zod.ZodObject<{
    minChars: zod.ZodOptional<zod.ZodNumber>;
    maxChars: zod.ZodOptional<zod.ZodNumber>;
    idleMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>;
export declare const BlockStreamingChunkSchema: zod.ZodObject<{
    minChars: zod.ZodOptional<zod.ZodNumber>;
    maxChars: zod.ZodOptional<zod.ZodNumber>;
    breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
}, zod.z.core.$strict>;
export declare const MarkdownTableModeSchema: zod.ZodEnum<{
    code: "code";
    off: "off";
    bullets: "bullets";
}>;
export declare const MarkdownConfigSchema: zod.ZodOptional<zod.ZodObject<{
    tables: zod.ZodOptional<zod.ZodEnum<{
        code: "code";
        off: "off";
        bullets: "bullets";
    }>>;
}, zod.z.core.$strict>>;
export declare const TtsProviderSchema: zod.ZodEnum<{
    openai: "openai";
    elevenlabs: "elevenlabs";
    edge: "edge";
}>;
export declare const TtsModeSchema: zod.ZodEnum<{
    all: "all";
    final: "final";
}>;
export declare const TtsAutoSchema: zod.ZodEnum<{
    always: "always";
    off: "off";
    inbound: "inbound";
    tagged: "tagged";
}>;
export declare const TtsConfigSchema: zod.ZodOptional<zod.ZodObject<{
    auto: zod.ZodOptional<zod.ZodEnum<{
        always: "always";
        off: "off";
        inbound: "inbound";
        tagged: "tagged";
    }>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    mode: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        final: "final";
    }>>;
    provider: zod.ZodOptional<zod.ZodEnum<{
        openai: "openai";
        elevenlabs: "elevenlabs";
        edge: "edge";
    }>>;
    summaryModel: zod.ZodOptional<zod.ZodString>;
    modelOverrides: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowText: zod.ZodOptional<zod.ZodBoolean>;
        allowProvider: zod.ZodOptional<zod.ZodBoolean>;
        allowVoice: zod.ZodOptional<zod.ZodBoolean>;
        allowModelId: zod.ZodOptional<zod.ZodBoolean>;
        allowVoiceSettings: zod.ZodOptional<zod.ZodBoolean>;
        allowNormalization: zod.ZodOptional<zod.ZodBoolean>;
        allowSeed: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    elevenlabs: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        voiceId: zod.ZodOptional<zod.ZodString>;
        modelId: zod.ZodOptional<zod.ZodString>;
        seed: zod.ZodOptional<zod.ZodNumber>;
        applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
            on: "on";
            off: "off";
            auto: "auto";
        }>>;
        languageCode: zod.ZodOptional<zod.ZodString>;
        voiceSettings: zod.ZodOptional<zod.ZodObject<{
            stability: zod.ZodOptional<zod.ZodNumber>;
            similarityBoost: zod.ZodOptional<zod.ZodNumber>;
            style: zod.ZodOptional<zod.ZodNumber>;
            useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
            speed: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    openai: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        voice: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    edge: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        voice: zod.ZodOptional<zod.ZodString>;
        lang: zod.ZodOptional<zod.ZodString>;
        outputFormat: zod.ZodOptional<zod.ZodString>;
        pitch: zod.ZodOptional<zod.ZodString>;
        rate: zod.ZodOptional<zod.ZodString>;
        volume: zod.ZodOptional<zod.ZodString>;
        saveSubtitles: zod.ZodOptional<zod.ZodBoolean>;
        proxy: zod.ZodOptional<zod.ZodString>;
        timeoutMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    prefsPath: zod.ZodOptional<zod.ZodString>;
    maxTextLength: zod.ZodOptional<zod.ZodNumber>;
    timeoutMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const HumanDelaySchema: zod.ZodObject<{
    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"natural">, zod.ZodLiteral<"custom">]>>;
    minMs: zod.ZodOptional<zod.ZodNumber>;
    maxMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>;
export declare const CliBackendSchema: zod.ZodObject<{
    command: zod.ZodString;
    args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    output: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"json">, zod.ZodLiteral<"text">, zod.ZodLiteral<"jsonl">]>>;
    resumeOutput: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"json">, zod.ZodLiteral<"text">, zod.ZodLiteral<"jsonl">]>>;
    input: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"arg">, zod.ZodLiteral<"stdin">]>>;
    maxPromptArgChars: zod.ZodOptional<zod.ZodNumber>;
    env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    clearEnv: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    modelArg: zod.ZodOptional<zod.ZodString>;
    modelAliases: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    sessionArg: zod.ZodOptional<zod.ZodString>;
    sessionArgs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    resumeArgs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    sessionMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"always">, zod.ZodLiteral<"existing">, zod.ZodLiteral<"none">]>>;
    sessionIdFields: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    systemPromptArg: zod.ZodOptional<zod.ZodString>;
    systemPromptMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"append">, zod.ZodLiteral<"replace">]>>;
    systemPromptWhen: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"always">, zod.ZodLiteral<"never">]>>;
    imageArg: zod.ZodOptional<zod.ZodString>;
    imageMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"repeat">, zod.ZodLiteral<"list">]>>;
    serialize: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>;
export declare const normalizeAllowFrom: (values?: Array<string | number>) => string[];
export declare const requireOpenAllowFrom: (params: {
    policy?: string;
    allowFrom?: Array<string | number>;
    ctx: zod.RefinementCtx;
    path: Array<string | number>;
    message: string;
}) => void;
export declare const MSTeamsReplyStyleSchema: zod.ZodEnum<{
    thread: "thread";
    "top-level": "top-level";
}>;
export declare const RetryConfigSchema: zod.ZodOptional<zod.ZodObject<{
    attempts: zod.ZodOptional<zod.ZodNumber>;
    minDelayMs: zod.ZodOptional<zod.ZodNumber>;
    maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
    jitter: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const QueueModeBySurfaceSchema: zod.ZodOptional<zod.ZodObject<{
    whatsapp: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    telegram: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    discord: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    slack: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    mattermost: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    imessage: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    msteams: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    webchat: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
}, zod.z.core.$strict>>;
export declare const DebounceMsBySurfaceSchema: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
export declare const QueueSchema: zod.ZodOptional<zod.ZodObject<{
    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    byChannel: zod.ZodOptional<zod.ZodObject<{
        whatsapp: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        telegram: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        discord: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        slack: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        mattermost: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        imessage: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        msteams: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        webchat: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
    }, zod.z.core.$strict>>;
    debounceMs: zod.ZodOptional<zod.ZodNumber>;
    debounceMsByChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
    cap: zod.ZodOptional<zod.ZodNumber>;
    drop: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"old">, zod.ZodLiteral<"new">, zod.ZodLiteral<"summarize">]>>;
}, zod.z.core.$strict>>;
export declare const InboundDebounceSchema: zod.ZodOptional<zod.ZodObject<{
    debounceMs: zod.ZodOptional<zod.ZodNumber>;
    byChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
}, zod.z.core.$strict>>;
export declare const TranscribeAudioSchema: zod.ZodOptional<zod.ZodObject<{
    command: zod.ZodArray<zod.ZodString>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const HexColorSchema: zod.ZodString;
export declare const ExecutableTokenSchema: zod.ZodString;
export declare const MediaUnderstandingScopeSchema: zod.ZodOptional<zod.ZodObject<{
    default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
    rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
        match: zod.ZodOptional<zod.ZodObject<{
            channel: zod.ZodOptional<zod.ZodString>;
            chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
            keyPrefix: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const MessagePolicySchema: zod.ZodOptional<zod.ZodObject<{
    default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
    rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
        match: zod.ZodOptional<zod.ZodObject<{
            channel: zod.ZodOptional<zod.ZodString>;
            chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
            keyPrefix: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const MediaUnderstandingCapabilitiesSchema: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
export declare const MediaUnderstandingAttachmentsSchema: zod.ZodOptional<zod.ZodObject<{
    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    maxAttachments: zod.ZodOptional<zod.ZodNumber>;
    prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
}, zod.z.core.$strict>>;
export declare const MediaUnderstandingModelSchema: zod.ZodOptional<zod.ZodObject<{
    provider: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
    type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
    command: zod.ZodOptional<zod.ZodString>;
    args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    prompt: zod.ZodOptional<zod.ZodString>;
    maxBytes: zod.ZodOptional<zod.ZodNumber>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    language: zod.ZodOptional<zod.ZodString>;
    providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
    deepgram: zod.ZodOptional<zod.ZodObject<{
        detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
        punctuate: zod.ZodOptional<zod.ZodBoolean>;
        smartFormat: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    profile: zod.ZodOptional<zod.ZodString>;
    preferredProfile: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const ToolsMediaUnderstandingSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    scope: zod.ZodOptional<zod.ZodObject<{
        default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
        rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
            match: zod.ZodOptional<zod.ZodObject<{
                channel: zod.ZodOptional<zod.ZodString>;
                chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                keyPrefix: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    maxBytes: zod.ZodOptional<zod.ZodNumber>;
    prompt: zod.ZodOptional<zod.ZodString>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    language: zod.ZodOptional<zod.ZodString>;
    providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
    deepgram: zod.ZodOptional<zod.ZodObject<{
        detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
        punctuate: zod.ZodOptional<zod.ZodBoolean>;
        smartFormat: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    attachments: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        maxAttachments: zod.ZodOptional<zod.ZodNumber>;
        prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
    }, zod.z.core.$strict>>;
    models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
        provider: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
        type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
        command: zod.ZodOptional<zod.ZodString>;
        args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        prompt: zod.ZodOptional<zod.ZodString>;
        maxBytes: zod.ZodOptional<zod.ZodNumber>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        language: zod.ZodOptional<zod.ZodString>;
        providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
        deepgram: zod.ZodOptional<zod.ZodObject<{
            detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
            punctuate: zod.ZodOptional<zod.ZodBoolean>;
            smartFormat: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        profile: zod.ZodOptional<zod.ZodString>;
        preferredProfile: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>>;
export declare const ToolsMediaSchema: zod.ZodOptional<zod.ZodObject<{
    models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
        provider: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
        type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
        command: zod.ZodOptional<zod.ZodString>;
        args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        prompt: zod.ZodOptional<zod.ZodString>;
        maxBytes: zod.ZodOptional<zod.ZodNumber>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        language: zod.ZodOptional<zod.ZodString>;
        providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
        deepgram: zod.ZodOptional<zod.ZodObject<{
            detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
            punctuate: zod.ZodOptional<zod.ZodBoolean>;
            smartFormat: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        profile: zod.ZodOptional<zod.ZodString>;
        preferredProfile: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
    concurrency: zod.ZodOptional<zod.ZodNumber>;
    image: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        scope: zod.ZodOptional<zod.ZodObject<{
            default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
            rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                match: zod.ZodOptional<zod.ZodObject<{
                    channel: zod.ZodOptional<zod.ZodString>;
                    chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                    keyPrefix: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        maxBytes: zod.ZodOptional<zod.ZodNumber>;
        prompt: zod.ZodOptional<zod.ZodString>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        language: zod.ZodOptional<zod.ZodString>;
        providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
        deepgram: zod.ZodOptional<zod.ZodObject<{
            detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
            punctuate: zod.ZodOptional<zod.ZodBoolean>;
            smartFormat: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        attachments: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            maxAttachments: zod.ZodOptional<zod.ZodNumber>;
            prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
        }, zod.z.core.$strict>>;
        models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
            provider: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
            type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
            command: zod.ZodOptional<zod.ZodString>;
            args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            prompt: zod.ZodOptional<zod.ZodString>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            profile: zod.ZodOptional<zod.ZodString>;
            preferredProfile: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>;
    audio: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        scope: zod.ZodOptional<zod.ZodObject<{
            default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
            rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                match: zod.ZodOptional<zod.ZodObject<{
                    channel: zod.ZodOptional<zod.ZodString>;
                    chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                    keyPrefix: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        maxBytes: zod.ZodOptional<zod.ZodNumber>;
        prompt: zod.ZodOptional<zod.ZodString>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        language: zod.ZodOptional<zod.ZodString>;
        providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
        deepgram: zod.ZodOptional<zod.ZodObject<{
            detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
            punctuate: zod.ZodOptional<zod.ZodBoolean>;
            smartFormat: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        attachments: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            maxAttachments: zod.ZodOptional<zod.ZodNumber>;
            prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
        }, zod.z.core.$strict>>;
        models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
            provider: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
            type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
            command: zod.ZodOptional<zod.ZodString>;
            args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            prompt: zod.ZodOptional<zod.ZodString>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            profile: zod.ZodOptional<zod.ZodString>;
            preferredProfile: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>;
    video: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        scope: zod.ZodOptional<zod.ZodObject<{
            default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
            rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                match: zod.ZodOptional<zod.ZodObject<{
                    channel: zod.ZodOptional<zod.ZodString>;
                    chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                    keyPrefix: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        maxBytes: zod.ZodOptional<zod.ZodNumber>;
        prompt: zod.ZodOptional<zod.ZodString>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        language: zod.ZodOptional<zod.ZodString>;
        providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
        deepgram: zod.ZodOptional<zod.ZodObject<{
            detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
            punctuate: zod.ZodOptional<zod.ZodBoolean>;
            smartFormat: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        attachments: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            maxAttachments: zod.ZodOptional<zod.ZodNumber>;
            prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
        }, zod.z.core.$strict>>;
        models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
            provider: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
            type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
            command: zod.ZodOptional<zod.ZodString>;
            args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            prompt: zod.ZodOptional<zod.ZodString>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            profile: zod.ZodOptional<zod.ZodString>;
            preferredProfile: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const LinkModelSchema: zod.ZodObject<{
    type: zod.ZodOptional<zod.ZodLiteral<"cli">>;
    command: zod.ZodString;
    args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>;
export declare const ToolsLinksSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    scope: zod.ZodOptional<zod.ZodObject<{
        default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
        rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
            match: zod.ZodOptional<zod.ZodObject<{
                channel: zod.ZodOptional<zod.ZodString>;
                chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                keyPrefix: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    maxLinks: zod.ZodOptional<zod.ZodNumber>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    models: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        type: zod.ZodOptional<zod.ZodLiteral<"cli">>;
        command: zod.ZodString;
        args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const NativeCommandsSettingSchema: zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>;
export declare const ProviderCommandsSchema: zod.ZodOptional<zod.ZodObject<{
    native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
}, zod.z.core.$strict>>;
export declare const ChannelHeartbeatVisibilitySchema: zod.ZodOptional<zod.ZodObject<{
    showOk: zod.ZodOptional<zod.ZodBoolean>;
    showAlerts: zod.ZodOptional<zod.ZodBoolean>;
    useIndicator: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>>;
export declare const MediaModeSchema: zod.ZodEnum<{
    cloud: "cloud";
    "own-key": "own-key";
}>;
export declare const ImageProviderSchema: zod.ZodEnum<{
    cloud: "cloud";
    openai: "openai";
    fal: "fal";
    google: "google";
    xai: "xai";
}>;
export declare const ImageFalConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const ImageOpenaiConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    quality: zod.ZodOptional<zod.ZodEnum<{
        standard: "standard";
        hd: "hd";
    }>>;
    style: zod.ZodOptional<zod.ZodEnum<{
        natural: "natural";
        vivid: "vivid";
    }>>;
}, zod.z.core.$strict>>;
export declare const ImageGoogleConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    aspectRatio: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const ImageXaiConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const ImageConfigSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    mode: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        "own-key": "own-key";
    }>>;
    provider: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        openai: "openai";
        fal: "fal";
        google: "google";
        xai: "xai";
    }>>;
    defaultSize: zod.ZodOptional<zod.ZodString>;
    fal: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    openai: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        quality: zod.ZodOptional<zod.ZodEnum<{
            standard: "standard";
            hd: "hd";
        }>>;
        style: zod.ZodOptional<zod.ZodEnum<{
            natural: "natural";
            vivid: "vivid";
        }>>;
    }, zod.z.core.$strict>>;
    google: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        aspectRatio: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    xai: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const VideoProviderSchema: zod.ZodEnum<{
    cloud: "cloud";
    openai: "openai";
    fal: "fal";
    google: "google";
}>;
export declare const VideoFalConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const VideoOpenaiConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const VideoGoogleConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const VideoConfigSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    mode: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        "own-key": "own-key";
    }>>;
    provider: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        openai: "openai";
        fal: "fal";
        google: "google";
    }>>;
    defaultDuration: zod.ZodOptional<zod.ZodNumber>;
    fal: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    openai: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    google: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const AudioKindSchema: zod.ZodEnum<{
    tts: "tts";
    music: "music";
    sfx: "sfx";
}>;
export declare const AudioGenProviderSchema: zod.ZodEnum<{
    cloud: "cloud";
    fal: "fal";
    elevenlabs: "elevenlabs";
    suno: "suno";
}>;
export declare const AudioProviderRoutingConfigSchema: zod.ZodOptional<zod.ZodObject<{
    default: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        fal: "fal";
        elevenlabs: "elevenlabs";
        suno: "suno";
    }>>;
    music: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        fal: "fal";
        elevenlabs: "elevenlabs";
        suno: "suno";
    }>>;
    sfx: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        fal: "fal";
        elevenlabs: "elevenlabs";
        suno: "suno";
    }>>;
    tts: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        fal: "fal";
        elevenlabs: "elevenlabs";
        suno: "suno";
    }>>;
}, zod.z.core.$strict>>;
export declare const AudioSunoConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const AudioFalConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
    secondsStart: zod.ZodOptional<zod.ZodNumber>;
    secondsTotal: zod.ZodOptional<zod.ZodNumber>;
    steps: zod.ZodOptional<zod.ZodNumber>;
    timeoutMs: zod.ZodOptional<zod.ZodNumber>;
    extraInput: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
}, zod.z.core.$strict>>;
export declare const AudioElevenlabsVoiceSettingsSchema: zod.ZodOptional<zod.ZodObject<{
    stability: zod.ZodOptional<zod.ZodNumber>;
    similarityBoost: zod.ZodOptional<zod.ZodNumber>;
    style: zod.ZodOptional<zod.ZodNumber>;
    useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
    speed: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const AudioElevenlabsConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
    modelId: zod.ZodOptional<zod.ZodString>;
    musicModelId: zod.ZodOptional<zod.ZodString>;
    sfxModelId: zod.ZodOptional<zod.ZodString>;
    ttsModelId: zod.ZodOptional<zod.ZodString>;
    voiceId: zod.ZodOptional<zod.ZodString>;
    outputFormat: zod.ZodOptional<zod.ZodString>;
    duration: zod.ZodOptional<zod.ZodNumber>;
    promptInfluence: zod.ZodOptional<zod.ZodNumber>;
    loop: zod.ZodOptional<zod.ZodBoolean>;
    seed: zod.ZodOptional<zod.ZodNumber>;
    languageCode: zod.ZodOptional<zod.ZodString>;
    applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
        on: "on";
        off: "off";
        auto: "auto";
    }>>;
    voiceSettings: zod.ZodOptional<zod.ZodObject<{
        stability: zod.ZodOptional<zod.ZodNumber>;
        similarityBoost: zod.ZodOptional<zod.ZodNumber>;
        style: zod.ZodOptional<zod.ZodNumber>;
        useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
        speed: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    signWithC2pa: zod.ZodOptional<zod.ZodBoolean>;
    timeoutMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const AudioElevenlabsSfxConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    baseUrl: zod.ZodOptional<zod.ZodString>;
    modelId: zod.ZodOptional<zod.ZodString>;
    musicModelId: zod.ZodOptional<zod.ZodString>;
    sfxModelId: zod.ZodOptional<zod.ZodString>;
    ttsModelId: zod.ZodOptional<zod.ZodString>;
    voiceId: zod.ZodOptional<zod.ZodString>;
    outputFormat: zod.ZodOptional<zod.ZodString>;
    duration: zod.ZodOptional<zod.ZodNumber>;
    promptInfluence: zod.ZodOptional<zod.ZodNumber>;
    loop: zod.ZodOptional<zod.ZodBoolean>;
    seed: zod.ZodOptional<zod.ZodNumber>;
    languageCode: zod.ZodOptional<zod.ZodString>;
    applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
        on: "on";
        off: "off";
        auto: "auto";
    }>>;
    voiceSettings: zod.ZodOptional<zod.ZodObject<{
        stability: zod.ZodOptional<zod.ZodNumber>;
        similarityBoost: zod.ZodOptional<zod.ZodNumber>;
        style: zod.ZodOptional<zod.ZodNumber>;
        useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
        speed: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    signWithC2pa: zod.ZodOptional<zod.ZodBoolean>;
    timeoutMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const AudioGenConfigSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    mode: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        "own-key": "own-key";
    }>>;
    provider: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        fal: "fal";
        elevenlabs: "elevenlabs";
        suno: "suno";
    }>>;
    providers: zod.ZodOptional<zod.ZodObject<{
        default: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            fal: "fal";
            elevenlabs: "elevenlabs";
            suno: "suno";
        }>>;
        music: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            fal: "fal";
            elevenlabs: "elevenlabs";
            suno: "suno";
        }>>;
        sfx: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            fal: "fal";
            elevenlabs: "elevenlabs";
            suno: "suno";
        }>>;
        tts: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            fal: "fal";
            elevenlabs: "elevenlabs";
            suno: "suno";
        }>>;
    }, zod.z.core.$strict>>;
    defaultKind: zod.ZodOptional<zod.ZodEnum<{
        tts: "tts";
        music: "music";
        sfx: "sfx";
    }>>;
    audioKind: zod.ZodOptional<zod.ZodEnum<{
        tts: "tts";
        music: "music";
        sfx: "sfx";
    }>>;
    kind: zod.ZodOptional<zod.ZodEnum<{
        tts: "tts";
        music: "music";
        sfx: "sfx";
    }>>;
    suno: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    elevenlabs: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        modelId: zod.ZodOptional<zod.ZodString>;
        musicModelId: zod.ZodOptional<zod.ZodString>;
        sfxModelId: zod.ZodOptional<zod.ZodString>;
        ttsModelId: zod.ZodOptional<zod.ZodString>;
        voiceId: zod.ZodOptional<zod.ZodString>;
        outputFormat: zod.ZodOptional<zod.ZodString>;
        duration: zod.ZodOptional<zod.ZodNumber>;
        promptInfluence: zod.ZodOptional<zod.ZodNumber>;
        loop: zod.ZodOptional<zod.ZodBoolean>;
        seed: zod.ZodOptional<zod.ZodNumber>;
        languageCode: zod.ZodOptional<zod.ZodString>;
        applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
            on: "on";
            off: "off";
            auto: "auto";
        }>>;
        voiceSettings: zod.ZodOptional<zod.ZodObject<{
            stability: zod.ZodOptional<zod.ZodNumber>;
            similarityBoost: zod.ZodOptional<zod.ZodNumber>;
            style: zod.ZodOptional<zod.ZodNumber>;
            useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
            speed: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        signWithC2pa: zod.ZodOptional<zod.ZodBoolean>;
        timeoutMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    fal: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        baseUrl: zod.ZodOptional<zod.ZodString>;
        secondsStart: zod.ZodOptional<zod.ZodNumber>;
        secondsTotal: zod.ZodOptional<zod.ZodNumber>;
        steps: zod.ZodOptional<zod.ZodNumber>;
        timeoutMs: zod.ZodOptional<zod.ZodNumber>;
        extraInput: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const VisionProviderSchema: zod.ZodEnum<{
    cloud: "cloud";
    anthropic: "anthropic";
    openai: "openai";
    ollama: "ollama";
    google: "google";
    xai: "xai";
}>;
export declare const VisionOpenaiConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    maxTokens: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const VisionGoogleConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const VisionAnthropicConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const VisionXaiConfigSchema: zod.ZodOptional<zod.ZodObject<{
    apiKey: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const VisionOllamaConfigSchema: zod.ZodOptional<zod.ZodObject<{
    baseUrl: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    maxTokens: zod.ZodOptional<zod.ZodNumber>;
    autoDownload: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>>;
export declare const VisionConfigSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    mode: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        "own-key": "own-key";
    }>>;
    provider: zod.ZodOptional<zod.ZodEnum<{
        cloud: "cloud";
        anthropic: "anthropic";
        openai: "openai";
        ollama: "ollama";
        google: "google";
        xai: "xai";
    }>>;
    openai: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        maxTokens: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    google: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    anthropic: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    xai: zod.ZodOptional<zod.ZodObject<{
        apiKey: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    ollama: zod.ZodOptional<zod.ZodObject<{
        baseUrl: zod.ZodOptional<zod.ZodString>;
        model: zod.ZodOptional<zod.ZodString>;
        maxTokens: zod.ZodOptional<zod.ZodNumber>;
        autoDownload: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const MediaConfigSchema: zod.ZodOptional<zod.ZodObject<{
    preserveFilenames: zod.ZodOptional<zod.ZodBoolean>;
    image: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        mode: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            "own-key": "own-key";
        }>>;
        provider: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            openai: "openai";
            fal: "fal";
            google: "google";
            xai: "xai";
        }>>;
        defaultSize: zod.ZodOptional<zod.ZodString>;
        fal: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        openai: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            quality: zod.ZodOptional<zod.ZodEnum<{
                standard: "standard";
                hd: "hd";
            }>>;
            style: zod.ZodOptional<zod.ZodEnum<{
                natural: "natural";
                vivid: "vivid";
            }>>;
        }, zod.z.core.$strict>>;
        google: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            aspectRatio: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        xai: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    video: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        mode: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            "own-key": "own-key";
        }>>;
        provider: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            openai: "openai";
            fal: "fal";
            google: "google";
        }>>;
        defaultDuration: zod.ZodOptional<zod.ZodNumber>;
        fal: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        openai: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        google: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    audio: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        mode: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            "own-key": "own-key";
        }>>;
        provider: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            fal: "fal";
            elevenlabs: "elevenlabs";
            suno: "suno";
        }>>;
        providers: zod.ZodOptional<zod.ZodObject<{
            default: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                fal: "fal";
                elevenlabs: "elevenlabs";
                suno: "suno";
            }>>;
            music: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                fal: "fal";
                elevenlabs: "elevenlabs";
                suno: "suno";
            }>>;
            sfx: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                fal: "fal";
                elevenlabs: "elevenlabs";
                suno: "suno";
            }>>;
            tts: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                fal: "fal";
                elevenlabs: "elevenlabs";
                suno: "suno";
            }>>;
        }, zod.z.core.$strict>>;
        defaultKind: zod.ZodOptional<zod.ZodEnum<{
            tts: "tts";
            music: "music";
            sfx: "sfx";
        }>>;
        audioKind: zod.ZodOptional<zod.ZodEnum<{
            tts: "tts";
            music: "music";
            sfx: "sfx";
        }>>;
        kind: zod.ZodOptional<zod.ZodEnum<{
            tts: "tts";
            music: "music";
            sfx: "sfx";
        }>>;
        suno: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        elevenlabs: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            modelId: zod.ZodOptional<zod.ZodString>;
            musicModelId: zod.ZodOptional<zod.ZodString>;
            sfxModelId: zod.ZodOptional<zod.ZodString>;
            ttsModelId: zod.ZodOptional<zod.ZodString>;
            voiceId: zod.ZodOptional<zod.ZodString>;
            outputFormat: zod.ZodOptional<zod.ZodString>;
            duration: zod.ZodOptional<zod.ZodNumber>;
            promptInfluence: zod.ZodOptional<zod.ZodNumber>;
            loop: zod.ZodOptional<zod.ZodBoolean>;
            seed: zod.ZodOptional<zod.ZodNumber>;
            languageCode: zod.ZodOptional<zod.ZodString>;
            applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
                on: "on";
                off: "off";
                auto: "auto";
            }>>;
            voiceSettings: zod.ZodOptional<zod.ZodObject<{
                stability: zod.ZodOptional<zod.ZodNumber>;
                similarityBoost: zod.ZodOptional<zod.ZodNumber>;
                style: zod.ZodOptional<zod.ZodNumber>;
                useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
                speed: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            signWithC2pa: zod.ZodOptional<zod.ZodBoolean>;
            timeoutMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        fal: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            secondsStart: zod.ZodOptional<zod.ZodNumber>;
            secondsTotal: zod.ZodOptional<zod.ZodNumber>;
            steps: zod.ZodOptional<zod.ZodNumber>;
            timeoutMs: zod.ZodOptional<zod.ZodNumber>;
            extraInput: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    vision: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        mode: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            "own-key": "own-key";
        }>>;
        provider: zod.ZodOptional<zod.ZodEnum<{
            cloud: "cloud";
            anthropic: "anthropic";
            openai: "openai";
            ollama: "ollama";
            google: "google";
            xai: "xai";
        }>>;
        openai: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            maxTokens: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        google: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        anthropic: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        xai: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        ollama: zod.ZodOptional<zod.ZodObject<{
            baseUrl: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            maxTokens: zod.ZodOptional<zod.ZodNumber>;
            autoDownload: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export {};
