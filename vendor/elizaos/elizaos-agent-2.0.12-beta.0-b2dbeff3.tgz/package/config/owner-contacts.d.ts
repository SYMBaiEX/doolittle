/**
 * Resolves the configured "owner" contact for a message source and builds the
 * routing hints used to reach the owner. resolveOwnerContactSource /
 * resolveOwnerContactWithFallback map a source (with telegram alias handling and
 * a chat/discord owner-entity fallback) to an OwnerContactEntry from
 * agents.defaults.ownerContacts. loadOwnerContactRoutingHints enriches each
 * contact from the relationships service (preferred channel, channel/room/entity
 * ids), entity platform identities, and recent owner message history.
 */
import { type IAgentRuntime } from "@elizaos/core";
import type { OwnerContactEntry, OwnerContactsConfig } from "@elizaos/host/protocol";
type OwnerContactsLoadContext = {
    boundary: string;
    operation: string;
    message: string;
};
export type OwnerContactPlatformIdentity = {
    platform: string;
    handle: string;
    status?: string;
};
export type OwnerContactRoutingHint = {
    source: string;
    entityId: string | null;
    channelId: string | null;
    roomId: string | null;
    preferredCommunicationChannel: string | null;
    platformIdentities: OwnerContactPlatformIdentity[];
    lastResponseAt: string | null;
    lastResponseChannel: string | null;
    resolvedFrom: "config" | "relationships" | "config+relationships";
};
export type OwnerContactResolution = {
    source: string;
    contact: OwnerContactEntry;
    resolvedFrom: "config" | "owner_entity";
};
type RuntimeLike = Pick<IAgentRuntime, "getService" | "getEntityById" | "getRoomsForParticipant" | "getMemories">;
/**
 * Resolve the SEND source for an owner-contact key. Keys are contact names,
 * not necessarily handler names: a scoped key like "discord-nubs-test" means
 * "the discord handler, this specific contact". The full key wins when a
 * handler is registered under it; otherwise the longest "-"-boundary prefix
 * with a registered handler carries the delivery. No handler at any boundary
 * returns the full key so the caller's missing-handler path still reports the
 * configured name.
 */
export declare function resolveScopedSendSource(key: string, hasHandler: (source: string) => boolean): string;
export declare function resolveOwnerContactSource(ownerContacts: OwnerContactsConfig, source: string | null | undefined): {
    source: string;
    contact: OwnerContactEntry;
} | null;
export declare function resolveOwnerContactWithFallback(args: {
    ownerContacts: OwnerContactsConfig;
    source: string | null | undefined;
    ownerEntityId: string | null | undefined;
}): OwnerContactResolution | null;
export declare function loadOwnerContactsConfig(context: OwnerContactsLoadContext): OwnerContactsConfig;
export declare function loadOwnerContactRoutingHints(runtime: RuntimeLike | null | undefined, ownerContacts: OwnerContactsConfig): Promise<Record<string, OwnerContactRoutingHint>>;
export {};
