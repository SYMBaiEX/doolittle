export const DEFAULT_MODEL_CONTEXT_WINDOW = 1_000_000;
const DEFAULT_MODEL_INPUT = ["text"];
const DEFAULT_MODEL_COST = {
    input: 0,
    output: 0,
    cacheRead: 0,
    cacheWrite: 0,
};
function toPositiveInt(value) {
    if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) {
        return undefined;
    }
    return Math.floor(value);
}
function toFiniteNonNegativeNumber(value) {
    if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
        return undefined;
    }
    return value;
}
function nonNegativeNumberOrDefault(value, defaultValue) {
    const normalized = toFiniteNonNegativeNumber(value);
    return normalized === undefined ? defaultValue : normalized;
}
function normalizeCost(value) {
    const record = value && typeof value === "object" && !Array.isArray(value)
        ? value
        : {};
    return {
        input: nonNegativeNumberOrDefault(record.input, DEFAULT_MODEL_COST.input),
        output: nonNegativeNumberOrDefault(record.output, DEFAULT_MODEL_COST.output),
        cacheRead: nonNegativeNumberOrDefault(record.cacheRead, DEFAULT_MODEL_COST.cacheRead),
        cacheWrite: nonNegativeNumberOrDefault(record.cacheWrite, DEFAULT_MODEL_COST.cacheWrite),
    };
}
function normalizeInput(value) {
    if (!Array.isArray(value)) {
        return [...DEFAULT_MODEL_INPUT];
    }
    const normalized = value.filter((entry) => entry === "text" || entry === "image");
    return normalized.length > 0 ? normalized : [...DEFAULT_MODEL_INPUT];
}
export function normalizeModelDefinitionConfig(model, defaults) {
    const { maxTokens: _unvalidatedMaxTokens, ...modelWithoutMaxTokens } = model;
    const contextWindow = toPositiveInt(model.contextWindow) ??
        toPositiveInt(defaults?.contextWindow) ??
        DEFAULT_MODEL_CONTEXT_WINDOW;
    const maxTokens = toPositiveInt(model.maxTokens) ?? toPositiveInt(defaults?.maxTokens);
    return {
        ...modelWithoutMaxTokens,
        id: model.id,
        name: typeof model.name === "string" && model.name.trim().length > 0
            ? model.name
            : model.id,
        reasoning: Boolean(model.reasoning),
        input: normalizeInput(model.input),
        cost: normalizeCost(model.cost ?? DEFAULT_MODEL_COST),
        contextWindow,
        ...(maxTokens !== undefined ? { maxTokens } : {}),
    };
}
export function normalizeModelMetadataInConfig(config) {
    const providers = config.models?.providers;
    if (!providers)
        return;
    const discoveryDefaults = config.models?.bedrockDiscovery;
    const defaults = {
        contextWindow: discoveryDefaults?.defaultContextWindow,
        maxTokens: discoveryDefaults?.defaultMaxTokens,
    };
    for (const [providerId, provider] of Object.entries(providers)) {
        const providerRecord = provider;
        providerRecord.models = providerRecord.models.map((model) => normalizeModelDefinitionConfig({ ...model, id: model.id }, providerId === "bedrock" ? defaults : undefined));
    }
}
function normalizeModelLookupKey(value) {
    return value.trim().toLowerCase();
}
function configuredModelKeys(providerId, modelId) {
    const normalizedProvider = normalizeModelLookupKey(providerId);
    const normalizedModel = normalizeModelLookupKey(modelId);
    const slashSuffix = normalizedModel.split("/").at(-1) ?? normalizedModel;
    return [
        normalizedModel,
        `${normalizedProvider}/${normalizedModel}`,
        `${normalizedProvider}/${slashSuffix}`,
        slashSuffix,
    ];
}
function readAgentDefaultContextTokens(config) {
    return toPositiveInt(config?.agents?.defaults?.contextTokens);
}
function findConfiguredModel(config, modelId) {
    if (!config?.models?.providers || !modelId)
        return undefined;
    const lookupKey = normalizeModelLookupKey(modelId);
    if (!lookupKey)
        return undefined;
    for (const [providerId, provider] of Object.entries(config.models.providers)) {
        for (const model of provider.models) {
            if (configuredModelKeys(providerId, model.id).includes(lookupKey)) {
                return { providerId, model };
            }
        }
    }
    return undefined;
}
export function resolveModelTokenMetadata(config, modelId) {
    const configured = findConfiguredModel(config, modelId);
    if (configured) {
        return {
            modelId: configured.model.id,
            providerId: configured.providerId,
            contextWindow: toPositiveInt(configured.model.contextWindow) ??
                DEFAULT_MODEL_CONTEXT_WINDOW,
            ...(toPositiveInt(configured.model.maxTokens) !== undefined
                ? { maxTokens: toPositiveInt(configured.model.maxTokens) }
                : {}),
            source: "model-config",
        };
    }
    const defaultContextWindow = readAgentDefaultContextTokens(config);
    if (defaultContextWindow !== undefined) {
        return {
            modelId: modelId?.trim() || "runtime-default",
            contextWindow: defaultContextWindow,
            source: "agent-defaults",
        };
    }
    return {
        modelId: modelId?.trim() || "runtime-default",
        contextWindow: DEFAULT_MODEL_CONTEXT_WINDOW,
        source: "runtime-default",
    };
}
