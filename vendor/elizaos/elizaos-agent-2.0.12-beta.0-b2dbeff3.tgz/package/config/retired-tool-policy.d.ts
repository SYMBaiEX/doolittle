/** Empty historical lists and the unrestricted full profile impose no policy. */
export declare function unsupportedToolPolicyKeys(value: unknown): string[];
/** Character JSON and restored characters carry the historical settings shape. */
export declare function assertNoRetiredCharacterToolRestrictions(settings: unknown): void;
/** Guard actual disk load/write as well as the separate settings schema. */
export declare function assertNoRetiredToolRestrictions(config: unknown): void;
