/**
 * Zod schemas validating the messaging-connector (`channels.*`) config for each
 * supported platform: Telegram, Discord, Google Chat, Slack, iMessage,
 * MS Teams, WhatsApp, Twitter/X, Twitch, and the live-streaming destinations
 * (Twitch/YouTube/custom-RTMP/Pumpfun/X). Each connector carries account,
 * group/channel, DM/group policy, per-scope tool policy, and delivery/streaming
 * knobs; refinements enforce that an "open" DM policy includes `allowFrom: ["*"]`
 * and that HTTP webhooks declare a signing secret.
 */
import * as zod from "zod";
export declare const TelegramTopicSchema: zod.ZodObject<{
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    systemPrompt: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const TelegramGroupSchema: zod.ZodObject<{
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    tools: zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>>;
    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    systemPrompt: zod.ZodOptional<zod.ZodString>;
    topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const TelegramAccountSchemaBase: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodArray<zod.ZodString>, zod.ZodObject<{
        inlineButtons: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            group: "group";
            dm: "dm";
            allowlist: "allowlist";
        }>>;
    }, zod.z.core.$strict>]>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    customCommands: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        command: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
        description: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
    }, zod.z.core.$strict>>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    botToken: zod.ZodOptional<zod.ZodString>;
    tokenFile: zod.ZodOptional<zod.ZodString>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
        topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    draftChunk: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
    }, zod.z.core.$strict>>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    streamMode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        off: "off";
        partial: "partial";
        block: "block";
    }>>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    retry: zod.ZodOptional<zod.ZodObject<{
        attempts: zod.ZodOptional<zod.ZodNumber>;
        minDelayMs: zod.ZodOptional<zod.ZodNumber>;
        maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
        jitter: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    network: zod.ZodOptional<zod.ZodObject<{
        autoSelectFamily: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    proxy: zod.ZodOptional<zod.ZodString>;
    webhookUrl: zod.ZodOptional<zod.ZodString>;
    webhookSecret: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodOptional<zod.ZodString>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        sendMessage: zod.ZodOptional<zod.ZodBoolean>;
        deleteMessage: zod.ZodOptional<zod.ZodBoolean>;
        sticker: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        off: "off";
        own: "own";
    }>>;
    reactionLevel: zod.ZodOptional<zod.ZodEnum<{
        off: "off";
        minimal: "minimal";
        ack: "ack";
        extensive: "extensive";
    }>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    linkPreview: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>;
export declare const TelegramAccountSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodArray<zod.ZodString>, zod.ZodObject<{
        inlineButtons: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            group: "group";
            dm: "dm";
            allowlist: "allowlist";
        }>>;
    }, zod.z.core.$strict>]>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    customCommands: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        command: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
        description: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
    }, zod.z.core.$strict>>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    botToken: zod.ZodOptional<zod.ZodString>;
    tokenFile: zod.ZodOptional<zod.ZodString>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
        topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    draftChunk: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
    }, zod.z.core.$strict>>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    streamMode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        off: "off";
        partial: "partial";
        block: "block";
    }>>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    retry: zod.ZodOptional<zod.ZodObject<{
        attempts: zod.ZodOptional<zod.ZodNumber>;
        minDelayMs: zod.ZodOptional<zod.ZodNumber>;
        maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
        jitter: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    network: zod.ZodOptional<zod.ZodObject<{
        autoSelectFamily: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    proxy: zod.ZodOptional<zod.ZodString>;
    webhookUrl: zod.ZodOptional<zod.ZodString>;
    webhookSecret: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodOptional<zod.ZodString>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        sendMessage: zod.ZodOptional<zod.ZodBoolean>;
        deleteMessage: zod.ZodOptional<zod.ZodBoolean>;
        sticker: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        off: "off";
        own: "own";
    }>>;
    reactionLevel: zod.ZodOptional<zod.ZodEnum<{
        off: "off";
        minimal: "minimal";
        ack: "ack";
        extensive: "extensive";
    }>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    linkPreview: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>;
export declare const TelegramConfigSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodArray<zod.ZodString>, zod.ZodObject<{
        inlineButtons: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            group: "group";
            dm: "dm";
            allowlist: "allowlist";
        }>>;
    }, zod.z.core.$strict>]>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    customCommands: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        command: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
        description: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
    }, zod.z.core.$strict>>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    botToken: zod.ZodOptional<zod.ZodString>;
    tokenFile: zod.ZodOptional<zod.ZodString>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
        topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    draftChunk: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
    }, zod.z.core.$strict>>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    streamMode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        off: "off";
        partial: "partial";
        block: "block";
    }>>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    retry: zod.ZodOptional<zod.ZodObject<{
        attempts: zod.ZodOptional<zod.ZodNumber>;
        minDelayMs: zod.ZodOptional<zod.ZodNumber>;
        maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
        jitter: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    network: zod.ZodOptional<zod.ZodObject<{
        autoSelectFamily: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    proxy: zod.ZodOptional<zod.ZodString>;
    webhookUrl: zod.ZodOptional<zod.ZodString>;
    webhookSecret: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodOptional<zod.ZodString>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        sendMessage: zod.ZodOptional<zod.ZodBoolean>;
        deleteMessage: zod.ZodOptional<zod.ZodBoolean>;
        sticker: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        off: "off";
        own: "own";
    }>>;
    reactionLevel: zod.ZodOptional<zod.ZodEnum<{
        off: "off";
        minimal: "minimal";
        ack: "ack";
        extensive: "extensive";
    }>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    linkPreview: zod.ZodOptional<zod.ZodBoolean>;
    accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodArray<zod.ZodString>, zod.ZodObject<{
            inlineButtons: zod.ZodOptional<zod.ZodEnum<{
                all: "all";
                off: "off";
                group: "group";
                dm: "dm";
                allowlist: "allowlist";
            }>>;
        }, zod.z.core.$strict>]>>;
        markdown: zod.ZodOptional<zod.ZodObject<{
            tables: zod.ZodOptional<zod.ZodEnum<{
                code: "code";
                off: "off";
                bullets: "bullets";
            }>>;
        }, zod.z.core.$strict>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        commands: zod.ZodOptional<zod.ZodObject<{
            native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
            nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        }, zod.z.core.$strict>>;
        customCommands: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            command: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
            description: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
        }, zod.z.core.$strict>>>;
        configWrites: zod.ZodOptional<zod.ZodBoolean>;
        dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        botToken: zod.ZodOptional<zod.ZodString>;
        tokenFile: zod.ZodOptional<zod.ZodString>;
        replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
            topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                systemPrompt: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
        dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
        dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>>;
        textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
        chunkMode: zod.ZodOptional<zod.ZodEnum<{
            length: "length";
            newline: "newline";
        }>>;
        blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
        draftChunk: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
        }, zod.z.core.$strict>>;
        blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            idleMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        streamMode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            off: "off";
            partial: "partial";
            block: "block";
        }>>>;
        mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        retry: zod.ZodOptional<zod.ZodObject<{
            attempts: zod.ZodOptional<zod.ZodNumber>;
            minDelayMs: zod.ZodOptional<zod.ZodNumber>;
            maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
            jitter: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        network: zod.ZodOptional<zod.ZodObject<{
            autoSelectFamily: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        proxy: zod.ZodOptional<zod.ZodString>;
        webhookUrl: zod.ZodOptional<zod.ZodString>;
        webhookSecret: zod.ZodOptional<zod.ZodString>;
        webhookPath: zod.ZodOptional<zod.ZodString>;
        actions: zod.ZodOptional<zod.ZodObject<{
            reactions: zod.ZodOptional<zod.ZodBoolean>;
            sendMessage: zod.ZodOptional<zod.ZodBoolean>;
            deleteMessage: zod.ZodOptional<zod.ZodBoolean>;
            sticker: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            own: "own";
        }>>;
        reactionLevel: zod.ZodOptional<zod.ZodEnum<{
            off: "off";
            minimal: "minimal";
            ack: "ack";
            extensive: "extensive";
        }>>;
        heartbeat: zod.ZodOptional<zod.ZodObject<{
            showOk: zod.ZodOptional<zod.ZodBoolean>;
            showAlerts: zod.ZodOptional<zod.ZodBoolean>;
            useIndicator: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        linkPreview: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const TelegramAccountConnectorSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    phone: zod.ZodOptional<zod.ZodString>;
    appId: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
    appHash: zod.ZodOptional<zod.ZodString>;
    deviceModel: zod.ZodOptional<zod.ZodString>;
    systemVersion: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const DiscordDmSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
    groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
}, zod.z.core.$strict>;
export declare const DiscordGuildChannelSchema: zod.ZodObject<{
    allow: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    tools: zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>>;
    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    systemPrompt: zod.ZodOptional<zod.ZodString>;
    autoThread: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>;
export declare const DiscordGuildSchema: zod.ZodObject<{
    slug: zod.ZodOptional<zod.ZodString>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    tools: zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>>;
    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        off: "off";
        allowlist: "allowlist";
        own: "own";
    }>>;
    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
        autoThread: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const DiscordAccountSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    token: zod.ZodOptional<zod.ZodString>;
    syncProfile: zod.ZodOptional<zod.ZodBoolean>;
    profileName: zod.ZodOptional<zod.ZodString>;
    profileAvatar: zod.ZodOptional<zod.ZodString>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    maxLinesPerMessage: zod.ZodOptional<zod.ZodNumber>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    retry: zod.ZodOptional<zod.ZodObject<{
        attempts: zod.ZodOptional<zod.ZodNumber>;
        minDelayMs: zod.ZodOptional<zod.ZodNumber>;
        maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
        jitter: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        stickers: zod.ZodOptional<zod.ZodBoolean>;
        emojiUploads: zod.ZodOptional<zod.ZodBoolean>;
        stickerUploads: zod.ZodOptional<zod.ZodBoolean>;
        polls: zod.ZodOptional<zod.ZodBoolean>;
        permissions: zod.ZodOptional<zod.ZodBoolean>;
        messages: zod.ZodOptional<zod.ZodBoolean>;
        threads: zod.ZodOptional<zod.ZodBoolean>;
        pins: zod.ZodOptional<zod.ZodBoolean>;
        search: zod.ZodOptional<zod.ZodBoolean>;
        memberInfo: zod.ZodOptional<zod.ZodBoolean>;
        roleInfo: zod.ZodOptional<zod.ZodBoolean>;
        roles: zod.ZodOptional<zod.ZodBoolean>;
        channelInfo: zod.ZodOptional<zod.ZodBoolean>;
        voiceStatus: zod.ZodOptional<zod.ZodBoolean>;
        events: zod.ZodOptional<zod.ZodBoolean>;
        moderation: zod.ZodOptional<zod.ZodBoolean>;
        channels: zod.ZodOptional<zod.ZodBoolean>;
        presence: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    dm: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
        groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    }, zod.z.core.$strict>>;
    guilds: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        slug: zod.ZodOptional<zod.ZodString>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            allowlist: "allowlist";
            own: "own";
        }>>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodBoolean>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
            autoThread: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    execApprovals: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        approvers: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        agentFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        sessionFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    intents: zod.ZodOptional<zod.ZodObject<{
        presence: zod.ZodOptional<zod.ZodBoolean>;
        guildMembers: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    pluralkit: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        token: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const DiscordConfigSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    token: zod.ZodOptional<zod.ZodString>;
    syncProfile: zod.ZodOptional<zod.ZodBoolean>;
    profileName: zod.ZodOptional<zod.ZodString>;
    profileAvatar: zod.ZodOptional<zod.ZodString>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    maxLinesPerMessage: zod.ZodOptional<zod.ZodNumber>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    retry: zod.ZodOptional<zod.ZodObject<{
        attempts: zod.ZodOptional<zod.ZodNumber>;
        minDelayMs: zod.ZodOptional<zod.ZodNumber>;
        maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
        jitter: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        stickers: zod.ZodOptional<zod.ZodBoolean>;
        emojiUploads: zod.ZodOptional<zod.ZodBoolean>;
        stickerUploads: zod.ZodOptional<zod.ZodBoolean>;
        polls: zod.ZodOptional<zod.ZodBoolean>;
        permissions: zod.ZodOptional<zod.ZodBoolean>;
        messages: zod.ZodOptional<zod.ZodBoolean>;
        threads: zod.ZodOptional<zod.ZodBoolean>;
        pins: zod.ZodOptional<zod.ZodBoolean>;
        search: zod.ZodOptional<zod.ZodBoolean>;
        memberInfo: zod.ZodOptional<zod.ZodBoolean>;
        roleInfo: zod.ZodOptional<zod.ZodBoolean>;
        roles: zod.ZodOptional<zod.ZodBoolean>;
        channelInfo: zod.ZodOptional<zod.ZodBoolean>;
        voiceStatus: zod.ZodOptional<zod.ZodBoolean>;
        events: zod.ZodOptional<zod.ZodBoolean>;
        moderation: zod.ZodOptional<zod.ZodBoolean>;
        channels: zod.ZodOptional<zod.ZodBoolean>;
        presence: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    dm: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
        groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    }, zod.z.core.$strict>>;
    guilds: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        slug: zod.ZodOptional<zod.ZodString>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            allowlist: "allowlist";
            own: "own";
        }>>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodBoolean>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
            autoThread: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    execApprovals: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        approvers: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        agentFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        sessionFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    intents: zod.ZodOptional<zod.ZodObject<{
        presence: zod.ZodOptional<zod.ZodBoolean>;
        guildMembers: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    pluralkit: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        token: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        markdown: zod.ZodOptional<zod.ZodObject<{
            tables: zod.ZodOptional<zod.ZodEnum<{
                code: "code";
                off: "off";
                bullets: "bullets";
            }>>;
        }, zod.z.core.$strict>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        commands: zod.ZodOptional<zod.ZodObject<{
            native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
            nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        }, zod.z.core.$strict>>;
        configWrites: zod.ZodOptional<zod.ZodBoolean>;
        token: zod.ZodOptional<zod.ZodString>;
        syncProfile: zod.ZodOptional<zod.ZodBoolean>;
        profileName: zod.ZodOptional<zod.ZodString>;
        profileAvatar: zod.ZodOptional<zod.ZodString>;
        allowBots: zod.ZodOptional<zod.ZodBoolean>;
        groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
        dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
        dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>>;
        textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
        chunkMode: zod.ZodOptional<zod.ZodEnum<{
            length: "length";
            newline: "newline";
        }>>;
        blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
        blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            idleMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        maxLinesPerMessage: zod.ZodOptional<zod.ZodNumber>;
        mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
        retry: zod.ZodOptional<zod.ZodObject<{
            attempts: zod.ZodOptional<zod.ZodNumber>;
            minDelayMs: zod.ZodOptional<zod.ZodNumber>;
            maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
            jitter: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        actions: zod.ZodOptional<zod.ZodObject<{
            reactions: zod.ZodOptional<zod.ZodBoolean>;
            stickers: zod.ZodOptional<zod.ZodBoolean>;
            emojiUploads: zod.ZodOptional<zod.ZodBoolean>;
            stickerUploads: zod.ZodOptional<zod.ZodBoolean>;
            polls: zod.ZodOptional<zod.ZodBoolean>;
            permissions: zod.ZodOptional<zod.ZodBoolean>;
            messages: zod.ZodOptional<zod.ZodBoolean>;
            threads: zod.ZodOptional<zod.ZodBoolean>;
            pins: zod.ZodOptional<zod.ZodBoolean>;
            search: zod.ZodOptional<zod.ZodBoolean>;
            memberInfo: zod.ZodOptional<zod.ZodBoolean>;
            roleInfo: zod.ZodOptional<zod.ZodBoolean>;
            roles: zod.ZodOptional<zod.ZodBoolean>;
            channelInfo: zod.ZodOptional<zod.ZodBoolean>;
            voiceStatus: zod.ZodOptional<zod.ZodBoolean>;
            events: zod.ZodOptional<zod.ZodBoolean>;
            moderation: zod.ZodOptional<zod.ZodBoolean>;
            channels: zod.ZodOptional<zod.ZodBoolean>;
            presence: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        dm: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
            groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        }, zod.z.core.$strict>>;
        guilds: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            slug: zod.ZodOptional<zod.ZodString>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
            reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                all: "all";
                off: "off";
                allowlist: "allowlist";
                own: "own";
            }>>;
            users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodBoolean>;
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
                skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                systemPrompt: zod.ZodOptional<zod.ZodString>;
                autoThread: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>>;
        heartbeat: zod.ZodOptional<zod.ZodObject<{
            showOk: zod.ZodOptional<zod.ZodBoolean>;
            showAlerts: zod.ZodOptional<zod.ZodBoolean>;
            useIndicator: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        execApprovals: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            approvers: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            agentFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            sessionFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        intents: zod.ZodOptional<zod.ZodObject<{
            presence: zod.ZodOptional<zod.ZodBoolean>;
            guildMembers: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        pluralkit: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            token: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const DiscordLocalConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    clientId: zod.ZodOptional<zod.ZodString>;
    clientSecret: zod.ZodOptional<zod.ZodString>;
    scopes: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    messageChannelIds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    sendDelayMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>;
export declare const GoogleChatDmSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
}, zod.z.core.$strict>;
export declare const GoogleChatGroupSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    allow: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    systemPrompt: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const GoogleChatAccountSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allow: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
    serviceAccount: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnknown>]>>;
    serviceAccountFile: zod.ZodOptional<zod.ZodString>;
    audienceType: zod.ZodOptional<zod.ZodEnum<{
        "app-url": "app-url";
        "project-number": "project-number";
    }>>;
    audience: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodOptional<zod.ZodString>;
    webhookUrl: zod.ZodOptional<zod.ZodString>;
    botUser: zod.ZodOptional<zod.ZodString>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    dm: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    }, zod.z.core.$strict>>;
    typingIndicator: zod.ZodOptional<zod.ZodEnum<{
        message: "message";
        none: "none";
        reaction: "reaction";
    }>>;
}, zod.z.core.$strict>;
export declare const GoogleChatConfigSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allow: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
    serviceAccount: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnknown>]>>;
    serviceAccountFile: zod.ZodOptional<zod.ZodString>;
    audienceType: zod.ZodOptional<zod.ZodEnum<{
        "app-url": "app-url";
        "project-number": "project-number";
    }>>;
    audience: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodOptional<zod.ZodString>;
    webhookUrl: zod.ZodOptional<zod.ZodString>;
    botUser: zod.ZodOptional<zod.ZodString>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    dm: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    }, zod.z.core.$strict>>;
    typingIndicator: zod.ZodOptional<zod.ZodEnum<{
        message: "message";
        none: "none";
        reaction: "reaction";
    }>>;
    accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        configWrites: zod.ZodOptional<zod.ZodBoolean>;
        allowBots: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allow: zod.ZodOptional<zod.ZodBoolean>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
        serviceAccount: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnknown>]>>;
        serviceAccountFile: zod.ZodOptional<zod.ZodString>;
        audienceType: zod.ZodOptional<zod.ZodEnum<{
            "app-url": "app-url";
            "project-number": "project-number";
        }>>;
        audience: zod.ZodOptional<zod.ZodString>;
        webhookPath: zod.ZodOptional<zod.ZodString>;
        webhookUrl: zod.ZodOptional<zod.ZodString>;
        botUser: zod.ZodOptional<zod.ZodString>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
        dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
        dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>>;
        textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
        chunkMode: zod.ZodOptional<zod.ZodEnum<{
            length: "length";
            newline: "newline";
        }>>;
        blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
        blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            idleMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
        replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        actions: zod.ZodOptional<zod.ZodObject<{
            reactions: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        dm: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        }, zod.z.core.$strict>>;
        typingIndicator: zod.ZodOptional<zod.ZodEnum<{
            message: "message";
            none: "none";
            reaction: "reaction";
        }>>;
    }, zod.z.core.$strict>>>>;
    defaultAccount: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const SlackDmSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
    groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
}, zod.z.core.$strict>;
export declare const SlackChannelSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    allow: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    tools: zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    systemPrompt: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const SlackThreadSchema: zod.ZodObject<{
    historyScope: zod.ZodOptional<zod.ZodEnum<{
        channel: "channel";
        thread: "thread";
    }>>;
    inheritParent: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>;
export declare const SlackAccountSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    mode: zod.ZodOptional<zod.ZodEnum<{
        http: "http";
        socket: "socket";
    }>>;
    signingSecret: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    botToken: zod.ZodOptional<zod.ZodString>;
    appToken: zod.ZodOptional<zod.ZodString>;
    userToken: zod.ZodOptional<zod.ZodString>;
    userTokenReadOnly: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        off: "off";
        allowlist: "allowlist";
        own: "own";
    }>>;
    reactionAllowlist: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    replyToModeByChatType: zod.ZodOptional<zod.ZodObject<{
        direct: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        group: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    }, zod.z.core.$strict>>;
    thread: zod.ZodOptional<zod.ZodObject<{
        historyScope: zod.ZodOptional<zod.ZodEnum<{
            channel: "channel";
            thread: "thread";
        }>>;
        inheritParent: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        messages: zod.ZodOptional<zod.ZodBoolean>;
        pins: zod.ZodOptional<zod.ZodBoolean>;
        search: zod.ZodOptional<zod.ZodBoolean>;
        permissions: zod.ZodOptional<zod.ZodBoolean>;
        memberInfo: zod.ZodOptional<zod.ZodBoolean>;
        channelInfo: zod.ZodOptional<zod.ZodBoolean>;
        emojiList: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    slashCommand: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        name: zod.ZodOptional<zod.ZodString>;
        sessionPrefix: zod.ZodOptional<zod.ZodString>;
        ephemeral: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    dm: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
        groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    }, zod.z.core.$strict>>;
    channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allow: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        allowBots: zod.ZodOptional<zod.ZodBoolean>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const SlackConfigSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    commands: zod.ZodOptional<zod.ZodObject<{
        native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    botToken: zod.ZodOptional<zod.ZodString>;
    appToken: zod.ZodOptional<zod.ZodString>;
    userToken: zod.ZodOptional<zod.ZodString>;
    userTokenReadOnly: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    allowBots: zod.ZodOptional<zod.ZodBoolean>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        off: "off";
        allowlist: "allowlist";
        own: "own";
    }>>;
    reactionAllowlist: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    replyToModeByChatType: zod.ZodOptional<zod.ZodObject<{
        direct: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        group: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    }, zod.z.core.$strict>>;
    thread: zod.ZodOptional<zod.ZodObject<{
        historyScope: zod.ZodOptional<zod.ZodEnum<{
            channel: "channel";
            thread: "thread";
        }>>;
        inheritParent: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        messages: zod.ZodOptional<zod.ZodBoolean>;
        pins: zod.ZodOptional<zod.ZodBoolean>;
        search: zod.ZodOptional<zod.ZodBoolean>;
        permissions: zod.ZodOptional<zod.ZodBoolean>;
        memberInfo: zod.ZodOptional<zod.ZodBoolean>;
        channelInfo: zod.ZodOptional<zod.ZodBoolean>;
        emojiList: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    slashCommand: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        name: zod.ZodOptional<zod.ZodString>;
        sessionPrefix: zod.ZodOptional<zod.ZodString>;
        ephemeral: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    dm: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
        groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
    }, zod.z.core.$strict>>;
    channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allow: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        allowBots: zod.ZodOptional<zod.ZodBoolean>;
        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        systemPrompt: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    mode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        http: "http";
        socket: "socket";
    }>>>;
    signingSecret: zod.ZodOptional<zod.ZodString>;
    webhookPath: zod.ZodDefault<zod.ZodOptional<zod.ZodString>>;
    accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        mode: zod.ZodOptional<zod.ZodEnum<{
            http: "http";
            socket: "socket";
        }>>;
        signingSecret: zod.ZodOptional<zod.ZodString>;
        webhookPath: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        markdown: zod.ZodOptional<zod.ZodObject<{
            tables: zod.ZodOptional<zod.ZodEnum<{
                code: "code";
                off: "off";
                bullets: "bullets";
            }>>;
        }, zod.z.core.$strict>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        commands: zod.ZodOptional<zod.ZodObject<{
            native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
            nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
        }, zod.z.core.$strict>>;
        configWrites: zod.ZodOptional<zod.ZodBoolean>;
        botToken: zod.ZodOptional<zod.ZodString>;
        appToken: zod.ZodOptional<zod.ZodString>;
        userToken: zod.ZodOptional<zod.ZodString>;
        userTokenReadOnly: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
        allowBots: zod.ZodOptional<zod.ZodBoolean>;
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
        dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
        dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>>;
        textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
        chunkMode: zod.ZodOptional<zod.ZodEnum<{
            length: "length";
            newline: "newline";
        }>>;
        blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
        blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            idleMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
        reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            off: "off";
            allowlist: "allowlist";
            own: "own";
        }>>;
        reactionAllowlist: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        replyToModeByChatType: zod.ZodOptional<zod.ZodObject<{
            direct: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            group: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        }, zod.z.core.$strict>>;
        thread: zod.ZodOptional<zod.ZodObject<{
            historyScope: zod.ZodOptional<zod.ZodEnum<{
                channel: "channel";
                thread: "thread";
            }>>;
            inheritParent: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        actions: zod.ZodOptional<zod.ZodObject<{
            reactions: zod.ZodOptional<zod.ZodBoolean>;
            messages: zod.ZodOptional<zod.ZodBoolean>;
            pins: zod.ZodOptional<zod.ZodBoolean>;
            search: zod.ZodOptional<zod.ZodBoolean>;
            permissions: zod.ZodOptional<zod.ZodBoolean>;
            memberInfo: zod.ZodOptional<zod.ZodBoolean>;
            channelInfo: zod.ZodOptional<zod.ZodBoolean>;
            emojiList: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        slashCommand: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            name: zod.ZodOptional<zod.ZodString>;
            sessionPrefix: zod.ZodOptional<zod.ZodString>;
            ephemeral: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        dm: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
            groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
        }, zod.z.core.$strict>>;
        channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allow: zod.ZodOptional<zod.ZodBoolean>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
            allowBots: zod.ZodOptional<zod.ZodBoolean>;
            users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            systemPrompt: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
        heartbeat: zod.ZodOptional<zod.ZodObject<{
            showOk: zod.ZodOptional<zod.ZodBoolean>;
            showAlerts: zod.ZodOptional<zod.ZodBoolean>;
            useIndicator: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const IMessageAccountSchemaBase: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    cliPath: zod.ZodOptional<zod.ZodString>;
    dbPath: zod.ZodOptional<zod.ZodString>;
    remoteHost: zod.ZodOptional<zod.ZodString>;
    service: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"imessage">, zod.ZodLiteral<"sms">, zod.ZodLiteral<"auto">]>>;
    region: zod.ZodOptional<zod.ZodString>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    includeAttachments: zod.ZodOptional<zod.ZodBoolean>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const IMessageAccountSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    cliPath: zod.ZodOptional<zod.ZodString>;
    dbPath: zod.ZodOptional<zod.ZodString>;
    remoteHost: zod.ZodOptional<zod.ZodString>;
    service: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"imessage">, zod.ZodLiteral<"sms">, zod.ZodLiteral<"auto">]>>;
    region: zod.ZodOptional<zod.ZodString>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    includeAttachments: zod.ZodOptional<zod.ZodBoolean>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const IMessageConfigSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    cliPath: zod.ZodOptional<zod.ZodString>;
    dbPath: zod.ZodOptional<zod.ZodString>;
    remoteHost: zod.ZodOptional<zod.ZodString>;
    service: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"imessage">, zod.ZodLiteral<"sms">, zod.ZodLiteral<"auto">]>>;
    region: zod.ZodOptional<zod.ZodString>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    includeAttachments: zod.ZodOptional<zod.ZodBoolean>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        markdown: zod.ZodOptional<zod.ZodObject<{
            tables: zod.ZodOptional<zod.ZodEnum<{
                code: "code";
                off: "off";
                bullets: "bullets";
            }>>;
        }, zod.z.core.$strict>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        configWrites: zod.ZodOptional<zod.ZodBoolean>;
        cliPath: zod.ZodOptional<zod.ZodString>;
        dbPath: zod.ZodOptional<zod.ZodString>;
        remoteHost: zod.ZodOptional<zod.ZodString>;
        service: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"imessage">, zod.ZodLiteral<"sms">, zod.ZodLiteral<"auto">]>>;
        region: zod.ZodOptional<zod.ZodString>;
        dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
        groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
        dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
        dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>>;
        includeAttachments: zod.ZodOptional<zod.ZodBoolean>;
        mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
        textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
        chunkMode: zod.ZodOptional<zod.ZodEnum<{
            length: "length";
            newline: "newline";
        }>>;
        blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
        blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            idleMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>>;
        heartbeat: zod.ZodOptional<zod.ZodObject<{
            showOk: zod.ZodOptional<zod.ZodBoolean>;
            showAlerts: zod.ZodOptional<zod.ZodBoolean>;
            useIndicator: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const TwitchConnectorConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    username: zod.ZodOptional<zod.ZodString>;
    clientId: zod.ZodOptional<zod.ZodString>;
    accessToken: zod.ZodOptional<zod.ZodString>;
    clientSecret: zod.ZodOptional<zod.ZodString>;
    refreshToken: zod.ZodOptional<zod.ZodString>;
    channel: zod.ZodOptional<zod.ZodString>;
    channels: zod.ZodOptional<zod.ZodString>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    allowedRoles: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const TwitchStreamConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    streamKey: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const YoutubeStreamConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    streamKey: zod.ZodOptional<zod.ZodString>;
    rtmpUrl: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const CustomRtmpConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    rtmpUrl: zod.ZodOptional<zod.ZodString>;
    rtmpKey: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const PumpfunStreamConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    streamKey: zod.ZodOptional<zod.ZodString>;
    rtmpUrl: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const XStreamConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    streamKey: zod.ZodOptional<zod.ZodString>;
    rtmpUrl: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const NamedRtmpSourceSchema: zod.ZodObject<{
    id: zod.ZodString;
    name: zod.ZodOptional<zod.ZodString>;
    rtmpUrl: zod.ZodString;
    rtmpKey: zod.ZodString;
}, zod.z.core.$strict>;
export declare const MSTeamsChannelSchema: zod.ZodObject<{
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    tools: zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>>;
    replyStyle: zod.ZodOptional<zod.ZodEnum<{
        thread: "thread";
        "top-level": "top-level";
    }>>;
}, zod.z.core.$strict>;
export declare const MSTeamsTeamSchema: zod.ZodObject<{
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    tools: zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>>;
    replyStyle: zod.ZodOptional<zod.ZodEnum<{
        thread: "thread";
        "top-level": "top-level";
    }>>;
    channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        replyStyle: zod.ZodOptional<zod.ZodEnum<{
            thread: "thread";
            "top-level": "top-level";
        }>>;
    }, zod.z.core.$strict>>>>;
}, zod.z.core.$strict>;
export declare const MSTeamsConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    appId: zod.ZodOptional<zod.ZodString>;
    appPassword: zod.ZodOptional<zod.ZodString>;
    tenantId: zod.ZodOptional<zod.ZodString>;
    webhook: zod.ZodOptional<zod.ZodObject<{
        port: zod.ZodOptional<zod.ZodNumber>;
        path: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    mediaAllowHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    mediaAuthAllowHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    requireMention: zod.ZodOptional<zod.ZodBoolean>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    replyStyle: zod.ZodOptional<zod.ZodEnum<{
        thread: "thread";
        "top-level": "top-level";
    }>>;
    teams: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
        replyStyle: zod.ZodOptional<zod.ZodEnum<{
            thread: "thread";
            "top-level": "top-level";
        }>>;
        channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
            replyStyle: zod.ZodOptional<zod.ZodEnum<{
                thread: "thread";
                "top-level": "top-level";
            }>>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    sharePointSiteId: zod.ZodOptional<zod.ZodString>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const WhatsAppAccountSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    sendReadReceipts: zod.ZodOptional<zod.ZodBoolean>;
    messagePrefix: zod.ZodOptional<zod.ZodString>;
    authDir: zod.ZodOptional<zod.ZodString>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    selfChatMode: zod.ZodOptional<zod.ZodBoolean>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    ackReaction: zod.ZodOptional<zod.ZodObject<{
        emoji: zod.ZodOptional<zod.ZodString>;
        direct: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
        group: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            always: "always";
            never: "never";
            mentions: "mentions";
        }>>>;
    }, zod.z.core.$strict>>;
    debounceMs: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const WhatsAppConfigSchema: zod.ZodObject<{
    accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        markdown: zod.ZodOptional<zod.ZodObject<{
            tables: zod.ZodOptional<zod.ZodEnum<{
                code: "code";
                off: "off";
                bullets: "bullets";
            }>>;
        }, zod.z.core.$strict>>;
        configWrites: zod.ZodOptional<zod.ZodBoolean>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        sendReadReceipts: zod.ZodOptional<zod.ZodBoolean>;
        messagePrefix: zod.ZodOptional<zod.ZodString>;
        authDir: zod.ZodOptional<zod.ZodString>;
        dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            pairing: "pairing";
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        selfChatMode: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            disabled: "disabled";
            open: "open";
            allowlist: "allowlist";
        }>>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
        dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
        dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>>;
        textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
        chunkMode: zod.ZodOptional<zod.ZodEnum<{
            length: "length";
            newline: "newline";
        }>>;
        mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
        blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
        blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
            minChars: zod.ZodOptional<zod.ZodNumber>;
            maxChars: zod.ZodOptional<zod.ZodNumber>;
            idleMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>>;
        ackReaction: zod.ZodOptional<zod.ZodObject<{
            emoji: zod.ZodOptional<zod.ZodString>;
            direct: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            group: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                always: "always";
                never: "never";
                mentions: "mentions";
            }>>>;
        }, zod.z.core.$strict>>;
        debounceMs: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
        heartbeat: zod.ZodOptional<zod.ZodObject<{
            showOk: zod.ZodOptional<zod.ZodBoolean>;
            showAlerts: zod.ZodOptional<zod.ZodBoolean>;
            useIndicator: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>>;
    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    markdown: zod.ZodOptional<zod.ZodObject<{
        tables: zod.ZodOptional<zod.ZodEnum<{
            code: "code";
            off: "off";
            bullets: "bullets";
        }>>;
    }, zod.z.core.$strict>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
    sendReadReceipts: zod.ZodOptional<zod.ZodBoolean>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    messagePrefix: zod.ZodOptional<zod.ZodString>;
    selfChatMode: zod.ZodOptional<zod.ZodBoolean>;
    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    historyLimit: zod.ZodOptional<zod.ZodNumber>;
    dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
    dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>>;
    textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
    chunkMode: zod.ZodOptional<zod.ZodEnum<{
        length: "length";
        newline: "newline";
    }>>;
    mediaMaxMb: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    actions: zod.ZodOptional<zod.ZodObject<{
        reactions: zod.ZodOptional<zod.ZodBoolean>;
        sendMessage: zod.ZodOptional<zod.ZodBoolean>;
        polls: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
        requireMention: zod.ZodOptional<zod.ZodBoolean>;
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>>;
    }, zod.z.core.$strict>>>>;
    ackReaction: zod.ZodOptional<zod.ZodObject<{
        emoji: zod.ZodOptional<zod.ZodString>;
        direct: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
        group: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
            always: "always";
            never: "never";
            mentions: "mentions";
        }>>>;
    }, zod.z.core.$strict>>;
    debounceMs: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        showOk: zod.ZodOptional<zod.ZodBoolean>;
        showAlerts: zod.ZodOptional<zod.ZodBoolean>;
        useIndicator: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const TwitterConfigSchema: zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    apiKey: zod.ZodOptional<zod.ZodString>;
    apiSecretKey: zod.ZodOptional<zod.ZodString>;
    accessToken: zod.ZodOptional<zod.ZodString>;
    accessTokenSecret: zod.ZodOptional<zod.ZodString>;
    postEnable: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    postImmediately: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    postIntervalMin: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    postIntervalMax: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    postIntervalVariance: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    searchEnable: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    autoRespondMentions: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    enableActionProcessing: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    timelineAlgorithm: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        latest: "latest";
        weighted: "weighted";
    }>>>;
    dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
        pairing: "pairing";
        disabled: "disabled";
        open: "open";
        allowlist: "allowlist";
    }>>>;
    dryRun: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
    retryLimit: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    pollInterval: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    maxTweetLength: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
    configWrites: zod.ZodOptional<zod.ZodBoolean>;
}, zod.z.core.$strict>;
export type TwitterConfig = zod.infer<typeof TwitterConfigSchema>;
