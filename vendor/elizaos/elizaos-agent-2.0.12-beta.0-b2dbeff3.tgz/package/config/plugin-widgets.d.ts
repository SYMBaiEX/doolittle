/**
 * Server-side plugin widget declarations.
 *
 * Widget declarations come from the plugin's own `widgets` field on its
 * `Plugin` instance; `getPluginWidgets` resolves them for a plugin id by
 * matching against the supplied runtime plugin list.
 */
import type { Plugin, PluginWidgetDeclaration } from "@elizaos/core";
export type PluginWidgetDeclarationServer = PluginWidgetDeclaration;
/**
 * Resolve widget declarations for a plugin by id from the matching runtime
 * plugin instance's own `widgets` field. Returns an empty list when no runtime
 * plugin list is supplied or no matched plugin declares widgets.
 */
export declare function getPluginWidgets(pluginId: string, runtimePlugins?: ReadonlyArray<Plugin>): PluginWidgetDeclaration[];
