/**
 * Validates and normalizes user-defined Telegram bot menu commands. Lowercases
 * and strips a leading slash from each command name, enforces Telegram's name
 * pattern, and rejects entries that collide with reserved/native commands,
 * duplicate an earlier entry, or lack a description — returning the accepted
 * commands alongside per-entry issues for the config UI to surface.
 */
export declare const TELEGRAM_COMMAND_NAME_PATTERN: RegExp;
export type TelegramCustomCommandInput = {
    command?: string | null;
    description?: string | null;
};
export type TelegramCustomCommandIssue = {
    index: number;
    field: "command" | "description";
    message: string;
};
export declare function normalizeTelegramCommandName(value: string): string;
export declare function normalizeTelegramCommandDescription(value: string): string;
export declare function resolveTelegramCustomCommands(params: {
    commands?: TelegramCustomCommandInput[] | null;
    reservedCommands?: Set<string>;
    checkReserved?: boolean;
    checkDuplicates?: boolean;
}): {
    commands: Array<{
        command: string;
        description: string;
    }>;
    issues: TelegramCustomCommandIssue[];
};
