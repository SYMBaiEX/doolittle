/**
 * Projects the eliza config's env and connector settings into flat
 * environment-variable records for plugins. CONNECTOR_ENV_MAP maps each
 * connector's config fields to the env keys its plugin expects;
 * collectConfigEnvVars flattens config.env (nested vars + top-level) and
 * collectConnectorEnvVars walks the configured connectors, normalizing
 * string/number/boolean/array values and mirroring compatibility aliases for
 * Discord and the Blooio-backed iMessage transport.
 * Both drop any key rejected by isBlockedEnvKey (the secret denylist plus the
 * dangerous prefix families).
 */
import { isBlockedEnvKey } from "./blocked-env-keys.js";
// Track the values this config projection actually writes, including cold boot.
// Separate env objects must not share ownership (embedded hosts and tests).
const configEnvWrites = new WeakMap();
export function writeConfigEnvValue(key, value, env = process.env) {
    let owned = configEnvWrites.get(env);
    if (env[key] !== value) {
        owned ??= new Map();
        configEnvWrites.set(env, owned);
        owned.set(key, value);
        env[key] = value;
    }
}
export function clearConfigEnvValue(key, env = process.env) {
    const owned = configEnvWrites.get(env);
    const previous = owned?.get(key);
    if (previous !== undefined && env[key] === previous)
        delete env[key];
    owned?.delete(key);
}
/**
 * Maps connector config fields to the environment variables expected by
 * elizaOS plugins. Keep this aligned with runtime/eliza.ts.
 */
export const CONNECTOR_ENV_MAP = {
    discord: {
        token: "DISCORD_API_TOKEN",
        botToken: "DISCORD_API_TOKEN",
        applicationId: "DISCORD_APPLICATION_ID",
        dmPolicy: "DISCORD_DM_POLICY",
        allowFrom: "DISCORD_ALLOW_FROM",
        // String form of ELIZA_DISCORD_OWNER_USER_IDS_JSON (JSON array text).
        // Array `ownerUserIds` is handled specially below — must JSON.stringify,
        // not comma-join, for parseDiscordOwnerUserIds.
        ownerUserIdsJson: "ELIZA_DISCORD_OWNER_USER_IDS_JSON",
        syncProfile: "DISCORD_SYNC_PROFILE",
        profileName: "DISCORD_PROFILE_NAME",
        profileAvatar: "DISCORD_PROFILE_AVATAR",
    },
    discordLocal: {
        enabled: "DISCORD_LOCAL_ENABLED",
        clientId: "DISCORD_LOCAL_CLIENT_ID",
        clientSecret: "DISCORD_LOCAL_CLIENT_SECRET",
        scopes: "DISCORD_LOCAL_SCOPES",
        messageChannelIds: "DISCORD_LOCAL_MESSAGE_CHANNEL_IDS",
        sendDelayMs: "DISCORD_LOCAL_SEND_DELAY_MS",
    },
    telegram: {
        botToken: "TELEGRAM_BOT_TOKEN",
    },
    telegramAccount: {
        phone: "TELEGRAM_ACCOUNT_PHONE",
        appId: "TELEGRAM_ACCOUNT_APP_ID",
        appHash: "TELEGRAM_ACCOUNT_APP_HASH",
        deviceModel: "TELEGRAM_ACCOUNT_DEVICE_MODEL",
        systemVersion: "TELEGRAM_ACCOUNT_SYSTEM_VERSION",
    },
    slack: {
        botToken: "SLACK_BOT_TOKEN",
        appToken: "SLACK_APP_TOKEN",
        userToken: "SLACK_USER_TOKEN",
        signingSecret: "SLACK_SIGNING_SECRET",
    },
    imessage: {
        enabled: "IMESSAGE_ENABLED",
        cliPath: "IMESSAGE_CLI_PATH",
        dbPath: "IMESSAGE_DB_PATH",
        dmPolicy: "IMESSAGE_DM_POLICY",
        groupPolicy: "IMESSAGE_GROUP_POLICY",
        allowFrom: "IMESSAGE_ALLOW_FROM",
        pollIntervalMs: "IMESSAGE_POLL_INTERVAL_MS",
    },
    whatsapp: {
        authDir: "WHATSAPP_AUTH_DIR",
        sessionPath: "WHATSAPP_AUTH_DIR",
        dmPolicy: "WHATSAPP_DM_POLICY",
        groupPolicy: "WHATSAPP_GROUP_POLICY",
    },
    msteams: {
        appId: "MSTEAMS_APP_ID",
        appPassword: "MSTEAMS_APP_PASSWORD",
    },
    mattermost: {
        botToken: "MATTERMOST_BOT_TOKEN",
        baseUrl: "MATTERMOST_BASE_URL",
    },
    googlechat: {
        serviceAccountKey: "GOOGLE_CHAT_SERVICE_ACCOUNT_KEY",
    },
    blooio: {
        apiKey: "IMESSAGE_BLOOIO_API_KEY",
        fromNumber: "IMESSAGE_BLOOIO_FROM_NUMBER",
        webhookSecret: "IMESSAGE_BLOOIO_WEBHOOK_SECRET",
        channelId: "IMESSAGE_BLOOIO_CHANNEL_ID",
        webhookUrl: "BLOOIO_WEBHOOK_URL",
        webhookPort: "BLOOIO_WEBHOOK_PORT",
    },
};
export function collectConfigEnvVars(cfg) {
    const envConfig = cfg?.env;
    if (!envConfig) {
        return {};
    }
    const entries = {};
    if (envConfig.vars) {
        for (const [key, value] of Object.entries(envConfig.vars)) {
            if (!value) {
                continue;
            }
            if (isBlockedEnvKey(key)) {
                continue;
            }
            entries[key] = value;
        }
    }
    for (const [key, value] of Object.entries(envConfig)) {
        if (key === "shellEnv" || key === "vars") {
            continue;
        }
        if (typeof value !== "string" || !value.trim()) {
            continue;
        }
        if (isBlockedEnvKey(key)) {
            continue;
        }
        entries[key] = value;
    }
    return entries;
}
/** The saved connector settings boot reads: `connectors`, else legacy `channels`. */
export function resolveConnectorConfigs(cfg) {
    const rawConnectors = cfg?.connectors ?? cfg?.channels;
    if (!rawConnectors ||
        typeof rawConnectors !== "object" ||
        Array.isArray(rawConnectors)) {
        return undefined;
    }
    return rawConnectors;
}
export function collectConnectorEnvVars(cfg) {
    const connectors = resolveConnectorConfigs(cfg);
    if (!connectors)
        return {};
    const entries = {};
    for (const [connectorName, envMap] of Object.entries(CONNECTOR_ENV_MAP)) {
        const connectorConfig = connectors[connectorName];
        if (!connectorConfig ||
            typeof connectorConfig !== "object" ||
            Array.isArray(connectorConfig)) {
            continue;
        }
        const configObj = connectorConfig;
        if (connectorName === "blooio") {
            entries.IMESSAGE_TRANSPORT = "blooio";
        }
        // Mirror Discord token aliases so older plugins and settings surfaces
        // agree on a single configured state. Owner snowflakes must stay JSON
        // (not comma-joined) for ELIZA_DISCORD_OWNER_USER_IDS_JSON.
        if (connectorName === "discord") {
            const tokenValue = (typeof configObj.token === "string" && configObj.token.trim()) ||
                (typeof configObj.botToken === "string" && configObj.botToken.trim()) ||
                "";
            if (tokenValue) {
                entries.DISCORD_API_TOKEN = tokenValue;
                entries.DISCORD_BOT_TOKEN = tokenValue;
            }
            const ownerUserIds = configObj.ownerUserIds;
            if (Array.isArray(ownerUserIds)) {
                const snowflakes = ownerUserIds
                    .map((entry) => {
                    if (typeof entry === "string")
                        return entry.trim();
                    if (typeof entry === "number" && Number.isFinite(entry)) {
                        return String(entry);
                    }
                    return "";
                })
                    .filter((entry) => entry.length > 0);
                if (snowflakes.length > 0) {
                    entries.ELIZA_DISCORD_OWNER_USER_IDS_JSON =
                        JSON.stringify(snowflakes);
                }
            }
        }
        for (const [configField, envKey] of Object.entries(envMap)) {
            // Discord token/botToken are handled above with token-first precedence; the
            // env map maps both fields to DISCORD_API_TOKEN, so applying them here would
            // let botToken overwrite token. ownerUserIds is handled above as JSON.
            if (connectorName === "discord" &&
                (configField === "token" ||
                    configField === "botToken" ||
                    configField === "ownerUserIds")) {
                continue;
            }
            const value = configObj[configField];
            let normalized = null;
            if (typeof value === "string") {
                normalized = value.trim() ? value : null;
            }
            else if (typeof value === "number" && Number.isFinite(value)) {
                normalized = String(value);
            }
            else if (typeof value === "boolean") {
                normalized = value ? "true" : "false";
            }
            else if (Array.isArray(value)) {
                const serialized = value
                    .map((entry) => {
                    if (typeof entry === "string")
                        return entry.trim();
                    if (typeof entry === "number" && Number.isFinite(entry)) {
                        return String(entry);
                    }
                    return "";
                })
                    .filter((entry) => entry.length > 0)
                    .join(",");
                normalized = serialized.length > 0 ? serialized : null;
            }
            if (!normalized) {
                continue;
            }
            if (isBlockedEnvKey(envKey)) {
                continue;
            }
            entries[envKey] = normalized;
        }
        if (connectorName === "blooio") {
            const apiKey = entries.IMESSAGE_BLOOIO_API_KEY;
            const webhookSecret = entries.IMESSAGE_BLOOIO_WEBHOOK_SECRET;
            const fromNumber = entries.IMESSAGE_BLOOIO_FROM_NUMBER;
            // plugin-imessage still accepts these pre-canonical names. Project them
            // for older plugin builds and settings consumers while keeping the
            // IMESSAGE_BLOOIO_* keys above as the startup authority.
            if (apiKey)
                entries.BLOOIO_API_KEY = apiKey;
            if (webhookSecret)
                entries.BLOOIO_WEBHOOK_SECRET = webhookSecret;
            if (fromNumber) {
                entries.BLOOIO_FROM_NUMBER = fromNumber;
                entries.BLOOIO_PHONE_NUMBER = fromNumber;
            }
        }
        if (connectorName === "whatsapp") {
            const allowFrom = configObj.allowFrom;
            if (Array.isArray(allowFrom) && allowFrom.length > 0) {
                const normalized = allowFrom
                    .map((value) => String(value).trim())
                    .filter(Boolean);
                if (normalized.length > 0) {
                    entries.WHATSAPP_ALLOW_FROM = normalized.join(",");
                }
            }
            const groupAllowFrom = configObj.groupAllowFrom;
            if (Array.isArray(groupAllowFrom) && groupAllowFrom.length > 0) {
                const normalized = groupAllowFrom
                    .map((value) => String(value).trim())
                    .filter(Boolean);
                if (normalized.length > 0) {
                    entries.WHATSAPP_GROUP_ALLOW_FROM = normalized.join(",");
                }
            }
            const accounts = configObj.accounts;
            if (accounts &&
                typeof accounts === "object" &&
                !Array.isArray(accounts)) {
                const firstEnabledAccount = Object.values(accounts).find((account) => {
                    if (!account ||
                        typeof account !== "object" ||
                        Array.isArray(account)) {
                        return false;
                    }
                    const candidate = account;
                    return (candidate.enabled !== false && typeof candidate.authDir === "string");
                });
                if (firstEnabledAccount &&
                    typeof firstEnabledAccount.authDir === "string" &&
                    firstEnabledAccount.authDir.trim()) {
                    entries.WHATSAPP_AUTH_DIR = firstEnabledAccount.authDir.trim();
                }
            }
        }
    }
    return entries;
}
