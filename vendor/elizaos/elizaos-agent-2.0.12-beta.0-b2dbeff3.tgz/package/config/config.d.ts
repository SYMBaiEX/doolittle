/**
 * Loads and persists the eliza.json runtime config. loadElizaConfig() merges
 * the base config file with the persisted overlay, resolves $include
 * directives, migrates legacy shapes, folds in skills.json extra dirs, and
 * hydrates env/connector vars into process.env (vault sentinels skipped;
 * secrets in config.env are applied to the process without being serialized
 * back to eliza.json). Values saved from the app win over stale .env/shell
 * values. saveElizaConfig() strips include directives and — when the OS
 * keystore is enabled — wallet private keys, then writes atomically via a temp
 * file + rename with 0600 permissions.
 */
import fs from "node:fs";
import { type ElizaConfig } from "@elizaos/host/protocol";
export declare function resolveConfigWritePath(env?: NodeJS.ProcessEnv, canonicalConfigPath?: string): string;
type ConfigReadObserver = (filePath: string) => void;
export declare function loadElizaConfig(onReadFile?: ConfigReadObserver): ElizaConfig;
/**
 * Load the operational/runtime view of config. The durable loader remains the
 * source for settings mutations; network and execution paths use this helper
 * so a launcher-selected dev Cloud target cannot be displaced by persisted
 * production topology or credentials.
 */
export declare function loadEffectiveElizaConfig(): ElizaConfig;
export interface EffectiveElizaConfigSnapshot {
    config: ElizaConfig;
    /** Identity is always checked; callers may throttle file metadata checks. */
    isCurrent(options?: {
        checkFiles?: boolean;
    }): boolean;
}
/**
 * Load once through the canonical loader and record its actual dependency
 * graph, including absent top-level sources. Unchanged checks only stat those
 * paths; they never parse config or walk a second implementation of $include.
 * The process-lifetime development authority is part of snapshot identity.
 */
export declare function loadEffectiveElizaConfigSnapshot(): EffectiveElizaConfigSnapshot;
type RenameSync = (from: fs.PathLike, to: fs.PathLike) => void;
/** Replaces the atomic rename operation for deterministic filesystem tests. */
export declare function __setConfigRenameSyncForTests(renameSync: RenameSync | null): void;
export declare function isWalletOsStoreEnabledInConfig(config: ElizaConfig): boolean;
export declare function saveElizaConfig(config: ElizaConfig): void;
export declare function configFileExists(): boolean;
export {};
