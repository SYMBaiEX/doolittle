/**
 * Zod schemas for session and messaging-behavior config. `SessionSchema` shapes
 * conversation session scoping (per-sender vs global, DM scope granularity),
 * reset triggers and schedules (daily/idle, per chat-type, per channel), typing
 * behavior, send policy, and agent-to-agent ping-pong bounds. `MessagesSchema`
 * covers message/response prefixes, group chat, the inbound queue and debounce,
 * ack reactions, and TTS.
 */
import * as zod from "zod";
export declare const SessionSendPolicySchema: zod.ZodOptional<zod.ZodObject<{
    default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
    rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
        match: zod.ZodOptional<zod.ZodObject<{
            channel: zod.ZodOptional<zod.ZodString>;
            chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
            keyPrefix: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const SessionSchema: zod.ZodOptional<zod.ZodObject<{
    scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"per-sender">, zod.ZodLiteral<"global">]>>;
    dmScope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"main">, zod.ZodLiteral<"per-peer">, zod.ZodLiteral<"per-channel-peer">, zod.ZodLiteral<"per-account-channel-peer">]>>;
    identityLinks: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodString>>>;
    resetTriggers: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    idleMinutes: zod.ZodOptional<zod.ZodNumber>;
    reset: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
        atHour: zod.ZodOptional<zod.ZodNumber>;
        idleMinutes: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    resetByType: zod.ZodOptional<zod.ZodObject<{
        dm: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
            atHour: zod.ZodOptional<zod.ZodNumber>;
            idleMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        group: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
            atHour: zod.ZodOptional<zod.ZodNumber>;
            idleMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        thread: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
            atHour: zod.ZodOptional<zod.ZodNumber>;
            idleMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    resetByChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
        atHour: zod.ZodOptional<zod.ZodNumber>;
        idleMinutes: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>>;
    store: zod.ZodOptional<zod.ZodString>;
    typingIntervalSeconds: zod.ZodOptional<zod.ZodNumber>;
    typingMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"never">, zod.ZodLiteral<"instant">, zod.ZodLiteral<"thinking">, zod.ZodLiteral<"message">]>>;
    mainKey: zod.ZodOptional<zod.ZodString>;
    sendPolicy: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
        default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
        rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
            match: zod.ZodOptional<zod.ZodObject<{
                channel: zod.ZodOptional<zod.ZodString>;
                chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                keyPrefix: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>>;
    agentToAgent: zod.ZodOptional<zod.ZodObject<{
        maxPingPongTurns: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const MessagesSchema: zod.ZodOptional<zod.ZodObject<{
    messagePrefix: zod.ZodOptional<zod.ZodString>;
    responsePrefix: zod.ZodOptional<zod.ZodString>;
    groupChat: zod.ZodOptional<zod.ZodObject<{
        mentionPatterns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    queue: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        byChannel: zod.ZodOptional<zod.ZodObject<{
            whatsapp: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            telegram: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            discord: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            slack: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            mattermost: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            imessage: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            msteams: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            webchat: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
        }, zod.z.core.$strict>>;
        debounceMs: zod.ZodOptional<zod.ZodNumber>;
        debounceMsByChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
        cap: zod.ZodOptional<zod.ZodNumber>;
        drop: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"old">, zod.ZodLiteral<"new">, zod.ZodLiteral<"summarize">]>>;
    }, zod.z.core.$strict>>;
    inbound: zod.ZodOptional<zod.ZodObject<{
        debounceMs: zod.ZodOptional<zod.ZodNumber>;
        byChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
    }, zod.z.core.$strict>>;
    ackReaction: zod.ZodOptional<zod.ZodString>;
    ackReactionScope: zod.ZodOptional<zod.ZodEnum<{
        all: "all";
        direct: "direct";
        "group-mentions": "group-mentions";
        "group-all": "group-all";
    }>>;
    removeAckAfterReply: zod.ZodOptional<zod.ZodBoolean>;
    tts: zod.ZodOptional<zod.ZodObject<{
        auto: zod.ZodOptional<zod.ZodEnum<{
            always: "always";
            off: "off";
            inbound: "inbound";
            tagged: "tagged";
        }>>;
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        mode: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            final: "final";
        }>>;
        provider: zod.ZodOptional<zod.ZodEnum<{
            openai: "openai";
            elevenlabs: "elevenlabs";
            edge: "edge";
        }>>;
        summaryModel: zod.ZodOptional<zod.ZodString>;
        modelOverrides: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowText: zod.ZodOptional<zod.ZodBoolean>;
            allowProvider: zod.ZodOptional<zod.ZodBoolean>;
            allowVoice: zod.ZodOptional<zod.ZodBoolean>;
            allowModelId: zod.ZodOptional<zod.ZodBoolean>;
            allowVoiceSettings: zod.ZodOptional<zod.ZodBoolean>;
            allowNormalization: zod.ZodOptional<zod.ZodBoolean>;
            allowSeed: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        elevenlabs: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            voiceId: zod.ZodOptional<zod.ZodString>;
            modelId: zod.ZodOptional<zod.ZodString>;
            seed: zod.ZodOptional<zod.ZodNumber>;
            applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
                on: "on";
                off: "off";
                auto: "auto";
            }>>;
            languageCode: zod.ZodOptional<zod.ZodString>;
            voiceSettings: zod.ZodOptional<zod.ZodObject<{
                stability: zod.ZodOptional<zod.ZodNumber>;
                similarityBoost: zod.ZodOptional<zod.ZodNumber>;
                style: zod.ZodOptional<zod.ZodNumber>;
                useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
                speed: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        openai: zod.ZodOptional<zod.ZodObject<{
            apiKey: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            voice: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        edge: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            voice: zod.ZodOptional<zod.ZodString>;
            lang: zod.ZodOptional<zod.ZodString>;
            outputFormat: zod.ZodOptional<zod.ZodString>;
            pitch: zod.ZodOptional<zod.ZodString>;
            rate: zod.ZodOptional<zod.ZodString>;
            volume: zod.ZodOptional<zod.ZodString>;
            saveSubtitles: zod.ZodOptional<zod.ZodBoolean>;
            proxy: zod.ZodOptional<zod.ZodString>;
            timeoutMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        prefsPath: zod.ZodOptional<zod.ZodString>;
        maxTextLength: zod.ZodOptional<zod.ZodNumber>;
        timeoutMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
