/**
 * Normalizes model-definition config (context window, max output tokens, cost,
 * input modality) and resolves per-model token metadata for the runtime. Given
 * an ElizaConfig and a model id, resolveModelTokenMetadata returns the context
 * window and an optional explicitly configured max-output value. Omission never
 * invents an output ceiling; the selected provider/model owns that boundary.
 */
import type { ElizaConfig, ModelDefinitionConfig } from "@elizaos/host/protocol";
export declare const DEFAULT_MODEL_CONTEXT_WINDOW = 1000000;
export type ModelTokenMetadataSource = "model-config" | "agent-defaults" | "runtime-default";
export interface ModelTokenMetadata {
    modelId: string;
    providerId?: string;
    contextWindow: number;
    maxTokens?: number;
    source: ModelTokenMetadataSource;
}
export declare function normalizeModelDefinitionConfig(model: Partial<ModelDefinitionConfig> & {
    id: string;
}, defaults?: {
    contextWindow?: number;
    maxTokens?: number;
}): ModelDefinitionConfig;
export declare function normalizeModelMetadataInConfig(config: ElizaConfig): void;
export declare function resolveModelTokenMetadata(config?: ElizaConfig, modelId?: string): ModelTokenMetadata;
