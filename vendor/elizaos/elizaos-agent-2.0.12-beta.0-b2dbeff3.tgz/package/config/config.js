/**
 * Loads and persists the eliza.json runtime config. loadElizaConfig() merges
 * the base config file with the persisted overlay, resolves $include
 * directives, migrates legacy shapes, folds in skills.json extra dirs, and
 * hydrates env/connector vars into process.env (vault sentinels skipped;
 * secrets in config.env are applied to the process without being serialized
 * back to eliza.json). Values saved from the app win over stale .env/shell
 * values. saveElizaConfig() strips include directives and — when the OS
 * keystore is enabled — wallet private keys, then writes atomically via a temp
 * file + rename with 0600 permissions.
 */
import fs from "node:fs";
import path from "node:path";
import { ElizaError, getElizaNamespace, logger, resolveStateDir, resolveUserPath, } from "@elizaos/core";
import { isElizaSettingsDebugEnabled, migrateLegacyRuntimeConfig, migrateRetiredSubscriptionChatRoute, sanitizeForSettingsDebug, settingsDebugCloudSummary, } from "@elizaos/host/protocol";
import { readConfigEnvSync, resolveConfigEnvPath, } from "@elizaos/plugin-elizacloud/lib/config-env";
import JSON5 from "json5";
import { syncSolanaPublicKeyEnv } from "../api/wallet-keygen.js";
import { isVaultRef } from "../runtime/operations/vault-bridge.js";
import { writeFileAtomically } from "../utils/atomic-file.js";
import { isProcessOnlyEnvKey } from "./blocked-env-keys.js";
import { captureDevCloudEnvAuthority, createDevCloudConfigAuthorityView, isDevCloudConfigAuthorityView, isDevCloudEnvOwnedKey, isDevCloudInternalEnvKey, resolveDevCloudEnvAuthority, } from "./dev-cloud-env-authority.js";
import { collectConfigEnvVars, collectConnectorEnvVars, writeConfigEnvValue, } from "./env-vars.js";
import { resolveConfigIncludes } from "./includes.js";
import { normalizeModelMetadataInConfig } from "./model-metadata.js";
import { resolveConfigPath } from "./paths.js";
import { assertNoRetiredToolRestrictions } from "./retired-tool-policy.js";
function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
const RETIRED_PLUGIN_CONFIG_IDS = new Set([
    "simple-views",
    "@elizaos/plugin-simple-views",
]);
/**
 * Removes plugin references whose product surfaces now belong to canonical
 * core plugins. Notes and Calendar load through their own packages, so keeping
 * the former aggregate package in user config creates a false boot failure
 * without preserving any capability.
 */
function migrateRetiredPluginConfig(config) {
    const plugins = config.plugins;
    if (!plugins)
        return;
    if (plugins.entries) {
        for (const pluginId of RETIRED_PLUGIN_CONFIG_IDS) {
            delete plugins.entries[pluginId];
        }
    }
    if (plugins.allow) {
        plugins.allow = plugins.allow.filter((pluginId) => !RETIRED_PLUGIN_CONFIG_IDS.has(pluginId));
    }
}
function migrateConfig(config) {
    if (migrateRetiredSubscriptionChatRoute(config)) {
        logger.warn("[eliza] The ChatGPT/Codex subscription no longer powers chat; removed its chat route. It stays linked for coding agents. Choose a chat provider in Settings.");
    }
    migrateLegacyRuntimeConfig(config);
    migrateRetiredPluginConfig(config);
}
export function resolveConfigWritePath(env = process.env, canonicalConfigPath) {
    const persistPath = env.ELIZA_PERSIST_CONFIG_PATH?.trim();
    return persistPath
        ? resolveUserPath(persistPath)
        : (canonicalConfigPath ?? resolveConfigPath());
}
function resolveBindMountOverlayPath(env = process.env) {
    return path.join(resolveStateDir(env), `${getElizaNamespace(env)}.config-overlay.json`);
}
function resolveConfigLoadPaths() {
    const stateDir = resolveStateDir();
    const configPath = resolveConfigPath(process.env, stateDir);
    return {
        configPath,
        persistPath: resolveConfigWritePath(process.env, configPath),
        bindMountOverlayPath: resolveBindMountOverlayPath(),
        stateDir,
    };
}
function applyConfigEnvToProcessEnv(entries) {
    const devCloudAuthority = resolveDevCloudEnvAuthority();
    for (const [key, value] of Object.entries(entries)) {
        if (isDevCloudInternalEnvKey(key))
            continue;
        if (devCloudAuthority && isDevCloudEnvOwnedKey(key))
            continue;
        // TEE / protected-profile keys come from the process environment only; a
        // persisted config.env line must not relax them.
        if (isProcessOnlyEnvKey(key))
            continue;
        // Skip unresolved vault sentinels. The boot-time vault hydration
        // (resolveConfigEnvForProcess + applyCloudConfigToEnv) writes the resolved
        // plaintext to process.env once at startup. Many services call
        // loadElizaConfig() again later for unrelated reads; without this guard the
        // sentinel literal `vault://KEY` would overwrite the real plaintext on
        // every such call, and downstream `runtime.getSetting()` would hand the
        // sentinel to consumers like plugin-elizacloud, producing 401s.
        if (isVaultRef(value))
            continue;
        writeConfigEnvValue(key, value);
    }
}
function getConfigEnvString(config, key) {
    const envConfig = config.env;
    const nestedVars = envConfig?.vars &&
        typeof envConfig.vars === "object" &&
        !Array.isArray(envConfig.vars)
        ? envConfig.vars
        : undefined;
    const value = nestedVars?.[key] ?? envConfig?.[key];
    return typeof value === "string" && value.trim() ? value.trim() : undefined;
}
function mergeConfigRecords(base, overlay) {
    if (overlay === undefined) {
        return base;
    }
    if (Array.isArray(overlay)) {
        return overlay.slice();
    }
    if (isPlainObject(base) && isPlainObject(overlay)) {
        const merged = { ...base };
        for (const [key, value] of Object.entries(overlay)) {
            merged[key] = mergeConfigRecords(base[key], value);
        }
        return merged;
    }
    return overlay;
}
function readConfigFile(configPath, onReadFile) {
    let raw;
    onReadFile?.(configPath);
    try {
        raw = fs.readFileSync(configPath, "utf-8");
    }
    catch (err) {
        if (err.code === "ENOENT") {
            return null;
        }
        throw err;
    }
    const parsed = JSON5.parse(raw);
    return resolveConfigIncludes(parsed, configPath, undefined, onReadFile);
}
export function loadElizaConfig(onReadFile) {
    const { configPath, persistPath, bindMountOverlayPath, stateDir } = resolveConfigLoadPaths();
    const baseConfig = readConfigFile(configPath, onReadFile);
    const persistedConfig = persistPath !== configPath ? readConfigFile(persistPath, onReadFile) : null;
    const bindMountOverlay = persistPath === configPath && bindMountOverlayPath !== configPath
        ? readConfigFile(bindMountOverlayPath, onReadFile)
        : null;
    // The automatic bind-mount overlay extends only the canonical file. An
    // explicitly configured persistence path disables it entirely, preventing
    // stale overlay keys from leaking into an operator-selected store.
    // Automatic overlays contain a complete sanitized snapshot. Treating that
    // snapshot as authoritative preserves deletions from the read-only base;
    // merging it as a patch would resurrect removed settings after restart.
    const resolved = (bindMountOverlay ??
        (baseConfig || persistedConfig
            ? mergeConfigRecords(baseConfig ?? {}, persistedConfig ?? {})
            : { logging: { level: "error" } }));
    migrateConfig(resolved);
    normalizeModelMetadataInConfig(resolved);
    assertNoRetiredToolRestrictions(resolved);
    const skillsJsonPath = path.join(stateDir, "skills.json");
    if (!fs.existsSync(skillsJsonPath)) {
        try {
            const skillsDir = path.dirname(skillsJsonPath);
            if (!fs.existsSync(skillsDir)) {
                fs.mkdirSync(skillsDir, { recursive: true });
            }
            fs.writeFileSync(skillsJsonPath, JSON.stringify({ extraDirs: [] }, null, 2), "utf-8");
        }
        catch (err) {
            logger.warn(`[eliza] Failed to auto-create ${skillsJsonPath}: ${String(err)}`);
        }
    }
    onReadFile?.(skillsJsonPath);
    if (fs.existsSync(skillsJsonPath)) {
        try {
            const skillsRaw = fs.readFileSync(skillsJsonPath, "utf-8");
            const skillsConfig = JSON5.parse(skillsRaw);
            if (skillsConfig.extraDirs &&
                Array.isArray(skillsConfig.extraDirs) &&
                skillsConfig.extraDirs.length > 0) {
                if (!resolved.skills)
                    resolved.skills = {};
                if (!resolved.skills.load)
                    resolved.skills.load = {};
                if (!resolved.skills.load.extraDirs) {
                    resolved.skills.load.extraDirs = [];
                }
                const existing = new Set(resolved.skills.load.extraDirs);
                for (const dir of skillsConfig.extraDirs) {
                    const loadedDir = resolveUserPath(dir);
                    if (!existing.has(loadedDir)) {
                        resolved.skills.load.extraDirs.push(loadedDir);
                        existing.add(loadedDir);
                    }
                }
            }
        }
        catch (err) {
            logger.warn(`[eliza] Failed to load ${skillsJsonPath}: ${String(err)}`);
        }
    }
    if (!resolved.logging) {
        resolved.logging = { level: "error" };
    }
    else if (!resolved.logging.level) {
        resolved.logging.level = "error";
    }
    onReadFile?.(resolveConfigEnvPath(stateDir));
    const persistedConfigEnv = readConfigEnvSync(stateDir);
    // SECURITY: Do NOT merge persistedConfigEnv into resolved.env — config.env
    // is the designated escape hatch for secrets that must NOT be serialized to
    // eliza.json (e.g. ELIZA_CLOUD_CLIENT_ADDRESS_KEY, WALLET_SOURCE_*).
    // Merging would create a sensitive-data boundary violation.
    // Instead, apply directly to process.env (below).
    const envVars = collectConfigEnvVars(resolved);
    const connectorEnvVars = collectConnectorEnvVars(resolved);
    // Saved config is the source of truth for settings edited in the app.
    // If a key is persisted here, it should override any stale value that
    // arrived from .env or the parent shell.
    applyConfigEnvToProcessEnv(envVars);
    applyConfigEnvToProcessEnv(connectorEnvVars);
    applyConfigEnvToProcessEnv(persistedConfigEnv);
    const discordToken = process.env.DISCORD_API_TOKEN?.trim() ||
        process.env.DISCORD_BOT_TOKEN?.trim();
    if (discordToken) {
        process.env.DISCORD_API_TOKEN = discordToken;
        process.env.DISCORD_BOT_TOKEN = discordToken;
    }
    // Keep public-key aliases available when only the private key is configured.
    syncSolanaPublicKeyEnv(getConfigEnvString(resolved, "SOLANA_PRIVATE_KEY"));
    if (isElizaSettingsDebugEnabled()) {
        const cloud = resolved.cloud;
        logger.debug({
            path: configPath,
            persistPath: persistPath !== configPath ? persistPath : undefined,
            bindMountOverlayPath: bindMountOverlay
                ? bindMountOverlayPath
                : undefined,
            topLevelKeys: Object.keys(resolved).sort(),
            cloud: settingsDebugCloudSummary(cloud),
            envVarKeysHydrated: Object.keys({
                ...persistedConfigEnv,
                ...envVars,
                ...connectorEnvVars,
            }).sort(),
            snapshot: sanitizeForSettingsDebug(resolved),
        }, "[eliza][settings][loadElizaConfig]");
    }
    return resolved;
}
/**
 * Load the operational/runtime view of config. The durable loader remains the
 * source for settings mutations; network and execution paths use this helper
 * so a launcher-selected dev Cloud target cannot be displaced by persisted
 * production topology or credentials.
 */
export function loadEffectiveElizaConfig() {
    return createDevCloudConfigAuthorityView(loadElizaConfig());
}
/** Metadata only: never retain file contents or credentials in a revision. */
function configFileRevision(filePath) {
    try {
        const stat = fs.statSync(filePath, { bigint: true });
        return [
            stat.dev,
            stat.ino,
            stat.mode,
            stat.size,
            stat.mtimeNs,
            stat.ctimeNs,
        ].join(":");
    }
    catch (error) {
        // error-policy:J4 only genuine absence is an empty dependency revision.
        if (error.code === "ENOENT")
            return null;
        throw error;
    }
}
function effectiveConfigIdentity() {
    return JSON.stringify(resolveConfigLoadPaths());
}
/**
 * Load once through the canonical loader and record its actual dependency
 * graph, including absent top-level sources. Unchanged checks only stat those
 * paths; they never parse config or walk a second implementation of $include.
 * The process-lifetime development authority is part of snapshot identity.
 */
export function loadEffectiveElizaConfigSnapshot() {
    const identity = effectiveConfigIdentity();
    const authority = captureDevCloudEnvAuthority();
    const revisions = new Map();
    const config = createDevCloudConfigAuthorityView(loadElizaConfig((filePath) => {
        if (!revisions.has(filePath)) {
            revisions.set(filePath, configFileRevision(filePath));
        }
    }));
    const snapshot = {
        config,
        isCurrent({ checkFiles = true } = {}) {
            if (effectiveConfigIdentity() !== identity ||
                captureDevCloudEnvAuthority() !== authority) {
                return false;
            }
            return (!checkFiles ||
                [...revisions].every(([filePath, revision]) => configFileRevision(filePath) === revision));
        },
    };
    if (!snapshot.isCurrent()) {
        throw new ElizaError("Config changed while its snapshot was loading", {
            code: "CONFIG_SNAPSHOT_CHANGED_DURING_READ",
        });
    }
    return snapshot;
}
let renameConfigFile = fs.renameSync.bind(fs);
/** Replaces the atomic rename operation for deterministic filesystem tests. */
export function __setConfigRenameSyncForTests(renameSync) {
    renameConfigFile = renameSync ?? fs.renameSync.bind(fs);
}
function stripIncludeDirectives(value) {
    if (value === null || value === undefined)
        return value;
    if (Array.isArray(value))
        return value.map(stripIncludeDirectives);
    if (typeof value !== "object")
        return value;
    const result = {};
    for (const [key, val] of Object.entries(value)) {
        if (key === "$include")
            continue;
        result[key] = stripIncludeDirectives(val);
    }
    return result;
}
export function isWalletOsStoreEnabledInConfig(config) {
    const envConfig = config.env;
    if (!envConfig || typeof envConfig !== "object" || Array.isArray(envConfig)) {
        return false;
    }
    const raw = envConfig.ELIZA_WALLET_OS_STORE;
    if (typeof raw !== "string") {
        return false;
    }
    const normalized = raw.trim().toLowerCase();
    return (normalized === "1" ||
        normalized === "true" ||
        normalized === "on" ||
        normalized === "yes");
}
function stripWalletPrivateKeysFromConfig(config) {
    const envConfig = config.env;
    if (!envConfig || typeof envConfig !== "object" || Array.isArray(envConfig)) {
        return;
    }
    delete envConfig.EVM_PRIVATE_KEY;
    delete envConfig.SOLANA_PRIVATE_KEY;
    const nestedVars = envConfig.vars &&
        typeof envConfig.vars === "object" &&
        !Array.isArray(envConfig.vars)
        ? envConfig.vars
        : undefined;
    if (nestedVars) {
        delete nestedVars.EVM_PRIVATE_KEY;
        delete nestedVars.SOLANA_PRIVATE_KEY;
    }
}
export function saveElizaConfig(config) {
    assertNoRetiredToolRestrictions(config);
    if (isDevCloudConfigAuthorityView(config)) {
        throw new Error("[eliza-config] Refusing to persist an ephemeral dev Cloud authority view");
    }
    const configPath = resolveConfigWritePath();
    const canonicalConfigPath = resolveConfigPath();
    const dir = path.dirname(configPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    }
    migrateConfig(config);
    if (isWalletOsStoreEnabledInConfig(config)) {
        stripWalletPrivateKeysFromConfig(config);
    }
    const sanitized = stripIncludeDirectives(config);
    if (!sanitized || typeof sanitized !== "object") {
        throw new Error(`[eliza-config] stripIncludeDirectives returned invalid result: ${typeof sanitized}`);
    }
    migrateConfig(sanitized);
    if (isWalletOsStoreEnabledInConfig(sanitized)) {
        stripWalletPrivateKeysFromConfig(sanitized);
    }
    // Host-managed credentials may be hydrated in memory, but stay outside disk config.
    const externalNames = process.env.ELIZA_CONFIG_EXTERNAL_SECRET_ENV_VARS;
    const names = externalNames === undefined || externalNames === ""
        ? []
        : externalNames.split(",");
    if (names.length > 32 ||
        names.some((name) => !/^[A-Z][A-Z0-9_]{0,127}$/.test(name))) {
        throw new ElizaError("Invalid external config secret policy", {
            code: "CONFIG_EXTERNAL_SECRET_POLICY_INVALID",
        });
    }
    const externalSecrets = new Set(names
        .map((name) => process.env[name])
        .filter((value) => typeof value === "string" && value.length > 0));
    const content = `${JSON.stringify(sanitized, (_key, value) => typeof value === "string" && externalSecrets.has(value)
        ? undefined
        : value, 2)}\n`;
    // Atomic write: write to a temp file then rename. If the process crashes
    // during writeFileSync, only the temp file is corrupted — the original
    // config remains intact. rename() is atomic on POSIX filesystems when
    // source and destination are on the same filesystem.
    //
    // Resolve symlinks so dotfile-managed setups (symlinked config) update
    // the target file instead of replacing the symlink with a regular file.
    const realConfigPath = fs.existsSync(configPath)
        ? fs.realpathSync(configPath)
        : configPath;
    const bindMountOverlayPath = resolveBindMountOverlayPath();
    const mayUseBindMountOverlay = configPath === canonicalConfigPath;
    let writtenPath = realConfigPath;
    // A file bind mount cannot be replaced with rename(2): Linux returns EBUSY.
    // Once observed, persist the complete sanitized config in the writable state
    // directory. The overlay is temp+fsync+rename committed and loaded last on
    // every subsequent boot. Keep using an existing overlay so stale state can
    // never override a later write to the read-only base file.
    if (mayUseBindMountOverlay && fs.existsSync(bindMountOverlayPath)) {
        writeFileAtomically(bindMountOverlayPath, content, renameConfigFile);
        writtenPath = bindMountOverlayPath;
    }
    else {
        try {
            writeFileAtomically(realConfigPath, content, renameConfigFile);
        }
        catch (error) {
            const code = error.code;
            if (code !== "EBUSY" || !mayUseBindMountOverlay)
                throw error;
            try {
                writeFileAtomically(bindMountOverlayPath, content, renameConfigFile);
                writtenPath = bindMountOverlayPath;
                logger.warn(`[eliza-config] ${realConfigPath} is not replaceable (EBUSY); persisted config atomically to ${bindMountOverlayPath}`);
            }
            catch (fallbackError) {
                throw new Error(`[eliza-config] Bind-mounted config could not be replaced and state overlay persistence failed: ${String(fallbackError)}`, { cause: error });
            }
        }
    }
    // Enforce 600 on every write — writeFileSync's mode only applies on
    // creation, so files created by older versions retain their original
    // (potentially world-readable) permissions.
    try {
        fs.chmodSync(writtenPath, 0o600);
    }
    catch (error) {
        // Windows does not implement POSIX permission bits. On POSIX, failure to
        // enforce the config's secret-bearing 0600 contract is a real write error.
        if (process.platform !== "win32")
            throw error;
    }
    if (!fs.existsSync(writtenPath)) {
        throw new Error(`[eliza-config] Config file missing after write: ${writtenPath}`);
    }
    const stat = fs.statSync(writtenPath);
    if (stat.size === 0) {
        throw new Error(`[eliza-config] Config file is empty after write: ${writtenPath}`);
    }
    if (isElizaSettingsDebugEnabled()) {
        const c = sanitized;
        const cloud = c.cloud;
        logger.debug({
            path: writtenPath,
            bytes: stat.size,
            topLevelKeys: Object.keys(c).sort(),
            cloud: settingsDebugCloudSummary(cloud),
            snapshot: sanitizeForSettingsDebug(sanitized),
        }, "[eliza][settings][saveElizaConfig]");
    }
}
export function configFileExists() {
    const configPath = resolveConfigPath();
    if (fs.existsSync(configPath)) {
        return true;
    }
    const persistPath = resolveConfigWritePath();
    if (persistPath !== configPath && fs.existsSync(persistPath)) {
        return true;
    }
    return (persistPath === configPath && fs.existsSync(resolveBindMountOverlayPath()));
}
