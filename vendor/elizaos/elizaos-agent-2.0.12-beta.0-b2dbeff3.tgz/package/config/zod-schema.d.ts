/**
 * Assembles the top-level `ElizaSchema` zod validator for the on-disk Eliza
 * config, alongside the standalone `CharacterSchema`. Composes the split
 * sub-schema modules (agent-runtime, core, hooks, provider-core, session) into
 * one strict object spanning connectors, streaming, memory, gateway, auth,
 * diagnostics, logging, browser, skills, plugins, and the rest of the config
 * tree, and cross-validates that every `broadcast` target names an agent id
 * declared in `agents.list`.
 */
import * as zod from "zod";
export declare const CharacterSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    username: zod.ZodOptional<zod.ZodString>;
    bio: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodArray<zod.ZodString>]>>;
    system: zod.ZodOptional<zod.ZodString>;
    adjectives: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    topics: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    style: zod.ZodOptional<zod.ZodObject<{
        all: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        chat: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        post: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    messageExamples: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        examples: zod.ZodArray<zod.ZodObject<{
            name: zod.ZodString;
            content: zod.ZodObject<{
                text: zod.ZodString;
                actions: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>;
    postExamples: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
}, zod.z.core.$strict>;
export declare const ElizaSchema: zod.ZodObject<{
    meta: zod.ZodOptional<zod.ZodObject<{
        firstRunComplete: zod.ZodOptional<zod.ZodBoolean>;
        lastTouchedVersion: zod.ZodOptional<zod.ZodString>;
        lastTouchedAt: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    env: zod.ZodOptional<zod.ZodObject<{
        shellEnv: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            timeoutMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        vars: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    }, zod.z.core.$catchall<zod.ZodString>>>;
    deploymentTarget: zod.ZodOptional<zod.ZodObject<{
        runtime: zod.ZodUnion<readonly [zod.ZodLiteral<"local">, zod.ZodLiteral<"cloud">, zod.ZodLiteral<"remote">]>;
        provider: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"elizacloud">, zod.ZodLiteral<"remote">]>>;
        remoteApiBase: zod.ZodOptional<zod.ZodString>;
        remoteAccessToken: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    linkedAccounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        status: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"linked">, zod.ZodLiteral<"unlinked">]>>;
        source: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"api-key">, zod.ZodLiteral<"oauth">, zod.ZodLiteral<"credentials">, zod.ZodLiteral<"subscription">]>>;
        userId: zod.ZodOptional<zod.ZodString>;
        organizationId: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>;
    serviceRouting: zod.ZodOptional<zod.ZodObject<{
        llmText: zod.ZodOptional<zod.ZodObject<{
            backend: zod.ZodOptional<zod.ZodString>;
            transport: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"cloud-proxy">, zod.ZodLiteral<"remote">]>>;
            accountId: zod.ZodOptional<zod.ZodString>;
            primaryModel: zod.ZodOptional<zod.ZodString>;
            nanoModel: zod.ZodOptional<zod.ZodString>;
            smallModel: zod.ZodOptional<zod.ZodString>;
            mediumModel: zod.ZodOptional<zod.ZodString>;
            largeModel: zod.ZodOptional<zod.ZodString>;
            megaModel: zod.ZodOptional<zod.ZodString>;
            responseHandlerModel: zod.ZodOptional<zod.ZodString>;
            shouldRespondModel: zod.ZodOptional<zod.ZodString>;
            actionPlannerModel: zod.ZodOptional<zod.ZodString>;
            plannerModel: zod.ZodOptional<zod.ZodString>;
            responseModel: zod.ZodOptional<zod.ZodString>;
            mediaDescriptionModel: zod.ZodOptional<zod.ZodString>;
            remoteApiBase: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        tts: zod.ZodOptional<zod.ZodObject<{
            backend: zod.ZodOptional<zod.ZodString>;
            transport: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"cloud-proxy">, zod.ZodLiteral<"remote">]>>;
            accountId: zod.ZodOptional<zod.ZodString>;
            primaryModel: zod.ZodOptional<zod.ZodString>;
            nanoModel: zod.ZodOptional<zod.ZodString>;
            smallModel: zod.ZodOptional<zod.ZodString>;
            mediumModel: zod.ZodOptional<zod.ZodString>;
            largeModel: zod.ZodOptional<zod.ZodString>;
            megaModel: zod.ZodOptional<zod.ZodString>;
            responseHandlerModel: zod.ZodOptional<zod.ZodString>;
            shouldRespondModel: zod.ZodOptional<zod.ZodString>;
            actionPlannerModel: zod.ZodOptional<zod.ZodString>;
            plannerModel: zod.ZodOptional<zod.ZodString>;
            responseModel: zod.ZodOptional<zod.ZodString>;
            mediaDescriptionModel: zod.ZodOptional<zod.ZodString>;
            remoteApiBase: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        media: zod.ZodOptional<zod.ZodObject<{
            backend: zod.ZodOptional<zod.ZodString>;
            transport: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"cloud-proxy">, zod.ZodLiteral<"remote">]>>;
            accountId: zod.ZodOptional<zod.ZodString>;
            primaryModel: zod.ZodOptional<zod.ZodString>;
            nanoModel: zod.ZodOptional<zod.ZodString>;
            smallModel: zod.ZodOptional<zod.ZodString>;
            mediumModel: zod.ZodOptional<zod.ZodString>;
            largeModel: zod.ZodOptional<zod.ZodString>;
            megaModel: zod.ZodOptional<zod.ZodString>;
            responseHandlerModel: zod.ZodOptional<zod.ZodString>;
            shouldRespondModel: zod.ZodOptional<zod.ZodString>;
            actionPlannerModel: zod.ZodOptional<zod.ZodString>;
            plannerModel: zod.ZodOptional<zod.ZodString>;
            responseModel: zod.ZodOptional<zod.ZodString>;
            mediaDescriptionModel: zod.ZodOptional<zod.ZodString>;
            remoteApiBase: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        embeddings: zod.ZodOptional<zod.ZodObject<{
            backend: zod.ZodOptional<zod.ZodString>;
            transport: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"cloud-proxy">, zod.ZodLiteral<"remote">]>>;
            accountId: zod.ZodOptional<zod.ZodString>;
            primaryModel: zod.ZodOptional<zod.ZodString>;
            nanoModel: zod.ZodOptional<zod.ZodString>;
            smallModel: zod.ZodOptional<zod.ZodString>;
            mediumModel: zod.ZodOptional<zod.ZodString>;
            largeModel: zod.ZodOptional<zod.ZodString>;
            megaModel: zod.ZodOptional<zod.ZodString>;
            responseHandlerModel: zod.ZodOptional<zod.ZodString>;
            shouldRespondModel: zod.ZodOptional<zod.ZodString>;
            actionPlannerModel: zod.ZodOptional<zod.ZodString>;
            plannerModel: zod.ZodOptional<zod.ZodString>;
            responseModel: zod.ZodOptional<zod.ZodString>;
            mediaDescriptionModel: zod.ZodOptional<zod.ZodString>;
            remoteApiBase: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        rpc: zod.ZodOptional<zod.ZodObject<{
            backend: zod.ZodOptional<zod.ZodString>;
            transport: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"cloud-proxy">, zod.ZodLiteral<"remote">]>>;
            accountId: zod.ZodOptional<zod.ZodString>;
            primaryModel: zod.ZodOptional<zod.ZodString>;
            nanoModel: zod.ZodOptional<zod.ZodString>;
            smallModel: zod.ZodOptional<zod.ZodString>;
            mediumModel: zod.ZodOptional<zod.ZodString>;
            largeModel: zod.ZodOptional<zod.ZodString>;
            megaModel: zod.ZodOptional<zod.ZodString>;
            responseHandlerModel: zod.ZodOptional<zod.ZodString>;
            shouldRespondModel: zod.ZodOptional<zod.ZodString>;
            actionPlannerModel: zod.ZodOptional<zod.ZodString>;
            plannerModel: zod.ZodOptional<zod.ZodString>;
            responseModel: zod.ZodOptional<zod.ZodString>;
            mediaDescriptionModel: zod.ZodOptional<zod.ZodString>;
            remoteApiBase: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    wizard: zod.ZodOptional<zod.ZodObject<{
        lastRunAt: zod.ZodOptional<zod.ZodString>;
        lastRunVersion: zod.ZodOptional<zod.ZodString>;
        lastRunCommit: zod.ZodOptional<zod.ZodString>;
        lastRunCommand: zod.ZodOptional<zod.ZodString>;
        lastRunMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"local">, zod.ZodLiteral<"remote">]>>;
    }, zod.z.core.$strict>>;
    diagnostics: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        flags: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        otel: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            endpoint: zod.ZodOptional<zod.ZodString>;
            protocol: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"http/protobuf">, zod.ZodLiteral<"grpc">]>>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            serviceName: zod.ZodOptional<zod.ZodString>;
            traces: zod.ZodOptional<zod.ZodBoolean>;
            metrics: zod.ZodOptional<zod.ZodBoolean>;
            logs: zod.ZodOptional<zod.ZodBoolean>;
            sampleRate: zod.ZodOptional<zod.ZodNumber>;
            flushIntervalMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        cacheTrace: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            filePath: zod.ZodOptional<zod.ZodString>;
            includeMessages: zod.ZodOptional<zod.ZodBoolean>;
            includePrompt: zod.ZodOptional<zod.ZodBoolean>;
            includeSystem: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    logging: zod.ZodOptional<zod.ZodObject<{
        level: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"silent">, zod.ZodLiteral<"fatal">, zod.ZodLiteral<"error">, zod.ZodLiteral<"warn">, zod.ZodLiteral<"info">, zod.ZodLiteral<"debug">, zod.ZodLiteral<"trace">]>>;
        file: zod.ZodOptional<zod.ZodString>;
        consoleLevel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"silent">, zod.ZodLiteral<"fatal">, zod.ZodLiteral<"error">, zod.ZodLiteral<"warn">, zod.ZodLiteral<"info">, zod.ZodLiteral<"debug">, zod.ZodLiteral<"trace">]>>;
        consoleStyle: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"pretty">, zod.ZodLiteral<"compact">, zod.ZodLiteral<"json">]>>;
        redactSensitive: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"tools">]>>;
        redactPatterns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    update: zod.ZodOptional<zod.ZodObject<{
        channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"stable">, zod.ZodLiteral<"beta">, zod.ZodLiteral<"dev">]>>;
        checkOnStart: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    browser: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        evaluateEnabled: zod.ZodOptional<zod.ZodBoolean>;
        cdpUrl: zod.ZodOptional<zod.ZodString>;
        remoteCdpTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
        remoteCdpHandshakeTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
        color: zod.ZodOptional<zod.ZodString>;
        executablePath: zod.ZodOptional<zod.ZodString>;
        headless: zod.ZodOptional<zod.ZodBoolean>;
        noSandbox: zod.ZodOptional<zod.ZodBoolean>;
        attachOnly: zod.ZodOptional<zod.ZodBoolean>;
        defaultProfile: zod.ZodOptional<zod.ZodString>;
        snapshotDefaults: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodLiteral<"efficient">>;
        }, zod.z.core.$strict>>;
        profiles: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            cdpPort: zod.ZodOptional<zod.ZodNumber>;
            cdpUrl: zod.ZodOptional<zod.ZodString>;
            driver: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"cdp">, zod.ZodLiteral<"extension">]>>;
            color: zod.ZodString;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    ui: zod.ZodOptional<zod.ZodObject<{
        seamColor: zod.ZodOptional<zod.ZodString>;
        assistant: zod.ZodOptional<zod.ZodObject<{
            name: zod.ZodOptional<zod.ZodString>;
            avatar: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    auth: zod.ZodOptional<zod.ZodObject<{
        profiles: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            provider: zod.ZodString;
            mode: zod.ZodUnion<readonly [zod.ZodLiteral<"api_key">, zod.ZodLiteral<"oauth">, zod.ZodLiteral<"token">]>;
            email: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>;
        order: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodString>>>;
        cooldowns: zod.ZodOptional<zod.ZodObject<{
            billingBackoffHours: zod.ZodOptional<zod.ZodNumber>;
            billingBackoffHoursByProvider: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
            billingMaxHours: zod.ZodOptional<zod.ZodNumber>;
            failureWindowHours: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    models: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"merge">, zod.ZodLiteral<"replace">]>>;
        providers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            baseUrl: zod.ZodString;
            apiKey: zod.ZodOptional<zod.ZodString>;
            auth: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"api-key">, zod.ZodLiteral<"aws-sdk">, zod.ZodLiteral<"oauth">, zod.ZodLiteral<"token">]>>;
            api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            authHeader: zod.ZodOptional<zod.ZodBoolean>;
            models: zod.ZodArray<zod.ZodPipe<zod.ZodObject<{
                id: zod.ZodString;
                name: zod.ZodString;
                api: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai-completions">, zod.ZodLiteral<"openai-responses">, zod.ZodLiteral<"anthropic-messages">, zod.ZodLiteral<"google-generative-ai">, zod.ZodLiteral<"bedrock-converse-stream">]>>;
                reasoning: zod.ZodOptional<zod.ZodBoolean>;
                input: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"text">, zod.ZodLiteral<"image">]>>>;
                cost: zod.ZodOptional<zod.ZodObject<{
                    input: zod.ZodOptional<zod.ZodNumber>;
                    output: zod.ZodOptional<zod.ZodNumber>;
                    cacheRead: zod.ZodOptional<zod.ZodNumber>;
                    cacheWrite: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                contextWindow: zod.ZodOptional<zod.ZodNumber>;
                maxTokens: zod.ZodOptional<zod.ZodNumber>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                compat: zod.ZodOptional<zod.ZodObject<{
                    supportsStore: zod.ZodOptional<zod.ZodBoolean>;
                    supportsDeveloperRole: zod.ZodOptional<zod.ZodBoolean>;
                    supportsReasoningEffort: zod.ZodOptional<zod.ZodBoolean>;
                    maxTokensField: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"max_completion_tokens">, zod.ZodLiteral<"max_tokens">]>>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>, zod.ZodTransform<{
                reasoning: boolean;
                input: ("image" | "text")[];
                cost: {
                    input: number;
                    output: number;
                    cacheRead: number;
                    cacheWrite: number;
                };
                contextWindow: number;
                id: string;
                name: string;
                api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
                maxTokens?: number | undefined;
                headers?: Record<string, string> | undefined;
                compat?: {
                    supportsStore?: boolean | undefined;
                    supportsDeveloperRole?: boolean | undefined;
                    supportsReasoningEffort?: boolean | undefined;
                    maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
                } | undefined;
            }, {
                id: string;
                name: string;
                api?: "openai-completions" | "openai-responses" | "anthropic-messages" | "google-generative-ai" | "bedrock-converse-stream" | undefined;
                reasoning?: boolean | undefined;
                input?: ("image" | "text")[] | undefined;
                cost?: {
                    input?: number | undefined;
                    output?: number | undefined;
                    cacheRead?: number | undefined;
                    cacheWrite?: number | undefined;
                } | undefined;
                contextWindow?: number | undefined;
                maxTokens?: number | undefined;
                headers?: Record<string, string> | undefined;
                compat?: {
                    supportsStore?: boolean | undefined;
                    supportsDeveloperRole?: boolean | undefined;
                    supportsReasoningEffort?: boolean | undefined;
                    maxTokensField?: "max_completion_tokens" | "max_tokens" | undefined;
                } | undefined;
            }>>>;
        }, zod.z.core.$strict>>>;
        bedrockDiscovery: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            region: zod.ZodOptional<zod.ZodString>;
            providerFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            refreshInterval: zod.ZodOptional<zod.ZodNumber>;
            defaultContextWindow: zod.ZodOptional<zod.ZodNumber>;
            defaultMaxTokens: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    nodeHost: zod.ZodOptional<zod.ZodObject<{
        browserProxy: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowProfiles: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    agents: zod.ZodOptional<zod.ZodObject<{
        defaults: zod.ZodOptional<zod.ZodLazy<zod.ZodOptional<zod.ZodObject<{
            model: zod.ZodOptional<zod.ZodObject<{
                primary: zod.ZodOptional<zod.ZodString>;
                fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            imageModel: zod.ZodOptional<zod.ZodObject<{
                primary: zod.ZodOptional<zod.ZodString>;
                fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            models: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                alias: zod.ZodOptional<zod.ZodString>;
                params: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
            }, zod.z.core.$strict>>>;
            workspace: zod.ZodOptional<zod.ZodString>;
            adminEntityId: zod.ZodOptional<zod.ZodString>;
            ownerContacts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                source: zod.ZodOptional<zod.ZodString>;
                entityId: zod.ZodOptional<zod.ZodString>;
                channelId: zod.ZodOptional<zod.ZodString>;
                roomId: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>;
            escalation: zod.ZodOptional<zod.ZodObject<{
                channels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                waitMinutes: zod.ZodOptional<zod.ZodNumber>;
                maxRetries: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            repoRoot: zod.ZodOptional<zod.ZodString>;
            skipInit: zod.ZodOptional<zod.ZodBoolean>;
            enableInitProviders: zod.ZodOptional<zod.ZodBoolean>;
            userTimezone: zod.ZodOptional<zod.ZodString>;
            timeFormat: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"auto">, zod.ZodLiteral<"12">, zod.ZodLiteral<"24">]>>;
            envelopeTimezone: zod.ZodOptional<zod.ZodString>;
            envelopeTimestamp: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"on">, zod.ZodLiteral<"off">]>>;
            envelopeElapsed: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"on">, zod.ZodLiteral<"off">]>>;
            contextTokens: zod.ZodOptional<zod.ZodNumber>;
            cliBackends: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                command: zod.ZodString;
                args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                output: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"json">, zod.ZodLiteral<"text">, zod.ZodLiteral<"jsonl">]>>;
                resumeOutput: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"json">, zod.ZodLiteral<"text">, zod.ZodLiteral<"jsonl">]>>;
                input: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"arg">, zod.ZodLiteral<"stdin">]>>;
                maxPromptArgChars: zod.ZodOptional<zod.ZodNumber>;
                env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                clearEnv: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                modelArg: zod.ZodOptional<zod.ZodString>;
                modelAliases: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                sessionArg: zod.ZodOptional<zod.ZodString>;
                sessionArgs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                resumeArgs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                sessionMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"always">, zod.ZodLiteral<"existing">, zod.ZodLiteral<"none">]>>;
                sessionIdFields: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                systemPromptArg: zod.ZodOptional<zod.ZodString>;
                systemPromptMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"append">, zod.ZodLiteral<"replace">]>>;
                systemPromptWhen: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"always">, zod.ZodLiteral<"never">]>>;
                imageArg: zod.ZodOptional<zod.ZodString>;
                imageMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"repeat">, zod.ZodLiteral<"list">]>>;
                serialize: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>>;
            memorySearch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                sources: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"memory">, zod.ZodLiteral<"sessions">]>>>;
                extraPaths: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                experimental: zod.ZodOptional<zod.ZodObject<{
                    sessionMemory: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                provider: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"local">, zod.ZodLiteral<"gemini">]>>;
                remote: zod.ZodOptional<zod.ZodObject<{
                    baseUrl: zod.ZodOptional<zod.ZodString>;
                    apiKey: zod.ZodOptional<zod.ZodString>;
                    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    batch: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        wait: zod.ZodOptional<zod.ZodBoolean>;
                        concurrency: zod.ZodOptional<zod.ZodNumber>;
                        pollIntervalMs: zod.ZodOptional<zod.ZodNumber>;
                        timeoutMinutes: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                fallback: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"gemini">, zod.ZodLiteral<"local">, zod.ZodLiteral<"none">]>>;
                model: zod.ZodOptional<zod.ZodString>;
                local: zod.ZodOptional<zod.ZodObject<{
                    modelPath: zod.ZodOptional<zod.ZodString>;
                    modelCacheDir: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
                store: zod.ZodOptional<zod.ZodObject<{
                    driver: zod.ZodOptional<zod.ZodLiteral<"sqlite">>;
                    path: zod.ZodOptional<zod.ZodString>;
                    vector: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        extensionPath: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                chunking: zod.ZodOptional<zod.ZodObject<{
                    tokens: zod.ZodOptional<zod.ZodNumber>;
                    overlap: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                sync: zod.ZodOptional<zod.ZodObject<{
                    onSessionStart: zod.ZodOptional<zod.ZodBoolean>;
                    onSearch: zod.ZodOptional<zod.ZodBoolean>;
                    watch: zod.ZodOptional<zod.ZodBoolean>;
                    watchDebounceMs: zod.ZodOptional<zod.ZodNumber>;
                    intervalMinutes: zod.ZodOptional<zod.ZodNumber>;
                    sessions: zod.ZodOptional<zod.ZodObject<{
                        deltaBytes: zod.ZodOptional<zod.ZodNumber>;
                        deltaMessages: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                query: zod.ZodOptional<zod.ZodObject<{
                    maxResults: zod.ZodOptional<zod.ZodNumber>;
                    minScore: zod.ZodOptional<zod.ZodNumber>;
                    hybrid: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        vectorWeight: zod.ZodOptional<zod.ZodNumber>;
                        textWeight: zod.ZodOptional<zod.ZodNumber>;
                        candidateMultiplier: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                cache: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    maxEntries: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
            advancedMemory: zod.ZodOptional<zod.ZodBoolean>;
            agentOrchestrator: zod.ZodOptional<zod.ZodBoolean>;
            gitpathologist: zod.ZodOptional<zod.ZodBoolean>;
            thinkingDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"minimal">, zod.ZodLiteral<"low">, zod.ZodLiteral<"medium">, zod.ZodLiteral<"high">, zod.ZodLiteral<"xhigh">]>>;
            verboseDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"on">, zod.ZodLiteral<"full">]>>;
            elevatedDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"on">, zod.ZodLiteral<"ask">, zod.ZodLiteral<"full">]>>;
            blockStreamingDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"on">]>>;
            blockStreamingBreak: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"text_end">, zod.ZodLiteral<"message_end">]>>;
            blockStreamingChunk: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
            }, zod.z.core.$strict>>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            humanDelay: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"natural">, zod.ZodLiteral<"custom">]>>;
                minMs: zod.ZodOptional<zod.ZodNumber>;
                maxMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            typingIntervalSeconds: zod.ZodOptional<zod.ZodNumber>;
            typingMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"never">, zod.ZodLiteral<"instant">, zod.ZodLiteral<"thinking">, zod.ZodLiteral<"message">]>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                every: zod.ZodOptional<zod.ZodString>;
                activeHours: zod.ZodOptional<zod.ZodObject<{
                    start: zod.ZodOptional<zod.ZodString>;
                    end: zod.ZodOptional<zod.ZodString>;
                    timezone: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
                model: zod.ZodOptional<zod.ZodString>;
                session: zod.ZodOptional<zod.ZodString>;
                includeReasoning: zod.ZodOptional<zod.ZodBoolean>;
                target: zod.ZodOptional<zod.ZodString>;
                to: zod.ZodOptional<zod.ZodString>;
                prompt: zod.ZodOptional<zod.ZodString>;
                ackMaxChars: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            maxConcurrent: zod.ZodOptional<zod.ZodNumber>;
            subagents: zod.ZodOptional<zod.ZodObject<{
                maxConcurrent: zod.ZodOptional<zod.ZodNumber>;
                archiveAfterMinutes: zod.ZodOptional<zod.ZodNumber>;
                model: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
                    primary: zod.ZodOptional<zod.ZodString>;
                    fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>]>>;
                thinking: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            sandbox: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"non-main">, zod.ZodLiteral<"all">]>>;
                workspaceAccess: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"none">, zod.ZodLiteral<"ro">, zod.ZodLiteral<"rw">]>>;
                sessionToolsVisibility: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"spawned">, zod.ZodLiteral<"all">]>>;
                scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"session">, zod.ZodLiteral<"agent">, zod.ZodLiteral<"shared">]>>;
                perSession: zod.ZodOptional<zod.ZodBoolean>;
                workspaceRoot: zod.ZodOptional<zod.ZodString>;
                docker: zod.ZodOptional<zod.ZodObject<{
                    image: zod.ZodOptional<zod.ZodString>;
                    containerPrefix: zod.ZodOptional<zod.ZodString>;
                    workdir: zod.ZodOptional<zod.ZodString>;
                    readOnlyRoot: zod.ZodOptional<zod.ZodBoolean>;
                    tmpfs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    network: zod.ZodOptional<zod.ZodString>;
                    user: zod.ZodOptional<zod.ZodString>;
                    capDrop: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    setupCommand: zod.ZodOptional<zod.ZodString>;
                    pidsLimit: zod.ZodOptional<zod.ZodNumber>;
                    memory: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
                    memorySwap: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
                    cpus: zod.ZodOptional<zod.ZodNumber>;
                    ulimits: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodObject<{
                        soft: zod.ZodOptional<zod.ZodNumber>;
                        hard: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>]>>>;
                    seccompProfile: zod.ZodOptional<zod.ZodString>;
                    apparmorProfile: zod.ZodOptional<zod.ZodString>;
                    dns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    extraHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    binds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                browser: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    image: zod.ZodOptional<zod.ZodString>;
                    containerPrefix: zod.ZodOptional<zod.ZodString>;
                    cdpPort: zod.ZodOptional<zod.ZodNumber>;
                    vncPort: zod.ZodOptional<zod.ZodNumber>;
                    noVncPort: zod.ZodOptional<zod.ZodNumber>;
                    headless: zod.ZodOptional<zod.ZodBoolean>;
                    enableNoVnc: zod.ZodOptional<zod.ZodBoolean>;
                    allowHostControl: zod.ZodOptional<zod.ZodBoolean>;
                    autoStart: zod.ZodOptional<zod.ZodBoolean>;
                    autoStartTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                prune: zod.ZodOptional<zod.ZodObject<{
                    idleHours: zod.ZodOptional<zod.ZodNumber>;
                    maxAgeDays: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
            inboxTriage: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                triageCron: zod.ZodOptional<zod.ZodString>;
                digestCron: zod.ZodOptional<zod.ZodString>;
                digestTimezone: zod.ZodOptional<zod.ZodString>;
                channels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                prioritySenders: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                priorityChannels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                autoReply: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    confidenceThreshold: zod.ZodOptional<zod.ZodNumber>;
                    senderWhitelist: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    channelWhitelist: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    maxAutoRepliesPerHour: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                triageRules: zod.ZodOptional<zod.ZodObject<{
                    alwaysUrgent: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alwaysIgnore: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alwaysNotify: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                digestDeliveryChannel: zod.ZodOptional<zod.ZodString>;
                retentionDays: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>>>;
        list: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            id: zod.ZodString;
            default: zod.ZodOptional<zod.ZodBoolean>;
            name: zod.ZodOptional<zod.ZodString>;
            identityName: zod.ZodOptional<zod.ZodString>;
            workspace: zod.ZodOptional<zod.ZodString>;
            agentDir: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
                primary: zod.ZodOptional<zod.ZodString>;
                fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>]>>;
            skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            memorySearch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                sources: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"memory">, zod.ZodLiteral<"sessions">]>>>;
                extraPaths: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                experimental: zod.ZodOptional<zod.ZodObject<{
                    sessionMemory: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                provider: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"local">, zod.ZodLiteral<"gemini">]>>;
                remote: zod.ZodOptional<zod.ZodObject<{
                    baseUrl: zod.ZodOptional<zod.ZodString>;
                    apiKey: zod.ZodOptional<zod.ZodString>;
                    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    batch: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        wait: zod.ZodOptional<zod.ZodBoolean>;
                        concurrency: zod.ZodOptional<zod.ZodNumber>;
                        pollIntervalMs: zod.ZodOptional<zod.ZodNumber>;
                        timeoutMinutes: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                fallback: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"gemini">, zod.ZodLiteral<"local">, zod.ZodLiteral<"none">]>>;
                model: zod.ZodOptional<zod.ZodString>;
                local: zod.ZodOptional<zod.ZodObject<{
                    modelPath: zod.ZodOptional<zod.ZodString>;
                    modelCacheDir: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
                store: zod.ZodOptional<zod.ZodObject<{
                    driver: zod.ZodOptional<zod.ZodLiteral<"sqlite">>;
                    path: zod.ZodOptional<zod.ZodString>;
                    vector: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        extensionPath: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                chunking: zod.ZodOptional<zod.ZodObject<{
                    tokens: zod.ZodOptional<zod.ZodNumber>;
                    overlap: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                sync: zod.ZodOptional<zod.ZodObject<{
                    onSessionStart: zod.ZodOptional<zod.ZodBoolean>;
                    onSearch: zod.ZodOptional<zod.ZodBoolean>;
                    watch: zod.ZodOptional<zod.ZodBoolean>;
                    watchDebounceMs: zod.ZodOptional<zod.ZodNumber>;
                    intervalMinutes: zod.ZodOptional<zod.ZodNumber>;
                    sessions: zod.ZodOptional<zod.ZodObject<{
                        deltaBytes: zod.ZodOptional<zod.ZodNumber>;
                        deltaMessages: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                query: zod.ZodOptional<zod.ZodObject<{
                    maxResults: zod.ZodOptional<zod.ZodNumber>;
                    minScore: zod.ZodOptional<zod.ZodNumber>;
                    hybrid: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        vectorWeight: zod.ZodOptional<zod.ZodNumber>;
                        textWeight: zod.ZodOptional<zod.ZodNumber>;
                        candidateMultiplier: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                cache: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    maxEntries: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
            advancedMemory: zod.ZodOptional<zod.ZodBoolean>;
            agentOrchestrator: zod.ZodOptional<zod.ZodBoolean>;
            gitpathologist: zod.ZodOptional<zod.ZodBoolean>;
            humanDelay: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"natural">, zod.ZodLiteral<"custom">]>>;
                minMs: zod.ZodOptional<zod.ZodNumber>;
                maxMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                every: zod.ZodOptional<zod.ZodString>;
                activeHours: zod.ZodOptional<zod.ZodObject<{
                    start: zod.ZodOptional<zod.ZodString>;
                    end: zod.ZodOptional<zod.ZodString>;
                    timezone: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
                model: zod.ZodOptional<zod.ZodString>;
                session: zod.ZodOptional<zod.ZodString>;
                includeReasoning: zod.ZodOptional<zod.ZodBoolean>;
                target: zod.ZodOptional<zod.ZodString>;
                to: zod.ZodOptional<zod.ZodString>;
                prompt: zod.ZodOptional<zod.ZodString>;
                ackMaxChars: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            identity: zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                theme: zod.ZodOptional<zod.ZodString>;
                emoji: zod.ZodOptional<zod.ZodString>;
                avatar: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            groupChat: zod.ZodOptional<zod.ZodObject<{
                mentionPatterns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            subagents: zod.ZodOptional<zod.ZodObject<{
                allowAgents: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                model: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
                    primary: zod.ZodOptional<zod.ZodString>;
                    fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>]>>;
                thinking: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            sandbox: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"non-main">, zod.ZodLiteral<"all">]>>;
                workspaceAccess: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"none">, zod.ZodLiteral<"ro">, zod.ZodLiteral<"rw">]>>;
                sessionToolsVisibility: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"spawned">, zod.ZodLiteral<"all">]>>;
                scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"session">, zod.ZodLiteral<"agent">, zod.ZodLiteral<"shared">]>>;
                perSession: zod.ZodOptional<zod.ZodBoolean>;
                workspaceRoot: zod.ZodOptional<zod.ZodString>;
                docker: zod.ZodOptional<zod.ZodObject<{
                    image: zod.ZodOptional<zod.ZodString>;
                    containerPrefix: zod.ZodOptional<zod.ZodString>;
                    workdir: zod.ZodOptional<zod.ZodString>;
                    readOnlyRoot: zod.ZodOptional<zod.ZodBoolean>;
                    tmpfs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    network: zod.ZodOptional<zod.ZodString>;
                    user: zod.ZodOptional<zod.ZodString>;
                    capDrop: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    setupCommand: zod.ZodOptional<zod.ZodString>;
                    pidsLimit: zod.ZodOptional<zod.ZodNumber>;
                    memory: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
                    memorySwap: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
                    cpus: zod.ZodOptional<zod.ZodNumber>;
                    ulimits: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodObject<{
                        soft: zod.ZodOptional<zod.ZodNumber>;
                        hard: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>]>>>;
                    seccompProfile: zod.ZodOptional<zod.ZodString>;
                    apparmorProfile: zod.ZodOptional<zod.ZodString>;
                    dns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    extraHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    binds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                browser: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    image: zod.ZodOptional<zod.ZodString>;
                    containerPrefix: zod.ZodOptional<zod.ZodString>;
                    cdpPort: zod.ZodOptional<zod.ZodNumber>;
                    vncPort: zod.ZodOptional<zod.ZodNumber>;
                    noVncPort: zod.ZodOptional<zod.ZodNumber>;
                    headless: zod.ZodOptional<zod.ZodBoolean>;
                    enableNoVnc: zod.ZodOptional<zod.ZodBoolean>;
                    allowHostControl: zod.ZodOptional<zod.ZodBoolean>;
                    autoStart: zod.ZodOptional<zod.ZodBoolean>;
                    autoStartTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                prune: zod.ZodOptional<zod.ZodObject<{
                    idleHours: zod.ZodOptional<zod.ZodNumber>;
                    maxAgeDays: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
            tools: zod.ZodOptional<zod.ZodObject<{
                profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                byProvider: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
                }, zod.z.core.$strict>>>;
                elevated: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    allowFrom: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>>;
                }, zod.z.core.$strict>>;
                exec: zod.ZodOptional<zod.ZodObject<{
                    host: zod.ZodOptional<zod.ZodEnum<{
                        sandbox: "sandbox";
                        gateway: "gateway";
                        node: "node";
                    }>>;
                    security: zod.ZodOptional<zod.ZodEnum<{
                        deny: "deny";
                        full: "full";
                        allowlist: "allowlist";
                    }>>;
                    ask: zod.ZodOptional<zod.ZodEnum<{
                        always: "always";
                        off: "off";
                        "on-miss": "on-miss";
                    }>>;
                    node: zod.ZodOptional<zod.ZodString>;
                    pathPrepend: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    safeBins: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    backgroundMs: zod.ZodOptional<zod.ZodNumber>;
                    timeoutSec: zod.ZodOptional<zod.ZodNumber>;
                    approvalRunningNoticeMs: zod.ZodOptional<zod.ZodNumber>;
                    cleanupMs: zod.ZodOptional<zod.ZodNumber>;
                    notifyOnExit: zod.ZodOptional<zod.ZodBoolean>;
                    applyPatch: zod.ZodOptional<zod.ZodObject<{
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        allowModels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
                sandbox: zod.ZodOptional<zod.ZodObject<{
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    tools: zod.ZodOptional<zod.ZodObject<{
        profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        byProvider: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
        }, zod.z.core.$strict>>>;
        web: zod.ZodOptional<zod.ZodObject<{
            search: zod.ZodOptional<zod.ZodObject<{
                maxResults: zod.ZodOptional<zod.ZodNumber>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            fetch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
                maxRedirects: zod.ZodOptional<zod.ZodNumber>;
                userAgent: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        cache: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            memoryCapacity: zod.ZodOptional<zod.ZodNumber>;
            diskRoot: zod.ZodOptional<zod.ZodString>;
            perTool: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                ttlMinutes: zod.ZodOptional<zod.ZodNumber>;
                version: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        media: zod.ZodOptional<zod.ZodObject<{
            models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                provider: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                command: zod.ZodOptional<zod.ZodString>;
                args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                prompt: zod.ZodOptional<zod.ZodString>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                profile: zod.ZodOptional<zod.ZodString>;
                preferredProfile: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
            concurrency: zod.ZodOptional<zod.ZodNumber>;
            image: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                scope: zod.ZodOptional<zod.ZodObject<{
                    default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                    rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                        action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                        match: zod.ZodOptional<zod.ZodObject<{
                            channel: zod.ZodOptional<zod.ZodString>;
                            chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                            keyPrefix: zod.ZodOptional<zod.ZodString>;
                        }, zod.z.core.$strict>>;
                    }, zod.z.core.$strict>>>;
                }, zod.z.core.$strict>>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                prompt: zod.ZodOptional<zod.ZodString>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                attachments: zod.ZodOptional<zod.ZodObject<{
                    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                    maxAttachments: zod.ZodOptional<zod.ZodNumber>;
                    prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
                }, zod.z.core.$strict>>;
                models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                    provider: zod.ZodOptional<zod.ZodString>;
                    model: zod.ZodOptional<zod.ZodString>;
                    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                    type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                    command: zod.ZodOptional<zod.ZodString>;
                    args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    prompt: zod.ZodOptional<zod.ZodString>;
                    maxBytes: zod.ZodOptional<zod.ZodNumber>;
                    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                    language: zod.ZodOptional<zod.ZodString>;
                    providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                    deepgram: zod.ZodOptional<zod.ZodObject<{
                        detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                        punctuate: zod.ZodOptional<zod.ZodBoolean>;
                        smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                    }, zod.z.core.$strict>>;
                    baseUrl: zod.ZodOptional<zod.ZodString>;
                    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    profile: zod.ZodOptional<zod.ZodString>;
                    preferredProfile: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>;
            audio: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                scope: zod.ZodOptional<zod.ZodObject<{
                    default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                    rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                        action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                        match: zod.ZodOptional<zod.ZodObject<{
                            channel: zod.ZodOptional<zod.ZodString>;
                            chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                            keyPrefix: zod.ZodOptional<zod.ZodString>;
                        }, zod.z.core.$strict>>;
                    }, zod.z.core.$strict>>>;
                }, zod.z.core.$strict>>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                prompt: zod.ZodOptional<zod.ZodString>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                attachments: zod.ZodOptional<zod.ZodObject<{
                    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                    maxAttachments: zod.ZodOptional<zod.ZodNumber>;
                    prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
                }, zod.z.core.$strict>>;
                models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                    provider: zod.ZodOptional<zod.ZodString>;
                    model: zod.ZodOptional<zod.ZodString>;
                    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                    type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                    command: zod.ZodOptional<zod.ZodString>;
                    args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    prompt: zod.ZodOptional<zod.ZodString>;
                    maxBytes: zod.ZodOptional<zod.ZodNumber>;
                    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                    language: zod.ZodOptional<zod.ZodString>;
                    providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                    deepgram: zod.ZodOptional<zod.ZodObject<{
                        detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                        punctuate: zod.ZodOptional<zod.ZodBoolean>;
                        smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                    }, zod.z.core.$strict>>;
                    baseUrl: zod.ZodOptional<zod.ZodString>;
                    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    profile: zod.ZodOptional<zod.ZodString>;
                    preferredProfile: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>;
            video: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                scope: zod.ZodOptional<zod.ZodObject<{
                    default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                    rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                        action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                        match: zod.ZodOptional<zod.ZodObject<{
                            channel: zod.ZodOptional<zod.ZodString>;
                            chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                            keyPrefix: zod.ZodOptional<zod.ZodString>;
                        }, zod.z.core.$strict>>;
                    }, zod.z.core.$strict>>>;
                }, zod.z.core.$strict>>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                prompt: zod.ZodOptional<zod.ZodString>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                attachments: zod.ZodOptional<zod.ZodObject<{
                    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                    maxAttachments: zod.ZodOptional<zod.ZodNumber>;
                    prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
                }, zod.z.core.$strict>>;
                models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                    provider: zod.ZodOptional<zod.ZodString>;
                    model: zod.ZodOptional<zod.ZodString>;
                    capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                    type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                    command: zod.ZodOptional<zod.ZodString>;
                    args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    prompt: zod.ZodOptional<zod.ZodString>;
                    maxBytes: zod.ZodOptional<zod.ZodNumber>;
                    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                    language: zod.ZodOptional<zod.ZodString>;
                    providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                    deepgram: zod.ZodOptional<zod.ZodObject<{
                        detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                        punctuate: zod.ZodOptional<zod.ZodBoolean>;
                        smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                    }, zod.z.core.$strict>>;
                    baseUrl: zod.ZodOptional<zod.ZodString>;
                    headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                    profile: zod.ZodOptional<zod.ZodString>;
                    preferredProfile: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        links: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            scope: zod.ZodOptional<zod.ZodObject<{
                default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                    action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                    match: zod.ZodOptional<zod.ZodObject<{
                        channel: zod.ZodOptional<zod.ZodString>;
                        chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                        keyPrefix: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>>;
            }, zod.z.core.$strict>>;
            maxLinks: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            models: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                type: zod.ZodOptional<zod.ZodLiteral<"cli">>;
                command: zod.ZodString;
                args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        message: zod.ZodOptional<zod.ZodObject<{
            allowCrossContextSend: zod.ZodOptional<zod.ZodBoolean>;
            crossContext: zod.ZodOptional<zod.ZodObject<{
                allowWithinProvider: zod.ZodOptional<zod.ZodBoolean>;
                allowAcrossProviders: zod.ZodOptional<zod.ZodBoolean>;
                marker: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    prefix: zod.ZodOptional<zod.ZodString>;
                    suffix: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
            broadcast: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        agentToAgent: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        elevated: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>>;
        }, zod.z.core.$strict>>;
        exec: zod.ZodOptional<zod.ZodObject<{
            host: zod.ZodOptional<zod.ZodEnum<{
                sandbox: "sandbox";
                gateway: "gateway";
                node: "node";
            }>>;
            security: zod.ZodOptional<zod.ZodEnum<{
                deny: "deny";
                full: "full";
                allowlist: "allowlist";
            }>>;
            ask: zod.ZodOptional<zod.ZodEnum<{
                always: "always";
                off: "off";
                "on-miss": "on-miss";
            }>>;
            node: zod.ZodOptional<zod.ZodString>;
            pathPrepend: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            safeBins: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            backgroundMs: zod.ZodOptional<zod.ZodNumber>;
            timeoutSec: zod.ZodOptional<zod.ZodNumber>;
            cleanupMs: zod.ZodOptional<zod.ZodNumber>;
            notifyOnExit: zod.ZodOptional<zod.ZodBoolean>;
            applyPatch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allowModels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        subagents: zod.ZodOptional<zod.ZodObject<{
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        sandbox: zod.ZodOptional<zod.ZodObject<{
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    bindings: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        agentId: zod.ZodString;
        match: zod.ZodObject<{
            channel: zod.ZodString;
            accountId: zod.ZodOptional<zod.ZodString>;
            peer: zod.ZodOptional<zod.ZodObject<{
                kind: zod.ZodUnion<readonly [zod.ZodLiteral<"dm">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>;
                id: zod.ZodString;
            }, zod.z.core.$strict>>;
            guildId: zod.ZodOptional<zod.ZodString>;
            teamId: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>;
    }, zod.z.core.$strict>>>;
    broadcast: zod.ZodOptional<zod.ZodObject<{
        strategy: zod.ZodOptional<zod.ZodEnum<{
            parallel: "parallel";
            sequential: "sequential";
        }>>;
    }, zod.z.core.$catchall<zod.ZodArray<zod.ZodString>>>>;
    audio: zod.ZodOptional<zod.ZodObject<{
        transcription: zod.ZodOptional<zod.ZodObject<{
            command: zod.ZodArray<zod.ZodString>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    media: zod.ZodOptional<zod.ZodObject<{
        preserveFilenames: zod.ZodOptional<zod.ZodBoolean>;
        image: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            mode: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                "own-key": "own-key";
            }>>;
            provider: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                openai: "openai";
                fal: "fal";
                google: "google";
                xai: "xai";
            }>>;
            defaultSize: zod.ZodOptional<zod.ZodString>;
            fal: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            openai: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                quality: zod.ZodOptional<zod.ZodEnum<{
                    standard: "standard";
                    hd: "hd";
                }>>;
                style: zod.ZodOptional<zod.ZodEnum<{
                    natural: "natural";
                    vivid: "vivid";
                }>>;
            }, zod.z.core.$strict>>;
            google: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                aspectRatio: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            xai: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        video: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            mode: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                "own-key": "own-key";
            }>>;
            provider: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                openai: "openai";
                fal: "fal";
                google: "google";
            }>>;
            defaultDuration: zod.ZodOptional<zod.ZodNumber>;
            fal: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            openai: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            google: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        audio: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            mode: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                "own-key": "own-key";
            }>>;
            provider: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                fal: "fal";
                elevenlabs: "elevenlabs";
                suno: "suno";
            }>>;
            providers: zod.ZodOptional<zod.ZodObject<{
                default: zod.ZodOptional<zod.ZodEnum<{
                    cloud: "cloud";
                    fal: "fal";
                    elevenlabs: "elevenlabs";
                    suno: "suno";
                }>>;
                music: zod.ZodOptional<zod.ZodEnum<{
                    cloud: "cloud";
                    fal: "fal";
                    elevenlabs: "elevenlabs";
                    suno: "suno";
                }>>;
                sfx: zod.ZodOptional<zod.ZodEnum<{
                    cloud: "cloud";
                    fal: "fal";
                    elevenlabs: "elevenlabs";
                    suno: "suno";
                }>>;
                tts: zod.ZodOptional<zod.ZodEnum<{
                    cloud: "cloud";
                    fal: "fal";
                    elevenlabs: "elevenlabs";
                    suno: "suno";
                }>>;
            }, zod.z.core.$strict>>;
            defaultKind: zod.ZodOptional<zod.ZodEnum<{
                tts: "tts";
                music: "music";
                sfx: "sfx";
            }>>;
            audioKind: zod.ZodOptional<zod.ZodEnum<{
                tts: "tts";
                music: "music";
                sfx: "sfx";
            }>>;
            kind: zod.ZodOptional<zod.ZodEnum<{
                tts: "tts";
                music: "music";
                sfx: "sfx";
            }>>;
            suno: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            elevenlabs: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                modelId: zod.ZodOptional<zod.ZodString>;
                musicModelId: zod.ZodOptional<zod.ZodString>;
                sfxModelId: zod.ZodOptional<zod.ZodString>;
                ttsModelId: zod.ZodOptional<zod.ZodString>;
                voiceId: zod.ZodOptional<zod.ZodString>;
                outputFormat: zod.ZodOptional<zod.ZodString>;
                duration: zod.ZodOptional<zod.ZodNumber>;
                promptInfluence: zod.ZodOptional<zod.ZodNumber>;
                loop: zod.ZodOptional<zod.ZodBoolean>;
                seed: zod.ZodOptional<zod.ZodNumber>;
                languageCode: zod.ZodOptional<zod.ZodString>;
                applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
                    on: "on";
                    off: "off";
                    auto: "auto";
                }>>;
                voiceSettings: zod.ZodOptional<zod.ZodObject<{
                    stability: zod.ZodOptional<zod.ZodNumber>;
                    similarityBoost: zod.ZodOptional<zod.ZodNumber>;
                    style: zod.ZodOptional<zod.ZodNumber>;
                    useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
                    speed: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                signWithC2pa: zod.ZodOptional<zod.ZodBoolean>;
                timeoutMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            fal: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                secondsStart: zod.ZodOptional<zod.ZodNumber>;
                secondsTotal: zod.ZodOptional<zod.ZodNumber>;
                steps: zod.ZodOptional<zod.ZodNumber>;
                timeoutMs: zod.ZodOptional<zod.ZodNumber>;
                extraInput: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        vision: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            mode: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                "own-key": "own-key";
            }>>;
            provider: zod.ZodOptional<zod.ZodEnum<{
                cloud: "cloud";
                anthropic: "anthropic";
                openai: "openai";
                ollama: "ollama";
                google: "google";
                xai: "xai";
            }>>;
            openai: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                maxTokens: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            google: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            anthropic: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            xai: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            ollama: zod.ZodOptional<zod.ZodObject<{
                baseUrl: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                maxTokens: zod.ZodOptional<zod.ZodNumber>;
                autoDownload: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    messages: zod.ZodOptional<zod.ZodObject<{
        messagePrefix: zod.ZodOptional<zod.ZodString>;
        responsePrefix: zod.ZodOptional<zod.ZodString>;
        groupChat: zod.ZodOptional<zod.ZodObject<{
            mentionPatterns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        queue: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            byChannel: zod.ZodOptional<zod.ZodObject<{
                whatsapp: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                telegram: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                discord: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                slack: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                mattermost: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                imessage: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                msteams: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
                webchat: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"steer">, zod.ZodLiteral<"followup">, zod.ZodLiteral<"collect">, zod.ZodLiteral<"steer-backlog">, zod.ZodLiteral<"steer+backlog">, zod.ZodLiteral<"queue">, zod.ZodLiteral<"interrupt">]>>;
            }, zod.z.core.$strict>>;
            debounceMs: zod.ZodOptional<zod.ZodNumber>;
            debounceMsByChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
            cap: zod.ZodOptional<zod.ZodNumber>;
            drop: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"old">, zod.ZodLiteral<"new">, zod.ZodLiteral<"summarize">]>>;
        }, zod.z.core.$strict>>;
        inbound: zod.ZodOptional<zod.ZodObject<{
            debounceMs: zod.ZodOptional<zod.ZodNumber>;
            byChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodNumber>>;
        }, zod.z.core.$strict>>;
        ackReaction: zod.ZodOptional<zod.ZodString>;
        ackReactionScope: zod.ZodOptional<zod.ZodEnum<{
            all: "all";
            direct: "direct";
            "group-mentions": "group-mentions";
            "group-all": "group-all";
        }>>;
        removeAckAfterReply: zod.ZodOptional<zod.ZodBoolean>;
        tts: zod.ZodOptional<zod.ZodObject<{
            auto: zod.ZodOptional<zod.ZodEnum<{
                always: "always";
                off: "off";
                inbound: "inbound";
                tagged: "tagged";
            }>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            mode: zod.ZodOptional<zod.ZodEnum<{
                all: "all";
                final: "final";
            }>>;
            provider: zod.ZodOptional<zod.ZodEnum<{
                openai: "openai";
                elevenlabs: "elevenlabs";
                edge: "edge";
            }>>;
            summaryModel: zod.ZodOptional<zod.ZodString>;
            modelOverrides: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allowText: zod.ZodOptional<zod.ZodBoolean>;
                allowProvider: zod.ZodOptional<zod.ZodBoolean>;
                allowVoice: zod.ZodOptional<zod.ZodBoolean>;
                allowModelId: zod.ZodOptional<zod.ZodBoolean>;
                allowVoiceSettings: zod.ZodOptional<zod.ZodBoolean>;
                allowNormalization: zod.ZodOptional<zod.ZodBoolean>;
                allowSeed: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            elevenlabs: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                voiceId: zod.ZodOptional<zod.ZodString>;
                modelId: zod.ZodOptional<zod.ZodString>;
                seed: zod.ZodOptional<zod.ZodNumber>;
                applyTextNormalization: zod.ZodOptional<zod.ZodEnum<{
                    on: "on";
                    off: "off";
                    auto: "auto";
                }>>;
                languageCode: zod.ZodOptional<zod.ZodString>;
                voiceSettings: zod.ZodOptional<zod.ZodObject<{
                    stability: zod.ZodOptional<zod.ZodNumber>;
                    similarityBoost: zod.ZodOptional<zod.ZodNumber>;
                    style: zod.ZodOptional<zod.ZodNumber>;
                    useSpeakerBoost: zod.ZodOptional<zod.ZodBoolean>;
                    speed: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
            openai: zod.ZodOptional<zod.ZodObject<{
                apiKey: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                voice: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            edge: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                voice: zod.ZodOptional<zod.ZodString>;
                lang: zod.ZodOptional<zod.ZodString>;
                outputFormat: zod.ZodOptional<zod.ZodString>;
                pitch: zod.ZodOptional<zod.ZodString>;
                rate: zod.ZodOptional<zod.ZodString>;
                volume: zod.ZodOptional<zod.ZodString>;
                saveSubtitles: zod.ZodOptional<zod.ZodBoolean>;
                proxy: zod.ZodOptional<zod.ZodString>;
                timeoutMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            prefsPath: zod.ZodOptional<zod.ZodString>;
            maxTextLength: zod.ZodOptional<zod.ZodNumber>;
            timeoutMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    approvals: zod.ZodOptional<zod.ZodObject<{
        exec: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"session">, zod.ZodLiteral<"targets">, zod.ZodLiteral<"both">]>>;
            agentFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            sessionFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            targets: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                channel: zod.ZodString;
                to: zod.ZodString;
                accountId: zod.ZodOptional<zod.ZodString>;
                threadId: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    session: zod.ZodOptional<zod.ZodObject<{
        scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"per-sender">, zod.ZodLiteral<"global">]>>;
        dmScope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"main">, zod.ZodLiteral<"per-peer">, zod.ZodLiteral<"per-channel-peer">, zod.ZodLiteral<"per-account-channel-peer">]>>;
        identityLinks: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodString>>>;
        resetTriggers: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        idleMinutes: zod.ZodOptional<zod.ZodNumber>;
        reset: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
            atHour: zod.ZodOptional<zod.ZodNumber>;
            idleMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        resetByType: zod.ZodOptional<zod.ZodObject<{
            dm: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
                atHour: zod.ZodOptional<zod.ZodNumber>;
                idleMinutes: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            group: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
                atHour: zod.ZodOptional<zod.ZodNumber>;
                idleMinutes: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            thread: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
                atHour: zod.ZodOptional<zod.ZodNumber>;
                idleMinutes: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        resetByChannel: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"daily">, zod.ZodLiteral<"idle">]>>;
            atHour: zod.ZodOptional<zod.ZodNumber>;
            idleMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>;
        store: zod.ZodOptional<zod.ZodString>;
        typingIntervalSeconds: zod.ZodOptional<zod.ZodNumber>;
        typingMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"never">, zod.ZodLiteral<"instant">, zod.ZodLiteral<"thinking">, zod.ZodLiteral<"message">]>>;
        mainKey: zod.ZodOptional<zod.ZodString>;
        sendPolicy: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
            default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
            rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                match: zod.ZodOptional<zod.ZodObject<{
                    channel: zod.ZodOptional<zod.ZodString>;
                    chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                    keyPrefix: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>>;
        agentToAgent: zod.ZodOptional<zod.ZodObject<{
            maxPingPongTurns: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    cron: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        store: zod.ZodOptional<zod.ZodString>;
        maxConcurrentRuns: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    hooks: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        path: zod.ZodOptional<zod.ZodString>;
        token: zod.ZodOptional<zod.ZodString>;
        maxBodyBytes: zod.ZodOptional<zod.ZodNumber>;
        presets: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        transformsDir: zod.ZodOptional<zod.ZodString>;
        mappings: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
            id: zod.ZodOptional<zod.ZodString>;
            match: zod.ZodOptional<zod.ZodObject<{
                path: zod.ZodOptional<zod.ZodString>;
                source: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strip>>;
            action: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"wake">, zod.ZodLiteral<"agent">]>>;
            wakeMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"now">, zod.ZodLiteral<"next-heartbeat">]>>;
            name: zod.ZodOptional<zod.ZodString>;
            sessionKey: zod.ZodOptional<zod.ZodString>;
            messageTemplate: zod.ZodOptional<zod.ZodString>;
            textTemplate: zod.ZodOptional<zod.ZodString>;
            deliver: zod.ZodOptional<zod.ZodBoolean>;
            allowUnsafeExternalContent: zod.ZodOptional<zod.ZodBoolean>;
            channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"last">, zod.ZodLiteral<"whatsapp">, zod.ZodLiteral<"telegram">, zod.ZodLiteral<"discord">, zod.ZodLiteral<"googlechat">, zod.ZodLiteral<"slack">, zod.ZodLiteral<"imessage">, zod.ZodLiteral<"msteams">]>>;
            to: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            thinking: zod.ZodOptional<zod.ZodString>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            transform: zod.ZodOptional<zod.ZodObject<{
                module: zod.ZodString;
                export: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>>>;
        gmail: zod.ZodOptional<zod.ZodObject<{
            account: zod.ZodOptional<zod.ZodString>;
            label: zod.ZodOptional<zod.ZodString>;
            topic: zod.ZodOptional<zod.ZodString>;
            subscription: zod.ZodOptional<zod.ZodString>;
            pushToken: zod.ZodOptional<zod.ZodString>;
            hookUrl: zod.ZodOptional<zod.ZodString>;
            includeBody: zod.ZodOptional<zod.ZodBoolean>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            renewEveryMinutes: zod.ZodOptional<zod.ZodNumber>;
            allowUnsafeExternalContent: zod.ZodOptional<zod.ZodBoolean>;
            serve: zod.ZodOptional<zod.ZodObject<{
                bind: zod.ZodOptional<zod.ZodString>;
                port: zod.ZodOptional<zod.ZodNumber>;
                path: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            tailscale: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"serve">, zod.ZodLiteral<"funnel">]>>;
                path: zod.ZodOptional<zod.ZodString>;
                target: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            model: zod.ZodOptional<zod.ZodString>;
            thinking: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"minimal">, zod.ZodLiteral<"low">, zod.ZodLiteral<"medium">, zod.ZodLiteral<"high">]>>;
        }, zod.z.core.$strict>>;
        internal: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            entries: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            }, zod.z.core.$strict>>>;
            load: zod.ZodOptional<zod.ZodObject<{
                extraDirs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            installs: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
                source: zod.ZodUnion<readonly [zod.ZodLiteral<"npm">, zod.ZodLiteral<"archive">, zod.ZodLiteral<"path">]>;
                spec: zod.ZodOptional<zod.ZodString>;
                sourcePath: zod.ZodOptional<zod.ZodString>;
                installPath: zod.ZodOptional<zod.ZodString>;
                version: zod.ZodOptional<zod.ZodString>;
                installedAt: zod.ZodOptional<zod.ZodString>;
                hooks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    web: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        heartbeatSeconds: zod.ZodOptional<zod.ZodNumber>;
        reconnect: zod.ZodOptional<zod.ZodObject<{
            initialMs: zod.ZodOptional<zod.ZodNumber>;
            maxMs: zod.ZodOptional<zod.ZodNumber>;
            factor: zod.ZodOptional<zod.ZodNumber>;
            jitter: zod.ZodOptional<zod.ZodNumber>;
            maxAttempts: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    connectors: zod.ZodOptional<zod.ZodObject<{
        defaults: zod.ZodOptional<zod.ZodObject<{
            groupPolicy: zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        whatsapp: zod.ZodOptional<zod.ZodObject<{
            accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                markdown: zod.ZodOptional<zod.ZodObject<{
                    tables: zod.ZodOptional<zod.ZodEnum<{
                        code: "code";
                        off: "off";
                        bullets: "bullets";
                    }>>;
                }, zod.z.core.$strict>>;
                configWrites: zod.ZodOptional<zod.ZodBoolean>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                sendReadReceipts: zod.ZodOptional<zod.ZodBoolean>;
                messagePrefix: zod.ZodOptional<zod.ZodString>;
                authDir: zod.ZodOptional<zod.ZodString>;
                dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    pairing: "pairing";
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                selfChatMode: zod.ZodOptional<zod.ZodBoolean>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
                dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
                dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    historyLimit: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>>>;
                textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
                chunkMode: zod.ZodOptional<zod.ZodEnum<{
                    length: "length";
                    newline: "newline";
                }>>;
                mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
                blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
                blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    idleMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                }, zod.z.core.$strict>>>>;
                ackReaction: zod.ZodOptional<zod.ZodObject<{
                    emoji: zod.ZodOptional<zod.ZodString>;
                    direct: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
                    group: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                        always: "always";
                        never: "never";
                        mentions: "mentions";
                    }>>>;
                }, zod.z.core.$strict>>;
                debounceMs: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
                heartbeat: zod.ZodOptional<zod.ZodObject<{
                    showOk: zod.ZodOptional<zod.ZodBoolean>;
                    showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                    useIndicator: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            markdown: zod.ZodOptional<zod.ZodObject<{
                tables: zod.ZodOptional<zod.ZodEnum<{
                    code: "code";
                    off: "off";
                    bullets: "bullets";
                }>>;
            }, zod.z.core.$strict>>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            sendReadReceipts: zod.ZodOptional<zod.ZodBoolean>;
            dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            messagePrefix: zod.ZodOptional<zod.ZodString>;
            selfChatMode: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            mediaMaxMb: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            actions: zod.ZodOptional<zod.ZodObject<{
                reactions: zod.ZodOptional<zod.ZodBoolean>;
                sendMessage: zod.ZodOptional<zod.ZodBoolean>;
                polls: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>>;
            ackReaction: zod.ZodOptional<zod.ZodObject<{
                emoji: zod.ZodOptional<zod.ZodString>;
                direct: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
                group: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    always: "always";
                    never: "never";
                    mentions: "mentions";
                }>>>;
            }, zod.z.core.$strict>>;
            debounceMs: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        telegram: zod.ZodOptional<zod.ZodObject<{
            name: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodArray<zod.ZodString>, zod.ZodObject<{
                inlineButtons: zod.ZodOptional<zod.ZodEnum<{
                    all: "all";
                    off: "off";
                    group: "group";
                    dm: "dm";
                    allowlist: "allowlist";
                }>>;
            }, zod.z.core.$strict>]>>;
            markdown: zod.ZodOptional<zod.ZodObject<{
                tables: zod.ZodOptional<zod.ZodEnum<{
                    code: "code";
                    off: "off";
                    bullets: "bullets";
                }>>;
            }, zod.z.core.$strict>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            commands: zod.ZodOptional<zod.ZodObject<{
                native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
            }, zod.z.core.$strict>>;
            customCommands: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                command: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
                description: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
            }, zod.z.core.$strict>>>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            botToken: zod.ZodOptional<zod.ZodString>;
            tokenFile: zod.ZodOptional<zod.ZodString>;
            replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
                skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                systemPrompt: zod.ZodOptional<zod.ZodString>;
                topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    systemPrompt: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
            draftChunk: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
            }, zod.z.core.$strict>>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            streamMode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                off: "off";
                partial: "partial";
                block: "block";
            }>>>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            retry: zod.ZodOptional<zod.ZodObject<{
                attempts: zod.ZodOptional<zod.ZodNumber>;
                minDelayMs: zod.ZodOptional<zod.ZodNumber>;
                maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
                jitter: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            network: zod.ZodOptional<zod.ZodObject<{
                autoSelectFamily: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            proxy: zod.ZodOptional<zod.ZodString>;
            webhookUrl: zod.ZodOptional<zod.ZodString>;
            webhookSecret: zod.ZodOptional<zod.ZodString>;
            webhookPath: zod.ZodOptional<zod.ZodString>;
            actions: zod.ZodOptional<zod.ZodObject<{
                reactions: zod.ZodOptional<zod.ZodBoolean>;
                sendMessage: zod.ZodOptional<zod.ZodBoolean>;
                deleteMessage: zod.ZodOptional<zod.ZodBoolean>;
                sticker: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                all: "all";
                off: "off";
                own: "own";
            }>>;
            reactionLevel: zod.ZodOptional<zod.ZodEnum<{
                off: "off";
                minimal: "minimal";
                ack: "ack";
                extensive: "extensive";
            }>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            linkPreview: zod.ZodOptional<zod.ZodBoolean>;
            accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodArray<zod.ZodString>, zod.ZodObject<{
                    inlineButtons: zod.ZodOptional<zod.ZodEnum<{
                        all: "all";
                        off: "off";
                        group: "group";
                        dm: "dm";
                        allowlist: "allowlist";
                    }>>;
                }, zod.z.core.$strict>]>>;
                markdown: zod.ZodOptional<zod.ZodObject<{
                    tables: zod.ZodOptional<zod.ZodEnum<{
                        code: "code";
                        off: "off";
                        bullets: "bullets";
                    }>>;
                }, zod.z.core.$strict>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                commands: zod.ZodOptional<zod.ZodObject<{
                    native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                    nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                }, zod.z.core.$strict>>;
                customCommands: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                    command: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
                    description: zod.ZodPipe<zod.ZodString, zod.ZodTransform<string, string>>;
                }, zod.z.core.$strict>>>;
                configWrites: zod.ZodOptional<zod.ZodBoolean>;
                dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    pairing: "pairing";
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                botToken: zod.ZodOptional<zod.ZodString>;
                tokenFile: zod.ZodOptional<zod.ZodString>;
                replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    systemPrompt: zod.ZodOptional<zod.ZodString>;
                    topics: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        requireMention: zod.ZodOptional<zod.ZodBoolean>;
                        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                        systemPrompt: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>>>;
                }, zod.z.core.$strict>>>>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
                dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
                dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    historyLimit: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>>>;
                textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
                chunkMode: zod.ZodOptional<zod.ZodEnum<{
                    length: "length";
                    newline: "newline";
                }>>;
                blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
                draftChunk: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
                }, zod.z.core.$strict>>;
                blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    idleMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                streamMode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    off: "off";
                    partial: "partial";
                    block: "block";
                }>>>;
                mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                retry: zod.ZodOptional<zod.ZodObject<{
                    attempts: zod.ZodOptional<zod.ZodNumber>;
                    minDelayMs: zod.ZodOptional<zod.ZodNumber>;
                    maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
                    jitter: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                network: zod.ZodOptional<zod.ZodObject<{
                    autoSelectFamily: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                proxy: zod.ZodOptional<zod.ZodString>;
                webhookUrl: zod.ZodOptional<zod.ZodString>;
                webhookSecret: zod.ZodOptional<zod.ZodString>;
                webhookPath: zod.ZodOptional<zod.ZodString>;
                actions: zod.ZodOptional<zod.ZodObject<{
                    reactions: zod.ZodOptional<zod.ZodBoolean>;
                    sendMessage: zod.ZodOptional<zod.ZodBoolean>;
                    deleteMessage: zod.ZodOptional<zod.ZodBoolean>;
                    sticker: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                    all: "all";
                    off: "off";
                    own: "own";
                }>>;
                reactionLevel: zod.ZodOptional<zod.ZodEnum<{
                    off: "off";
                    minimal: "minimal";
                    ack: "ack";
                    extensive: "extensive";
                }>>;
                heartbeat: zod.ZodOptional<zod.ZodObject<{
                    showOk: zod.ZodOptional<zod.ZodBoolean>;
                    showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                    useIndicator: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                linkPreview: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>;
        telegramAccount: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            phone: zod.ZodOptional<zod.ZodString>;
            appId: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
            appHash: zod.ZodOptional<zod.ZodString>;
            deviceModel: zod.ZodOptional<zod.ZodString>;
            systemVersion: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        discord: zod.ZodOptional<zod.ZodObject<{
            name: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            markdown: zod.ZodOptional<zod.ZodObject<{
                tables: zod.ZodOptional<zod.ZodEnum<{
                    code: "code";
                    off: "off";
                    bullets: "bullets";
                }>>;
            }, zod.z.core.$strict>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            commands: zod.ZodOptional<zod.ZodObject<{
                native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
            }, zod.z.core.$strict>>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            token: zod.ZodOptional<zod.ZodString>;
            syncProfile: zod.ZodOptional<zod.ZodBoolean>;
            profileName: zod.ZodOptional<zod.ZodString>;
            profileAvatar: zod.ZodOptional<zod.ZodString>;
            allowBots: zod.ZodOptional<zod.ZodBoolean>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            maxLinesPerMessage: zod.ZodOptional<zod.ZodNumber>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            retry: zod.ZodOptional<zod.ZodObject<{
                attempts: zod.ZodOptional<zod.ZodNumber>;
                minDelayMs: zod.ZodOptional<zod.ZodNumber>;
                maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
                jitter: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            actions: zod.ZodOptional<zod.ZodObject<{
                reactions: zod.ZodOptional<zod.ZodBoolean>;
                stickers: zod.ZodOptional<zod.ZodBoolean>;
                emojiUploads: zod.ZodOptional<zod.ZodBoolean>;
                stickerUploads: zod.ZodOptional<zod.ZodBoolean>;
                polls: zod.ZodOptional<zod.ZodBoolean>;
                permissions: zod.ZodOptional<zod.ZodBoolean>;
                messages: zod.ZodOptional<zod.ZodBoolean>;
                threads: zod.ZodOptional<zod.ZodBoolean>;
                pins: zod.ZodOptional<zod.ZodBoolean>;
                search: zod.ZodOptional<zod.ZodBoolean>;
                memberInfo: zod.ZodOptional<zod.ZodBoolean>;
                roleInfo: zod.ZodOptional<zod.ZodBoolean>;
                roles: zod.ZodOptional<zod.ZodBoolean>;
                channelInfo: zod.ZodOptional<zod.ZodBoolean>;
                voiceStatus: zod.ZodOptional<zod.ZodBoolean>;
                events: zod.ZodOptional<zod.ZodBoolean>;
                moderation: zod.ZodOptional<zod.ZodBoolean>;
                channels: zod.ZodOptional<zod.ZodBoolean>;
                presence: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            dm: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    pairing: "pairing";
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
                groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            }, zod.z.core.$strict>>;
            guilds: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                slug: zod.ZodOptional<zod.ZodString>;
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
                reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                    all: "all";
                    off: "off";
                    allowlist: "allowlist";
                    own: "own";
                }>>;
                users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodBoolean>;
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    systemPrompt: zod.ZodOptional<zod.ZodString>;
                    autoThread: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            execApprovals: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                approvers: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                agentFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                sessionFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
            intents: zod.ZodOptional<zod.ZodObject<{
                presence: zod.ZodOptional<zod.ZodBoolean>;
                guildMembers: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            pluralkit: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                token: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                markdown: zod.ZodOptional<zod.ZodObject<{
                    tables: zod.ZodOptional<zod.ZodEnum<{
                        code: "code";
                        off: "off";
                        bullets: "bullets";
                    }>>;
                }, zod.z.core.$strict>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                commands: zod.ZodOptional<zod.ZodObject<{
                    native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                    nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                }, zod.z.core.$strict>>;
                configWrites: zod.ZodOptional<zod.ZodBoolean>;
                token: zod.ZodOptional<zod.ZodString>;
                syncProfile: zod.ZodOptional<zod.ZodBoolean>;
                profileName: zod.ZodOptional<zod.ZodString>;
                profileAvatar: zod.ZodOptional<zod.ZodString>;
                allowBots: zod.ZodOptional<zod.ZodBoolean>;
                groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
                dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
                dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    historyLimit: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>>>;
                textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
                chunkMode: zod.ZodOptional<zod.ZodEnum<{
                    length: "length";
                    newline: "newline";
                }>>;
                blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
                blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    idleMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                maxLinesPerMessage: zod.ZodOptional<zod.ZodNumber>;
                mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
                retry: zod.ZodOptional<zod.ZodObject<{
                    attempts: zod.ZodOptional<zod.ZodNumber>;
                    minDelayMs: zod.ZodOptional<zod.ZodNumber>;
                    maxDelayMs: zod.ZodOptional<zod.ZodNumber>;
                    jitter: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                actions: zod.ZodOptional<zod.ZodObject<{
                    reactions: zod.ZodOptional<zod.ZodBoolean>;
                    stickers: zod.ZodOptional<zod.ZodBoolean>;
                    emojiUploads: zod.ZodOptional<zod.ZodBoolean>;
                    stickerUploads: zod.ZodOptional<zod.ZodBoolean>;
                    polls: zod.ZodOptional<zod.ZodBoolean>;
                    permissions: zod.ZodOptional<zod.ZodBoolean>;
                    messages: zod.ZodOptional<zod.ZodBoolean>;
                    threads: zod.ZodOptional<zod.ZodBoolean>;
                    pins: zod.ZodOptional<zod.ZodBoolean>;
                    search: zod.ZodOptional<zod.ZodBoolean>;
                    memberInfo: zod.ZodOptional<zod.ZodBoolean>;
                    roleInfo: zod.ZodOptional<zod.ZodBoolean>;
                    roles: zod.ZodOptional<zod.ZodBoolean>;
                    channelInfo: zod.ZodOptional<zod.ZodBoolean>;
                    voiceStatus: zod.ZodOptional<zod.ZodBoolean>;
                    events: zod.ZodOptional<zod.ZodBoolean>;
                    moderation: zod.ZodOptional<zod.ZodBoolean>;
                    channels: zod.ZodOptional<zod.ZodBoolean>;
                    presence: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                dm: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                        pairing: "pairing";
                        disabled: "disabled";
                        open: "open";
                        allowlist: "allowlist";
                    }>>>;
                    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
                    groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                }, zod.z.core.$strict>>;
                guilds: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    slug: zod.ZodOptional<zod.ZodString>;
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                    reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                        all: "all";
                        off: "off";
                        allowlist: "allowlist";
                        own: "own";
                    }>>;
                    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodBoolean>;
                        requireMention: zod.ZodOptional<zod.ZodBoolean>;
                        tools: zod.ZodOptional<zod.ZodObject<{
                            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        }, zod.z.core.$strict>>;
                        toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        }, zod.z.core.$strict>>>>;
                        skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        enabled: zod.ZodOptional<zod.ZodBoolean>;
                        users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                        systemPrompt: zod.ZodOptional<zod.ZodString>;
                        autoThread: zod.ZodOptional<zod.ZodBoolean>;
                    }, zod.z.core.$strict>>>>;
                }, zod.z.core.$strict>>>>;
                heartbeat: zod.ZodOptional<zod.ZodObject<{
                    showOk: zod.ZodOptional<zod.ZodBoolean>;
                    showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                    useIndicator: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                execApprovals: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    approvers: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    agentFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    sessionFilter: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                intents: zod.ZodOptional<zod.ZodObject<{
                    presence: zod.ZodOptional<zod.ZodBoolean>;
                    guildMembers: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                pluralkit: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    token: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>;
        discordLocal: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            clientId: zod.ZodOptional<zod.ZodString>;
            clientSecret: zod.ZodOptional<zod.ZodString>;
            scopes: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            messageChannelIds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            sendDelayMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        twitter: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            apiKey: zod.ZodOptional<zod.ZodString>;
            apiSecretKey: zod.ZodOptional<zod.ZodString>;
            accessToken: zod.ZodOptional<zod.ZodString>;
            accessTokenSecret: zod.ZodOptional<zod.ZodString>;
            postEnable: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            postImmediately: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            postIntervalMin: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            postIntervalMax: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            postIntervalVariance: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            searchEnable: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            autoRespondMentions: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            enableActionProcessing: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            timelineAlgorithm: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                latest: "latest";
                weighted: "weighted";
            }>>>;
            dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            dryRun: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            retryLimit: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            pollInterval: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            maxTweetLength: zod.ZodDefault<zod.ZodOptional<zod.ZodNumber>>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        googlechat: zod.ZodOptional<zod.ZodObject<{
            name: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            allowBots: zod.ZodOptional<zod.ZodBoolean>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allow: zod.ZodOptional<zod.ZodBoolean>;
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                systemPrompt: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
            serviceAccount: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnknown>]>>;
            serviceAccountFile: zod.ZodOptional<zod.ZodString>;
            audienceType: zod.ZodOptional<zod.ZodEnum<{
                "app-url": "app-url";
                "project-number": "project-number";
            }>>;
            audience: zod.ZodOptional<zod.ZodString>;
            webhookPath: zod.ZodOptional<zod.ZodString>;
            webhookUrl: zod.ZodOptional<zod.ZodString>;
            botUser: zod.ZodOptional<zod.ZodString>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            actions: zod.ZodOptional<zod.ZodObject<{
                reactions: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            dm: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    pairing: "pairing";
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            }, zod.z.core.$strict>>;
            typingIndicator: zod.ZodOptional<zod.ZodEnum<{
                message: "message";
                none: "none";
                reaction: "reaction";
            }>>;
            accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                configWrites: zod.ZodOptional<zod.ZodBoolean>;
                allowBots: zod.ZodOptional<zod.ZodBoolean>;
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    allow: zod.ZodOptional<zod.ZodBoolean>;
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    systemPrompt: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>>>;
                serviceAccount: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnknown>]>>;
                serviceAccountFile: zod.ZodOptional<zod.ZodString>;
                audienceType: zod.ZodOptional<zod.ZodEnum<{
                    "app-url": "app-url";
                    "project-number": "project-number";
                }>>;
                audience: zod.ZodOptional<zod.ZodString>;
                webhookPath: zod.ZodOptional<zod.ZodString>;
                webhookUrl: zod.ZodOptional<zod.ZodString>;
                botUser: zod.ZodOptional<zod.ZodString>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
                dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
                dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    historyLimit: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>>>;
                textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
                chunkMode: zod.ZodOptional<zod.ZodEnum<{
                    length: "length";
                    newline: "newline";
                }>>;
                blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
                blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    idleMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
                replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                actions: zod.ZodOptional<zod.ZodObject<{
                    reactions: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                dm: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                        pairing: "pairing";
                        disabled: "disabled";
                        open: "open";
                        allowlist: "allowlist";
                    }>>>;
                    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                }, zod.z.core.$strict>>;
                typingIndicator: zod.ZodOptional<zod.ZodEnum<{
                    message: "message";
                    none: "none";
                    reaction: "reaction";
                }>>;
            }, zod.z.core.$strict>>>>;
            defaultAccount: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        slack: zod.ZodOptional<zod.ZodObject<{
            name: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            markdown: zod.ZodOptional<zod.ZodObject<{
                tables: zod.ZodOptional<zod.ZodEnum<{
                    code: "code";
                    off: "off";
                    bullets: "bullets";
                }>>;
            }, zod.z.core.$strict>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            commands: zod.ZodOptional<zod.ZodObject<{
                native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
            }, zod.z.core.$strict>>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            botToken: zod.ZodOptional<zod.ZodString>;
            appToken: zod.ZodOptional<zod.ZodString>;
            userToken: zod.ZodOptional<zod.ZodString>;
            userTokenReadOnly: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
            allowBots: zod.ZodOptional<zod.ZodBoolean>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                all: "all";
                off: "off";
                allowlist: "allowlist";
                own: "own";
            }>>;
            reactionAllowlist: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            replyToModeByChatType: zod.ZodOptional<zod.ZodObject<{
                direct: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                group: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            }, zod.z.core.$strict>>;
            thread: zod.ZodOptional<zod.ZodObject<{
                historyScope: zod.ZodOptional<zod.ZodEnum<{
                    channel: "channel";
                    thread: "thread";
                }>>;
                inheritParent: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            actions: zod.ZodOptional<zod.ZodObject<{
                reactions: zod.ZodOptional<zod.ZodBoolean>;
                messages: zod.ZodOptional<zod.ZodBoolean>;
                pins: zod.ZodOptional<zod.ZodBoolean>;
                search: zod.ZodOptional<zod.ZodBoolean>;
                permissions: zod.ZodOptional<zod.ZodBoolean>;
                memberInfo: zod.ZodOptional<zod.ZodBoolean>;
                channelInfo: zod.ZodOptional<zod.ZodBoolean>;
                emojiList: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            slashCommand: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                name: zod.ZodOptional<zod.ZodString>;
                sessionPrefix: zod.ZodOptional<zod.ZodString>;
                ephemeral: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            dm: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    pairing: "pairing";
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
                groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
            }, zod.z.core.$strict>>;
            channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allow: zod.ZodOptional<zod.ZodBoolean>;
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
                allowBots: zod.ZodOptional<zod.ZodBoolean>;
                users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                systemPrompt: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            mode: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                http: "http";
                socket: "socket";
            }>>>;
            signingSecret: zod.ZodOptional<zod.ZodString>;
            webhookPath: zod.ZodDefault<zod.ZodOptional<zod.ZodString>>;
            accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                mode: zod.ZodOptional<zod.ZodEnum<{
                    http: "http";
                    socket: "socket";
                }>>;
                signingSecret: zod.ZodOptional<zod.ZodString>;
                webhookPath: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                markdown: zod.ZodOptional<zod.ZodObject<{
                    tables: zod.ZodOptional<zod.ZodEnum<{
                        code: "code";
                        off: "off";
                        bullets: "bullets";
                    }>>;
                }, zod.z.core.$strict>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                commands: zod.ZodOptional<zod.ZodObject<{
                    native: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                    nativeSkills: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodBoolean, zod.ZodLiteral<"auto">]>>;
                }, zod.z.core.$strict>>;
                configWrites: zod.ZodOptional<zod.ZodBoolean>;
                botToken: zod.ZodOptional<zod.ZodString>;
                appToken: zod.ZodOptional<zod.ZodString>;
                userToken: zod.ZodOptional<zod.ZodString>;
                userTokenReadOnly: zod.ZodDefault<zod.ZodOptional<zod.ZodBoolean>>;
                allowBots: zod.ZodOptional<zod.ZodBoolean>;
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
                dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
                dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    historyLimit: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>>>;
                textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
                chunkMode: zod.ZodOptional<zod.ZodEnum<{
                    length: "length";
                    newline: "newline";
                }>>;
                blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
                blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    idleMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
                reactionNotifications: zod.ZodOptional<zod.ZodEnum<{
                    all: "all";
                    off: "off";
                    allowlist: "allowlist";
                    own: "own";
                }>>;
                reactionAllowlist: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                replyToModeByChatType: zod.ZodOptional<zod.ZodObject<{
                    direct: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                    group: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                    channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                }, zod.z.core.$strict>>;
                thread: zod.ZodOptional<zod.ZodObject<{
                    historyScope: zod.ZodOptional<zod.ZodEnum<{
                        channel: "channel";
                        thread: "thread";
                    }>>;
                    inheritParent: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                actions: zod.ZodOptional<zod.ZodObject<{
                    reactions: zod.ZodOptional<zod.ZodBoolean>;
                    messages: zod.ZodOptional<zod.ZodBoolean>;
                    pins: zod.ZodOptional<zod.ZodBoolean>;
                    search: zod.ZodOptional<zod.ZodBoolean>;
                    permissions: zod.ZodOptional<zod.ZodBoolean>;
                    memberInfo: zod.ZodOptional<zod.ZodBoolean>;
                    channelInfo: zod.ZodOptional<zod.ZodBoolean>;
                    emojiList: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                slashCommand: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    name: zod.ZodOptional<zod.ZodString>;
                    sessionPrefix: zod.ZodOptional<zod.ZodString>;
                    ephemeral: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                dm: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    policy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                        pairing: "pairing";
                        disabled: "disabled";
                        open: "open";
                        allowlist: "allowlist";
                    }>>>;
                    allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    groupEnabled: zod.ZodOptional<zod.ZodBoolean>;
                    groupChannels: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    replyToMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                }, zod.z.core.$strict>>;
                channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    allow: zod.ZodOptional<zod.ZodBoolean>;
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                    allowBots: zod.ZodOptional<zod.ZodBoolean>;
                    users: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    systemPrompt: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>>>;
                heartbeat: zod.ZodOptional<zod.ZodObject<{
                    showOk: zod.ZodOptional<zod.ZodBoolean>;
                    showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                    useIndicator: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>;
        imessage: zod.ZodOptional<zod.ZodObject<{
            name: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            markdown: zod.ZodOptional<zod.ZodObject<{
                tables: zod.ZodOptional<zod.ZodEnum<{
                    code: "code";
                    off: "off";
                    bullets: "bullets";
                }>>;
            }, zod.z.core.$strict>>;
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            cliPath: zod.ZodOptional<zod.ZodString>;
            dbPath: zod.ZodOptional<zod.ZodString>;
            remoteHost: zod.ZodOptional<zod.ZodString>;
            service: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"imessage">, zod.ZodLiteral<"sms">, zod.ZodLiteral<"auto">]>>;
            region: zod.ZodOptional<zod.ZodString>;
            dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            includeAttachments: zod.ZodOptional<zod.ZodBoolean>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            accounts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                name: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                markdown: zod.ZodOptional<zod.ZodObject<{
                    tables: zod.ZodOptional<zod.ZodEnum<{
                        code: "code";
                        off: "off";
                        bullets: "bullets";
                    }>>;
                }, zod.z.core.$strict>>;
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                configWrites: zod.ZodOptional<zod.ZodBoolean>;
                cliPath: zod.ZodOptional<zod.ZodString>;
                dbPath: zod.ZodOptional<zod.ZodString>;
                remoteHost: zod.ZodOptional<zod.ZodString>;
                service: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"imessage">, zod.ZodLiteral<"sms">, zod.ZodLiteral<"auto">]>>;
                region: zod.ZodOptional<zod.ZodString>;
                dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    pairing: "pairing";
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>;
                groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                    disabled: "disabled";
                    open: "open";
                    allowlist: "allowlist";
                }>>>;
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
                dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
                dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    historyLimit: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>>>;
                includeAttachments: zod.ZodOptional<zod.ZodBoolean>;
                mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
                textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
                chunkMode: zod.ZodOptional<zod.ZodEnum<{
                    length: "length";
                    newline: "newline";
                }>>;
                blockStreaming: zod.ZodOptional<zod.ZodBoolean>;
                blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                    minChars: zod.ZodOptional<zod.ZodNumber>;
                    maxChars: zod.ZodOptional<zod.ZodNumber>;
                    idleMs: zod.ZodOptional<zod.ZodNumber>;
                }, zod.z.core.$strict>>;
                groups: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                }, zod.z.core.$strict>>>>;
                heartbeat: zod.ZodOptional<zod.ZodObject<{
                    showOk: zod.ZodOptional<zod.ZodBoolean>;
                    showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                    useIndicator: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>;
        msteams: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            markdown: zod.ZodOptional<zod.ZodObject<{
                tables: zod.ZodOptional<zod.ZodEnum<{
                    code: "code";
                    off: "off";
                    bullets: "bullets";
                }>>;
            }, zod.z.core.$strict>>;
            configWrites: zod.ZodOptional<zod.ZodBoolean>;
            appId: zod.ZodOptional<zod.ZodString>;
            appPassword: zod.ZodOptional<zod.ZodString>;
            tenantId: zod.ZodOptional<zod.ZodString>;
            webhook: zod.ZodOptional<zod.ZodObject<{
                port: zod.ZodOptional<zod.ZodNumber>;
                path: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            dmPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                pairing: "pairing";
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            allowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            groupAllowFrom: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            groupPolicy: zod.ZodDefault<zod.ZodOptional<zod.ZodEnum<{
                disabled: "disabled";
                open: "open";
                allowlist: "allowlist";
            }>>>;
            textChunkLimit: zod.ZodOptional<zod.ZodNumber>;
            chunkMode: zod.ZodOptional<zod.ZodEnum<{
                length: "length";
                newline: "newline";
            }>>;
            blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
                minChars: zod.ZodOptional<zod.ZodNumber>;
                maxChars: zod.ZodOptional<zod.ZodNumber>;
                idleMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            mediaAllowHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            mediaAuthAllowHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            historyLimit: zod.ZodOptional<zod.ZodNumber>;
            dmHistoryLimit: zod.ZodOptional<zod.ZodNumber>;
            dms: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                historyLimit: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>>>;
            replyStyle: zod.ZodOptional<zod.ZodEnum<{
                thread: "thread";
                "top-level": "top-level";
            }>>;
            teams: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                requireMention: zod.ZodOptional<zod.ZodBoolean>;
                tools: zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>;
                toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                }, zod.z.core.$strict>>>>;
                replyStyle: zod.ZodOptional<zod.ZodEnum<{
                    thread: "thread";
                    "top-level": "top-level";
                }>>;
                channels: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                    requireMention: zod.ZodOptional<zod.ZodBoolean>;
                    tools: zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>;
                    toolsBySender: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodOptional<zod.ZodObject<{
                        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                    }, zod.z.core.$strict>>>>;
                    replyStyle: zod.ZodOptional<zod.ZodEnum<{
                        thread: "thread";
                        "top-level": "top-level";
                    }>>;
                }, zod.z.core.$strict>>>>;
            }, zod.z.core.$strict>>>>;
            mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
            sharePointSiteId: zod.ZodOptional<zod.ZodString>;
            heartbeat: zod.ZodOptional<zod.ZodObject<{
                showOk: zod.ZodOptional<zod.ZodBoolean>;
                showAlerts: zod.ZodOptional<zod.ZodBoolean>;
                useIndicator: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        twitch: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            username: zod.ZodOptional<zod.ZodString>;
            clientId: zod.ZodOptional<zod.ZodString>;
            accessToken: zod.ZodOptional<zod.ZodString>;
            clientSecret: zod.ZodOptional<zod.ZodString>;
            refreshToken: zod.ZodOptional<zod.ZodString>;
            channel: zod.ZodOptional<zod.ZodString>;
            channels: zod.ZodOptional<zod.ZodString>;
            requireMention: zod.ZodOptional<zod.ZodBoolean>;
            allowedRoles: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$loose>>;
    streaming: zod.ZodOptional<zod.ZodObject<{
        activeDestination: zod.ZodOptional<zod.ZodString>;
        twitch: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            streamKey: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        youtube: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            streamKey: zod.ZodOptional<zod.ZodString>;
            rtmpUrl: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        customRtmp: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            rtmpUrl: zod.ZodOptional<zod.ZodString>;
            rtmpKey: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        pumpfun: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            streamKey: zod.ZodOptional<zod.ZodString>;
            rtmpUrl: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        x: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            streamKey: zod.ZodOptional<zod.ZodString>;
            rtmpUrl: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        rtmpSources: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            id: zod.ZodString;
            name: zod.ZodOptional<zod.ZodString>;
            rtmpUrl: zod.ZodString;
            rtmpKey: zod.ZodString;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$loose>>;
    discovery: zod.ZodOptional<zod.ZodObject<{
        wideArea: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        mdns: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodEnum<{
                full: "full";
                off: "off";
                minimal: "minimal";
            }>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    talk: zod.ZodOptional<zod.ZodObject<{
        voiceId: zod.ZodOptional<zod.ZodString>;
        voiceAliases: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        modelId: zod.ZodOptional<zod.ZodString>;
        outputFormat: zod.ZodOptional<zod.ZodString>;
        apiKey: zod.ZodOptional<zod.ZodString>;
        interruptOnSpeech: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    gateway: zod.ZodOptional<zod.ZodObject<{
        port: zod.ZodOptional<zod.ZodNumber>;
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"local">, zod.ZodLiteral<"remote">]>>;
        bind: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"auto">, zod.ZodLiteral<"lan">, zod.ZodLiteral<"loopback">, zod.ZodLiteral<"custom">, zod.ZodLiteral<"tailnet">]>>;
        controlUi: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            basePath: zod.ZodOptional<zod.ZodString>;
            root: zod.ZodOptional<zod.ZodString>;
            allowedOrigins: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            allowInsecureAuth: zod.ZodOptional<zod.ZodBoolean>;
            dangerouslyDisableDeviceAuth: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        auth: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"token">, zod.ZodLiteral<"password">]>>;
            token: zod.ZodOptional<zod.ZodString>;
            password: zod.ZodOptional<zod.ZodString>;
            allowTailscale: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        trustedProxies: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        tailscale: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"serve">, zod.ZodLiteral<"funnel">]>>;
            resetOnExit: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        remote: zod.ZodOptional<zod.ZodObject<{
            url: zod.ZodOptional<zod.ZodString>;
            transport: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"ssh">, zod.ZodLiteral<"direct">]>>;
            token: zod.ZodOptional<zod.ZodString>;
            password: zod.ZodOptional<zod.ZodString>;
            tlsFingerprint: zod.ZodOptional<zod.ZodString>;
            sshTarget: zod.ZodOptional<zod.ZodString>;
            sshIdentity: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        reload: zod.ZodOptional<zod.ZodObject<{
            mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"restart">, zod.ZodLiteral<"hot">, zod.ZodLiteral<"hybrid">]>>;
            debounceMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        tls: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            autoGenerate: zod.ZodOptional<zod.ZodBoolean>;
            certPath: zod.ZodOptional<zod.ZodString>;
            keyPath: zod.ZodOptional<zod.ZodString>;
            caPath: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strip>>;
        http: zod.ZodOptional<zod.ZodObject<{
            endpoints: zod.ZodOptional<zod.ZodObject<{
                chatCompletions: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                responses: zod.ZodOptional<zod.ZodObject<{
                    enabled: zod.ZodOptional<zod.ZodBoolean>;
                    maxBodyBytes: zod.ZodOptional<zod.ZodNumber>;
                    files: zod.ZodOptional<zod.ZodObject<{
                        allowUrl: zod.ZodOptional<zod.ZodBoolean>;
                        allowedMimes: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        maxBytes: zod.ZodOptional<zod.ZodNumber>;
                        maxChars: zod.ZodOptional<zod.ZodNumber>;
                        maxRedirects: zod.ZodOptional<zod.ZodNumber>;
                        timeoutMs: zod.ZodOptional<zod.ZodNumber>;
                        pdf: zod.ZodOptional<zod.ZodObject<{
                            maxPages: zod.ZodOptional<zod.ZodNumber>;
                            maxPixels: zod.ZodOptional<zod.ZodNumber>;
                            minTextChars: zod.ZodOptional<zod.ZodNumber>;
                        }, zod.z.core.$strict>>;
                    }, zod.z.core.$strict>>;
                    images: zod.ZodOptional<zod.ZodObject<{
                        allowUrl: zod.ZodOptional<zod.ZodBoolean>;
                        allowedMimes: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                        maxBytes: zod.ZodOptional<zod.ZodNumber>;
                        maxRedirects: zod.ZodOptional<zod.ZodNumber>;
                        timeoutMs: zod.ZodOptional<zod.ZodNumber>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        nodes: zod.ZodOptional<zod.ZodObject<{
            browser: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"auto">, zod.ZodLiteral<"manual">, zod.ZodLiteral<"off">]>>;
                node: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            allowCommands: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            denyCommands: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    memory: zod.ZodOptional<zod.ZodObject<{
        backend: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"builtin">, zod.ZodLiteral<"qmd">]>>;
        citations: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"auto">, zod.ZodLiteral<"on">, zod.ZodLiteral<"off">]>>;
        qmd: zod.ZodOptional<zod.ZodObject<{
            command: zod.ZodOptional<zod.ZodString>;
            includeDefaultMemory: zod.ZodOptional<zod.ZodBoolean>;
            paths: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                path: zod.ZodString;
                name: zod.ZodOptional<zod.ZodString>;
                pattern: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>;
            sessions: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                exportDir: zod.ZodOptional<zod.ZodString>;
                retentionDays: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            update: zod.ZodOptional<zod.ZodObject<{
                interval: zod.ZodOptional<zod.ZodString>;
                debounceMs: zod.ZodOptional<zod.ZodNumber>;
                onBoot: zod.ZodOptional<zod.ZodBoolean>;
                embedInterval: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
            limits: zod.ZodOptional<zod.ZodObject<{
                timeoutMs: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
            scope: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
                default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                    action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                    match: zod.ZodOptional<zod.ZodObject<{
                        channel: zod.ZodOptional<zod.ZodString>;
                        chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                        keyPrefix: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    roles: zod.ZodOptional<zod.ZodObject<{
        connectorAdmins: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodString>>>;
    }, zod.z.core.$strict>>;
    embedding: zod.ZodOptional<zod.ZodObject<{
        model: zod.ZodOptional<zod.ZodString>;
        modelRepo: zod.ZodOptional<zod.ZodString>;
        dimensions: zod.ZodOptional<zod.ZodNumber>;
        contextSize: zod.ZodOptional<zod.ZodNumber>;
        gpuLayers: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"auto">, zod.ZodLiteral<"max">, zod.ZodNumber]>>;
        idleTimeoutMinutes: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    skills: zod.ZodOptional<zod.ZodObject<{
        allowBundled: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        denyBundled: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        load: zod.ZodOptional<zod.ZodObject<{
            extraDirs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            watch: zod.ZodOptional<zod.ZodBoolean>;
            watchDebounceMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        install: zod.ZodOptional<zod.ZodObject<{
            preferBrew: zod.ZodOptional<zod.ZodBoolean>;
            nodeManager: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"npm">, zod.ZodLiteral<"yarn">, zod.ZodLiteral<"bun">]>>;
        }, zod.z.core.$strict>>;
        entries: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            apiKey: zod.ZodOptional<zod.ZodString>;
            env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            config: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    plugins: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        load: zod.ZodOptional<zod.ZodObject<{
            paths: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        slots: zod.ZodOptional<zod.ZodObject<{
            memory: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        entries: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            config: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
        }, zod.z.core.$strict>>>;
        installs: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            source: zod.ZodUnion<readonly [zod.ZodLiteral<"npm">, zod.ZodLiteral<"archive">, zod.ZodLiteral<"path">]>;
            spec: zod.ZodOptional<zod.ZodString>;
            sourcePath: zod.ZodOptional<zod.ZodString>;
            installPath: zod.ZodOptional<zod.ZodString>;
            version: zod.ZodOptional<zod.ZodString>;
            installedAt: zod.ZodOptional<zod.ZodString>;
            hooks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
