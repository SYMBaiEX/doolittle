/**
 * Zod schema for the agent Character config: name/username/bio/system text,
 * adjective and topic lists, chat/post style arrays, and message/post examples.
 * Every object is strict, so unknown keys are rejected at parse time.
 */
import * as zod from "zod";
export declare const CharacterSchema: zod.ZodObject<{
    name: zod.ZodOptional<zod.ZodString>;
    username: zod.ZodOptional<zod.ZodString>;
    bio: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodArray<zod.ZodString>]>>;
    system: zod.ZodOptional<zod.ZodString>;
    adjectives: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    topics: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    style: zod.ZodOptional<zod.ZodObject<{
        all: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        chat: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        post: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    messageExamples: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
        examples: zod.ZodArray<zod.ZodObject<{
            name: zod.ZodString;
            content: zod.ZodObject<{
                text: zod.ZodString;
                actions: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>>;
    postExamples: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
}, zod.z.core.$strict>;
