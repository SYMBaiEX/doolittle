/**
 * Zod schemas for the workspace hooks config surface. Validates external hook
 * mappings (path/source matchers that wake the agent or dispatch a message,
 * with delivery channel, message/text templating, and an optional transform
 * module), the internal hook handler/entry registry and install records, and
 * the Gmail push-hook config (label/topic/subscription plus local or tailscale
 * serve/funnel exposure). `allowUnsafeExternalContent` gates whether hook
 * payloads are treated as trusted input.
 */
import * as zod from "zod";
export declare const HookMappingSchema: zod.ZodOptional<zod.ZodObject<{
    id: zod.ZodOptional<zod.ZodString>;
    match: zod.ZodOptional<zod.ZodObject<{
        path: zod.ZodOptional<zod.ZodString>;
        source: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strip>>;
    action: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"wake">, zod.ZodLiteral<"agent">]>>;
    wakeMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"now">, zod.ZodLiteral<"next-heartbeat">]>>;
    name: zod.ZodOptional<zod.ZodString>;
    sessionKey: zod.ZodOptional<zod.ZodString>;
    messageTemplate: zod.ZodOptional<zod.ZodString>;
    textTemplate: zod.ZodOptional<zod.ZodString>;
    deliver: zod.ZodOptional<zod.ZodBoolean>;
    allowUnsafeExternalContent: zod.ZodOptional<zod.ZodBoolean>;
    channel: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"last">, zod.ZodLiteral<"whatsapp">, zod.ZodLiteral<"telegram">, zod.ZodLiteral<"discord">, zod.ZodLiteral<"googlechat">, zod.ZodLiteral<"slack">, zod.ZodLiteral<"imessage">, zod.ZodLiteral<"msteams">]>>;
    to: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodString>;
    thinking: zod.ZodOptional<zod.ZodString>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    transform: zod.ZodOptional<zod.ZodObject<{
        module: zod.ZodString;
        export: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const InstallRecordSchema: zod.ZodObject<{
    source: zod.ZodUnion<readonly [zod.ZodLiteral<"npm">, zod.ZodLiteral<"archive">, zod.ZodLiteral<"path">]>;
    spec: zod.ZodOptional<zod.ZodString>;
    sourcePath: zod.ZodOptional<zod.ZodString>;
    installPath: zod.ZodOptional<zod.ZodString>;
    version: zod.ZodOptional<zod.ZodString>;
    installedAt: zod.ZodOptional<zod.ZodString>;
    hooks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
}, zod.z.core.$strict>;
export declare const InternalHooksSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    entries: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    }, zod.z.core.$strict>>>;
    load: zod.ZodOptional<zod.ZodObject<{
        extraDirs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    installs: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        source: zod.ZodUnion<readonly [zod.ZodLiteral<"npm">, zod.ZodLiteral<"archive">, zod.ZodLiteral<"path">]>;
        spec: zod.ZodOptional<zod.ZodString>;
        sourcePath: zod.ZodOptional<zod.ZodString>;
        installPath: zod.ZodOptional<zod.ZodString>;
        version: zod.ZodOptional<zod.ZodString>;
        installedAt: zod.ZodOptional<zod.ZodString>;
        hooks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const HooksGmailSchema: zod.ZodOptional<zod.ZodObject<{
    account: zod.ZodOptional<zod.ZodString>;
    label: zod.ZodOptional<zod.ZodString>;
    topic: zod.ZodOptional<zod.ZodString>;
    subscription: zod.ZodOptional<zod.ZodString>;
    pushToken: zod.ZodOptional<zod.ZodString>;
    hookUrl: zod.ZodOptional<zod.ZodString>;
    includeBody: zod.ZodOptional<zod.ZodBoolean>;
    maxBytes: zod.ZodOptional<zod.ZodNumber>;
    renewEveryMinutes: zod.ZodOptional<zod.ZodNumber>;
    allowUnsafeExternalContent: zod.ZodOptional<zod.ZodBoolean>;
    serve: zod.ZodOptional<zod.ZodObject<{
        bind: zod.ZodOptional<zod.ZodString>;
        port: zod.ZodOptional<zod.ZodNumber>;
        path: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    tailscale: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"serve">, zod.ZodLiteral<"funnel">]>>;
        path: zod.ZodOptional<zod.ZodString>;
        target: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    model: zod.ZodOptional<zod.ZodString>;
    thinking: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"minimal">, zod.ZodLiteral<"low">, zod.ZodLiteral<"medium">, zod.ZodLiteral<"high">]>>;
}, zod.z.core.$strict>>;
