export { isProcessOnlyEnvKey, PROCESS_ONLY_ENV_KEY_PREFIXES, } from "@elizaos/core";
export declare const BLOCKED_ENV_KEYS: Set<string>;
/**
 * Families whose whole namespace is dangerous, so no exact-key list can cover
 * them. `BASH_FUNC_*` is the Shellshock function-export prefix; the
 * package-manager and container families redirect registries, install hooks,
 * and runtimes for anything spawned afterwards. The core spawn policy is the
 * single source: it guards a caller-supplied child environment, while this
 * boundary guards config and API writes, which reach `process.env` and are
 * then inherited by every spawn site that passes no explicit env — so both
 * paths need the same families.
 */
export declare const BLOCKED_ENV_KEY_PREFIXES: readonly string[];
/**
 * The single predicate every config/API env gate should use. `BLOCKED_ENV_KEYS`
 * remains exported for callers that need the raw set, but membership alone
 * misses the prefix families above, and indexed families like
 * {@code GIT_CONFIG_KEY_0} are caught here at config write time, not just at
 * the later spawn boundary.
 */
export declare function isBlockedEnvKey(key: string): boolean;
