export declare function resolveWorkspaceRootsForDiscovery(options?: {
    readonly moduleDir: string;
    readonly cwd: string;
    readonly envRoot?: string;
}): string[];
