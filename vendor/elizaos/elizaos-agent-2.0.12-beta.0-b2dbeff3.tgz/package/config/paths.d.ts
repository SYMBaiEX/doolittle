/**
 * Create a state directory (and parents) owner-only, then heal the mode on
 * directories left behind by older installs. The state tree holds the PGlite
 * memory DB, `config.env`, and `secret-salt` — all credential-bearing — so it
 * must never be group/other-readable. `mkdir` only applies `mode` to newly
 * created directories, hence the explicit chmod for the pre-existing case.
 */
export declare function ensurePrivateDir(dir: string): void;
export declare function resolveConfigPath(env?: NodeJS.ProcessEnv, stateDirPath?: string): string;
/**
 * Directory for per-provider model cache files.
 * Each provider gets its own file: `<state-dir>/models/<providerId>.json`
 */
export declare function resolveModelsCacheDir(env?: NodeJS.ProcessEnv, stateDirPath?: string): string;
/**
 * Canonical path to the persisted Steward credentials file.
 * Honors the canonical state-dir resolver.
 */
export declare function resolveStewardCredentialsPath(env?: NodeJS.ProcessEnv, stateDirPath?: string): string;
export declare function resolveDefaultSessionStorePath(agentId?: string): string;
