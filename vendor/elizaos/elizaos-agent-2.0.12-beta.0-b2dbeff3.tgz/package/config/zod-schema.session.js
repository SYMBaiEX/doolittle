/**
 * Zod schemas for session and messaging-behavior config. `SessionSchema` shapes
 * conversation session scoping (per-sender vs global, DM scope granularity),
 * reset triggers and schedules (daily/idle, per chat-type, per channel), typing
 * behavior, send policy, and agent-to-agent ping-pong bounds. `MessagesSchema`
 * covers message/response prefixes, group chat, the inbound queue and debounce,
 * ack reactions, and TTS.
 */
import * as zod from "zod";
import { GroupChatSchema, InboundDebounceSchema, MessagePolicySchema, QueueSchema, TtsConfigSchema, } from "./zod-schema.core.js";
const z = zod.z ?? zod;
const SessionResetConfigSchema = z
    .object({
    mode: z.union([z.literal("daily"), z.literal("idle")]).optional(),
    atHour: z.number().int().min(0).max(23).optional(),
    idleMinutes: z.number().int().positive().optional(),
})
    .strict();
export const SessionSendPolicySchema = MessagePolicySchema;
export const SessionSchema = z
    .object({
    scope: z.union([z.literal("per-sender"), z.literal("global")]).optional(),
    dmScope: z
        .union([
        z.literal("main"),
        z.literal("per-peer"),
        z.literal("per-channel-peer"),
        z.literal("per-account-channel-peer"),
    ])
        .optional(),
    identityLinks: z.record(z.string(), z.array(z.string())).optional(),
    resetTriggers: z.array(z.string()).optional(),
    idleMinutes: z.number().int().positive().optional(),
    reset: SessionResetConfigSchema.optional(),
    resetByType: z
        .object({
        dm: SessionResetConfigSchema.optional(),
        group: SessionResetConfigSchema.optional(),
        thread: SessionResetConfigSchema.optional(),
    })
        .strict()
        .optional(),
    resetByChannel: z.record(z.string(), SessionResetConfigSchema).optional(),
    store: z.string().optional(),
    typingIntervalSeconds: z.number().int().positive().optional(),
    typingMode: z
        .union([
        z.literal("never"),
        z.literal("instant"),
        z.literal("thinking"),
        z.literal("message"),
    ])
        .optional(),
    mainKey: z.string().optional(),
    sendPolicy: SessionSendPolicySchema.optional(),
    agentToAgent: z
        .object({
        maxPingPongTurns: z.number().int().min(0).max(5).optional(),
    })
        .strict()
        .optional(),
})
    .strict()
    .optional();
export const MessagesSchema = z
    .object({
    messagePrefix: z.string().optional(),
    responsePrefix: z.string().optional(),
    groupChat: GroupChatSchema,
    queue: QueueSchema,
    inbound: InboundDebounceSchema,
    ackReaction: z.string().optional(),
    ackReactionScope: z
        .enum(["group-mentions", "group-all", "direct", "all"])
        .optional(),
    removeAckAfterReply: z.boolean().optional(),
    tts: TtsConfigSchema,
})
    .strict()
    .optional();
