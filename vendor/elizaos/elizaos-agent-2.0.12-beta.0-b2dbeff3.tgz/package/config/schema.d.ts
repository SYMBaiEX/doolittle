/**
 * Builds the config UI-schema response served to the settings surface. Emits a
 * draft-07 JSON Schema from the zod ElizaSchema and pairs it with UI hints —
 * per-field labels, help text, placeholders, and group labels/ordering. Marks
 * sensitive fields (via the shared isSensitiveConfigKey predicate) so the client
 * masks them, and merges plugin- and connector-supplied config schemas and UI
 * hints (including heartbeat-target help that lists the known connectors) onto
 * the base. The base schema/hints are computed once and cached; buildConfigSchema
 * layers any plugin/connector metadata on top per call.
 */
import { CONNECTOR_IDS } from "@elizaos/host/protocol";
import { ElizaSchema } from "./zod-schema.js";
export { CONNECTOR_IDS };
export type ShowIfCondition = {
    field: string;
    op: "eq" | "neq" | "in" | "truthy" | "falsy";
    value?: unknown;
};
export type ConfigUiHint = {
    label?: string;
    help?: string;
    group?: string;
    order?: number;
    advanced?: boolean;
    sensitive?: boolean;
    placeholder?: string;
    itemTemplate?: unknown;
    /** Explicit field type override (must match a catalog field name). */
    type?: string;
    /** Icon name for the field label. */
    icon?: string;
    /** Whether the field is read-only. */
    readonly?: boolean;
    /** Hide this field from the UI entirely. */
    hidden?: boolean;
    /** Layout width hint. */
    width?: "full" | "half" | "third";
    /** Regex pattern for string validation. */
    pattern?: string;
    /** Error message when pattern doesn't match. */
    patternError?: string;
    /** Legacy conditional visibility. */
    showIf?: ShowIfCondition;
    /**
     * Show only after every listed key is present (draft non-empty or
     * persisted/`isSet`, including masked secrets).
     */
    requires?: string | string[];
    /** Show when any one of the listed keys is present. */
    requiresAny?: string | string[];
    /** Rich visibility condition (shared ConfigUiHint shape). */
    visible?: unknown;
    /** Enhanced options for select/radio/multiselect fields. */
    options?: Array<{
        value: string;
        label: string;
        description?: string;
        icon?: string;
        disabled?: boolean;
    }>;
    /** Minimum value (for number fields). */
    min?: number;
    /** Maximum value (for number fields). */
    max?: number;
    /** Step increment (for number fields). */
    step?: number;
    /** Display unit label (e.g., "ms", "tokens", "%"). */
    unit?: string;
    /** Schema for array item fields. */
    itemSchema?: ConfigUiHint;
    /** Minimum items (for array fields). */
    minItems?: number;
    /** Maximum items (for array fields). */
    maxItems?: number;
    /** Plugin-provided custom React component name. */
    component?: string;
    /** Render a toggle that hides this backing field when enabled. */
    modeToggle?: {
        kind: "mode-toggle-with-hidden-field";
        enabledLabel: string;
        disabledLabel: string;
        enabledHelp?: string;
        disabledHelp?: string;
        hiddenValue?: string;
        restoreValue?: string;
    };
};
export type ConfigUiHints = Record<string, ConfigUiHint>;
export type ConfigSchema = ReturnType<typeof ElizaSchema.toJSONSchema>;
type JsonSchemaNode = Record<string, unknown>;
export type ConfigSchemaResponse = {
    schema: ConfigSchema;
    uiHints: ConfigUiHints;
    version: string;
    generatedAt: string;
};
export type PluginUiMetadata = {
    id: string;
    name?: string;
    description?: string;
    configUiHints?: Record<string, Pick<ConfigUiHint, "label" | "help" | "advanced" | "sensitive" | "placeholder" | "type" | "icon" | "readonly" | "hidden" | "width" | "pattern" | "patternError" | "showIf" | "requires" | "requiresAny" | "visible" | "options" | "min" | "max" | "step" | "unit" | "modeToggle">>;
    configSchema?: JsonSchemaNode;
};
export type ConnectorUiMetadata = {
    id: string;
    label?: string;
    description?: string;
    configSchema?: JsonSchemaNode;
    configUiHints?: Record<string, ConfigUiHint>;
};
export declare function buildConfigSchema(params?: {
    plugins?: PluginUiMetadata[];
    connectors?: ConnectorUiMetadata[];
}): ConfigSchemaResponse;
