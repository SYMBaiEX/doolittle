/**
 * Projects the eliza config's env and connector settings into flat
 * environment-variable records for plugins. CONNECTOR_ENV_MAP maps each
 * connector's config fields to the env keys its plugin expects;
 * collectConfigEnvVars flattens config.env (nested vars + top-level) and
 * collectConnectorEnvVars walks the configured connectors, normalizing
 * string/number/boolean/array values and mirroring compatibility aliases for
 * Discord and the Blooio-backed iMessage transport.
 * Both drop any key rejected by isBlockedEnvKey (the secret denylist plus the
 * dangerous prefix families).
 */
import type { ElizaConfig } from "@elizaos/host/protocol";
export declare function writeConfigEnvValue(key: string, value: string, env?: NodeJS.ProcessEnv): void;
export declare function clearConfigEnvValue(key: string, env?: NodeJS.ProcessEnv): void;
/**
 * Maps connector config fields to the environment variables expected by
 * elizaOS plugins. Keep this aligned with runtime/eliza.ts.
 */
export declare const CONNECTOR_ENV_MAP: Readonly<Record<string, Readonly<Record<string, string>>>>;
export declare function collectConfigEnvVars(cfg?: ElizaConfig): Record<string, string>;
/** The saved connector settings boot reads: `connectors`, else legacy `channels`. */
export declare function resolveConnectorConfigs(cfg?: ElizaConfig): Record<string, unknown> | undefined;
export declare function collectConnectorEnvVars(cfg?: ElizaConfig): Record<string, string>;
