/**
 * Zod schemas validating the per-agent and agent-defaults slice of the eliza
 * config: heartbeat scheduling with active-hours windows, sandbox execution
 * (docker/browser/prune), tool profiles and allow/deny policies (with the
 * conflicting-allowlist refinement), semantic memory search, media/link
 * understanding tools, owner contacts, escalation, and inbox triage. Composes
 * the shared building blocks from zod-schema.core.ts into `AgentEntrySchema`
 * (one configured agent) and `AgentDefaultsSchema` (fallbacks applied to every
 * agent). `.strict()` throughout, so unknown keys surface as validation errors.
 */
import * as zod from "zod";
export declare const HeartbeatSchema: zod.ZodOptional<zod.ZodObject<{
    every: zod.ZodOptional<zod.ZodString>;
    activeHours: zod.ZodOptional<zod.ZodObject<{
        start: zod.ZodOptional<zod.ZodString>;
        end: zod.ZodOptional<zod.ZodString>;
        timezone: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    model: zod.ZodOptional<zod.ZodString>;
    session: zod.ZodOptional<zod.ZodString>;
    includeReasoning: zod.ZodOptional<zod.ZodBoolean>;
    target: zod.ZodOptional<zod.ZodString>;
    to: zod.ZodOptional<zod.ZodString>;
    prompt: zod.ZodOptional<zod.ZodString>;
    ackMaxChars: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const SandboxDockerSchema: zod.ZodOptional<zod.ZodObject<{
    image: zod.ZodOptional<zod.ZodString>;
    containerPrefix: zod.ZodOptional<zod.ZodString>;
    workdir: zod.ZodOptional<zod.ZodString>;
    readOnlyRoot: zod.ZodOptional<zod.ZodBoolean>;
    tmpfs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    network: zod.ZodOptional<zod.ZodString>;
    user: zod.ZodOptional<zod.ZodString>;
    capDrop: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
    setupCommand: zod.ZodOptional<zod.ZodString>;
    pidsLimit: zod.ZodOptional<zod.ZodNumber>;
    memory: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
    memorySwap: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
    cpus: zod.ZodOptional<zod.ZodNumber>;
    ulimits: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodObject<{
        soft: zod.ZodOptional<zod.ZodNumber>;
        hard: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>]>>>;
    seccompProfile: zod.ZodOptional<zod.ZodString>;
    apparmorProfile: zod.ZodOptional<zod.ZodString>;
    dns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    extraHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    binds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
}, zod.z.core.$strict>>;
export declare const SandboxBrowserSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    image: zod.ZodOptional<zod.ZodString>;
    containerPrefix: zod.ZodOptional<zod.ZodString>;
    cdpPort: zod.ZodOptional<zod.ZodNumber>;
    vncPort: zod.ZodOptional<zod.ZodNumber>;
    noVncPort: zod.ZodOptional<zod.ZodNumber>;
    headless: zod.ZodOptional<zod.ZodBoolean>;
    enableNoVnc: zod.ZodOptional<zod.ZodBoolean>;
    allowHostControl: zod.ZodOptional<zod.ZodBoolean>;
    autoStart: zod.ZodOptional<zod.ZodBoolean>;
    autoStartTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const SandboxPruneSchema: zod.ZodOptional<zod.ZodObject<{
    idleHours: zod.ZodOptional<zod.ZodNumber>;
    maxAgeDays: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const ToolsWebSearchSchema: zod.ZodOptional<zod.ZodObject<{
    maxResults: zod.ZodOptional<zod.ZodNumber>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const ToolsWebFetchSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
    maxRedirects: zod.ZodOptional<zod.ZodNumber>;
    userAgent: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>;
export declare const ToolsWebSchema: zod.ZodOptional<zod.ZodObject<{
    search: zod.ZodOptional<zod.ZodObject<{
        maxResults: zod.ZodOptional<zod.ZodNumber>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    fetch: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
        maxRedirects: zod.ZodOptional<zod.ZodNumber>;
        userAgent: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
/**
 * Top-level cross-tool cache config. Drives the two-tier `ToolCallCache`
 * (in-memory LRU + on-disk persistent under <stateDir>/tool-cache).
 *
 * Per-tool TTL overrides live under `perTool` keyed by tool name; values
 * are minutes for parity with the existing web search/fetch knobs. The
 * `cacheTtlMinutes` fields on `tools.web.search` / `tools.web.fetch` are
 * preserved for back-compat and feed into the same cache.
 */
export declare const ToolsCacheSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    memoryCapacity: zod.ZodOptional<zod.ZodNumber>;
    diskRoot: zod.ZodOptional<zod.ZodString>;
    perTool: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        ttlMinutes: zod.ZodOptional<zod.ZodNumber>;
        version: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>;
}, zod.z.core.$strict>>;
export declare const ToolProfileSchema: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
export declare const ToolPolicySchema: zod.ZodOptional<zod.ZodObject<{
    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
}, zod.z.core.$strict>>;
export declare const ToolPolicyWithProfileSchema: zod.ZodObject<{
    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
}, zod.z.core.$strict>;
export declare const ElevatedAllowFromSchema: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>>;
export declare const AgentSandboxSchema: zod.ZodOptional<zod.ZodObject<{
    mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"non-main">, zod.ZodLiteral<"all">]>>;
    workspaceAccess: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"none">, zod.ZodLiteral<"ro">, zod.ZodLiteral<"rw">]>>;
    sessionToolsVisibility: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"spawned">, zod.ZodLiteral<"all">]>>;
    scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"session">, zod.ZodLiteral<"agent">, zod.ZodLiteral<"shared">]>>;
    perSession: zod.ZodOptional<zod.ZodBoolean>;
    workspaceRoot: zod.ZodOptional<zod.ZodString>;
    docker: zod.ZodOptional<zod.ZodObject<{
        image: zod.ZodOptional<zod.ZodString>;
        containerPrefix: zod.ZodOptional<zod.ZodString>;
        workdir: zod.ZodOptional<zod.ZodString>;
        readOnlyRoot: zod.ZodOptional<zod.ZodBoolean>;
        tmpfs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        network: zod.ZodOptional<zod.ZodString>;
        user: zod.ZodOptional<zod.ZodString>;
        capDrop: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        setupCommand: zod.ZodOptional<zod.ZodString>;
        pidsLimit: zod.ZodOptional<zod.ZodNumber>;
        memory: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
        memorySwap: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
        cpus: zod.ZodOptional<zod.ZodNumber>;
        ulimits: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodObject<{
            soft: zod.ZodOptional<zod.ZodNumber>;
            hard: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>]>>>;
        seccompProfile: zod.ZodOptional<zod.ZodString>;
        apparmorProfile: zod.ZodOptional<zod.ZodString>;
        dns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        extraHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        binds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    browser: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        image: zod.ZodOptional<zod.ZodString>;
        containerPrefix: zod.ZodOptional<zod.ZodString>;
        cdpPort: zod.ZodOptional<zod.ZodNumber>;
        vncPort: zod.ZodOptional<zod.ZodNumber>;
        noVncPort: zod.ZodOptional<zod.ZodNumber>;
        headless: zod.ZodOptional<zod.ZodBoolean>;
        enableNoVnc: zod.ZodOptional<zod.ZodBoolean>;
        allowHostControl: zod.ZodOptional<zod.ZodBoolean>;
        autoStart: zod.ZodOptional<zod.ZodBoolean>;
        autoStartTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    prune: zod.ZodOptional<zod.ZodObject<{
        idleHours: zod.ZodOptional<zod.ZodNumber>;
        maxAgeDays: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const AgentToolsSchema: zod.ZodOptional<zod.ZodObject<{
    profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    byProvider: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
    }, zod.z.core.$strict>>>;
    elevated: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>>;
    }, zod.z.core.$strict>>;
    exec: zod.ZodOptional<zod.ZodObject<{
        host: zod.ZodOptional<zod.ZodEnum<{
            sandbox: "sandbox";
            gateway: "gateway";
            node: "node";
        }>>;
        security: zod.ZodOptional<zod.ZodEnum<{
            deny: "deny";
            full: "full";
            allowlist: "allowlist";
        }>>;
        ask: zod.ZodOptional<zod.ZodEnum<{
            always: "always";
            off: "off";
            "on-miss": "on-miss";
        }>>;
        node: zod.ZodOptional<zod.ZodString>;
        pathPrepend: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        safeBins: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        backgroundMs: zod.ZodOptional<zod.ZodNumber>;
        timeoutSec: zod.ZodOptional<zod.ZodNumber>;
        approvalRunningNoticeMs: zod.ZodOptional<zod.ZodNumber>;
        cleanupMs: zod.ZodOptional<zod.ZodNumber>;
        notifyOnExit: zod.ZodOptional<zod.ZodBoolean>;
        applyPatch: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowModels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    sandbox: zod.ZodOptional<zod.ZodObject<{
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const MemorySearchSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    sources: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"memory">, zod.ZodLiteral<"sessions">]>>>;
    extraPaths: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    experimental: zod.ZodOptional<zod.ZodObject<{
        sessionMemory: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>;
    provider: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"local">, zod.ZodLiteral<"gemini">]>>;
    remote: zod.ZodOptional<zod.ZodObject<{
        baseUrl: zod.ZodOptional<zod.ZodString>;
        apiKey: zod.ZodOptional<zod.ZodString>;
        headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        batch: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            wait: zod.ZodOptional<zod.ZodBoolean>;
            concurrency: zod.ZodOptional<zod.ZodNumber>;
            pollIntervalMs: zod.ZodOptional<zod.ZodNumber>;
            timeoutMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    fallback: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"gemini">, zod.ZodLiteral<"local">, zod.ZodLiteral<"none">]>>;
    model: zod.ZodOptional<zod.ZodString>;
    local: zod.ZodOptional<zod.ZodObject<{
        modelPath: zod.ZodOptional<zod.ZodString>;
        modelCacheDir: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    store: zod.ZodOptional<zod.ZodObject<{
        driver: zod.ZodOptional<zod.ZodLiteral<"sqlite">>;
        path: zod.ZodOptional<zod.ZodString>;
        vector: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            extensionPath: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    chunking: zod.ZodOptional<zod.ZodObject<{
        tokens: zod.ZodOptional<zod.ZodNumber>;
        overlap: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    sync: zod.ZodOptional<zod.ZodObject<{
        onSessionStart: zod.ZodOptional<zod.ZodBoolean>;
        onSearch: zod.ZodOptional<zod.ZodBoolean>;
        watch: zod.ZodOptional<zod.ZodBoolean>;
        watchDebounceMs: zod.ZodOptional<zod.ZodNumber>;
        intervalMinutes: zod.ZodOptional<zod.ZodNumber>;
        sessions: zod.ZodOptional<zod.ZodObject<{
            deltaBytes: zod.ZodOptional<zod.ZodNumber>;
            deltaMessages: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    query: zod.ZodOptional<zod.ZodObject<{
        maxResults: zod.ZodOptional<zod.ZodNumber>;
        minScore: zod.ZodOptional<zod.ZodNumber>;
        hybrid: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            vectorWeight: zod.ZodOptional<zod.ZodNumber>;
            textWeight: zod.ZodOptional<zod.ZodNumber>;
            candidateMultiplier: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    cache: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        maxEntries: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const AgentModelSchema: zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
    primary: zod.ZodOptional<zod.ZodString>;
    fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
}, zod.z.core.$strict>]>;
export declare const AgentEntrySchema: zod.ZodObject<{
    id: zod.ZodString;
    default: zod.ZodOptional<zod.ZodBoolean>;
    name: zod.ZodOptional<zod.ZodString>;
    identityName: zod.ZodOptional<zod.ZodString>;
    workspace: zod.ZodOptional<zod.ZodString>;
    agentDir: zod.ZodOptional<zod.ZodString>;
    model: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
        primary: zod.ZodOptional<zod.ZodString>;
        fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>]>>;
    skills: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    memorySearch: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        sources: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"memory">, zod.ZodLiteral<"sessions">]>>>;
        extraPaths: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        experimental: zod.ZodOptional<zod.ZodObject<{
            sessionMemory: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        provider: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"local">, zod.ZodLiteral<"gemini">]>>;
        remote: zod.ZodOptional<zod.ZodObject<{
            baseUrl: zod.ZodOptional<zod.ZodString>;
            apiKey: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            batch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                wait: zod.ZodOptional<zod.ZodBoolean>;
                concurrency: zod.ZodOptional<zod.ZodNumber>;
                pollIntervalMs: zod.ZodOptional<zod.ZodNumber>;
                timeoutMinutes: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        fallback: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"gemini">, zod.ZodLiteral<"local">, zod.ZodLiteral<"none">]>>;
        model: zod.ZodOptional<zod.ZodString>;
        local: zod.ZodOptional<zod.ZodObject<{
            modelPath: zod.ZodOptional<zod.ZodString>;
            modelCacheDir: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        store: zod.ZodOptional<zod.ZodObject<{
            driver: zod.ZodOptional<zod.ZodLiteral<"sqlite">>;
            path: zod.ZodOptional<zod.ZodString>;
            vector: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                extensionPath: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        chunking: zod.ZodOptional<zod.ZodObject<{
            tokens: zod.ZodOptional<zod.ZodNumber>;
            overlap: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        sync: zod.ZodOptional<zod.ZodObject<{
            onSessionStart: zod.ZodOptional<zod.ZodBoolean>;
            onSearch: zod.ZodOptional<zod.ZodBoolean>;
            watch: zod.ZodOptional<zod.ZodBoolean>;
            watchDebounceMs: zod.ZodOptional<zod.ZodNumber>;
            intervalMinutes: zod.ZodOptional<zod.ZodNumber>;
            sessions: zod.ZodOptional<zod.ZodObject<{
                deltaBytes: zod.ZodOptional<zod.ZodNumber>;
                deltaMessages: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        query: zod.ZodOptional<zod.ZodObject<{
            maxResults: zod.ZodOptional<zod.ZodNumber>;
            minScore: zod.ZodOptional<zod.ZodNumber>;
            hybrid: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                vectorWeight: zod.ZodOptional<zod.ZodNumber>;
                textWeight: zod.ZodOptional<zod.ZodNumber>;
                candidateMultiplier: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        cache: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            maxEntries: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    advancedMemory: zod.ZodOptional<zod.ZodBoolean>;
    agentOrchestrator: zod.ZodOptional<zod.ZodBoolean>;
    gitpathologist: zod.ZodOptional<zod.ZodBoolean>;
    humanDelay: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"natural">, zod.ZodLiteral<"custom">]>>;
        minMs: zod.ZodOptional<zod.ZodNumber>;
        maxMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        every: zod.ZodOptional<zod.ZodString>;
        activeHours: zod.ZodOptional<zod.ZodObject<{
            start: zod.ZodOptional<zod.ZodString>;
            end: zod.ZodOptional<zod.ZodString>;
            timezone: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        model: zod.ZodOptional<zod.ZodString>;
        session: zod.ZodOptional<zod.ZodString>;
        includeReasoning: zod.ZodOptional<zod.ZodBoolean>;
        target: zod.ZodOptional<zod.ZodString>;
        to: zod.ZodOptional<zod.ZodString>;
        prompt: zod.ZodOptional<zod.ZodString>;
        ackMaxChars: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    identity: zod.ZodOptional<zod.ZodObject<{
        name: zod.ZodOptional<zod.ZodString>;
        theme: zod.ZodOptional<zod.ZodString>;
        emoji: zod.ZodOptional<zod.ZodString>;
        avatar: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    groupChat: zod.ZodOptional<zod.ZodObject<{
        mentionPatterns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        historyLimit: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    subagents: zod.ZodOptional<zod.ZodObject<{
        allowAgents: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        model: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
            primary: zod.ZodOptional<zod.ZodString>;
            fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>]>>;
        thinking: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    sandbox: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"non-main">, zod.ZodLiteral<"all">]>>;
        workspaceAccess: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"none">, zod.ZodLiteral<"ro">, zod.ZodLiteral<"rw">]>>;
        sessionToolsVisibility: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"spawned">, zod.ZodLiteral<"all">]>>;
        scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"session">, zod.ZodLiteral<"agent">, zod.ZodLiteral<"shared">]>>;
        perSession: zod.ZodOptional<zod.ZodBoolean>;
        workspaceRoot: zod.ZodOptional<zod.ZodString>;
        docker: zod.ZodOptional<zod.ZodObject<{
            image: zod.ZodOptional<zod.ZodString>;
            containerPrefix: zod.ZodOptional<zod.ZodString>;
            workdir: zod.ZodOptional<zod.ZodString>;
            readOnlyRoot: zod.ZodOptional<zod.ZodBoolean>;
            tmpfs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            network: zod.ZodOptional<zod.ZodString>;
            user: zod.ZodOptional<zod.ZodString>;
            capDrop: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            setupCommand: zod.ZodOptional<zod.ZodString>;
            pidsLimit: zod.ZodOptional<zod.ZodNumber>;
            memory: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
            memorySwap: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
            cpus: zod.ZodOptional<zod.ZodNumber>;
            ulimits: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodObject<{
                soft: zod.ZodOptional<zod.ZodNumber>;
                hard: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>]>>>;
            seccompProfile: zod.ZodOptional<zod.ZodString>;
            apparmorProfile: zod.ZodOptional<zod.ZodString>;
            dns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            extraHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            binds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        browser: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            image: zod.ZodOptional<zod.ZodString>;
            containerPrefix: zod.ZodOptional<zod.ZodString>;
            cdpPort: zod.ZodOptional<zod.ZodNumber>;
            vncPort: zod.ZodOptional<zod.ZodNumber>;
            noVncPort: zod.ZodOptional<zod.ZodNumber>;
            headless: zod.ZodOptional<zod.ZodBoolean>;
            enableNoVnc: zod.ZodOptional<zod.ZodBoolean>;
            allowHostControl: zod.ZodOptional<zod.ZodBoolean>;
            autoStart: zod.ZodOptional<zod.ZodBoolean>;
            autoStartTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        prune: zod.ZodOptional<zod.ZodObject<{
            idleHours: zod.ZodOptional<zod.ZodNumber>;
            maxAgeDays: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    tools: zod.ZodOptional<zod.ZodObject<{
        profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        byProvider: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
        }, zod.z.core.$strict>>>;
        elevated: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowFrom: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>>;
        }, zod.z.core.$strict>>;
        exec: zod.ZodOptional<zod.ZodObject<{
            host: zod.ZodOptional<zod.ZodEnum<{
                sandbox: "sandbox";
                gateway: "gateway";
                node: "node";
            }>>;
            security: zod.ZodOptional<zod.ZodEnum<{
                deny: "deny";
                full: "full";
                allowlist: "allowlist";
            }>>;
            ask: zod.ZodOptional<zod.ZodEnum<{
                always: "always";
                off: "off";
                "on-miss": "on-miss";
            }>>;
            node: zod.ZodOptional<zod.ZodString>;
            pathPrepend: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            safeBins: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            backgroundMs: zod.ZodOptional<zod.ZodNumber>;
            timeoutSec: zod.ZodOptional<zod.ZodNumber>;
            approvalRunningNoticeMs: zod.ZodOptional<zod.ZodNumber>;
            cleanupMs: zod.ZodOptional<zod.ZodNumber>;
            notifyOnExit: zod.ZodOptional<zod.ZodBoolean>;
            applyPatch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                allowModels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        sandbox: zod.ZodOptional<zod.ZodObject<{
            tools: zod.ZodOptional<zod.ZodObject<{
                allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>;
export declare const ToolsSchema: zod.ZodOptional<zod.ZodObject<{
    profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
    allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    byProvider: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        profile: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"minimal">, zod.ZodLiteral<"coding">, zod.ZodLiteral<"messaging">, zod.ZodLiteral<"full">]>>;
    }, zod.z.core.$strict>>>;
    web: zod.ZodOptional<zod.ZodObject<{
        search: zod.ZodOptional<zod.ZodObject<{
            maxResults: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        fetch: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            cacheTtlMinutes: zod.ZodOptional<zod.ZodNumber>;
            maxRedirects: zod.ZodOptional<zod.ZodNumber>;
            userAgent: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    cache: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        memoryCapacity: zod.ZodOptional<zod.ZodNumber>;
        diskRoot: zod.ZodOptional<zod.ZodString>;
        perTool: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
            ttlMinutes: zod.ZodOptional<zod.ZodNumber>;
            version: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    media: zod.ZodOptional<zod.ZodObject<{
        models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
            provider: zod.ZodOptional<zod.ZodString>;
            model: zod.ZodOptional<zod.ZodString>;
            capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
            type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
            command: zod.ZodOptional<zod.ZodString>;
            args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            prompt: zod.ZodOptional<zod.ZodString>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            profile: zod.ZodOptional<zod.ZodString>;
            preferredProfile: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>>>;
        concurrency: zod.ZodOptional<zod.ZodNumber>;
        image: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            scope: zod.ZodOptional<zod.ZodObject<{
                default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                    action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                    match: zod.ZodOptional<zod.ZodObject<{
                        channel: zod.ZodOptional<zod.ZodString>;
                        chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                        keyPrefix: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>>;
            }, zod.z.core.$strict>>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            prompt: zod.ZodOptional<zod.ZodString>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            attachments: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                maxAttachments: zod.ZodOptional<zod.ZodNumber>;
                prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
            }, zod.z.core.$strict>>;
            models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                provider: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                command: zod.ZodOptional<zod.ZodString>;
                args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                prompt: zod.ZodOptional<zod.ZodString>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                profile: zod.ZodOptional<zod.ZodString>;
                preferredProfile: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>;
        audio: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            scope: zod.ZodOptional<zod.ZodObject<{
                default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                    action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                    match: zod.ZodOptional<zod.ZodObject<{
                        channel: zod.ZodOptional<zod.ZodString>;
                        chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                        keyPrefix: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>>;
            }, zod.z.core.$strict>>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            prompt: zod.ZodOptional<zod.ZodString>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            attachments: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                maxAttachments: zod.ZodOptional<zod.ZodNumber>;
                prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
            }, zod.z.core.$strict>>;
            models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                provider: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                command: zod.ZodOptional<zod.ZodString>;
                args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                prompt: zod.ZodOptional<zod.ZodString>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                profile: zod.ZodOptional<zod.ZodString>;
                preferredProfile: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>;
        video: zod.ZodOptional<zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            scope: zod.ZodOptional<zod.ZodObject<{
                default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
                rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                    action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                    match: zod.ZodOptional<zod.ZodObject<{
                        channel: zod.ZodOptional<zod.ZodString>;
                        chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                        keyPrefix: zod.ZodOptional<zod.ZodString>;
                    }, zod.z.core.$strict>>;
                }, zod.z.core.$strict>>>;
            }, zod.z.core.$strict>>;
            maxBytes: zod.ZodOptional<zod.ZodNumber>;
            prompt: zod.ZodOptional<zod.ZodString>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
            language: zod.ZodOptional<zod.ZodString>;
            providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
            deepgram: zod.ZodOptional<zod.ZodObject<{
                detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                punctuate: zod.ZodOptional<zod.ZodBoolean>;
                smartFormat: zod.ZodOptional<zod.ZodBoolean>;
            }, zod.z.core.$strict>>;
            baseUrl: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            attachments: zod.ZodOptional<zod.ZodObject<{
                mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"all">]>>;
                maxAttachments: zod.ZodOptional<zod.ZodNumber>;
                prefer: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"last">, zod.ZodLiteral<"path">, zod.ZodLiteral<"url">]>>;
            }, zod.z.core.$strict>>;
            models: zod.ZodOptional<zod.ZodArray<zod.ZodOptional<zod.ZodObject<{
                provider: zod.ZodOptional<zod.ZodString>;
                model: zod.ZodOptional<zod.ZodString>;
                capabilities: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"image">, zod.ZodLiteral<"audio">, zod.ZodLiteral<"video">]>>>;
                type: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"provider">, zod.ZodLiteral<"cli">]>>;
                command: zod.ZodOptional<zod.ZodString>;
                args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
                prompt: zod.ZodOptional<zod.ZodString>;
                maxBytes: zod.ZodOptional<zod.ZodNumber>;
                timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
                language: zod.ZodOptional<zod.ZodString>;
                providerOptions: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodBoolean]>>>>;
                deepgram: zod.ZodOptional<zod.ZodObject<{
                    detectLanguage: zod.ZodOptional<zod.ZodBoolean>;
                    punctuate: zod.ZodOptional<zod.ZodBoolean>;
                    smartFormat: zod.ZodOptional<zod.ZodBoolean>;
                }, zod.z.core.$strict>>;
                baseUrl: zod.ZodOptional<zod.ZodString>;
                headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
                profile: zod.ZodOptional<zod.ZodString>;
                preferredProfile: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>>>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    links: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        scope: zod.ZodOptional<zod.ZodObject<{
            default: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>>;
            rules: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
                action: zod.ZodUnion<readonly [zod.ZodLiteral<"allow">, zod.ZodLiteral<"deny">]>;
                match: zod.ZodOptional<zod.ZodObject<{
                    channel: zod.ZodOptional<zod.ZodString>;
                    chatType: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"direct">, zod.ZodLiteral<"group">, zod.ZodLiteral<"channel">]>>;
                    keyPrefix: zod.ZodOptional<zod.ZodString>;
                }, zod.z.core.$strict>>;
            }, zod.z.core.$strict>>>;
        }, zod.z.core.$strict>>;
        maxLinks: zod.ZodOptional<zod.ZodNumber>;
        timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        models: zod.ZodOptional<zod.ZodArray<zod.ZodObject<{
            type: zod.ZodOptional<zod.ZodLiteral<"cli">>;
            command: zod.ZodString;
            args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>>;
    }, zod.z.core.$strict>>;
    message: zod.ZodOptional<zod.ZodObject<{
        allowCrossContextSend: zod.ZodOptional<zod.ZodBoolean>;
        crossContext: zod.ZodOptional<zod.ZodObject<{
            allowWithinProvider: zod.ZodOptional<zod.ZodBoolean>;
            allowAcrossProviders: zod.ZodOptional<zod.ZodBoolean>;
            marker: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                prefix: zod.ZodOptional<zod.ZodString>;
                suffix: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        broadcast: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    agentToAgent: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    elevated: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        allowFrom: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodArray<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>>>;
    }, zod.z.core.$strict>>;
    exec: zod.ZodOptional<zod.ZodObject<{
        host: zod.ZodOptional<zod.ZodEnum<{
            sandbox: "sandbox";
            gateway: "gateway";
            node: "node";
        }>>;
        security: zod.ZodOptional<zod.ZodEnum<{
            deny: "deny";
            full: "full";
            allowlist: "allowlist";
        }>>;
        ask: zod.ZodOptional<zod.ZodEnum<{
            always: "always";
            off: "off";
            "on-miss": "on-miss";
        }>>;
        node: zod.ZodOptional<zod.ZodString>;
        pathPrepend: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        safeBins: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        backgroundMs: zod.ZodOptional<zod.ZodNumber>;
        timeoutSec: zod.ZodOptional<zod.ZodNumber>;
        cleanupMs: zod.ZodOptional<zod.ZodNumber>;
        notifyOnExit: zod.ZodOptional<zod.ZodBoolean>;
        applyPatch: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            allowModels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    subagents: zod.ZodOptional<zod.ZodObject<{
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    sandbox: zod.ZodOptional<zod.ZodObject<{
        tools: zod.ZodOptional<zod.ZodObject<{
            allow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alsoAllow: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            deny: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
export declare const OwnerContactEntrySchema: zod.ZodObject<{
    source: zod.ZodOptional<zod.ZodString>;
    entityId: zod.ZodOptional<zod.ZodString>;
    channelId: zod.ZodOptional<zod.ZodString>;
    roomId: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>;
export declare const OwnerContactsSchema: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
    source: zod.ZodOptional<zod.ZodString>;
    entityId: zod.ZodOptional<zod.ZodString>;
    channelId: zod.ZodOptional<zod.ZodString>;
    roomId: zod.ZodOptional<zod.ZodString>;
}, zod.z.core.$strict>>>;
export declare const EscalationSchema: zod.ZodOptional<zod.ZodObject<{
    channels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    waitMinutes: zod.ZodOptional<zod.ZodNumber>;
    maxRetries: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const InboxTriageConfigSchema: zod.ZodOptional<zod.ZodObject<{
    enabled: zod.ZodOptional<zod.ZodBoolean>;
    triageCron: zod.ZodOptional<zod.ZodString>;
    digestCron: zod.ZodOptional<zod.ZodString>;
    digestTimezone: zod.ZodOptional<zod.ZodString>;
    channels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    prioritySenders: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    priorityChannels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    autoReply: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        confidenceThreshold: zod.ZodOptional<zod.ZodNumber>;
        senderWhitelist: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        channelWhitelist: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        maxAutoRepliesPerHour: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    triageRules: zod.ZodOptional<zod.ZodObject<{
        alwaysUrgent: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alwaysIgnore: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        alwaysNotify: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    digestDeliveryChannel: zod.ZodOptional<zod.ZodString>;
    retentionDays: zod.ZodOptional<zod.ZodNumber>;
}, zod.z.core.$strict>>;
export declare const AgentDefaultsSchema: zod.ZodOptional<zod.ZodObject<{
    model: zod.ZodOptional<zod.ZodObject<{
        primary: zod.ZodOptional<zod.ZodString>;
        fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    imageModel: zod.ZodOptional<zod.ZodObject<{
        primary: zod.ZodOptional<zod.ZodString>;
        fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
    }, zod.z.core.$strict>>;
    models: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        alias: zod.ZodOptional<zod.ZodString>;
        params: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnknown>>;
    }, zod.z.core.$strict>>>;
    workspace: zod.ZodOptional<zod.ZodString>;
    adminEntityId: zod.ZodOptional<zod.ZodString>;
    ownerContacts: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        source: zod.ZodOptional<zod.ZodString>;
        entityId: zod.ZodOptional<zod.ZodString>;
        channelId: zod.ZodOptional<zod.ZodString>;
        roomId: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>>;
    escalation: zod.ZodOptional<zod.ZodObject<{
        channels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        waitMinutes: zod.ZodOptional<zod.ZodNumber>;
        maxRetries: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    repoRoot: zod.ZodOptional<zod.ZodString>;
    skipInit: zod.ZodOptional<zod.ZodBoolean>;
    enableInitProviders: zod.ZodOptional<zod.ZodBoolean>;
    userTimezone: zod.ZodOptional<zod.ZodString>;
    timeFormat: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"auto">, zod.ZodLiteral<"12">, zod.ZodLiteral<"24">]>>;
    envelopeTimezone: zod.ZodOptional<zod.ZodString>;
    envelopeTimestamp: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"on">, zod.ZodLiteral<"off">]>>;
    envelopeElapsed: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"on">, zod.ZodLiteral<"off">]>>;
    contextTokens: zod.ZodOptional<zod.ZodNumber>;
    cliBackends: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodObject<{
        command: zod.ZodString;
        args: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        output: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"json">, zod.ZodLiteral<"text">, zod.ZodLiteral<"jsonl">]>>;
        resumeOutput: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"json">, zod.ZodLiteral<"text">, zod.ZodLiteral<"jsonl">]>>;
        input: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"arg">, zod.ZodLiteral<"stdin">]>>;
        maxPromptArgChars: zod.ZodOptional<zod.ZodNumber>;
        env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        clearEnv: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        modelArg: zod.ZodOptional<zod.ZodString>;
        modelAliases: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
        sessionArg: zod.ZodOptional<zod.ZodString>;
        sessionArgs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        resumeArgs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        sessionMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"always">, zod.ZodLiteral<"existing">, zod.ZodLiteral<"none">]>>;
        sessionIdFields: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        systemPromptArg: zod.ZodOptional<zod.ZodString>;
        systemPromptMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"append">, zod.ZodLiteral<"replace">]>>;
        systemPromptWhen: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"first">, zod.ZodLiteral<"always">, zod.ZodLiteral<"never">]>>;
        imageArg: zod.ZodOptional<zod.ZodString>;
        imageMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"repeat">, zod.ZodLiteral<"list">]>>;
        serialize: zod.ZodOptional<zod.ZodBoolean>;
    }, zod.z.core.$strict>>>;
    memorySearch: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        sources: zod.ZodOptional<zod.ZodArray<zod.ZodUnion<readonly [zod.ZodLiteral<"memory">, zod.ZodLiteral<"sessions">]>>>;
        extraPaths: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        experimental: zod.ZodOptional<zod.ZodObject<{
            sessionMemory: zod.ZodOptional<zod.ZodBoolean>;
        }, zod.z.core.$strict>>;
        provider: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"local">, zod.ZodLiteral<"gemini">]>>;
        remote: zod.ZodOptional<zod.ZodObject<{
            baseUrl: zod.ZodOptional<zod.ZodString>;
            apiKey: zod.ZodOptional<zod.ZodString>;
            headers: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            batch: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                wait: zod.ZodOptional<zod.ZodBoolean>;
                concurrency: zod.ZodOptional<zod.ZodNumber>;
                pollIntervalMs: zod.ZodOptional<zod.ZodNumber>;
                timeoutMinutes: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        fallback: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"openai">, zod.ZodLiteral<"gemini">, zod.ZodLiteral<"local">, zod.ZodLiteral<"none">]>>;
        model: zod.ZodOptional<zod.ZodString>;
        local: zod.ZodOptional<zod.ZodObject<{
            modelPath: zod.ZodOptional<zod.ZodString>;
            modelCacheDir: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        store: zod.ZodOptional<zod.ZodObject<{
            driver: zod.ZodOptional<zod.ZodLiteral<"sqlite">>;
            path: zod.ZodOptional<zod.ZodString>;
            vector: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                extensionPath: zod.ZodOptional<zod.ZodString>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        chunking: zod.ZodOptional<zod.ZodObject<{
            tokens: zod.ZodOptional<zod.ZodNumber>;
            overlap: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        sync: zod.ZodOptional<zod.ZodObject<{
            onSessionStart: zod.ZodOptional<zod.ZodBoolean>;
            onSearch: zod.ZodOptional<zod.ZodBoolean>;
            watch: zod.ZodOptional<zod.ZodBoolean>;
            watchDebounceMs: zod.ZodOptional<zod.ZodNumber>;
            intervalMinutes: zod.ZodOptional<zod.ZodNumber>;
            sessions: zod.ZodOptional<zod.ZodObject<{
                deltaBytes: zod.ZodOptional<zod.ZodNumber>;
                deltaMessages: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        query: zod.ZodOptional<zod.ZodObject<{
            maxResults: zod.ZodOptional<zod.ZodNumber>;
            minScore: zod.ZodOptional<zod.ZodNumber>;
            hybrid: zod.ZodOptional<zod.ZodObject<{
                enabled: zod.ZodOptional<zod.ZodBoolean>;
                vectorWeight: zod.ZodOptional<zod.ZodNumber>;
                textWeight: zod.ZodOptional<zod.ZodNumber>;
                candidateMultiplier: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>>;
        }, zod.z.core.$strict>>;
        cache: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            maxEntries: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    advancedMemory: zod.ZodOptional<zod.ZodBoolean>;
    agentOrchestrator: zod.ZodOptional<zod.ZodBoolean>;
    gitpathologist: zod.ZodOptional<zod.ZodBoolean>;
    thinkingDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"minimal">, zod.ZodLiteral<"low">, zod.ZodLiteral<"medium">, zod.ZodLiteral<"high">, zod.ZodLiteral<"xhigh">]>>;
    verboseDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"on">, zod.ZodLiteral<"full">]>>;
    elevatedDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"on">, zod.ZodLiteral<"ask">, zod.ZodLiteral<"full">]>>;
    blockStreamingDefault: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"on">]>>;
    blockStreamingBreak: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"text_end">, zod.ZodLiteral<"message_end">]>>;
    blockStreamingChunk: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        breakPreference: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"paragraph">, zod.ZodLiteral<"newline">, zod.ZodLiteral<"sentence">]>>;
    }, zod.z.core.$strict>>;
    blockStreamingCoalesce: zod.ZodOptional<zod.ZodObject<{
        minChars: zod.ZodOptional<zod.ZodNumber>;
        maxChars: zod.ZodOptional<zod.ZodNumber>;
        idleMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    humanDelay: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"natural">, zod.ZodLiteral<"custom">]>>;
        minMs: zod.ZodOptional<zod.ZodNumber>;
        maxMs: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    timeoutSeconds: zod.ZodOptional<zod.ZodNumber>;
    mediaMaxMb: zod.ZodOptional<zod.ZodNumber>;
    typingIntervalSeconds: zod.ZodOptional<zod.ZodNumber>;
    typingMode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"never">, zod.ZodLiteral<"instant">, zod.ZodLiteral<"thinking">, zod.ZodLiteral<"message">]>>;
    heartbeat: zod.ZodOptional<zod.ZodObject<{
        every: zod.ZodOptional<zod.ZodString>;
        activeHours: zod.ZodOptional<zod.ZodObject<{
            start: zod.ZodOptional<zod.ZodString>;
            end: zod.ZodOptional<zod.ZodString>;
            timezone: zod.ZodOptional<zod.ZodString>;
        }, zod.z.core.$strict>>;
        model: zod.ZodOptional<zod.ZodString>;
        session: zod.ZodOptional<zod.ZodString>;
        includeReasoning: zod.ZodOptional<zod.ZodBoolean>;
        target: zod.ZodOptional<zod.ZodString>;
        to: zod.ZodOptional<zod.ZodString>;
        prompt: zod.ZodOptional<zod.ZodString>;
        ackMaxChars: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
    maxConcurrent: zod.ZodOptional<zod.ZodNumber>;
    subagents: zod.ZodOptional<zod.ZodObject<{
        maxConcurrent: zod.ZodOptional<zod.ZodNumber>;
        archiveAfterMinutes: zod.ZodOptional<zod.ZodNumber>;
        model: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodObject<{
            primary: zod.ZodOptional<zod.ZodString>;
            fallbacks: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>]>>;
        thinking: zod.ZodOptional<zod.ZodString>;
    }, zod.z.core.$strict>>;
    sandbox: zod.ZodOptional<zod.ZodObject<{
        mode: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"off">, zod.ZodLiteral<"non-main">, zod.ZodLiteral<"all">]>>;
        workspaceAccess: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"none">, zod.ZodLiteral<"ro">, zod.ZodLiteral<"rw">]>>;
        sessionToolsVisibility: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"spawned">, zod.ZodLiteral<"all">]>>;
        scope: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodLiteral<"session">, zod.ZodLiteral<"agent">, zod.ZodLiteral<"shared">]>>;
        perSession: zod.ZodOptional<zod.ZodBoolean>;
        workspaceRoot: zod.ZodOptional<zod.ZodString>;
        docker: zod.ZodOptional<zod.ZodObject<{
            image: zod.ZodOptional<zod.ZodString>;
            containerPrefix: zod.ZodOptional<zod.ZodString>;
            workdir: zod.ZodOptional<zod.ZodString>;
            readOnlyRoot: zod.ZodOptional<zod.ZodBoolean>;
            tmpfs: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            network: zod.ZodOptional<zod.ZodString>;
            user: zod.ZodOptional<zod.ZodString>;
            capDrop: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            env: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodString>>;
            setupCommand: zod.ZodOptional<zod.ZodString>;
            pidsLimit: zod.ZodOptional<zod.ZodNumber>;
            memory: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
            memorySwap: zod.ZodOptional<zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber]>>;
            cpus: zod.ZodOptional<zod.ZodNumber>;
            ulimits: zod.ZodOptional<zod.ZodRecord<zod.ZodString, zod.ZodUnion<readonly [zod.ZodString, zod.ZodNumber, zod.ZodObject<{
                soft: zod.ZodOptional<zod.ZodNumber>;
                hard: zod.ZodOptional<zod.ZodNumber>;
            }, zod.z.core.$strict>]>>>;
            seccompProfile: zod.ZodOptional<zod.ZodString>;
            apparmorProfile: zod.ZodOptional<zod.ZodString>;
            dns: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            extraHosts: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            binds: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        browser: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            image: zod.ZodOptional<zod.ZodString>;
            containerPrefix: zod.ZodOptional<zod.ZodString>;
            cdpPort: zod.ZodOptional<zod.ZodNumber>;
            vncPort: zod.ZodOptional<zod.ZodNumber>;
            noVncPort: zod.ZodOptional<zod.ZodNumber>;
            headless: zod.ZodOptional<zod.ZodBoolean>;
            enableNoVnc: zod.ZodOptional<zod.ZodBoolean>;
            allowHostControl: zod.ZodOptional<zod.ZodBoolean>;
            autoStart: zod.ZodOptional<zod.ZodBoolean>;
            autoStartTimeoutMs: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        prune: zod.ZodOptional<zod.ZodObject<{
            idleHours: zod.ZodOptional<zod.ZodNumber>;
            maxAgeDays: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
    }, zod.z.core.$strict>>;
    inboxTriage: zod.ZodOptional<zod.ZodObject<{
        enabled: zod.ZodOptional<zod.ZodBoolean>;
        triageCron: zod.ZodOptional<zod.ZodString>;
        digestCron: zod.ZodOptional<zod.ZodString>;
        digestTimezone: zod.ZodOptional<zod.ZodString>;
        channels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        prioritySenders: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        priorityChannels: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        autoReply: zod.ZodOptional<zod.ZodObject<{
            enabled: zod.ZodOptional<zod.ZodBoolean>;
            confidenceThreshold: zod.ZodOptional<zod.ZodNumber>;
            senderWhitelist: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            channelWhitelist: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            maxAutoRepliesPerHour: zod.ZodOptional<zod.ZodNumber>;
        }, zod.z.core.$strict>>;
        triageRules: zod.ZodOptional<zod.ZodObject<{
            alwaysUrgent: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alwaysIgnore: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
            alwaysNotify: zod.ZodOptional<zod.ZodArray<zod.ZodString>>;
        }, zod.z.core.$strict>>;
        digestDeliveryChannel: zod.ZodOptional<zod.ZodString>;
        retentionDays: zod.ZodOptional<zod.ZodNumber>;
    }, zod.z.core.$strict>>;
}, zod.z.core.$strict>>;
