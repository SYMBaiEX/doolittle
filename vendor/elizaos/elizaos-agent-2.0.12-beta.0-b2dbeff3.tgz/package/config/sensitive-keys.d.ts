export declare function isSensitiveConfigKey(key: string): boolean;
/**
 * Leaf value written in place of a secret by every redaction walk
 * (`/api/config`, connectors, and the `/api/runtime` debug snapshot).
 * Empty strings and nullish values stay as they are, so the reader can
 * still see that no value is set.
 */
export declare function redactSensitiveLeaf(value: unknown): unknown;
