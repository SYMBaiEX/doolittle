import type http from "node:http";
import { applyCanonicalSetupConfig } from "../lib/config-like";
import { buildHomeRemoteRunnerAccessUrl } from "./home-remote-runner-access-url";
import { buildHomeRemoteRunnerSshTunnel } from "./home-remote-runner-access-url";
import { clearCloudAuthService } from "../lib/cloud-connection";
import { clearCloudSecrets } from "../lib/cloud-secrets";
import { disconnectCloudConnection } from "../lib/cloud-connection";
import { getCloudAuth } from "../lib/cloud-connection";
import { handleCloudCodingContainerRoute } from "./cloud-coding-container-routes";
import { handleCloudRoute as handleAutonomousCloudRoute } from "./cloud-routes-autonomous.js";
import { isCloudInferenceSelectedInConfig } from "@elizaos/host/protocol";
import { isTimeoutError } from "../lib/config-like";
import { logger } from "@elizaos/core";
import { migrateLegacyRuntimeConfig } from "@elizaos/host/protocol";
import { normalizeCloudSiteUrl } from "../cloud/base-url.js";
import { resolveDevCloudEnvAuthority } from "../cloud-config/dev-cloud-env-authority.js";
import { getCloudSecret, scrubCloudSecretsFromEnv } from "../lib/cloud-secrets";
import { sendJson } from "../lib/http";
import { sendJsonError } from "../lib/http";
import { type AgentRuntime } from "@elizaos/core";
import { type CloudManager } from "../cloud/cloud-manager.js";
import { type CloudRouteState as AutonomousCloudRouteState } from "./cloud-routes-autonomous.js";
import { type ElizaConfig } from "../lib/config-like";
import { type RuntimeCloudLike } from "../lib/cloud-connection";
import { validateCloudBaseUrl } from "../cloud/validate-url.js";
export interface CloudRouteState {
    config: ElizaConfig;
    cloudManager: CloudManager | null;
    /** The running agent runtime — needed to persist cloud credentials to the DB. */
    runtime: AgentRuntime | null;
    restartRuntime?: (reason: string) => Promise<boolean> | boolean;
    services?: Partial<CloudRouteServices>;
}
type CreateIntegrationTelemetrySpan = (meta: {
    boundary: "cloud";
    operation: string;
    timeoutMs?: number;
}) => TelemetrySpan | null | undefined;
export interface CloudRouteServices {
    applyCanonicalSetupConfig: typeof applyCanonicalSetupConfig;
    createIntegrationTelemetrySpan: CreateIntegrationTelemetrySpan;
    handleAutonomousCloudRoute: typeof handleAutonomousCloudRoute;
    normalizeCloudSiteUrl: typeof normalizeCloudSiteUrl;
    saveElizaConfig: (config: ElizaConfig) => void;
    validateCloudBaseUrl: typeof validateCloudBaseUrl;
}
type CloudRuntimeSecrets = Record<string, string | number | boolean>;
type ReplaceableCloudManager = NonNullable<CloudRouteState["cloudManager"]> & {
    replaceApiKey?: (apiKey: string) => Promise<void>;
};
type StartableCloudRelayService = {
    startRelayLoopIfReady?: () => boolean | Promise<boolean>;
};
type RelayStatusService = {
    getSessionInfo?: () => {
        sessionId: string | null;
        organizationId: string | null;
        userId: string | null;
        agentName: string | null;
        platform: string | null;
        lastSeenAt: string | null;
        status: "idle" | "registered" | "polling" | "error" | "stopped";
    };
};
const CLOUD_LOGIN_POLL_TIMEOUT_MS = 10000;
function cloudLoginMutationBlockReason(): string | null {
    return resolveDevCloudEnvAuthority()
        ? "Cloud login cannot persist credentials owned by the immutable local development launch target"
        : null;
}
function isCloudConnectionMutationRoute(pathname: string, method: string): boolean {
    return ((method === "POST" &&
        (pathname === "/api/cloud/login" ||
            pathname === "/api/cloud/login/persist" ||
            pathname === "/api/cloud/disconnect")) ||
        (method === "GET" && pathname === "/api/cloud/login/status"));
}
const DEFAULT_CLOUD_ROUTE_SERVICES: CloudRouteServices = {
    applyCanonicalSetupConfig,
    createIntegrationTelemetrySpan: () => undefined,
    handleAutonomousCloudRoute,
    normalizeCloudSiteUrl,
    saveElizaConfig: () => {
        logger.warn("[cloud-routes] saveConfig unavailable - config not persisted");
    },
    validateCloudBaseUrl,
};
async function readRouteJsonBody(req: http.IncomingMessage, res: http.ServerResponse): Promise<Record<string, unknown> | null> {
    const preParsed = (req as http.IncomingMessage & {
        body?: unknown;
    }).body;
    if (preParsed !== undefined) {
        if (preParsed !== null &&
            typeof preParsed === "object" &&
            !Array.isArray(preParsed)) {
            return preParsed as Record<string, unknown>;
        }
        // error-policy:J3 untrusted-input sanitizing — middleware-parsed arrays,
        // primitives, and null are invalid persist objects just like raw JSON.
        sendJson(res, { ok: false, error: "Invalid JSON body" }, 400);
        return null;
    }
    const chunks: Buffer[] = [];
    for await (const chunk of req) {
        chunks.push(typeof chunk === "string" ? Buffer.from(chunk) : chunk);
    }
    const rawBody = Buffer.concat(chunks).toString("utf8").trim();
    if (!rawBody) {
        return {};
    }
    let parsed: unknown;
    try {
        parsed = JSON.parse(rawBody) as unknown;
    }
    catch {
        // error-policy:J3 untrusted-input sanitizing — malformed JSON is client
        // garbage and already answered as 400; null tells persist not to 500.
        sendJson(res, { ok: false, error: "Invalid JSON body" }, 400);
        return null;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        // error-policy:J3 untrusted-input sanitizing — a JSON primitive or array
        // is not a persist object; 400, not a persistence 500.
        sendJson(res, { ok: false, error: "Invalid JSON body" }, 400);
        return null;
    }
    return parsed as Record<string, unknown>;
}
/**
 * Monotonic counter incremented on every `POST /api/cloud/disconnect`.
 *
 * WHY: We must not persist a stale "authenticated" poll after the user
 * disconnects mid-flight. The previous guard (`cloud.enabled === false`)
 * also matched **first-time** cloud (never enabled), so successful logins
 * were discarded. Comparing epoch before/after the poll preserves the race
 * fix without blocking legitimate first connect.
 */
let cloudDisconnectEpoch = 0;
type TelemetrySpan = {
    success: (meta?: Record<string, unknown>) => void;
    failure: (meta?: Record<string, unknown>) => void;
};
function isRedirectResponse(response: Response): boolean {
    return response.status >= 300 && response.status < 400;
}
function createNoopTelemetrySpan(): TelemetrySpan {
    return {
        success: () => { },
        failure: () => { },
    };
}
function getTelemetrySpan(meta: {
    boundary: "cloud";
    operation: string;
    timeoutMs: number;
    services: CloudRouteServices;
}): TelemetrySpan {
    return (meta.services.createIntegrationTelemetrySpan(meta) ??
        createNoopTelemetrySpan());
}
async function fetchCloudLoginStatus(sessionId: string, baseUrl: string): Promise<Response> {
    return fetch(`${baseUrl}/api/auth/cli-session/${encodeURIComponent(sessionId)}`, {
        redirect: "manual",
        signal: AbortSignal.timeout(CLOUD_LOGIN_POLL_TIMEOUT_MS),
    });
}
/**
 * Sha-256 hex prefix (16 chars) of the cloud API key the RUNNING runtime
 * resolves right now, echoed to `POST /api/cloud/login/persist` callers as
 * `appliedKeyFingerprint`. The warm-claim re-credential control plane
 * (`pushClaimedWarmContainerInferenceKey`) compares it against the key it
 * minted: equality proves the process applied the pushed credential, while a
 * transport 200 alone only proves the route ran (the F0 bug lineage is
 * "control plane believed, process didn't"). Resolution goes through
 * `runtime.getSetting` first — the same precedence chain inference uses, so a
 * stale key shadowing via character secrets is DETECTED, not papered over —
 * with `process.env` used only when no runtime exists. A missing or throwing
 * runtime resolution fails the request rather than fabricating attestation.
 * Derivation mirrors
 * `warmClaimKeyFingerprint` in cloud/shared `warm-claim-key-push.ts` (kept
 * duplicated so the agent bundle never imports the cloud DB layer); only a
 * digest prefix crosses the wire, never key material.
 */
export async function resolveAppliedCloudKeyFingerprint(state: {
    runtime: unknown;
}): Promise<string> {
    const runtime = state.runtime as RuntimeCloudLike | null;
    const resolved = typeof runtime?.getSetting === "function"
        ? runtime.getSetting("ELIZAOS_CLOUD_API_KEY")
        : getCloudSecret("ELIZAOS_CLOUD_API_KEY");
    const key = typeof resolved === "string" ? resolved.trim() : "";
    if (!key) {
        throw new Error("Running runtime does not resolve a cloud credential");
    }
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(key));
    return Array.from(new Uint8Array(digest))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("")
        .slice(0, 16);
}
/**
 * Pin the ElizaCloud cloud-proxy text route into a config object so
 * `isCloudInferenceSelectedInConfig` returns true on the next boot. Additive
 * and minimal: preserves any existing serviceRouting fields, only (re)writes
 * the `llmText` slot with the canonical cloud-proxy shape. Used exclusively by
 * the warm-claim re-credential path (forceInferenceEnabled).
 */
export function applyCloudProxyTextRouting(config: Record<string, unknown>): void {
    const existingRouting = config.serviceRouting && typeof config.serviceRouting === "object"
        ? (config.serviceRouting as Record<string, unknown>)
        : {};
    config.serviceRouting = {
        ...existingRouting,
        llmText: {
            backend: "elizacloud",
            transport: "cloud-proxy",
            accountId: "elizacloud",
        },
    };
}
async function persistCloudLoginStatus(args: {
    apiKey: string;
    organizationId?: string;
    services: CloudRouteServices;
    state: CloudRouteState;
    userId?: string;
    /**
     * From GET `/api/cloud/login/status`: epoch captured before `fetch` so a
     * disconnect during the poll invalidates this result. Omitted for POST
     * `/api/cloud/login/persist` (direct client push) — no race window.
     */
    epochAtPollStart?: number;
    /**
     * Force cloud inference ON regardless of the config-derived
     * `isCloudInferenceSelectedInConfig` signal (warm-pool claim re-credential,
     * #16977-class F0). A warm-pool container boots managed with
     * `ELIZAOS_CLOUD_ENABLED=true` in its process env, but its persisted
     * eliza.json service-routing may not report `llmText.transport='cloud-proxy'`
     * (the managed env is the source of truth on that image, not the config
     * file). Without this override the re-credential push would swap the API key
     * but then DELETE `ELIZAOS_CLOUD_ENABLED`, leaving the just-claimed agent
     * unable to infer. When true, the login persist keeps inference enabled and
     * (below) writes the cloud-proxy service routing so the derivation agrees on
     * the next boot. Defaults to the config-derived behavior (undefined) so the
     * normal interactive login path is byte-identical.
     */
    forceInferenceEnabled?: boolean;
}): Promise<string | null> {
    if (cloudLoginMutationBlockReason()) {
        logger.warn("[cloud-login] Ignoring credential persistence that differs from the development launcher Cloud profile");
        return null;
    }
    if (args.epochAtPollStart !== undefined &&
        args.epochAtPollStart !== cloudDisconnectEpoch) {
        logger.warn("[cloud-login] Skipping login persist: a disconnect occurred while the login poll was in-flight");
        return null;
    }
    migrateLegacyRuntimeConfig(args.state.config as Record<string, unknown>);
    const runtime = args.state.runtime as RuntimeCloudLike | null;
    const cloudAuth = getCloudAuth(runtime);
    await clearCloudAuthService(cloudAuth);
    const cloud = { ...(args.state.config.cloud ?? {}) } as Record<string, unknown>;
    cloud.apiKey = args.apiKey;
    const cloudInferenceSelected = args.forceInferenceEnabled === true ||
        isCloudInferenceSelectedInConfig(args.state.config as Record<string, unknown>);
    args.state.config.cloud = cloud as ElizaConfig["cloud"];
    // Warm-claim re-credential: pin the cloud-proxy text route so a subsequent
    // container restart's config-derived `isCloudInferenceSelectedInConfig`
    // agrees with the managed env and inference stays enabled without another
    // push. Only when explicitly forced — the normal login path leaves routing
    // to the interactive provider selection.
    if (args.forceInferenceEnabled === true) {
        applyCloudProxyTextRouting(args.state.config as Record<string, unknown>);
    }
    args.services.applyCanonicalSetupConfig(args.state.config, {
        linkedAccounts: {
            elizacloud: {
                status: "linked",
                source: "api-key",
            },
        },
    });
    migrateLegacyRuntimeConfig(args.state.config as Record<string, unknown>);
    try {
        args.services.saveElizaConfig(args.state.config);
        logger.info("[cloud-login] Saved cloud API key to config file");
        logger.warn("[cloud-login] Cloud API key is stored in cleartext in ~/.eliza/eliza.json. " +
            "Ensure this file has restrictive permissions (chmod 600).");
    }
    catch (saveErr) {
        // error-policy:J6 best-effort — the config file is one of several
        // persistence layers for the API key (sealed secrets + agent DB below
        // also carry it); a config-write failure is logged loud but does not
        // abort login, which continues via the other layers.
        logger.error(`[cloud-login] Failed to save cloud API key to config: ${saveErr instanceof Error ? saveErr.message : String(saveErr)}`);
    }
    clearCloudSecrets();
    process.env.ELIZAOS_CLOUD_API_KEY = args.apiKey;
    if (cloudInferenceSelected) {
        process.env.ELIZAOS_CLOUD_ENABLED = "true";
    }
    else {
        delete process.env.ELIZAOS_CLOUD_ENABLED;
    }
    scrubCloudSecretsFromEnv();
    const cloudManager = args.state
        .cloudManager as ReplaceableCloudManager | null;
    if (cloudManager && typeof cloudManager.replaceApiKey === "function") {
        await cloudManager.replaceApiKey(args.apiKey);
    }
    else if (cloudManager &&
        !cloudManager.getClient() &&
        typeof cloudManager.init === "function") {
        await cloudManager.init();
    }
    if (typeof cloudAuth?.authenticateWithApiKey === "function") {
        cloudAuth.authenticateWithApiKey({
            apiKey: args.apiKey,
            organizationId: args.organizationId,
            userId: args.userId,
        });
    }
    const relayService = (runtime?.getService("CLOUD_MANAGED_GATEWAY_RELAY") ??
        runtime?.getService("cloud-managed-gateway-relay") ??
        runtime?.getService("cloudManagedGatewayRelay")) as StartableCloudRelayService | null;
    if (typeof relayService?.startRelayLoopIfReady === "function") {
        await relayService.startRelayLoopIfReady();
    }
    if (!runtime || typeof runtime.updateAgent !== "function") {
        const resolvedKey = getCloudSecret("ELIZAOS_CLOUD_API_KEY")?.trim();
        if (resolvedKey !== args.apiKey) {
            throw new Error("Cloud credential swap did not reach process state");
        }
        return resolvedKey;
    }
    try {
        const nextSecrets: CloudRuntimeSecrets = {
            ...(runtime.character.secrets ?? {}),
            ELIZAOS_CLOUD_API_KEY: args.apiKey,
        };
        if (args.userId) {
            nextSecrets.ELIZA_CLOUD_USER_ID = args.userId;
            nextSecrets.ELIZAOS_CLOUD_USER_ID = args.userId;
        }
        else {
            delete nextSecrets.ELIZA_CLOUD_USER_ID;
            delete nextSecrets.ELIZAOS_CLOUD_USER_ID;
        }
        if (args.organizationId) {
            nextSecrets.ELIZA_CLOUD_ORGANIZATION_ID = args.organizationId;
            nextSecrets.ELIZAOS_CLOUD_ORG_ID = args.organizationId;
        }
        else {
            delete nextSecrets.ELIZA_CLOUD_ORGANIZATION_ID;
            delete nextSecrets.ELIZAOS_CLOUD_ORG_ID;
        }
        if (cloudInferenceSelected) {
            nextSecrets.ELIZAOS_CLOUD_ENABLED = "true";
        }
        else {
            delete nextSecrets.ELIZAOS_CLOUD_ENABLED;
        }
        runtime.character.secrets = nextSecrets;
        if (typeof runtime.setSetting === "function") {
            runtime.setSetting("ELIZAOS_CLOUD_API_KEY", args.apiKey);
            runtime.setSetting("ELIZA_CLOUD_USER_ID", args.userId ?? null);
            runtime.setSetting("ELIZAOS_CLOUD_USER_ID", args.userId ?? null);
            runtime.setSetting("ELIZA_CLOUD_ORGANIZATION_ID", args.organizationId ?? null);
            runtime.setSetting("ELIZAOS_CLOUD_ORG_ID", args.organizationId ?? null);
        }
        await runtime.updateAgent(runtime.agentId, {
            secrets: { ...nextSecrets },
        });
    }
    catch (err) {
        // error-policy:J6 best-effort — config/sealed-secret persistence is enough
        // for login continuity; the agent-DB copy is a convenience layer, so its
        // failure is warned (observable) but non-fatal.
        logger.warn(`[cloud-routes] Failed to persist cloud secrets to agent DB: ${String(err)}`);
    }
    const resolvedKey = readRuntimeSetting(runtime as AgentRuntime, "ELIZAOS_CLOUD_API_KEY");
    if (resolvedKey !== args.apiKey) {
        throw new Error("Cloud credential swap did not reach the running runtime");
    }
    return resolvedKey;
}
function getCloudRouteServices(state: CloudRouteState): CloudRouteServices {
    return {
        ...DEFAULT_CLOUD_ROUTE_SERVICES,
        ...state.services,
    };
}
function readRuntimeSetting(runtime: AgentRuntime | null, key: string): string | null {
    const value = runtime?.getSetting(key);
    if (typeof value !== "string")
        return null;
    const trimmed = value.trim();
    return trimmed ? trimmed : null;
}
function toAutonomousState(state: CloudRouteState, services: CloudRouteServices): AutonomousCloudRouteState {
    return {
        ...state,
        saveConfig: () => services.saveElizaConfig(state.config),
        createTelemetrySpan: services.createIntegrationTelemetrySpan,
    };
}
export async function handleCloudRoute(req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: CloudRouteState): Promise<boolean> {
    const authorityBlockReason = cloudLoginMutationBlockReason();
    if (authorityBlockReason &&
        isCloudConnectionMutationRoute(pathname, method)) {
        sendJson(res, { ok: false, error: authorityBlockReason }, 409);
        return true;
    }
    const services = getCloudRouteServices(state);
    const codingContainerHandled = await handleCloudCodingContainerRoute(req, res, pathname, method, { runtime: state.runtime });
    if (codingContainerHandled) {
        return true;
    }
    if (method === "GET" && pathname === "/api/cloud/relay-status") {
        const relayService = (state.runtime?.getService("CLOUD_MANAGED_GATEWAY_RELAY") ??
            state.runtime?.getService("cloud-managed-gateway-relay") ??
            state.runtime?.getService("cloudManagedGatewayRelay")) as RelayStatusService | null;
        if (typeof relayService?.getSessionInfo !== "function") {
            sendJson(res, {
                available: false,
                status: "not_registered",
                reason: "Gateway relay service not active. Connect to Eliza Cloud in Settings to enable instance routing.",
            });
            return true;
        }
        try {
            const info = relayService.getSessionInfo();
            sendJson(res, {
                available: true,
                ...info,
                accessUrl: buildHomeRemoteRunnerAccessUrl({
                    cloudBaseUrl: services.normalizeCloudSiteUrl(state.config.cloud?.baseUrl),
                    sessionId: info.sessionId,
                }),
                ssh: buildHomeRemoteRunnerSshTunnel({
                    remoteBaseUrl: readRuntimeSetting(state.runtime, "ELIZA_HOME_REMOTE_RUNNER_URL") ??
                        process.env.ELIZA_HOME_REMOTE_RUNNER_URL ??
                        readRuntimeSetting(state.runtime, "ELIZA_HOME_RUNNER_URL") ??
                        process.env.ELIZA_HOME_RUNNER_URL,
                    sshTarget: readRuntimeSetting(state.runtime, "ELIZA_HOME_REMOTE_RUNNER_SSH_TARGET") ??
                        process.env.ELIZA_HOME_REMOTE_RUNNER_SSH_TARGET ??
                        readRuntimeSetting(state.runtime, "ELIZA_HOME_SSH_TARGET") ??
                        process.env.ELIZA_HOME_SSH_TARGET,
                    sshIdentity: readRuntimeSetting(state.runtime, "ELIZA_HOME_REMOTE_RUNNER_SSH_IDENTITY") ??
                        process.env.ELIZA_HOME_REMOTE_RUNNER_SSH_IDENTITY ??
                        readRuntimeSetting(state.runtime, "ELIZA_HOME_SSH_IDENTITY") ??
                        process.env.ELIZA_HOME_SSH_IDENTITY,
                    localPort: readRuntimeSetting(state.runtime, "ELIZA_HOME_REMOTE_RUNNER_SSH_LOCAL_PORT") ?? process.env.ELIZA_HOME_REMOTE_RUNNER_SSH_LOCAL_PORT,
                }),
            });
        }
        catch (error) {
            // error-policy:J4 explicit degrade — the home-remote-runner access probe
            // renders an `available: false` error state the UI shows directly; the
            // reason is surfaced, not swallowed.
            sendJson(res, {
                available: false,
                status: "error",
                reason: error instanceof Error ? error.message : String(error),
            });
        }
        return true;
    }
    if (method === "POST" && pathname === "/api/cloud/disconnect") {
        // Invalidate any in-flight login poll (see persistCloudLoginStatus).
        cloudDisconnectEpoch++;
        try {
            await disconnectCloudConnection({
                cloudManager: state.cloudManager,
                config: state.config,
                runtime: state.runtime,
                saveConfig: services.saveElizaConfig,
            });
        }
        catch (err) {
            // error-policy:J1 boundary translation — a disconnect failure surfaces as
            // a 500 with the message, never a fabricated success.
            const message = err instanceof Error ? err.message : String(err);
            logger.error(`[cloud/disconnect] failed: ${message}`);
            sendJson(res, { ok: false, error: message }, 500);
            return true;
        }
        sendJson(res, { ok: true, status: "disconnected" });
        return true;
    }
    // Direct-auth persistence: the frontend authenticated directly with Eliza
    // Cloud (bypassing the backend's login/status handler) and needs to push
    // the API key to the backend so billing/compat routes can authenticate.
    if (method === "POST" && pathname === "/api/cloud/login/persist") {
        try {
            const body = await readRouteJsonBody(req, res);
            if (!body) {
                return true;
            }
            if (typeof body.apiKey !== "string" || !body.apiKey.trim()) {
                sendJson(res, { ok: false, error: "apiKey is required" }, 400);
                return true;
            }
            const resolvedApiKey = await persistCloudLoginStatus({
                apiKey: body.apiKey.trim(),
                organizationId: typeof body.organizationId === "string"
                    ? body.organizationId.trim()
                    : undefined,
                services,
                state,
                userId: typeof body.userId === "string" ? body.userId.trim() : undefined,
                // Warm-pool claim re-credential (F0): the cloud control plane forces
                // inference ON so the just-claimed container can infer against the
                // claiming org even when its persisted config routing does not report
                // cloud-proxy. Strictly boolean-true opt-in — the interactive login
                // path omits it and keeps config-derived behavior.
                forceInferenceEnabled: body.forceInferenceEnabled === true,
            });
            if (!resolvedApiKey) {
                throw new Error("Cloud credential persistence was not applied");
            }
            sendJson(res, {
                ok: true,
                appliedKeyFingerprint: await resolveAppliedCloudKeyFingerprint({
                    runtime: state.runtime,
                }),
            });
        }
        catch (err) {
            // error-policy:J1 boundary translation — a persistence failure surfaces as
            // a 500 with the message; the route never reports success it did not do.
            const msg = err instanceof Error ? err.message : String(err);
            logger.error(`[cloud/login/persist] Failed: ${msg}`);
            sendJson(res, { ok: false, error: msg }, 500);
        }
        return true;
    }
    if (method === "GET" && pathname.startsWith("/api/cloud/login/status")) {
        const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
        const sessionId = url.searchParams.get("sessionId");
        if (!sessionId) {
            sendJsonError(res, "sessionId query parameter is required", 400);
            return true;
        }
        const baseUrl = services.normalizeCloudSiteUrl(state.config.cloud?.baseUrl);
        const urlError = await services.validateCloudBaseUrl(baseUrl);
        if (urlError) {
            sendJsonError(res, urlError, 400);
            return true;
        }
        const epochBeforePoll = cloudDisconnectEpoch;
        const loginPollSpan = getTelemetrySpan({
            boundary: "cloud",
            operation: "login_poll_status",
            services,
            timeoutMs: CLOUD_LOGIN_POLL_TIMEOUT_MS,
        });
        let pollRes: Response;
        try {
            pollRes = await fetchCloudLoginStatus(sessionId, baseUrl);
            // error-policy:J1 boundary translation — transport failure to Eliza Cloud
            // maps to 504 (timeout) or 502 (unreachable); the error is reported on
            // the telemetry span and returned as an explicit error status.
        }
        catch (fetchErr) {
            if (isTimeoutError(fetchErr)) {
                loginPollSpan.failure({ error: fetchErr, statusCode: 504 });
                sendJson(res, {
                    status: "error",
                    error: "Eliza Cloud status request timed out",
                }, 504);
                return true;
            }
            loginPollSpan.failure({ error: fetchErr, statusCode: 502 });
            sendJson(res, {
                status: "error",
                error: "Failed to reach Eliza Cloud",
            }, 502);
            return true;
        }
        if (isRedirectResponse(pollRes)) {
            loginPollSpan.failure({
                statusCode: pollRes.status,
                errorKind: "redirect_response",
            });
            sendJson(res, {
                status: "error",
                error: "Eliza Cloud status request was redirected; redirects are not allowed",
            }, 502);
            return true;
        }
        if (!pollRes.ok) {
            loginPollSpan.failure({
                statusCode: pollRes.status,
                errorKind: "http_error",
            });
            sendJson(res, pollRes.status === 404
                ? { status: "expired", error: "Session not found or expired" }
                : {
                    status: "error",
                    error: `Eliza Cloud returned HTTP ${pollRes.status}`,
                });
            return true;
        }
        let data: {
            apiKey?: unknown;
            keyPrefix?: unknown;
            organizationId?: unknown;
            status?: unknown;
            userId?: unknown;
        };
        try {
            data = (await pollRes.json()) as {
                apiKey?: unknown;
                keyPrefix?: unknown;
                organizationId?: unknown;
                status?: unknown;
                userId?: unknown;
            };
        }
        catch (parseErr) {
            // error-policy:J3 sanitizing boundary — an unparseable upstream body is an
            // explicit 502 "invalid JSON", never a fabricated authenticated result.
            loginPollSpan.failure({ error: parseErr, statusCode: pollRes.status });
            sendJson(res, {
                status: "error",
                error: "Eliza Cloud returned invalid JSON",
            }, 502);
            return true;
        }
        loginPollSpan.success({ statusCode: pollRes.status });
        if (data.status === "authenticated" && typeof data.apiKey === "string") {
            const resolvedApiKey = await persistCloudLoginStatus({
                apiKey: data.apiKey,
                organizationId: typeof data.organizationId === "string"
                    ? data.organizationId
                    : undefined,
                services,
                state,
                epochAtPollStart: epochBeforePoll,
                userId: typeof data.userId === "string" ? data.userId : undefined,
            });
            if (!resolvedApiKey) {
                sendJson(res, { status: "disconnected" });
                return true;
            }
            sendJson(res, {
                status: "authenticated",
                keyPrefix: typeof data.keyPrefix === "string" ? data.keyPrefix : undefined,
                organizationId: typeof data.organizationId === "string"
                    ? data.organizationId
                    : undefined,
                token: data.apiKey,
                userId: typeof data.userId === "string" ? data.userId : undefined,
            });
            return true;
        }
        sendJson(res, {
            status: typeof data.status === "string" ? data.status : "error",
        });
        return true;
    }
    const result = await services.handleAutonomousCloudRoute(req, res, pathname, method, toAutonomousState(state, services));
    // The upstream handler writes secrets to process.env — scrub them
    // immediately so they don't leak to child processes or env dumps.
    scrubCloudSecretsFromEnv();
    return result;
}
