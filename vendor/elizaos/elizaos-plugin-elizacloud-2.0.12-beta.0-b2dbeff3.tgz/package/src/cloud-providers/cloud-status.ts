/**
 * cloudStatusProvider — Container and connection status in agent state.
 */

import type { IAgentRuntime, Memory, Provider, ProviderResult, State } from "@elizaos/core";
import { CLOUD_CONTAINER_SERVICE_TYPE } from "@elizaos/contracts";
import type { CloudAuthService } from "../services/cloud-auth";
import type { CloudBridgeService } from "../services/cloud-bridge";
import type { CloudContainerService } from "../services/cloud-container";

export const cloudStatusProvider: Provider = {
  name: "elizacloud_status",
  description: "ElizaCloud container and connection status",
  descriptionCompressed: "ElizaCloud container/connection status.",
  dynamic: true,
  position: 90,
  contexts: ["cloud", "settings", "finance"],
  contextGate: { anyOf: ["cloud", "settings", "finance"] },
  cacheStable: false,
  cacheScope: "turn",
  // Cloud account/connection state is operator context — admin+ only (#12094 item 3).
  roleGate: { minRole: "ADMIN" },
  async get(runtime: IAgentRuntime, _message: Memory, _state: State): Promise<ProviderResult> {
    try {
      const auth = runtime.getService("CLOUD_AUTH") as CloudAuthService | undefined;
      if (!auth?.isAuthenticated()) {
        return {
          text: "ElizaCloud: Not authenticated",
          values: { cloudAuthenticated: false },
        };
      }

      const containerSvc = runtime.getService(CLOUD_CONTAINER_SERVICE_TYPE) as
        | CloudContainerService
        | undefined;
      const bridgeSvc = runtime.getService("CLOUD_BRIDGE") as CloudBridgeService | undefined;
      const containers = containerSvc?.getTrackedContainers() ?? [];
      const connected = bridgeSvc?.getConnectedContainerIds() ?? [];

      const apiKeyInvalid = auth.isApiKeyInvalid();

      const running = containers.filter((c) => c.status === "running").length;
      const deploying = containers.filter(
        (c) => c.status === "pending" || c.status === "building" || c.status === "deploying"
      ).length;

      const summaries = containers.map((c) => ({
        id: c.id,
        name: c.name,
        status: c.status,
        url: c.load_balancer_url,
        billing: c.billing_status,
        bridged: connected.includes(c.id),
      }));

      const lines = [
        `ElizaCloud: ${containers.length} container(s), ${running} running, ${connected.length} bridged`,
        ...(apiKeyInvalid
          ? ["  - WARNING: Eliza Cloud API key REVOKED/INVALID — model calls will 401 until re-provisioned"]
          : []),
        ...summaries.map(
          (c) =>
            `  - ${c.name} [${c.status}]${c.url ? ` @ ${c.url}` : ""}${c.bridged ? " (bridged)" : ""}`
        ),
      ];

      return {
        text: lines.join("\n"),
        values: {
          cloudAuthenticated: true,
          cloudApiKeyInvalid: apiKeyInvalid,
          totalContainers: containers.length,
          runningContainers: running,
          deployingContainers: deploying,
        },
        data: { containers: summaries },
      };
    } catch {
      return { text: "", values: {}, data: {} };
    }
  },
};
