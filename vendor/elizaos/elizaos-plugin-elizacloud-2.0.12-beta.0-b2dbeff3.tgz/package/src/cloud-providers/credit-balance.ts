/** Credit balance in agent state (60s cache). */

import type { IAgentRuntime, Memory, Provider, ProviderResult, State } from "@elizaos/core";
import { logger } from "@elizaos/core";
import { resolveCloudBillingUrl } from "../cloud/base-url";
import type { CloudAuthService } from "../services/cloud-auth";
import { getBaseURL } from "../utils/config";
import { createElizaCloudClient } from "../utils/sdk-client";
import { getCachedAccountSnapshot } from "./cloud-account";

/** Keyed by runtime and tagged with the org: a sign-in to another org reuses the runtime. */
const creditCaches = new WeakMap<
  IAgentRuntime,
  { value: number; at: number; organizationId: string | undefined }
>();
const TTL = 60_000;

export const creditBalanceProvider: Provider = {
  name: "elizacloud_credits",
  description: "ElizaCloud credit balance",
  descriptionCompressed: "ElizaCloud credit balance.",
  dynamic: true,
  contexts: ["cloud", "settings", "finance"],
  contextGate: { anyOf: ["cloud", "settings", "finance"] },
  cacheStable: false,
  cacheScope: "turn",
  // Cloud credit balance is operator/billing context — admin+ only (#12094 item 3).
  roleGate: { minRole: "ADMIN" },
  position: 91,
  async get(runtime: IAgentRuntime, _message: Memory, _state: State): Promise<ProviderResult> {
    const auth = runtime.getService("CLOUD_AUTH") as CloudAuthService | undefined;
    if (!auth?.isAuthenticated()) return { text: "" };
    const organizationId = auth.getOrganizationId();
    const isCurrentOrganization = () =>
      auth.isAuthenticated() && organizationId === auth.getOrganizationId();
    const topUpUrl = resolveCloudBillingUrl(getBaseURL(runtime));

    // CLOUD_ACCOUNT shares this contextGate and fetches the same balance in
    // the same compose; reuse its snapshot so the billing endpoint is hit
    // once per cache window instead of once per provider.
    const shared = getCachedAccountSnapshot(runtime);
    if (shared) {
      const result = format(shared.balance, topUpUrl);
      return result;
    }

    const entry = creditCaches.get(runtime);
    const cached = entry?.organizationId === organizationId ? entry : undefined;
    if (cached && Date.now() - cached.at < TTL) {
      const result = format(cached.value, topUpUrl);
      return result;
    }

    let balance: number;
    try {
      ({ balance } = await createElizaCloudClient(runtime).getCreditsBalance());
    } catch (err) {
      logger.warn(
        `[CloudCredits] Failed to fetch balance: ${err instanceof Error ? err.message : err}`
      );
      if (cached && isCurrentOrganization()) {
        const result = format(cached.value, topUpUrl);
        return result;
      }
      return { text: "", values: { cloudCreditsUnavailable: true }, data: {} };
    }
    // A sign-in to another org while the request ran: this balance is not the
    // current account's, so neither cache nor show it.
    if (!isCurrentOrganization()) {
      return { text: "", values: { cloudCreditsUnavailable: true }, data: {} };
    }
    creditCaches.set(runtime, { value: balance, at: Date.now(), organizationId });

    if (balance < 1.0) logger.warn(`[CloudCredits] Low balance: $${balance.toFixed(2)}`);
    const result = format(balance, topUpUrl);
    return result;
  },
};

function format(balance: number, topUpUrl: string): ProviderResult {
  const low = balance < 2.0;
  const critical = balance < 0.5;
  let text = `ElizaCloud credits: $${balance.toFixed(2)}`;
  if (critical) text += ` (CRITICAL — top up at ${topUpUrl})`;
  else if (low) text += ` (LOW — top up at ${topUpUrl})`;
  return {
    text,
    values: {
      cloudCredits: balance,
      cloudCreditsLow: low,
      cloudCreditsCritical: critical,
      cloudTopUpUrl: topUpUrl,
    },
  };
}
