import pluginDefault from "./index.js";

export * from "./index.js";
export default pluginDefault;

// Node-only route handlers (depend on node:os and other node built-ins).
export { handleCloudBillingRoute } from "./routes/cloud-billing-routes";
export { handleCloudCompatRoute } from "./routes/cloud-compat-routes";
export { handleCloudRelayRoute } from "./routes/cloud-relay-routes";
export {
  type CloudRouteState,
  handleCloudRoute,
} from "./routes/cloud-routes-autonomous";
export {
  handleCloudCodingContainerRoute,
  type CloudCodingContainerRouteState,
} from "./routes/cloud-coding-container-routes";
export type { CloudConfigLike } from "./routes/cloud-routes-autonomous";
export { handleCloudStatusRoutes } from "./routes/cloud-status-routes";
export { runCloudSetup, type CloudSetupResult } from "./cloud-setup";
export { ClackObserver } from "./cloud/clack-observer";
export { NullCloudSetupObserver } from "./cloud/null-observer";
export type {
  AvailabilityResult,
  CloudSetupObserver,
  ConfirmPrompt,
  ProvisionSuccessInfo,
  SelectChoiceOption,
  SelectChoicePrompt,
} from "./cloud/setup-observer";
export { CloudManager, type CloudManagerCallbacks } from "./cloud/cloud-manager";
export {
  getOrCreateClientAddressKey,
  persistCloudWalletCache,
  provisionCloudWalletsBestEffort,
} from "./cloud/cloud-wallet";
export {
  normalizeCloudSecret,
  resolveCloudApiKey,
} from "./cloud/cloud-api-key";
export {
  isCloudAuthApiKeyService,
  normalizeCloudApiKey,
  type CloudAuthApiKeyService,
} from "./cloud/auth-service-types";
export {
  clearCloudSecrets,
  getCloudSecret,
  scrubCloudSecretsFromEnv,
} from "./lib/cloud-secrets";
export {
  __resetCloudBaseUrlCache,
  ensureCloudTtsApiKeyAlias,
  handleCloudSttRoute,
  handleCloudTtsPreviewRoute,
  mirrorCompatHeaders,
  resolveCloudTtsBaseUrl,
  resolveElevenLabsApiKeyForCloudMode,
} from "./lib/server-cloud-tts";
export {
  fetchCloudVoiceCatalog,
  resetCloudVoiceCatalogCacheForTesting,
  setCloudVoiceClientFactoryForTesting,
  type CloudVoiceCatalogEntry,
  type CloudVoiceClient,
} from "./cloud-voice-catalog";
export {
  CloudTtsUnavailableError,
  type CloudTextToSpeechParams,
} from "./models/speech";
