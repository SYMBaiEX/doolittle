import type { IAgentRuntime, TranscriptionParams } from "@elizaos/core";
import { fetchWithSsrfGuard, logger } from '@elizaos/core';
import { readResponseWithLimit } from "@elizaos/core";
import type { OpenAITranscriptionParams } from "../types";
import { isCloudSttAvailable, resolveCloudTimeoutMs } from "../utils/config";
import { detectAudioMimeType } from "../utils/helpers";
import { createElizaCloudClient } from "../utils/sdk-client";
import { warmingRetryWaitSeconds } from "../utils/warming";

/** Hard cap on caller-supplied audio bytes pulled for transcription (Whisper-class 25 MiB). */
const TRANSCRIPTION_AUDIO_MAX_BYTES = 25 * 1024 * 1024;

/**
 * Thrown when Cloud STT cannot serve (no API key, or neither
 * `ELIZAOS_CLOUD_ENABLED` nor `ELIZAOS_CLOUD_USE_STT` is set). The
 * local-inference router catches any provider error and falls through to the
 * next eligible TRANSCRIPTION provider — the STT counterpart of
 * `CloudTtsUnavailableError` in `speech.ts`.
 */
export class CloudSttUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CloudSttUnavailableError";
  }
}

/** Every input shape core documents for `ModelType.TRANSCRIPTION` plus the plugin's own param object. */
export type CloudTranscriptionInput =
  | Blob
  | File
  | Buffer
  | string
  | TranscriptionParams
  | OpenAITranscriptionParams;

function isCoreTranscriptionParams(input: object): input is TranscriptionParams {
  return "audioUrl" in input && typeof (input as { audioUrl: unknown }).audioUrl === "string";
}

/**
 * Fetch caller-provided audio bytes from an http(s) URL through the SSRF
 * guard (the repo's convention for every server-side attachment fetch) so a
 * crafted `audioUrl` can't reach internal/metadata endpoints. The body is
 * read under a hard byte cap — the 30 s timeout alone cannot bound a hostile
 * server's payload size.
 */
async function fetchAudioFromUrl(url: string, signal?: AbortSignal): Promise<Blob> {
  const { response, release } = await fetchWithSsrfGuard({
    url,
    timeoutMs: 30_000,
    signal,
  });
  try {
    if (!response.ok) {
      throw new Error(
        `Failed to fetch TRANSCRIPTION audioUrl: ${response.status} ${response.statusText}`
      );
    }
    const bytes = await readResponseWithLimit(
      response,
      TRANSCRIPTION_AUDIO_MAX_BYTES
    );
    const mimeType = response.headers.get("content-type") || detectAudioMimeType(bytes);
    return new Blob([bytes] as never, { type: mimeType });
  } finally {
    await release();
  }
}

export async function handleTranscription(
  runtime: IAgentRuntime,
  input: CloudTranscriptionInput
): Promise<string> {
  if (!isCloudSttAvailable(runtime)) {
    throw new CloudSttUnavailableError(
      "Eliza Cloud STT is not available — falling through to next TRANSCRIPTION handler"
    );
  }

  let blob: Blob;
  let extraParams: OpenAITranscriptionParams | null = null;

  if (input instanceof Blob || input instanceof File) {
    blob = input as Blob;
  } else if (Buffer.isBuffer(input)) {
    const detectedMimeType = detectAudioMimeType(input);
    logger.debug(`Auto-detected audio MIME type: ${detectedMimeType}`);
    blob = new Blob([input] as never, { type: detectedMimeType });
  } else if (typeof input === "string") {
    blob = await fetchAudioFromUrl(input);
  } else if (
    typeof input === "object" &&
    input !== null &&
    "audio" in input &&
    input.audio != null
  ) {
    // In-process audio wins over any audioUrl: core TranscriptionParams
    // requires an audioUrl, so callers that already hold the media send
    // `{ audioUrl: "", audio }` (audio redaction verification). Transcribe
    // the bytes instead of fetching the (possibly empty) URL.
    const params = input as OpenAITranscriptionParams;
    const providedAudio: unknown = params.audio;
    const rawBytes =
      Buffer.isBuffer(providedAudio)
        ? providedAudio
        : providedAudio instanceof Uint8Array
          ? Buffer.from(providedAudio)
          : providedAudio instanceof ArrayBuffer
            ? Buffer.from(new Uint8Array(providedAudio))
            : null;
    if (rawBytes !== null) {
      const mimeType = params.mimeType ?? detectAudioMimeType(rawBytes);
      logger.debug(
        params.mimeType
          ? `Using provided MIME type: ${mimeType}`
          : `Auto-detected audio MIME type: ${mimeType}`
      );
      blob = new Blob([rawBytes] as never, { type: mimeType });
    } else if (
      providedAudio instanceof Blob ||
      providedAudio instanceof File
    ) {
      blob = providedAudio;
    } else {
      throw new Error(
        "TRANSCRIPTION param 'audio' must be a Blob/File/Buffer/Uint8Array/ArrayBuffer."
      );
    }
    extraParams = params;
  } else if (typeof input === "object" && input !== null && isCoreTranscriptionParams(input)) {
    // No in-process bytes accompanied the URL: only a remote fetch can serve
    // the transcript. An empty audioUrl is a caller-shape error, not a
    // fetchable resource — reject it instead of issuing a request that
    // cannot succeed.
    if (!input.audioUrl) {
      throw new Error(
        "TRANSCRIPTION requires audio bytes or a non-empty audioUrl; received an empty audioUrl with no audio."
      );
    }
    blob = await fetchAudioFromUrl(input.audioUrl, input.signal);
  } else {
    throw new Error(
      "TRANSCRIPTION expects a Blob/File/Buffer/Uint8Array/ArrayBuffer, an http(s) audio URL string, { audioUrl }, or an object { audio: Blob/File/Buffer/Uint8Array/ArrayBuffer, mimeType?, language?, response_format?, timestampGranularities?, prompt?, temperature? }"
    );
  }

  const mime = (blob as File).type || "audio/webm";
  const filename =
    (blob as File).name ||
    (mime.includes("mp3") || mime.includes("mpeg")
      ? "recording.mp3"
      : mime.includes("ogg")
        ? "recording.ogg"
        : mime.includes("wav")
          ? "recording.wav"
          : mime.includes("webm")
            ? "recording.webm"
            : "recording.bin");

  const formData = new FormData();
  formData.append("audio", blob, filename);
  if (extraParams) {
    if (typeof extraParams.language === "string") {
      formData.append("languageCode", String(extraParams.language));
    }
  }

  try {
    // Ride through the cloud's transient cold-cache warming 503: on a box
    // whose text brain runs elsewhere the STT admission cache goes cold
    // between rare calls and the first one 503s with a warming body that
    // clears in ~1s — the raw-Response companion to the throw-shaped retries
    // in image/video/music (#18323/#18325/#18333). A non-warming failure
    // still throws immediately.
    let response: Response;
    let warmingRetries = 0;
    for (;;) {
      response = await createElizaCloudClient(runtime).routes.postApiV1VoiceSttRaw({
        body: formData,
        timeoutMs: resolveCloudTimeoutMs("ELIZAOS_CLOUD_STT_TIMEOUT_MS", 60_000),
      });
      if (warmingRetries < 2) {
        const waitSeconds = await warmingRetryWaitSeconds(response);
        if (waitSeconds !== null) {
          warmingRetries++;
          logger.warn(
            `[ELIZAOS_CLOUD] STT cold-cache warming (503), retry ${warmingRetries}/2 after ${waitSeconds}s...`
          );
          await new Promise((r) => setTimeout(r, waitSeconds * 1000));
          continue;
        }
      }
      break;
    }

    if (!response.ok) {
      throw new Error(`Failed to transcribe audio: ${response.status} ${response.statusText}`);
    }

    const data = (await response.json()) as {
      text?: string;
      transcript?: string;
    };
    return data.text ?? data.transcript ?? "";
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.error(`TRANSCRIPTION error: ${message}`);
    throw error;
  }
}
