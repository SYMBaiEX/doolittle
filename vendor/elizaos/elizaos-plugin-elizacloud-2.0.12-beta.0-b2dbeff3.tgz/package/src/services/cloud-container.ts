/**
 * CloudContainerService — Manages container lifecycle through ElizaCloud API.
 *
 * Handles listing, status polling, and deletion of the org's containers.
 * Deployments are async, so `waitForDeployment` polls with exponential backoff.
 */

import { ElizaError, type IAgentRuntime, logger, Service } from "@elizaos/core";
import { CLOUD_CONTAINER_SERVICE_TYPE } from "@elizaos/contracts";
import type {
  CloudCodingContainerService,
  CloudContainer,
  ContainerDeleteResponse,
  ContainerGetResponse,
  ContainerListResponse,
  PromoteVfsToCloudContainerRequest,
  PromoteVfsToCloudContainerResponse,
  RequestCodingAgentContainerRequest,
  RequestCodingAgentContainerResponse,
  SyncCloudCodingContainerRequest,
  SyncCloudCodingContainerResponse,
} from "../types/cloud";
import { type CloudApiClient, CloudApiError } from "../utils/cloud-api";
import type { CloudAuthService } from "./cloud-auth";

/** `runtime.reportError` scope for deployment-polling failures. */
const POLL_ERROR_SCOPE = "CloudContainerService.deploymentPolling";
/** `runtime.reportError` scope for failures to load the existing containers. */
const LOAD_ERROR_SCOPE = "CloudContainerService.loadExisting";
const LOAD_RETRY_BASE_MS = 30_000;
const LOAD_RETRY_MAX_MS = 10 * 60_000;

/** Active containers tracked locally for quick access. */
interface TrackedContainer {
  container: CloudContainer;
  pollingTimer: ReturnType<typeof setTimeout> | null;
}

export class CloudContainerService
  extends Service
  implements CloudCodingContainerService
{
  static serviceType = CLOUD_CONTAINER_SERVICE_TYPE;
  capabilityDescription = "ElizaCloud container provisioning and lifecycle management";

  private authService!: CloudAuthService;
  private tracked: Map<string, TrackedContainer> = new Map();
  private loadRetryTimer: ReturnType<typeof setTimeout> | null = null;
  private stopped = false;

  static async start(runtime: IAgentRuntime): Promise<Service> {
    const service = new CloudContainerService(runtime);
    await service.initialize();
    return service;
  }

  async stop(): Promise<void> {
    this.stopped = true;
    if (this.loadRetryTimer) clearTimeout(this.loadRetryTimer);
    this.loadRetryTimer = null;
    for (const [, tracked] of this.tracked) {
      if (tracked.pollingTimer) clearTimeout(tracked.pollingTimer);
    }
    this.tracked.clear();
  }

  private async initialize(): Promise<void> {
    // Get auth service reference
    const auth = this.runtime.getService("CLOUD_AUTH");
    if (!auth) {
      logger.debug(
        "[CloudContainer] CloudAuthService not available, container operations will fail"
      );
      return;
    }
    this.authService = auth as CloudAuthService;

    if (this.authService.isAuthenticated()) await this.loadExistingContainers(1);
  }

  /**
   * Track the containers that already exist and resume polling the ones still
   * deploying. A failure (Cloud unreachable, a key that is replaced later) must
   * not fail service start: the service would stay unregistered until restart.
   * It is reported and retried with backoff instead.
   */
  private async loadExistingContainers(attempt: number): Promise<void> {
    this.loadRetryTimer = null;
    let containers: CloudContainer[];
    try {
      containers = await this.listContainers();
    } catch (error) {
      // error-policy:J1 boot and timer boundary: report, then retry.
      if (this.stopped) return;
      const nextLoadInMs = Math.min(
        LOAD_RETRY_BASE_MS * 2 ** (attempt - 1),
        LOAD_RETRY_MAX_MS
      );
      this.runtime.reportError(
        LOAD_ERROR_SCOPE,
        new ElizaError(
          `Loading existing cloud containers failed: ${
            error instanceof Error ? error.message : String(error)
          }`,
          {
            code: "CLOUD_CONTAINER_LOAD_FAILED",
            severity: "ephemeral",
            cause: error,
            context: { attempt, nextLoadInMs },
          }
        )
      );
      this.loadRetryTimer = setTimeout(() => {
        void this.loadExistingContainers(attempt + 1);
      }, nextLoadInMs);
      return;
    }
    if (this.stopped) return;
    for (const container of containers) {
      // A container created or tracked while a retry was pending keeps its entry.
      if (this.tracked.has(container.id)) continue;
      this.tracked.set(container.id, {
        container,
        pollingTimer: null,
      });

      // Resume polling for containers that are still deploying
      if (
        container.status === "pending" ||
        container.status === "building" ||
        container.status === "deploying"
      ) {
        this.startPolling(container.id);
      }
    }
    logger.info(`[CloudContainer] Loaded ${containers.length} existing container(s)`);
  }

  private getClient(): CloudApiClient {
    return this.authService.getClient();
  }

  // ─── CRUD ───────────────────────────────────────────────────────────────

  async listContainers(): Promise<CloudContainer[]> {
    const client = this.getClient();
    const response = await client.requestData<ContainerListResponse>(
      "GET",
      "/containers",
    );
    return response.data;
  }

  async getContainer(containerId: string): Promise<CloudContainer> {
    const client = this.getClient();
    const response = await client.requestData<ContainerGetResponse>(
      "GET",
      `/containers/${containerId}`,
    );

    // Update local tracking
    const existing = this.tracked.get(containerId);
    if (existing) {
      existing.container = response.data;
    }

    return response.data;
  }

  async deleteContainer(containerId: string): Promise<void> {
    const client = this.getClient();
    await client.delete<ContainerDeleteResponse>(`/containers/${containerId}`);

    // Stop tracking
    const tracked = this.tracked.get(containerId);
    if (tracked) {
      if (tracked.pollingTimer) clearTimeout(tracked.pollingTimer);
      this.tracked.delete(containerId);
    }

    logger.info(`[CloudContainer] Deleted container ${containerId}`);
  }

  // ─── Deployment Polling ────────────────────────────────────────────────

  /**
   * Poll container status until it reaches a terminal state (running, failed, stopped).
   * Uses exponential backoff: 5s, 10s, 20s, 30s, 30s, ...
   *
   * A retryable status-fetch failure consumes one attempt and re-arms on the
   * same backoff; a permanent one (authorization, not-found, other client
   * errors) ends the chain. Both are reported through `runtime.reportError`.
   */
  private startPolling(containerId: string): void {
    const tracked = this.tracked.get(containerId);
    if (!tracked) return;

    let attempt = 0;
    const maxAttempts = 120; // ~1 hour with backoff
    const baseInterval = 5_000;
    const maxInterval = 30_000;

    // stop() and deleteContainer() clear the pending timer and drop the entry,
    // but cannot cancel a poll already awaiting the API. Once that request
    // settles, the poll must not reschedule or report for an entry that is no
    // longer the tracked one.
    const stillTracked = (): boolean => {
      if (this.tracked.get(containerId) === tracked) return true;
      logger.debug(
        `[CloudContainer] Poll #${attempt} for ${containerId} settled after polling stopped; not rescheduling`
      );
      return false;
    };

    const poll = async () => {
      attempt++;
      if (attempt > maxAttempts) {
        this.runtime.reportError(
          POLL_ERROR_SCOPE,
          new ElizaError(
            `Deployment polling for container ${containerId} stopped after ${maxAttempts} attempts without a terminal status`,
            {
              code: "CLOUD_CONTAINER_POLL_TIMEOUT",
              severity: "fatal",
              context: {
                containerId,
                attempts: maxAttempts,
                lastObservedStatus: tracked.container.status,
              },
            }
          )
        );
        return;
      }

      // Backoff for the next poll; computed once so the retry branch below
      // re-arms on exactly the schedule a successful poll would have used.
      const delay = Math.min(baseInterval * 2 ** Math.min(attempt - 1, 3), maxInterval);

      let container: CloudContainer;
      try {
        container = await this.getContainer(containerId);
      } catch (error) {
        // error-policy:J1 boundary translation — this timer callback is the
        // outermost frame of the polling job and nothing awaits it, so a failed
        // status fetch becomes a runtime.reportError report plus an explicit
        // retry-or-stop decision instead of an unhandled rejection that
        // silently ends the chain.
        if (!stillTracked()) return;
        const retryable = isRetryablePollFailure(error);
        const statusCode = error instanceof CloudApiError ? error.statusCode : null;
        this.runtime.reportError(
          POLL_ERROR_SCOPE,
          new ElizaError(
            `Status poll #${attempt} for container ${containerId} failed: ${
              error instanceof Error ? error.message : String(error)
            }`,
            {
              code: retryable ? "CLOUD_CONTAINER_POLL_RETRYABLE" : "CLOUD_CONTAINER_POLL_REJECTED",
              severity: retryable ? "ephemeral" : "fatal",
              cause: error,
              context: {
                containerId,
                attempt,
                maxAttempts,
                statusCode,
                nextPollInMs: retryable ? delay : null,
              },
            }
          )
        );
        if (retryable) tracked.pollingTimer = setTimeout(poll, delay);
        return;
      }
      if (!stillTracked()) return;
      const status = container.status;

      logger.debug(`[CloudContainer] Poll #${attempt} for ${containerId}: status=${status}`);

      if (status === "running") {
        logger.info(
          `[CloudContainer] Container ${containerId} is now running at ${container.load_balancer_url}`
        );
        return;
      }

      if (status === "failed" || status === "stopped" || status === "suspended") {
        logger.warn(`[CloudContainer] Container ${containerId} reached terminal state: ${status}`);
        if (container.error_message) {
          logger.error(`[CloudContainer] Error: ${container.error_message}`);
        }
        return;
      }

      // Schedule next poll with exponential backoff
      tracked.pollingTimer = setTimeout(poll, delay);
    };

    tracked.pollingTimer = setTimeout(poll, baseInterval);
  }

  /**
   * Wait for a container to reach "running" status. Returns the updated container.
   * This is the synchronous API for actions that need to block.
   */
  async waitForDeployment(containerId: string, timeoutMs = 900_000): Promise<CloudContainer> {
    const deadline = Date.now() + timeoutMs;
    let interval = 5_000;
    const maxInterval = 30_000;

    while (Date.now() < deadline) {
      const container = await this.getContainer(containerId);

      if (container.status === "running") return container;
      if (container.status === "failed") {
        throw new Error(
          `Container deployment failed: ${container.error_message ?? "unknown error"}`
        );
      }
      if (container.status === "stopped" || container.status === "suspended") {
        throw new Error(`Container reached terminal state: ${container.status}`);
      }

      await new Promise((resolve) => setTimeout(resolve, interval));
      interval = Math.min(interval * 1.5, maxInterval);
    }

    throw new Error(`Container deployment timed out after ${Math.round(timeoutMs / 1000)}s`);
  }

  // ─── Coding Containers / VFS Promotion ────────────────────────────────

  async promoteVfsToCloudContainer(
    request: PromoteVfsToCloudContainerRequest,
  ): Promise<PromoteVfsToCloudContainerResponse> {
    if (!this.isAuthenticated()) {
      throw cloudCodingUnavailable("Cloud auth is not connected");
    }

    try {
      return await this.getClient().requestData<PromoteVfsToCloudContainerResponse>(
        "POST",
        "/coding-containers/promotions",
        { json: request },
      );
    } catch (error) {
      if (isMissingCloudCodingEndpoint(error)) {
        throw cloudCodingUnavailable(
          "Eliza Cloud coding-container promotion endpoint is not deployed yet",
        );
      }
      throw error;
    }
  }

  async requestCodingAgentContainer(
    request: RequestCodingAgentContainerRequest,
  ): Promise<RequestCodingAgentContainerResponse> {
    if (!this.isAuthenticated()) {
      throw cloudCodingUnavailable("Cloud auth is not connected");
    }

    try {
      return await this.getClient().requestData<RequestCodingAgentContainerResponse>(
        "POST",
        "/coding-containers",
        { json: request },
      );
    } catch (error) {
      if (isMissingCloudCodingEndpoint(error)) {
        throw cloudCodingUnavailable(
          "Eliza Cloud coding-container endpoint is not deployed yet",
        );
      }
      throw error;
    }
  }

  async syncCodingContainerChanges(
    containerId: string,
    request: SyncCloudCodingContainerRequest,
  ): Promise<SyncCloudCodingContainerResponse> {
    if (!this.isAuthenticated()) {
      throw cloudCodingUnavailable("Cloud auth is not connected");
    }

    try {
      return await this.getClient().requestData<SyncCloudCodingContainerResponse>(
        "POST",
        `/coding-containers/${encodeURIComponent(containerId)}/sync`,
        { json: request },
      );
    } catch (error) {
      if (isMissingCloudCodingEndpoint(error)) {
        throw cloudCodingUnavailable(
          "Eliza Cloud coding-container sync endpoint is not deployed yet",
        );
      }
      throw error;
    }
  }

  // ─── Accessors ─────────────────────────────────────────────────────────

  getTrackedContainers(): CloudContainer[] {
    return Array.from(this.tracked.values()).map((t) => t.container);
  }

  getTrackedContainer(containerId: string): CloudContainer | undefined {
    return this.tracked.get(containerId)?.container;
  }

  isContainerRunning(containerId: string): boolean {
    return this.tracked.get(containerId)?.container.status === "running";
  }

  getContainerUrl(containerId: string): string | null {
    return this.tracked.get(containerId)?.container.load_balancer_url ?? null;
  }

  private isAuthenticated(): boolean {
    return this.authService?.isAuthenticated?.() === true;
  }
}

/**
 * Whether a failed status fetch can succeed on a later poll. Transport failures
 * (no HTTP response) and 408/425/429/5xx are transient; every other HTTP status
 * — 401/403 authorization, 402 credits, 404 not-found, other client errors —
 * fails identically on each retry.
 */
function isRetryablePollFailure(error: unknown): boolean {
  if (!(error instanceof CloudApiError)) return true;
  const { statusCode } = error;
  return statusCode === 408 || statusCode === 425 || statusCode === 429 || statusCode >= 500;
}

function isMissingCloudCodingEndpoint(error: unknown): boolean {
  const statusCode =
    typeof (error as { statusCode?: unknown })?.statusCode === "number"
      ? (error as { statusCode: number }).statusCode
      : undefined;
  return statusCode === 404 || statusCode === 501;
}

function cloudCodingUnavailable(message: string): Error & { statusCode: number } {
  const error = new Error(message) as Error & { statusCode: number };
  error.statusCode = 503;
  return error;
}
