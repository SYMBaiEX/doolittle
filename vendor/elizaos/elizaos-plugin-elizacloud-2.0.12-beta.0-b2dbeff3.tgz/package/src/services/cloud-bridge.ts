/**
 * CloudBridgeService — WebSocket bridge to cloud-hosted agents.
 *
 * Establishes a JSON-RPC 2.0 WebSocket connection per container, allowing
 * the local eliza client to send messages to and receive events from
 * cloud-hosted ElizaOS agents. Handles reconnection with exponential
 * backoff and heartbeat keepalive.
 */

import { type IAgentRuntime, logger, Service } from "@elizaos/core";
import { WebSocket } from "undici";
import type {
  BridgeConnection,
  BridgeConnectionState,
  BridgeMessage,
  BridgeMessageHandler,
} from "../types/cloud";
import { DEFAULT_CLOUD_CONFIG } from "../types/cloud";
import type { CloudAuthService } from "./cloud-auth";

interface ActiveConnection {
  ws: WebSocket | null;
  state: BridgeConnectionState;
  connectedAt: number | null;
  lastHeartbeat: number | null;
  reconnectAttempts: number;
  heartbeatTimer: ReturnType<typeof setInterval> | null;
  reconnectTimer: ReturnType<typeof setTimeout> | null;
  handlers: Set<BridgeMessageHandler>;
  pendingRequests: Map<
    string | number,
    {
      resolve: (value: unknown) => void;
      reject: (reason: Error) => void;
      timeout: ReturnType<typeof setTimeout>;
    }
  >;
  nextRequestId: number;
}

function requireWebSocket(conn: ActiveConnection, containerId: string): WebSocket {
  if (!conn.ws) {
    throw new Error(`WebSocket not connected for container ${containerId}`);
  }
  return conn.ws;
}

export class CloudBridgeService extends Service {
  static serviceType = "CLOUD_BRIDGE";
  capabilityDescription = "WebSocket bridge to cloud-hosted ElizaOS agents";

  private authService!: CloudAuthService;
  private readonly bridgeConfig = DEFAULT_CLOUD_CONFIG.bridge;
  private connections: Map<string, ActiveConnection> = new Map();

  static async start(runtime: IAgentRuntime): Promise<Service> {
    const service = new CloudBridgeService(runtime);
    await service.initialize();
    return service;
  }

  async stop(): Promise<void> {
    for (const [containerId] of this.connections) {
      await this.disconnect(containerId);
    }
    logger.info("[CloudBridge] Service stopped");
  }

  private async initialize(): Promise<void> {
    const auth = this.runtime.getService("CLOUD_AUTH");
    if (!auth) {
      logger.debug("[CloudBridge] CloudAuthService not available");
      return;
    }
    this.authService = auth as CloudAuthService;
    logger.info("[CloudBridge] Service initialized");
  }

  // ─── Connection Management ─────────────────────────────────────────────

  async connect(containerId: string): Promise<void> {
    const existing = this.connections.get(containerId);
    if (existing) {
      if (existing.state === "connected" || existing.state === "connecting") {
        logger.debug(`[CloudBridge] Already connected/connecting to ${containerId}`);
        return;
      }
    }

    await this.establishConnection(containerId, 0);
  }

  async disconnect(containerId: string): Promise<void> {
    const conn = this.connections.get(containerId);
    if (!conn) return;

    if (conn.heartbeatTimer) clearInterval(conn.heartbeatTimer);
    if (conn.reconnectTimer) clearTimeout(conn.reconnectTimer);

    // Reject all pending requests
    for (const [, pending] of conn.pendingRequests) {
      clearTimeout(pending.timeout);
      pending.reject(new Error("Bridge disconnected"));
    }
    conn.pendingRequests.clear();

    const ws = conn.ws;
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
      ws.close(1000, "Client disconnect");
    }

    this.connections.delete(containerId);
    logger.info(`[CloudBridge] Disconnected from ${containerId}`);
  }

  private async establishConnection(containerId: string, reconnectAttempts: number): Promise<void> {
    const client = this.authService.getClient();
    const apiKey = this.authService.getApiKey();
    const wsUrl = client.buildWsUrl(`/agent-bridge/${containerId}`);

    // Append API key as query parameter for WebSocket auth
    const authUrl = apiKey ? `${wsUrl}?token=${encodeURIComponent(apiKey)}` : wsUrl;
    const ws = new WebSocket(authUrl);

    const conn: ActiveConnection = {
      ws,
      state: "connecting",
      connectedAt: null,
      lastHeartbeat: null,
      reconnectAttempts,
      heartbeatTimer: null,
      reconnectTimer: null,
      handlers: this.connections.get(containerId)?.handlers ?? new Set(),
      pendingRequests: new Map(),
      nextRequestId: 1,
    };

    this.connections.set(containerId, conn);

    ws.addEventListener("open", () => {
      if (this.connections.get(containerId) !== conn) return;
      conn.state = "connected";
      conn.connectedAt = Date.now();
      conn.reconnectAttempts = 0;
      logger.info(`[CloudBridge] Connected to agent ${containerId}`);

      // Start heartbeat
      conn.heartbeatTimer = setInterval(() => {
        this.sendHeartbeat(containerId);
      }, this.bridgeConfig.heartbeatIntervalMs);
    });

    ws.addEventListener("message", (event) => {
      if (this.connections.get(containerId) !== conn) return;
      const raw = event.data;
      const data =
        typeof raw === "string" ? raw : raw instanceof Buffer ? raw.toString("utf-8") : String(raw);

      const message = this.parseBridgeFrame(containerId, data);
      // A malformed or non-object frame is dropped so one bad frame cannot take
      // down the connection (or, via the host uncaughtException handler, the
      // whole process). See parseBridgeFrame.
      if (!message) return;

      // Handle heartbeat responses
      if (message.method === "heartbeat.ack") {
        conn.lastHeartbeat = Date.now();
        return;
      }

      // Handle responses to pending requests
      if (message.id !== undefined && !message.method) {
        const pending = conn.pendingRequests.get(message.id);
        if (pending) {
          clearTimeout(pending.timeout);
          conn.pendingRequests.delete(message.id);
          if (message.error) {
            pending.reject(new Error(message.error.message));
          } else {
            pending.resolve(message.result);
          }
          return;
        }
      }

      // Dispatch to handlers
      for (const handler of conn.handlers) {
        handler(message);
      }
    });

    ws.addEventListener("close", (event) => {
      // A late close must clean up its own timer without mutating the replacement.
      if (this.connections.get(containerId) !== conn) {
        if (conn.heartbeatTimer) clearInterval(conn.heartbeatTimer);
        return;
      }

      conn.state = "disconnected";
      if (conn.heartbeatTimer) clearInterval(conn.heartbeatTimer);

      // Don't reconnect on clean close
      if (event.code === 1000) {
        logger.info(`[CloudBridge] Clean disconnect from ${containerId}`);
        return;
      }

      logger.warn(
        `[CloudBridge] Connection lost to ${containerId} (code=${event.code}, reason=${event.reason})`
      );
      this.scheduleReconnect(containerId, conn.reconnectAttempts + 1);
    });

    ws.addEventListener("error", () => {
      if (this.connections.get(containerId) !== conn) return;
      logger.error(`[CloudBridge] WebSocket error for ${containerId}`);
    });
  }

  /**
   * Parse an inbound WebSocket frame into a `BridgeMessage`, returning `null`
   * for any frame that is not a JSON object.
   *
   * undici's `WebSocket` is an `EventTarget` subclass, so a throw inside the
   * `"message"` listener is re-raised via `process.nextTick` and surfaces as an
   * `uncaughtException`; the agent host translates that into `process.exit(1)`
   * (`packages/app/src/cli/run-main.ts`). A single non-JSON text frame
   * (protocol drift, a proxy-injected error page, or a misbehaving peer) would
   * therefore kill the entire process, not just the bridge. This is the
   * transport boundary, so an untrusted frame is sanitized here rather than
   * dereferenced blindly.
   */
  private parseBridgeFrame(containerId: string, data: string): BridgeMessage | null {
    let parsed: unknown;
    try {
      parsed = JSON.parse(data);
    } catch (error) {
      // error-policy:J3 untrusted transport frame; an unparseable body is an
      // explicit invalid result (dropped), never a fake-valid message. The
      // frame is peer-controlled and the connect URL carries `?token=<apiKey>`,
      // so a proxy-injected error page echoing that URL must not reach a log:
      // record the error name and byte length, never the raw bytes or the
      // `SyntaxError` message (which itself quotes a slice of the input).
      logger.warn(
        `[CloudBridge] Ignoring malformed frame from ${containerId}: ${
          error instanceof Error ? error.name : "ParseError"
        } (${data.length} bytes)`
      );
      return null;
    }

    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      // error-policy:J3 valid JSON that is not a JSON-RPC object cannot be
      // dereferenced for `method`/`id`; treat it as an invalid frame. Log the
      // JSON shape and byte length only, never the peer-controlled bytes. The
      // shape label special-cases `null` because `typeof null === "object"`
      // would otherwise mislabel a dropped `null` frame as a JSON object.
      logger.warn(
        `[CloudBridge] Ignoring non-object frame from ${containerId}: JSON ${
          parsed === null ? "null" : Array.isArray(parsed) ? "array" : typeof parsed
        } (${data.length} bytes)`
      );
      return null;
    }

    return parsed as BridgeMessage;
  }

  private scheduleReconnect(containerId: string, attempt: number): void {
    if (attempt > this.bridgeConfig.maxReconnectAttempts) {
      logger.error(
        `[CloudBridge] Max reconnect attempts (${this.bridgeConfig.maxReconnectAttempts}) reached for ${containerId}`
      );
      this.connections.delete(containerId);
      return;
    }

    // Exponential backoff with jitter: base * 2^attempt + random jitter
    const base = this.bridgeConfig.reconnectIntervalMs;
    const delay = Math.min(base * 2 ** Math.min(attempt, 5), 120_000);
    const jitter = Math.floor(Math.random() * 1000);

    logger.info(
      `[CloudBridge] Reconnecting to ${containerId} in ${Math.round((delay + jitter) / 1000)}s (attempt ${attempt})`
    );

    const conn = this.connections.get(containerId);
    if (conn) {
      conn.state = "reconnecting";
      conn.reconnectTimer = setTimeout(() => {
        if (this.connections.get(containerId) !== conn) return;
        this.establishConnection(containerId, attempt);
      }, delay + jitter);
    }
  }

  private sendHeartbeat(containerId: string): void {
    const conn = this.connections.get(containerId);
    if (!conn || conn.state !== "connected") return;

    const message: BridgeMessage = {
      jsonrpc: "2.0",
      method: "heartbeat",
      params: { timestamp: Date.now() },
    };

    requireWebSocket(conn, containerId).send(JSON.stringify(message));
  }

  // ─── Messaging ─────────────────────────────────────────────────────────

  /**
   * Send a JSON-RPC request and wait for a response.
   */
  async sendRequest(
    containerId: string,
    method: string,
    params: Record<string, unknown>,
    timeoutMs = 60_000
  ): Promise<unknown> {
    const conn = this.connections.get(containerId);
    if (!conn || conn.state !== "connected") {
      throw new Error(`Not connected to container ${containerId}`);
    }

    const id = conn.nextRequestId++;
    const message: BridgeMessage = {
      jsonrpc: "2.0",
      id,
      method,
      params,
    };

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        conn.pendingRequests.delete(id);
        reject(new Error(`Request ${method} timed out after ${timeoutMs}ms`));
      }, timeoutMs);

      conn.pendingRequests.set(id, { resolve, reject, timeout });
      requireWebSocket(conn, containerId).send(JSON.stringify(message));
    });
  }

  /**
   * Send a one-way notification (no response expected).
   */
  sendNotification(containerId: string, method: string, params: Record<string, unknown>): void {
    const conn = this.connections.get(containerId);
    if (!conn || conn.state !== "connected") {
      throw new Error(`Not connected to container ${containerId}`);
    }

    const message: BridgeMessage = {
      jsonrpc: "2.0",
      method,
      params,
    };

    requireWebSocket(conn, containerId).send(JSON.stringify(message));
  }

  /**
   * Send a chat message to the cloud agent and get the response.
   */
  async sendChatMessage(
    containerId: string,
    text: string,
    roomId?: string,
    metadata?: Record<string, unknown>
  ): Promise<{ text: string; metadata?: Record<string, unknown> }> {
    const result = await this.sendRequest(containerId, "message.send", {
      text,
      roomId,
      metadata,
    });
    return result as { text: string; metadata?: Record<string, unknown> };
  }

  /**
   * Request the cloud agent's current status.
   */
  async getAgentStatus(containerId: string): Promise<Record<string, unknown>> {
    const result = await this.sendRequest(containerId, "status.get", {});
    return result as Record<string, unknown>;
  }

  /**
   * Update the cloud agent's configuration.
   */
  async updateAgentConfig(containerId: string, config: Record<string, unknown>): Promise<void> {
    await this.sendRequest(containerId, "config.update", config);
  }

  // ─── Event Handlers ────────────────────────────────────────────────────

  onMessage(containerId: string, handler: BridgeMessageHandler): () => void {
    let conn = this.connections.get(containerId);
    if (!conn) {
      // Pre-register handler before connection is established
      conn = {
        ws: null,
        state: "disconnected",
        connectedAt: null,
        lastHeartbeat: null,
        reconnectAttempts: 0,
        heartbeatTimer: null,
        reconnectTimer: null,
        handlers: new Set(),
        pendingRequests: new Map(),
        nextRequestId: 1,
      };
      this.connections.set(containerId, conn);
    }

    conn.handlers.add(handler);

    // Return unsubscribe function
    return () => {
      conn.handlers.delete(handler);
    };
  }

  // ─── Accessors ─────────────────────────────────────────────────────────

  getConnectionState(containerId: string): BridgeConnectionState {
    return this.connections.get(containerId)?.state ?? "disconnected";
  }

  getConnectionInfo(containerId: string): BridgeConnection | null {
    const conn = this.connections.get(containerId);
    if (!conn) return null;

    return {
      containerId,
      state: conn.state,
      connectedAt: conn.connectedAt,
      lastHeartbeat: conn.lastHeartbeat,
      reconnectAttempts: conn.reconnectAttempts,
    };
  }

  getConnectedContainerIds(): string[] {
    const ids: string[] = [];
    for (const [id, conn] of this.connections) {
      if (conn.state === "connected") ids.push(id);
    }
    return ids;
  }
}
