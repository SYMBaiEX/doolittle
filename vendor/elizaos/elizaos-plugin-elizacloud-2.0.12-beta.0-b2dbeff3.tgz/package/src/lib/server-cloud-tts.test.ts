/**
 * `/api/tts/cloud` proxy handler (`handleCloudTtsPreviewRoute`) driven with
 * real node req/res fakes and a stubbed upstream fetch. Pins the #16425
 * contract — the client's per-utterance Idempotency-Key is forwarded upstream
 * so the cloud route can replay the direct attempt's committed reservation —
 * plus the handler's auth/validation/success/error envelope, the #16347
 * `ELIZA_TTS_DEBUG` contract (phases observably emitted on the structured
 * logger when the flag is set, silent otherwise), and the proxy fetch abort
 * so a stalled upstream cannot hang the warming `for (;;)` loop.
 */
import { _resetCloudSecretsForTesting } from "../cloud-config/cloud-secrets.js";
import { addLogListener, logger } from "@elizaos/core";
import { afterAll } from "vitest";
import { afterEach } from "vitest";
import { beforeEach } from "vitest";
import { describe } from "vitest";
import { expect } from "vitest";
import { handleCloudSttRoute } from "./server-cloud-tts";
import { handleCloudTtsPreviewRoute } from "./server-cloud-tts";
import { test } from "vitest";
import { type LogEntry } from "@elizaos/core";
import { vi } from "vitest";
import http from "node:http";
import { EventEmitter, once } from "node:events";
// The logger freezes its level at module init and the repo test setup defaults
// LOG_LEVEL to "error", which would gate the info-level tts lines (and their
// listener delivery) off. vi.hoisted runs before the imports above evaluate,
// so the logger initializes at "info" — the production default the
// ELIZA_TTS_DEBUG diagnostic is documented against.
vi.hoisted(() => {
    process.env.LOG_LEVEL = "info";
});
const prevApiKey = process.env.ELIZAOS_CLOUD_API_KEY;
const prevConfigPath = process.env.ELIZA_CONFIG_PATH;
const prevTtsDebug = process.env.ELIZA_TTS_DEBUG;
const realFetch = globalThis.fetch;
interface CapturedUpstream {
    url: string;
    headers: Record<string, string>;
    body: unknown;
    signal?: AbortSignal;
}
let upstream: CapturedUpstream[] = [];
let upstreamResponse: () => Response = () => new Response(new Uint8Array([73, 68, 51]), {
    status: 200,
    headers: { "content-type": "audio/mpeg" },
});
function evented<T extends object>(value:T):T & EventEmitter {
    Object.setPrototypeOf(value, EventEmitter.prototype);
    EventEmitter.call(value);
    return value as T & EventEmitter;
}
function fakeReq(body: string, headers: Record<string, string> = {}): http.IncomingMessage {
    const chunks = [Buffer.from(body)];
    return evented({
        headers,
        async *[Symbol.asyncIterator]() {
            for (const chunk of chunks)
                yield chunk;
        },
    }) as unknown as http.IncomingMessage;
}
/**
 * Models the bare agent server after `attachJsonBodyIfPresent`
 * (packages/agent/src/api/runtime-plugin-routes.ts) has already consumed the
 * stream for a JSON request: `req.body`/`req.rawBody` are populated and the
 * underlying stream is drained (iterating it yields zero bytes). #16348.
 */
function fakeReqPreParsed(parsed: Record<string, unknown>, headers: Record<string, string> = {}): http.IncomingMessage {
    return evented({
        headers,
        body: parsed,
        rawBody: JSON.stringify(parsed),
        // Stream already drained upstream → yields nothing on re-read.
        async *[Symbol.asyncIterator]() {
            // no chunks
        },
    }) as unknown as http.IncomingMessage;
}
function fakeRes(): {
    res: http.ServerResponse;
    state: {
        statusCode: number;
        headers: Record<string, string>;
        body: Buffer | string | null;
    };
} {
    const state = {
        statusCode: 0,
        headers: {} as Record<string, string>,
        body: null as Buffer | string | null,
    };
    const res = evented({
        headersSent: false,
        set statusCode(code: number) {
            state.statusCode = code;
        },
        get statusCode() {
            return state.statusCode;
        },
        setHeader(name: string, value: string) {
            state.headers[name.toLowerCase()] = value;
        },
        end(payload?: Buffer | string) {
            state.body = payload ?? null;
        },
    }) as unknown as http.ServerResponse;
    return { res, state };
}
beforeEach(() => {
    _resetCloudSecretsForTesting();
    process.env.ELIZA_CONFIG_PATH = `/tmp/eliza-cloud-tts-test-missing-${process.pid}.json`;
    process.env.ELIZAOS_CLOUD_API_KEY = "test-cloud-key";
    upstream = [];
    upstreamResponse = () => new Response(new Uint8Array([73, 68, 51]), {
        status: 200,
        headers: { "content-type": "audio/mpeg" },
    });
    globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
        upstream.push({
            url: String(input),
            headers: (init?.headers ?? {}) as Record<string, string>,
            body: init?.body instanceof FormData
                ? init.body
                : init?.body
                    ? JSON.parse(String(init.body))
                    : null,
            signal: init?.signal,
        });
        return upstreamResponse();
    }) as typeof fetch;
});
afterAll(() => {
    globalThis.fetch = realFetch;
    _resetCloudSecretsForTesting();
    if (prevApiKey === undefined)
        delete process.env.ELIZAOS_CLOUD_API_KEY;
    else
        process.env.ELIZAOS_CLOUD_API_KEY = prevApiKey;
    if (prevConfigPath === undefined)
        delete process.env.ELIZA_CONFIG_PATH;
    else
        process.env.ELIZA_CONFIG_PATH = prevConfigPath;
    if (prevTtsDebug === undefined)
        delete process.env.ELIZA_TTS_DEBUG;
    else
        process.env.ELIZA_TTS_DEBUG = prevTtsDebug;
});
afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllEnvs();
});
describe("handleCloudTtsPreviewRoute (/api/tts/cloud proxy)", () => {
    test("forwards the client's Idempotency-Key upstream (#16425)", async () => {
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "bill me once" }), {
            "idempotency-key": "utt-abc",
        }), res);
        expect(state.statusCode).toBe(200);
        expect(upstream.length).toBeGreaterThanOrEqual(1);
        expect(upstream[0].headers["Idempotency-Key"]).toBe("utt-abc");
        expect(upstream[0].body).toMatchObject({ text: "bill me once" });
    });
    test("keeps deeply nested stage directions out of the upstream speech request", async () => {
        let nestedDirection = "";
        for (let layer = 0; layer < 12; layer += 1) {
            nestedDirection = `(secret-${layer} ${nestedDirection})`;
        }
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: `Say this. ${nestedDirection} Done.` })), res);
        expect(state.statusCode).toBe(200);
        expect(upstream).toHaveLength(1);
        expect(upstream[0].body).toMatchObject({ text: "Say this. Done." });
        expect(JSON.stringify(upstream[0].body)).not.toContain("secret-");
    });
    test.each(["*", "**"])("keeps deeply nested %s directions out of the upstream speech request", async (marker) => {
        let nestedDirection = `${marker}pause${marker}`;
        for (let layer = 0; layer < 12; layer += 1) {
            nestedDirection = `${marker}secret-${layer} ${nestedDirection} tail-${layer}${marker}`;
        }
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: `Say this. ${nestedDirection} Done.` })), res);
        expect(state.statusCode).toBe(200);
        expect(upstream).toHaveLength(1);
        expect(upstream[0].body).toMatchObject({ text: "Say this. Done." });
        expect(JSON.stringify(upstream[0].body)).not.toContain("secret-");
    });
    test("honors a host pre-parsed JSON body when the stream is already drained (#16348)", async () => {
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReqPreParsed({ text: "pre-parsed on the bare server" }, { "content-type": "application/json" }), res);
        expect(state.statusCode).toBe(200);
        expect(upstream.length).toBeGreaterThanOrEqual(1);
        expect(upstream[0].body).toMatchObject({
            text: "pre-parsed on the bare server",
        });
    });
    test("pre-parsed body still forwards modelId/voiceId and the idempotency key (#16348)", async () => {
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReqPreParsed({ text: "hi", modelId: "m-9", voiceId: "v-3" }, {
            "content-type": "application/json",
            "idempotency-key": "utt-preparsed",
        }), res);
        expect(state.statusCode).toBe(200);
        expect(upstream[0].headers["Idempotency-Key"]).toBe("utt-preparsed");
        expect(upstream[0].body).toMatchObject({ text: "hi" });
    });
    test("no incoming key → no Idempotency-Key header upstream (unchanged shape)", async () => {
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "hi" })), res);
        expect(state.statusCode).toBe(200);
        expect("Idempotency-Key" in upstream[0].headers).toBe(false);
    });
    test("pipes upstream audio back with no-store caching", async () => {
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "hi" })), res);
        expect(state.statusCode).toBe(200);
        expect(state.headers["content-type"]).toBe("audio/mpeg");
        expect(state.headers["cache-control"]).toBe("no-store");
        expect(Buffer.isBuffer(state.body)).toBe(true);
        expect(Array.from(state.body as Buffer)).toEqual([73, 68, 51]);
    });
    test("projects no moderation header from Cloud TTS", async () => {
        upstreamResponse = () => new Response(new Uint8Array([73,68,51]), {headers:{"content-type":"audio/mpeg","X-Eliza-TTS-Moderation":"reviewed","X-Private-Cache-Detail":"never-project-secret"}});
        const {res,state}=fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({text:"hi"})),res);
        expect(state.statusCode).toBe(200);
        expect(state.headers["x-eliza-tts-moderation"]).toBeUndefined();
        expect(state.headers["x-private-cache-detail"]).toBeUndefined();
    });
    test("401 when Eliza Cloud is not connected — no upstream call", async () => {
        delete process.env.ELIZAOS_CLOUD_API_KEY;
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "hi" })), res);
        expect(state.statusCode).toBe(401);
        expect(upstream).toHaveLength(0);
    });
    test("400 on invalid JSON and on missing text — no upstream call", async () => {
        const bad = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq("{not json"), bad.res);
        expect(bad.state.statusCode).toBe(400);
        const missing = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({})), missing.res);
        expect(missing.state.statusCode).toBe(400);
        expect(upstream).toHaveLength(0);
    });
    test("forwards a non-retryable upstream error status and body", async () => {
        upstreamResponse = () => new Response(JSON.stringify({ error: "Insufficient credits" }), {
            status: 402,
            headers: { "content-type": "application/json" },
        });
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "hi" })), res);
        expect(state.statusCode).toBe(402);
        expect(JSON.parse(String(state.body))).toMatchObject({
            error: "Insufficient credits",
        });
    });
    test("retries a warming503 and retains each attempt's own numeric upstream timing before returning audio", async () => {
        const logs=vi.spyOn(logger,"info");
        try {
            let calls = 0;
            upstreamResponse = () => {
                calls++;
                return calls === 1
                    ? Response.json({code:"service_unavailable",details:{retryable:true,retryAfterSeconds:1}},{status:503,headers:{"Server-Timing":'entry_dispatch;dur=9850, cloud_worker;dur=1800, auth;dur=1750;desc="private synthetic speech"',"CF-Ray":"0123456789abcdef-LAX","X-Eliza-Trace-Id":"a".repeat(32)}})
                    : new Response(new Uint8Array([73,68,51]),{status:200,headers:{"content-type":"audio/mpeg","Server-Timing":"entry_dispatch;dur=800, auth;dur=12","CF-Ray":"fedcba9876543210-SJC","X-Eliza-Trace-Id":"b".repeat(32)}});
            };
            vi.useFakeTimers();
            const { res, state } = fakeRes();
            const handled = handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "warm up" })), res);
            await vi.runAllTimersAsync();
            await handled;
            expect(state.statusCode).toBe(200);
            expect(upstream).toHaveLength(2);
            expect(calls).toBe(2);
            const attempts=logs.mock.calls.filter(([value,message])=>message==="[Cloud Speech] proxy timing" && typeof value==="object" && value!==null && "phase" in value && value.phase==="upstream_headers").map(([value])=>value);
            expect(attempts).toHaveLength(2);
            expect(attempts[0]).toMatchObject({status:503,attempt:1,upstreamTraceId:"a".repeat(32),upstreamCfRay:"0123456789abcdef-LAX",upstreamServerTimingMs:{entry_dispatch:9850,cloud_worker:1800,auth:1750}});
            expect(attempts[1]).toMatchObject({status:200,attempt:2,upstreamTraceId:"b".repeat(32),upstreamCfRay:"fedcba9876543210-SJC",upstreamServerTimingMs:{entry_dispatch:800,auth:12}});
            expect(JSON.stringify(attempts)).not.toContain("private synthetic speech");
        } finally { logs.mockRestore(); }
    });
    test("passes an abort signal on the default TTS timeout", async () => {
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "signal me" })), res);
        expect(state.statusCode).toBe(200);
        expect(upstream[0]?.signal).toBeDefined();
        expect(upstream[0]?.signal?.aborted).toBe(false);
    });
    test("aborts a hanging TTS upstream instead of waiting forever", async () => {
        const prevTimeout = process.env.ELIZAOS_CLOUD_TTS_TIMEOUT_MS;
        process.env.ELIZAOS_CLOUD_TTS_TIMEOUT_MS = "50";
        globalThis.fetch = ((input: string | URL | Request, init?: RequestInit) => {
            upstream.push({
                url: String(input),
                headers: (init?.headers ?? {}) as Record<string, string>,
                body: init?.body ? JSON.parse(String(init.body)) : null,
                signal: init?.signal,
            });
            return new Promise<Response>((_resolve, reject) => {
                const signal = init?.signal;
                if (!signal)
                    return;
                const abort = () => reject(signal.reason ?? new DOMException("Aborted", "AbortError"));
                if (signal.aborted)
                    abort();
                else
                    signal.addEventListener("abort", abort, { once: true });
            });
        }) as typeof fetch;
        try {
            const { res, state } = fakeRes();
            await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "do not hang" })), res);
            expect(state.statusCode).toBe(502);
            expect(String(state.body)).toMatch(/aborted|timeout/i);
        }
        finally {
            if (prevTimeout === undefined) {
                delete process.env.ELIZAOS_CLOUD_TTS_TIMEOUT_MS;
            }
            else {
                process.env.ELIZAOS_CLOUD_TTS_TIMEOUT_MS = prevTimeout;
            }
        }
    });
});
describe("handleCloudSttRoute (/api/asr/cloud proxy)", () => {
    test.each([undefined, "cartesia"])("forwards only explicit STT provider opt-in %s and actual model evidence", async (provider) => {
        upstreamResponse = () => Response.json({transcript:"selected speech"}, {headers:{"X-Eliza-STT-Provider":"cartesia", "X-Eliza-STT-Model":"ink-whisper"}});
        const req = fakeReq("RIFF-audio", {"content-type":"audio/wav", ...(provider ? {"x-eliza-stt-provider":provider} : {})});
        const {res,state} = fakeRes();
        await handleCloudSttRoute(req,res);
        expect(state.statusCode).toBe(200);
        expect(upstream).toHaveLength(1);
        expect(upstream[0].body).toBeInstanceOf(FormData);
        const form = upstream[0].body as FormData;
        expect(form.getAll("provider")).toEqual(provider ? ["cartesia"] : []);
        expect(await (form.get("audio") as Blob).text()).toBe("RIFF-audio");
        expect(state.headers["x-eliza-stt-model"]).toBe("ink-whisper");
    });
    test("keeps the existing JSON audio path with an explicit provider opt-in", async () => {
        upstreamResponse = () => Response.json({transcript:"speech"});
        const {res,state} = fakeRes();
        await handleCloudSttRoute(fakeReq(JSON.stringify({audioBase64:Buffer.from("RIFF-audio").toString("base64")}), {"content-type":"application/json", "x-eliza-stt-provider":"cartesia"}),res);
        expect(state.statusCode).toBe(200);
        const form = upstream[0].body as FormData;
        expect(form.getAll("provider")).toEqual(["cartesia"]);
        expect(await (form.get("audio") as Blob).text()).toBe("RIFF-audio");
    });
    test.each(["", "Cartesia", " cartesia ", "whisper", "cartesia, cartesia"])("refuses invalid STT provider header %j before dispatch", async (provider) => {
        const {res,state} = fakeRes();
        await handleCloudSttRoute(fakeReq("RIFF-audio", {"x-eliza-stt-provider":provider}),res);
        expect(state.statusCode).toBe(400);
        expect(upstream).toHaveLength(0);
    });
    test("refuses duplicated STT provider headers", async () => {
        const req = fakeReq("RIFF-audio");
        req.headers["x-eliza-stt-provider"] = ["cartesia", "cartesia"];
        const {res,state} = fakeRes();
        await handleCloudSttRoute(req,res);
        expect(state.statusCode).toBe(400);
        expect(upstream).toHaveLength(0);
    });
    test("does not invent a missing upstream model attestation", async () => {
        upstreamResponse = () => Response.json({transcript:"speech"});
        const {res,state} = fakeRes();
        await handleCloudSttRoute(fakeReq("RIFF-audio", {"x-eliza-stt-provider":"cartesia"}),res);
        expect(state.statusCode).toBe(200);
        expect(state.headers["x-eliza-stt-model"]).toBeUndefined();
        expect(state.headers["x-eliza-stt-provider"]).toBeUndefined();
    });

    test.each([
        ["1", "https://api-staging.eliza.app/api/v1/voice/stt"],
        [undefined, "https://api.eliza.app/api/v1/voice/stt"],
    ])("sends speech to the login environment for dev source %s", async (devSource, expectedUrl) => {
        vi.stubEnv("ELIZA_DEV_SOURCE", devSource);
        vi.stubEnv("ELIZA_DEV_CLOUD_ENV_AUTHORITY", undefined);
        vi.stubEnv("ELIZAOS_CLOUD_BASE_URL", undefined);
        upstreamResponse = () => Response.json({ text: "what time is it" });
        const { res, state } = fakeRes();
        await handleCloudSttRoute(fakeReq("RIFF-audio", { "content-type": "audio/wav" }), res);
        expect(upstream[0].url).toBe(expectedUrl);
        expect(upstream[0].headers.Authorization).toBe("Bearer test-cloud-key");
        expect(state.statusCode).toBe(200);
        expect(JSON.parse(String(state.body))).toEqual({ text: "what time is it" });
    });
    test("retries an explicit cache-warming 503 before returning a transcript", async () => {
        let calls = 0;
        upstreamResponse = () => {
            calls++;
            return calls === 1
                ? new Response(JSON.stringify({
                    code: "service_unavailable",
                    details: { retryable: true, retryAfterSeconds: 1 },
                }), { status: 503 })
                : Response.json({ text: "The quick brown fox." });
        };
        vi.useFakeTimers();
        const { res, state } = fakeRes();
        const handled = handleCloudSttRoute(fakeReq("RIFF-audio", { "content-type": "audio/wav" }), res);
        await vi.runAllTimersAsync();
        await handled;
        expect(state.statusCode).toBe(200);
        expect(JSON.parse(String(state.body))).toEqual({
            text: "The quick brown fox.",
        });
        expect(upstream).toHaveLength(2);
        expect(upstream.every((request) => request.body instanceof FormData)).toBe(true);
    });
    test("does not project TTS moderation receipts onto speech recognition", async () => {
        upstreamResponse=()=>Response.json({text:"hello"},{headers:{"X-Eliza-TTS-Moderation":"approved-hit"}});
        const {res,state}=fakeRes();
        await handleCloudSttRoute(fakeReq("RIFF-audio",{"content-type":"audio/wav"}),res);
        expect(state.statusCode).toBe(200);expect(state.headers["x-eliza-tts-moderation"]).toBeUndefined();
    });
    test("does not retry a non-warming 503", async () => {
        upstreamResponse = () => new Response(JSON.stringify({ error: "Whisper unavailable" }), {
            status: 503,
        });
        const { res, state } = fakeRes();
        await handleCloudSttRoute(fakeReq("RIFF-audio", { "content-type": "audio/wav" }), res);
        expect(state.statusCode).toBe(502);
        expect(upstream).toHaveLength(1);
    });
    test("aborts a hanging STT upstream instead of waiting forever", async () => {
        const prevTimeout = process.env.ELIZAOS_CLOUD_STT_TIMEOUT_MS;
        process.env.ELIZAOS_CLOUD_STT_TIMEOUT_MS = "50";
        globalThis.fetch = ((input: string | URL | Request, init?: RequestInit) => {
            upstream.push({
                url: String(input),
                headers: (init?.headers ?? {}) as Record<string, string>,
                body: init?.body instanceof FormData ? init.body : null,
                signal: init?.signal,
            });
            return new Promise<Response>((_resolve, reject) => {
                const signal = init?.signal;
                if (!signal)
                    return;
                const abort = () => reject(signal.reason ?? new DOMException("Aborted", "AbortError"));
                if (signal.aborted)
                    abort();
                else
                    signal.addEventListener("abort", abort, { once: true });
            });
        }) as typeof fetch;
        try {
            const { res, state } = fakeRes();
            await handleCloudSttRoute(fakeReq("RIFF-audio", { "content-type": "audio/wav" }), res);
            expect(state.statusCode).toBe(502);
            expect(String(state.body)).toMatch(/aborted|timeout/i);
        }
        finally {
            if (prevTimeout === undefined) {
                delete process.env.ELIZAOS_CLOUD_STT_TIMEOUT_MS;
            }
            else {
                process.env.ELIZAOS_CLOUD_STT_TIMEOUT_MS = prevTimeout;
            }
        }
    });
});
// #16347: server-side ELIZA_TTS_DEBUG must actually emit — entries observed on
// the real structured logger's listener stream, driven through the real route.
describe("ELIZA_TTS_DEBUG tracing on /api/tts/cloud", () => {
    let entries: LogEntry[] = [];
    let unsubscribe: (() => void) | null = null;
    const ttsLines = () => entries.filter((entry) => entry.msg.includes("[eliza][tts]"));
    beforeEach(() => {
        entries = [];
        unsubscribe?.();
        unsubscribe = addLogListener((entry) => entries.push(entry));
    });
    afterAll(() => {
        unsubscribe?.();
    });
    test("successful proxy emits proxy → upstream-ok → success phases", async () => {
        process.env.ELIZA_TTS_DEBUG = "1";
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "trace me please" }), {
            "x-elizaos-tts-message-id": "msg-42",
        }), res);
        expect(state.statusCode).toBe(200);
        const phases = ttsLines().map((entry) => entry.msg);
        expect(phases.some((m) => m.includes("[eliza][tts] server:cloud-tts:proxy"))).toBe(true);
        expect(phases.some((m) => m.includes("[eliza][tts] server:cloud-tts:upstream-ok"))).toBe(true);
        expect(phases.some((m) => m.includes("[eliza][tts] server:cloud-tts:success"))).toBe(true);
        // Client correlation header and spoken-text preview ride along.
        expect(phases.some((m) => m.includes("msg-42"))).toBe(true);
        expect(phases.some((m) => m.includes("trace me please"))).toBe(true);
    });
    test("missing cloud key emits a reject phase with the reason", async () => {
        process.env.ELIZA_TTS_DEBUG = "1";
        delete process.env.ELIZAOS_CLOUD_API_KEY;
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "hi" })), res);
        expect(state.statusCode).toBe(401);
        const reject = ttsLines().find((entry) => entry.msg.includes("server:cloud-tts:reject"));
        expect(reject).toBeDefined();
        expect(reject?.msg).toContain("no_api_key");
    });
    test("flag unset → the same successful request emits zero tts lines", async () => {
        delete process.env.ELIZA_TTS_DEBUG;
        const { res, state } = fakeRes();
        await handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({ text: "silent run" })), res);
        expect(state.statusCode).toBe(200);
        expect(ttsLines()).toHaveLength(0);
    });
});


describe("Cloud speech evidence and client lifecycle", () => {
    test.each(["tts", "stt"] as const)("forwards actual %s provider, timing and trace headers only", async (kind) => {
        upstreamResponse = () => new Response(kind === "tts" ? new Uint8Array([73,68,51]) : JSON.stringify({transcript:"synthetic transcript"}), {headers:{
            [`X-Eliza-${kind.toUpperCase()}-Provider`]:"cartesia",
            "Server-Timing":"synthesis;dur=12", "X-Eliza-Trace-Id":"test-trace",
            "X-Request-Id":"test-request", "CF-Ray":"test-ray",
            "Set-Cookie":"private=not-forwarded", "Authorization":"Bearer not-forwarded",
            "X-Eliza-Speech-Provider":"untrusted-normalized-header",
        }});
        const {res,state}=fakeRes();
        await (kind === "tts" ? handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({text:"synthetic speech"})),res) : handleCloudSttRoute(fakeReq("synthetic audio",{"content-type":"audio/wav"}),res));
        expect(state.statusCode).toBe(200);
        expect(state.headers["x-eliza-speech-provider"]).toBe("cartesia");
        expect(state.headers["x-eliza-speech-route"]).toBe("cloud");
        expect(state.headers["server-timing"]).toBe("synthesis;dur=12");
        expect(state.headers["x-eliza-trace-id"]).toBe("test-trace");
        expect(state.headers["x-request-id"]).toBe("test-request");
        expect(state.headers["cf-ray"]).toBe("test-ray");
        expect(state.headers["set-cookie"]).toBeUndefined();
        expect(state.headers.authorization).toBeUndefined();
    });
    test.each(["tts", "stt"] as const)("missing actual %s provider remains unverified", async(kind)=>{
        upstreamResponse=()=>new Response(kind === "tts" ? new Uint8Array([73,68,51]) : JSON.stringify({transcript:"synthetic transcript"}),{headers:{"X-Eliza-Speech-Provider":"cartesia"}});
        const {res,state}=fakeRes();
        await (kind === "tts" ? handleCloudTtsPreviewRoute(fakeReq(JSON.stringify({text:"synthetic speech"})),res) : handleCloudSttRoute(fakeReq("synthetic audio",{"content-type":"audio/wav"}),res));
        expect(state.headers["x-eliza-speech-route"]).toBe("cloud");
        expect(state.headers["x-eliza-speech-provider"]).toBeUndefined();
    });
    async function proxy(kind:"tts"|"stt") {
        let finish!:()=>void, fail!:(error:unknown)=>void, requestClosed!:()=>void, responseClosed!:()=>void;
        const finished=new Promise<void>((resolve,reject)=>{finish=resolve;fail=reject});
        const requestComplete=new Promise<void>(resolve=>{requestClosed=resolve});
        const disconnected=new Promise<void>(resolve=>{responseClosed=resolve});
        const server=http.createServer((req,res)=>{
            req.once("close",requestClosed);res.once("close",responseClosed);
            void (kind === "tts" ? handleCloudTtsPreviewRoute(req,res) : handleCloudSttRoute(req,res)).then(()=>finish(),fail);
        });
        server.listen(0,"127.0.0.1");await once(server,"listening");
        const address=server.address();if(!address||typeof address==="string")throw Error("Fixture port missing");
        let receive!:(value:{status:number;body:Buffer})=>void;
        const received=new Promise<{status:number;body:Buffer}>(resolve=>{receive=resolve});
        const client=http.request({host:"127.0.0.1",port:address.port,method:"POST",headers:{"Content-Type":kind === "tts" ? "application/json" : "audio/wav"}},res=>{const chunks:Buffer[]=[];res.on("data",chunk=>chunks.push(chunk));res.on("end",()=>receive({status:res.statusCode??0,body:Buffer.concat(chunks)}));});
        client.on("error",()=>{});
        client.end(kind === "tts" ? JSON.stringify({text:"synthetic speech"}) : "synthetic audio");
        return {client,received,finished,requestComplete,disconnected,close:async()=>{client.destroy();await new Promise<void>(resolve=>server.close(()=>resolve()));}};
    }
    test.each(["tts", "stt"] as const)("%s client disconnect cancels an in-flight upstream without retry",async(kind)=>{
        let entered!:()=>void, rejectFetch!:(reason:unknown)=>void;const started=new Promise<void>(resolve=>{entered=resolve});let signal:AbortSignal|undefined,calls=0;
        globalThis.fetch=(async(_input,init)=>{calls++;signal=init?.signal??undefined;entered();return new Promise<Response>((_resolve,reject)=>{rejectFetch=reject;signal?.addEventListener("abort",()=>reject(signal?.reason),{once:true});});}) as typeof fetch;
        const active=await proxy(kind);
        try{await started;active.client.destroy();await active.disconnected;expect(signal?.aborted).toBe(true);expect(calls).toBe(1);}
        finally{rejectFetch(Error("fixture cleanup"));await active.finished;await active.close();}
    });
    test.each(["tts", "stt"] as const)("%s normal request EOF does not cancel the upstream or successful response",async(kind)=>{
        let entered!:()=>void,release!:(response:Response)=>void;const started=new Promise<void>(resolve=>{entered=resolve});let signal:AbortSignal|undefined;
        globalThis.fetch=(async(_input,init)=>{signal=init?.signal??undefined;entered();return new Promise<Response>(resolve=>{release=resolve});}) as typeof fetch;
        const active=await proxy(kind);
        try{await started;await active.requestComplete;expect(signal?.aborted).toBe(false);release(new Response(kind === "tts"?new Uint8Array([73,68,51]):JSON.stringify({transcript:"synthetic transcript"})));expect((await active.received).status).toBe(200);await active.finished;expect(signal?.aborted).toBe(false);}
        finally{release(new Response("fixture cleanup"));await active.finished;await active.close();}
    });
    test("disconnect interrupts warming backoff without another paid attempt",async()=>{
        vi.useFakeTimers();upstreamResponse=()=>Response.json({error:{code:"auth_cache_warming",retryAfter:3}},{status:503});
        const req=fakeReq(JSON.stringify({text:"synthetic speech"})),{res}=fakeRes();
        const pending=handleCloudTtsPreviewRoute(req,res);
        await vi.advanceTimersByTimeAsync(10);expect(upstream.length).toBe(1);
        res.emit("close");await vi.runAllTimersAsync();await pending;
        expect(upstream.length).toBe(1);
    });
});
