/**
 * Eliza Cloud route plugin — registers `/api/cloud/*` route handlers with the
 * elizaOS runtime plugin route system.
 *
 * All routes use `rawPath: true` to preserve the legacy `/api/cloud/*` paths
 * without a plugin-name prefix. This module is node-only — the main plugin
 * (services, actions, providers, model handlers) lives in `index.node.ts`
 * and is browser-safe; this `plugin.ts` is loaded only on the server via
 * `register-routes.ts`.
 *
 * Migrated from packages/app/src/api/cloud-routes.ts and
 * cloud-status-routes.ts. The login/persist, login/status and disconnect
 * paths each carry a small loopback-PUT that previously lived inline in
 * server.ts; that orchestration moved here so server.ts no longer needs
 * to import the cloud handlers directly.
 */
import type http from "node:http";
import { getRuntimeRouteHostContext } from "@elizaos/host/protocol";
import { handleCloudBillingRoute } from "./routes/cloud-billing-routes";
import { handleCloudRoute } from "./routes/cloud-routes";
import { handleCloudStatusRoutes } from "./routes/cloud-status-routes";
import { handleCloudWarmRoute } from "./routes/cloud-warm-route";
import { ELIZA_CLOUD_STT_MAX_JSON_BODY_BYTES } from "./lib/server-cloud-tts";
import { handleCloudSttRoute } from "./lib/server-cloud-tts";
import { handleCloudTtsPreviewRoute } from "./lib/server-cloud-tts";
import { handleXRelayRoute } from "./routes/x-relay-routes";
import { logger } from "@elizaos/core";
import { sendJson } from "./lib/http";
import { type CloudBillingRouteState } from "./routes/cloud-billing-routes";
import { type CloudRouteState } from "./routes/cloud-routes";
import { type ElizaConfig } from "./lib/config-like";
import { type HttpPlugin as Plugin } from "@elizaos/host/protocol";
import { type Route } from "@elizaos/host/protocol";
import { type XRelayRouteState } from "./routes/x-relay-routes";
type AnyRuntime = Parameters<typeof handleCloudStatusRoutes>[0]["runtime"];
function getHostContext(runtime: unknown) {
    return getRuntimeRouteHostContext<Record<string, unknown>>(runtime && typeof runtime === "object" ? runtime : null);
}
function getRuntimeConfig(runtime: unknown): ElizaConfig {
    return (getHostContext(runtime)?.config ?? {}) as ElizaConfig;
}
function makeStatusHandler() {
    return async (req: unknown, res: unknown, runtime: unknown): Promise<void> => {
        const httpReq = req as http.IncomingMessage;
        const httpRes = res as http.ServerResponse;
        const url = new URL(httpReq.url ?? "/", "http://localhost");
        const method = (httpReq.method ?? "GET").toUpperCase();
        const runtimeRef = runtime as AnyRuntime;
        const config = getRuntimeConfig(runtime);
        await handleCloudStatusRoutes({
            req: httpReq,
            res: httpRes,
            method,
            pathname: url.pathname,
            config,
            runtime: runtimeRef,
            json: (_res, body, status = 200) => {
                sendJson(httpRes, body, status);
            },
        });
    };
}
/**
 * Generic handler for the rest of `/api/cloud/*` (login, disconnect,
 * relay-status, …).  Carries the post-dispatch loopback sync that
 * previously lived inline in server.ts.
 */
function makeCloudRouteHandler() {
    return async (req: unknown, res: unknown, runtime: unknown): Promise<void> => {
        const httpReq = req as http.IncomingMessage;
        const httpRes = res as http.ServerResponse;
        const url = new URL(httpReq.url ?? "/", "http://localhost");
        const method = (httpReq.method ?? "GET").toUpperCase();
        const hostContext = getHostContext(runtime);
        if (!hostContext?.config) {
            logger.warn("[eliza-cloud-routes] host config unavailable");
        }
        const config = (hostContext?.config ?? {}) as ElizaConfig;
        const cloudState: CloudRouteState = {
            config,
            runtime: runtime as CloudRouteState["runtime"],
            cloudManager: null,
            restartRuntime: hostContext?.restartRuntime,
            services: {
                createIntegrationTelemetrySpan: hostContext?.createTelemetrySpan,
                saveElizaConfig: (nextConfig) => {
                    hostContext?.saveConfig?.(nextConfig as Record<string, unknown>);
                },
            },
        };
        const handled = await handleCloudRoute(httpReq, httpRes, url.pathname, method, cloudState);
        if (!handled) {
            return;
        }
    };
}
function makeBillingRouteHandler() {
    return async (req: unknown, res: unknown, runtime: unknown): Promise<void> => {
        const httpReq = req as http.IncomingMessage;
        const httpRes = res as http.ServerResponse;
        const url = new URL(httpReq.url ?? "/", "http://localhost");
        const method = (httpReq.method ?? "GET").toUpperCase();
        const hostContext = getHostContext(runtime);
        const state: CloudBillingRouteState = {
            config: (hostContext?.config ?? {}) as ElizaConfig,
            runtime: runtime as CloudBillingRouteState["runtime"],
        };
        await handleCloudBillingRoute(httpReq, httpRes, url.pathname, method, state);
    };
}
function makeXRelayRouteHandler() {
    return async (req: unknown, res: unknown, runtime: unknown): Promise<void> => {
        const httpReq = req as http.IncomingMessage;
        const httpRes = res as http.ServerResponse;
        const url = new URL(httpReq.url ?? "/", "http://localhost");
        const method = (httpReq.method ?? "GET").toUpperCase();
        const hostContext = getHostContext(runtime);
        const state: XRelayRouteState = {
            config: (hostContext?.config ?? {}) as ElizaConfig,
            runtime: runtime as XRelayRouteState["runtime"],
        };
        await handleXRelayRoute(httpReq, httpRes, url.pathname, method, state);
    };
}
const cloudStatusHandler = makeStatusHandler();
const cloudRouteHandler = makeCloudRouteHandler();
const cloudBillingRouteHandler = makeBillingRouteHandler();
const xRelayRouteHandler = makeXRelayRouteHandler();
async function cloudTtsPreviewHandler(req: unknown, res: unknown): Promise<void> {
    await handleCloudTtsPreviewRoute(req as http.IncomingMessage, res as http.ServerResponse);
}
async function cloudSttHandler(req: unknown, res: unknown): Promise<void> {
    await handleCloudSttRoute(req as http.IncomingMessage, res as http.ServerResponse);
}
const cloudRoutes: Route[] = [
    // Status surface (read-only). Note: server.ts may exempt this from auth on
    // cloud-provisioned containers BEFORE the plugin route system fires.
    {
        type: "GET",
        path: "/api/cloud/status",
        rawPath: true,
        handler: cloudStatusHandler,
    },
    {
        type: "GET",
        path: "/api/cloud/credits",
        rawPath: true,
        handler: cloudStatusHandler,
    },
    // Pre-warm: one no-credential OPTIONS to the Cloud chat/completions URL.
    {
        type: "POST",
        path: "/api/cloud/warm",
        rawPath: true,
        handler: handleCloudWarmRoute,
    },
    {
        type: "GET",
        path: "/api/cloud/relay-status",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/coding-containers/promotions",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/coding-containers",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/coding-containers/:containerId/sync",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/tts/cloud",
        rawPath: true,
        modes: ["local", "cloud", "remote"],
        modeReason: "cloud TTS preview — hidden in local-only",
        handler: cloudTtsPreviewHandler,
    },
    {
        type: "POST",
        path: "/api/asr/cloud",
        rawPath: true,
        maxBodyBytes: ELIZA_CLOUD_STT_MAX_JSON_BODY_BYTES,
        modes: ["local", "cloud", "remote"],
        modeReason: "cloud STT proxy — no cloud account in local-only",
        handler: cloudSttHandler,
    },
    ...(["GET", "POST", "PUT", "PATCH", "DELETE"] as const).map((type) => ({
        type,
        path: "/api/cloud/billing/:path*",
        rawPath: true,
        handler: cloudBillingRouteHandler,
    })),
    // X relay proxy (LifeOps X → Cloud). All methods are registered so the
    // handler owns the 405 for non-GET/POST, matching the billing surface and
    // the former host-dispatch special-case behavior byte-for-byte.
    ...(["GET", "POST", "PUT", "PATCH", "DELETE"] as const).map((type) => ({
        type,
        path: "/api/cloud/x/:path*",
        rawPath: true,
        handler: xRelayRouteHandler,
    })),
    {
        type: "POST",
        path: "/api/cloud/disconnect",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/login",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/login/persist",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "GET",
        path: "/api/cloud/login/status",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/coding-containers/promotions",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/coding-containers",
        rawPath: true,
        handler: cloudRouteHandler,
    },
    {
        type: "POST",
        path: "/api/cloud/coding-containers/:containerId/sync",
        rawPath: true,
        handler: cloudRouteHandler,
    },
];
export const elizaCloudRoutePlugin: Plugin = {
    name: "@elizaos/plugin-elizacloud:routes",
    description: "Eliza Cloud connection, login, status, credit, and relay routes (extracted from app/server.ts)",
    routes: cloudRoutes,
    // Routes-only plugin — no services or persistent resources to dispose.
    dispose: async (_runtime) => { },
};
export default elizaCloudRoutePlugin;
