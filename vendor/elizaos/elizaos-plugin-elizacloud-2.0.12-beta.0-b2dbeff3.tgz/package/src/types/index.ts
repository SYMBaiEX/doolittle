export interface OpenAITranscriptionParams {
  audio: Blob | File | Buffer;
  model?: string;
  language?: string;
  response_format?: string;
  prompt?: string;
  temperature?: number;
  timestampGranularities?: string[];
  mimeType?: string;
}

export interface OpenAITextToSpeechParams {
  text: string;
  model?: string;
  voice?: string;
  format?: "mp3" | "wav" | "flac" | string;
  instructions?: string;
  signal?: AbortSignal;
}

export interface ImageDescriptionResult {
  title: string;
  description: string;
}

export interface OpenAIConfig {
  apiKey?: string;
  baseURL?: string;
  embeddingApiKey?: string;
  embeddingURL?: string;
  smallModel?: string;
  largeModel?: string;
  imageDescriptionModel?: string;
  embeddingModel?: string;
  embeddingDimensions?: number;
}

// Re-export all cloud types
export type {
  BridgeConnection,
  BridgeConnectionState,
  BridgeError,
  BridgeMessage,
  BridgeMessageHandler,
  CloudApiErrorBody,
  CloudCodingAgent,
  CloudCodingContainerSession,
  CloudCodingContainerStatus,
  CloudCodingPatch,
  CloudCodingPatchFormat,
  CloudCodingPromotion,
  CloudCodingSyncDirection,
  CloudCodingSyncResult,
  CloudContainer,
  CloudCredentials,
  CloudPluginConfig,
  CloudVfsBundle,
  CloudVfsDeletedFile,
  CloudVfsFile,
  CloudVfsFileEncoding,
  CloudVfsSourceKind,
  ContainerArchitecture,
  ContainerBillingStatus,
  ContainerDeleteResponse,
  ContainerGetResponse,
  ContainerListResponse,
  ContainerStatus,
  CreditSummaryResponse,
  CreditTransaction,
  GatewayRelayRequest,
  GatewayRelayRequestEnvelope,
  GatewayRelayResponse,
  GatewayRelaySession,
  InferenceMode,
  PollGatewayRelayResponse,
  PromoteVfsToCloudContainerRequest,
  PromoteVfsToCloudContainerResponse,
  RegisterGatewayRelaySessionResponse,
  RequestCodingAgentContainerRequest,
  RequestCodingAgentContainerResponse,
  SyncCloudCodingContainerRequest,
  SyncCloudCodingContainerResponse,
} from "./cloud";

export {
  CloudApiError,
  DEFAULT_CLOUD_CONFIG,
  InsufficientCreditsError,
} from "./cloud";
