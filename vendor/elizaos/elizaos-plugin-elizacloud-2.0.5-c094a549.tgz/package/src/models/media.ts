import type {
  AudioProcessingParams,
  IAgentRuntime,
  JsonValue,
  VideoProcessingParams,
} from "@elizaos/core";
import { logger } from "@elizaos/core";
import { resolveCloudTimeoutMs } from "../utils/config";
import { createElizaCloudClient } from "../utils/sdk-client";

interface CloudMediaClient {
  routes: {
    postApiV1GenerateVideo<T = unknown>(options: {
      json: Record<string, unknown>;
      signal?: AbortSignal;
      timeoutMs?: number;
    }): Promise<T>;
    postApiV1GenerateMusic<T = unknown>(options: {
      json: Record<string, unknown>;
      signal?: AbortSignal;
      timeoutMs?: number;
    }): Promise<T>;
  };
}

type CloudMediaClientFactory = (runtime: IAgentRuntime) => CloudMediaClient;

let cloudMediaClientFactory: CloudMediaClientFactory = (runtime) =>
  createElizaCloudClient(runtime) as CloudMediaClient;

export function setCloudMediaClientFactoryForTesting(
  factory: CloudMediaClientFactory | null,
): void {
  cloudMediaClientFactory =
    factory ??
    ((runtime) => createElizaCloudClient(runtime) as CloudMediaClient);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringValue(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function numberValue(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value)
    ? value
    : undefined;
}

function booleanValue(value: unknown): boolean | undefined {
  return typeof value === "boolean" ? value : undefined;
}

type CloudMediaModelResult = Record<string, JsonValue>;

function cleanRecord(
  record: Record<string, JsonValue | undefined>,
): CloudMediaModelResult {
  return Object.fromEntries(
    Object.entries(record).filter(([, value]) => value !== undefined),
  ) as CloudMediaModelResult;
}

interface CloudVideoResponse {
  success?: boolean;
  id?: string;
  requestId?: string;
  video?: {
    url?: string;
    content_type?: string;
    width?: number;
    height?: number;
  };
  seed?: number;
}

/**
 * Retry a media call twice on the cloud's typed transient refusal
 * (`service_unavailable`: the admission Durable Object or primary was briefly
 * unreachable). Any other error fails fast.
 */
async function retryMediaWarming<T>(
  fn: () => Promise<T>,
  label: string,
): Promise<T> {
  let warmingRetries = 0;
  for (;;) {
    try {
      return await fn();
    } catch (err) {
      const errRecord = err as {
        code?: unknown;
        error?: { code?: unknown; type?: unknown };
      };
      const code = String(
        errRecord?.code ?? errRecord?.error?.code ?? errRecord?.error?.type ?? "",
      );
      const isWarming = code === "service_unavailable";
      if (isWarming && warmingRetries < 2) {
        warmingRetries++;
        logger.warn(
          `[ELIZAOS_CLOUD] ${label} transient unavailability, retry ${warmingRetries}/2...`,
        );
        await new Promise((r) => setTimeout(r, 1500));
        continue;
      }
      throw withCloudFailureDetails(err);
    }
  }
}

/**
 * Recompose a terminal cloud media failure so its message carries the
 * server-attached diagnosis. The cloud's media routes put the actionable
 * context (provider, model, upstream status/code, redacted upstream message)
 * in the error body's `details` while the thrown message stays generic — live
 * matrix sweep 2026-08-16: four video turns failed as bare "Video provider
 * request failed" with the failing provider unknowable from any trajectory.
 * The details are server-side redacted and bounded, so surfacing them is
 * safe; a non-CloudApiError shape passes through untouched.
 */
function withCloudFailureDetails(err: unknown): unknown {
  if (!(err instanceof Error)) return err;
  const body = (err as { errorBody?: unknown }).errorBody;
  if (!isRecord(body)) return err;
  const details = body.details;
  if (!isRecord(details)) return err;
  const parts: string[] = [];
  const provider = stringValue(details.provider);
  const model = stringValue(details.model);
  if (provider) parts.push(`provider=${provider}`);
  if (model) parts.push(`model=${model}`);
  const status = numberValue(details.upstreamStatus);
  const code = stringValue(details.upstreamCode);
  if (status !== undefined || code) {
    parts.push(`upstream=${status ?? "?"}${code ? `/${code}` : ""}`);
  }
  const upstreamMessage = stringValue(details.upstreamMessage);
  if (upstreamMessage) parts.push(upstreamMessage);
  if (parts.length === 0) return err;
  err.message = `${err.message} (${parts.join(" ")})`;
  return err;
}

export async function handleVideoGeneration(
  runtime: IAgentRuntime,
  params: VideoProcessingParams,
): Promise<CloudMediaModelResult> {
  const prompt = stringValue(params.prompt);
  if (!prompt) {
    throw new Error("Cloud video generation requires a prompt");
  }

  const referenceUrl =
    stringValue(params.referenceUrl) ?? stringValue(params.imageUrl);
  const durationSeconds =
    numberValue(params.durationSeconds) ?? numberValue(params.duration);

  logger.log("[ELIZAOS_CLOUD] Using VIDEO model via /generate-video");
  const response = await retryMediaWarming(
    () =>
      cloudMediaClientFactory(
        runtime,
      ).routes.postApiV1GenerateVideo<CloudVideoResponse>({
        json: cleanRecord({
          prompt,
          model: stringValue(params.model),
          referenceUrl,
          durationSeconds,
          resolution: stringValue(params.resolution ?? params.aspectRatio),
          audio: booleanValue(params.audio),
          voiceControl: booleanValue(params.voiceControl),
        }),
        signal: params.signal,
        timeoutMs: resolveCloudTimeoutMs(
          "ELIZAOS_CLOUD_VIDEO_TIMEOUT_MS",
          300_000,
        ),
      }),
    "Video generation",
  );

  const videoUrl = response.video?.url;
  if (!videoUrl) {
    throw new Error("Eliza Cloud video generation returned no video URL");
  }

  return cleanRecord({
    url: videoUrl,
    videoUrl,
    mimeType: response.video?.content_type ?? "video/mp4",
    duration: durationSeconds,
    requestId: response.requestId,
    id: response.id,
    seed: response.seed,
  });
}

interface CloudMusicResponse {
  success?: boolean;
  id?: string;
  requestId?: string;
  status?: string;
  music?: {
    url?: string;
    content_type?: string;
    file_name?: string;
  };
}

export async function handleAudioGeneration(
  runtime: IAgentRuntime,
  params: AudioProcessingParams,
): Promise<CloudMediaModelResult> {
  const kind = stringValue(params.audioKind) ?? "music";
  if (kind !== "music") {
    throw new Error(
      "Eliza Cloud AUDIO generation supports music. Use TEXT_TO_SPEECH for speech or configure a direct SFX provider.",
    );
  }

  const prompt = stringValue(params.prompt ?? params.text);
  if (!prompt) {
    throw new Error("Cloud music generation requires a prompt");
  }

  const durationSeconds =
    numberValue(params.durationSeconds) ?? numberValue(params.duration);

  logger.log("[ELIZAOS_CLOUD] Using AUDIO model via /generate-music");
  const requestJson = cleanRecord({
    prompt,
    model: stringValue(params.model),
    provider: stringValue(params.provider),
    durationSeconds,
    referenceUrl: stringValue(params.referenceUrl ?? params.audioUrl),
    seed: numberValue(params.seed),
    outputFormat: stringValue(params.outputFormat),
    instrumental: booleanValue(params.instrumental),
    extraInput: params.genre ? { genre: params.genre } : undefined,
  });
  const timeoutMs = resolveCloudTimeoutMs(
    "ELIZAOS_CLOUD_MUSIC_TIMEOUT_MS",
    300_000,
  );
  const postMusic = (json: Record<string, JsonValue>) =>
    retryMediaWarming(
      () =>
        cloudMediaClientFactory(
          runtime,
        ).routes.postApiV1GenerateMusic<CloudMusicResponse>({
          json,
          signal: params.signal,
          timeoutMs,
        }),
      "Music generation",
    );
  let response: CloudMusicResponse;
  let outputDurationSeconds = durationSeconds;
  try {
    response = await postMusic(requestJson);
  } catch (err) {
    // error-policy:J2 fixed-price music models 400 with an explicitly
    // machine-actionable hint ("...omit durationSeconds and bill it as a
    // fixed-price generation" — generate-music route). Observed live: "make
    // me a 10 second synthwave loop" set durationSeconds=10 against the
    // default fal-ai/minimax-music model and the whole turn failed. Honour
    // the server's instruction with ONE retry minus the param; any other
    // failure rethrows unchanged.
    const message = err instanceof Error ? err.message : String(err);
    if (
      requestJson.durationSeconds === undefined ||
      !/does not support durationSeconds/i.test(message)
    ) {
      throw err;
    }
    logger.warn(
      "[ELIZAOS_CLOUD] Music model rejects durationSeconds; retrying as a fixed-price generation",
    );
    const { durationSeconds: _omitted, ...fixedPriceJson } = requestJson;
    response = await postMusic(fixedPriceJson);
    outputDurationSeconds = undefined;
  }

  const audioUrl = response.music?.url;
  if (!audioUrl) {
    throw new Error("Eliza Cloud music generation returned no audio URL");
  }

  return cleanRecord({
    url: audioUrl,
    audioUrl,
    mimeType: response.music?.content_type ?? "audio/mpeg",
    title: response.music?.file_name,
    duration: outputDurationSeconds,
    requestId: response.requestId,
    id: response.id,
    status: response.status,
  });
}
