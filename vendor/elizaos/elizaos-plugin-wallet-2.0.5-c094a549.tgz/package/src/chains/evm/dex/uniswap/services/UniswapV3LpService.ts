/**
 * `UniswapV3LpService` implements `IEvmLpService` for Uniswap V3 across
 * Ethereum, Base, Arbitrum, Polygon, and Optimism: concentrated-liquidity
 * pool reads via the factory/pool contracts, and NFT-position mint/decrease/
 * collect/burn writes through the nonfungible position manager, with
 * per-chain RPC clients and ERC-20 approval handled inline.
 */
import { type IAgentRuntime, logger, Service } from "@elizaos/core";
import {
  type Address,
  type Chain,
  createPublicClient,
  createWalletClient,
  http,
  maxUint128,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import * as viemChains from "viem/chains";
import type {
  EvmAddLiquidityParams,
  EvmDex,
  EvmPoolInfo,
  EvmPositionDetails,
  EvmRemoveLiquidityParams,
  EvmTransactionResult,
  IEvmLpService,
} from "../../../../../lp/types.ts";
import {
  ERC20_ABI,
  UNISWAP_V3_ADDRESSES,
  UNISWAP_V3_FACTORY_ABI,
  UNISWAP_V3_FEE_TIERS,
  UNISWAP_V3_POOL_ABI,
  UNISWAP_V3_POSITION_MANAGER_ABI,
  type UniswapV3FeeTier,
  type UniswapV3Position,
} from "../types.ts";
import { minAmountAfterSlippage } from "../../slippage";

const SUPPORTED_CHAIN_IDS = [1, 8453, 42161, 137, 10]; // Ethereum, Base, Arbitrum, Polygon, Optimism

type EvmPublicClient = ReturnType<typeof createPublicClient>;
type EvmWalletClient = ReturnType<typeof createWalletClient>;

function getViemChain(chainId: number): Chain {
  const chainMap: Record<number, Chain> = {
    1: viemChains.mainnet,
    8453: viemChains.base,
    42161: viemChains.arbitrum,
    137: viemChains.polygon,
    10: viemChains.optimism,
  };
  const chain = chainMap[chainId];
  if (!chain) {
    throw new Error(`Unsupported chain ID: ${chainId}`);
  }
  return chain;
}

export class UniswapV3LpService extends Service implements IEvmLpService {
  public static readonly serviceType = "uniswap-v3-lp";
  public readonly capabilityDescription =
    "Provides Uniswap V3 liquidity pool management for EVM chains.";

  private publicClients: Map<number, EvmPublicClient> = new Map();
  private walletClients: Map<string, EvmWalletClient> = new Map();
  private rpcUrls: Map<number, string> = new Map();

  constructor(runtime?: IAgentRuntime) {
    super(runtime);
    if (runtime) {
      this.initializeRpcUrls();
    }
  }

  private initializeRpcUrls(): void {
    const rpcSettings: Record<number, string[]> = {
      1: ["ETHEREUM_RPC_URL", "ETH_RPC_URL", "EVM_PROVIDER_MAINNET"],
      8453: ["BASE_RPC_URL", "EVM_PROVIDER_BASE"],
      42161: ["ARBITRUM_RPC_URL", "EVM_PROVIDER_ARBITRUM"],
      137: ["POLYGON_RPC_URL", "EVM_PROVIDER_POLYGON"],
      10: ["OPTIMISM_RPC_URL", "EVM_PROVIDER_OPTIMISM"],
    };

    for (const [chainId, envKeys] of Object.entries(rpcSettings)) {
      for (const key of envKeys) {
        const rpcUrl = this.runtime.getSetting(key);
        if (rpcUrl && typeof rpcUrl === "string") {
          this.rpcUrls.set(Number(chainId), rpcUrl);
          break;
        }
      }
    }
  }

  private getPublicClient(chainId: number): EvmPublicClient {
    let client = this.publicClients.get(chainId);
    if (client) return client;

    const rpcUrl = this.rpcUrls.get(chainId);
    const chain = getViemChain(chainId);

    client = createPublicClient({
      chain,
      transport: rpcUrl ? http(rpcUrl) : http(),
    });

    this.publicClients.set(chainId, client);
    return client;
  }

  private getWalletClient(
    chainId: number,
    privateKey: `0x${string}`,
  ): EvmWalletClient {
    // Key by chain AND wallet: the cache is per-service (singleton), and
    // addLiquidity/removeLiquidity take a per-call wallet, so keying by
    // chainId alone would return a different wallet's signer (Aerodrome's
    // getWalletClient keys by account.address for the same reason).
    const account = privateKeyToAccount(privateKey);
    const cacheKey = `${chainId}:${account.address}`;
    let client = this.walletClients.get(cacheKey);
    if (client) return client;

    const rpcUrl = this.rpcUrls.get(chainId);
    const chain = getViemChain(chainId);

    client = createWalletClient({
      chain,
      transport: rpcUrl ? http(rpcUrl) : http(),
      account,
    });

    this.walletClients.set(cacheKey, client);
    return client;
  }

  static async start(runtime: IAgentRuntime): Promise<UniswapV3LpService> {
    const service = new UniswapV3LpService(runtime);
    logger.info("[UniswapV3LpService] started");
    return service;
  }

  async stop(): Promise<void> {
    this.publicClients.clear();
    this.walletClients.clear();
    logger.info("[UniswapV3LpService] stopped");
  }

  getDexName(): EvmDex {
    return "uniswap";
  }

  getSupportedChainIds(): number[] {
    return SUPPORTED_CHAIN_IDS.filter((chainId) => UNISWAP_V3_ADDRESSES[chainId] !== undefined);
  }

  supportsChain(chainId: number): boolean {
    return this.getSupportedChainIds().includes(chainId);
  }

  async getPools(
    chainId: number,
    tokenA?: Address,
    tokenB?: Address,
    feeTier?: number
  ): Promise<EvmPoolInfo[]> {
    if (!this.supportsChain(chainId)) {
      logger.warn(`[UniswapV3LpService] Chain ${chainId} not supported`);
      return [];
    }

    const addresses = UNISWAP_V3_ADDRESSES[chainId];
    if (!addresses) return [];

    const client = this.getPublicClient(chainId);
    const pools: EvmPoolInfo[] = [];

    // If specific tokens are provided, look up their pools
    if (tokenA && tokenB) {
      const feeTiers = feeTier
        ? [feeTier as UniswapV3FeeTier]
        : Object.values(UNISWAP_V3_FEE_TIERS);

      for (const fee of feeTiers) {
        try {
          const poolAddress = await client.readContract({
            address: addresses.factory,
            abi: UNISWAP_V3_FACTORY_ABI,
            functionName: "getPool",
            args: [tokenA, tokenB, fee],
          });

          if (poolAddress && poolAddress !== "0x0000000000000000000000000000000000000000") {
            const poolInfo = await this.getPoolInfo(chainId, poolAddress as Address);
            if (poolInfo) {
              pools.push(poolInfo);
            }
          }
        } catch (_error: unknown) {
          logger.debug(`[UniswapV3LpService] No pool found for ${tokenA}/${tokenB} at fee ${fee}`);
        }
      }
    }

    return pools;
  }

  private async getPoolInfo(chainId: number, poolAddress: Address): Promise<EvmPoolInfo | null> {
    const client = this.getPublicClient(chainId);
    const chain = getViemChain(chainId);

    try {
      const [token0, token1, fee, tickSpacing, _liquidity, slot0] = await Promise.all([
        client.readContract({
          address: poolAddress,
          abi: UNISWAP_V3_POOL_ABI,
          functionName: "token0",
        }),
        client.readContract({
          address: poolAddress,
          abi: UNISWAP_V3_POOL_ABI,
          functionName: "token1",
        }),
        client.readContract({
          address: poolAddress,
          abi: UNISWAP_V3_POOL_ABI,
          functionName: "fee",
        }),
        client.readContract({
          address: poolAddress,
          abi: UNISWAP_V3_POOL_ABI,
          functionName: "tickSpacing",
        }),
        client.readContract({
          address: poolAddress,
          abi: UNISWAP_V3_POOL_ABI,
          functionName: "liquidity",
        }),
        client.readContract({
          address: poolAddress,
          abi: UNISWAP_V3_POOL_ABI,
          functionName: "slot0",
        }),
      ]);

      const [symbol0, decimals0, symbol1, decimals1] = await Promise.all([
        client
          .readContract({
            address: token0 as Address,
            abi: ERC20_ABI,
            functionName: "symbol",
          })
          .catch(() => "UNKNOWN"),
        client
          .readContract({
            address: token0 as Address,
            abi: ERC20_ABI,
            functionName: "decimals",
          })
          .catch(() => 18),
        client
          .readContract({
            address: token1 as Address,
            abi: ERC20_ABI,
            functionName: "symbol",
          })
          .catch(() => "UNKNOWN"),
        client
          .readContract({
            address: token1 as Address,
            abi: ERC20_ABI,
            functionName: "decimals",
          })
          .catch(() => 18),
      ]);

      const poolInfo: EvmPoolInfo = {
        id: poolAddress,
        dex: "uniswap",
        chainId,
        chainName: chain.name,
        poolAddress,
        tokenA: {
          address: token0 as Address,
          mint: token0 as Address,
          symbol: symbol0 as string,
          decimals: Number(decimals0),
        },
        tokenB: {
          address: token1 as Address,
          mint: token1 as Address,
          symbol: symbol1 as string,
          decimals: Number(decimals1),
        },
        feeTier: Number(fee),
        tickSpacing: Number(tickSpacing),
        currentTick: Number(slot0[1]),
        sqrtPriceX96: slot0[0] as bigint,
        fee: Number(fee) / 1_000_000, // Convert to percentage
        displayName: `${symbol0}/${symbol1} (${Number(fee) / 10000}%)`,
      };

      return poolInfo;
    } catch (error: unknown) {
      logger.error(
        `[UniswapV3LpService] Error fetching pool info for ${poolAddress}:`,
        error instanceof Error ? error.message : String(error)
      );
      return null;
    }
  }

  async addLiquidity(params: EvmAddLiquidityParams): Promise<EvmTransactionResult> {
    if (!this.supportsChain(params.chainId)) {
      return { success: false, error: `Chain ${params.chainId} not supported` };
    }

    const addresses = UNISWAP_V3_ADDRESSES[params.chainId];
    if (!addresses) {
      return { success: false, error: "Uniswap V3 not deployed on this chain" };
    }

    try {
      const publicClient = this.getPublicClient(params.chainId);
      const walletClient = this.getWalletClient(params.chainId, params.wallet.privateKey);

      const poolInfo = await this.getPoolInfo(params.chainId, params.poolAddress);
      if (!poolInfo) {
        return { success: false, error: "Pool not found" };
      }

      const slippageMultiplier = BigInt(10000 - params.slippageBps);
      const amount0Min = (params.tokenAAmount * slippageMultiplier) / 10000n;
      const amount1Min = ((params.tokenBAmount ?? 0n) * slippageMultiplier) / 10000n;

      await this.approveToken(
        params.chainId,
        params.wallet.privateKey,
        poolInfo.tokenA.address,
        addresses.nonfungiblePositionManager,
        params.tokenAAmount
      );

      if (params.tokenBAmount && params.tokenBAmount > 0n) {
        await this.approveToken(
          params.chainId,
          params.wallet.privateKey,
          poolInfo.tokenB.address,
          addresses.nonfungiblePositionManager,
          params.tokenBAmount
        );
      }

      const deadline = params.deadline ?? BigInt(Math.floor(Date.now() / 1000) + 1800); // 30 min default

      const tickLower = params.tickLower ?? poolInfo.currentTick! - 1000;
      const tickUpper = params.tickUpper ?? poolInfo.currentTick! + 1000;

      // Align ticks to the pool's spacing so the position is valid on-chain.
      const tickSpacing = poolInfo.tickSpacing ?? 60;
      const alignedTickLower = Math.floor(tickLower / tickSpacing) * tickSpacing;
      const alignedTickUpper = Math.ceil(tickUpper / tickSpacing) * tickSpacing;

      const mintParams = {
        token0: poolInfo.tokenA.address,
        token1: poolInfo.tokenB.address,
        fee: poolInfo.feeTier!,
        tickLower: alignedTickLower,
        tickUpper: alignedTickUpper,
        amount0Desired: params.tokenAAmount,
        amount1Desired: params.tokenBAmount ?? 0n,
        amount0Min,
        amount1Min,
        recipient: params.wallet.address,
        deadline,
      };

      const { request } = await publicClient.simulateContract({
        address: addresses.nonfungiblePositionManager,
        abi: UNISWAP_V3_POSITION_MANAGER_ABI,
        functionName: "mint",
        args: [mintParams],
        account: walletClient.account,
      });

      const hash = await walletClient.writeContract(request);

      const receipt = await publicClient.waitForTransactionReceipt({ hash });

      return {
        success: receipt.status === "success",
        transactionId: hash,
        hash,
        chainId: params.chainId,
        blockNumber: receipt.blockNumber,
        gasUsed: receipt.gasUsed,
        data: {
          poolAddress: params.poolAddress,
          tickLower: alignedTickLower,
          tickUpper: alignedTickUpper,
        },
      };
    } catch (error: unknown) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      logger.error("[UniswapV3LpService] Error adding liquidity:", errorMsg);
      return {
        success: false,
        error: errorMsg || "Unknown error adding liquidity",
      };
    }
  }

  async removeLiquidity(params: EvmRemoveLiquidityParams): Promise<EvmTransactionResult> {
    if (!this.supportsChain(params.chainId)) {
      return { success: false, error: `Chain ${params.chainId} not supported` };
    }

    const addresses = UNISWAP_V3_ADDRESSES[params.chainId];
    if (!addresses) {
      return { success: false, error: "Uniswap V3 not deployed on this chain" };
    }

    if (!params.tokenId) {
      return {
        success: false,
        error: "Position token ID required for Uniswap V3",
      };
    }

    try {
      const publicClient = this.getPublicClient(params.chainId);
      const walletClient = this.getWalletClient(params.chainId, params.wallet.privateKey);

      const position = await this.getPositionFromContract(params.chainId, params.tokenId);
      if (!position) {
        return { success: false, error: "Position not found" };
      }

      let liquidityToRemove = position.liquidity;
      if (params.percentageToRemove && params.percentageToRemove < 100) {
        // Basis points, rounded down: BigInt() rejects non-integers, and a
        // fractional percentage must never remove more than requested.
        const percentageBps = BigInt(Math.floor(params.percentageToRemove * 100));
        liquidityToRemove = (position.liquidity * percentageBps) / 10000n;
      }

      const deadline = params.deadline ?? BigInt(Math.floor(Date.now() / 1000) + 1800);

      // Removing liquidity is a two-step position-manager protocol: decrease
      // liquidity first, then collect the freed tokens as a separate call.
      // Quote what the position returns now, then require at least that much
      // minus the confirmed slippage. With zero minimums a sandwich around the
      // close can take the position's value.
      const quoteParams = {
        tokenId: params.tokenId,
        liquidity: liquidityToRemove,
        amount0Min: 0n,
        amount1Min: 0n,
        deadline,
      };
      const { result: quoted } = await publicClient.simulateContract({
        address: addresses.nonfungiblePositionManager,
        abi: UNISWAP_V3_POSITION_MANAGER_ABI,
        functionName: "decreaseLiquidity",
        args: [quoteParams],
        account: walletClient.account,
      });
      const [quotedAmount0, quotedAmount1] = quoted as readonly [bigint, bigint];
      const decreaseParams = {
        ...quoteParams,
        amount0Min: minAmountAfterSlippage(quotedAmount0, params.slippageBps),
        amount1Min: minAmountAfterSlippage(quotedAmount1, params.slippageBps),
      };

      const { request: decreaseRequest } = await publicClient.simulateContract({
        address: addresses.nonfungiblePositionManager,
        abi: UNISWAP_V3_POSITION_MANAGER_ABI,
        functionName: "decreaseLiquidity",
        args: [decreaseParams],
        account: walletClient.account,
      });

      const decreaseHash = await walletClient.writeContract(decreaseRequest);
      const decreaseReceipt = await publicClient.waitForTransactionReceipt({
        hash: decreaseHash,
      });
      // A reverted decrease (for example the slippage minimums above) leaves
      // the liquidity in the position. Report it instead of collecting fees
      // and calling the close a success.
      if (decreaseReceipt.status !== "success") {
        return {
          success: false,
          error: "decreaseLiquidity reverted (slippage limit exceeded?)",
          transactionId: decreaseHash,
          hash: decreaseHash,
          chainId: params.chainId,
          blockNumber: decreaseReceipt.blockNumber,
          gasUsed: decreaseReceipt.gasUsed,
        };
      }

      const collectParams = {
        tokenId: params.tokenId,
        recipient: params.wallet.address,
        amount0Max: maxUint128,
        amount1Max: maxUint128,
      };

      const { request: collectRequest } = await publicClient.simulateContract({
        address: addresses.nonfungiblePositionManager,
        abi: UNISWAP_V3_POSITION_MANAGER_ABI,
        functionName: "collect",
        args: [collectParams],
        account: walletClient.account,
      });

      const collectHash = await walletClient.writeContract(collectRequest);
      const receipt = await publicClient.waitForTransactionReceipt({
        hash: collectHash,
      });

      // If removing all liquidity, burn the NFT
      if (params.percentageToRemove === 100 || !params.percentageToRemove) {
        try {
          const { request: burnRequest } = await publicClient.simulateContract({
            address: addresses.nonfungiblePositionManager,
            abi: UNISWAP_V3_POSITION_MANAGER_ABI,
            functionName: "burn",
            args: [params.tokenId],
            account: walletClient.account,
          });
          await walletClient.writeContract(burnRequest);
        } catch (burnError: unknown) {
          logger.debug(
            "[UniswapV3LpService] Could not burn position NFT:",
            burnError instanceof Error ? burnError.message : String(burnError)
          );
        }
      }

      return {
        success: receipt.status === "success",
        transactionId: collectHash,
        hash: collectHash,
        chainId: params.chainId,
        blockNumber: receipt.blockNumber,
        gasUsed: receipt.gasUsed,
      };
    } catch (error: unknown) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      logger.error("[UniswapV3LpService] Error removing liquidity:", errorMsg);
      return {
        success: false,
        error: errorMsg || "Unknown error removing liquidity",
      };
    }
  }

  private async getPositionFromContract(
    chainId: number,
    tokenId: bigint
  ): Promise<UniswapV3Position | null> {
    const addresses = UNISWAP_V3_ADDRESSES[chainId];
    if (!addresses) return null;

    const client = this.getPublicClient(chainId);

    try {
      const result = await client.readContract({
        address: addresses.nonfungiblePositionManager,
        abi: UNISWAP_V3_POSITION_MANAGER_ABI,
        functionName: "positions",
        args: [tokenId],
      });

      return {
        tokenId,
        nonce: result[0],
        operator: result[1] as Address,
        token0: result[2] as Address,
        token1: result[3] as Address,
        fee: result[4] as UniswapV3FeeTier,
        tickLower: result[5],
        tickUpper: result[6],
        liquidity: result[7],
        feeGrowthInside0LastX128: result[8],
        feeGrowthInside1LastX128: result[9],
        tokensOwed0: result[10],
        tokensOwed1: result[11],
      };
    } catch (error: unknown) {
      logger.error(
        `[UniswapV3LpService] Error fetching position ${tokenId}:`,
        error instanceof Error ? error.message : String(error)
      );
      return null;
    }
  }

  async getPositionDetails(
    chainId: number,
    owner: Address,
    poolAddress: Address,
    tokenId?: bigint
  ): Promise<EvmPositionDetails | null> {
    if (!this.supportsChain(chainId)) return null;

    if (tokenId) {
      const position = await this.getPositionFromContract(chainId, tokenId);
      if (!position) return null;

      const client = this.getPublicClient(chainId);
      const _chain = getViemChain(chainId);

      const [symbol0, decimals0, symbol1, decimals1] = await Promise.all([
        client
          .readContract({
            address: position.token0,
            abi: ERC20_ABI,
            functionName: "symbol",
          })
          .catch(() => "UNKNOWN"),
        client
          .readContract({
            address: position.token0,
            abi: ERC20_ABI,
            functionName: "decimals",
          })
          .catch(() => 18),
        client
          .readContract({
            address: position.token1,
            abi: ERC20_ABI,
            functionName: "symbol",
          })
          .catch(() => "UNKNOWN"),
        client
          .readContract({
            address: position.token1,
            abi: ERC20_ABI,
            functionName: "decimals",
          })
          .catch(() => 18),
      ]);

      return {
        poolId: poolAddress,
        dex: "uniswap",
        chainId,
        owner,
        tokenId: position.tokenId,
        tickLower: position.tickLower,
        tickUpper: position.tickUpper,
        liquidity: position.liquidity,
        lpTokenBalance: {
          address: poolAddress,
          balance: position.liquidity.toString(),
          decimals: 0,
          symbol: `UNI-V3-${symbol0}/${symbol1}`,
        },
        underlyingTokens: [
          {
            address: position.token0,
            balance: position.tokensOwed0.toString(),
            decimals: Number(decimals0),
            symbol: symbol0 as string,
          },
          {
            address: position.token1,
            balance: position.tokensOwed1.toString(),
            decimals: Number(decimals1),
            symbol: symbol1 as string,
          },
        ],
        accruedFees: [],
        rewards: [],
      };
    }

    const positions = await this.getAllPositions(chainId, owner);
    return positions.find((p) => p.poolId.toLowerCase() === poolAddress.toLowerCase()) ?? null;
  }

  async getAllPositions(chainId: number, owner: Address): Promise<EvmPositionDetails[]> {
    if (!this.supportsChain(chainId)) return [];

    const addresses = UNISWAP_V3_ADDRESSES[chainId];
    if (!addresses) return [];

    const client = this.getPublicClient(chainId);
    const positions: EvmPositionDetails[] = [];

    try {
      const balance = await client.readContract({
        address: addresses.nonfungiblePositionManager,
        abi: UNISWAP_V3_POSITION_MANAGER_ABI,
        functionName: "balanceOf",
        args: [owner],
      });

      for (let i = 0; i < Number(balance); i++) {
        const tokenId = await client.readContract({
          address: addresses.nonfungiblePositionManager,
          abi: UNISWAP_V3_POSITION_MANAGER_ABI,
          functionName: "tokenOfOwnerByIndex",
          args: [owner, BigInt(i)],
        });

        const position = await this.getPositionFromContract(chainId, tokenId as bigint);
        if (position && position.liquidity > 0n) {
          const poolAddress = await client.readContract({
            address: addresses.factory,
            abi: UNISWAP_V3_FACTORY_ABI,
            functionName: "getPool",
            args: [position.token0, position.token1, position.fee],
          });

          if (poolAddress) {
            const details = await this.getPositionDetails(
              chainId,
              owner,
              poolAddress as Address,
              tokenId as bigint
            );
            if (details) {
              positions.push(details);
            }
          }
        }
      }
    } catch (error: unknown) {
      logger.error(
        "[UniswapV3LpService] Error fetching all positions:",
        error instanceof Error ? error.message : String(error)
      );
    }

    return positions;
  }

  async getMarketData(poolAddresses: Address[]): Promise<Record<string, Partial<EvmPoolInfo>>> {
    const result: Record<string, Partial<EvmPoolInfo>> = {};

    for (const address of poolAddresses) {
      for (const chainId of this.getSupportedChainIds()) {
        try {
          const poolInfo = await this.getPoolInfo(chainId, address);
          if (poolInfo) {
            result[address] = poolInfo;
            break;
          }
        } catch {
          // Pool not on this chain
        }
      }
    }

    return result;
  }

  private async approveToken(
    chainId: number,
    privateKey: `0x${string}`,
    tokenAddress: Address,
    spenderAddress: Address,
    amount: bigint
  ): Promise<void> {
    const publicClient = this.getPublicClient(chainId);
    const walletClient = this.getWalletClient(chainId, privateKey);
    const ownerAddress = walletClient.account?.address;
    if (!ownerAddress) {
      throw new Error("Wallet account is required to approve token spending.");
    }

    const allowance = await publicClient.readContract({
      address: tokenAddress,
      abi: ERC20_ABI,
      functionName: "allowance",
      args: [ownerAddress, spenderAddress],
    });

    if ((allowance as bigint) >= amount) {
      return;
    }

    logger.info(`[UniswapV3LpService] Approving ${tokenAddress} for ${spenderAddress}`);

    const { request } = await publicClient.simulateContract({
      address: tokenAddress,
      abi: ERC20_ABI,
      functionName: "approve",
      args: [spenderAddress, amount],
      account: walletClient.account,
    });

    const hash = await walletClient.writeContract(request);
    await publicClient.waitForTransactionReceipt({ hash });

    logger.info(`[UniswapV3LpService] Token approved: ${hash}`);
  }
}
