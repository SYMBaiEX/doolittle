import { configureDefaultAccountPoolSelection, DIRECT_PROVIDER_BY_BACKEND, isAccountExpired, isAccountSelectableNow, selectionForProvider, } from "./account-selection.js";
/**
 * Multi-account selection brain.
 *
 * Owns the runtime decision "which `LinkedAccountConfig` should serve this
 * request?" given a strategy (priority / round-robin / least-used /
 * quota-aware / drain-soonest-reset), session affinity, and per-account health
 * state.
 *
 * The pool never reads OAuth credentials directly — callers resolve them
 * via `getAccessToken(providerId, accountId)` from `@elizaos/auth/auth` once
 * the pool returns an account. Health, priority, and usage live in this
 * layer; the OAuth blob lives under the active state-dir auth directory.
 *
 * Persistence: the pool layers rich metadata (priority, enabled, health,
 * usage) on top of the credential records from `@elizaos/auth/auth`. The
 * metadata is written to `<stateDir>/auth/_pool-metadata.json` atomically
 * so it survives process restarts.
 */
import { randomUUID } from "node:crypto";
import { closeSync, constants, fstatSync, fsyncSync, openSync, readFileSync, renameSync, rmSync, writeFileSync, } from "node:fs";
import path from "node:path";
import { logger, resolveStateDir } from "@elizaos/core";
import { ElizaError, setAnthropicAccountPoolBridge, } from "@elizaos/core/protocol";
import { isLinkedAccountProviderId } from "@elizaos/host/protocol";
import { createRuntimeAccountStoragePolicy, withAccountStorageMutation, } from "../auth/account-storage.js";
import { getAccessToken as getAccountAccessToken, listProviderAccounts, } from "../auth/credentials.js";
import { fetchAnthropicOAuthProfile } from "../auth/oauth-flow.js";
import { ACCOUNT_CREDENTIAL_PROVIDER_IDS, DIRECT_ACCOUNT_PROVIDER_ENV, DIRECT_ACCOUNT_PROVIDER_IDS, isSubscriptionProvider, OPENAI_COMPAT_BASE_BY_DIRECT_PROVIDER, } from "../auth/types.js";
import { pollAnthropicUsage, pollCodexUsage, recordCall as recordUsageEntry, } from "./account-usage.js";
import { adoptRotatedCodexTokens, installCodingAgentSelectorBridge, } from "./coding-account-bridge.js";
const DEFAULT_RATE_LIMIT_BACKOFF_MS = 60000;
const QUOTA_AWARE_SKIP_PCT = 85;
const SESSION_AFFINITY_MAX_ATTEMPTS = 3;
const USAGE_PRIMING_DEBOUNCE_MS = 6 * 60 * 60000;
const USAGE_PRIMING_RETRY_DELAY_MS = 30000;
const ANTHROPIC_MESSAGES_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_USAGE_PRIMING_MODEL = "claude-haiku-4-5-20251001";
const SUBSCRIPTION_END_BOOST_WINDOW_MS = 48 * 60 * 60 * 1000;
const KEEP_ALIVE_INTERVAL_MS = 5 * 60000;
/**
 * How long the keep-alive sweep waits before re-probing a parked
 * (needs-reauth / invalid) SUBSCRIPTION account. A parked OAuth account's
 * refresh grant is dead until a human re-auths, so each probe burns a doomed
 * refresh attempt against the provider's token endpoint and emits an error
 * log line — at the 5-minute sweep cadence that is ~288 spam lines per
 * account per day. A credential update (re-auth) bypasses the cooldown, so
 * recovered accounts still re-admit within one sweep.
 */
const PARKED_SUBSCRIPTION_PROBE_COOLDOWN_MS = 6 * 60 * 60000;
function accountSessionPct(account) {
    return typeof account.usage?.sessionPct === "number"
        ? account.usage.sessionPct
        : 0;
}
function accountWeeklyPct(account) {
    return typeof account.usage?.weeklyPct === "number"
        ? account.usage.weeklyPct
        : accountSessionPct(account);
}
function normalizeModelKey(value) {
    return value
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "");
}
function modelKeysMatch(requested, bucket) {
    return (requested === bucket ||
        (bucket.length >= 4 && requested.includes(bucket)) ||
        (requested.length >= 4 && bucket.includes(requested)));
}
function accountWeeklyBucket(account, requestedModel) {
    const key = requestedModel ? normalizeModelKey(requestedModel) : "";
    const buckets = account.usage?.weeklyModelBuckets;
    if (key && buckets) {
        for (const [name, bucket] of Object.entries(buckets)) {
            if (modelKeysMatch(key, normalizeModelKey(name)))
                return bucket;
        }
    }
    return {
        pct: accountWeeklyPct(account),
        ...(account.usage?.resetsAt !== undefined
            ? { resetsAt: account.usage.resetsAt }
            : {}),
    };
}
function accountLastUsedAt(account) {
    return typeof account.lastUsedAt === "number" ? account.lastUsedAt : 0;
}
/**
 * The instant an account's weekly budget refunds. Prefers the usage
 * snapshot's `resetsAt`; falls back to a live rate-limit `until`. Undefined
 * when the provider hasn't reported a reset window yet.
 */
function accountResetAt(account) {
    return account.usage?.resetsAt;
}
/**
 * `reset-soonest` comparator. Prefer the account whose weekly reset arrives
 * SOONEST: its budget refunds first, so spending it now is the cheapest.
 * Accounts with a known reset instant sort ahead of unknowns; ties and
 * all-unknown pools fall back to least-recently-used (held-in-reserve
 * heuristic), then priority for a fully stable order.
 */
function bySoonestReset(a, b) {
    const ar = accountResetAt(a);
    const br = accountResetAt(b);
    if (ar != null && br != null) {
        if (ar !== br)
            return ar - br;
    }
    else if (ar != null) {
        return -1;
    }
    else if (br != null) {
        return 1;
    }
    const aUsed = accountLastUsedAt(a);
    const bUsed = accountLastUsedAt(b);
    if (aUsed !== bUsed)
        return aUsed - bUsed;
    return a.priority - b.priority;
}
function subscriptionEndBoost(account, now) {
    if (typeof account.subscriptionEndsAt !== "number" ||
        account.subscriptionEndsAt <= now) {
        return Number.MAX_SAFE_INTEGER;
    }
    const remaining = account.subscriptionEndsAt - now;
    return remaining <= SUBSCRIPTION_END_BOOST_WINDOW_MS
        ? remaining
        : Number.MAX_SAFE_INTEGER;
}
// affinity is keyed by sessionKey, which is per-conversation/per-request, so the
// map grows one entry per distinct session over the process lifetime. Cap it
// (FIFO by Map insertion order) — an evicted session simply re-selects on its
// next call, which is the same behavior as a cold session.
const MAX_AFFINITY_ENTRIES = 10000;
export class AccountPool {
    deps;
    affinity = new Map();
    roundRobinCursor = new Map();
    // Burst-spread for least-used: `usage.sessionPct` is only refreshed every few
    // minutes, so a burst of fresh spawns inside one poll window would otherwise
    // all stack on the single lowest-sessionPct account. Stamping each pick lets
    // the tiebreak rotate across equally-/un-probed accounts until real usage
    // diverges. Monotonic + epoch-aligned so it composes with `lastUsedAt`.
    recentlySelectedAt = new Map();
    selectionClock = 0;
    constructor(deps) {
        this.deps = deps;
    }
    // Selection.
    async select(input) {
        const all = this.deps.readAccounts();
        await this.markExpiredAccounts(input.providerId, all);
        const eligible = this.filterEligible(all, input);
        if (eligible.length === 0)
            return null;
        const affinityKey = input.sessionKey
            ? poolRecordKey(input.providerId, input.sessionKey)
            : undefined;
        if (affinityKey) {
            const cached = this.affinity.get(affinityKey);
            if (cached &&
                cached.attempts < SESSION_AFFINITY_MAX_ATTEMPTS &&
                eligible.some((a) => a.id === cached.accountId)) {
                cached.attempts += 1;
                const account = eligible.find((a) => a.id === cached.accountId);
                if (account)
                    return account;
            }
        }
        const strategy = input.strategy ?? "priority";
        const picked = this.applyStrategy(strategy, eligible, input.providerId, {
            model: input.model,
            advanceCursor: true,
        });
        if (!picked)
            return null;
        this.stampSelection(poolRecordKey(picked.providerId, picked.id));
        if (affinityKey) {
            this.affinity.set(affinityKey, {
                accountId: picked.id,
                attempts: 1,
            });
            while (this.affinity.size > MAX_AFFINITY_ENTRIES) {
                const oldest = this.affinity.keys().next().value;
                if (oldest === undefined)
                    break;
                this.affinity.delete(oldest);
            }
        }
        return picked;
    }
    /**
     * Non-mutating dry-run of selection for the accounts API / settings UI:
     * "which account would we serve next for this provider, and why?" Uses the
     * SAME eligibility + strategy ordering as {@link select} but never stamps a
     * selection or touches affinity, so polling it from the UI has no runtime
     * side effects. Ignores session affinity (that's per-request state the UI
     * can't meaningfully reflect).
     */
    selectionState(providerId, strategy = "priority", opts) {
        return this.selectionStateFromAccounts(this.deps.readAccounts(), providerId, strategy, opts);
    }
    /** A request-scoped inventory; later requests must acquire a fresh snapshot. */
    readSnapshot() {
        const all = this.deps.readAccounts();
        return {
            list: (providerId) => Object.values(all).filter((account) => !providerId || account.providerId === providerId),
            selectionState: (providerId, strategy = "priority") => this.selectionStateFromAccounts(all, providerId, strategy),
        };
    }
    selectionStateFromAccounts(all, providerId, strategy, opts) {
        const eligible = this.filterEligible(all, {
            providerId,
            accountIds: opts?.accountIds,
        });
        if (eligible.length === 0)
            return { activeAccountId: null, reason: null };
        if (eligible.length === 1) {
            return {
                activeAccountId: eligible[0]?.id ?? null,
                reason: "only-eligible",
            };
        }
        const picked = this.applyStrategy(strategy, eligible, providerId, opts);
        if (!picked)
            return { activeAccountId: null, reason: null };
        let reason = strategy;
        if (strategy === "reset-soonest") {
            // Distinguish a real reset-time pick from the least-recently-used
            // fallback so the UI copy stays honest.
            reason = eligible.some((a) => accountResetAt(a) != null)
                ? "reset-soonest"
                : "least-recently-throttled";
        }
        else if (strategy === "drain-soonest-reset") {
            reason = "drain-soonest-reset";
        }
        return { activeAccountId: picked.id, reason };
    }
    async sweepExpired(providerId) {
        const all = this.deps.readAccounts();
        return this.markExpiredAccounts(providerId, all);
    }
    async markExpiredAccounts(providerId, all) {
        const now = Date.now();
        let changed = 0;
        for (const account of Object.values(all)) {
            if (providerId && account.providerId !== providerId)
                continue;
            if (typeof account.subscriptionEndsAt !== "number" ||
                account.subscriptionEndsAt > now ||
                account.health === "expired") {
                continue;
            }
            changed += 1;
            logger.warn(`[AccountPool] account expired providerId=${account.providerId} accountId=${account.id} subscriptionEndsAt=${account.subscriptionEndsAt}`);
            await this.deps.writeAccount({
                ...account,
                health: "expired",
                healthDetail: { lastChecked: now },
            });
        }
        return changed;
    }
    filterEligible(all, input) {
        const exclude = new Set(input.exclude ?? []);
        const explicit = input.accountIds && input.accountIds.length > 0
            ? new Set(input.accountIds)
            : null;
        const now = Date.now();
        return Object.values(all).filter((account) => {
            if (account.providerId !== input.providerId)
                return false;
            if (!account.enabled)
                return false;
            if (exclude.has(account.id))
                return false;
            if (explicit && !explicit.has(account.id))
                return false;
            return isAccountSelectableNow(account, now);
        });
    }
    applyStrategy(strategy, eligible, providerId, opts = {}) {
        if (eligible.length === 0)
            return null;
        if (eligible.length === 1)
            return eligible[0] ?? null;
        switch (strategy) {
            case "round-robin": {
                // The ring MUST have a stable order: byPriorityThenAge tiebreaks on
                // lastUsedAt, which recordCall bumps between selects, so the ring
                // would reshuffle under the cursor and serve the same account
                // back-to-back (a,a,b,b,…) in the normal select→record→select flow.
                const sorted = [...eligible].sort(byPriorityThenStableIdentity);
                const cursor = (this.roundRobinCursor.get(providerId) ?? -1) + 1;
                const index = cursor % sorted.length;
                if (opts.advanceCursor)
                    this.roundRobinCursor.set(providerId, index);
                return sorted[index] ?? null;
            }
            case "least-used": {
                return ([...eligible].sort((a, b) => this.byLeastUsedEffective(a, b))[0] ??
                    null);
            }
            case "quota-aware": {
                const underQuota = eligible.filter((a) => accountSessionPct(a) < QUOTA_AWARE_SKIP_PCT);
                const pool = underQuota.length > 0 ? underQuota : eligible;
                return [...pool].sort(byPriorityThenAge)[0] ?? null;
            }
            case "reset-soonest": {
                // Among accounts still under quota, serve the one whose weekly budget
                // refunds soonest. Accounts that just reset (far-off resetsAt) are
                // naturally held in reserve because they sort last.
                const underQuota = eligible.filter((a) => accountSessionPct(a) < QUOTA_AWARE_SKIP_PCT);
                const pool = underQuota.length > 0 ? underQuota : eligible;
                return [...pool].sort(bySoonestReset)[0] ?? null;
            }
            case "drain-soonest-reset": {
                // A weekly window is the scarce budget, but a currently exhausted
                // session cannot serve traffic. Cool it out without changing the
                // relative weekly drain order used when it becomes eligible again.
                const underSessionCap = eligible.filter((a) => accountSessionPct(a) < QUOTA_AWARE_SKIP_PCT);
                const pool = underSessionCap.length > 0 ? underSessionCap : eligible;
                return ([...pool].sort((a, b) => byDrainSoonestReset(a, b, opts.model))[0] ??
                    null);
            }
            default:
                return [...eligible].sort(byPriorityThenAge)[0] ?? null;
        }
    }
    /** Record that `accountId` was just selected, with a strictly-increasing,
     * epoch-aligned stamp so a same-millisecond burst still rotates. */
    stampSelection(accountId) {
        this.selectionClock = Math.max(Date.now(), this.selectionClock + 1);
        this.recentlySelectedAt.set(accountId, this.selectionClock);
        while (this.recentlySelectedAt.size > MAX_AFFINITY_ENTRIES) {
            const oldest = this.recentlySelectedAt.keys().next().value;
            if (oldest === undefined)
                break;
            this.recentlySelectedAt.delete(oldest);
        }
    }
    /** Most recent of the persisted `lastUsedAt` and the in-memory selection
     * stamp — so a just-picked account sorts as "more recently used". */
    effectiveLastUsed(account) {
        const recentSelection = this.recentlySelectedAt.get(poolRecordKey(account.providerId, account.id));
        return Math.max(accountLastUsedAt(account), recentSelection === undefined ? 0 : recentSelection);
    }
    /** least-used comparator: spread load first by reported usage, then by
     * recency-of-use (persisted + in-flight selection). Recency is ranked ABOVE
     * `priority` here because least-used is a load-spreading strategy and the
     * default `priority` is just creation order — honoring it would pin every
     * equal-usage pick to the oldest account (the burst herd). `priority` only
     * breaks a recency tie. */
    byLeastUsedEffective(a, b) {
        const aPct = accountSessionPct(a);
        const bPct = accountSessionPct(b);
        if (aPct !== bPct)
            return aPct - bPct;
        const aUsed = this.effectiveLastUsed(a);
        const bUsed = this.effectiveLastUsed(b);
        if (aUsed !== bUsed)
            return aUsed - bUsed;
        return a.priority - b.priority;
    }
    // CRUD — used by accounts-routes.ts as the single source of truth for
    // LinkedAccountConfig records. Both reads and writes go through here so
    // changes from the HTTP API and from runtime mutations (markRateLimited,
    // refreshUsage, recordCall) stay consistent.
    list(providerId) {
        const all = Object.values(this.deps.readAccounts());
        if (!providerId)
            return all;
        return all.filter((a) => a.providerId === providerId);
    }
    get(accountId, providerId) {
        return findAccountById(this.deps.readAccounts(), accountId, providerId);
    }
    async upsert(account) {
        const prior = this.get(account.id, account.providerId);
        await this.deps.writeAccount({
            ...account,
            prioritySource: account.prioritySource ?? prior?.prioritySource ?? "generated",
        });
    }
    async deleteMetadata(providerId, accountId) {
        if (!this.deps.deleteAccount) {
            throw new ElizaError("Account-pool persistence cannot delete metadata", {
                code: "ACCOUNT_POOL_DELETE_UNSUPPORTED",
                context: { providerId, accountId },
                severity: "fatal",
            });
        }
        await this.deps.deleteAccount(providerId, accountId);
    }
    // Mutations.
    async recordCall(accountId, result, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        recordUsageEntry(account.providerId, account.id, result);
        const next = {
            ...account,
            lastUsedAt: Date.now(),
        };
        await this.deps.writeAccount(next);
    }
    async refreshUsage(accountId, accessToken, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        if (isAccountExpired(account)) {
            await this.markExpiredAccounts(account.providerId, {
                [poolRecordKey(account.providerId, account.id)]: account,
            });
            return;
        }
        let usage;
        // Anthropic's OAuth token is opaque (no OIDC claims), so accounts linked
        // before the OAuth flow started persisting the profile email — or imported
        // from a CLI login — have no identity to display. Backfill it here from the
        // same profile endpoint the link flow uses.
        let email;
        if (account.providerId === "anthropic-subscription") {
            usage = await pollAnthropicUsage(accessToken, opts?.fetch);
            if (!account.email) {
                try {
                    email = (await fetchAnthropicOAuthProfile(accessToken, opts?.fetch))
                        .email;
                }
                catch (err) {
                    // error-policy:J7 diagnostics-must-not-kill-the-loop — the identity
                    // backfill is enrichment on top of the usage refresh. A profile
                    // failure is REPORTED here (typed ElizaError from the profile
                    // boundary, logged with the account id) and the email stays absent —
                    // never fabricated as a healthy empty identity — while the
                    // successfully fetched usage snapshot below is still persisted.
                    logger.warn(`[AccountPool] Anthropic profile backfill failed for account ${accountId}: ${String(err)}`);
                }
            }
        }
        else if (account.providerId === "openai-codex") {
            const codexAccountId = opts?.codexAccountId ?? account.organizationId;
            if (!codexAccountId) {
                throw new Error(`[AccountPool] Codex usage probe needs the OpenAI account_id (account ${accountId} has no organizationId).`);
            }
            usage = await pollCodexUsage(accessToken, codexAccountId, opts?.fetch);
        }
        else {
            // No probe defined for direct API providers.
            return;
        }
        // The usage probe above is a real suspension point: a concurrent health
        // transition (markRateLimited's 429 cooldown, markNeedsReauth, markInvalid)
        // may have committed while it was in flight. Writing the PRE-AWAIT snapshot
        // back would silently clobber it — persistAccount replaces the whole
        // metadata bucket, so it is last-writer-wins with stale data — re-admitting
        // a rate-limited/revoked account and defeating the backoff clock. Re-read
        // the account now and merge: `readAccounts` is synchronous and the write's
        // persist body runs to completion before this frame yields, so the
        // read-merge-write is atomic on the event loop against every other mutator
        // (which are all likewise read-then-write with no await between).
        const baseline = healthSignature(account);
        const fresh = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!fresh)
            return;
        if (healthSignature(fresh) !== baseline) {
            // A newer, authoritative health verdict landed during the probe. Keep it
            // verbatim; only layer on the freshly fetched usage/email.
            await this.deps.writeAccount({
                ...fresh,
                usage,
                ...(email ? { email } : {}),
            });
            return;
        }
        // No concurrent transition: a successful usage read proves the account
        // works, so (re-)admit it as OK and drop any now-stale health detail.
        await this.deps.writeAccount({
            ...fresh,
            health: "ok",
            healthDetail: undefined,
            usage,
            ...(email ? { email } : {}),
        });
    }
    async markRateLimited(accountId, untilMs, detail, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        // Provider-authoritative cooldown, per provider semantics of
        // `usage.resetsAt` (see LinkedAccountUsage contract):
        //  - Codex persists its PRIMARY FIVE-HOUR window reset there, which is
        //    exactly the 429 cooldown clock. Using it re-admits the account the
        //    moment the limit lifts; a 60s caller heuristic would ping-pong spawns
        //    onto a still-limited ~5h window every minute (the documented Codex
        //    429 regression).
        //  - Anthropic persists the SEVEN-DAY weekly reset there for drain
        //    ordering. Using it as a 429 cooldown would strand a session-limited
        //    account for up to a week, so Anthropic keeps the caller heuristic
        //    (60s probe default / provider retry-after when the caller has one).
        const providerResetMs = account.providerId === "openai-codex"
            ? account.usage?.resetsAt
            : undefined;
        const heuristicUntil = Number.isFinite(untilMs) && untilMs > Date.now()
            ? untilMs
            : Date.now() + DEFAULT_RATE_LIMIT_BACKOFF_MS;
        const healthDetail = {
            until: typeof providerResetMs === "number" && providerResetMs > Date.now()
                ? providerResetMs
                : heuristicUntil,
            lastChecked: Date.now(),
            ...(detail ? { lastError: detail } : {}),
        };
        await this.deps.writeAccount({
            ...account,
            health: "rate-limited",
            healthDetail,
        });
    }
    async markRateLimitedUnknown(accountId, detail, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        const healthDetail = {
            lastChecked: Date.now(),
            ...(detail ? { lastError: detail } : {}),
        };
        await this.deps.writeAccount({
            ...account,
            health: "rate-limited",
            healthDetail,
        });
    }
    async markNeedsReauth(accountId, detail, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        if (isAccountExpired(account)) {
            await this.markExpiredAccounts(account.providerId, {
                [poolRecordKey(account.providerId, account.id)]: account,
            });
            return;
        }
        // Repeated probes may report the same state; log only the transition while
        // still persisting the newest diagnostic detail on every call.
        if (account.health !== "needs-reauth") {
            logger.warn(`[account-pool] ${account.providerId} account "${account.label ?? account.id}" (${account.id}) → needs-reauth: ${detail ?? "no detail provided"}`);
        }
        await this.deps.writeAccount({
            ...account,
            health: "needs-reauth",
            healthDetail: {
                lastChecked: Date.now(),
                ...(detail ? { lastError: detail } : {}),
            },
        });
    }
    async markInvalid(accountId, detail, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        if (isAccountExpired(account)) {
            await this.markExpiredAccounts(account.providerId, {
                [poolRecordKey(account.providerId, account.id)]: account,
            });
            return;
        }
        await this.deps.writeAccount({
            ...account,
            health: "invalid",
            healthDetail: {
                lastChecked: Date.now(),
                ...(detail ? { lastError: detail } : {}),
            },
        });
    }
    async markHealthy(accountId, opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        if (isAccountExpired(account)) {
            await this.markExpiredAccounts(account.providerId, {
                [poolRecordKey(account.providerId, account.id)]: account,
            });
            return;
        }
        if (account.health === "ok")
            return;
        await this.deps.writeAccount({
            ...account,
            health: "ok",
            ...(account.healthDetail ? { healthDetail: undefined } : {}),
        });
    }
    async markUsagePrimed(accountId, lastPrimedAt = Date.now(), opts) {
        const account = findAccountById(this.deps.readAccounts(), accountId, opts?.providerId);
        if (!account)
            return;
        await this.deps.writeAccount({
            ...account,
            lastPrimedAt,
        });
    }
    /**
     * Re-probe accounts whose `health` is non-OK and whose `healthDetail.until`
     * has passed (or is absent). Used by background sweepers to recover
     * temporarily flagged accounts. We don't load access tokens here — the
     * caller probes via `refreshUsage` separately.
     */
    async reprobeFlagged() {
        const all = this.deps.readAccounts();
        const now = Date.now();
        const ready = [];
        for (const account of Object.values(all)) {
            if (account.health === "ok")
                continue;
            if (account.health === "rate-limited") {
                const until = account.healthDetail?.until;
                if (typeof until === "number" && until > now)
                    continue;
            }
            ready.push(account.id);
        }
        return ready;
    }
}
function poolRecordKey(providerId, accountId) {
    return `${providerId}:${accountId}`;
}
/**
 * A stable fingerprint of an account's health verdict (`health` plus its
 * `healthDetail`). `refreshUsage` snapshots this before its network probe and
 * re-checks it after, so any change committed by a concurrent mutator during
 * the await — a new rate-limit cooldown, a re-auth/invalid flag, or even a
 * re-probed `lastChecked` — is detected and its verdict is preserved instead of
 * being overwritten by the probe's stale "ok" assumption.
 */
function healthSignature(account) {
    return JSON.stringify({
        health: account.health,
        healthDetail: account.healthDetail ?? null,
    });
}
function findAccountById(all, accountId, providerId) {
    if (providerId) {
        const scoped = all[poolRecordKey(providerId, accountId)];
        if (scoped)
            return scoped;
        return (Object.values(all).find((account) => account.id === accountId && account.providerId === providerId) ?? null);
    }
    const direct = all[accountId];
    if (direct)
        return direct;
    return Object.values(all).find((account) => account.id === accountId) ?? null;
}
function byPriorityThenAge(a, b) {
    if (a.priority !== b.priority)
        return a.priority - b.priority;
    const aLast = accountLastUsedAt(a);
    const bLast = accountLastUsedAt(b);
    return aLast - bLast; // older first
}
function byExplicitPriority(a, b) {
    const aExplicit = a.prioritySource === "explicit";
    const bExplicit = b.prioritySource === "explicit";
    if (aExplicit && bExplicit && a.priority !== b.priority) {
        return a.priority - b.priority;
    }
    if (aExplicit !== bExplicit)
        return aExplicit ? -1 : 1;
    return 0;
}
function byDrainSoonestReset(a, b, requestedModel) {
    const explicit = byExplicitPriority(a, b);
    if (explicit !== 0)
        return explicit;
    const aBucket = accountWeeklyBucket(a, requestedModel);
    const bBucket = accountWeeklyBucket(b, requestedModel);
    if (aBucket.resetsAt != null && bBucket.resetsAt != null) {
        if (aBucket.resetsAt !== bBucket.resetsAt) {
            return aBucket.resetsAt - bBucket.resetsAt;
        }
    }
    else if (aBucket.resetsAt != null) {
        return -1;
    }
    else if (bBucket.resetsAt != null) {
        return 1;
    }
    if (aBucket.pct !== bBucket.pct)
        return aBucket.pct - bBucket.pct;
    const now = Date.now();
    const aBoost = subscriptionEndBoost(a, now);
    const bBoost = subscriptionEndBoost(b, now);
    if (aBoost !== bBoost)
        return aBoost - bBoost;
    if (a.createdAt !== b.createdAt)
        return a.createdAt - b.createdAt;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}
/** Mutation-free ordering for the round-robin ring: identity fields only
 * (priority, createdAt, id), so the cursor walks the same sequence no matter
 * how usage recording mutates `lastUsedAt` between selects. */
function byPriorityThenStableIdentity(a, b) {
    if (a.priority !== b.priority)
        return a.priority - b.priority;
    if (a.createdAt !== b.createdAt)
        return a.createdAt - b.createdAt;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}
function metadataFile(storagePolicy) {
    return path.join(storagePolicy.authRoot, "_pool-metadata.json");
}
function readMetaStore(storagePolicy) {
    const file = metadataFile(storagePolicy);
    let descriptor;
    try {
        descriptor = openSync(file, constants.O_RDONLY | constants.O_NOFOLLOW);
        if (!fstatSync(descriptor).isFile()) {
            throw new ElizaError("Account-pool metadata is not a regular file", {
                code: "ACCOUNT_POOL_METADATA_NOT_REGULAR",
                context: { file },
                severity: "fatal",
            });
        }
        const raw = readFileSync(descriptor, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
            return parsed;
        }
    }
    catch (cause) {
        if (cause.code === "ENOENT") {
            return {};
        }
        if (cause instanceof ElizaError)
            throw cause;
        throw new ElizaError("Account-pool metadata could not be read safely", {
            code: "ACCOUNT_POOL_METADATA_CORRUPT",
            cause,
            context: { file },
            severity: "fatal",
        });
    }
    finally {
        if (descriptor !== undefined)
            closeSync(descriptor);
    }
    throw new ElizaError("Account-pool metadata has an invalid root shape", {
        code: "ACCOUNT_POOL_METADATA_CORRUPT",
        context: { file },
        severity: "fatal",
    });
}
function fsyncMetadataDirectory(directory) {
    if (process.platform === "win32")
        return;
    const descriptor = openSync(directory, constants.O_RDONLY | (constants.O_DIRECTORY ?? 0));
    try {
        fsyncSync(descriptor);
    }
    finally {
        closeSync(descriptor);
    }
}
function writeMetaStore(store, storagePolicy) {
    const file = metadataFile(storagePolicy);
    const dir = path.dirname(file);
    const tmp = `${file}.${process.pid}.${randomUUID()}.tmp`;
    let descriptor;
    try {
        descriptor = openSync(tmp, constants.O_WRONLY |
            constants.O_CREAT |
            constants.O_EXCL |
            constants.O_NOFOLLOW, 0o600);
        writeFileSync(descriptor, JSON.stringify(store, null, 2), "utf-8");
        fsyncSync(descriptor);
        closeSync(descriptor);
        descriptor = undefined;
        renameSync(tmp, file);
        fsyncMetadataDirectory(dir);
    }
    finally {
        if (descriptor !== undefined)
            closeSync(descriptor);
        rmSync(tmp, { force: true });
    }
}
function recordToLinked(record, meta, providerId, defaultPriority) {
    return {
        id: record.id,
        providerId,
        label: meta?.label ?? record.label,
        source: record.source,
        enabled: meta?.enabled ?? true,
        priority: meta?.priority ?? defaultPriority,
        // Legacy metadata persisted creation-order priorities for every account.
        // Treat an unchanged creation-order value as generated, while preserving a
        // hand-tuned legacy value as an explicit override.
        prioritySource: meta?.prioritySource ??
            (typeof meta?.priority === "number" && meta.priority !== defaultPriority
                ? "explicit"
                : "generated"),
        createdAt: record.createdAt,
        health: meta?.health ?? "ok",
        // Prefer the pool-meta lastUsedAt (bumped by recordCall) over the credential
        // record's (bumped only by touchAccount); fall back to the record's.
        ...((meta?.lastUsedAt ?? record.lastUsedAt) !== undefined
            ? { lastUsedAt: meta?.lastUsedAt ?? record.lastUsedAt }
            : {}),
        ...(meta?.lastPrimedAt !== undefined
            ? { lastPrimedAt: meta.lastPrimedAt }
            : {}),
        ...(meta?.healthDetail ? { healthDetail: meta.healthDetail } : {}),
        ...(meta?.usage ? { usage: meta.usage } : {}),
        ...(typeof meta?.subscriptionEndsAt === "number"
            ? { subscriptionEndsAt: meta.subscriptionEndsAt }
            : {}),
        ...(record.organizationId ? { organizationId: record.organizationId } : {}),
        ...(record.userId ? { userId: record.userId } : {}),
        ...(() => {
            // Show WHO an account is: prefer the credential record's email (new OAuth
            // links persist it), then the pool-meta backfill (refreshUsage profile
            // probe for older Anthropic links), then derive it from the id_token's
            // OIDC `email` claim (Codex CLI imports carry an id_token; providers
            // without one simply have no email to show).
            const email = record.email ??
                meta?.email ??
                emailFromIdToken(record.credentials.idToken);
            return email ? { email } : {};
        })(),
    };
}
/** The OIDC `email` claim from a JWT id_token, or undefined. */
function emailFromIdToken(idToken) {
    if (!idToken)
        return undefined;
    try {
        const segments = idToken.split(".");
        const encodedPayload = segments.length === 3 ? segments[1] : undefined;
        if (!encodedPayload)
            return undefined;
        const payload = JSON.parse(Buffer.from(encodedPayload, "base64url").toString("utf8"));
        return typeof payload.email === "string" && payload.email.includes("@")
            ? payload.email
            : undefined;
    }
    catch {
        // error-policy:J3 untrusted id_token payload — undecodable ⇒ no email.
        return undefined;
    }
}
function loadAllAccounts(storagePolicy) {
    const meta = readMetaStore(storagePolicy);
    const out = {};
    for (const provider of ACCOUNT_CREDENTIAL_PROVIDER_IDS) {
        const records = listProviderAccounts(provider);
        let priorityCounter = 0;
        const sorted = [...records].sort((a, b) => {
            const aTime = Number.isFinite(a.createdAt) ? a.createdAt : 0;
            const bTime = Number.isFinite(b.createdAt) ? b.createdAt : 0;
            return aTime - bTime;
        });
        for (const record of sorted) {
            const providerMeta = meta[provider]?.[record.id];
            out[poolRecordKey(provider, record.id)] = recordToLinked(record, providerMeta, provider, priorityCounter);
            priorityCounter += 1;
        }
    }
    return out;
}
async function persistAccount(account, storagePolicy) {
    if (!isLinkedAccountProviderId(account.providerId))
        return;
    withAccountStorageMutation(storagePolicy, "persist-account-pool-metadata", () => {
        const store = readMetaStore(storagePolicy);
        if (!store[account.providerId]) {
            store[account.providerId] = {};
        }
        store[account.providerId][account.id] = {
            label: account.label,
            enabled: account.enabled,
            priority: account.priority,
            prioritySource: account.prioritySource ?? "generated",
            health: account.health,
            ...(account.healthDetail ? { healthDetail: account.healthDetail } : {}),
            ...(account.usage ? { usage: account.usage } : {}),
            ...(typeof account.subscriptionEndsAt === "number"
                ? { subscriptionEndsAt: account.subscriptionEndsAt }
                : {}),
            ...(account.lastUsedAt !== undefined
                ? { lastUsedAt: account.lastUsedAt }
                : {}),
            ...(account.lastPrimedAt !== undefined
                ? { lastPrimedAt: account.lastPrimedAt }
                : {}),
            ...(account.email ? { email: account.email } : {}),
        };
        writeMetaStore(store, storagePolicy);
    });
}
async function deleteAccountMeta(providerId, accountId, storagePolicy) {
    withAccountStorageMutation(storagePolicy, "delete-account-pool-metadata", () => {
        const store = readMetaStore(storagePolicy);
        const bucket = store[providerId];
        if (!bucket)
            return;
        if (!(accountId in bucket))
            return;
        delete bucket[accountId];
        writeMetaStore(store, storagePolicy);
    });
}
let cachedDefaultPool = null;
let cachedRuntimeStoragePolicy = null;
/**
 * Module-level singleton for the default pool wired against `@elizaos/auth/auth`'s
 * account-storage and the pool-owned metadata file. Plugins and runtime
 * resolvers should import `getDefaultAccountPool()` rather than constructing
 * a new pool directly.
 */
/**
 * The storage policy every account mutation in this module presents.
 * `getAccessToken` refuses to refresh without one, and a refresh that rotates a
 * one-time grant must be able to persist what came back, so token resolution
 * needs the same policy the pool's read/write/delete closures already carry.
 */
function defaultRuntimeStoragePolicy() {
    if (!cachedRuntimeStoragePolicy) {
        cachedRuntimeStoragePolicy = createRuntimeAccountStoragePolicy(process.env.ELIZA_HOME || resolveStateDir());
    }
    return cachedRuntimeStoragePolicy;
}
export function getDefaultAccountPool() {
    if (!cachedDefaultPool) {
        const storagePolicy = defaultRuntimeStoragePolicy();
        cachedDefaultPool = new AccountPool({
            readAccounts: () => loadAllAccounts(storagePolicy),
            writeAccount: (account) => persistAccount(account, storagePolicy),
            deleteAccount: (providerId, accountId) => deleteAccountMeta(providerId, accountId, storagePolicy),
        });
        installAnthropicBridge(cachedDefaultPool);
        installCodingAgentSelectorBridge(cachedDefaultPool);
    }
    return cachedDefaultPool;
}
const defaultDirectProviderEnvLedger = new Map();
/**
 * Baselines are scoped to a ledger so tests and alternate hosts do not share
 * authority state. A WeakMap keeps the public ledger wire shape compatible
 * while retaining the operator values displaced by a live pool export.
 */
const displacedDirectProviderEnv = new WeakMap();
const directProviderExportGeneration = new WeakMap();
function nextDirectProviderExportGeneration(ledger) {
    const generation = (directProviderExportGeneration.get(ledger) ?? 0) + 1;
    directProviderExportGeneration.set(ledger, generation);
    return generation;
}
function assignExportedEnv(env, ledger, key, value) {
    let displaced = displacedDirectProviderEnv.get(ledger);
    if (!displaced) {
        displaced = new Map();
        displacedDirectProviderEnv.set(ledger, displaced);
    }
    if (!displaced.has(key)) {
        const previous = env[key];
        displaced.set(key, previous === undefined
            ? { present: false }
            : { present: true, value: previous });
    }
    env[key] = value;
}
function restoreExportedEnv(env, ledger, key, ownedValue) {
    if (env[key] !== ownedValue)
        return;
    const displaced = displacedDirectProviderEnv.get(ledger)?.get(key);
    if (displaced?.present)
        env[key] = displaced.value;
    else
        delete env[key];
}
function retractExportedDirectProviderEnv(providerId, env, ledger) {
    const previous = ledger.get(providerId);
    if (!previous)
        return;
    ledger.delete(providerId);
    const envKey = DIRECT_ACCOUNT_PROVIDER_ENV[providerId];
    if (previous.providerEnv !== false) {
        restoreExportedEnv(env, ledger, envKey, previous.token);
        if (providerId === "zai-api" && env.Z_AI_API_KEY === previous.token) {
            restoreExportedEnv(env, ledger, "Z_AI_API_KEY", previous.token);
        }
    }
    const openAiCompatBase = OPENAI_COMPAT_BASE_BY_DIRECT_PROVIDER[providerId];
    if (previous.openAiCompat && openAiCompatBase) {
        restoreExportedEnv(env, ledger, "OPENAI_API_KEY", previous.token);
        restoreExportedEnv(env, ledger, "OPENAI_BASE_URL", openAiCompatBase);
    }
}
function retractAllExportedDirectProviderEnvInternal(env, ledger) {
    for (const providerId of DIRECT_ACCOUNT_PROVIDER_IDS) {
        retractExportedDirectProviderEnv(providerId, env, ledger);
    }
    displacedDirectProviderEnv.delete(ledger);
}
export function retractAllExportedDirectProviderEnv(env, ledger) {
    nextDirectProviderExportGeneration(ledger);
    retractAllExportedDirectProviderEnvInternal(env, ledger);
}
/**
 * Export the pool-selected credential of every direct provider into `env`.
 *
 * The pool is the authority: when it rejects every linked account (disabled,
 * invalid, rate-limited, or a pin that names no account) nothing is exported and
 * any value this pass previously exported for that provider is retracted, so a
 * user-excluded key can never keep serving billable calls. Launch env set by the
 * operator is only consulted for the active OpenAI-compatible route when the
 * provider has no linked accounts at all.
 */
export async function applyDirectProviderCredentialsToEnv(activeBackend, deps) {
    const { pool, env, ledger } = deps;
    const generation = nextDirectProviderExportGeneration(ledger);
    // Revoke the prior export before any storage or selection read can fail or
    // suspend. A durable disable/delete must never leave its old credential live
    // merely because the follow-up reconciliation could not finish.
    retractAllExportedDirectProviderEnvInternal(env, ledger);
    const activeProvider = activeBackend
        ? DIRECT_PROVIDER_BY_BACKEND[activeBackend]
        : undefined;
    const selected = new Map();
    const providersWithAccounts = new Set();
    for (const providerId of DIRECT_ACCOUNT_PROVIDER_IDS) {
        const accounts = deps.listAccounts(providerId);
        if (accounts.length === 0)
            continue;
        providersWithAccounts.add(providerId);
        const account = await pool.select({
            providerId,
            sessionKey: `env:${providerId}`,
            ...selectionForProvider(providerId),
        });
        const token = account ? await deps.getToken(providerId, account.id) : null;
        if (account && token)
            selected.set(providerId, token);
    }
    // A newer mutation began a sync while this pass was resolving credentials.
    // Its view of account eligibility is authoritative; an older snapshot must
    // never re-export a credential after the newer pass disabled or deleted it.
    if (directProviderExportGeneration.get(ledger) !== generation)
        return;
    for (const [providerId, token] of selected) {
        const envKey = DIRECT_ACCOUNT_PROVIDER_ENV[providerId];
        assignExportedEnv(env, ledger, envKey, token);
        if (providerId === "zai-api") {
            if (!env.Z_AI_API_KEY) {
                assignExportedEnv(env, ledger, "Z_AI_API_KEY", token);
            }
        }
        ledger.set(providerId, {
            token,
            openAiCompat: false,
            providerEnv: true,
        });
    }
    let activeProviderToken = activeProvider
        ? (selected.get(activeProvider) ?? null)
        : null;
    if (activeProvider &&
        !activeProviderToken &&
        !providersWithAccounts.has(activeProvider)) {
        const envKey = DIRECT_ACCOUNT_PROVIDER_ENV[activeProvider];
        activeProviderToken = env[envKey]?.trim() || null;
        if (!activeProviderToken && activeProvider === "zai-api") {
            activeProviderToken = env.Z_AI_API_KEY?.trim() || null;
        }
        if (!activeProviderToken && activeProvider === "moonshot-api") {
            activeProviderToken = env.KIMI_API_KEY?.trim() || null;
        }
    }
    const openAiCompatibleBase = activeProvider
        ? OPENAI_COMPAT_BASE_BY_DIRECT_PROVIDER[activeProvider]
        : undefined;
    if (openAiCompatibleBase && activeProviderToken) {
        assignExportedEnv(env, ledger, "OPENAI_API_KEY", activeProviderToken);
        assignExportedEnv(env, ledger, "OPENAI_BASE_URL", openAiCompatibleBase);
        const exported = activeProvider ? ledger.get(activeProvider) : undefined;
        if (exported) {
            exported.openAiCompat = true;
        }
        else if (activeProvider) {
            // The provider key came from operator launch env, but the compatibility
            // aliases are still values written by this module and must be retracted
            // or restored on route switch/reset.
            ledger.set(activeProvider, {
                token: activeProviderToken,
                openAiCompat: true,
                providerEnv: false,
            });
        }
    }
}
/**
 * Boot-time and mutation-time bridge: re-reads the selection config, then
 * exports the selected credential of every direct provider into `process.env`.
 * The account routes call this after add, replace, enable/disable, priority,
 * strategy, and delete so the live environment follows pool authority without
 * a process restart.
 */
export async function applyAccountPoolApiCredentials(opts = {}) {
    configureDefaultAccountPoolSelection({
        accountStrategies: opts.accountStrategies,
        serviceRouting: opts.serviceRouting,
    });
    await applyDirectProviderCredentialsToEnv(opts.activeBackend, {
        pool: getDefaultAccountPool(),
        listAccounts: (providerId) => listProviderAccounts(providerId),
        getToken: (providerId, accountId) => getAccountAccessToken(providerId, accountId, {
            storagePolicy: defaultRuntimeStoragePolicy(),
        }),
        env: process.env,
        ledger: defaultDirectProviderEnvLedger,
    });
}
function accountPoolUsagePrimingEnabled() {
    const value = process.env.ELIZA_ACCOUNT_POOL_USAGE_PRIMING?.trim().toLowerCase();
    return (value !== "0" && value !== "false" && value !== "no" && value !== "off");
}
function accountNeedsUsagePriming(account, now) {
    if (!account?.enabled)
        return false;
    const resetsAt = account.usage?.resetsAt;
    const lastPrimedAt = account.lastPrimedAt;
    if (typeof resetsAt === "number" && resetsAt <= now) {
        // One attempt per crossed reset boundary, even inside the normal debounce.
        return typeof lastPrimedAt !== "number" || lastPrimedAt < resetsAt;
    }
    if (typeof resetsAt === "number")
        return false;
    return (typeof lastPrimedAt !== "number" ||
        lastPrimedAt + USAGE_PRIMING_DEBOUNCE_MS <= now);
}
async function probeAnthropicUsagePriming(accessToken, fetchImpl) {
    const response = await fetchImpl(ANTHROPIC_MESSAGES_URL, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${accessToken}`,
            "anthropic-beta": "oauth-2025-04-20",
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            model: ANTHROPIC_USAGE_PRIMING_MODEL,
            max_tokens: 1,
            messages: [{ role: "user", content: "hi" }],
        }),
    });
    if (!response.ok) {
        await response.body?.cancel();
        throw new Error(`Anthropic usage priming probe failed: HTTP ${response.status}`);
    }
    await response.body?.cancel();
}
async function primeAnthropicUsageThenRefresh(pool, record, token, deps) {
    // Persist the attempt before probing so a soft provider failure cannot cause
    // a probe storm on every keep-alive sweep.
    await pool.markUsagePrimed(record.id, deps.now(), {
        providerId: "anthropic-subscription",
    });
    try {
        await probeAnthropicUsagePriming(token, deps.fetch);
    }
    catch {
        // error-policy:J7 diagnostics-must-not-kill-the-loop — priming is an
        // observability wake-up call, not credential proof. Keep health untouched
        // and never include provider error text because OAuth failures may echo
        // request metadata.
        logger.warn(`[AccountPool] Anthropic usage priming failed for account ${record.id}; usage refresh will continue.`);
    }
    await pool.refreshUsage(record.id, token, {
        providerId: "anthropic-subscription",
        fetch: deps.fetch,
    });
    const refreshedReset = pool.get(record.id, "anthropic-subscription")?.usage
        ?.resetsAt;
    if (refreshedReset !== undefined && refreshedReset > deps.now()) {
        return;
    }
    await deps.sleep(deps.usagePrimingRetryDelayMs);
    await pool.refreshUsage(record.id, token, {
        providerId: "anthropic-subscription",
        fetch: deps.fetch,
    });
}
function resolveKeepAliveDeps(deps = {}) {
    const envDelay = Number.parseInt(process.env.ELIZA_ACCOUNT_POOL_USAGE_PRIMING_RETRY_DELAY_MS ?? "", 10);
    const usagePrimingRetryDelayMs = deps.usagePrimingRetryDelayMs ??
        (Number.isFinite(envDelay) && envDelay >= 0
            ? envDelay
            : USAGE_PRIMING_RETRY_DELAY_MS);
    return {
        fetch: deps.fetch ?? fetch,
        sleep: deps.sleep ??
            ((ms) => new Promise((resolve) => setTimeout(resolve, ms))),
        now: deps.now ?? (() => Date.now()),
        usagePrimingRetryDelayMs,
    };
}
export async function sweepAccountPoolKeepAlive(deps = {}) {
    const pool = getDefaultAccountPool();
    const keepAliveDeps = resolveKeepAliveDeps(deps);
    const result = {
        checked: 0,
        refreshed: 0,
        failed: 0,
    };
    for (const providerId of ACCOUNT_CREDENTIAL_PROVIDER_IDS) {
        await pool.sweepExpired(providerId);
        for (const record of listProviderAccounts(providerId)) {
            result.checked += 1;
            const pooled = pool.get(record.id, providerId);
            if (pooled?.enabled === false || pooled?.health === "expired")
                continue;
            // A parked subscription account's refresh grant is dead until a human
            // re-auths, so resolving it burns a doomed refresh against the
            // provider's token endpoint (plus an error log line) every sweep,
            // forever. Probe parked accounts only when the stored credential has
            // changed since the last probe (a re-auth just landed — re-admit
            // within one sweep) or the cooldown elapsed. Direct-API probes stay
            // unthrottled: they read a static key with no network cost, and they
            // are the heal path for accounts flagged by earlier failures.
            if ((pooled?.health === "needs-reauth" || pooled?.health === "invalid") &&
                isSubscriptionProvider(providerId)) {
                const lastProbeMs = pooled.healthDetail?.lastChecked ?? 0;
                const credentialChanged = record.updatedAt > lastProbeMs;
                if (!credentialChanged &&
                    Date.now() - lastProbeMs < PARKED_SUBSCRIPTION_PROBE_COOLDOWN_MS) {
                    continue;
                }
            }
            // A Codex CLI may have rotated the one-time refresh token inside its
            // per-account CODEX_HOME mid-session; adopt it BEFORE resolving, or the
            // refresh below burns on the consumed token and this sweep marks a
            // perfectly recoverable account needs-reauth.
            if (providerId === "openai-codex") {
                await adoptRotatedCodexTokens(record.id);
            }
            const outcome = await getAccountAccessToken(providerId, record.id, {
                storagePolicy: defaultRuntimeStoragePolicy(),
                outcome: true,
            });
            if (!outcome.ok) {
                result.failed += 1;
                // Only a proven credential failure parks the account. Transport and
                // provider outages keep the current health — one network blip must
                // not mass-flag a healthy fleet as needs-reauth — and the next sweep
                // simply retries.
                if (outcome.kind === "auth") {
                    await pool.markNeedsReauth(record.id, outcome.message, {
                        providerId,
                    });
                }
                continue;
            }
            const token = outcome.accessToken;
            if (!isSubscriptionProvider(providerId)) {
                // Reading a locally stored API key proves only that storage is intact.
                // Provider-observed 401/429 health remains authoritative until the
                // explicit authenticated probe route records a successful response.
                continue;
            }
            try {
                if (providerId === "anthropic-subscription" &&
                    accountPoolUsagePrimingEnabled() &&
                    accountNeedsUsagePriming(pool.get(record.id, "anthropic-subscription"), keepAliveDeps.now())) {
                    await primeAnthropicUsageThenRefresh(pool, record, token, keepAliveDeps);
                }
                else {
                    await pool.refreshUsage(record.id, token, {
                        providerId,
                        fetch: keepAliveDeps.fetch,
                        ...(record.organizationId
                            ? { codexAccountId: record.organizationId }
                            : {}),
                    });
                }
                result.refreshed += 1;
            }
            catch (err) {
                result.failed += 1;
                const message = err instanceof Error ? err.message : String(err);
                if (/\b(?:HTTP\s*)?(?:401|403)\b|unauthoriz/i.test(message)) {
                    await pool.markNeedsReauth(record.id, message, { providerId });
                }
                else if (/\b(?:HTTP\s*)?429\b|rate.?limit/i.test(message)) {
                    await pool.markRateLimited(record.id, Date.now() + DEFAULT_RATE_LIMIT_BACKOFF_MS, message, { providerId });
                }
                else {
                    logger.warn(`[AccountPool] usage refresh failed for ${providerId}/${record.id} without proving credential failure: ${message}`);
                }
                // Usage parsing, transport, and provider-shape failures do not prove
                // the credential is bad. Keep the current health so a successfully
                // replaced credential cannot be permanently evicted merely because
                // an optional usage endpoint changed shape. Explicit authentication
                // failures above remain terminal; token-resolution failures are
                // handled before this probe.
            }
        }
    }
    return result;
}
let keepAliveTimer = null;
let keepAliveRunning = false;
export function startAccountPoolKeepAlive(intervalMs = KEEP_ALIVE_INTERVAL_MS) {
    const disabled = process.env.ELIZA_ACCOUNT_POOL_KEEPALIVE?.trim().toLowerCase();
    if (disabled === "0" ||
        disabled === "false" ||
        disabled === "no" ||
        disabled === "off") {
        return;
    }
    if (keepAliveTimer)
        return;
    const run = () => {
        if (keepAliveRunning)
            return;
        keepAliveRunning = true;
        void sweepAccountPoolKeepAlive()
            .catch((err) => {
            // error-policy:J1 timer boundary observes rejected sweeps; the next
            // interval retries without translating credential failure to health.
            logger.error(`[AccountPool] keep-alive sweep failed: ${String(err)}`);
        })
            .finally(() => {
            keepAliveRunning = false;
        });
    };
    keepAliveTimer = setInterval(run, Math.max(60000, intervalMs));
    keepAliveTimer.unref();
    run();
}
export function stopAccountPoolKeepAlive() {
    if (keepAliveTimer) {
        clearInterval(keepAliveTimer);
        keepAliveTimer = null;
    }
    keepAliveRunning = false;
}
/**
 * Install the `globalThis`-keyed bridge that plugin-anthropic's
 * credential-store reads. Idempotent — repeated installs replace the
 * previous bridge.
 */
function installAnthropicBridge(pool) {
    const bridge = {
        selectAnthropicSubscription: async (opts) => {
            const account = await pool.select({
                providerId: "anthropic-subscription",
                sessionKey: opts?.sessionKey,
                exclude: opts?.exclude,
                ...selectionForProvider("anthropic-subscription"),
            });
            if (!account)
                return null;
            // expiresAt is sourced from the underlying credential blob via
            // `loadCredentials`; we cache it on the cached account record's
            // lastUsedAt is independent. The plugin only uses expiresAt as a
            // hint for cache TTL, so an Infinity fallback is acceptable.
            return { id: account.id, expiresAt: Number.POSITIVE_INFINITY };
        },
        getAccessToken: (providerId, accountId) => getAccountAccessToken(providerId, accountId, {
            storagePolicy: defaultRuntimeStoragePolicy(),
        }),
        markInvalid: (accountId, detail) => pool.markInvalid(accountId, detail, {
            providerId: "anthropic-subscription",
        }),
        markRateLimited: (accountId, untilMs, detail) => pool.markRateLimited(accountId, untilMs, detail, {
            providerId: "anthropic-subscription",
        }),
    };
    setAnthropicAccountPoolBridge(bridge);
}
export function resetDefaultAccountPoolAfterCredentialReset() {
    stopAccountPoolKeepAlive();
    retractAllExportedDirectProviderEnv(process.env, defaultDirectProviderEnvLedger);
    cachedDefaultPool = null;
    cachedRuntimeStoragePolicy = null;
}
//# sourceMappingURL=account-pool.js.map