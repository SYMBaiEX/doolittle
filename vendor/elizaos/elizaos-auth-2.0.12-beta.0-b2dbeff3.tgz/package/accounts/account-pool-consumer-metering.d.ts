export interface AccountPoolConsumerKey {
    id: string;
    label: string;
    enabled: boolean;
    dailyTokenQuota: number | null;
    keyDigest: string;
    keyPrefix: string;
    createdAt: number;
    updatedAt: number;
    lastUsedAt?: number;
}
export interface AccountPoolConsumerKeyPublic {
    id: string;
    label: string;
    enabled: boolean;
    dailyTokenQuota: number | null;
    keyPrefix: string;
    createdAt: number;
    updatedAt: number;
    lastUsedAt?: number;
}
export interface AccountPoolConsumerKeyCreateInput {
    label?: unknown;
    enabled?: unknown;
    dailyTokenQuota?: unknown;
}
export interface AccountPoolConsumerKeyUpdateInput {
    label?: unknown;
    enabled?: unknown;
    dailyTokenQuota?: unknown;
}
export interface AccountPoolConsumerUsage {
    input_tokens: number;
    output_tokens: number;
    cache_read_input_tokens: number;
    cache_creation_input_tokens: number;
}
export interface AccountPoolConsumerUsageRecord {
    ts: number;
    consumerId: string;
    consumerLabel: string;
    model: string | null;
    streaming: boolean;
    status: number;
    latencyMs: number;
    usage: AccountPoolConsumerUsage;
    totalTokens: number;
}
export interface AccountPoolConsumerUsageTotals {
    totals: {
        requests: number;
        tokens: number;
        input_tokens: number;
        output_tokens: number;
        cache_read_input_tokens: number;
        cache_creation_input_tokens: number;
        errors: number;
        latencyMs: number;
    };
    byConsumer: Record<string, AccountPoolConsumerUsageTotals["totals"]>;
    byDay: Record<string, AccountPoolConsumerUsageTotals["totals"]>;
    byConsumerDay: Record<string, AccountPoolConsumerUsageTotals["totals"]>;
}
export interface AccountPoolConsumerUsageQuery {
    consumerId?: string;
    startMs?: number;
    endMs?: number;
}
export interface AccountPoolConsumerUsageBreakdown {
    totals: AccountPoolConsumerUsageTotals["totals"];
    byDay: Record<string, AccountPoolConsumerUsageTotals["totals"]>;
    byConsumer: Record<string, AccountPoolConsumerUsageTotals["totals"]>;
    records: AccountPoolConsumerUsageRecord[];
}
export interface AccountPoolConsumerAdmission {
    id: string;
    consumerId: string;
    day: string;
    reservedTokens: number;
}
export type AccountPoolConsumerAuthResult = {
    ok: true;
    mode: "legacy";
    consumer: null;
    admission: null;
    upstreamHeaders: Headers;
} | {
    ok: true;
    mode: "consumer";
    consumer: AccountPoolConsumerKeyPublic;
    admission: AccountPoolConsumerAdmission;
    upstreamHeaders: Headers;
} | {
    ok: false;
    status: 401 | 429;
    body: AnthropicErrorBody;
    upstreamHeaders: Headers;
};
export interface AnthropicErrorBody {
    type: "error";
    error: {
        type: "authentication_error" | "rate_limit_error";
        message: string;
    };
}
type HeaderInput = Headers | Record<string, string | string[] | undefined>;
export declare function createAccountPoolConsumerKey(input?: AccountPoolConsumerKeyCreateInput): {
    key: string;
    consumer: AccountPoolConsumerKeyPublic;
} | null;
export declare function listAccountPoolConsumerKeys(): AccountPoolConsumerKeyPublic[];
export declare function updateAccountPoolConsumerKey(id: string, input: AccountPoolConsumerKeyUpdateInput): AccountPoolConsumerKeyPublic | null | "invalid";
export declare function rotateAccountPoolConsumerKey(id: string): {
    key: string;
    consumer: AccountPoolConsumerKeyPublic;
} | null;
export declare function findAccountPoolConsumerByKey(key: string): AccountPoolConsumerKeyPublic | null | "disabled";
export declare function stripAccountPoolConsumerCredentialHeaders(headers: HeaderInput): Headers;
export declare function anthropicAuthError(message?: string): AnthropicErrorBody;
export declare function anthropicQuotaError(message?: string): AnthropicErrorBody;
export declare function estimateAnthropicRequestReservation(payload: unknown): number;
export declare function authenticateAccountPoolConsumerRequest(headers: HeaderInput, requestPayload: unknown, env?: NodeJS.ProcessEnv): Promise<AccountPoolConsumerAuthResult>;
export declare function __resetAccountPoolConsumerMeteringForTests(): void;
export declare function admitAccountPoolConsumerRequest(consumer: AccountPoolConsumerKeyPublic, reservationTokens?: number): Promise<AccountPoolConsumerAdmission | {
    ok: false;
    status: 429;
    body: AnthropicErrorBody;
}>;
export declare function recordAccountPoolConsumerUsage(input: Omit<AccountPoolConsumerUsageRecord, "ts" | "totalTokens"> & {
    ts?: number;
    admission?: AccountPoolConsumerAdmission;
}): Promise<AccountPoolConsumerUsageRecord>;
export declare function extractAnthropicUsageFromJson(payload: unknown): AccountPoolConsumerUsage;
export declare function parseAnthropicSseEventUsage(payload: unknown): Partial<AccountPoolConsumerUsage> | null;
export interface AnthropicSseUsageMeter extends TransformStream<Uint8Array, Uint8Array> {
    /** Idempotent finalizer. Call from the proxy's finally block on abort/error. */
    finalizeUsage(): Promise<void>;
}
export declare function createAnthropicSseUsageMeter(onUsage: (usage: AccountPoolConsumerUsage) => void | Promise<void>): AnthropicSseUsageMeter;
export declare function getAccountPoolConsumerUsageSummary(): Promise<AccountPoolConsumerUsageBreakdown>;
export declare function queryAccountPoolConsumerUsage(query?: AccountPoolConsumerUsageQuery): Promise<AccountPoolConsumerUsageBreakdown>;
export {};
//# sourceMappingURL=account-pool-consumer-metering.d.ts.map