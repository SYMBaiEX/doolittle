import { type AccountPool } from "./account-pool.js";
import { type queryAccountPoolConsumerUsage } from "./account-pool-consumer-metering.js";
type PublicAccountState = "serving" | "draining" | "exhausted";
type CapacityState = "EXHAUSTED" | "BURNING HOT" | "OK" | "FRESH";
export interface PublicPoolModelBucket {
    usedPct: number;
}
export type PublicPoolModelBuckets = {
    available: true;
    fable: PublicPoolModelBucket | null;
    sonnet: PublicPoolModelBucket | null;
} | {
    available: false;
    note: string;
};
interface InternalPoolModelBucket extends PublicPoolModelBucket {
    resetAt: number | null;
}
type InternalPoolModelBuckets = {
    available: true;
    fable: InternalPoolModelBucket | null;
    sonnet: InternalPoolModelBucket | null;
} | {
    available: false;
    note: string;
};
interface InternalPoolStatusAccount {
    /** Stable local identity for persisted burn snapshots. Never serialized. */
    snapshotKey: string;
    name: string;
    accountState: PublicAccountState;
    sessionUsedPct: number | null;
    sessionHeadroomPct: number | null;
    weeklyUsedPct: number | null;
    weeklyHeadroomPct: number | null;
    weeklyResetAt: number | null;
    weeklyResetIn: string | null;
    fableUsedPct: number | null;
    modelBuckets: InternalPoolModelBuckets;
    burnRatePctPerHour: number | null;
    burnSampleHours: number | null;
    projectedExhaustionIn: string | null;
    projectedBeforeReset: boolean | null;
    state: CapacityState;
    exhaustionMessage: string;
}
export interface PublicPoolStatusAccount {
    name: string;
    accountState: PublicAccountState;
    sessionUsedPct: number | null;
    sessionHeadroomPct: number | null;
    weeklyUsedPct: number | null;
    weeklyHeadroomPct: number | null;
    weeklyResetIn: string | null;
    fableUsedPct: number | null;
    modelBuckets: PublicPoolModelBuckets;
    burnRatePctPerHour: number | null;
    burnSampleHours: number | null;
    projectedExhaustionIn: string | null;
    projectedBeforeReset: boolean | null;
    state: CapacityState;
    exhaustionMessage: string;
}
export interface PublicPoolStatus {
    updatedAt: string;
    usageRefreshedAt: string | null;
    pool: {
        accounts: number;
        capacityPct: number;
        selectableAccounts: number;
    };
    fable: {
        leftPct: number;
        ofPct: number;
        source: "fable weekly bucket" | "all-model weekly fallback";
    };
    allModels: {
        leftPct: number;
        ofPct: number;
    };
    perAccount: PublicPoolStatusAccount[];
    publicEdge: {
        today: PublicPoolConsumerTotals;
        allTime: PublicPoolConsumerTotals;
    };
    urgency: {
        burnRatePctPerHour: number | null;
        projectedDepletionIn: string | null;
        depletionMessage: string;
        nextRefill: {
            account: string;
            in: string;
            capacityAddedPct: number;
        } | null;
    };
    health: {
        snapshotAgeSeconds: number;
        snapshotAge: string;
        stale: boolean;
    };
}
interface InternalPoolStatus extends Omit<PublicPoolStatus, "perAccount"> {
    perAccount: InternalPoolStatusAccount[];
}
export interface PublicPoolConsumerTotals {
    requests: number;
    tokens: number;
    inputTokens: number;
    outputTokens: number;
    cacheReadInputTokens: number;
    cacheCreationInputTokens: number;
    errors: number;
    latencyMs: number;
}
interface AccountPoolStatusDeps {
    pool?: AccountPool;
    queryConsumerUsage?: typeof queryAccountPoolConsumerUsage;
    now?: () => number;
    stateDir?: () => string;
    cacheTtlMs?: number;
    snapshotMaxLines?: number;
}
export declare function serializePublicPoolStatus(status: InternalPoolStatus): PublicPoolStatus;
export declare function getPublicAccountPoolStatus(): Promise<PublicPoolStatus>;
export declare function __resetAccountPoolStatusForTests(deps?: AccountPoolStatusDeps): void;
export {};
//# sourceMappingURL=account-pool-status.d.ts.map