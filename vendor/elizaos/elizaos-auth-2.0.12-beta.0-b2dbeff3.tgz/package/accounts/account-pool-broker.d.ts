import { type PoolProviderId, type Strategy } from "./account-selection.js";
import type { LinkedAccountUsage } from "@elizaos/contracts";
import type { AccountPoolBrokerLastReportedStatus, AccountPoolBrokerProviderSnapshot, AccountPoolBrokerSnapshot } from "@elizaos/core";
import { type AccountPool } from "./account-pool.js";
export interface AccountPoolBrokerLeaseRequest {
    providerId: PoolProviderId;
    sessionKey: string;
    strategy?: Strategy;
    exclude?: string[];
}
export interface AccountPoolBrokerReportRequest {
    leaseId: string;
    ok: boolean;
    httpStatus?: number;
    errorCode?: string;
    retryAfterMs?: number;
    tokens?: number;
    latencyMs?: number;
    model?: string;
}
export interface AccountPoolBrokerReleaseRequest {
    leaseId: string;
}
export interface AccountPoolBrokerLeaseResponse {
    leaseId: string;
    providerId: PoolProviderId;
    accountId: string;
    accessToken: string;
    accessExpiresAt: number;
    leaseExpiresAt: number;
    usage?: LinkedAccountUsage;
    chatgptAccountId?: string;
}
export interface AccountPoolBrokerDeps {
    pool?: AccountPool;
    now?: () => number;
    tokenResolver?: typeof resolveBrokerAccessToken;
    idGenerator?: () => string;
    leaseTtlMs?: number;
}
export declare function parseBrokerLeaseRequest(body: Record<string, unknown>): AccountPoolBrokerLeaseRequest | null;
export declare function parseBrokerReportRequest(body: Record<string, unknown>): AccountPoolBrokerReportRequest | null;
export declare function parseBrokerReleaseRequest(body: Record<string, unknown>): AccountPoolBrokerReleaseRequest | null;
export declare function resolveBrokerAccessToken(providerId: PoolProviderId, accountId: string): Promise<{
    accessToken: string;
    accessExpiresAt: number;
}>;
export declare class AccountPoolBroker {
    private readonly pool;
    private readonly now;
    private readonly tokenResolver;
    private readonly idGenerator;
    private readonly leaseTtlMs;
    private readonly byLeaseId;
    private readonly bySessionKey;
    private readonly accountObservability;
    private readonly lastSelectionByProvider;
    private readonly recentFailoversByProvider;
    private readonly pendingFailoversBySession;
    constructor(deps?: AccountPoolBrokerDeps);
    lease(request: AccountPoolBrokerLeaseRequest): Promise<AccountPoolBrokerLeaseResponse | null>;
    report(report: AccountPoolBrokerReportRequest): Promise<{
        ok: true;
    } | {
        ok: false;
        error: "unknown_lease" | "expired_lease";
    }>;
    release(request: AccountPoolBrokerReleaseRequest): {
        ok: true;
        released: boolean;
    };
    health(): {
        ok: true;
        enabled: true;
        providers: Array<{
            providerId: PoolProviderId;
            total: number;
            enabled: number;
            selectable: number;
            lastSelection: AccountPoolBrokerProviderSnapshot["lastSelection"];
        }>;
        activeLeases: number;
        accounts: Record<string, {
            activeLeaseCount: number;
            lastLeaseAt: number | null;
            lastReportedStatus: AccountPoolBrokerLastReportedStatus | null;
        }>;
    };
    snapshot(): AccountPoolBrokerSnapshot;
    private observeLease;
    private ensureAccountObservability;
    private resolveSessionPin;
    private deleteLease;
    private pruneExpired;
}
//# sourceMappingURL=account-pool-broker.d.ts.map