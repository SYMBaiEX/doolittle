import type { LinkedAccountConfig, LinkedAccountProviderId } from "@elizaos/contracts";
import type { DirectAccountProvider } from "../auth/types.js";
export type Strategy = "priority" | "round-robin" | "least-used" | "quota-aware" | "reset-soonest" | "drain-soonest-reset";
export type PoolProviderId = LinkedAccountProviderId;
interface AccountPoolSelectionRoute {
    backend?: string;
    accountId?: string;
    accountIds?: string[];
    strategy?: string;
}
export interface AccountPoolSelectionConfig {
    accountStrategies?: Partial<Record<PoolProviderId, unknown>>;
    serviceRouting?: {
        llmText?: AccountPoolSelectionRoute;
    } | null;
}
export declare const DIRECT_PROVIDER_BY_BACKEND: Readonly<Record<string, DirectAccountProvider>>;
export declare function isAccountExpired(account: LinkedAccountConfig, now?: number): boolean;
/**
 * Health half of the eligibility gate, shared with the coding-agent bridge's
 * `describe()` so availability reporting can never disagree with what
 * `select()` would actually serve: `ok` is selectable, and a rate-limited
 * account is selectable again once its `healthDetail.until` reset has elapsed
 * (`invalid` / `needs-reauth` never re-admit on their own). Counting only
 * `health === "ok"` here used to report `healthy: 0` for a pool whose
 * rate-limit window had already elapsed — making the orchestrator's failover
 * gate refuse a respawn that `select()` would have served.
 */
export declare function isAccountSelectableNow(account: LinkedAccountConfig, now?: number): boolean;
/**
 * Live read of the configured per-provider selection (the app's
 * `config.accountStrategies` picker plus any llmText service-routing pin).
 * Every account-selecting bridge resolves through this so the picker steers
 * all of them — including the coding-agent bridge.
 */
export declare function selectionForProvider(providerId: PoolProviderId, opts?: {
    includeProviderDefault?: boolean;
}): {
    strategy?: Strategy;
    accountIds?: string[];
};
export declare function configuredAccountStrategyForProvider(providerId: PoolProviderId): Strategy | undefined;
export declare function configureDefaultAccountPoolSelection(config?: AccountPoolSelectionConfig): void;
export {};
//# sourceMappingURL=account-selection.d.ts.map