import { type AccountPoolSelectionConfig, type PoolProviderId, type Strategy } from "./account-selection.js";
import type { LinkedAccountConfig, LinkedAccountsConfig } from "@elizaos/contracts";
import { type AccountCredentialRecord } from "../auth/account-storage.js";
import { type DirectAccountProvider } from "../auth/types.js";
export interface AccountPoolDeps {
    /** Read the current `LinkedAccountsConfig` (live). */
    readAccounts: () => Record<string, LinkedAccountConfig>;
    /** Persist a single account's mutated fields. */
    writeAccount: (account: LinkedAccountConfig) => Promise<void>;
    /** Remove the metadata overlay for an account. */
    deleteAccount?: (providerId: PoolProviderId, accountId: string) => Promise<void>;
}
export interface SelectInput {
    providerId: PoolProviderId;
    /** Stable session key for affinity (e.g. agent id + run id). */
    sessionKey?: string;
    /** Defaults to `"priority"`. */
    strategy?: Strategy;
    /** Explicit pool; defaults to all enabled accounts for `providerId`. */
    accountIds?: string[];
    /** Account IDs to skip (e.g. just-failed accounts). */
    exclude?: string[];
    /** Requested model/display name for provider-specific weekly buckets. */
    model?: string;
}
export declare class AccountPool {
    private readonly deps;
    private readonly affinity;
    private readonly roundRobinCursor;
    private readonly recentlySelectedAt;
    private selectionClock;
    constructor(deps: AccountPoolDeps);
    select(input: SelectInput): Promise<LinkedAccountConfig | null>;
    /**
     * Non-mutating dry-run of selection for the accounts API / settings UI:
     * "which account would we serve next for this provider, and why?" Uses the
     * SAME eligibility + strategy ordering as {@link select} but never stamps a
     * selection or touches affinity, so polling it from the UI has no runtime
     * side effects. Ignores session affinity (that's per-request state the UI
     * can't meaningfully reflect).
     */
    selectionState(providerId: PoolProviderId, strategy?: Strategy, opts?: {
        model?: string;
        accountIds?: string[];
    }): {
        activeAccountId: string | null;
        reason: string | null;
    };
    /** A request-scoped inventory; later requests must acquire a fresh snapshot. */
    readSnapshot(): {
        list(providerId?: PoolProviderId): LinkedAccountConfig[];
        selectionState(providerId: PoolProviderId, strategy?: Strategy): {
            activeAccountId: string | null;
            reason: string | null;
        };
    };
    private selectionStateFromAccounts;
    sweepExpired(providerId?: PoolProviderId): Promise<number>;
    private markExpiredAccounts;
    private filterEligible;
    private applyStrategy;
    /** Record that `accountId` was just selected, with a strictly-increasing,
     * epoch-aligned stamp so a same-millisecond burst still rotates. */
    private stampSelection;
    /** Most recent of the persisted `lastUsedAt` and the in-memory selection
     * stamp — so a just-picked account sorts as "more recently used". */
    private effectiveLastUsed;
    /** least-used comparator: spread load first by reported usage, then by
     * recency-of-use (persisted + in-flight selection). Recency is ranked ABOVE
     * `priority` here because least-used is a load-spreading strategy and the
     * default `priority` is just creation order — honoring it would pin every
     * equal-usage pick to the oldest account (the burst herd). `priority` only
     * breaks a recency tie. */
    private byLeastUsedEffective;
    list(providerId?: PoolProviderId): LinkedAccountConfig[];
    get(accountId: string, providerId?: PoolProviderId): LinkedAccountConfig | null;
    upsert(account: LinkedAccountConfig): Promise<void>;
    deleteMetadata(providerId: PoolProviderId, accountId: string): Promise<void>;
    recordCall(accountId: string, result: {
        tokens?: number;
        latencyMs?: number;
        ok: boolean;
        errorCode?: string;
        model?: string;
    }, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    refreshUsage(accountId: string, accessToken: string, opts?: {
        codexAccountId?: string;
        fetch?: typeof fetch;
        providerId?: PoolProviderId;
    }): Promise<void>;
    markRateLimited(accountId: string, untilMs: number, detail?: string, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    markRateLimitedUnknown(accountId: string, detail?: string, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    markNeedsReauth(accountId: string, detail?: string, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    markInvalid(accountId: string, detail?: string, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    markHealthy(accountId: string, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    markUsagePrimed(accountId: string, lastPrimedAt?: number, opts?: {
        providerId?: PoolProviderId;
    }): Promise<void>;
    /**
     * Re-probe accounts whose `health` is non-OK and whose `healthDetail.until`
     * has passed (or is absent). Used by background sweepers to recover
     * temporarily flagged accounts. We don't load access tokens here — the
     * caller probes via `refreshUsage` separately.
     */
    reprobeFlagged(): Promise<string[]>;
}
export declare function getDefaultAccountPool(): AccountPool;
export interface DirectProviderCredentialExportDeps {
    pool: Pick<AccountPool, "select">;
    listAccounts: (providerId: DirectAccountProvider) => readonly Pick<AccountCredentialRecord, "id">[];
    getToken: (providerId: DirectAccountProvider, accountId: string) => Promise<string | null>;
    env: NodeJS.ProcessEnv;
    /** Env values this module exported on earlier passes; cleared on fail-closed. */
    ledger: DirectProviderEnvLedger;
}
/**
 * Tracks which env values the export pass wrote so a later pass can retract
 * exactly those values. A displaced operator value is restored when pool
 * ownership ends; an operator edit made during ownership is left untouched.
 */
export type DirectProviderEnvLedger = Map<DirectAccountProvider, {
    token: string;
    openAiCompat: boolean;
    /** False when only compatibility aliases, not the provider key, are owned. */
    providerEnv?: boolean;
}>;
export declare function retractAllExportedDirectProviderEnv(env: NodeJS.ProcessEnv, ledger: DirectProviderEnvLedger): void;
/**
 * Export the pool-selected credential of every direct provider into `env`.
 *
 * The pool is the authority: when it rejects every linked account (disabled,
 * invalid, rate-limited, or a pin that names no account) nothing is exported and
 * any value this pass previously exported for that provider is retracted, so a
 * user-excluded key can never keep serving billable calls. Launch env set by the
 * operator is only consulted for the active OpenAI-compatible route when the
 * provider has no linked accounts at all.
 */
export declare function applyDirectProviderCredentialsToEnv(activeBackend: string | null | undefined, deps: DirectProviderCredentialExportDeps): Promise<void>;
/**
 * Boot-time and mutation-time bridge: re-reads the selection config, then
 * exports the selected credential of every direct provider into `process.env`.
 * The account routes call this after add, replace, enable/disable, priority,
 * strategy, and delete so the live environment follows pool authority without
 * a process restart.
 */
export declare function applyAccountPoolApiCredentials(opts?: {
    activeBackend?: string | null;
    accountStrategies?: AccountPoolSelectionConfig["accountStrategies"];
    serviceRouting?: AccountPoolSelectionConfig["serviceRouting"];
}): Promise<void>;
export interface AccountPoolKeepAliveResult {
    checked: number;
    refreshed: number;
    failed: number;
}
export interface AccountPoolKeepAliveDeps {
    fetch?: typeof fetch;
    sleep?: (ms: number) => Promise<void>;
    now?: () => number;
    usagePrimingRetryDelayMs?: number;
}
export declare function sweepAccountPoolKeepAlive(deps?: AccountPoolKeepAliveDeps): Promise<AccountPoolKeepAliveResult>;
export declare function startAccountPoolKeepAlive(intervalMs?: number): void;
export declare function stopAccountPoolKeepAlive(): void;
export declare function resetDefaultAccountPoolAfterCredentialReset(): void;
export type { LinkedAccountsConfig };
//# sourceMappingURL=account-pool.d.ts.map