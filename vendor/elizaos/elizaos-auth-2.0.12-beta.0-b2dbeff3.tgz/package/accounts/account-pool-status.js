import { isAccountSelectableNow, selectionForProvider, } from "./account-selection.js";
/**
 * Public-safe account-pool status snapshots for anonymous capacity reporting.
 *
 * This service reads the default account-pool metadata and consumer metering
 * totals, derives aggregate burn/projection signals, and persists only the
 * anonymized fields needed to compare future snapshots within the same reset
 * window. The HTTP route must serialize through the allowlist here; raw
 * account, consumer, key, and lease records never cross this boundary.
 */
import { createHash, randomBytes } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync, } from "node:fs";
import path from "node:path";
import { logger, resolveStateDir } from "@elizaos/core";
import { getDefaultAccountPool } from "./account-pool.js";
import { getAccountPoolConsumerUsageSummary, } from "./account-pool-consumer-metering.js";
const STATUS_TTL_MS = 60000;
const SNAPSHOT_MAX_LINES = 2000;
const SNAPSHOT_RESET_TOLERANCE_MS = 5 * 60000;
const STORE_DIR = "account-pool";
const SNAPSHOTS_FILE = "public-status-snapshots.jsonl";
const PROVIDER_ID = "anthropic-subscription";
let cache = null;
let inflight = null;
let depsOverride = {};
function nowMs() {
    return depsOverride.now?.() ?? Date.now();
}
function stateDir() {
    return depsOverride.stateDir?.() ?? resolveStateDir();
}
function snapshotFile() {
    return path.join(stateDir(), STORE_DIR, SNAPSHOTS_FILE);
}
function cacheTtlMs() {
    return depsOverride.cacheTtlMs ?? STATUS_TTL_MS;
}
function snapshotMaxLines() {
    return depsOverride.snapshotMaxLines ?? SNAPSHOT_MAX_LINES;
}
function ensureDir(filePath) {
    const dir = path.dirname(filePath);
    if (!existsSync(dir))
        mkdirSync(dir, { recursive: true, mode: 0o700 });
}
function atomicWriteText(filePath, value) {
    ensureDir(filePath);
    const tmp = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${process.pid}.${randomBytes(8).toString("hex")}.tmp`);
    writeFileSync(tmp, value, { encoding: "utf8", mode: 0o600 });
    renameSync(tmp, filePath);
}
function clampPct(value) {
    return typeof value === "number" && Number.isFinite(value)
        ? Math.max(0, Math.min(100, value))
        : null;
}
function round2(value) {
    return Number(value.toFixed(2));
}
function snapshotKey(account) {
    return createHash("sha256")
        .update(`${account.providerId}:${account.id}`, "utf8")
        .digest("hex");
}
function durationText(ms) {
    if (typeof ms !== "number" || !Number.isFinite(ms))
        return null;
    if (ms <= 0)
        return "now";
    const minutes = Math.max(1, Math.round(ms / 60000));
    const days = Math.floor(minutes / 1440);
    const hours = Math.floor((minutes % 1440) / 60);
    const mins = minutes % 60;
    if (days > 0)
        return `~${days}d ${hours}h`;
    if (hours > 0)
        return `~${hours}h ${mins}m`;
    return `~${mins}m`;
}
function resetText(ms) {
    const duration = durationText(ms);
    if (!duration)
        return null;
    if (duration === "now")
        return "reset due";
    return `resets in ${duration.replace(/^~/, "")}`;
}
function compactAge(ms) {
    if (ms < 60000)
        return "<1m";
    return durationText(ms)?.replace(/^~/, "") ?? "unknown";
}
function readSnapshots() {
    const file = snapshotFile();
    if (!existsSync(file))
        return [];
    const snapshots = [];
    const raw = readFileSync(file, "utf8");
    for (const line of raw.split("\n")) {
        if (!line.trim())
            continue;
        try {
            const parsed = JSON.parse(line);
            if (typeof parsed.ts !== "number" || !Array.isArray(parsed.accounts)) {
                continue;
            }
            snapshots.push({
                ts: parsed.ts,
                accounts: parsed.accounts
                    .filter((account) => typeof account.name === "string" &&
                    typeof account.snapshotKey === "string")
                    .map((account) => ({
                    snapshotKey: account.snapshotKey,
                    name: account.name,
                    weeklyUsedPct: clampPct(account.weeklyUsedPct),
                    fableUsedPct: clampPct(account.fableUsedPct),
                    weeklyResetAt: typeof account.weeklyResetAt === "number"
                        ? account.weeklyResetAt
                        : null,
                })),
            });
        }
        catch (error) {
            // error-policy:J3 persisted snapshots are local diagnostic input; a bad
            // line is invalid history, not a reason to fail the public status route.
            logger.warn(`[account-pool-status] skipping invalid snapshot line: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    return snapshots;
}
function appendSnapshot(status) {
    const snapshot = {
        ts: nowMs(),
        accounts: status.perAccount.map((account) => ({
            snapshotKey: account.snapshotKey,
            name: account.name,
            weeklyUsedPct: account.weeklyUsedPct,
            fableUsedPct: account.fableUsedPct,
            weeklyResetAt: account.weeklyResetAt,
        })),
    };
    const file = snapshotFile();
    ensureDir(file);
    appendFileSync(file, `${JSON.stringify(snapshot)}\n`, {
        encoding: "utf8",
        mode: 0o600,
    });
    const lines = readFileSync(file, "utf8").split("\n").filter(Boolean);
    const max = snapshotMaxLines();
    if (lines.length > max) {
        atomicWriteText(file, `${lines.slice(-max).join("\n")}\n`);
    }
}
/**
 * Reads only the fields usage producers write (`pollAnthropicUsage` /
 * `pollCodexUsage` in account-usage.ts, persisted through core's
 * `normalizeLinkedAccountUsage`): `sessionPct`, `weeklyPct`, `resetsAt`,
 * `refreshedAt`, and `weeklyModelBuckets` entries of `{ pct, resetsAt? }`.
 * No producer reports a session-window reset, so none is published.
 */
function getModelBuckets(usage) {
    const source = usage.weeklyModelBuckets ?? {};
    let fable = null;
    let sonnet = null;
    for (const [key, value] of Object.entries(source)) {
        const usedPct = clampPct(value.pct);
        if (usedPct === null)
            continue;
        const bucket = {
            usedPct: round2(usedPct),
            resetAt: typeof value.resetsAt === "number" ? value.resetsAt : null,
        };
        if (/fable/i.test(key))
            fable = bucket;
        if (/sonnet/i.test(key))
            sonnet = bucket;
    }
    if (fable || sonnet)
        return { available: true, fable, sonnet };
    return {
        available: false,
        note: "per-model buckets pending account usage support",
    };
}
function calculateBurn(row, snapshots, now) {
    if (row.fableUsedPct === null || row.weeklyResetAt === null) {
        return { ratePctPerHour: null, sampleHours: null };
    }
    const candidates = [];
    for (const snapshot of snapshots) {
        const old = snapshot.accounts.find((account) => account.snapshotKey === row.snapshotKey);
        if (!old || snapshot.ts >= now)
            continue;
        if (old.weeklyResetAt === null ||
            Math.abs(old.weeklyResetAt - row.weeklyResetAt) >
                SNAPSHOT_RESET_TOLERANCE_MS) {
            continue;
        }
        if (old.fableUsedPct === null || old.fableUsedPct > row.fableUsedPct) {
            continue;
        }
        candidates.push({ ts: snapshot.ts, used: old.fableUsedPct });
    }
    if (candidates.length === 0) {
        return { ratePctPerHour: null, sampleHours: null };
    }
    candidates.sort((a, b) => a.ts - b.ts);
    const oldest = candidates[0];
    const hours = (now - oldest.ts) / 3600000;
    if (!oldest || hours <= 0) {
        return { ratePctPerHour: null, sampleHours: null };
    }
    return {
        ratePctPerHour: Math.max(0, (row.fableUsedPct - oldest.used) / hours),
        sampleHours: hours,
    };
}
function applyUrgency(status, snapshots) {
    const now = nowMs();
    let totalRate = 0;
    let knownRates = 0;
    for (const row of status.perAccount) {
        const burn = calculateBurn(row, snapshots, now);
        const rate = burn.ratePctPerHour;
        row.burnRatePctPerHour = rate === null ? null : round2(rate);
        row.burnSampleHours =
            burn.sampleHours === null ? null : round2(burn.sampleHours);
        const resetMs = row.weeklyResetAt === null ? null : row.weeklyResetAt - now;
        row.weeklyResetIn = resetText(resetMs);
        const exhaustMs = row.fableUsedPct !== null && rate !== null && rate > 0
            ? ((100 - row.fableUsedPct) / rate) * 3600000
            : null;
        row.projectedExhaustionIn = durationText(exhaustMs);
        row.projectedBeforeReset =
            exhaustMs !== null && resetMs !== null ? exhaustMs < resetMs : null;
        if (row.fableUsedPct !== null && row.fableUsedPct >= 100) {
            row.state = "EXHAUSTED";
        }
        else if (row.projectedBeforeReset === true) {
            row.state = "BURNING HOT";
        }
        else if (row.fableUsedPct !== null && row.fableUsedPct <= 5) {
            row.state = "FRESH";
        }
        else {
            row.state = "OK";
        }
        if (rate === null) {
            row.exhaustionMessage = "at current burn: estimating";
        }
        else if (rate === 0 || row.projectedBeforeReset === false) {
            row.exhaustionMessage = "at current burn: will not run out before reset";
        }
        else {
            row.exhaustionMessage = `at current burn: runs out in ${durationText(exhaustMs)}`;
        }
        if (rate !== null) {
            totalRate += rate;
            knownRates += 1;
        }
    }
    const rank = {
        EXHAUSTED: 0,
        "BURNING HOT": 1,
        OK: 2,
        FRESH: 3,
    };
    status.perAccount.sort((a, b) => {
        if (rank[a.state] !== rank[b.state])
            return rank[a.state] - rank[b.state];
        return (b.fableUsedPct ?? -1) - (a.fableUsedPct ?? -1);
    });
    const next = status.perAccount
        .filter((account) => account.weeklyResetAt !== null)
        .filter((account) => (account.weeklyResetAt ?? 0) > now)
        .sort((a, b) => (a.weeklyResetAt ?? 0) - (b.weeklyResetAt ?? 0))[0];
    const poolMs = totalRate > 0 ? (status.fable.leftPct / totalRate) * 3600000 : null;
    status.urgency = {
        burnRatePctPerHour: knownRates > 0 ? round2(totalRate) : null,
        projectedDepletionIn: durationText(poolMs),
        depletionMessage: knownRates === 0
            ? "pool-wide burn: estimating"
            : totalRate === 0
                ? "pool-wide burn is currently flat"
                : `pool-wide capacity at current burn: ${durationText(poolMs)}`,
        nextRefill: next && next.weeklyResetAt !== null
            ? {
                account: next.name,
                in: durationText(next.weeklyResetAt - now) ?? "unknown",
                capacityAddedPct: round2(next.fableUsedPct ?? next.weeklyUsedPct ?? 0),
            }
            : null,
    };
}
function consumerTotals(totals) {
    return {
        requests: totals.requests,
        tokens: totals.tokens,
        inputTokens: totals.input_tokens,
        outputTokens: totals.output_tokens,
        cacheReadInputTokens: totals.cache_read_input_tokens,
        cacheCreationInputTokens: totals.cache_creation_input_tokens,
        errors: totals.errors,
        latencyMs: totals.latencyMs,
    };
}
function currentDayStamp(now) {
    return new Date(now).toISOString().slice(0, 10);
}
function publicEdgeUsage(usage, now) {
    const today = usage.byDay[currentDayStamp(now)] ??
        {
            requests: 0,
            tokens: 0,
            input_tokens: 0,
            output_tokens: 0,
            cache_read_input_tokens: 0,
            cache_creation_input_tokens: 0,
            errors: 0,
            latencyMs: 0,
        };
    return {
        today: consumerTotals(today),
        allTime: consumerTotals(usage.totals),
    };
}
function buildStatus(pool, consumerUsage, snapshots) {
    const now = nowMs();
    const configured = selectionForProvider(PROVIDER_ID);
    const configuredIds = configured.accountIds
        ? new Set(configured.accountIds)
        : null;
    const accounts = pool
        .list(PROVIDER_ID)
        .filter((account) => account.enabled !== false)
        .filter((account) => configuredIds === null || configuredIds.has(account.id))
        .filter((account) => isAccountSelectableNow(account, now));
    if (accounts.length === 0) {
        throw new Error("no selectable public pool accounts");
    }
    const selection = pool.selectionState(PROVIDER_ID, configured.strategy ?? "drain-soonest-reset", configured.accountIds ? { accountIds: configured.accountIds } : undefined);
    let fableLeft = 0;
    let allLeft = 0;
    let fableKnownAccounts = 0;
    let allModelsKnownAccounts = 0;
    let fableFromBucket = true;
    let lastRefreshed = 0;
    const rows = accounts.map((account, index) => {
        const usage = account.usage ?? { refreshedAt: 0 };
        if (typeof usage.refreshedAt === "number") {
            lastRefreshed = Math.max(lastRefreshed, usage.refreshedAt);
        }
        const weeklyAll = clampPct(usage.weeklyPct);
        const sessionPct = clampPct(usage.sessionPct);
        const modelBuckets = getModelBuckets(usage);
        const fableUsed = modelBuckets.available && modelBuckets.fable
            ? modelBuckets.fable.usedPct
            : weeklyAll;
        if (!(modelBuckets.available && modelBuckets.fable)) {
            fableFromBucket = false;
        }
        if (fableUsed !== null) {
            fableLeft += 100 - fableUsed;
            fableKnownAccounts += 1;
        }
        if (weeklyAll !== null) {
            allLeft += 100 - weeklyAll;
            allModelsKnownAccounts += 1;
        }
        // Anthropic producers write the all-model seven-day reset as `resetsAt`.
        const fallbackWeeklyResetAt = typeof usage.resetsAt === "number" ? usage.resetsAt : null;
        const weeklyResetAt = modelBuckets.available && modelBuckets.fable
            ? (modelBuckets.fable.resetAt ?? fallbackWeeklyResetAt)
            : fallbackWeeklyResetAt;
        const exhausted = fableUsed !== null && fableUsed >= 100;
        const serving = selection.activeAccountId === account.id &&
            isAccountSelectableNow(account, now);
        return {
            snapshotKey: snapshotKey(account),
            name: `account-${index + 1}`,
            accountState: exhausted ? "exhausted" : serving ? "serving" : "draining",
            sessionUsedPct: sessionPct === null ? null : round2(sessionPct),
            sessionHeadroomPct: sessionPct === null ? null : round2(100 - sessionPct),
            weeklyUsedPct: weeklyAll === null ? null : round2(weeklyAll),
            weeklyHeadroomPct: weeklyAll === null ? null : round2(100 - weeklyAll),
            weeklyResetAt,
            weeklyResetIn: null,
            fableUsedPct: fableUsed === null ? null : round2(fableUsed),
            modelBuckets,
            burnRatePctPerHour: null,
            burnSampleHours: null,
            projectedExhaustionIn: null,
            projectedBeforeReset: null,
            state: "OK",
            exhaustionMessage: "at current burn: estimating",
        };
    });
    const status = {
        updatedAt: new Date(now).toISOString(),
        usageRefreshedAt: lastRefreshed
            ? new Date(lastRefreshed).toISOString()
            : null,
        pool: {
            accounts: accounts.length,
            capacityPct: accounts.length * 100,
            selectableAccounts: accounts.filter((account) => isAccountSelectableNow(account, now)).length,
        },
        fable: {
            leftPct: round2(fableLeft),
            ofPct: fableKnownAccounts * 100,
            source: fableFromBucket
                ? "fable weekly bucket"
                : "all-model weekly fallback",
        },
        allModels: {
            leftPct: round2(allLeft),
            ofPct: allModelsKnownAccounts * 100,
        },
        perAccount: rows,
        publicEdge: publicEdgeUsage(consumerUsage, now),
        urgency: {
            burnRatePctPerHour: null,
            projectedDepletionIn: null,
            depletionMessage: "pool-wide burn: estimating",
            nextRefill: null,
        },
        health: {
            snapshotAgeSeconds: 0,
            snapshotAge: "<1m",
            stale: false,
        },
    };
    applyUrgency(status, snapshots);
    return status;
}
function withHealth(status, stale) {
    const now = nowMs();
    const ageSeconds = Math.max(0, Math.round((now - (cache?.at ?? now)) / 1000));
    return {
        ...status,
        health: {
            snapshotAgeSeconds: ageSeconds,
            snapshotAge: compactAge(ageSeconds * 1000),
            stale,
        },
    };
}
function publicModelBuckets(buckets) {
    if (!buckets.available) {
        return { available: false, note: buckets.note };
    }
    return {
        available: true,
        fable: buckets.fable ? { usedPct: buckets.fable.usedPct } : null,
        sonnet: buckets.sonnet ? { usedPct: buckets.sonnet.usedPct } : null,
    };
}
export function serializePublicPoolStatus(status) {
    return {
        updatedAt: status.updatedAt,
        usageRefreshedAt: status.usageRefreshedAt,
        pool: {
            accounts: status.pool.accounts,
            capacityPct: status.pool.capacityPct,
            selectableAccounts: status.pool.selectableAccounts,
        },
        fable: {
            leftPct: status.fable.leftPct,
            ofPct: status.fable.ofPct,
            source: status.fable.source,
        },
        allModels: {
            leftPct: status.allModels.leftPct,
            ofPct: status.allModels.ofPct,
        },
        perAccount: status.perAccount.map((account) => ({
            name: account.name,
            accountState: account.accountState,
            sessionUsedPct: account.sessionUsedPct,
            sessionHeadroomPct: account.sessionHeadroomPct,
            weeklyUsedPct: account.weeklyUsedPct,
            weeklyHeadroomPct: account.weeklyHeadroomPct,
            weeklyResetIn: account.weeklyResetIn,
            fableUsedPct: account.fableUsedPct,
            modelBuckets: publicModelBuckets(account.modelBuckets),
            burnRatePctPerHour: account.burnRatePctPerHour,
            burnSampleHours: account.burnSampleHours,
            projectedExhaustionIn: account.projectedExhaustionIn,
            projectedBeforeReset: account.projectedBeforeReset,
            state: account.state,
            exhaustionMessage: account.exhaustionMessage,
        })),
        publicEdge: {
            today: { ...status.publicEdge.today },
            allTime: { ...status.publicEdge.allTime },
        },
        urgency: {
            burnRatePctPerHour: status.urgency.burnRatePctPerHour,
            projectedDepletionIn: status.urgency.projectedDepletionIn,
            depletionMessage: status.urgency.depletionMessage,
            nextRefill: status.urgency.nextRefill
                ? {
                    account: status.urgency.nextRefill.account,
                    in: status.urgency.nextRefill.in,
                    capacityAddedPct: status.urgency.nextRefill.capacityAddedPct,
                }
                : null,
        },
        health: {
            snapshotAgeSeconds: status.health.snapshotAgeSeconds,
            snapshotAge: status.health.snapshotAge,
            stale: status.health.stale,
        },
    };
}
export async function getPublicAccountPoolStatus() {
    const now = nowMs();
    if (cache && now >= cache.at && now - cache.at < cacheTtlMs()) {
        return serializePublicPoolStatus(withHealth(cache.status, false));
    }
    if (!inflight) {
        inflight = (async () => {
            const history = readSnapshots();
            const pool = depsOverride.pool ?? getDefaultAccountPool();
            const usage = await (depsOverride.queryConsumerUsage ?? getAccountPoolConsumerUsageSummary)();
            const status = buildStatus(pool, usage, history);
            appendSnapshot(status);
            cache = { at: nowMs(), status };
            return status;
        })()
            .catch((error) => {
            logger.warn(`[AccountPoolStatus] status refresh failed: ${error instanceof Error ? error.message : String(error)}`);
            if (cache)
                return withHealth(cache.status, true);
            throw error;
        })
            .finally(() => {
            inflight = null;
        });
    }
    return serializePublicPoolStatus(await inflight);
}
export function __resetAccountPoolStatusForTests(deps = {}) {
    depsOverride = deps;
    cache = null;
    inflight = null;
}
//# sourceMappingURL=account-pool-status.js.map