import { selectionForProvider, } from "./account-selection.js";
/**
 * Localhost-only account-pool lease broker for same-host compatibility shims.
 * It delegates selection, token resolution, usage accounting, and health
 * mutation to the canonical AccountPool and credential store; callers receive
 * short-lived access tokens but never refresh tokens or display identities.
 */
import { createHash, randomBytes } from "node:crypto";
import { logger, resolveStateDir } from "@elizaos/core";
import { isLinkedAccountProviderId } from "@elizaos/host/protocol";
import { createRuntimeAccountStoragePolicy } from "../auth/account-storage.js";
import { getAccessToken } from "../auth/credentials.js";
import { getDefaultAccountPool } from "./account-pool.js";
import { claudeMinRemainingMs, resolveClaudeExpectedRunMs, } from "./claude-token-refresh.js";
import { adoptRotatedCodexTokens, isAuthFailure, } from "./coding-account-bridge.js";
const DEFAULT_LEASE_TTL_MS = 5 * 60000;
const MAX_LEASE_TTL_MS = 15 * 60000;
const FAILOVER_WINDOW_MS = 60000;
const MAX_RECENT_FAILOVERS = 10;
function normalizeLeaseTtlMs(value) {
    if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) {
        return DEFAULT_LEASE_TTL_MS;
    }
    return Math.min(Math.max(1000, value), MAX_LEASE_TTL_MS);
}
function readLeaseTtlFromEnv() {
    const raw = process.env.ELIZA_ACCOUNT_POOL_BROKER_LEASE_TTL_MS;
    if (!raw)
        return DEFAULT_LEASE_TTL_MS;
    return normalizeLeaseTtlMs(Number(raw));
}
function isStrategy(value) {
    return (value === "priority" ||
        value === "round-robin" ||
        value === "least-used" ||
        value === "quota-aware" ||
        value === "reset-soonest");
}
function parseStringArray(value) {
    if (value === undefined)
        return undefined;
    if (!Array.isArray(value))
        return undefined;
    if (!value.every((item) => typeof item === "string"))
        return undefined;
    const out = value.map((item) => item.trim()).filter(Boolean);
    return out;
}
export function parseBrokerLeaseRequest(body) {
    const providerId = body.providerId;
    const sessionKey = body.sessionKey;
    if (!isLinkedAccountProviderId(providerId))
        return null;
    if (typeof sessionKey !== "string" || !sessionKey.trim())
        return null;
    const strategy = body.strategy;
    if (strategy !== undefined && !isStrategy(strategy))
        return null;
    const exclude = parseStringArray(body.exclude);
    if (body.exclude !== undefined && exclude === undefined)
        return null;
    return {
        providerId,
        sessionKey: sessionKey.trim(),
        ...(strategy ? { strategy } : {}),
        ...(exclude ? { exclude } : {}),
    };
}
export function parseBrokerReportRequest(body) {
    if (typeof body.leaseId !== "string" || !body.leaseId.trim())
        return null;
    if (typeof body.ok !== "boolean")
        return null;
    const out = {
        leaseId: body.leaseId.trim(),
        ok: body.ok,
    };
    for (const key of [
        "httpStatus",
        "retryAfterMs",
        "tokens",
        "latencyMs",
    ]) {
        const value = body[key];
        if (value === undefined)
            continue;
        if (typeof value !== "number" || !Number.isFinite(value))
            return null;
        out[key] = value;
    }
    for (const key of ["errorCode", "model"]) {
        const value = body[key];
        if (value === undefined)
            continue;
        if (typeof value !== "string")
            return null;
        const trimmed = value.trim();
        if (trimmed.length > 128)
            return null;
        if (trimmed)
            out[key] = trimmed;
    }
    return out;
}
export function parseBrokerReleaseRequest(body) {
    return typeof body.leaseId === "string" && body.leaseId.trim()
        ? { leaseId: body.leaseId.trim() }
        : null;
}
function makeLeaseId() {
    return randomBytes(32).toString("base64url");
}
function hashSessionKey(sessionKey) {
    return createHash("sha256").update(sessionKey).digest("hex").slice(0, 12);
}
function observabilityAccountKey(providerId, accountId) {
    return `${providerId}:${accountId}`;
}
function pendingFailoverKey(providerId, sessionKeyHash) {
    return `${providerId}:${sessionKeyHash}`;
}
function retryUntilMs(now, retryAfterMs) {
    if (typeof retryAfterMs !== "number" ||
        !Number.isFinite(retryAfterMs) ||
        retryAfterMs <= 0) {
        return null;
    }
    return now + retryAfterMs;
}
function reportIsAuthFailure(report) {
    if (report.httpStatus === 401 || report.httpStatus === 403)
        return true;
    return report.errorCode ? isAuthFailure(report.errorCode) : false;
}
function reportErrorCodeMatches(report, pattern) {
    return report.errorCode !== undefined && pattern.test(report.errorCode);
}
function reportIsRateLimit(report) {
    if (report.httpStatus === 429)
        return true;
    return reportErrorCodeMatches(report, /rate.?limit|quota|subscription/i);
}
function reportIsTransient(report) {
    if (typeof report.httpStatus === "number" &&
        report.httpStatus >= 500 &&
        report.httpStatus <= 599) {
        return true;
    }
    return reportErrorCodeMatches(report, /\b(timeout|timed.?out|overload|unavailable|reset|network)\b/i);
}
function normalizeReportCause(report) {
    // Keep this precedence aligned with report(), which applies rate-limit
    // health before auth when a provider response ambiguously matches both.
    if (reportIsRateLimit(report)) {
        return {
            category: "rate_limit",
            reason: report.httpStatus === 429 ? "http_429" : "rate_limit",
        };
    }
    if (reportIsAuthFailure(report)) {
        return {
            category: "auth",
            reason: report.httpStatus === 401
                ? "http_401"
                : report.httpStatus === 403
                    ? "http_403"
                    : "auth_failed",
        };
    }
    if (reportIsTransient(report)) {
        const status = report.httpStatus;
        return {
            category: "transient",
            reason: typeof status === "number" && status >= 500 && status <= 599
                ? "http_5xx"
                : reportErrorCodeMatches(report, /\b(timeout|timed.?out)\b/i)
                    ? "timeout"
                    : reportErrorCodeMatches(report, /\b(network|reset)\b/i)
                        ? "network"
                        : "transient_error",
        };
    }
    return null;
}
function lastReportedStatusFromReport(report, atMs) {
    const failoverCause = normalizeReportCause(report);
    return {
        atMs,
        ok: report.ok,
        category: report.ok ? "ok" : (failoverCause?.category ?? "other"),
        reason: report.ok ? "ok" : (failoverCause?.reason ?? "error"),
        ...(typeof report.httpStatus === "number"
            ? { httpStatus: report.httpStatus }
            : {}),
        ...(report.model ? { model: report.model } : {}),
    };
}
export async function resolveBrokerAccessToken(providerId, accountId) {
    if (providerId === "openai-codex") {
        try {
            await adoptRotatedCodexTokens(accountId);
        }
        catch (err) {
            // error-policy:J7 Codex token adoption is a repair step before canonical
            // token resolution; getAccessToken below remains the observed boundary.
            logger.warn(`[AccountPoolBroker] Codex token adoption failed for account ${accountId}: ${String(err)}`);
        }
    }
    const opts = providerId === "anthropic-subscription"
        ? {
            minRemainingMs: claudeMinRemainingMs(resolveClaudeExpectedRunMs((key) => process.env[key])),
            outcome: true,
        }
        : { outcome: true };
    const outcome = await getAccessToken(providerId, accountId, {
        ...opts,
        storagePolicy: createRuntimeAccountStoragePolicy(resolveStateDir()),
    });
    if (!outcome.ok) {
        throw new Error(`token_resolve_failed:${outcome.kind}`);
    }
    return {
        accessToken: outcome.accessToken,
        accessExpiresAt: outcome.expiresAt,
    };
}
export class AccountPoolBroker {
    pool;
    now;
    tokenResolver;
    idGenerator;
    leaseTtlMs;
    byLeaseId = new Map();
    bySessionKey = new Map();
    accountObservability = new Map();
    lastSelectionByProvider = new Map();
    recentFailoversByProvider = new Map();
    pendingFailoversBySession = new Map();
    constructor(deps = {}) {
        this.pool = deps.pool ?? getDefaultAccountPool();
        this.now = deps.now ?? Date.now;
        this.tokenResolver = deps.tokenResolver ?? resolveBrokerAccessToken;
        this.idGenerator = deps.idGenerator ?? makeLeaseId;
        this.leaseTtlMs = normalizeLeaseTtlMs(deps.leaseTtlMs ?? readLeaseTtlFromEnv());
    }
    async lease(request) {
        this.pruneExpired();
        const now = this.now();
        const exclude = new Set(request.exclude);
        const pinned = this.resolveSessionPin(request.sessionKey);
        const configured = selectionForProvider(request.providerId);
        const account = pinned &&
            pinned.providerId === request.providerId &&
            !exclude.has(pinned.accountId) &&
            (!configured.accountIds ||
                configured.accountIds.includes(pinned.accountId))
            ? await this.pool.select({
                providerId: request.providerId,
                sessionKey: request.sessionKey,
                strategy: request.strategy ?? configured.strategy,
                accountIds: [pinned.accountId],
            })
            : null;
        const selected = account ??
            (await this.pool.select({
                providerId: request.providerId,
                sessionKey: request.sessionKey,
                strategy: request.strategy ?? configured.strategy,
                ...(configured.accountIds ? { accountIds: configured.accountIds } : {}),
                exclude: request.exclude,
            }));
        if (!selected)
            return null;
        const token = await this.tokenResolver(request.providerId, selected.id);
        const leaseId = this.idGenerator();
        const leaseExpiresAt = now + this.leaseTtlMs;
        const sessionKeyHash = hashSessionKey(request.sessionKey);
        const lease = {
            leaseId,
            providerId: request.providerId,
            accountId: selected.id,
            sessionKey: request.sessionKey,
            sessionKeyHash,
            atMs: now,
            expiresAt: leaseExpiresAt,
        };
        this.byLeaseId.set(leaseId, lease);
        this.bySessionKey.set(request.sessionKey, leaseId);
        this.observeLease(lease, request.strategy ?? configured.strategy);
        return {
            leaseId,
            providerId: request.providerId,
            accountId: selected.id,
            accessToken: token.accessToken,
            accessExpiresAt: token.accessExpiresAt,
            leaseExpiresAt,
            ...(selected.usage ? { usage: selected.usage } : {}),
            ...(request.providerId === "openai-codex" && selected.organizationId
                ? { chatgptAccountId: selected.organizationId }
                : {}),
        };
    }
    async report(report) {
        const lease = this.byLeaseId.get(report.leaseId);
        if (!lease)
            return { ok: false, error: "unknown_lease" };
        if (lease.expiresAt <= this.now()) {
            this.deleteLease(lease);
            return { ok: false, error: "expired_lease" };
        }
        const reportAt = this.now();
        const observability = this.ensureAccountObservability(lease.providerId, lease.accountId);
        if (report.model) {
            lease.model = report.model;
            if (observability.lastLease?.leaseId === lease.leaseId) {
                observability.lastLease = {
                    ...observability.lastLease,
                    model: report.model,
                };
            }
        }
        const successPredatesFailure = report.ok &&
            observability.lastFailureAtMs !== null &&
            lease.atMs <= observability.lastFailureAtMs;
        if (!successPredatesFailure) {
            observability.lastReportedStatus = lastReportedStatusFromReport(report, reportAt);
        }
        if (!report.ok)
            observability.lastFailureAtMs = reportAt;
        await this.pool.recordCall(lease.accountId, {
            ok: report.ok,
            ...(report.tokens !== undefined ? { tokens: report.tokens } : {}),
            ...(report.latencyMs !== undefined
                ? { latencyMs: report.latencyMs }
                : {}),
            ...(report.errorCode ? { errorCode: report.errorCode } : {}),
            ...(report.model ? { model: report.model } : {}),
        }, { providerId: lease.providerId });
        if (report.ok) {
            const pendingKey = pendingFailoverKey(lease.providerId, lease.sessionKeyHash);
            const pending = this.pendingFailoversBySession.get(pendingKey);
            if (pending?.accountId === lease.accountId) {
                this.pendingFailoversBySession.delete(pendingKey);
            }
            if (!successPredatesFailure) {
                await this.pool.markHealthy(lease.accountId, {
                    providerId: lease.providerId,
                });
            }
            return { ok: true };
        }
        const failoverCause = normalizeReportCause(report);
        if (failoverCause) {
            this.pendingFailoversBySession.set(pendingFailoverKey(lease.providerId, lease.sessionKeyHash), {
                providerId: lease.providerId,
                accountId: lease.accountId,
                sessionKeyHash: lease.sessionKeyHash,
                atMs: reportAt,
                cause: failoverCause,
                ...(report.model ? { model: report.model } : {}),
            });
        }
        if (reportIsRateLimit(report)) {
            const untilMs = retryUntilMs(this.now(), report.retryAfterMs);
            if (untilMs === null) {
                await this.pool.markRateLimitedUnknown(lease.accountId, report.errorCode ?? "rate_limited", { providerId: lease.providerId });
            }
            else {
                await this.pool.markRateLimited(lease.accountId, untilMs, report.errorCode ?? "rate_limited", { providerId: lease.providerId });
            }
            this.deleteLease(lease);
            return { ok: true };
        }
        if (reportIsAuthFailure(report)) {
            await this.pool.markNeedsReauth(lease.accountId, report.errorCode ?? "auth_failed", { providerId: lease.providerId });
            this.deleteLease(lease);
            return { ok: true };
        }
        if (reportIsTransient(report)) {
            return { ok: true };
        }
        return { ok: true };
    }
    release(request) {
        const lease = this.byLeaseId.get(request.leaseId);
        if (!lease)
            return { ok: true, released: false };
        this.deleteLease(lease);
        return { ok: true, released: true };
    }
    health() {
        this.pruneExpired();
        const now = this.now();
        const snapshot = this.snapshot();
        const providers = new Set(this.pool.list().map((account) => account.providerId));
        return {
            ok: true,
            enabled: true,
            activeLeases: this.byLeaseId.size,
            accounts: Object.fromEntries(Object.entries(snapshot.accounts).map(([accountId, account]) => [
                accountId,
                {
                    activeLeaseCount: account.activeLeaseCount,
                    lastLeaseAt: account.lastLeaseAt,
                    lastReportedStatus: account.lastReportedStatus,
                },
            ])),
            providers: [...providers].sort().map((providerId) => {
                const accounts = this.pool.list(providerId);
                return {
                    providerId,
                    total: accounts.length,
                    enabled: accounts.filter((account) => account.enabled).length,
                    lastSelection: this.lastSelectionByProvider.get(providerId) ?? null,
                    selectable: accounts.filter((account) => account.enabled &&
                        (account.health === "ok" ||
                            (account.health === "rate-limited" &&
                                typeof account.healthDetail?.until === "number" &&
                                account.healthDetail.until < now))).length,
                };
            }),
        };
    }
    snapshot() {
        this.pruneExpired();
        const activeCounts = new Map();
        for (const lease of this.byLeaseId.values()) {
            const key = observabilityAccountKey(lease.providerId, lease.accountId);
            const current = activeCounts.get(key);
            activeCounts.set(key, current === undefined ? 1 : current + 1);
        }
        const activeLeaseCount = (key) => {
            const count = activeCounts.get(key);
            return count === undefined ? 0 : count;
        };
        const accounts = {};
        for (const account of this.pool.list()) {
            const key = observabilityAccountKey(account.providerId, account.id);
            const state = this.accountObservability.get(key);
            accounts[key] = {
                activeLeaseCount: activeLeaseCount(key),
                lastLease: state?.lastLease ?? null,
                lastLeaseAt: state?.lastLease?.atMs ?? null,
                lastReportedStatus: state?.lastReportedStatus ?? null,
            };
        }
        for (const [key, state] of this.accountObservability) {
            accounts[key] ??= {
                activeLeaseCount: activeLeaseCount(key),
                lastLease: state.lastLease,
                lastLeaseAt: state.lastLease?.atMs ?? null,
                lastReportedStatus: state.lastReportedStatus,
            };
        }
        const providerIds = new Set([
            ...this.pool.list().map((account) => account.providerId),
            ...this.lastSelectionByProvider.keys(),
            ...this.recentFailoversByProvider.keys(),
        ]);
        const providers = {};
        for (const providerId of providerIds) {
            const recentFailovers = this.recentFailoversByProvider.get(providerId);
            providers[providerId] = {
                lastSelection: this.lastSelectionByProvider.get(providerId) ?? null,
                recentFailovers: recentFailovers ? [...recentFailovers] : [],
            };
        }
        return { accounts, providers };
    }
    observeLease(lease, reason) {
        const state = this.ensureAccountObservability(lease.providerId, lease.accountId);
        state.lastLease = {
            leaseId: lease.leaseId,
            atMs: lease.atMs,
            sessionKeyHash: lease.sessionKeyHash,
            ...(lease.model ? { model: lease.model } : {}),
        };
        this.lastSelectionByProvider.set(lease.providerId, {
            accountId: lease.accountId,
            atMs: lease.atMs,
            reason: reason ?? "priority",
        });
        const pendingKey = pendingFailoverKey(lease.providerId, lease.sessionKeyHash);
        const pending = this.pendingFailoversBySession.get(pendingKey);
        if (!pending)
            return;
        this.pendingFailoversBySession.delete(pendingKey);
        if (pending.accountId === lease.accountId ||
            lease.atMs - pending.atMs > FAILOVER_WINDOW_MS) {
            return;
        }
        const failover = {
            atMs: lease.atMs,
            providerId: lease.providerId,
            sessionKeyHash: lease.sessionKeyHash,
            fromAccountId: pending.accountId,
            toAccountId: lease.accountId,
            cause: pending.cause,
            ...(pending.model ? { model: pending.model } : {}),
        };
        const recent = this.recentFailoversByProvider.get(lease.providerId);
        const next = recent ? [...recent, failover] : [failover];
        this.recentFailoversByProvider.set(lease.providerId, next.slice(-MAX_RECENT_FAILOVERS));
    }
    ensureAccountObservability(providerId, accountId) {
        const key = observabilityAccountKey(providerId, accountId);
        let state = this.accountObservability.get(key);
        if (!state) {
            state = {
                lastLease: null,
                lastReportedStatus: null,
                lastFailureAtMs: null,
            };
            this.accountObservability.set(key, state);
        }
        return state;
    }
    resolveSessionPin(sessionKey) {
        const leaseId = this.bySessionKey.get(sessionKey);
        if (!leaseId)
            return null;
        const lease = this.byLeaseId.get(leaseId);
        if (!lease || lease.expiresAt <= this.now()) {
            if (lease)
                this.deleteLease(lease);
            else
                this.bySessionKey.delete(sessionKey);
            return null;
        }
        return lease;
    }
    deleteLease(lease) {
        this.byLeaseId.delete(lease.leaseId);
        if (this.bySessionKey.get(lease.sessionKey) === lease.leaseId) {
            this.bySessionKey.delete(lease.sessionKey);
        }
    }
    pruneExpired() {
        const now = this.now();
        for (const lease of this.byLeaseId.values()) {
            if (lease.expiresAt <= now)
                this.deleteLease(lease);
        }
        for (const [sessionKey, pending] of this.pendingFailoversBySession) {
            if (now - pending.atMs > FAILOVER_WINDOW_MS) {
                this.pendingFailoversBySession.delete(sessionKey);
            }
        }
    }
}
//# sourceMappingURL=account-pool-broker.js.map