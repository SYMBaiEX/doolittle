/**
 * Coding-agent account-selector bridge.
 *
 * The orchestrator plugin (`@elizaos/plugin-agent-orchestrator`) spawns Claude
 * Claude Code / Codex sub-agents but depends only on `@elizaos/core` — it
 * cannot import the `AccountPool` or the credential store. So, exactly like the
 * Anthropic and subscription-selector bridges in `account-pool.ts`, we publish a
 * narrow contract on a `globalThis` symbol that the plugin reads at spawn time.
 *
 * Responsibilities:
 *  - Map a coding-agent type ("claude" / "codex" / …) to its candidate provider
 *    ids and pick one account from the pool (default `least-used`).
 *  - Resolve that account's credential and return the env vars the spawned
 *    coding-agent subprocess needs to authenticate AS THAT ACCOUNT:
 *      claude  → `CLAUDE_CODE_OAUTH_TOKEN`
 *      codex   → a per-account `CODEX_HOME` dir holding an `auth.json`
 *      *-api   → the provider's direct API-key env var
 *  - Record usage + health back into the pool keyed by the serving account.
 *
 * Subscription tokens only ever leave this layer to flow into the first-party
 * coding subprocess (which IS Claude Code / Codex) — never into the runtime's
 * own `process.env`. That respects the providers' TOS the same way
 * `applySubscriptionCredentialsLocal` does.
 */
import type { AccountPool } from "./account-pool.js";
export declare function isAuthFailure(err: unknown): boolean;
/**
 * Adopt tokens a spawned Codex CLI rotated inside its per-account CODEX_HOME
 * back into the canonical account record.
 *
 * OpenAI refresh tokens are ONE-TIME-USE: when a long-running Codex session
 * self-refreshes, it writes the rotated pair to `CODEX_HOME/auth.json` only —
 * the canonical record at `auth/openai-codex/{accountId}.json` is left holding
 * an already-consumed refresh token. Every later canonical refresh (next
 * spawn's `getAccessToken`, the keep-alive usage sweep) then fails with
 * `invalid_grant` and the account is marked needs-reauth — forcing a manual
 * re-login even though the CLI's copy holds perfectly good tokens. Calling
 * this before any canonical token resolution heals that drift.
 *
 * Serialized on the same per-account refresh mutex as `getAccessToken` so an
 * adoption can't interleave with an in-flight canonical refresh.
 */
export declare function adoptRotatedCodexTokens(accountId: string): Promise<boolean>;
/**
 * Install the coding-agent selector bridge. Idempotent — called from
 * `getDefaultAccountPool()` so it is present before the first spawn. The
 * symbol + accessors live in `@elizaos/core` so producer and plugin consumers
 * share one contract.
 */
export declare function installCodingAgentSelectorBridge(pool: AccountPool): void;
//# sourceMappingURL=coding-account-bridge.d.ts.map