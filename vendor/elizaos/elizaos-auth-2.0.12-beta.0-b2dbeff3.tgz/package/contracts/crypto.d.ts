/** Browser-safe cryptographic encodings shared by account and service protocols. */
export declare const SIGNATURE_SCHEME = "v2";
export declare function hmacSha256Hex(secret: string, canonical: string): Promise<string>;
export declare function canonicalSignedPayload(timestamp: string, deliveryId: string, eventType: string, body: string): string;
export declare function generateCodeVerifier(): Promise<string>;
export declare function generateCodeChallenge(verifier: string): Promise<string>;
export declare function base64urlEncode(bytes: Uint8Array): string;
export declare function generatePKCE(): Promise<{
    verifier: string;
    challenge: string;
}>;
//# sourceMappingURL=crypto.d.ts.map