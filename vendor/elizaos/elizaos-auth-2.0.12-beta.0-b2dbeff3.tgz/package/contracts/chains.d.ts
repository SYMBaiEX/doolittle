export type ChainFamily = "evm" | "solana" | "bitcoin" | "monero";
export interface ChainProvider {
    /** CAIP-2 identifier (e.g. "eip155:100"). */
    caip2: string;
    /** Internal numeric ID. For EVM chains this matches the chain ID. For
     * non-EVM chains this is a convention used to map back to CAIP-2. */
    numericId: number;
    /** Family/VM the chain belongs to. */
    family: ChainFamily;
    /** Human-readable display name. */
    name: string;
    /** Native asset ticker. */
    symbol: string;
    /** Whether this is a testnet. */
    testnet: boolean;
    /** Block-explorer base URL (no trailing slash). */
    explorerUrl: string;
    /** Brand color used by UI chain badges. */
    color: string;
    /** Function building the explorer URL for a transaction hash. */
    explorerTxUrl: (txHash: string) => string;
    /** Function building the explorer URL for an address. */
    explorerAddressUrl: (address: string) => string;
}
export declare const ethereum: {
    readonly caip2: "eip155:1";
    readonly numericId: 1;
    readonly family: "evm";
    readonly name: "Ethereum";
    readonly symbol: "ETH";
    readonly testnet: false;
    readonly explorerUrl: "https://etherscan.io";
    readonly color: "#627EEA";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const bsc: {
    readonly caip2: "eip155:56";
    readonly numericId: 56;
    readonly family: "evm";
    readonly name: "BSC";
    readonly symbol: "BNB";
    readonly testnet: false;
    readonly explorerUrl: "https://bscscan.com";
    readonly color: "#F0B90B";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const bscTestnet: {
    readonly caip2: "eip155:97";
    readonly numericId: 97;
    readonly family: "evm";
    readonly name: "BSC Testnet";
    readonly symbol: "tBNB";
    readonly testnet: true;
    readonly explorerUrl: "https://testnet.bscscan.com";
    readonly color: "#F0B90B";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const gnosis: {
    readonly caip2: "eip155:100";
    readonly numericId: 100;
    readonly family: "evm";
    readonly name: "Gnosis";
    readonly symbol: "xDAI";
    readonly testnet: false;
    readonly explorerUrl: "https://gnosisscan.io";
    readonly color: "#04795B";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const polygon: {
    readonly caip2: "eip155:137";
    readonly numericId: 137;
    readonly family: "evm";
    readonly name: "Polygon";
    readonly symbol: "POL";
    readonly testnet: false;
    readonly explorerUrl: "https://polygonscan.com";
    readonly color: "#8247E5";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const base: {
    readonly caip2: "eip155:8453";
    readonly numericId: 8453;
    readonly family: "evm";
    readonly name: "Base";
    readonly symbol: "ETH";
    readonly testnet: false;
    readonly explorerUrl: "https://basescan.org";
    readonly color: "#0052FF";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const baseSepolia: {
    readonly caip2: "eip155:84532";
    readonly numericId: 84532;
    readonly family: "evm";
    readonly name: "Base Sepolia";
    readonly symbol: "ETH";
    readonly testnet: true;
    readonly explorerUrl: "https://sepolia.basescan.org";
    readonly color: "#0052FF";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const arbitrum: {
    readonly caip2: "eip155:42161";
    readonly numericId: 42161;
    readonly family: "evm";
    readonly name: "Arbitrum";
    readonly symbol: "ETH";
    readonly testnet: false;
    readonly explorerUrl: "https://arbiscan.io";
    readonly color: "#28A0F0";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const solana: {
    readonly caip2: "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp";
    readonly numericId: 101;
    readonly family: "solana";
    readonly name: "Solana";
    readonly symbol: "SOL";
    readonly testnet: false;
    readonly explorerUrl: "https://explorer.solana.com";
    readonly color: "#9945FF";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const solanaDevnet: {
    readonly caip2: "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1";
    readonly numericId: 102;
    readonly family: "solana";
    readonly name: "Solana Devnet";
    readonly symbol: "SOL";
    readonly testnet: true;
    readonly explorerUrl: "https://explorer.solana.com";
    readonly color: "#9945FF";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const bitcoin: {
    readonly caip2: "bip122:000000000019d6689c085ae165831e93";
    readonly numericId: 201;
    readonly family: "bitcoin";
    readonly name: "Bitcoin";
    readonly symbol: "BTC";
    readonly testnet: false;
    readonly explorerUrl: "https://mempool.space";
    readonly color: "#F7931A";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const bitcoinTestnet: {
    readonly caip2: "bip122:000000000933ea01ad0ee984209779ba";
    readonly numericId: 202;
    readonly family: "bitcoin";
    readonly name: "Bitcoin Testnet";
    readonly symbol: "BTC";
    readonly testnet: true;
    readonly explorerUrl: "https://mempool.space/testnet";
    readonly color: "#F7931A";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
/**
 * Monero has no finalized CAIP-2 namespace; `monero:mainnet` / `monero:stagenet`
 * is the in-repo convention (mirrors how bitcoin uses the bip122 genesis-hash
 * form as an internal identifier). Numeric IDs follow the non-EVM block
 * convention: solana 101/102, bitcoin 201/202, monero 301/302.
 */
export declare const monero: {
    readonly caip2: "monero:mainnet";
    readonly numericId: 301;
    readonly family: "monero";
    readonly name: "Monero";
    readonly symbol: "XMR";
    readonly testnet: false;
    readonly explorerUrl: "https://xmrchain.net";
    readonly color: "#FF6600";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
export declare const moneroStagenet: {
    readonly caip2: "monero:stagenet";
    readonly numericId: 302;
    readonly family: "monero";
    readonly name: "Monero Stagenet";
    readonly symbol: "XMR";
    readonly testnet: true;
    readonly explorerUrl: "https://stagenet.xmrchain.net";
    readonly color: "#FF6600";
    readonly explorerTxUrl: (h: string) => string;
    readonly explorerAddressUrl: (a: string) => string;
};
/** All registered chain providers. Add new entries here. */
export declare const CHAIN_PROVIDERS: readonly ChainProvider[];
/** Lookup helpers built from the registry. */
export declare const CHAIN_PROVIDERS_BY_CAIP2: Record<string, ChainProvider>;
export declare const CHAIN_PROVIDERS_BY_NUMERIC: Record<number, ChainProvider>;
export declare function getChainProviderByCaip2(caip2: string): ChainProvider | undefined;
export declare function getChainProviderByNumeric(numericId: number): ChainProvider | undefined;
export interface ChainIdentifier {
    caip2: string;
    numericId: number;
    family: ChainFamily;
    name: string;
    symbol: string;
    testnet: boolean;
}
/** Chain identity records derived from the shared provider registry. */
export declare const CHAINS: Record<string, ChainIdentifier>;
/** Look up a chain by its internal numeric ID. Returns undefined if not found. */
export declare function chainFromNumeric(id: number): ChainIdentifier | undefined;
/** Look up a chain by its CAIP-2 string (e.g. `"eip155:8453"`). Returns undefined if not found. */
export declare function chainFromCaip2(caip2: string): ChainIdentifier | undefined;
/**
 * Convert an internal numeric chain ID to its CAIP-2 string.
 * Returns undefined for unrecognised chain IDs.
 */
export declare function toCaip2(numericId: number): string | undefined;
/**
 * Convert a CAIP-2 string back to the internal numeric chain ID.
 * Returns undefined for unrecognised CAIP-2 strings.
 */
export declare function fromCaip2(caip2: string): number | undefined;
export declare const SUPPORTED_CHAINS: {
    readonly ethereum: 1;
    readonly bsc: 56;
    readonly bscTestnet: 97;
    readonly gnosis: 100;
    readonly polygon: 137;
    readonly base: 8453;
    readonly baseSepolia: 84532;
    readonly arbitrum: 42161;
    readonly solana: 101;
    readonly solanaDevnet: 102;
    readonly bitcoin: 201;
    readonly bitcoinTestnet: 202;
    readonly monero: 301;
    readonly moneroStagenet: 302;
};
export declare const DEFAULT_CHAIN_ID: 8453;
export interface ChainMeta {
    id: number;
    name: string;
    symbol: string;
    explorerUrl: string;
    explorerTxUrl: string;
}
export declare const CHAIN_META: Record<number, ChainMeta>;
export declare function getChainMeta(chainId: number): ChainMeta | undefined;
export declare function getExplorerTxLink(chainId: number, txHash: string): string | undefined;
//# sourceMappingURL=chains.d.ts.map