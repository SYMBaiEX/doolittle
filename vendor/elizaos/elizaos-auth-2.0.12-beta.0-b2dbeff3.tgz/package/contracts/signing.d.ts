/**
 * Signature-curve capability registry.
 *
 * The vault can produce raw signatures on a fixed set of curves. This module is
 * the single source of truth for *which curves are supported* and *which chains
 * those curves serve*, so the cross-curve raw-digest signing surface
 * (`POST /vault/:agentId/sign-raw-digest`) has a documented, testable capability
 * matrix instead of scattered string literals.
 *
 * Design notes:
 *  - We declare curves, NOT chains-as-fully-supported. Listing a chain here means
 *    "the vault can produce a valid signature on that chain's curve" — it does
 *    NOT imply Steward has RPC / balance / transaction-builder support for it.
 *    (Over-claiming transaction support would violate the fail-closed posture.)
 *  - `stark` is intentionally unsupported: no vetted starknet curve library is
 *    installed, and hand-rolling curve crypto in a money path is unacceptable.
 *    It is listed so callers get a precise, honest reason rather than a generic
 *    "unknown curve" error.
 */
/** Signature curves the raw-digest signing surface knows about. */
export type SigningCurve = "secp256k1" | "ed25519" | "stark";
export interface SigningCurveSupport {
    curve: SigningCurve;
    /** Whether the vault can currently produce signatures on this curve. */
    supported: boolean;
    /** Human-readable reason when `supported` is false. */
    unsupportedReason?: string;
    /** Representative chains served by this curve (informational, non-exhaustive). */
    exampleChains: readonly string[];
}
export type RawSigningChain = "bitcoin" | "spark" | "lightning" | "tron" | "tempo" | "ton" | "cosmos" | "stellar" | "near" | "sui" | "aptos" | "movement" | "starknet" | "monero";
export interface RawSigningChainSupport {
    chain: RawSigningChain;
    curve: SigningCurve;
    supported: boolean;
    unsupportedReason?: string;
    /**
     * Honest scope of vault support:
     *  - "raw-digest": the vault signs a caller-provided digest on the chain's
     *    curve; it does NOT build or broadcast transactions for the chain.
     *  - "transfer-intent": the vault builds, signs, and broadcasts native
     *    transfers via a dedicated chain route, but the generic raw-digest
     *    surface is NOT available (the chain's signature scheme is not plain
     *    ECDSA/EdDSA over a digest — e.g. Monero's CLSAG ring signatures).
     */
    capability: "raw-digest" | "transfer-intent";
}
/** Canonical reason the stark curve fails closed. Mirrors the vault's guard. */
export declare const STARK_UNSUPPORTED_REASON: "no vetted starknet signing library is installed";
/** Capability matrix for raw-digest signing, keyed by curve. */
export declare const SIGNING_CURVE_SUPPORT: Readonly<Record<SigningCurve, SigningCurveSupport>>;
/** Raw-digest signing support for non-EVM/other-chain parity rows. */
export declare const RAW_SIGNING_CHAIN_SUPPORT: Readonly<Record<RawSigningChain, RawSigningChainSupport>>;
/** Curves the vault can actually sign with (supported === true). */
export declare const SUPPORTED_SIGNING_CURVES: readonly SigningCurve[];
/** Type guard: is `value` a known signing curve (supported or not)? */
export declare function isSigningCurve(value: unknown): value is SigningCurve;
/** True only for curves the vault can currently produce signatures on. */
export declare function isSigningCurveSupported(value: unknown): value is "secp256k1" | "ed25519";
/** Look up the support record for a curve, or undefined if unknown. */
export declare function signingCurveSupport(value: unknown): SigningCurveSupport | undefined;
export declare function rawSigningChainSupport(value: unknown): RawSigningChainSupport | undefined;
//# sourceMappingURL=signing.d.ts.map