export declare function serveUntilSignal(server: {
    port: number | undefined;
    stop(): Promise<void>;
}): Promise<void>;
//# sourceMappingURL=serve-until-signal.d.ts.map