interface JournalEntry {
    idx: number;
    tag: string;
    when: number;
}
interface Journal {
    entries: JournalEntry[];
}
/**
 * The legacy `psql -f` deploy loop was retired when this migrator was
 * introduced; the journal tip at that moment was 0024_audit_events. A legacy
 * DB is therefore only provably migrated through that tag — entries past it
 * must be APPLIED by the migrator, never seeded.
 */
export declare const LEGACY_BACKFILL_TIP_TAG = "0024_audit_events";
/**
 * Fingerprint proving a legacy DB actually reached the psql-era tip: the
 * newest table 0024 created. `public.tenants` (0000) alone says nothing about
 * how far the psql loop got before the DB was frozen.
 */
export declare const LEGACY_BACKFILL_FINGERPRINT_TABLE = "public.audit_events";
/**
 * Select the journal entries a legacy DB may be seeded with: everything up to
 * and including the psql-era tip. Throws if the tip is absent from the
 * journal (should never happen — it is a historical entry).
 */
export declare function selectLegacyBackfillEntries(journal: Journal): JournalEntry[];
/**
 * Run drizzle-kit migrations under a Postgres advisory session lock so
 * concurrent API replicas don't race on startup. Returns the tags of
 * migrations applied during this call (empty if everything was up to date).
 *
 * On first run against a DB that pre-dates this migrator (the deploy script
 * used to `psql -f` each .sql by hand), we backfill `drizzle.__drizzle_migrations`
 * from the journal so the migrator doesn't try to re-apply non-idempotent DDL.
 * Heuristic: if `__drizzle_migrations` is empty AND `tenants` exists (was
 * created by 0000), the DB came from the psql loop. We then FINGERPRINT the
 * psql-era tip (`LEGACY_BACKFILL_FINGERPRINT_TABLE`, created by 0024) and seed
 * only the entries through that tip — seeding the whole current journal would
 * silently skip every migration between the DB's true tip and now, including
 * constraint-only hardening migrations whose absence produces no runtime error.
 */
export declare function runMigrations(): Promise<{
    applied: string[];
}>;
export {};
//# sourceMappingURL=migrate.d.ts.map