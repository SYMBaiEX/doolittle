/** Preserves existing deployment mode names and their immutable migration ledgers. */
export declare function initializeLoginSchema(): Promise<void>;
//# sourceMappingURL=schema-readiness.d.ts.map