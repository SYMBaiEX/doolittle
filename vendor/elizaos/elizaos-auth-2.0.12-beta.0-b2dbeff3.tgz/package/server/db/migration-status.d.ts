export type MigrationExpectation = {
    tag: string;
    createdAt: number;
    count: number;
};
export type MigrationLedgerEntry = {
    hash: string;
    createdAt: number;
};
export type MigrationLedgerExpectation = {
    entries: MigrationLedgerEntry[];
};
export type MigrationLedgerReadiness = {
    ok: boolean;
    state: "exact" | "behind" | "ahead-known" | "ahead-unknown" | "corrupt";
    requiredCount: number;
    actualCount: number;
    forwardCount: number;
};
type AppliedMigrationLedgerEntry = {
    hash?: unknown;
    createdAt?: unknown;
};
/**
 * Validate the applied core migration ledger against the migrations required by
 * this release. Required migrations must be present with their exact hash and
 * timestamp. A well-formed forward suffix is accepted so an older application
 * can remain ready while a newer compatible release has already migrated the
 * shared database.
 *
 * `knownEntries` may include migrations newer than this release's required
 * floor. It only improves diagnostics (`ahead-known` versus `ahead-unknown`);
 * both states are ready. Missing, altered, duplicated, malformed, or
 * non-forward unknown entries remain fail-closed.
 */
export declare function assessMigrationLedger(appliedEntries: readonly AppliedMigrationLedgerEntry[], requiredEntries: readonly MigrationLedgerEntry[], knownEntries?: readonly MigrationLedgerEntry[]): MigrationLedgerReadiness;
/** Return every checked-in core migration identity in journal order. */
export declare function getMigrationLedgerExpectation(): MigrationLedgerExpectation;
/**
 * Return the checked-in migration tip. Reading the journal keeps operational
 * diagnostics aligned with the migrator instead of duplicating a tag that
 * becomes stale whenever a migration is added.
 */
export declare function getMigrationExpectation(): MigrationExpectation;
export {};
//# sourceMappingURL=migration-status.d.ts.map