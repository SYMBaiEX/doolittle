import type { AgentIdentity, PolicyRule, SignRequest, TxRecord } from "../shared/index.js";
export { __resetAuditHmacKeyCacheForTests, type ActorType as AuditActorType, type AppendRequiredAudit, type AuditEventInput, type AuditTxLike, appendAuditEvent, appendAuditEventWithinTx, withTenantAuditedTransaction, withTenantAuditedTransactionOnDb, withTenantAuditQueue, writeAuditEvent, } from "./audit-chain.js";
export type { DatabaseDriver } from "./client.js";
export { closeDb, createDb, createPostgresClient, DATABASE_DEADLINE_EXCEEDED_MESSAGE, DatabaseDeadlineExceededError, getDatabaseDriver, getDatabaseUrl, getDb, getSql, hasTenantTransactionDatabase, isEmbeddedDatabase, setPGLiteOverride, waitUntilTenantDatabaseTask, withDatabaseDeadline, withTenantTransactionDatabase, } from "./client.js";
export { runMigrations } from "./migrate.js";
export { assessMigrationLedger, getMigrationExpectation, getMigrationLedgerExpectation, type MigrationExpectation, type MigrationLedgerEntry, type MigrationLedgerExpectation, type MigrationLedgerReadiness, } from "./migration-status.js";
export { ALL_INVENTORIED_TABLES, BOOTSTRAP_ROOT_TABLES, DIRECT_TENANT_TABLES, HYBRID_SCOPE_TABLES, INDIRECT_TENANT_TABLES, INTENTIONALLY_GLOBAL_TABLES, TENANT_COLUMN_BACKFILL_TABLES, } from "./rls-inventory.js";
export * from "./schema.js";
export * from "./schema-auth.js";
export { assertTenantRlsDriver, type TenantRlsDriver, type TenantTransactionCharacteristics, type TrustedTenantContext, tenantContextForInternalJob, tenantContextFromAuthenticatedPrincipal, withTenantRlsTransaction, } from "./tenant-rls-context.js";
import type { Agent, Policy, Transaction } from "./schema.js";
import { policyTypeEnum } from "./schema.js";
export type DbAgentIdentity = AgentIdentity & {
    tenantId: string;
    updatedAt: Date;
};
export type DbPolicyRule = PolicyRule & {
    agentId: string;
    createdAt: Date;
    updatedAt: Date;
};
export type PersistedPolicyType = (typeof policyTypeEnum.enumValues)[number];
export type PersistedPolicyRule = Omit<PolicyRule, "type"> & {
    type: PersistedPolicyType;
};
export type TransactionRequestFields = Pick<Transaction, "toAddress" | "value" | "data" | "chainId">;
export type DbTxRecord = TxRecord;
export declare function isPersistedPolicyType(value: string): value is PersistedPolicyType;
export declare function toPersistedPolicyRule(policy: PolicyRule): PersistedPolicyRule;
export declare function toAgentIdentity(agent: Agent): DbAgentIdentity;
/**
 * Query all wallet addresses for a single agent from the `agent_wallets` table.
 * Returns an empty object for legacy agents that pre-date multi-wallet support.
 */
export declare function getAgentWalletAddresses(agentId: string): Promise<{
    evm?: string;
    solana?: string;
    bitcoin?: string;
    monero?: string;
}>;
/**
 * Query wallet addresses for multiple agents in a single DB round-trip.
 * Returns a Map from agentId → { evm?, solana?, bitcoin?, monero? }.
 */
export declare function getAgentWalletAddressesBatch(agentIds: string[]): Promise<Map<string, {
    evm?: string;
    solana?: string;
    bitcoin?: string;
    monero?: string;
}>>;
export declare function toPolicyRule(policy: Policy): DbPolicyRule;
export declare function toSignRequest(transaction: Transaction): SignRequest;
export declare function toTxRecord(transaction: Transaction): DbTxRecord;
//# sourceMappingURL=index.d.ts.map