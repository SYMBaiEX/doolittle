/** Byte encoding shared by audit-chain writers and verifiers. Preserve historical preimages. */
import { createHmac } from "node:crypto";
export function toU8(value) {
    if (value instanceof Uint8Array)
        return value;
    if (typeof value === "string") {
        // Postgres bytea hex format: `\x...` or hex string.
        const hex = value.startsWith("\\x") ? value.slice(2) : value;
        const out = new Uint8Array(hex.length / 2);
        for (let i = 0; i < out.length; i++) {
            out[i] = parseInt(hex.substr(i * 2, 2), 16);
        }
        return out;
    }
    throw new Error("toU8: unsupported value");
}
export function canonicalJsonValue(value) {
    if (value === undefined)
        return null;
    if (value === null)
        return null;
    if (value instanceof Date)
        return value.toISOString();
    if (Array.isArray(value))
        return value.map((item) => canonicalJsonValue(item));
    if (typeof value === "object") {
        const ordered = {};
        for (const key of Object.keys(value).sort()) {
            ordered[key] = canonicalJsonValue(value[key]);
        }
        return ordered;
    }
    return value;
}
export function canonicalize(fields) {
    return JSON.stringify(canonicalJsonValue(fields));
}
export function computeHmac(key, prevHash, canonical) {
    const h = createHmac("sha256", key);
    h.update(prevHash);
    h.update(canonical);
    return new Uint8Array(h.digest());
}
export function rowsFromExecute(result) {
    if (Array.isArray(result))
        return result;
    if (result &&
        typeof result === "object" &&
        Array.isArray(result.rows)) {
        return result.rows;
    }
    return [];
}
//# sourceMappingURL=audit-codec.js.map