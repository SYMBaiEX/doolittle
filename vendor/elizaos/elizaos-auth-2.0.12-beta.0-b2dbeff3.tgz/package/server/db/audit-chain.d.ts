import { getDb } from "./client.js";
/** @internal test hook: forget the memoized HMAC key so env changes take effect. */
export declare function __resetAuditHmacKeyCacheForTests(): void;
export type ActorType = "user" | "agent" | "platform" | "system" | "api-key";
export interface AuditEventInput {
    tenantId: string;
    actorType: ActorType;
    actorId?: string | null;
    /** Dotted action name, e.g. "vault.sign", "auth.login", "policy.update". */
    action: string;
    resourceType?: string | null;
    resourceId?: string | null;
    metadata?: Record<string, unknown>;
    ipAddress?: string | null;
    userAgent?: string | null;
    requestId?: string | null;
}
/**
 * Serialize `fn` per tenant in-process. This is the PGLite chain-serialization
 * guarantee and also gates the real-Postgres advisory-lock acquisition so
 * concurrent appends within one process cannot interleave the seq read/insert.
 */
export declare function withTenantAuditQueue<T>(tenantId: string, fn: () => Promise<T>, deadlineAt?: number): Promise<T>;
/**
 * Minimal transaction handle the audit writer needs. Both Drizzle transaction
 * objects (postgres-js / neon-http / PGLite) and the top-level db satisfy this,
 * so the same append core works standalone or joined to a caller's tx.
 */
export type AuditTxLike = {
    execute: (query: unknown) => Promise<unknown>;
};
/**
 * Extend the tenant's audit chain using an EXISTING transaction. The head read,
 * event insert, and chain-head high-water-mark update all execute against `tx`,
 * so they commit or roll back atomically with whatever else the caller did in
 * the same transaction. This is the primitive that lets a state transition and
 * its required audit event be both-or-neither (spec I14, evidence before
 * visibility).
 *
 * Callers MUST hold the per-tenant advisory lock (real Postgres) or the
 * per-tenant in-process queue (PGLite) for the duration of `tx` so concurrent
 * appends cannot interleave the seq read/insert. `withTenantAuditedTransaction`
 * arranges both; do not call this directly outside that helper.
 */
export declare function appendAuditEventWithinTx(tx: AuditTxLike, ev: AuditEventInput): Promise<void>;
/**
 * Append the event on its own transaction (standalone chain extension). Throws
 * on failure. Serialization / seq conflicts retry the whole append.
 */
export declare function appendAuditEvent(ev: AuditEventInput): Promise<void>;
/**
 * Append an event to the tenant's audit chain. Throws on failure — callers
 * MUST treat audit-write failure as an action failure for sensitive
 * operations (auth, signing, policy mutations).
 */
export declare function writeAuditEvent(ev: AuditEventInput): Promise<void>;
/**
 * Callback signature handed to `withTenantAuditedTransaction`. Appending a
 * required audit event uses the SAME transaction as the caller's row mutations,
 * so the state change and its audit record are atomic.
 */
export type AppendRequiredAudit = (event: AuditEventInput) => Promise<void>;
/**
 * Run `fn` inside one tenant-audited transaction. The state mutations the caller
 * performs on `tx` and every `appendRequiredAudit(...)` event commit or roll
 * back together, closing the non-atomic "mutate then audit in a separate
 * transaction" gap (spec section 7.1 / invariant I14).
 *
 * Guarantees:
 *  - one `db.transaction` wraps the whole unit of work;
 *  - the per-tenant advisory lock (real Postgres) is acquired before any audit
 *    read, matching `writeAuditEvent`'s chain-serialization contract;
 *  - PGLite runs are serialized per tenant in-process (advisory lock is a no-op
 *    there, exactly as in `appendAuditEvent`);
 *  - serialization / seq conflicts retry the WHOLE unit of work before it is
 *    known committed, so a retried transition never double-applies or duplicates
 *    an audit row (the mutations use guarded `WHERE status = ...` predicates and
 *    are idempotent on retry).
 *
 * The caller must not open a nested transaction inside `fn`; use the provided
 * `tx`. The caller must not call `writeAuditEvent` inside `fn` (that would open
 * a second transaction and deadlock on the advisory lock); use
 * `appendRequiredAudit` instead.
 */
export declare function withTenantAuditedTransaction<T>(tenantId: string, fn: (tx: unknown, appendRequiredAudit: AppendRequiredAudit) => Promise<T>): Promise<T>;
/** Deadline-aware form used by bounded credential-lease lifecycles. The
 * supplied handle is dedicated to that lifecycle, so all reads and audited
 * mutations share one driver cancellation boundary. */
export declare function withTenantAuditedTransactionOnDb<T>(db: ReturnType<typeof getDb>, tenantId: string, fn: (tx: unknown, appendRequiredAudit: AppendRequiredAudit) => Promise<T>, deadlineAt?: number): Promise<T>;
//# sourceMappingURL=audit-chain.d.ts.map