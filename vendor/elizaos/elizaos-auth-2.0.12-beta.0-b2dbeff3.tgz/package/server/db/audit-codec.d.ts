export declare function toU8(value: unknown): Uint8Array;
export declare function canonicalJsonValue(value: unknown): unknown;
export declare function canonicalize(fields: Record<string, unknown>): string;
export declare function computeHmac(key: Uint8Array, prevHash: Uint8Array, canonical: string): Uint8Array;
export declare function rowsFromExecute<T>(result: unknown): T[];
//# sourceMappingURL=audit-codec.d.ts.map