declare const trustedTenantContextBrand: unique symbol;
export type TenantRlsDriver = "postgres-js" | "pglite";
/**
 * An application-internal capability minted only after authentication or by a
 * named background job. Request headers and body fields are not valid inputs to
 * the transaction helper.
 */
export interface TrustedTenantContext {
    readonly tenantId: string;
    readonly userId?: string;
    readonly authority: {
        readonly kind: "authenticated-principal";
        readonly method: string;
        readonly subject: string;
    } | {
        readonly kind: "internal-job";
        readonly job: string;
    };
    readonly [trustedTenantContextBrand]: true;
}
export declare function tenantContextFromAuthenticatedPrincipal(input: {
    tenantId: string;
    method: string;
    subject: string;
    userId?: string;
}): TrustedTenantContext;
export declare function tenantContextForInternalJob(input: {
    tenantId: string;
    job: string;
}): TrustedTenantContext;
export declare function assertTenantRlsDriver(driver: TenantRlsDriver): void;
interface TenantTransactionExecutor {
    execute(query: unknown): Promise<unknown>;
}
interface TenantTransactionalDatabase<Tx extends TenantTransactionExecutor> {
    transaction<T>(callback: (tx: Tx) => Promise<T>): Promise<T>;
}
export interface TenantTransactionCharacteristics {
    isolationLevel?: "repeatable read";
    readOnly?: boolean;
}
/**
 * Run one tenant unit of work on one checked-out connection. `set_config(...,
 * true)` is transaction-local, so commit, rollback, and pool reuse clear the
 * context. Never replace this with session-level SET on a pooled connection.
 */
export declare function withTenantRlsTransaction<Tx extends TenantTransactionExecutor, T>(db: TenantTransactionalDatabase<Tx>, driver: TenantRlsDriver, context: TrustedTenantContext, callback: (tx: Tx) => Promise<T>, characteristics?: TenantTransactionCharacteristics): Promise<T>;
export {};
//# sourceMappingURL=tenant-rls-context.d.ts.map