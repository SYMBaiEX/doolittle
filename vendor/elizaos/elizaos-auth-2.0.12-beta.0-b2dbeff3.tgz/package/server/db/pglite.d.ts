/**
 * PGLite adapter for Steward — runs Postgres in-process via WASM.
 *
 * Use this for local / desktop mode (Electrobun) where no external
 * PostgreSQL server is available.
 *
 * Environment detection:
 *   - STEWARD_DB_MODE=pglite  → always use PGLite
 *   - No DATABASE_URL set     → fall back to PGLite
 *   - STEWARD_PGLITE_PATH    → persistence directory (default ~/.steward/data)
 *   - STEWARD_PGLITE_MEMORY  → if "true", use in-memory (no persistence)
 */
import { PGlite } from "@electric-sql/pglite";
import { drizzle } from "drizzle-orm/pglite";
import * as schema from "./schema.js";
import * as schemaAuth from "./schema-auth.js";
export type PGLiteDb = ReturnType<typeof drizzle<typeof schema & typeof schemaAuth>>;
/**
 * Resolve the data directory for PGLite persistence.
 */
export declare function getDataDir(): string;
/**
 * Determine whether PGLite should be used based on environment variables.
 */
export declare function shouldUsePGLite(): boolean;
/**
 * Run all SQL migration files from the drizzle/ folder in lexicographic order.
 *
 * This reads every *.sql file (excluding meta/), splits on the Drizzle
 * statement-breakpoint marker, and executes each statement sequentially.
 * The `__steward_migrations` table tracks which files have already been applied
 * so restarts with a persistent data dir don't re-run migrations.
 */
export declare function runPGLiteMigrations(client: PGlite, migrationsFolder?: string): Promise<void>;
/**
 * Create a PGLite-backed Drizzle instance.
 *
 * @param dataDir - directory for persistence, or "memory://" for in-memory
 */
export declare function createPGLiteDb(dataDir?: string): Promise<{
    client: PGlite;
    db: PGLiteDb;
}>;
/**
 * Get or create the global PGLite DB singleton.
 * Mirrors the getDb() / getSql() pattern from client.ts.
 */
export declare function getPGLiteDb(): Promise<PGLiteDb>;
export declare function getPGLiteClient(): Promise<PGlite>;
export declare function closePGLiteDb(): Promise<void>;
//# sourceMappingURL=pglite.d.ts.map