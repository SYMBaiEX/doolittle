import { eq, inArray } from "drizzle-orm";
import { requireLoginValue } from "../../required.js";
export { __resetAuditHmacKeyCacheForTests, appendAuditEvent, appendAuditEventWithinTx, withTenantAuditedTransaction, withTenantAuditedTransactionOnDb, withTenantAuditQueue, writeAuditEvent, } from "./audit-chain.js";
export { closeDb, createDb, createPostgresClient, DATABASE_DEADLINE_EXCEEDED_MESSAGE, DatabaseDeadlineExceededError, getDatabaseDriver, getDatabaseUrl, getDb, getSql, hasTenantTransactionDatabase, isEmbeddedDatabase, setPGLiteOverride, waitUntilTenantDatabaseTask, withDatabaseDeadline, withTenantTransactionDatabase, } from "./client.js";
export { runMigrations } from "./migrate.js";
export { assessMigrationLedger, getMigrationExpectation, getMigrationLedgerExpectation, } from "./migration-status.js";
export { ALL_INVENTORIED_TABLES, BOOTSTRAP_ROOT_TABLES, DIRECT_TENANT_TABLES, HYBRID_SCOPE_TABLES, INDIRECT_TENANT_TABLES, INTENTIONALLY_GLOBAL_TABLES, TENANT_COLUMN_BACKFILL_TABLES, } from "./rls-inventory.js";
// PGlite is loaded by the embedded runtime; ordinary database consumers do not initialize WASM.
export * from "./schema.js";
export * from "./schema-auth.js";
export { assertTenantRlsDriver, tenantContextForInternalJob, tenantContextFromAuthenticatedPrincipal, withTenantRlsTransaction, } from "./tenant-rls-context.js";
import { policyTypeEnum } from "./schema.js";
export function isPersistedPolicyType(value) {
    return policyTypeEnum.enumValues.includes(value);
}
export function toPersistedPolicyRule(policy) {
    if (!isPersistedPolicyType(policy.type)) {
        throw new Error(`Unsupported persisted policy type: ${policy.type}`);
    }
    return policy;
}
export function toAgentIdentity(agent) {
    return {
        id: agent.id,
        tenantId: agent.tenantId,
        name: agent.name,
        walletAddress: agent.walletAddress,
        platformId: agent.platformId ?? undefined,
        createdAt: agent.createdAt,
        updatedAt: agent.updatedAt,
    };
}
/**
 * Query all wallet addresses for a single agent from the `agent_wallets` table.
 * Returns an empty object for legacy agents that pre-date multi-wallet support.
 */
export async function getAgentWalletAddresses(agentId) {
    const { getDb } = await import("./client.js");
    const { agentWallets } = await import("./schema.js");
    const db = getDb();
    const rows = await db
        .select()
        .from(agentWallets)
        .where(eq(agentWallets.agentId, agentId));
    const result = {};
    for (const row of rows) {
        if (row.chainFamily === "evm")
            result.evm = row.address;
        if (row.chainFamily === "solana")
            result.solana = row.address;
        if (row.chainFamily === "bitcoin")
            result.bitcoin = row.address;
        if (row.chainFamily === "monero")
            result.monero = row.address;
    }
    return result;
}
/**
 * Query wallet addresses for multiple agents in a single DB round-trip.
 * Returns a Map from agentId → { evm?, solana?, bitcoin?, monero? }.
 */
export async function getAgentWalletAddressesBatch(agentIds) {
    if (agentIds.length === 0)
        return new Map();
    const { getDb } = await import("./client.js");
    const { agentWallets } = await import("./schema.js");
    const db = getDb();
    const rows = await db
        .select()
        .from(agentWallets)
        .where(inArray(agentWallets.agentId, agentIds));
    const result = new Map();
    for (const row of rows) {
        if (!result.has(row.agentId))
            result.set(row.agentId, {});
        const entry = requireLoginValue(result.get(row.agentId), "result.get(row.agentId)");
        if (row.chainFamily === "evm")
            entry.evm = row.address;
        if (row.chainFamily === "solana")
            entry.solana = row.address;
        if (row.chainFamily === "bitcoin")
            entry.bitcoin = row.address;
        if (row.chainFamily === "monero")
            entry.monero = row.address;
    }
    return result;
}
export function toPolicyRule(policy) {
    return {
        id: policy.id,
        agentId: policy.agentId,
        type: policy.type,
        enabled: policy.enabled,
        config: policy.config,
        createdAt: policy.createdAt,
        updatedAt: policy.updatedAt,
    };
}
export function toSignRequest(transaction) {
    return {
        agentId: transaction.agentId,
        tenantId: "",
        to: transaction.toAddress,
        value: transaction.value,
        data: transaction.data ?? undefined,
        chainId: transaction.chainId,
    };
}
export function toTxRecord(transaction) {
    return {
        id: transaction.id,
        agentId: transaction.agentId,
        status: transaction.status,
        request: toSignRequest(transaction),
        txHash: transaction.txHash ?? undefined,
        policyResults: transaction.policyResults ?? [],
        createdAt: transaction.createdAt,
        signedAt: transaction.signedAt ?? undefined,
        confirmedAt: transaction.confirmedAt ?? undefined,
    };
}
//# sourceMappingURL=index.js.map