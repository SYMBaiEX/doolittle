/** Starts the first-party desktop identity service using its persisted local database. */
import { startEmbeddedLogin } from "./runtime.js";
import { serveUntilSignal } from "./serve-until-signal.js";
export { startEmbeddedLogin } from "./runtime.js";
if (import.meta.main)
    await serveUntilSignal(await startEmbeddedLogin());
//# sourceMappingURL=embedded.js.map