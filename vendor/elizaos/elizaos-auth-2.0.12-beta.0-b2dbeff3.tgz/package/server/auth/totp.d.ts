/**
 * TOTP (RFC 6238) — time-based one-time passwords for authenticator-app 2FA.
 *
 * Uses HMAC-SHA-1 with a 30-second step, 6-digit codes (the configuration
 * universally accepted by Google Authenticator, Authy, 1Password, etc).
 *
 * Verification accepts the current step plus a configurable window of ±N
 * steps to tolerate clock skew between the user's device and the server.
 * The default window of ±1 step (so 90s total) is the recommendation from
 * the RFC for interactive 2FA.
 *
 * Secrets are stored as RFC 4648 base32 (uppercase, no padding) because
 * that is the format `otpauth://` URIs require and what authenticator apps
 * accept by scan or by hand-entry.
 */
/** RFC 4648 base32 encode (no padding). */
export declare function base32Encode(bytes: Uint8Array): string;
/** RFC 4648 base32 decode. Tolerates lowercase, whitespace, and trailing '='. */
export declare function base32Decode(encoded: string): Uint8Array;
/** Generate a fresh 20-byte (160-bit) secret and return it base32-encoded. */
export declare function generateTotpSecret(): string;
/** Generate the TOTP code for `secret` at `time` (defaults to Date.now()). */
export declare function generateTotp(secret: string, options?: {
    stepSec?: number;
    time?: number;
}): Promise<string>;
export interface TotpVerifyOptions {
    /** ± steps of clock-skew tolerance. Default 1 (±30s). */
    windowSteps?: number;
    stepSec?: number;
    time?: number;
}
/**
 * Verify a user-supplied TOTP code. Returns `{ valid: true, drift }` where
 * `drift` is the step offset at which the code matched (0 = current step,
 * -1 = previous, +1 = next). Returns `{ valid: false }` on no match.
 *
 * Callers MUST track the per-secret highest-matched drift and reject any
 * subsequent code whose step <= the last accepted step — otherwise a code
 * captured in flight can be replayed within the same window.
 */
export declare function verifyTotp(secret: string, code: string, options?: TotpVerifyOptions): Promise<{
    valid: boolean;
    drift?: number;
}>;
export interface OtpauthUriParams {
    /** Application name shown in the authenticator app. */
    issuer: string;
    /** Account identifier (usually email or username). */
    accountName: string;
    /** Base32-encoded secret. */
    secret: string;
}
/**
 * Build the `otpauth://` URI consumed by authenticator-app QR codes.
 * Spec: https://github.com/google/google-authenticator/wiki/Key-Uri-Format
 */
export declare function buildOtpauthUri(params: OtpauthUriParams): string;
/**
 * Suppress unused-import warnings — `encoder` exists for parity with the
 * other auth modules even though TOTP doesn't itself encode UTF-8.
 */
export declare const _: TextEncoder;
//# sourceMappingURL=totp.d.ts.map