import { type ManagedSmsOtpProvider, type SmsProvider, TwilioVerifyProvider } from "./sms-provider.js";
export declare class BlooioSmsProvider implements SmsProvider {
    private readonly config;
    constructor(config: {
        apiKey: string;
        from: string;
    });
    send(to: string, body: string): Promise<void>;
}
export declare function buildTwilioVerifyProviderFromEnvironment(env?: NodeJS.ProcessEnv): TwilioVerifyProvider | undefined;
export declare function buildPhoneAuthProvidersFromEnvironment(env?: NodeJS.ProcessEnv): {
    provider?: SmsProvider;
    managedProvider?: ManagedSmsOtpProvider;
};
//# sourceMappingURL=phone-provider.d.ts.map