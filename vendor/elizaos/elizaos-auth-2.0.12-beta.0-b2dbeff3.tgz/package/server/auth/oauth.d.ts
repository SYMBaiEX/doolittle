/**
 * oauth.ts — Generic OAuth2 authorization-code flow helper
 *
 * Supports any provider that follows the standard OAuth2 authorization-code flow.
 * Built-in configs for Google, Discord, Twitter/X, GitHub, LinkedIn, Spotify,
 * Twitch, Instagram, LINE, Apple, and TikTok.
 *
 * Twitter specifics:
 *   - Requires PKCE (RFC 7636, S256 method) — Twitter OAuth2 mandates it for
 *     confidential clients.
 *   - Does NOT return an email address. provisionOAuthUser() in auth.ts must
 *     handle this by generating a synthetic internal email.
 *   - User info endpoint returns { data: { id, name, username } }, not a flat object.
 *
 * Usage:
 *   const client = new OAuthClient(config, 'google');
 *   const { url, codeVerifier } = client.generateAuthUrl(state, redirectUri);
 *   // store codeVerifier in challenge store alongside state
 *   const { access_token } = await client.exchangeCode(code, redirectUri, codeVerifier);
 *   const profile = await client.getUserInfo(access_token);
 */
export interface OAuthProvider {
    clientId: string;
    clientSecret: string;
    authorizationUrl: string;
    tokenUrl: string;
    userInfoUrl: string;
    scopes: string[];
    scopeDelimiter?: " " | ",";
    /** If true, PKCE (S256) is added to the auth URL and required in code exchange. */
    requiresPkce?: boolean;
    emailUrl?: string;
    profileMap?: OAuthProfileMap;
    /**
     * Overrides the OAuth `client_id` parameter name on the authorize and token
     * requests. TikTok, for example, names the parameter `client_key` rather than
     * `client_id`. The internal config field stays `clientId`; only the wire
     * parameter name changes. Defaults to "client_id".
     */
    clientIdParam?: string;
    /**
     * Asserts that this provider returns a confirmed/verified account email even
     * though its userinfo response carries no per-response verification flag.
     * Only set this when the provider's contract proves email verification.
     */
    assertsEmailVerified?: boolean;
    /**
     * Marks the provider as OIDC: the user's identity is derived from the
     * `id_token` returned by the token endpoint (verified against `oidcJwksUri`),
     * not from a userinfo endpoint. Used for "Sign in with Apple", which exposes
     * no userinfo endpoint. When set, getUserInfo() verifies the id_token from the
     * preceding exchangeCode() call instead of calling userInfoUrl.
     */
    oidc?: OAuthOidcConfig;
}
export interface OAuthOidcConfig {
    /** Expected issuer (`iss`) of the id_token. */
    issuer: string;
    /** JWKS endpoint used to verify the id_token signature. */
    jwksUri: string;
}
export interface OAuthProfileMap {
    id?: string;
    email?: string;
    name?: string;
    picture?: string;
    emailVerified?: string;
}
export interface OAuthTokenResponse {
    access_token: string;
    token_type: string;
    expires_in?: number;
    refresh_token?: string;
    scope?: string;
    /** Present for OIDC providers (e.g. Apple). A JWT carrying the user identity. */
    id_token?: string;
}
export interface OAuthUserInfo {
    id: string;
    email: string;
    name?: string;
    picture?: string;
    verified_email?: boolean;
}
export interface AuthUrlResult {
    url: string;
    /** Present for internally generated PKCE; caller-owned challenges never return a verifier. */
    codeVerifier?: string;
}
declare const BUILT_IN_PROVIDERS: readonly ["google", "discord", "twitter", "github", "linkedin", "spotify", "twitch", "instagram", "line", "apple", "tiktok"];
type BuiltInProvider = (typeof BUILT_IN_PROVIDERS)[number];
/**
 * Returns true if the given provider name is a known built-in OAuth provider.
 */
export declare function isBuiltInProvider(provider: string): provider is BuiltInProvider | string;
/**
 * Returns the list of OAuth providers that are currently enabled via environment variables.
 */
export declare function getEnabledProviders(): string[];
export declare function getProviderConfig(provider: string): OAuthProvider;
/**
 * Generic OAuth2 authorization-code flow client.
 * Supports PKCE (S256) when the provider's requiresPkce flag is true.
 */
export declare class OAuthClient {
    private readonly provider;
    /**
     * For OIDC providers (e.g. Apple), the id_token captured from the most recent
     * exchangeCode() call. getUserInfo() verifies this rather than fetching a
     * userinfo endpoint. A fresh OAuthClient is constructed per request, so this
     * per-instance state never leaks across login attempts.
     */
    private lastIdToken;
    /**
     * Optional login-request nonce that an OIDC id_token must echo back. When the
     * caller issued a nonce for the authorize request, it sets this before
     * getUserInfo() so verification binds the token to this login attempt.
     */
    private expectedNonce;
    constructor(provider: OAuthProvider);
    /**
     * Generates the authorization URL to redirect the user to.
     *
     * @param state      - CSRF state token (random, stored server-side)
     * @param redirectUri - Where the provider should send the user after auth
     * @returns url and, when PKCE is required, a codeVerifier to store server-side
     */
    generateAuthUrl(state: string, redirectUri: string, pkce?: {
        codeChallenge: string;
        codeChallengeMethod: "S256";
    }): AuthUrlResult;
    /**
     * Exchanges an authorization code for an access token.
     *
     * @param code         - The authorization code from the provider callback
     * @param redirectUri  - Must match the one used in generateAuthUrl
     * @param codeVerifier - Required when PKCE was used in generateAuthUrl
     */
    exchangeCode(code: string, redirectUri: string, codeVerifier?: string): Promise<OAuthTokenResponse>;
    /**
     * Binds the next getUserInfo() call (OIDC providers only) to a login-request
     * nonce. Apple echoes the authorize-request `nonce` back into the id_token;
     * setting it here makes verification reject a token minted for a different
     * login attempt. No-op for non-OIDC providers.
     */
    setExpectedNonce(nonce: string | undefined): void;
    /**
     * Fetches the authenticated user's profile from the provider.
     *
     * Handles provider-specific response shapes:
     * - Google/Discord: flat object with standard fields
     * - Twitter: nested `{ data: { id, name, username } }` — no email field
     *
     * For Twitter, email will be empty string. Callers must handle this:
     * use `twitter.${id}@id.steward.internal` as a synthetic identity key.
     *
     * @param accessToken - The access token from exchangeCode
     */
    getUserInfo(accessToken: string): Promise<OAuthUserInfo>;
    /**
     * Verifies the OIDC id_token captured during exchangeCode() and normalizes it
     * into the common profile shape. Currently the only built-in OIDC provider is
     * Apple, whose issuer/JWKS are pinned; the verifier checks signature, issuer,
     * audience (=clientId), expiry, and — when set — the login-request nonce.
     */
    private getOidcUserInfo;
    private getPrimaryEmail;
}
export {};
//# sourceMappingURL=oauth.d.ts.map