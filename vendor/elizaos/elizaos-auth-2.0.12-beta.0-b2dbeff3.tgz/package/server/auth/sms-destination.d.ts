/**
 * SMS destination policy — the deployment-wide guard against SMS pumping
 * (toll fraud). Pumping farms trigger OTP sends to premium-rate numbers in
 * countries the product never serves; per-IP and per-destination limits do not
 * stop them because they rotate both. This policy runs inside PhoneAuth.sendOtp,
 * so every send path (login, WhatsApp, MFA enrollment/challenge, account link)
 * is covered regardless of tenant configuration.
 *
 * STEWARD_SMS_ALLOWED_COUNTRY_CODES — comma-separated calling-code prefixes
 * (digits, no "+"). Default "1". "*" disables the policy. The bare "1" entry
 * means US + Canada (and US territories): +1 numbers in the other NANP
 * countries (Caribbean, Bermuda) and non-geographic +1 codes (toll-free,
 * premium 900, personal 5XX) are refused unless their own longer prefix is
 * listed, e.g. "1,1876" also allows Jamaica.
 */
/** Errors a caller maps to a client response; no provider call was made. */
export declare class SmsDestinationNotAllowedError extends Error {
    constructor();
}
export declare class SmsSendBudgetExceededError extends Error {
    readonly retryAfterSecs: number;
    constructor(retryAfterSecs?: number);
}
export declare function parseAllowedSmsCountryCodes(raw: string | undefined): string[] | "*";
/** True when an E.164 number may receive an OTP under the deployment policy. */
export declare function isSmsDestinationAllowed(phone: string, env?: Record<string, string | undefined>): boolean;
/** Deployment-wide OTP send ceiling per hour. 0 disables the ceiling. */
export declare function smsSendGlobalMaxPerHour(env?: Record<string, string | undefined>): number;
//# sourceMappingURL=sms-destination.d.ts.map