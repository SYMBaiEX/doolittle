/**
 * P-256 (secp256r1 / ECDSA) asymmetric authorization keys.
 *
 * Privy "authorization keys" are P-256 keypairs: the client signs each
 * privileged request with a private key and the server verifies the signature
 * against a registered public key. This module is the asymmetric counterpart to
 * the symmetric HMAC request-signing path in
 * `packages/auth/src/server/api/middleware/authorization-signature.ts`.
 *
 * The verifier signs/verifies the SAME canonical string the HMAC path builds,
 * so the two mechanisms are interchangeable per signer record.
 *
 * Security posture: every parse / import / verify error is swallowed and
 * surfaced as `false` (fail closed). No exception escapes `verifyP256Signature`.
 *
 * ── Accepted public-key encodings ──────────────────────────────────────────
 *   - SPKI / DER, base64 or base64url (the standard `crypto.subtle` "spki"
 *     export — what `exportP256PublicKeySpkiBase64` emits).
 *   - Raw uncompressed EC point `0x04 || X(32) || Y(32)` (65 bytes), as base64,
 *     base64url, or hex (with or without a leading `0x`). WebCrypto imports this
 *     via the "raw" format.
 *   - JWK (an object, or a JSON string) with `kty:"EC"`, `crv:"P-256"`.
 *
 * ── Accepted signature encodings ───────────────────────────────────────────
 *   - IEEE-P1363 fixed-width `r || s` (64 bytes for P-256), base64/base64url/hex.
 *     This is what WebCrypto's ECDSA verify expects natively and what
 *     `signP256` emits.
 *   - ASN.1 DER `SEQUENCE { INTEGER r, INTEGER s }` (what OpenSSL / many HSMs
 *     emit), base64/base64url/hex. Converted to r||s before verification;
 *     malformed DER fails closed.
 */
export type P256PublicKeyInput = string | JsonWebKey | CryptoKey;
/**
 * Import a P-256 public key from any accepted encoding. Returns null on any
 * failure (wrong curve, wrong format, malformed bytes) — fail closed.
 *
 * Exported so callers can pre-validate a registered key at write time.
 */
export declare function importP256PublicKey(input: P256PublicKeyInput): Promise<CryptoKey | null>;
/**
 * Verify a P-256 ECDSA signature over `canonicalString`.
 *
 * @param publicKey   Registered public key in any accepted encoding (see module docs).
 * @param canonicalString  The exact canonical request string the signer signed.
 * @param signatureBase64  Signature as base64/base64url/hex, P1363 r||s or DER.
 * @returns `true` only on a cryptographically valid signature; `false` on ANY
 *          error (import failure, wrong curve, malformed signature, mismatch).
 */
export declare function verifyP256Signature(publicKey: P256PublicKeyInput, canonicalString: string, signatureBase64: string): Promise<boolean>;
export type GeneratedP256KeyPair = {
    privateKey: CryptoKey;
    publicKey: CryptoKey;
    /** Base64 SPKI public key, suitable for storing as `agent_signers.public_key`. */
    publicKeySpkiBase64: string;
    /** Base64 raw uncompressed `04||X||Y` public key. */
    publicKeyRawBase64: string;
};
/** Generate a P-256 keypair (extractable public key) for tests / tooling. */
export declare function generateP256KeyPair(): Promise<GeneratedP256KeyPair>;
/** Export a P-256 public key to base64 SPKI (storage format). */
export declare function exportP256PublicKeySpkiBase64(publicKey: CryptoKey): Promise<string>;
/**
 * Sign `canonicalString` with a P-256 private key, returning a base64 P1363
 * (r||s) signature. For tests / client tooling only.
 */
export declare function signP256(privateKey: CryptoKey, canonicalString: string): Promise<string>;
//# sourceMappingURL=authorization-keys.d.ts.map