export declare function hashSha256Hex(value: string): string;
//# sourceMappingURL=crypto.d.ts.map