/**
 * Issues and verifies login tokens with deployment-owned signing authority.
 * Persisted issuer, audience and key derivation labels preserve existing sessions.
 */
import { type JWK, type JWTPayload } from "jose";
export declare const JWT_ISSUER = "steward";
export declare const JWT_AUDIENCE = "steward-api";
export declare const ACCESS_TOKEN_EXPIRY = "15m";
export declare const ACCESS_TOKEN_EXPIRY_SECONDS = 900;
/** Stable default retained for API compatibility. Runtime overrides are read by getAgentTokenExpiry. */
export declare const AGENT_TOKEN_EXPIRY = "30d";
export declare const REFRESH_TOKEN_EXPIRY = "30d";
export declare const IDENTITY_TOKEN_EXPIRY = "15m";
export type IdentityJwtAlgorithm = "RS256" | "ES256";
export interface LoginJwtPayload extends JWTPayload {
    tenantId?: string;
    address?: string;
    userId?: string;
    email?: string;
    agentId?: string;
    scope?: string;
    tokenType?: "access" | "agent" | "refresh";
    [key: string]: unknown;
}
export interface AccessTokenPayload extends LoginJwtPayload {
    address: string;
    tenantId: string;
}
export interface AgentTokenPayload extends LoginJwtPayload {
    agentId: string;
    tenantId: string;
    scope: "agent";
    /** Plural permissions list. Required for proxy access ("api:proxy"). */
    scopes?: string[];
}
export interface RefreshTokenPayload extends LoginJwtPayload {
    userId: string;
    tenantId: string;
    tokenType: "refresh";
}
export interface JwtSecretOptions {
    /** Defaults to process.env.NODE_ENV. */
    nodeEnv?: string;
    /** Defaults to the structured login logger. Pass null to silence warnings. */
    warn?: ((message: string) => void) | null;
    /** Explicit immutable environment used to construct request-scoped authority. */
    environment?: JwtRuntimeEnvironment;
}
export interface JwtRuntimeEnvironment {
    readonly NODE_ENV?: string;
    readonly STEWARD_JWT_SECRET?: string;
    readonly STEWARD_SESSION_SECRET?: string;
    readonly STEWARD_MASTER_PASSWORD?: string;
    readonly STEWARD_EMBEDDED?: string;
    readonly STEWARD_EMBEDDED_MODE?: string;
    readonly STEWARD_DB_MODE?: string;
    readonly DATABASE_URL?: string;
    readonly STEWARD_ALLOW_DEV_SECRETS?: string;
    readonly STEWARD_ALLOW_DEV_SECRET?: string;
    readonly AGENT_TOKEN_EXPIRY?: string;
    readonly STEWARD_IDENTITY_JWT_ALG?: string;
    readonly STEWARD_IDENTITY_JWT_PRIVATE_KEY?: string;
    readonly STEWARD_IDENTITY_JWT_KID?: string;
    readonly STEWARD_IDENTITY_JWT_ISSUER?: string;
    readonly STEWARD_IDENTITY_JWT_AUDIENCE?: string;
    readonly APP_URL?: string;
}
/** Immutable symmetric and asymmetric JWT authority for one request. */
export interface JwtRuntimeAuthority {
    readonly nodeEnv: string | undefined;
    readonly jwtSecret: string;
    readonly agentTokenExpiry: string;
    readonly identityJwtAlgorithm: IdentityJwtAlgorithm;
    readonly identityJwtPrivateKey?: string;
    readonly identityJwtKid?: string;
    readonly identityJwtIssuer?: string;
    readonly identityJwtAudience: string;
    readonly appUrl?: string;
}
export interface IdentityJwtConfig {
    alg: IdentityJwtAlgorithm;
    kid: string;
    issuer: string;
    audience: string;
}
export declare class IdentityJwtConfigurationError extends Error {
    constructor(message: string);
}
/**
 * Whether the insecure built-in "dev-secret" fallbacks may be used.
 *
 * Hardened opt-in: a dev-secret is only permitted when the deployment is NOT
 * production AND the operator has explicitly set STEWARD_ALLOW_DEV_SECRETS=true.
 * This prevents a staging/preview deploy that forgot NODE_ENV=production from
 * silently signing/verifying with a well-known, predictable secret.
 *
 * Exported so other packages (vault, webhooks, api key stores) can apply the
 * same consistent guard.
 */
export declare function isDevSecretAllowed(nodeEnv?: string | undefined, environment?: JwtRuntimeEnvironment): boolean;
/**
 * Length policy for any CONFIGURED JWT secret (SEC-053): production hard-fails
 * below 32 characters; other environments still accept shorter values (tests
 * and local dev rely on them) but warn loudly once, so a staging/preview
 * deploy with a weak secret is visible in logs instead of silently issuing
 * brute-forceable tokens. The explicit dev-secret fallback is not routed here.
 */
export declare function checkJwtSecretStrength(secret: string, sourceName: string, options?: {
    nodeEnv?: string;
    warn?: ((message: string) => void) | null;
}): void;
/**
 * Resolve Steward's canonical JWT secret.
 *
 * Canonical env var: STEWARD_JWT_SECRET.
 * Deprecated compatibility fallback: STEWARD_SESSION_SECRET.
 * In embedded/local dev mode only, STEWARD_MASTER_PASSWORD is accepted as
 * derivation input — never used verbatim (see deriveEmbeddedJwtSecret).
 */
export declare function getJwtSecret(options?: JwtSecretOptions): string;
export declare function getJwtSecretKey(options?: JwtSecretOptions): Uint8Array;
export declare function isAsymmetricIdentityJwtConfigured(): boolean;
export declare function getIdentityJwtIssuer(requestOrigin?: string): string;
/**
 * Resolve the externally visible identity-discovery base for the current
 * request. Worker requests use their immutable authority snapshot so an
 * overlapping invocation cannot substitute its process.env compatibility
 * mirror while this request is suspended.
 */
export declare function getIdentityDiscoveryBaseUrl(requestUrl: string): string;
export declare function getIdentityJwtAudience(): string;
export declare function getIdentityJwks(): Promise<{
    keys: JWK[];
}>;
export declare function getIdentityJwtConfig(requestOrigin?: string): Promise<IdentityJwtConfig | null>;
/** Validate JWT env at service startup; throws clear errors for invalid production config. */
export declare function validateJwtSecretEnv(options?: JwtSecretOptions): void;
/** Hard upper bound for AGENT_TOKEN_EXPIRY: one year. */
export declare const AGENT_TOKEN_EXPIRY_MAX_SECONDS: number;
/**
 * Parse a relative duration string ("30m", "12h", "5 days") into seconds.
 * Returns null when the value is not a positive forward duration in the
 * grammar jose accepts for setExpirationTime.
 */
export declare function parseDurationSeconds(value: string): number | null;
/**
 * Validate AGENT_TOKEN_EXPIRY format and bound at startup (SEC-134). A bad
 * value otherwise surfaces as a 500 at token-signing time, and an unbounded
 * value mints effectively-permanent agent tokens.
 *
 * The default resolves an immutable request authority when present, then falls
 * back to process.env for Bun/Node entry points. It never uses a module-init
 * environment capture.
 */
export declare function validateAgentTokenExpiryEnv(value?: string): void;
/** Resolve and validate an explicit, request-scoped, or process default agent-token TTL. */
export declare function getAgentTokenExpiry(value?: string): string;
/**
 * Resolve and validate one immutable JWT authority before a Worker request can
 * yield. The returned snapshot never consults process.env again.
 */
export declare function createJwtRuntimeAuthority(environment: JwtRuntimeEnvironment, options?: Pick<JwtSecretOptions, "warn">): Readonly<JwtRuntimeAuthority>;
/** Bind one immutable JWT authority to all asynchronous work spawned by a request. */
export declare function withJwtRuntimeAuthority<T>(authority: Readonly<JwtRuntimeAuthority>, callback: () => T): T;
export declare function signJwtPayload(payload: JWTPayload, expiresIn: string, secretKey?: Uint8Array, issuer?: string, audience?: string): Promise<string>;
export declare function signIdentityJwtPayload(payload: JWTPayload, expiresIn?: string, issuer?: string, audience?: string): Promise<string>;
export declare function verifyJwtPayload(token: string, secretKey?: Uint8Array, issuer?: string, audience?: string): Promise<JWTPayload>;
export declare function signAccessToken(payload: AccessTokenPayload, expiresIn?: string): Promise<string>;
export declare function signAgentToken(payload: Omit<AgentTokenPayload, "scope"> & {
    scope?: "agent";
    scopes?: string[];
}, expiresIn?: string): Promise<string>;
export declare function signRefreshToken(payload: RefreshTokenPayload, expiresIn?: string): Promise<string>;
export declare function verifyToken(token: string): Promise<LoginJwtPayload>;
//# sourceMappingURL=jwt.d.ts.map