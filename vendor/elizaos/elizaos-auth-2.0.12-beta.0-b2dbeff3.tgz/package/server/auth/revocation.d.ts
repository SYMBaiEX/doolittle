/**
 * Access-token revocation store.
 *
 * Design: user access tokens are short-lived (15m) so logout revocation is
 * mostly defense-in-depth; high-value agent tokens keep their existing longer
 * TTL and use a server-side revocation line. Multi-instance deployments should
 * set REDIS_URL so revocation state is shared. Outside production, this falls
 * back to in-memory state suitable only for single-instance/embedded mode.
 */
import type { getDb } from "../db/client.js";
export declare class TokenRevokedError extends Error {
    constructor(message?: string);
}
type ExpiresAt = Date | number;
/** An open identity-database transaction a database-backed store can write through. */
export type RevocationTransaction = Pick<ReturnType<typeof getDb>, "execute">;
export interface RevocationStore {
    revokeToken(jti: string, expiresAt: ExpiresAt): Promise<void>;
    isRevoked(jti: string): Promise<boolean>;
    revokeAgentTokens(agentId: string, issuedBefore?: number, expiresAt?: ExpiresAt): Promise<number>;
    getAgentRevokedBefore(agentId: string): Promise<number | null>;
    /**
     * `transaction` is for a caller that already holds an identity-database
     * transaction. A database-backed store writes the line in it, so the write
     * commits with the caller's work and never waits for a second connection.
     * Stores that keep the line elsewhere ignore it.
     */
    revokeUserTokens(userId: string, issuedBefore?: number, expiresAt?: ExpiresAt, transaction?: RevocationTransaction): Promise<number>;
    getUserRevokedBefore(userId: string): Promise<number | null>;
}
/** Selects the durable database store while the embedded server owns its connection. */
export declare function setDatabaseRevocationStore(store: RevocationStore | undefined): void;
export declare const revocationStore: RevocationStore;
export declare function assertTokenNotRevoked(payload: {
    jti?: string;
    exp?: number;
    iat?: number;
    agentId?: unknown;
    userId?: unknown;
    scope?: unknown;
}): Promise<void>;
export {};
//# sourceMappingURL=revocation.d.ts.map