export interface TelegramLoginPayload {
    id?: unknown;
    first_name?: unknown;
    last_name?: unknown;
    username?: unknown;
    photo_url?: unknown;
    auth_date?: unknown;
    hash?: unknown;
    [key: string]: unknown;
}
export interface VerifiedTelegramUser {
    id: string;
    firstName?: string;
    lastName?: string;
    username?: string;
    photoUrl?: string;
    authDate: number;
}
export interface VerifyTelegramLoginOptions {
    nowMs?: number;
    maxAgeSec?: number;
    maxFutureSkewSec?: number;
}
export declare function telegramLoginDataCheckString(payload: TelegramLoginPayload): string;
export declare function signTelegramLoginPayload(payload: Omit<TelegramLoginPayload, "hash">, botToken: string): string;
export declare function verifyTelegramLogin(payload: TelegramLoginPayload, botToken: string, options?: VerifyTelegramLoginOptions): VerifiedTelegramUser;
//# sourceMappingURL=telegram.d.ts.map