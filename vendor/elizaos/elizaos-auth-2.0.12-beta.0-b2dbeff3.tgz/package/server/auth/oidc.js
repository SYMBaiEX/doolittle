import { lookup as dnsLookup } from "node:dns";
import { isIP } from "node:net";
import { assertPublicHttpsEndpoint, assertPublicInternetAddress, } from "@elizaos/core";
import { createRemoteJWKSet, customFetch, decodeProtectedHeader, jwtVerify, } from "jose";
import { fetchPinnedResponse } from "../shared/pinned-response.js";
import { runtimeEnvironmentValue } from "../shared/runtime-env.js";
import { assertPinnedDnsTransportSupported, createPublicInternetLookup, } from "./public-endpoint-node.js";
const JWKS_CACHE = new Map();
const JWKS_FETCH_TIMEOUT_MS = 5_000;
const JWKS_MAX_BYTES = 256 * 1024;
const JWKS_CACHE_MAX_ENTRIES = 256;
// Hard ceiling on how long a remote JWKS set is cached before it is rebuilt.
// jose's internal cooldown only limits how *often* it refetches on unknown-kid;
// it never evicts known keys, so a process-lifetime cache would not pick up an
// IdP emergency key revocation. Rebuilding the set after this TTL guarantees a
// rotated/revoked key stops verifying within the window. Resolve the binding
// for each cache decision so a long-lived Worker observes a tightened window.
const DEFAULT_JWKS_MAX_AGE_MS = 60 * 60 * 1000;
function jwksMaxAgeMs() {
    const raw = Number(runtimeEnvironmentValue("STEWARD_OIDC_JWKS_MAX_AGE_MS"));
    if (Number.isFinite(raw) && raw >= 60_000)
        return raw;
    return DEFAULT_JWKS_MAX_AGE_MS;
}
function allowTestJwksFetch() {
    return (runtimeEnvironmentValue("NODE_ENV") === "test" &&
        runtimeEnvironmentValue("STEWARD_ALLOW_INSECURE_OIDC_JWKS_FETCH") === "true");
}
function cacheKey(tenantId, provider) {
    return `${tenantId}:${provider.id}:${provider.issuer}:${provider.jwksUri}`;
}
function claimString(claims, name) {
    if (!name)
        return undefined;
    const value = claims[name];
    return typeof value === "string" && value.trim() ? value : undefined;
}
function claimBoolean(claims, name) {
    if (!name)
        return undefined;
    const value = claims[name];
    return typeof value === "boolean" ? value : undefined;
}
function assertSafeJwksUri(jwksUri) {
    return assertPublicHttpsEndpoint(jwksUri, "OIDC jwksUri");
}
function assertPublicJwksAddress(address, family) {
    assertPublicInternetAddress(address, family, "OIDC jwksUri");
}
export async function assertPublicJwksDestination(jwksUri) {
    const url = assertSafeJwksUri(jwksUri);
    assertPinnedDnsTransportSupported("OIDC jwksUri");
    const hostname = url.hostname.replace(/^\[|\]$/g, "").toLowerCase();
    const literalVersion = isIP(hostname);
    if (literalVersion !== 0) {
        assertPublicJwksAddress(hostname, literalVersion);
        return;
    }
    const addresses = await new Promise((resolve, reject) => {
        let settled = false;
        const finish = (fn, value) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(deadline);
            fn(value);
        };
        const deadline = setTimeout(() => finish(reject, new Error("OIDC jwksUri DNS lookup timed out")), JWKS_FETCH_TIMEOUT_MS);
        dnsLookup(hostname, { all: true, verbatim: true }, (error, resolved) => {
            if (error) {
                finish(reject, new Error("OIDC jwksUri host did not resolve"));
                return;
            }
            finish(resolve, resolved);
        });
    });
    if (addresses.length === 0)
        throw new Error("OIDC jwksUri host did not resolve");
    for (const { address, family } of addresses) {
        assertPublicJwksAddress(address, family);
    }
}
/**
 * Builds (or returns a cached) remote JWKS set whose key fetches are routed
 * through the SSRF-guarded {@link fetchPublicJwks} transport. The set is
 * rebuilt once it exceeds the configured maximum age so rotated or emergency-
 * revoked IdP keys stop verifying within the window.
 *
 * Reused by both the tenant OIDC path ({@link verifyOidcJwt}) and the
 * built-in "Sign in with Apple" id_token verifier so there is a single,
 * hardened JWKS transport in the codebase.
 *
 * @param jwksUri  - The IdP JWKS endpoint (must be a public https URL).
 * @param cacheKey - Stable cache key the caller controls (e.g. issuer:jwksUri).
 */
export async function getPublicRemoteJWKSet(jwksUri, cacheKey) {
    assertPinnedDnsTransportSupported("OIDC jwksUri");
    const cached = JWKS_CACHE.get(cacheKey);
    if (cached && Date.now() - cached.createdAt <= jwksMaxAgeMs()) {
        // Refresh insertion order so the bounded map acts as an LRU cache.
        JWKS_CACHE.delete(cacheKey);
        JWKS_CACHE.set(cacheKey, cached);
        return cached.jwks;
    }
    const url = assertSafeJwksUri(jwksUri);
    const jwks = createRemoteJWKSet(url, {
        [customFetch]: (fetchUrl, init) => fetchPublicJwks(fetchUrl, init),
    });
    JWKS_CACHE.delete(cacheKey);
    while (JWKS_CACHE.size >= JWKS_CACHE_MAX_ENTRIES) {
        const oldestKey = JWKS_CACHE.keys().next().value;
        if (oldestKey === undefined)
            break;
        JWKS_CACHE.delete(oldestKey);
    }
    JWKS_CACHE.set(cacheKey, { jwks, createdAt: Date.now() });
    return jwks;
}
async function fetchPublicJwks(url, init) {
    const jwksUrl = assertSafeJwksUri(url.toString());
    assertPinnedDnsTransportSupported("OIDC jwksUri");
    if (allowTestJwksFetch())
        return fetch(jwksUrl, init);
    return fetchPinnedResponse(jwksUrl, { ...init, method: "GET" }, {
        lookup: createPublicInternetLookup("OIDC jwksUri"),
        timeoutMs: JWKS_FETCH_TIMEOUT_MS,
        maxBytes: JWKS_MAX_BYTES,
        rejectRedirects: true,
    });
}
export async function verifyOidcJwt(tenantId, provider, token) {
    const algorithms = provider.allowedAlgs?.length
        ? provider.allowedAlgs
        : ["RS256", "ES256"];
    const protectedHeader = decodeProtectedHeader(token);
    if (!protectedHeader.alg ||
        !algorithms.includes(protectedHeader.alg)) {
        throw new Error("Unsupported OIDC token algorithm");
    }
    const jwks = await getPublicRemoteJWKSet(provider.jwksUri, cacheKey(tenantId, provider));
    const { payload } = await jwtVerify(token, jwks, {
        issuer: provider.issuer,
        audience: provider.audience,
        algorithms,
        // Fail closed on non-compliant IdPs: an id_token without exp/iat never
        // expires (jose only validates exp when present) and cannot be age-bound.
        requiredClaims: ["exp", "iat"],
    });
    // OIDC Core §3.1.3.7: the `azp` (authorized party) claim, when present, MUST
    // equal the client_id. If the token carries more than one audience, `azp`
    // MUST be present (and equal to client_id). Without this check a token minted
    // for a different relying party but listing this provider's audience among
    // several would be accepted (multi-audience token substitution). jose only
    // verifies that *one* of the configured audiences matches, so we enforce azp
    // here. Fail closed. clientId is optional config (id-token-only providers may
    // omit it); when absent we cannot bind azp, so single-aud back-compat applies.
    const audiences = Array.isArray(payload.aud)
        ? payload.aud
        : payload.aud
            ? [payload.aud]
            : [];
    const azp = claimString(payload, "azp");
    const clientId = provider.clientId?.trim() || undefined;
    if (azp !== undefined) {
        if (!clientId || azp !== clientId) {
            throw new Error("OIDC token azp does not match the configured client_id");
        }
    }
    else if (clientId && !audiences.includes(clientId)) {
        throw new Error("OIDC token audience does not include the configured client_id");
    }
    else if (audiences.length > 1) {
        throw new Error("OIDC token with multiple audiences must include an azp claim");
    }
    const subjectClaim = provider.subjectClaim ?? "sub";
    const subject = claimString(payload, subjectClaim);
    if (!subject)
        throw new Error("OIDC token subject is missing");
    return {
        subject,
        claims: payload,
        email: claimString(payload, provider.emailClaim ?? "email"),
        emailVerified: claimBoolean(payload, provider.emailVerifiedClaim ?? "email_verified"),
        name: claimString(payload, provider.nameClaim ?? "name"),
        picture: claimString(payload, provider.pictureClaim ?? "picture"),
    };
}
export function clearOidcJwksCacheForTests() {
    JWKS_CACHE.clear();
}
//# sourceMappingURL=oidc.js.map