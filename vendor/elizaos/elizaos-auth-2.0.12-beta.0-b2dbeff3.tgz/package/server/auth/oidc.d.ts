import { createRemoteJWKSet, type JWTPayload } from "jose";
import type { TenantOidcProviderConfig } from "../shared/index.js";
export interface VerifiedOidcToken {
    subject: string;
    claims: JWTPayload;
    email?: string;
    emailVerified?: boolean;
    name?: string;
    picture?: string;
}
export declare function assertPublicJwksDestination(jwksUri: string): Promise<void>;
/**
 * Builds (or returns a cached) remote JWKS set whose key fetches are routed
 * through the SSRF-guarded {@link fetchPublicJwks} transport. The set is
 * rebuilt once it exceeds the configured maximum age so rotated or emergency-
 * revoked IdP keys stop verifying within the window.
 *
 * Reused by both the tenant OIDC path ({@link verifyOidcJwt}) and the
 * built-in "Sign in with Apple" id_token verifier so there is a single,
 * hardened JWKS transport in the codebase.
 *
 * @param jwksUri  - The IdP JWKS endpoint (must be a public https URL).
 * @param cacheKey - Stable cache key the caller controls (e.g. issuer:jwksUri).
 */
export declare function getPublicRemoteJWKSet(jwksUri: string, cacheKey: string): Promise<ReturnType<typeof createRemoteJWKSet>>;
export declare function verifyOidcJwt(tenantId: string, provider: TenantOidcProviderConfig, token: string): Promise<VerifiedOidcToken>;
export declare function clearOidcJwksCacheForTests(): void;
//# sourceMappingURL=oidc.d.ts.map