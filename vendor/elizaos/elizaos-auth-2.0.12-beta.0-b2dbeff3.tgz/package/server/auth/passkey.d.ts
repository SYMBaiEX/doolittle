/**
 * PasskeyAuth — framework-agnostic WebAuthn passkey registration and authentication.
 *
 * Uses @simplewebauthn/server v13. The caller is responsible for persisting
 * credential data returned from verifyRegistration and for looking up credentials
 * (publicKey, counter) when calling verifyAuthentication.
 *
 * Challenges are stored in an in-memory ChallengeStore with a 5-minute TTL.
 * In production you should swap this for a Redis-backed store.
 *
 * Security defaults (SEC-143):
 *   - `userVerification: "required"` at both ceremonies, matching the
 *     `requireUserVerification: true` checks at verify — authenticators that
 *     cannot perform UV fail at options/ceremony time instead of registering
 *     a credential that can never verify.
 *   - `attestationType: "none"`: attestation is not requested, so hardware-
 *     bound keys cannot be enforced and authenticator supply-chain properties
 *     are not verified. Consumer passkey UX (platform authenticators, synced
 *     credentials) is the target; requiring attestation is a product decision
 *     that would exclude those authenticators.
 */
import type { AuthenticationResponseJSON, AuthenticatorTransport, PublicKeyCredentialCreationOptionsJSON, PublicKeyCredentialRequestOptionsJSON, RegistrationResponseJSON } from "@simplewebauthn/server";
export type { VerifiedAuthenticationResponse, VerifiedRegistrationResponse, } from "@simplewebauthn/server";
export type { AuthenticationResponseJSON, PublicKeyCredentialCreationOptionsJSON, PublicKeyCredentialRequestOptionsJSON, RegistrationResponseJSON, };
import { ChallengeStore } from "./challenge-store.js";
/** Retain the v13 transport contract for stored credentials and existing consumers. */
export type AuthenticatorTransportFuture = AuthenticatorTransport | "cable" | "smart-card";
export interface PasskeyConfig {
    /** Friendly human-readable name shown in browser dialogs, e.g. "Steward" */
    rpName: string;
    /** Effective domain, e.g. "eliza.app" — must match the browser's origin */
    rpID: string;
    /** Full origin URL, e.g. "https://eliza.app" (or array for multi-origin) */
    origin: string | string[];
    /**
     * Optional external challenge store to share across instances or swap out.
     * Defaults to an isolated ChallengeStore per PasskeyAuth instance.
     */
    challengeStore?: ChallengeStore;
}
export interface StoredCredential {
    /** base64url-encoded credential ID */
    credentialId: string;
    /** base64url-encoded COSE public key */
    credentialPublicKey: string;
    /** Monotonically increasing counter — must be persisted to detect cloning */
    counter: number;
}
export declare class PasskeyAuth {
    private readonly config;
    private readonly challenges;
    constructor(config: PasskeyConfig);
    /** Canonical relying-party ID used for every ceremony on this instance. */
    get rpID(): string;
    /**
     * Generate options to pass to the browser's `navigator.credentials.create()`.
     *
     * The generated challenge is stored keyed by `userId`. Callers must later
     * call `verifyRegistration` with the same `userId` within 5 minutes.
     *
     * @param userId         Unique user ID (UUID or similar)
     * @param email          User's email (used as the WebAuthn userName)
     * @param existingCredentials  base64url credential IDs already registered for
     *                       this user — prevents duplicate registrations
     */
    generateRegistrationOptions(userId: string, email: string, existingCredentials?: string[], options?: {
        /**
         * Hint to the browser about which authenticator to prefer.
         *   - "platform":      built-in (Touch ID, Face ID, Windows Hello)
         *   - "cross-platform": roaming (YubiKey, phone-QR, security key)
         *   - undefined:        let the browser pick (shows both)
         *
         * Most consumer apps want "platform" so the OS surfaces native UX.
         */
        authenticatorAttachment?: "platform" | "cross-platform";
    }): Promise<PublicKeyCredentialCreationOptionsJSON>;
    /**
     * Verify the browser's registration response.
     *
     * Consumes (deletes) the stored challenge — each challenge is one-time-use.
     * On success, persist `registrationInfo.credential` to your database.
     *
     * @param userId            Must match the userId used in generateRegistrationOptions
     * @param response          The JSON response from the browser
     * @param expectedChallenge The challenge that was issued (pass in for explicit verification,
     *                          or omit to auto-consume from the internal store)
     */
    verifyRegistration(userId: string, response: RegistrationResponseJSON, expectedChallenge?: string): Promise<any>;
    /**
     * Generate options to pass to the browser's `navigator.credentials.get()`.
     *
     * The generated challenge is stored keyed by `email`. Callers must call
     * `verifyAuthentication` with the same `email` within 5 minutes.
     *
     * @param email   Used purely as the challenge store key — the browser will
     *                present a discoverable-credential picker if no allowCredentials
     *                list is supplied. Pass `allowCredentials` via options if you
     *                have the user's credentials handy.
     * @param options.allowCredentials  Optionally restrict to known credential IDs
     */
    generateAuthenticationOptions(email: string, options?: {
        allowCredentials?: Array<{
            id: string;
            /**
             * Stored transports for this credential. Including these is what
             * tells the browser the credential lives on the local platform
             * authenticator (e.g. Touch ID) vs roaming (e.g. phone via QR). When
             * omitted, browsers conservatively show the QR/cross-device picker
             * even for credentials that were registered on this device.
             */
            transports?: AuthenticatorTransportFuture[];
        }>;
    }): Promise<PublicKeyCredentialRequestOptionsJSON>;
    /**
     * Verify the browser's authentication response.
     *
     * Consumes (deletes) the stored challenge. On success, persist the new counter
     * value returned in `authenticationInfo.newCounter` to prevent replay attacks.
     *
     * @param response              The JSON response from the browser
     * @param expectedChallenge     The challenge that was issued (or omit to auto-consume from store)
     * @param credentialPublicKey   base64url-encoded COSE public key (from your DB)
     * @param counter               Current counter value (from your DB)
     * @param email                 Used to look up the stored challenge when expectedChallenge is omitted
     */
    verifyAuthentication(response: AuthenticationResponseJSON, expectedChallenge: string | undefined, credentialPublicKey: string, counter: number, email?: string): Promise<any>;
}
/**
 * Convert a Uint8Array to a base64url string (for persisting public keys).
 */
export declare function uint8ArrayToBase64url(bytes: Uint8Array): string;
//# sourceMappingURL=passkey.d.ts.map