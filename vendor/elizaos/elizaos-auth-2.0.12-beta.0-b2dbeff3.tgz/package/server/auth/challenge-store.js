/**
 * ChallengeStore — persists WebAuthn challenges with per-entry TTL.
 *
 * Backed by a pluggable StoreBackend (Redis, Postgres, or in-memory).
 * The default (zero-config) backend is MemoryBackend, preserving
 * backward-compatible behavior.
 *
 * Public API is intentionally unchanged so existing call-sites don't need
 * to be updated:  set(), get(), consume(), delete(), destroy(), size.
 *
 * To use a persistent backend, pass it at construction time:
 *
 *   import { RedisBackend } from "./store-backends";
 *   const store = new ChallengeStore({ backend: new RedisBackend(redisClient) });
 */
import { MemoryBackend } from "./store-backends.js";
const CHALLENGE_TTL_MS = 5 * 60 * 1000; // 5 minutes
export class ChallengeStore {
    backend;
    ttlMs;
    constructor(options = {}) {
        // Accept bare number for backward compat: `new ChallengeStore(ttlMs)`
        if (typeof options === "number") {
            this.ttlMs = options;
            this.backend = new MemoryBackend();
        }
        else {
            this.ttlMs = options.ttlMs ?? CHALLENGE_TTL_MS;
            this.backend = options.backend ?? new MemoryBackend();
        }
    }
    /** Store a challenge for a given key (userId or email). Overwrites any existing entry. */
    async set(key, challenge) {
        await this.backend.set(key, challenge, this.ttlMs);
    }
    /** Store a challenge only when the key is currently absent or expired. */
    async setIfNotExists(key, challenge, ttlMs = this.ttlMs) {
        return this.backend.setIfNotExists(key, challenge, ttlMs);
    }
    /**
     * Retrieve and immediately delete a challenge (one-time-use).
     * Returns null if missing or expired.
     *
     * NOTE: Because backends are async, this returns a Promise.
     * Existing code that ignores the return value continues to work.
     * Code that needs the value should await it.
     */
    async consume(key) {
        return this.backend.consume(key);
    }
    /** Peek at a challenge without consuming it. Returns null if missing or expired. */
    async get(key) {
        return this.backend.get(key);
    }
    /** Delete a challenge explicitly and surface backend failures to the caller. */
    async delete(key) {
        await this.backend.delete(key);
    }
    /**
     * Stop background cleanup timers (no-op for Redis/Postgres backends).
     * Useful in tests when using the default MemoryBackend.
     */
    destroy() {
        if (this.backend instanceof MemoryBackend) {
            this.backend.destroy();
        }
    }
    /** Current number of stored entries — only meaningful for MemoryBackend. */
    get size() {
        if (this.backend instanceof MemoryBackend) {
            return this.backend.size;
        }
        return 0;
    }
}
/** Singleton default store using in-memory backend — use this unless you need isolation. */
export const challengeStore = new ChallengeStore();
//# sourceMappingURL=challenge-store.js.map