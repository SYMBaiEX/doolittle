import { type VerifiedOidcToken } from "./oidc.js";
export declare function googleNativeClientIds(clientId: string): string[];
/** Verify an Android Google identity against server-owned OAuth clients. */
export declare function verifyGoogleNativeIdToken(token: string, audience: string, androidClientIds: string[], nonce: string): Promise<VerifiedOidcToken & {
    email: string;
    emailVerified: true;
}>;
//# sourceMappingURL=google-native.d.ts.map