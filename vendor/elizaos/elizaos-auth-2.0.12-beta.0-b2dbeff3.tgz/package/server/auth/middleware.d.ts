/**
 * tenantAuthMiddleware — X-Steward-Tenant + X-Steward-Key authentication.
 *
 * Mount this ONLY on the API router it is meant to protect (e.g. /v1/*),
 * never globally over an app that serves content at `/`: exact GET `/` and
 * GET `/health` requests bypass authentication for liveness probes.
 */
export declare function tenantAuthMiddleware(): any;
//# sourceMappingURL=middleware.d.ts.map