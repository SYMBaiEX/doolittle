/**
 * apple.ts — "Sign in with Apple" id_token verification (OIDC)
 *
 * Apple returns an `id_token` (a JWT) from its token endpoint. There is no
 * userinfo endpoint: the user's identity lives entirely inside the verified
 * id_token. This module verifies that token, failing closed on any check, and
 * normalizes the verified claims into the same profile shape the other OAuth
 * providers produce.
 *
 * Verification (all mandatory, fail-closed):
 *   - Signature against Apple's published JWKS (https://appleid.apple.com/auth/keys),
 *     fetched through the same SSRF-guarded, cached transport as the tenant
 *     OIDC path (see getPublicRemoteJWKSet in oidc.ts).
 *   - iss === https://appleid.apple.com
 *   - aud === the configured Apple client id (the Services ID)
 *   - exp in the future, nbf/iat sane (enforced by jose's jwtVerify)
 *   - nonce, when one was issued for the login request, must match
 *
 * Security notes:
 *   - Never logs the id_token, client secret, or any token material.
 *   - Treats every claim as untrusted; validates types before use.
 *   - Apple's algorithm is ES256; we pin it so an attacker cannot downgrade.
 */
import { type JWTPayload } from "jose";
/** Canonical Apple OIDC issuer. The id_token `iss` MUST equal this exactly. */
export declare const APPLE_ISSUER = "https://appleid.apple.com";
/** Apple's published JWKS endpoint used to verify id_token signatures. */
export declare const APPLE_JWKS_URI = "https://appleid.apple.com/auth/keys";
export interface VerifiedAppleIdToken {
    /** Stable Apple user id (`sub`) → the account's provider-account-id. */
    subject: string;
    /** May be a private-relay (@privaterelay.appleid.com) address; stored as-is. */
    email?: string;
    /** Normalized from Apple's boolean-or-string `email_verified` claim. */
    emailVerified?: boolean;
    /** Whether Apple flagged the email as a private-relay address. */
    isPrivateEmail?: boolean;
    /** Raw verified claims, for callers that need more than the normalized view. */
    claims: JWTPayload;
}
/**
 * Verifies a "Sign in with Apple" id_token and returns the normalized identity.
 *
 * @param idToken  - The raw JWT id_token returned by Apple's token endpoint.
 * @param options.clientId      - Configured Apple Services ID; must equal `aud`.
 * @param options.expectedNonce - When the login request issued a nonce, the
 *                                value that must match the token's `nonce`.
 * @throws Error on any signature/issuer/audience/expiry/nonce failure. Callers
 *         MUST treat a throw as "no identity established".
 */
export declare function verifyAppleIdToken(idToken: string, options: {
    clientId: string;
    expectedNonce?: string;
}): Promise<VerifiedAppleIdToken>;
//# sourceMappingURL=apple.d.ts.map