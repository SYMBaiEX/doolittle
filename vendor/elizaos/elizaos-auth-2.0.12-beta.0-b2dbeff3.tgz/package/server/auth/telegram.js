import { createHash, createHmac, timingSafeEqual } from "node:crypto";
const DEFAULT_MAX_AGE_SEC = 24 * 60 * 60;
const DEFAULT_MAX_FUTURE_SKEW_SEC = 5 * 60;
const TELEGRAM_HASH_RE = /^[0-9a-f]{64}$/i;
function asNonEmptyString(value) {
    if (typeof value === "number" && Number.isFinite(value))
        return String(Math.trunc(value));
    return typeof value === "string" && value.trim().length > 0
        ? value.trim()
        : null;
}
function optionalString(value) {
    return typeof value === "string" && value.trim().length > 0
        ? value.trim()
        : undefined;
}
export function telegramLoginDataCheckString(payload) {
    return Object.entries(payload)
        .filter(([key, value]) => key !== "hash" && value !== undefined && value !== null)
        .map(([key, value]) => [key, String(value)])
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, value]) => `${key}=${value}`)
        .join("\n");
}
export function signTelegramLoginPayload(payload, botToken) {
    const secretKey = createHash("sha256").update(botToken).digest();
    return createHmac("sha256", secretKey)
        .update(telegramLoginDataCheckString(payload))
        .digest("hex");
}
export function verifyTelegramLogin(payload, botToken, options = {}) {
    if (!botToken.trim())
        throw new Error("Telegram bot token is required");
    const id = asNonEmptyString(payload.id);
    if (!id || !/^\d+$/.test(id))
        throw new Error("Telegram id is required");
    const authDateRaw = asNonEmptyString(payload.auth_date);
    const authDate = authDateRaw ? Number(authDateRaw) : NaN;
    if (!Number.isFinite(authDate) || authDate <= 0) {
        throw new Error("Telegram auth_date is required");
    }
    const hash = asNonEmptyString(payload.hash);
    if (!hash || !TELEGRAM_HASH_RE.test(hash))
        throw new Error("Telegram hash is required");
    const expected = signTelegramLoginPayload({ ...payload, hash: undefined }, botToken);
    const providedHash = Buffer.from(hash.toLowerCase(), "hex");
    const expectedHash = Buffer.from(expected, "hex");
    if (providedHash.length !== expectedHash.length ||
        !timingSafeEqual(providedHash, expectedHash)) {
        throw new Error("Telegram login hash mismatch");
    }
    const nowMs = options.nowMs ?? Date.now();
    const maxAgeSec = options.maxAgeSec ?? DEFAULT_MAX_AGE_SEC;
    const nowSec = Math.floor(nowMs / 1000);
    const maxFutureSkewSec = options.maxFutureSkewSec ?? DEFAULT_MAX_FUTURE_SKEW_SEC;
    if (authDate - nowSec > maxFutureSkewSec) {
        throw new Error("Telegram login payload is from the future");
    }
    if (nowSec - authDate > maxAgeSec) {
        throw new Error("Telegram login payload is expired");
    }
    return {
        id,
        firstName: optionalString(payload.first_name),
        lastName: optionalString(payload.last_name),
        username: optionalString(payload.username),
        photoUrl: optionalString(payload.photo_url),
        authDate,
    };
}
//# sourceMappingURL=telegram.js.map