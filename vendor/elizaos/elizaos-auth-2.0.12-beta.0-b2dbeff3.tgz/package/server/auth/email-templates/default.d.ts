/** Renders escaped login email content using the tenant brand or the elizaOS default. */
export interface MagicLinkTemplateData {
    email: string;
    magicLink: string;
    code?: string;
    tenantName?: string;
    expiresInMinutes: number;
}
export interface OtpTemplateData {
    email: string;
    code: string;
    /** Display brand for the sending tenant (e.g. "elizaOS", "Acme"). */
    brandName: string;
    expiresInMinutes: number;
}
export interface RenderedMagicLinkTemplate {
    subject: string;
    text: string;
    html: string;
}
export declare function escapeEmailHtml(value: string): string;
export declare function renderDefaultTemplate({ magicLink, code, tenantName, expiresInMinutes, }: MagicLinkTemplateData): RenderedMagicLinkTemplate;
/**
 * Default (elizaOS-branded) OTP sign-in-code email.
 *
 * OTP emails use the same per-tenant template contract as magic-link emails.
 */
export declare function renderDefaultOtpTemplate({ code, brandName, expiresInMinutes, }: OtpTemplateData): RenderedMagicLinkTemplate;
//# sourceMappingURL=default.d.ts.map