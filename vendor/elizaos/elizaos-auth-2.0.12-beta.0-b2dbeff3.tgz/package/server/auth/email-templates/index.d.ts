import { type MagicLinkTemplateData, type OtpTemplateData, type RenderedMagicLinkTemplate } from "./default.js";
export type { CustomEmailTemplate, TenantEmailTemplates } from "./custom.js";
export { magicLinkTemplateValues, otpTemplateValues, renderCustomTemplate, } from "./custom.js";
export type { MagicLinkTemplateData, OtpTemplateData, RenderedMagicLinkTemplate, } from "./default.js";
export declare function renderTemplate(_templateId: string | undefined, data: MagicLinkTemplateData): RenderedMagicLinkTemplate;
/**
 * Per-tenant OTP (sign-in code) template resolution. Unknown/absent
 * templateIds fall back to the elizaOS-branded default so existing tenants
 * are unaffected.
 */
export declare function renderOtpTemplate(_templateId: string | undefined, data: OtpTemplateData): RenderedMagicLinkTemplate;
//# sourceMappingURL=index.d.ts.map