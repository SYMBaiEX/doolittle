import { renderDefaultOtpTemplate, renderDefaultTemplate, } from "./default.js";
export { magicLinkTemplateValues, otpTemplateValues, renderCustomTemplate, } from "./custom.js";
export function renderTemplate(_templateId, data) {
    return renderDefaultTemplate(data);
}
/**
 * Per-tenant OTP (sign-in code) template resolution. Unknown/absent
 * templateIds fall back to the elizaOS-branded default so existing tenants
 * are unaffected.
 */
export function renderOtpTemplate(_templateId, data) {
    return renderDefaultOtpTemplate(data);
}
//# sourceMappingURL=index.js.map