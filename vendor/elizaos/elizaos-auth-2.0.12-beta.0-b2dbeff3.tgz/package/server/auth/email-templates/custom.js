import { escapeEmailHtml } from "./default.js";
function substitute(template, values, escapeHtml) {
    return template.replace(/\{\{\s*(\w+)\s*\}\}/g, (match, key) => {
        const value = values[key];
        if (value === undefined)
            return match;
        return escapeHtml ? escapeEmailHtml(value) : value;
    });
}
export function renderCustomTemplate(template, values) {
    return {
        subject: substitute(template.subject, values, false),
        text: substitute(template.text, values, false),
        html: substitute(template.html, values, true),
    };
}
export function magicLinkTemplateValues(data) {
    return {
        magicLink: data.magicLink,
        code: data.code ?? "",
        email: data.email,
        tenantName: data.tenantName ?? "",
        expiresInMinutes: String(data.expiresInMinutes),
    };
}
export function otpTemplateValues(data) {
    return {
        code: data.code,
        email: data.email,
        brandName: data.brandName,
        expiresInMinutes: String(data.expiresInMinutes),
    };
}
//# sourceMappingURL=custom.js.map