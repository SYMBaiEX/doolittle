/**
 * SIWE-guard — defensive validators that go beyond bare `siwe` library checks.
 *
 * The base `siwe` package verifies the signature and the canonical message
 * format. It does NOT check:
 *   1. whether the `domain` field is one your server actually serves,
 *   2. whether `chainId` is in your allowed set,
 *   3. whether the `notBefore` / `expirationTime` window is sane (a
 *      pathologically long-lived signature is technically valid; a missing
 *      expirationTime falls back to bounding the message's issuedAt age, and
 *      a future-dated issuedAt is rejected),
 *   4. whether the `statement` matches a server-side allowlist (defends
 *      against phishing sites tricking users into signing your messages),
 *   5. whether `uri` matches `domain` (some wallets fail to enforce this).
 *
 * This module supplies all five as a single `evaluateSiwePolicy` call that
 * inspects an already-parsed SIWE message and returns the first violation
 * it finds, or `null` for "passes policy." It does NOT verify the signature
 * itself — that remains the responsibility of the calling auth route.
 */
export interface SiweMessageLike {
    domain: string;
    address: string;
    statement?: string;
    uri: string;
    version: string;
    chainId: number;
    nonce: string;
    issuedAt: string;
    expirationTime?: string;
    notBefore?: string;
}
export interface SiwePolicy {
    /** Exact-match allowlist of acceptable `domain` values. Required. */
    allowedDomains: readonly string[];
    /** Allowed chainIds. Empty array allows none; omit to allow any. */
    allowedChainIds?: readonly number[];
    /** Required exact-match `statement`. Set to skip statement check. */
    requiredStatement?: string;
    /** Maximum lifetime (issuedAt → expirationTime), in milliseconds. Default 10 minutes. */
    maxLifetimeMs?: number;
    /** Maximum clock skew tolerated for notBefore/issuedAt, in ms. Default 30s. */
    clockSkewMs?: number;
    /** Override clock for tests. */
    now?: () => Date;
}
export type SiweViolation = "domain-not-allowed" | "chain-not-allowed" | "statement-mismatch" | "uri-domain-mismatch" | "version-unsupported" | "expired" | "not-yet-valid" | "lifetime-too-long" | "missing-nonce";
export declare function evaluateSiwePolicy(msg: SiweMessageLike, policy: SiwePolicy): SiweViolation | null;
//# sourceMappingURL=siwe-guard.d.ts.map