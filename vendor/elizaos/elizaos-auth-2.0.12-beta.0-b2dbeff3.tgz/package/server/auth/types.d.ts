import type { Tenant } from "../db/index.js";
export interface AuthContext {
    tenantId: string;
    tenant: Tenant;
}
export interface ApiKeyPair {
    key: string;
    hash: string;
}
export type AuthVariables = AuthContext;
//# sourceMappingURL=types.d.ts.map