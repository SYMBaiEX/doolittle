/**
 * ChallengeStore — persists WebAuthn challenges with per-entry TTL.
 *
 * Backed by a pluggable StoreBackend (Redis, Postgres, or in-memory).
 * The default (zero-config) backend is MemoryBackend, preserving
 * backward-compatible behavior.
 *
 * Public API is intentionally unchanged so existing call-sites don't need
 * to be updated:  set(), get(), consume(), delete(), destroy(), size.
 *
 * To use a persistent backend, pass it at construction time:
 *
 *   import { RedisBackend } from "./store-backends";
 *   const store = new ChallengeStore({ backend: new RedisBackend(redisClient) });
 */
import type { StoreBackend } from "./store-backends.js";
export interface ChallengeStoreOptions {
    /** Override the default in-memory backend with a persistent implementation. */
    backend?: StoreBackend;
    /** Custom TTL in milliseconds for each challenge. Default: 5 minutes. */
    ttlMs?: number;
}
export declare class ChallengeStore {
    private readonly backend;
    private readonly ttlMs;
    constructor(options?: ChallengeStoreOptions | number);
    /** Store a challenge for a given key (userId or email). Overwrites any existing entry. */
    set(key: string, challenge: string): Promise<void>;
    /** Store a challenge only when the key is currently absent or expired. */
    setIfNotExists(key: string, challenge: string, ttlMs?: number): Promise<boolean>;
    /**
     * Retrieve and immediately delete a challenge (one-time-use).
     * Returns null if missing or expired.
     *
     * NOTE: Because backends are async, this returns a Promise.
     * Existing code that ignores the return value continues to work.
     * Code that needs the value should await it.
     */
    consume(key: string): Promise<string | null>;
    /** Peek at a challenge without consuming it. Returns null if missing or expired. */
    get(key: string): Promise<string | null>;
    /** Delete a challenge explicitly and surface backend failures to the caller. */
    delete(key: string): Promise<void>;
    /**
     * Stop background cleanup timers (no-op for Redis/Postgres backends).
     * Useful in tests when using the default MemoryBackend.
     */
    destroy(): void;
    /** Current number of stored entries — only meaningful for MemoryBackend. */
    get size(): number;
}
/** Singleton default store using in-memory backend — use this unless you need isolation. */
export declare const challengeStore: ChallengeStore;
//# sourceMappingURL=challenge-store.d.ts.map