export declare function checkDatabaseAuthRateLimit(key: string, windowMs: number, maximum: number): Promise<{
    allowed: boolean;
    retryAfterSecs: number;
}>;
//# sourceMappingURL=database-rate-limit.d.ts.map