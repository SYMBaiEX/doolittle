import { randomUUID } from "node:crypto";
import { logger } from "@elizaos/core";
import { Resend } from "resend";
/**
 * Typed failure raised when a provider rejects a send (or returns no
 * acceptance receipt). The message is deliberately generic — never the
 * recipient, token, code, or raw provider error text — so it can be logged
 * and surfaced without leaking secrets. The API layer maps this to 502.
 */
export class EmailDeliveryError extends Error {
    constructor(message = "Email delivery failed") {
        super(message);
        this.name = "EmailDeliveryError";
    }
}
/**
 * Typed failure raised when no delivery-capable email provider is configured
 * (e.g. the ConsoleProvider fallback in production). Raised BEFORE any
 * challenge state is created so a misconfigured deployment can never issue
 * an unredeemable-by-email challenge. The API layer maps this to 503.
 */
export class EmailDeliveryNotConfiguredError extends Error {
    constructor(message = "Email delivery is not configured") {
        super(message);
        this.name = "EmailDeliveryNotConfiguredError";
    }
}
export class ResendProvider {
    client;
    from;
    replyTo;
    constructor(config) {
        this.client = new Resend(config.apiKey);
        this.from = config.from;
        this.replyTo = config.replyTo;
    }
    async send(to, subject, text, html, options) {
        const { data, error } = await this.client.emails.send({
            from: this.from,
            to,
            subject,
            text,
            ...(options?.replyTo || this.replyTo
                ? { replyTo: options?.replyTo || this.replyTo }
                : {}),
            ...(html ? { html } : {}),
        });
        if (error) {
            throw new Error(`Resend error: ${error.message}`);
        }
        if (!data || typeof data.id !== "string" || data.id.trim().length === 0) {
            throw new Error("Resend returned no delivery acceptance id");
        }
        return { provider: "resend", id: data.id };
    }
}
// ---------------------------------------------------------------------------
// ConsoleProvider — redacted development delivery receipt (never logs credentials)
// ---------------------------------------------------------------------------
export class ConsoleProvider {
    async send(_to, _subject, _text, _html, _options) {
        logger.info({
            details: [
                [
                    "─────────────────────────────────────────",
                    `[ConsoleProvider] Magic link email`,
                    `To:      [redacted]`,
                    "",
                    "─────────────────────────────────────────",
                ].join("\n"),
            ],
        }, "[Login:email-provider] info");
        return { provider: "console" };
    }
}
function parseMagicLink(text) {
    let segmentStart = 0;
    while (segmentStart < text.length) {
        while (segmentStart < text.length && text[segmentStart].trim().length === 0)
            segmentStart += 1;
        let segmentEnd = segmentStart;
        while (segmentEnd < text.length && text[segmentEnd].trim().length !== 0)
            segmentEnd += 1;
        if (segmentEnd === segmentStart)
            break;
        let schemeStart = -1;
        for (let index = segmentStart; index < segmentEnd; index += 1) {
            if (text.startsWith("http://", index) ||
                text.startsWith("https://", index)) {
                schemeStart = index;
                break;
            }
        }
        if (schemeStart !== -1) {
            let tokenStart = -1;
            let tokenEnd = -1;
            for (let index = schemeStart; index < segmentEnd; index += 1) {
                if (text.startsWith("?token=", index) ||
                    text.startsWith("&token=", index)) {
                    const candidate = index + 7;
                    const code = text.charCodeAt(candidate);
                    if ((code >= 0x30 && code <= 0x39) ||
                        (code >= 0x41 && code <= 0x5a) ||
                        (code >= 0x61 && code <= 0x7a) ||
                        code === 0x2d ||
                        code === 0x5f) {
                        let candidateEnd = candidate;
                        while (candidateEnd < segmentEnd) {
                            const tokenCode = text.charCodeAt(candidateEnd);
                            if ((tokenCode >= 0x30 && tokenCode <= 0x39) ||
                                (tokenCode >= 0x41 && tokenCode <= 0x5a) ||
                                (tokenCode >= 0x61 && tokenCode <= 0x7a) ||
                                tokenCode === 0x2d ||
                                tokenCode === 0x5f) {
                                candidateEnd += 1;
                            }
                            else {
                                break;
                            }
                        }
                        tokenStart = candidate;
                        tokenEnd = candidateEnd;
                    }
                }
            }
            if (tokenStart !== -1) {
                return {
                    magicLink: text.slice(schemeStart, tokenEnd),
                    token: text.slice(tokenStart, tokenEnd),
                };
            }
        }
        segmentStart = segmentEnd + 1;
    }
    return {};
}
class MockEmailInboxRegistry {
    byEmail = new Map();
    push(msg) {
        const key = msg.to.toLowerCase();
        const existing = this.byEmail.get(key) ?? [];
        existing.push(msg);
        this.byEmail.set(key, existing);
    }
    last(email) {
        const list = this.byEmail.get(email.toLowerCase());
        return list?.[list.length - 1];
    }
    all(email) {
        return [...(this.byEmail.get(email.toLowerCase()) ?? [])];
    }
    clear(email) {
        if (email)
            this.byEmail.delete(email.toLowerCase());
        else
            this.byEmail.clear();
    }
}
export const MockEmailInbox = new MockEmailInboxRegistry();
export class MockEmailProvider {
    async send(to, subject, text, html, options) {
        MockEmailInbox.push({
            to,
            subject,
            text,
            ...(html ? { html } : {}),
            ...(options?.replyTo ? { replyTo: options.replyTo } : {}),
            sentAt: new Date(),
            ...parseMagicLink(text),
        });
        return { provider: "mock", id: randomUUID() };
    }
}
//# sourceMappingURL=email-provider.js.map