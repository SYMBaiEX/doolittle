/** Persists logout and monotonic account revocation in the identity database across restarts. */
import { ElizaError } from "@elizaos/core";
import { createDatabaseAuthSql, createTransactionAuthSql } from "./auth-sql.js";
const DEFAULT_REVOCATION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
function expiry(value) {
    const milliseconds = value instanceof Date
        ? value.getTime()
        : value > 10_000_000_000
            ? value
            : value * 1000;
    return new Date(milliseconds).toISOString();
}
function issuedBefore(value) {
    const result = Number(value);
    if (!Number.isSafeInteger(result) || result < 0) {
        throw new ElizaError("Stored revocation timestamp is invalid", {
            code: "LOGIN_REVOCATION_INVALID",
        });
    }
    return result;
}
export class DatabaseRevocationStore {
    sql = createDatabaseAuthSql();
    async revokeToken(jti, expiresAt) {
        await this.sql `
      INSERT INTO auth_kv_store (id, namespace, value, expires_at)
      VALUES (${jti}, 'revocation:jti', 'revoked', ${expiry(expiresAt)})
      ON CONFLICT (id, namespace) DO UPDATE
      SET expires_at = GREATEST(auth_kv_store.expires_at, EXCLUDED.expires_at)
    `;
    }
    async isRevoked(jti) {
        const rows = await this.sql `
      SELECT id FROM auth_kv_store WHERE id = ${jti}
        AND namespace = 'revocation:jti' AND expires_at > clock_timestamp()
    `;
        return rows.length > 0;
    }
    async revokeLine(namespace, id, timestamp, expiresAt, transaction) {
        issuedBefore(String(timestamp));
        // The embedded database has one connection. A statement issued beside the
        // caller's open transaction would queue behind it and never run.
        const sql = transaction ? createTransactionAuthSql(transaction) : this.sql;
        const [row] = await sql `
      INSERT INTO auth_kv_store (id, namespace, value, expires_at)
      VALUES (${id}, ${namespace}, ${String(timestamp)}, ${expiry(expiresAt)})
      ON CONFLICT (id, namespace) DO UPDATE SET
        value = CASE WHEN auth_kv_store.expires_at > clock_timestamp()
          THEN GREATEST(auth_kv_store.value::bigint, EXCLUDED.value::bigint)::text
          ELSE EXCLUDED.value END,
        expires_at = GREATEST(auth_kv_store.expires_at, EXCLUDED.expires_at)
      RETURNING value
    `;
        return issuedBefore(row.value);
    }
    async readLine(namespace, id) {
        const [row] = await this.sql `
      SELECT value FROM auth_kv_store WHERE id = ${id}
        AND namespace = ${namespace} AND expires_at > clock_timestamp()
    `;
        return row ? issuedBefore(row.value) : null;
    }
    revokeAgentTokens(agentId, timestamp = Math.floor(Date.now() / 1000), expiresAt = Date.now() + DEFAULT_REVOCATION_TTL_MS) {
        return this.revokeLine("revocation:agent", agentId, timestamp, expiresAt);
    }
    getAgentRevokedBefore(agentId) {
        return this.readLine("revocation:agent", agentId);
    }
    revokeUserTokens(userId, timestamp = Math.floor(Date.now() / 1000), expiresAt = Date.now() + DEFAULT_REVOCATION_TTL_MS, transaction) {
        return this.revokeLine("revocation:user", userId, timestamp, expiresAt, transaction);
    }
    getUserRevokedBefore(userId) {
        return this.readLine("revocation:user", userId);
    }
}
//# sourceMappingURL=database-revocation.js.map