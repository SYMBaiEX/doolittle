export interface FarcasterLoginPayload {
    message?: unknown;
    signature?: unknown;
    custodyAddress?: unknown;
    address?: unknown;
    fid?: unknown;
    username?: unknown;
    displayName?: unknown;
    pfpUrl?: unknown;
    pfp?: unknown;
}
export interface ParsedSiwfMessage {
    domain: string;
    address: `0x${string}`;
    statement?: string;
    uri: string;
    version: string;
    chainId?: number;
    nonce: string;
    issuedAt: string;
    expirationTime?: string;
    notBefore?: string;
    requestId?: string;
    resources: string[];
    /** fid claimed by the message's farcaster:// resource — self-signed, NOT
     * verified against a hub/IdRegistry (SEC-058). Unverified metadata only. */
    fid?: string;
}
export interface VerifiedFarcasterUser {
    /**
     * The fid CLAIMED by the self-signed SIWF message's `farcaster://fid/N`
     * resource. NOT cryptographically bound to the signer (SEC-058): anyone can
     * place any fid in their own signed message, so this is unverified metadata.
     * Never key identity or authorization decisions on it — use
     * `custodyAddress`, which IS signature-verified. A verified fid would
     * require checking the fid→custody-address binding against a Farcaster
     * hub / the IdRegistry contract.
     */
    claimedFid: string;
    custodyAddress: `0x${string}`;
    username?: string;
    displayName?: string;
    pfpUrl?: string;
    message: ParsedSiwfMessage;
}
export interface VerifyFarcasterLoginOptions {
    expectedDomain?: string | string[];
    expectedNonce?: string;
    expectedUri?: string;
    nowMs?: number;
    clockSkewMs?: number;
    maxMessageAgeMs?: number;
    /** Require a fid CLAIM to be present in the signed message (default true).
     * Note the claim is unverified metadata — see VerifiedFarcasterUser.claimedFid. */
    requireFid?: boolean;
}
export declare function parseSiwfMessage(message: string): ParsedSiwfMessage;
export declare function validateSiwfMessage(parsed: ParsedSiwfMessage, options?: VerifyFarcasterLoginOptions): void;
export declare function verifyFarcasterLogin(payload: FarcasterLoginPayload, options?: VerifyFarcasterLoginOptions): Promise<VerifiedFarcasterUser>;
//# sourceMappingURL=farcaster.d.ts.map