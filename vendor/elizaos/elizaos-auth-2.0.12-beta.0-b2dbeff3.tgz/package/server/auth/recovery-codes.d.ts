/**
 * Recovery codes — single-use backup codes for account recovery.
 *
 * When a user enables passkey/2FA, we issue a small batch (default 10) of
 * recovery codes. Each is a 14-character base32 string (Crockford alphabet,
 * I/L/O removed to avoid 1/0 confusion); legacy 10-character codes issued
 * before the length bump still verify. The plaintext is shown to the user
 * exactly once; the server stores only a salted hash. Verification compares
 * by hash (constant-time) and marks the code as used so it cannot be
 * replayed.
 *
 * Codes are formatted in groups of 5 ("ABCDE-FGHJK") for human readability
 * but stored without the separator. Verification is tolerant of casing and
 * separator placement so users typing them back work without UX rough edges.
 *
 * This module is storage-agnostic — callers supply a RecoveryCodeStore
 * (typically backed by a `user_recovery_codes` table) that persists hashes
 * and tracks which have been consumed.
 */
export interface StoredRecoveryCode {
    /** Opaque id assigned by the persistence layer (DB row PK, etc). */
    id: string;
    /** SHA-256 hex of the salt+normalized code. */
    hash: string;
    /** Per-code salt, hex. */
    salt: string;
    /** Set when the code is redeemed; non-null = unusable. */
    usedAt: Date | null;
}
export interface RecoveryCodeStore {
    /** Persist a fresh batch of codes for a user, replacing any prior codes. */
    replaceForUser(userId: string, codes: Array<{
        hash: string;
        salt: string;
    }>): Promise<void>;
    /** List all stored (active + used) codes for a user. */
    listForUser(userId: string): Promise<StoredRecoveryCode[]>;
    /** Mark a single code as consumed. Returns false when it was already used or missing. */
    markUsed(id: string, usedAt: Date): Promise<boolean>;
}
/** Pretty-print a raw code as "ABCDE-FGHJK" without changing its identity. */
export declare function formatRecoveryCode(raw: string): string;
/** Strip whitespace + separators and uppercase; rejects anything outside the alphabet. */
export declare function normalize(input: string): string;
/**
 * Generate `count` recovery codes for a user, persist their hashes, and
 * return the plaintext codes. The caller is responsible for displaying them
 * exactly once and warning the user that they will not be shown again.
 */
export declare function generateRecoveryCodes(store: RecoveryCodeStore, userId: string, count?: number): Promise<string[]>;
/**
 * Verify a user-supplied recovery code. On success the code is marked used
 * and `{ valid: true }` is returned. On failure (unknown code, already used,
 * malformed input) `{ valid: false }` is returned without leaking which
 * branch failed — callers should treat all failures identically.
 */
export declare function verifyRecoveryCode(store: RecoveryCodeStore, userId: string, supplied: string): Promise<{
    valid: boolean;
}>;
/** Count of unused codes for a user, for surfacing "you have N left" in the UI. */
export declare function unusedRecoveryCodeCount(store: RecoveryCodeStore, userId: string): Promise<number>;
/**
 * Minimal in-memory RecoveryCodeStore — for tests and dev. NOT suitable for
 * production: codes vanish on restart and there is no cross-instance sharing.
 */
export declare class InMemoryRecoveryCodeStore implements RecoveryCodeStore {
    private byUser;
    private nextId;
    replaceForUser(userId: string, codes: Array<{
        hash: string;
        salt: string;
    }>): Promise<void>;
    listForUser(userId: string): Promise<StoredRecoveryCode[]>;
    markUsed(id: string, usedAt: Date): Promise<boolean>;
}
//# sourceMappingURL=recovery-codes.d.ts.map