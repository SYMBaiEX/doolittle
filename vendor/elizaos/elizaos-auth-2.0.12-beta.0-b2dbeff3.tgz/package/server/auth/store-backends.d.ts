/**
 * Pluggable backend implementations for ChallengeStore and TokenStore.
 *
 * All backends implement StoreBackend: a simple async key-value interface
 * with per-entry TTL semantics.
 *
 * Hierarchy (best → fallback):
 *   Redis  →  Postgres  →  Memory
 *
 * The caller (typically packages/auth/src/server/api/services/auth-lifecycle.ts) picks the best
 * available backend and passes it to ChallengeStore / TokenStore via their
 * constructors.  Neither store cares which backend it uses.
 */
import { getSql } from "../db/index.js";
import { createDatabaseAuthSql } from "./auth-sql.js";
export interface StorePublishEntry {
    key: string;
    /** A null value deletes the key as part of the atomic publication. */
    value: string | null;
    /** Absolute Unix epoch deadline. A value is not published after this deadline. */
    expiresAt: number;
    /**
     * Optional compare-and-publish guard. Null means the key must be absent or
     * expired. If every guard already contains its desired value, publication
     * succeeds as a no-op so a lost-ack retry cannot recreate consumed entries.
     * Otherwise every guard must still contain its expected value.
     */
    expected?: string | null;
}
export interface StoreBackend {
    set(key: string, value: string, ttlMs: number): Promise<void>;
    setIfNotExists(key: string, value: string, ttlMs: number): Promise<boolean>;
    get(key: string): Promise<string | null>;
    consume(key: string): Promise<string | null>;
    /** Atomically delete only a live entry whose value exactly matches expected. */
    compareDelete(key: string, expected: string): Promise<boolean>;
    /** Atomically replace an exact value. Repeating an already-applied transition succeeds. */
    transition(key: string, expected: string, desired: string, ttlMs: number, guard?: {
        key: string;
        expected: string;
    }): Promise<boolean>;
    /** Atomically apply every entry, or none; returns false after any value deadline. */
    publish(entries: readonly StorePublishEntry[]): Promise<boolean>;
    delete(key: string): Promise<void>;
}
/**
 * Adds a collision-safe logical namespace to every key sent to a shared
 * backend. This lets related stores share one durable backend selection while
 * preserving independent key spaces and atomic backend operations.
 */
export declare class NamespacedStoreBackend implements StoreBackend {
    private readonly backend;
    private readonly keyPrefix;
    constructor(backend: StoreBackend, namespace: string);
    private key;
    set(key: string, value: string, ttlMs: number): Promise<void>;
    setIfNotExists(key: string, value: string, ttlMs: number): Promise<boolean>;
    get(key: string): Promise<string | null>;
    consume(key: string): Promise<string | null>;
    compareDelete(key: string, expected: string): Promise<boolean>;
    transition(key: string, expected: string, desired: string, ttlMs: number, guard?: {
        key: string;
        expected: string;
    }): Promise<boolean>;
    publish(entries: readonly StorePublishEntry[]): Promise<boolean>;
    delete(key: string): Promise<void>;
}
export declare class MemoryBackend implements StoreBackend {
    private readonly store;
    private readonly cleanupTimer?;
    constructor(cleanupIntervalMs?: number);
    set(key: string, value: string, ttlMs: number): Promise<void>;
    setIfNotExists(key: string, value: string, ttlMs: number): Promise<boolean>;
    get(key: string): Promise<string | null>;
    consume(key: string): Promise<string | null>;
    compareDelete(key: string, expected: string): Promise<boolean>;
    transition(key: string, expected: string, desired: string, ttlMs: number, guard?: {
        key: string;
        expected: string;
    }): Promise<boolean>;
    publish(entries: readonly StorePublishEntry[]): Promise<boolean>;
    delete(key: string): Promise<void>;
    private _cleanup;
    destroy(): void;
    get size(): number;
}
/**
 * Minimal duck-typed Redis interface — any ioredis.Redis instance satisfies this.
 * The store contract depends only on the Redis operations it uses.
 */
export interface RedisLike {
    set(key: string, value: string, expiryMode: "PX", time: number, condition?: "NX"): Promise<string | null>;
    get(key: string): Promise<string | null>;
    getdel?(key: string): Promise<string | null>;
    del(...keys: string[]): Promise<number>;
    eval(script: string, numberOfKeys: number, ...args: Array<string | number>): Promise<unknown>;
}
/**
 * Redis-backed store backend.
 * Uses atomic SET key value PX ttlMs for writes; native TTL handles expiry.
 *
 * Pass a connected ioredis client (e.g. from packages/redis `getRedis()`).
 */
export declare class RedisBackend implements StoreBackend {
    private readonly client;
    private readonly prefix;
    constructor(client: RedisLike, prefix?: string);
    set(key: string, value: string, ttlMs: number): Promise<void>;
    setIfNotExists(key: string, value: string, ttlMs: number): Promise<boolean>;
    get(key: string): Promise<string | null>;
    consume(key: string): Promise<string | null>;
    compareDelete(key: string, expected: string): Promise<boolean>;
    transition(key: string, expected: string, desired: string, ttlMs: number, guard?: {
        key: string;
        expected: string;
    }): Promise<boolean>;
    publish(entries: readonly StorePublishEntry[]): Promise<boolean>;
    delete(key: string): Promise<void>;
}
/** Binds durable auth state to the database owned by the embedded server. */
export declare function setEmbeddedAuthDatabase(enabled: boolean): void;
export declare class PostgresBackend implements StoreBackend {
    private readonly namespace;
    private readonly sqlClient?;
    private initialized;
    /**
     * @param namespace  Logical partition (e.g. "challenge", "token") so multiple
     *                   stores can share the same table without key collision.
     */
    constructor(namespace: string, sqlClient?: (ReturnType<typeof getSql> | ReturnType<typeof createDatabaseAuthSql>) | undefined);
    private getSqlClient;
    private ensureTable;
    set(key: string, value: string, ttlMs: number): Promise<void>;
    setIfNotExists(key: string, value: string, ttlMs: number): Promise<boolean>;
    get(key: string): Promise<string | null>;
    consume(key: string): Promise<string | null>;
    compareDelete(key: string, expected: string): Promise<boolean>;
    transition(key: string, expected: string, desired: string, ttlMs: number, guard?: {
        key: string;
        expected: string;
    }): Promise<boolean>;
    publish(entries: readonly StorePublishEntry[]): Promise<boolean>;
    delete(key: string): Promise<void>;
}
/**
 * Build the best available backend for a given namespace.
 *
 * Priority: Redis > Postgres > Memory
 *
 * Intended to be called once at startup from API route setup code.
 * Errors are caught and logged; the function always returns a usable backend.
 *
 * @param namespace   Logical key namespace (e.g. "challenge" or "token")
 * @param redisClient An ioredis client if Redis is available, or null/undefined
 * @param usePostgres Whether the Postgres DB is considered available
 */
export declare function buildBackend(namespace: string, redisClient: RedisLike | null | undefined, usePostgres: boolean): Promise<{
    backend: StoreBackend;
    source: "redis" | "postgres" | "pglite" | "memory";
}>;
//# sourceMappingURL=store-backends.d.ts.map