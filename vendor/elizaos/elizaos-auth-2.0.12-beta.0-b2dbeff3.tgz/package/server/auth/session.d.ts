/**
 * SessionManager — JWT-based session creation and verification using jose.
 *
 * jose is a root-level dependency (package.json: "jose": "^6.2.1") so it is
 * available to all packages via the monorepo workspace.
 */
import type { JWTPayload } from "jose";
import { TokenRevokedError } from "./revocation.js";
export interface SessionConfig {
    /** JWT signing secret — at least 32 random bytes recommended. Defaults to STEWARD_JWT_SECRET. */
    secret?: string;
    /** JWT issuer claim. Defaults to "steward" */
    issuer?: string;
    /**
     * Token lifetime expressed as a relative time string understood by jose,
     * e.g. "7d", "24h", "30m". Defaults to "7d".
     */
    expiresIn?: string;
}
export interface SessionPayload extends JWTPayload {
    userId: string;
    jti: string;
    [key: string]: unknown;
}
export declare class SessionManager {
    private readonly secret;
    private readonly issuer;
    private readonly expiresIn;
    constructor(config: SessionConfig);
    /**
     * Create a signed JWT for a user session. signJwtPayload guarantees a jti
     * claim, so every session token can be individually revoked.
     *
     * @param userId  The user's UUID or identifier — included as a top-level claim
     * @param extra   Optional additional claims to embed in the token. Spread
     *                BEFORE the authenticated identity and stripped of any jti
     *                or subject, so request-derived claims can never override
     *                the user or pre-select a session jti (SEC-134).
     * @returns       A compact JWT string suitable for use as a session token
     */
    createSession(userId: string, extra?: Record<string, unknown>): Promise<string>;
    /**
     * Verify and decode a session JWT.
     *
     * Returns the payload (including `userId`) on success, or `null` if the
     * token is invalid, expired, or has been tampered with. Throws
     * TokenRevokedError if the token's jti has been revoked.
     *
     * @param token  The compact JWT string
     */
    verifySession(token: string): Promise<SessionPayload | null>;
    /**
     * Invalidate a session token by adding its JTI to the revocation store until
     * the token's natural expiry. Redis shares this across instances; without
     * REDIS_URL the store is in-memory for single-instance/embedded mode.
     *
     * @param token  The token to invalidate
     */
    invalidateSession(token: string): Promise<void>;
}
export { TokenRevokedError };
//# sourceMappingURL=session.d.ts.map