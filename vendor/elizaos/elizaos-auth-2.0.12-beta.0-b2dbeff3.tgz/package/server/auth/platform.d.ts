import type { MiddlewareHandler } from "hono";
/**
 * Validate a supplied key against the list of allowed platform keys.
 *
 * Iterates ALL valid keys without short-circuiting to avoid timing oracles
 * that could reveal how many keys are configured or their ordering.
 */
export declare function isValidPlatformKey(key: string): boolean;
/**
 * Resolve the scopes configured for a platform key. Keys absent from
 * STEWARD_PLATFORM_KEY_SCOPES receive [] — deny-by-default under every
 * hasPlatformScope check (SEC-138).
 */
export declare function getPlatformKeyScopes(key: string): string[];
export declare function hasPlatformScope(scopes: readonly string[] | undefined, required: string): boolean;
/**
 * Hono middleware that enforces platform key authentication.
 * Mount this on any route group that requires platform-level access.
 *
 * IMPORTANT (SEC-138): this middleware AUTHENTICATES only — it does not
 * authorize. Every route mounted behind it must additionally gate on
 * `hasPlatformScope(c.get("platformScopes"), ...)`. A route that mounts only
 * this middleware grants full platform access to every valid key, including
 * keys with no configured scopes.
 *
 * @example
 * ```ts
 * const platform = new Hono();
 * platform.use("*", platformAuthMiddleware());
 * platform.get("/stats", (c) => {
 *   if (!hasPlatformScope(c.get("platformScopes"), "platform:read")) {
 *     return c.json({ ok: false, error: "Forbidden" }, 403);
 *   }
 *   // ...
 * });
 * ```
 */
export declare function platformAuthMiddleware(): MiddlewareHandler;
//# sourceMappingURL=platform.d.ts.map