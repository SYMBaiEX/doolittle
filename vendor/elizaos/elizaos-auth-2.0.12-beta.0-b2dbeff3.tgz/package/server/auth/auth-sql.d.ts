import { getDb, type getSql } from "../db/client.js";
export declare function createPostgresAuthSql(client: ReturnType<typeof getSql>): ReturnType<typeof createDatabaseAuthSql>;
/** Auth-store SQL that runs on one open transaction instead of a new connection checkout. */
export declare function createTransactionAuthSql(transaction: Pick<ReturnType<typeof getDb>, "execute">): <Rows extends Record<string, unknown>[]>(strings: TemplateStringsArray, ...values: (string | number | boolean | null)[]) => Promise<Rows[number][]>;
export declare function createDatabaseAuthSql(): (<Rows extends Record<string, unknown>[]>(strings: TemplateStringsArray, ...values: (string | number | boolean | null)[]) => Promise<Rows[number][]>) & {
    begin: {
        (callback: (transaction: <Rows extends Record<string, unknown>[]>(strings: TemplateStringsArray, ...values: (string | number | boolean | null)[]) => Promise<Rows[number][]>) => Promise<void>): Promise<void>;
        (options: "isolation level serializable", callback: (transaction: <Rows extends Record<string, unknown>[]>(strings: TemplateStringsArray, ...values: (string | number | boolean | null)[]) => Promise<Rows[number][]>) => Promise<void>): Promise<void>;
    };
};
//# sourceMappingURL=auth-sql.d.ts.map