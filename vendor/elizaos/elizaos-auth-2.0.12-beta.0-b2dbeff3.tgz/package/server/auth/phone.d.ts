/**
 * PhoneAuth — SMS OTP login.
 *
 * 6-digit numeric code, persisted as hash-of-(phone||code) so a leaked code
 * cannot be replayed against a different phone number. One-time consume,
 * 5-minute TTL by default.
 *
 * Caller responsibilities at the API layer:
 *  - Rate-limit /sendOtp per phone number and per IP.
 *  - Track failed verifyOtp attempts and lock out after N (e.g. 5).
 */
import { type ManagedOtpDeliveryChannel, type ManagedSmsOtpProvider, type SmsProvider } from "./sms-provider.js";
import { TokenStore } from "./token-store.js";
export interface PhoneAuthConfig {
    provider?: SmsProvider;
    /** Provider-managed code generation and verification (for example Twilio Verify). */
    managedProvider?: ManagedSmsOtpProvider;
    /** Local OTP TTL. Managed challenges never expire before their provider. */
    tokenTtlMs?: number;
    tokenStore?: TokenStore;
    bodyTemplate?: string;
    /**
     * Runs before any provider call on every send. Throw to refuse the send
     * (destination policy, deployment-wide budget). Never sees the code.
     */
    sendGuard?: (phone: string) => Promise<void>;
}
/** A different auth flow already owns the active managed OTP for this phone. */
export declare class SmsChallengeInProgressError extends Error {
    constructor();
}
export declare function isValidE164(phone: unknown): phone is string;
export declare class PhoneAuth {
    private provider?;
    private managedProvider?;
    private tokenStore;
    private tokenTtlMs;
    private managedOperationLockTtlMs;
    private managedReservationTtlMs;
    private bodyTemplate;
    private sendGuard?;
    constructor(config?: PhoneAuthConfig);
    private managedOperationError;
    private acquireManagedOperation;
    private releaseManagedOperation;
    private renewManagedOperation;
    private withManagedOperation;
    private reserveManagedChallenge;
    private finalizeManagedChallenge;
    sendOtp(phone: string, purpose: string, deliveryChannel: ManagedOtpDeliveryChannel): Promise<{
        expiresAt: Date;
    }>;
    verifyOtp(phone: string, code: string, purpose?: string): Promise<{
        valid: boolean;
        phone?: string;
    }>;
    destroy(): void;
}
//# sourceMappingURL=phone.d.ts.map