import type { ApiKeyPair } from "./types.js";
export declare function generateApiKey(): ApiKeyPair;
export declare function hashApiKey(key: string): string;
export declare function validateApiKey(key: string, hash: string): boolean;
//# sourceMappingURL=api-keys.d.ts.map