import type { Sql } from "postgres";
/** Caller must stop source writers before apply; validation never changes records. */
export declare function transferLoginState(sql: Sql, snapshot: unknown, mode: "validate" | "apply-quiesced"): Promise<{
    entries: number;
    live: number;
    conflicts: number;
    applied: boolean;
}>;
//# sourceMappingURL=store-transfer.d.ts.map