export interface VerifySamlAcsInput {
    samlResponse: string;
    expectedRequestId?: string;
    tenantId: string;
    idpEntityId: string;
    idpSsoUrl: string;
    idpCertPems: string[];
    spEntityId: string;
    acsUrl: string;
    emailAttribute?: string;
    groupsAttribute?: string;
    acceptedClockSkewMs?: number;
}
export interface VerifiedSamlAssertion {
    tenantId: string;
    issuer: string;
    assertionId: string;
    nameId: string;
    email: string;
    groups: string[];
    sessionIndex?: string;
    attributes: Record<string, unknown>;
}
export interface BuildSamlAuthorizeUrlInput {
    relayState: string;
    requestId: string;
    idpSsoUrl: string;
    idpEntityId: string;
    idpCertPems: string[];
    spEntityId: string;
    acsUrl: string;
}
export interface BuiltSamlAuthorizeUrl {
    url: string;
    requestId: string;
}
export declare function verifySamlAcsResponse(input: VerifySamlAcsInput): Promise<VerifiedSamlAssertion>;
export declare function buildSamlAuthorizeUrl(input: BuildSamlAuthorizeUrlInput): Promise<BuiltSamlAuthorizeUrl>;
//# sourceMappingURL=saml.d.ts.map