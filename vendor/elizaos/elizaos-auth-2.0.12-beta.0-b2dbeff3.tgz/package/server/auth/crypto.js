import { createHash } from "node:crypto";
export function hashSha256Hex(value) {
    return createHash("sha256").update(value).digest("hex");
}
//# sourceMappingURL=crypto.js.map