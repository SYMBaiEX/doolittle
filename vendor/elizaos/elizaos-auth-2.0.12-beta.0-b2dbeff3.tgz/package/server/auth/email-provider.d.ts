/**
 * Redacted delivery acceptance receipt: proof that the underlying provider
 * ACCEPTED the message for delivery. Never carries the recipient, subject,
 * body, or any embedded token/code — safe to log as-is.
 */
export interface EmailDeliveryReceipt {
    /** Which provider accepted the message, e.g. "resend" | "console" | "mock". */
    provider: string;
    /** Provider-assigned message id, when the provider returns one. */
    id?: string;
}
/**
 * Typed failure raised when a provider rejects a send (or returns no
 * acceptance receipt). The message is deliberately generic — never the
 * recipient, token, code, or raw provider error text — so it can be logged
 * and surfaced without leaking secrets. The API layer maps this to 502.
 */
export declare class EmailDeliveryError extends Error {
    constructor(message?: string);
}
/**
 * Typed failure raised when no delivery-capable email provider is configured
 * (e.g. the ConsoleProvider fallback in production). Raised BEFORE any
 * challenge state is created so a misconfigured deployment can never issue
 * an unredeemable-by-email challenge. The API layer maps this to 503.
 */
export declare class EmailDeliveryNotConfiguredError extends Error {
    constructor(message?: string);
}
/**
 * Pluggable email provider interface.
 * Swap implementations without touching EmailAuth logic.
 *
 * `send` must resolve with an acceptance receipt only after the underlying
 * provider accepted the message, and must THROW when it did not — resolving
 * without a receipt is treated as delivery failure by EmailAuth (fail closed).
 */
export interface EmailProvider {
    send(to: string, subject: string, text: string, html?: string, options?: {
        replyTo?: string;
    }): Promise<EmailDeliveryReceipt>;
}
export interface ResendProviderConfig {
    apiKey: string;
    from: string;
    replyTo?: string;
}
export declare class ResendProvider implements EmailProvider {
    private client;
    private from;
    private replyTo?;
    constructor(config: ResendProviderConfig);
    send(to: string, subject: string, text: string, html?: string, options?: {
        replyTo?: string;
    }): Promise<EmailDeliveryReceipt>;
}
export declare class ConsoleProvider implements EmailProvider {
    send(_to: string, _subject: string, _text: string, _html?: string, _options?: {
        replyTo?: string;
    }): Promise<EmailDeliveryReceipt>;
}
export interface MockEmailMessage {
    to: string;
    subject: string;
    text: string;
    html?: string;
    replyTo?: string;
    sentAt: Date;
    /** Magic-link token extracted from the text body, if present. */
    token?: string;
    /** Full magic-link URL extracted from the text body, if present. */
    magicLink?: string;
}
declare class MockEmailInboxRegistry {
    private byEmail;
    push(msg: MockEmailMessage): void;
    last(email: string): MockEmailMessage | undefined;
    all(email: string): MockEmailMessage[];
    clear(email?: string): void;
}
export declare const MockEmailInbox: MockEmailInboxRegistry;
export declare class MockEmailProvider implements EmailProvider {
    send(to: string, subject: string, text: string, html?: string, options?: {
        replyTo?: string;
    }): Promise<EmailDeliveryReceipt>;
}
export {};
//# sourceMappingURL=email-provider.d.ts.map