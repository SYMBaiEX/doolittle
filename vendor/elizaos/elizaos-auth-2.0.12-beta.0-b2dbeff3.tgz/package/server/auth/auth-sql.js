/** Adapts parameterized auth-store SQL and atomic transactions to the embedded database. */
import { ElizaError } from "@elizaos/core";
import { sql } from "drizzle-orm";
import { getDb, hasTenantTransactionDatabase, isEmbeddedDatabase, } from "../db/client.js";
function parameterizedStatement(strings) {
    return strings.reduce((query, segment, index) => query + (index === 0 ? "" : `$${index}`) + segment, "");
}
function resultRows(result) {
    return Array.isArray(result) ? result : result.rows;
}
function queryTag(database) {
    return async (strings, ...values) => {
        const statement = sql.empty();
        strings.forEach((segment, index) => {
            if (index > 0)
                statement.append(sql `${values[index - 1]}`);
            statement.append(sql.raw(segment));
        });
        return resultRows(await database().execute(statement));
    };
}
function postgresQueryTag(client) {
    return async (strings, ...values) => {
        return await client.unsafe(parameterizedStatement(strings), values);
    };
}
export function createPostgresAuthSql(client) {
    const query = postgresQueryTag(client);
    async function begin(options, callback) {
        const run = typeof options === "function" ? options : callback;
        if (!run)
            throw new TypeError("Auth transaction callback is required");
        await client.begin(typeof options === "string" ? options : "", async (transaction) => {
            await run(postgresQueryTag(transaction));
        });
    }
    return Object.assign(query, { begin });
}
/** Auth-store SQL that runs on one open transaction instead of a new connection checkout. */
export function createTransactionAuthSql(transaction) {
    return queryTag(() => transaction);
}
export function createDatabaseAuthSql() {
    const query = queryTag(getDb);
    async function begin(options, callback) {
        const run = typeof options === "function" ? options : callback;
        if (!run)
            throw new TypeError("Auth transaction callback is required");
        if (typeof options === "string" &&
            !isEmbeddedDatabase() &&
            hasTenantTransactionDatabase()) {
            const [isolation] = await query `SELECT current_setting('transaction_isolation') AS level`;
            if (isolation.level !== "serializable") {
                throw new ElizaError("Atomic auth publication requires a serializable transaction", { code: "LOGIN_AUTH_ISOLATION_REQUIRED" });
            }
        }
        // getDb resolves the current identity transaction, so auth state cannot
        // queue behind the same request's transaction on PGlite's single connection.
        await getDb().transaction(async (transaction) => {
            await run(queryTag(() => transaction));
        }, typeof options === "string"
            ? { isolationLevel: "serializable" }
            : undefined);
    }
    return Object.assign(query, { begin });
}
//# sourceMappingURL=auth-sql.js.map