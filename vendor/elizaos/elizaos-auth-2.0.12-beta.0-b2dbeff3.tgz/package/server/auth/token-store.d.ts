/**
 * TokenStore — persists magic-link token hashes with per-entry TTL.
 *
 * Backed by a pluggable StoreBackend (Redis, Postgres, or in-memory).
 * The default (zero-config) backend is MemoryBackend, preserving
 * backward-compatible behavior.
 *
 * Public API is intentionally unchanged:  store(), verify(), delete(), destroy().
 *
 * To use a persistent backend, pass it at construction time:
 *
 *   import { RedisBackend } from "./store-backends";
 *   const ts = new TokenStore({ backend: new RedisBackend(redisClient) });
 */
import type { StoreBackend, StorePublishEntry } from "./store-backends.js";
export interface TokenStoreOptions {
    /** Override the default in-memory backend with a persistent implementation. */
    backend?: StoreBackend;
}
export declare class TokenStore {
    private readonly backend;
    constructor(options?: TokenStoreOptions);
    /**
     * Store a hash → email mapping with a TTL.
     * @param hash   SHA-256 hex of the raw token
     * @param email  Email address tied to this token
     * @param ttlMs  Time-to-live in milliseconds (default 10 min)
     */
    store(hash: string, email: string, ttlMs?: number): Promise<void>;
    setIfNotExists(hash: string, email: string, ttlMs?: number): Promise<boolean>;
    /**
     * Verify a hash and return the associated email if it exists and hasn't expired.
     * Does NOT delete the entry — call delete() explicitly after use.
     */
    verify(hash: string): Promise<string | null>;
    /**
     * Atomically retrieve and delete a token hash.
     */
    consume(hash: string): Promise<string | null>;
    compareDelete(hash: string, expected: string): Promise<boolean>;
    transition(hash: string, expected: string, desired: string, ttlMs?: number, guard?: {
        key: string;
        expected: string;
    }): Promise<boolean>;
    publish(entries: readonly StorePublishEntry[]): Promise<boolean>;
    /**
     * Delete a hash from the store (called after one-time token consumption).
     */
    delete(hash: string): Promise<void>;
    /**
     * Stop background cleanup timers (no-op for Redis/Postgres backends).
     * Useful in tests when using the default MemoryBackend.
     */
    destroy(): void;
}
//# sourceMappingURL=token-store.d.ts.map