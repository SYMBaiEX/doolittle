export type ManagedOtpDeliveryChannel = "sms" | "whatsapp";
/**
 * Pluggable SMS provider interface. Implementations send a short text body
 * to an E.164-formatted phone number.
 */
export interface SmsProvider {
    /** Defaults to SMS-only; test doubles may explicitly emulate other channels. */
    readonly otpDeliveryChannels?: readonly ManagedOtpDeliveryChannel[];
    send(to: string, body: string): Promise<void>;
}
/**
 * Provider-managed SMS OTP lifecycle. Unlike {@link SmsProvider}, the remote
 * provider owns code generation and verification as one bounded challenge.
 */
export interface ManagedSmsOtpProvider {
    /** Provider-side lifetime of an active OTP challenge. */
    readonly challengeTtlMs: number;
    /**
     * Lifetime of the per-phone operation lock. It must cover one bounded
     * provider request plus clock skew so sends and checks cannot overlap.
     */
    readonly operationLockTtlMs: number;
    /**
     * Pre-send purpose-reservation TTL. It must cover provider validity, both a
     * bounded send and a bounded check window, and clock skew.
     */
    readonly reservationTtlMs: number;
    /** Starts or resends a challenge on the explicit transport. */
    send(to: string, channel: ManagedOtpDeliveryChannel): Promise<{
        expiresAt: Date;
    }>;
    verify(to: string, code: string): Promise<boolean>;
}
/**
 * Typed delivery failure raised by SMS providers. Deliberately generic: the
 * raw provider error body can carry account/phone metadata and must never
 * propagate into thrown errors, logs, or API responses (SEC-061).
 */
export declare class SmsDeliveryError extends Error {
    constructor(message?: string);
}
/** Generic verification failure that never carries provider response data. */
export declare class SmsVerificationError extends Error {
    constructor(message?: string);
}
/**
 * Verification could not reach the provider-check boundary. API callers may
 * safely roll back a claim-first invalid-attempt slot for this disposition.
 */
export declare class SmsVerificationNotAttemptedError extends SmsVerificationError {
    constructor();
}
export declare class ConsoleSmsProvider implements SmsProvider {
    send(to: string, body: string): Promise<void>;
}
export interface TwilioSmsProviderConfig {
    accountSid: string;
    authToken: string;
    /** Sender — phone number, alphanumeric ID, or Messaging Service SID (MGxxxx). */
    from: string;
}
export declare class TwilioSmsProvider implements SmsProvider {
    private accountSid;
    private authToken;
    private from;
    constructor(config: TwilioSmsProviderConfig);
    send(to: string, body: string): Promise<void>;
}
export interface TwilioVerifyProviderConfig {
    accountSid: string;
    authToken: string;
    /** Verify v2 Service SID (VAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx). */
    serviceSid: string;
    /**
     * Exact token validity configured on the Verify Service, in seconds. Twilio
     * allows 120 through 86400. This must not be guessed locally because Verify
     * reuses the same code for the configured validity window.
     */
    tokenTtlSeconds: number;
    /** Request timeout override for tests and constrained runtimes. Default: 15 seconds. */
    requestTimeoutMs?: number;
}
/**
 * Twilio Verify v2 adapter. Verify owns the OTP and compliant delivery route;
 * Steward retains the local auth-purpose binding in {@link PhoneAuth}.
 */
export declare class TwilioVerifyProvider implements ManagedSmsOtpProvider {
    readonly challengeTtlMs: number;
    readonly operationLockTtlMs: number;
    readonly reservationTtlMs: number;
    private readonly accountSid;
    private readonly authToken;
    private readonly serviceSid;
    private readonly requestTimeoutMs;
    constructor(config: TwilioVerifyProviderConfig);
    send(to: string, channel: ManagedOtpDeliveryChannel): Promise<{
        expiresAt: Date;
    }>;
    verify(to: string, code: string): Promise<boolean>;
}
export interface MockSmsMessage {
    to: string;
    body: string;
    sentAt: Date;
    code?: string;
}
declare class MockSmsInboxRegistry {
    private byPhone;
    push(msg: MockSmsMessage): void;
    last(phone: string): MockSmsMessage | undefined;
    all(phone: string): MockSmsMessage[];
    clear(phone?: string): void;
}
export declare const MockSmsInbox: MockSmsInboxRegistry;
export declare class MockSmsProvider implements SmsProvider {
    readonly otpDeliveryChannels: readonly ["sms", "whatsapp"];
    send(to: string, body: string): Promise<void>;
}
export {};
//# sourceMappingURL=sms-provider.d.ts.map