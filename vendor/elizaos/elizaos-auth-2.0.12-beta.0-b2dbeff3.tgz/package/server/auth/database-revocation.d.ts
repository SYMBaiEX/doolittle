import type { RevocationStore, RevocationTransaction } from "./revocation.js";
export declare class DatabaseRevocationStore implements RevocationStore {
    private readonly sql;
    revokeToken(jti: string, expiresAt: Date | number): Promise<void>;
    isRevoked(jti: string): Promise<boolean>;
    private revokeLine;
    private readLine;
    revokeAgentTokens(agentId: string, timestamp?: number, expiresAt?: Date | number): Promise<number>;
    getAgentRevokedBefore(agentId: string): Promise<number | null>;
    revokeUserTokens(userId: string, timestamp?: number, expiresAt?: Date | number, transaction?: RevocationTransaction): Promise<number>;
    getUserRevokedBefore(userId: string): Promise<number | null>;
}
//# sourceMappingURL=database-revocation.d.ts.map