import type { EmailProvider } from "./email-provider.js";
import { type MagicLinkTemplateData, type OtpTemplateData, type RenderedMagicLinkTemplate } from "./email-templates/index.js";
import { TokenStore } from "./token-store.js";
/** How an email sign-in challenge is delivered. */
export type EmailLoginDelivery = "link_and_code" | "code";
export interface EmailAuthConfig {
    /** Sender address, e.g. "login@eliza.app" */
    from: string;
    /** Base URL for building the callback link, e.g. "https://eliza.app" */
    baseUrl: string;
    /**
     * Pluggable email provider.
     * Defaults to ConsoleProvider so nothing breaks without API credentials.
     */
    provider?: EmailProvider;
    /** Token TTL in milliseconds. Default: 10 minutes. */
    tokenTtlMs?: number;
    /** Maximum time to wait for a provider acceptance receipt. Default: 30 seconds. */
    deliveryTimeoutMs?: number;
    /** Path that receives the magic-link callback. Default: "/auth/callback/email" */
    callbackPath?: string;
    /**
     * Optional external TokenStore to use for magic-link tokens.
     * Defaults to a fresh TokenStore backed by in-memory storage.
     * Pass a store configured with a Redis or Postgres backend for
     * restart-safe / multi-instance deployments.
     */
    tokenStore?: TokenStore;
    /** Override the magic-link template renderer. */
    templateRenderer?: (templateId: string | undefined, data: MagicLinkTemplateData) => RenderedMagicLinkTemplate;
    /** Override the OTP (sign-in code) template renderer. */
    otpTemplateRenderer?: (templateId: string | undefined, data: OtpTemplateData) => RenderedMagicLinkTemplate;
    /** Template ID to render for outgoing magic-link emails. */
    templateId?: string;
    /** Display brand used by the built-in magic-link and OTP templates. */
    brandName?: string;
    /** Override the rendered subject line. */
    subjectOverride?: string;
    /** Optional reply-to address to pass through to the provider. */
    replyTo?: string;
    /** Server secret used for keyed email login code and polling verifiers. */
    codeVerifierSecret?: string;
}
export interface TenantInvitationEmailContext {
    tenantId: string;
    token: string;
    expiresAt: Date;
    acceptPath?: string;
    tenantName?: string;
}
export type EmailLoginVerifyResult = {
    valid: true;
    email: string;
    tenantId?: string;
    challengeId: string;
} | {
    valid: false;
    email: "";
    reason?: "invalid" | "locked";
};
export type EmailLoginChallengeStatus = {
    status: "pending";
    expiresAt: string;
} | {
    status: "consumed" | "locked" | "expired" | "invalid";
};
export declare class EmailAuth {
    private provider;
    private deliveryNotConfigured;
    private tokenStore;
    private baseUrl;
    private callbackPath;
    private tokenTtlMs;
    private deliveryTimeoutMs;
    private from;
    private replyTo?;
    private templateId?;
    private brandName?;
    private subjectOverride?;
    private codeVerifierSecret;
    private templateRenderer;
    private otpTemplateRenderer;
    constructor(config: EmailAuthConfig);
    private emailHash;
    private codeVerifier;
    private pollSecretHash;
    private pollSecretMatches;
    private assertDeliveryConfigured;
    /** Dispatch through the provider and require a redacted acceptance receipt. */
    private sendAccepted;
    private markEmailLoginConsumed;
    private publishChallenge;
    private reserveIssuance;
    private releaseIssuance;
    private discardStaging;
    /**
     * Generate a magic link token, persist its hash, and send the email.
     * Returns the token hash (for verification lookup) and the expiry date.
     */
    sendMagicLink(email: string, context?: {
        tenantId?: string;
        /**
         * `"code"` sends only the six-digit code, rendered with the sign-in code
         * template, and issues no link token, so nothing in the email can sign
         * in a browser. Native apps use it so the user never leaves the app.
         * The default sends both the magic link and the code.
         */
        delivery?: EmailLoginDelivery;
    }): Promise<{
        tokenHash: string;
        expiresAt: Date;
        challengeId: string;
        pollSecret: string;
    }>;
    /**
     * Generate a 6-digit one-time code, persist its hash, and email it.
     * Privy-style email verification: the code proves address ownership and
     * is exchanged for a short-lived verified-email grant by the API layer.
     */
    sendOtp(email: string, context?: {
        tenantId?: string;
        tenantName?: string;
    }): Promise<{
        expiresAt: Date;
    }>;
    /**
     * Verify a 6-digit code for {email, tenantId}. One-time use: the code is
     * consumed on success. Returns false for unknown/expired/mismatched codes.
     */
    verifyOtp(email: string, code: string, tenantId?: string): Promise<boolean>;
    sendTenantInvitation(email: string, context: TenantInvitationEmailContext): Promise<void>;
    /**
     * Verify a raw token received from the callback URL.
     * One-time use: deletes the token after successful verification.
     */
    verifyMagicLink(token: string, email?: string, tenantId?: string): Promise<EmailLoginVerifyResult>;
    verifyEmailLoginCode(email: string, code: string, tenantId?: string): Promise<EmailLoginVerifyResult>;
    /**
     * Record a failed code attempt against the pending challenge; locks the
     * challenge after MAX_EMAIL_LOGIN_CODE_ATTEMPTS failures.
     *
     * Accepted trade-off (SEC-136): the attempt counter is keyed by email, so
     * anyone who knows a victim's address can burn the attempts and force the
     * victim to re-request a code. That is inherent to any attempt limiter —
     * the alternative (no limiter) leaves the 6-digit code brute-forceable.
     * Impact is availability-only (re-request); no code is ever confirmed or
     * consumed by failed attempts.
     */
    recordEmailLoginCodeFailure(email: string, tenantId?: string): Promise<"failed" | "locked">;
    getEmailLoginStatus(challengeId: string, pollSecret: string): Promise<EmailLoginChallengeStatus>;
    /**
     * Clean up background timers.  Call in tests after each suite.
     */
    destroy(): void;
}
//# sourceMappingURL=email.d.ts.map