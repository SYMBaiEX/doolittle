/**
 * Assembles the first-party identity API with authentication before idempotency.
 * Existing identity and wallet routes retain their persisted protocol contracts;
 * trading venues, strategies and DeFi adapter routes are not mounted.
 */
import { Hono } from "hono";
import { type AppVariables } from "./api/services/context.js";
/** Creates a router without starting a process, mutating a database or installing timers. */
export declare function createLoginApp(): Hono<{
    Variables: AppVariables;
}>;
//# sourceMappingURL=app.d.ts.map