export type ProviderExecutionAuthV2ErrorCode = "secret_unavailable" | "unknown_key" | "signature_invalid";
export declare class ProviderExecutionAuthV2Error extends Error {
    readonly code: ProviderExecutionAuthV2ErrorCode;
    constructor(message: string, code: ProviderExecutionAuthV2ErrorCode);
}
export interface ProviderExecutionAuthV2KeyEntry {
    keyId: string;
    key: Uint8Array;
}
/**
 * Parse STEWARD_EXECUTION_AUTH_SECRET into a keyId->key rotation list.
 *
 * Format is a comma-separated list of `keyId:secret` pairs; the FIRST entry is
 * the active signing key, all entries verify. A bare secret with no `keyId:`
 * prefix is treated as a single key with the reserved keyId `v2-default`.
 *
 * Each key is HKDF-derived with distinct salt/info from v1 so the derived keys
 * can never collide with the v1 (STEWARD_JWT_SECRET) key material.
 */
export declare function loadExecutionAuthV2Keys(): ProviderExecutionAuthV2KeyEntry[];
//# sourceMappingURL=execution-auth-keys.d.ts.map