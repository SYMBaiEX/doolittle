import { CHAIN_PROVIDERS_BY_NUMERIC } from "../../contracts/index.js";
/**
 * Canonical normalization + digest for the primary EVM `wallet.sign_transaction`
 * execution payload.
 *
 * ONE implementation, used by both:
 *  - the API when minting an ExecutionAuthorization (packages/api execution-authorization.ts)
 *  - GovernedVault when verifying an authorization immediately before raw signing
 *    (packages/auth governed-vault.ts)
 *
 * The digest binds the transaction *intent* (caller-controlled, policy-relevant
 * fields), NOT the final node-resolved serialized envelope. Node-resolved
 * nonce/gas price may still be finalized inside the Vault after authorization is
 * consumed; those node-resolved fields are deliberately outside the bound intent.
 */
/**
 * Fields that carry a caller-supplied integer we bind into the intent digest.
 * All are validated as non-negative safe integers before they are normalized so
 * a malformed value can never be silently coerced past the digest boundary.
 */
export class ExecutionPayloadNormalizationError extends Error {
    field;
    constructor(message, field) {
        super(message);
        this.field = field;
        this.name = "ExecutionPayloadNormalizationError";
    }
}
function normalizeSafeNonNegativeInteger(value, field) {
    if (value === undefined || value === null)
        return null;
    if (!Number.isSafeInteger(value) || value < 0) {
        throw new ExecutionPayloadNormalizationError(`${field} must be a non-negative safe integer`, field);
    }
    return value;
}
/**
 * True only for chains registered as EVM-family. Unknown numeric ids and
 * non-EVM families (Solana/Bitcoin/Monero) return false — fail closed, so a
 * future caller routing on this never mis-handles a non-EVM id as EVM
 * (SEC-193).
 */
export function isEvmChainId(chainId) {
    return CHAIN_PROVIDERS_BY_NUMERIC[chainId]?.family === "evm";
}
/**
 * Produce the canonical normalized intent payload for a primary EVM sign
 * request. Throws ExecutionPayloadNormalizationError on any malformed
 * numeric caller field so callers can fail closed rather than digest garbage.
 */
export function normalizeEvmExecutionPayload(request) {
    const chainId = normalizeSafeNonNegativeInteger(request.chainId, "chainId");
    if (chainId === null) {
        throw new ExecutionPayloadNormalizationError("chainId is required", "chainId");
    }
    const nonce = normalizeSafeNonNegativeInteger(request.nonce ?? null, "nonce");
    return {
        agentId: request.agentId,
        tenantId: request.tenantId,
        capability: "wallet.sign_transaction",
        backend: "local-vault",
        transaction: {
            to: request.to,
            value: request.value,
            data: request.data ?? "0x",
            chainId,
            nonce,
            gasLimit: request.gasLimit ?? null,
            broadcast: request.broadcast !== false,
            venue: request.venue ?? null,
            walletAddress: request.walletAddress ?? null,
        },
    };
}
/** Stable stringify with sorted keys. Shared by digest producers/verifiers. */
export function canonicalJsonStringify(value) {
    return JSON.stringify(canonicalize(value));
}
function canonicalize(value) {
    if (typeof value === "bigint")
        return value.toString();
    if (value === null || typeof value !== "object")
        return value;
    if (value instanceof Date)
        return value.toISOString();
    if (Array.isArray(value))
        return value.map((entry) => canonicalize(entry));
    const input = value;
    // Null-prototype output: plain `{}` assignment silently DROPS an own
    // `__proto__` key (present after JSON.parse/JSONB reads), which would let two
    // snapshots differing only in that member digest identically (SEC-115).
    const output = Object.create(null);
    for (const key of Object.keys(input).sort()) {
        const item = input[key];
        if (item !== undefined)
            output[key] = canonicalize(item);
    }
    return output;
}
//# sourceMappingURL=execution-payload.js.map