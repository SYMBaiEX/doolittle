export function approvalIntentActionType(actionType) {
    if (actionType === "transfer")
        return "wallet_action.transfer";
    if (actionType === "send_calls")
        return "wallet_action.send_calls";
    if (actionType === "user_operation")
        return "user_operation";
    if (actionType === "authorization")
        return "eip7702_authorization";
    return "transaction";
}
//# sourceMappingURL=execution-contract.js.map