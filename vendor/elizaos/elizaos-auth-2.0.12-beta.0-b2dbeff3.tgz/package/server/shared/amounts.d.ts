export declare function parseDecimalToScaled(value: string, scaleDecimals?: number): bigint | null;
export declare function formatScaledDecimal(value: bigint, scaleDecimals?: number): string;
export declare function priceToScaledText(price: number | null): string | null;
export declare function tokenAmountUsdText(balance: string, decimals: number, price: number | null): string | null;
export declare function sumUsdText(values: Array<string | null>): string | null;
export declare function isUint256DecimalString(value: unknown): value is string;
//# sourceMappingURL=amounts.d.ts.map