import type { SignRequest } from "./index.js";
/**
 * Canonical normalization + digest for the primary EVM `wallet.sign_transaction`
 * execution payload.
 *
 * ONE implementation, used by both:
 *  - the API when minting an ExecutionAuthorization (packages/api execution-authorization.ts)
 *  - GovernedVault when verifying an authorization immediately before raw signing
 *    (packages/auth governed-vault.ts)
 *
 * The digest binds the transaction *intent* (caller-controlled, policy-relevant
 * fields), NOT the final node-resolved serialized envelope. Node-resolved
 * nonce/gas price may still be finalized inside the Vault after authorization is
 * consumed; those node-resolved fields are deliberately outside the bound intent.
 */
/**
 * Fields that carry a caller-supplied integer we bind into the intent digest.
 * All are validated as non-negative safe integers before they are normalized so
 * a malformed value can never be silently coerced past the digest boundary.
 */
export declare class ExecutionPayloadNormalizationError extends Error {
    readonly field: string;
    constructor(message: string, field: string);
}
export interface NormalizedEvmExecutionPayload {
    agentId: string;
    tenantId: string;
    capability: "wallet.sign_transaction";
    backend: "local-vault";
    transaction: {
        to: string;
        value: string;
        data: string;
        chainId: number;
        nonce: number | null;
        gasLimit: string | null;
        broadcast: boolean;
        venue: string | null;
        walletAddress: string | null;
    };
}
/**
 * True only for chains registered as EVM-family. Unknown numeric ids and
 * non-EVM families (Solana/Bitcoin/Monero) return false — fail closed, so a
 * future caller routing on this never mis-handles a non-EVM id as EVM
 * (SEC-193).
 */
export declare function isEvmChainId(chainId: number): boolean;
/**
 * Produce the canonical normalized intent payload for a primary EVM sign
 * request. Throws ExecutionPayloadNormalizationError on any malformed
 * numeric caller field so callers can fail closed rather than digest garbage.
 */
export declare function normalizeEvmExecutionPayload(request: SignRequest): NormalizedEvmExecutionPayload;
/** Stable stringify with sorted keys. Shared by digest producers/verifiers. */
export declare function canonicalJsonStringify(value: unknown): string;
//# sourceMappingURL=execution-payload.d.ts.map