export { startEmbeddedLogin } from "./runtime.js";
//# sourceMappingURL=embedded.d.ts.map