/** Starts one embedded identity database per process and releases ownership on shutdown. */
export declare function startEmbeddedLogin(options?: {
    port?: number;
}): Promise<{
    port: number | undefined;
    stop(): Promise<void>;
}>;
export declare function startLoginServer(options?: {
    port?: number;
    hostname?: string;
}): Promise<{
    port: number | undefined;
    stop(): Promise<void>;
}>;
//# sourceMappingURL=runtime.d.ts.map