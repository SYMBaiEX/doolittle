export declare function resolveEmbeddedSecrets(dataDir: string, masterPassword: string, configured: {
    kdfSalt?: string;
    auditKey?: string;
}): {
    kdfSalt: string;
    auditKey: string;
};
//# sourceMappingURL=embedded-secrets.d.ts.map