/**
 * Starts the identity API with an owned embedded or PostgreSQL database.
 * The application host supplies the persisted vault password before startup;
 * database migrations and authentication initialization finish before listening.
 */
import { ElizaError, registerScheduledProcessTask } from "@elizaos/core";
let activeOwner;
/** Starts one embedded identity database per process and releases ownership on shutdown. */
export function startEmbeddedLogin(options = {}) {
    return startLoginRuntime({
        ...options,
        mode: "embedded",
        hostname: "127.0.0.1",
    });
}
export function startLoginServer(options = {}) {
    return startLoginRuntime({
        ...options,
        mode: "postgres",
        hostname: options.hostname ?? process.env.LOGIN_BIND_HOST ?? "127.0.0.1",
    });
}
async function startLoginRuntime(options) {
    if (activeOwner) {
        throw new ElizaError("A login server is already starting or running in this process", {
            code: "LOGIN_ALREADY_RUNNING",
        });
    }
    const owner = Symbol("login-runtime");
    activeOwner = owner;
    const release = () => {
        if (activeOwner === owner)
            activeOwner = undefined;
    };
    try {
        const server = await startOwnedLogin(options);
        return {
            port: server.port,
            async stop() {
                try {
                    await server.stop();
                }
                finally {
                    release();
                }
            },
        };
    }
    catch (error) {
        // error-policy:J2 release process ownership while preserving the startup failure.
        release();
        throw new ElizaError("Unable to start the login server", {
            code: "LOGIN_STARTUP_FAILED",
            cause: error,
        });
    }
}
async function startOwnedLogin(options) {
    const port = options.port ?? Number(process.env.PORT ?? "3200");
    if (!Number.isInteger(port) || port < 0 || port > 65535) {
        throw new ElizaError("Login port must be an integer from 0 to 65535", {
            code: "LOGIN_PORT_INVALID",
            context: { port },
        });
    }
    if (!process.env.STEWARD_MASTER_PASSWORD?.trim()) {
        throw new ElizaError("The application host must supply its persisted login vault password", {
            code: "LOGIN_MASTER_PASSWORD_REQUIRED",
        });
    }
    const { setPGLiteOverride, closeDb, getDatabaseDriver } = await import("./db/client.js");
    let releaseAuth;
    let stopWebhookWorker;
    let closeRedis;
    let clearRateLimiter;
    const { clearConfiguredVaults } = await import("./api/services/vault-factory.js");
    const { setEmbeddedAuthDatabase } = await import("./auth/store-backends.js");
    const { setDatabaseRevocationStore } = await import("./auth/revocation.js");
    const { setDatabaseIdempotencyStore } = await import("./api/middleware/idempotency.js");
    const { DatabaseRevocationStore } = await import("./auth/database-revocation.js");
    try {
        if (options.mode === "embedded") {
            process.env.STEWARD_DB_MODE = "pglite";
            process.env.STEWARD_EMBEDDED = "true";
            const { createPGLiteDb, getDataDir } = await import("./db/pglite.js");
            if (process.env.STEWARD_PGLITE_MEMORY !== "true") {
                const { resolveEmbeddedSecrets } = await import("./embedded-secrets.js");
                const secrets = resolveEmbeddedSecrets(getDataDir(), process.env.STEWARD_MASTER_PASSWORD, {
                    kdfSalt: process.env.STEWARD_KDF_SALT,
                    auditKey: process.env.STEWARD_AUDIT_HMAC_KEY,
                });
                process.env.STEWARD_KDF_SALT = secrets.kdfSalt;
                process.env.STEWARD_AUDIT_HMAC_KEY = secrets.auditKey;
            }
            const database = await createPGLiteDb();
            setPGLiteOverride(database.db, () => database.client.close());
        }
        else {
            if (getDatabaseDriver() !== "postgres-js") {
                throw new ElizaError("The login service requires the transactional postgres-js database driver", { code: "LOGIN_DATABASE_DRIVER_INVALID" });
            }
            process.env.STEWARD_DB_MODE = "postgres";
            process.env.STEWARD_EMBEDDED = "false";
            const { initializeLoginSchema } = await import("./db/schema-readiness.js");
            await initializeLoginSchema();
        }
        setEmbeddedAuthDatabase(options.mode === "embedded");
        setDatabaseRevocationStore(new DatabaseRevocationStore());
        const { createLoginApp } = await import("./app.js");
        const { initializeDefaultTenant } = await import("./api/services/context.js");
        await initializeDefaultTenant();
        const { initAuthStores, assertAuthStoresAreSafe, releaseAuthStores } = await import("./api/services/auth-lifecycle.js");
        const { setDatabaseAuthRateLimiter } = await import("./api/services/auth-rate-limit.js");
        const { initRedis, shutdownRedis, isRedisConfigured } = await import("./api/middleware/redis.js");
        const { getConfiguredVault } = await import("./api/services/vault-factory.js");
        const { SOCKET_PEER_ENV_KEY } = await import("./api/services/runtime-gate.js");
        closeRedis = shutdownRedis;
        releaseAuth = releaseAuthStores;
        clearRateLimiter = () => setDatabaseAuthRateLimiter(undefined);
        const redisAvailable = await initRedis();
        const { isCloudflareRateLimitConfigured } = await import("./redis/cloudflare-rate-limit.js");
        isCloudflareRateLimitConfigured();
        const { isCloudflareAggregationConfigured } = await import("./redis/cloudflare-aggregation.js");
        isCloudflareAggregationConfigured();
        const { isCloudflareSpendMetricsConfigured } = await import("./redis/cloudflare-spend-metrics.js");
        isCloudflareSpendMetricsConfigured();
        // A configured Redis outage must not select a different receipt history.
        setDatabaseIdempotencyStore(!isRedisConfigured());
        await initAuthStores(options.mode === "postgres" && !redisAvailable);
        assertAuthStoresAreSafe();
        const { checkDatabaseAuthRateLimit } = await import("./auth/database-rate-limit.js");
        setDatabaseAuthRateLimiter(checkDatabaseAuthRateLimit);
        getConfiguredVault();
        const { PersistentQueue } = await import("./webhooks/index.js");
        const webhookQueue = new PersistentQueue();
        stopWebhookWorker = registerScheduledProcessTask("login-webhook-delivery", async (signal) => {
            await webhookQueue.processQueue(signal);
        });
        const app = createLoginApp();
        const server = Bun.serve({
            hostname: options.hostname,
            port,
            // OAuth can consume its one-time state before account provisioning
            // finishes. Keep the response socket alive beyond the Cloud proxy's
            // 25-second deadline so a dropped connection cannot provoke a replay.
            idleTimeout: 30,
            fetch(request, listener) {
                return app.fetch(request, {
                    [SOCKET_PEER_ENV_KEY]: listener.requestIP(request)?.address ?? null,
                });
            },
        });
        let closing;
        return {
            port: server.port,
            stop() {
                closing ??= (async () => {
                    const listener = await Promise.allSettled([server.stop(true)]);
                    await stopWebhookWorker?.();
                    const { drainWebhookDeliveries } = await import("./api/services/webhook-dispatch.js");
                    await drainWebhookDeliveries();
                    releaseAuth?.();
                    clearConfiguredVaults();
                    setDatabaseAuthRateLimiter(undefined);
                    setEmbeddedAuthDatabase(false);
                    setDatabaseRevocationStore(undefined);
                    setDatabaseIdempotencyStore(false);
                    const storage = await Promise.allSettled([
                        closeDb(),
                        shutdownRedis(),
                    ]);
                    const failures = [...listener, ...storage].flatMap((result) => result.status === "rejected" ? [result.reason] : []);
                    if (failures.length > 0) {
                        throw new ElizaError("Unable to close the login service cleanly", {
                            code: "LOGIN_SHUTDOWN_FAILED",
                            cause: new AggregateError(failures),
                        });
                    }
                })();
                return closing;
            },
        };
    }
    catch (error) {
        // error-policy:J2 preserve the startup failure after closing the owned database.
        await stopWebhookWorker?.();
        releaseAuth?.();
        clearConfiguredVaults();
        clearRateLimiter?.();
        setEmbeddedAuthDatabase(false);
        setDatabaseRevocationStore(undefined);
        setDatabaseIdempotencyStore(false);
        const teardown = await Promise.allSettled([
            closeDb(),
            ...(closeRedis ? [closeRedis()] : []),
        ]);
        throw new ElizaError("Login startup failed", {
            code: "LOGIN_STARTUP_FAILED",
            cause: error,
            context: {
                teardownFailed: teardown.some((result) => result.status === "rejected"),
            },
        });
    }
}
//# sourceMappingURL=runtime.js.map