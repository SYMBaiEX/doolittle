/**
 * Default tenant control plane configurations for common use cases.
 */
import type { TenantControlPlaneConfig } from "../../shared/index.js";
export declare const MILADY_CLOUD_CONFIG: TenantControlPlaneConfig;
export declare const MILADY_DESKTOP_CONFIG: TenantControlPlaneConfig;
export declare const ELIZA_CLOUD_CONFIG: TenantControlPlaneConfig;
/** All default configs, keyed by tenant ID */
export declare const DEFAULT_TENANT_CONFIGS: Record<string, TenantControlPlaneConfig>;
//# sourceMappingURL=tenant-configs.d.ts.map