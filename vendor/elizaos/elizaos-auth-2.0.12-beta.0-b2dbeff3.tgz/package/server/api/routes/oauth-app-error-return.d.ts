/** Only call with a return URL verified from server-owned OAuth state. */
export declare function buildOAuthAppErrorReturn(redirectUrl: string, state: string, code: string, allowedReturns?: string): string | null;
//# sourceMappingURL=oauth-app-error-return.d.ts.map