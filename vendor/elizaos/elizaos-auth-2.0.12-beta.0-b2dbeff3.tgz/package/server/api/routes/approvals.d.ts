export declare const approvalRoutes: any;
//# sourceMappingURL=approvals.d.ts.map