export declare function getSmsVerifyFailedAttempts(phone: string, purpose: string): Promise<number>;
export declare function recordSmsVerifyFailure(phone: string, purpose: string): Promise<void>;
export { verifySessionToken } from "../services/context.js";
/** Fail app construction before health/readiness can accept malformed Verify config. */
export declare function validatePhoneAuthProviderEnvironment(env?: NodeJS.ProcessEnv): void;
declare const auth: any;
export declare function resolveOAuthPromptPassthrough(providerName: string, rawPrompt: string | undefined): {
    ok: true;
    prompt?: string;
} | {
    ok: false;
    error: string;
};
export { auth as authRoutes };
//# sourceMappingURL=auth.d.ts.map