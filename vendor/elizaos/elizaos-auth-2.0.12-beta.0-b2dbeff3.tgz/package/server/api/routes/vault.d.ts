export declare const vaultRoutes: any;
//# sourceMappingURL=vault.d.ts.map