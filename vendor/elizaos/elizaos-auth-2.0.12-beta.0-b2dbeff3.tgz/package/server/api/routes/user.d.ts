import { type Context, type Next } from "hono";
interface UserSessionPayload {
    userId: string;
    address?: string;
    email?: string;
    tenantId?: string;
    iat?: number;
    exp?: number;
    mfaVerifiedAt?: number;
    mfaMethod?: string;
    factorEnrollmentVerifiedAt?: number;
    [key: string]: unknown;
}
type UserVariables = {
    userId: string;
    userSession: UserSessionPayload;
    authType?: "session-jwt" | "user-wallet-signer";
    userWalletSignerAuth?: {
        signerId: string;
        tenantId: string;
        agentId: string;
        requiredPermission: string;
    };
    sessionMfaVerifiedAt?: number;
    sessionMfaMethod?: string;
    requestId?: string;
};
/**
 * Reads `Authorization: Bearer <jwt>`, verifies it with jose, and populates
 * `c.get("userId")` + `c.get("userSession")` for downstream handlers.
 *
 * The JWT is expected to contain `userId` from the auth identity layer. Legacy
 * address-only SIWE sessions are intentionally rejected here because user routes
 * operate on database users and tenant memberships, not raw wallet addresses.
 */
export declare function userSessionAuth(c: Context<{
    Variables: UserVariables;
}>, next: Next): Promise<Response | undefined>;
declare const user: any;
export { user as userRoutes };
//# sourceMappingURL=user.d.ts.map