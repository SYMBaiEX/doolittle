export declare const kmsRoutes: any;
//# sourceMappingURL=kms.d.ts.map