export declare const identityDiscoveryRoutes: any;
//# sourceMappingURL=discovery.d.ts.map