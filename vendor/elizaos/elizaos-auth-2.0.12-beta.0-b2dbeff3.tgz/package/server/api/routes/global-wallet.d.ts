export declare const globalWalletRoutes: any;
//# sourceMappingURL=global-wallet.d.ts.map