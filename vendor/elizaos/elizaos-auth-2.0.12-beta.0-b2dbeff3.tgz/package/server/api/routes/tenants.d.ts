import { type Context, type Next } from "hono";
import { type AppVariables } from "../services/context.js";
export declare const tenantRoutes: any;
export declare const requireTenantId: (c: Context<{
    Variables: AppVariables;
}>, next: Next) => Promise<Response | void>;
//# sourceMappingURL=tenants.d.ts.map