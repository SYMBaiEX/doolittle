import { googleNativeClientIds, verifyGoogleNativeIdToken, } from "../../auth/google-native.js";
import { buildPhoneAuthProvidersFromEnvironment } from "../../auth/phone-provider.js";
import { fetchPinnedResponse } from "../../shared/pinned-response.js";
import { assertAllowedOAuthRedirectUri, authAppClientSubjects, authTenantConfigSubject, bootstrapRows, claimSmsVerifyAttempt, clearSmsVerifyFailures, createSessionToken, EMAIL_GRANT_TTL_MS, emailGrantKey, encryptOAuthProviderTokens, getChallengeStore, getEmailAuthForTenant, getEmailGrantStore, getMfaBackend, getNonceBackend, getOAuthCodeStore, getOAuthKeyStore, getPasskeyAuth, getPhoneAuth, isMockEmailEnabled, loginMethodProviderKey, loginMethodRefusal, normalizePublicClientId, OAUTH_CODE_TTL_MS, releaseUnattemptedSmsVerifyClaim, SMS_VERIFY_MAX_FAILED_ATTEMPTS, smsVerifyAttemptSlotKey, tenantSwitchLoginRefusal, } from "../services/auth-lifecycle.js";
import { checkAuthRateLimit, trustedClientIp, } from "../services/auth-rate-limit.js";
import { verifySolanaMessageSignature } from "../services/wallet-proof.js";
import { buildOAuthAppErrorReturn } from "./oauth-app-error-return.js";
/**
 * Serves identity login, account enrollment, MFA and session lifecycle endpoints.
 * Tenant policy gates every login method; one-time challenges and refresh tokens
 * use atomic storage operations so concurrent requests cannot replay credentials.
 */
import { randomBytes } from "node:crypto";
import { assertPublicHttpsEndpoint, ElizaError, logger } from "@elizaos/core";
import { and, eq, gte, inArray, isNull, lt, sql } from "drizzle-orm";
import { Hono } from "hono";
import { errors as joseErrors } from "jose";
import { generateNonce, SiweMessage } from "siwe";
import { getAddress, verifyMessage as viemVerifyMessage } from "viem";
import { ACCESS_TOKEN_EXPIRY, ACCESS_TOKEN_EXPIRY_SECONDS, assertPinnedDnsTransportSupported, buildOtpauthUri, buildSamlAuthorizeUrl, createPublicInternetLookup, EmailDeliveryError, EmailDeliveryNotConfiguredError, evaluateSiwePolicy, generateApiKey, generateRecoveryCodes, generateTotpSecret, getEnabledProviders, getIdentityJwtIssuer, getProviderConfig, hashSha256Hex, IdentityJwtConfigurationError, InMemoryRecoveryCodeStore, isBuiltInProvider, isValidE164, MockEmailInbox, MockSmsInbox, OAuthClient, revocationStore, signIdentityJwtPayload, uint8ArrayToBase64url, unusedRecoveryCodeCount, verifyFarcasterLogin, verifyOidcJwt, verifyRecoveryCode, verifySamlAcsResponse, verifyTelegramLogin, verifyToken, verifyTotp, } from "../../auth/index.js";
import { accounts, authenticators, getDatabaseDriver, getDb, hasTenantTransactionDatabase, refreshTokens, tenantContextFromAuthenticatedPrincipal, tenantSamlAssertionReplays, tenantSamlAuthnRequests, tenantSamlSsoConfigs, tenants, users, userTenants, withTenantRlsTransaction, withTenantTransactionDatabase, } from "../../db/index.js";
import { redactedThrownDiagnostics, } from "../../shared/index.js";
import { provisionUserWallet } from "../../wallet/index.js";
import { writeAuditEvent as appendAuthAuditEvent, } from "../services/audit.js";
import { normalizeEmailDomain, publicAuthAbuseConfig, validateEmailAbusePolicy, validatePhoneAbusePolicy, validateWalletAbusePolicy, verifyCaptchaToken, } from "../services/auth-abuse.js";
import { verifySessionToken } from "../services/context.js";
import { defaultAuthTenantId } from "../services/default-auth-tenant.js";
import { verifyEip1271 } from "../services/eip1271.js";
import { isAllowedOidcClientSecretEnvForTenant, normalizeOidcProviders, } from "../services/oidc-provider-config.js";
import { revokeUserRefreshSessions } from "../services/refresh-session-revocation.js";
import { buildSamlServiceProviderUrls } from "../services/saml-sso-config.js";
import { lockUserSession } from "../services/session-lock.js";
import { testAccountOtpMatches } from "../services/test-account-credentials.js";
import { getConfiguredVault } from "../services/vault-factory.js";
import { dispatchWebhook } from "../services/webhook-dispatch.js";
// ─── Constants ────────────────────────────────────────────────────────────────
async function withVerifiedAuthTenant(tenantId, subject, callback) {
    if (hasTenantTransactionDatabase({ tenantId, userId: subject }))
        return callback();
    const context = tenantContextFromAuthenticatedPrincipal({
        tenantId,
        method: "verified-auth-flow",
        subject,
        userId: subject,
    });
    const driver = process.env.STEWARD_DB_MODE === "pglite" ||
        process.env.STEWARD_PGLITE_MEMORY === "true"
        ? "pglite"
        : getDatabaseDriver();
    return withTenantRlsTransaction(getDb(), driver, context, async (tx) => withTenantTransactionDatabase(tx, { tenantId, userId: subject }, callback));
}
async function withPreAuthTenant(tenantId, method, callback) {
    if (hasTenantTransactionDatabase({ tenantId }))
        return callback();
    const context = tenantContextFromAuthenticatedPrincipal({
        tenantId,
        method,
        subject: "public-auth-flow",
    });
    const driver = process.env.STEWARD_DB_MODE === "pglite" ||
        process.env.STEWARD_PGLITE_MEMORY === "true"
        ? "pglite"
        : getDatabaseDriver();
    return withTenantRlsTransaction(getDb(), driver, context, async (tx) => withTenantTransactionDatabase(tx, { tenantId }, callback));
}
/** Keeps login audit writes within their tenant's transaction-local policy context. */
async function writeAuditEvent(event) {
    return withPreAuthTenant(event.tenantId, "auth-audit", () => appendAuthAuditEvent(event));
}
function isValidTenantId(value) {
    return typeof value === "string" && /^[a-zA-Z0-9_\-.:]{1,64}$/.test(value);
}
function isReservedTenantId(value) {
    const normalized = value.toLowerCase();
    return (normalized === "personal" ||
        normalized.startsWith("personal-") ||
        normalized.startsWith("eth:") ||
        normalized.startsWith("t-") ||
        normalized.startsWith("solana:"));
}
const TOTP_VERIFY_MAX_FAILED_ATTEMPTS = 5;
const TOTP_VERIFY_FAILED_ATTEMPT_TTL_MS = 10 * 60 * 1000;
const FACTOR_ENROLLMENT_STEP_UP_MAX_AGE_MS = 5 * 60 * 1000;
export async function getSmsVerifyFailedAttempts(phone, purpose) {
    const attempts = await Promise.all(Array.from({ length: SMS_VERIFY_MAX_FAILED_ATTEMPTS }, (_, index) => getMfaBackend().get(smsVerifyAttemptSlotKey(phone, purpose, index + 1))));
    return attempts.filter((value) => value !== null).length;
}
export async function recordSmsVerifyFailure(phone, purpose) {
    await claimSmsVerifyAttempt(phone, purpose);
}
function totpVerifyAttemptSlotKey(scope, slot) {
    return `totp-verify-attempts:${hashSha256Hex(scope)}:${slot}`;
}
/**
 * Claim one attempt slot before a code is checked. A read-then-write counter
 * lets a parallel burst read the same count and all reach verification, so
 * each attempt takes its own slot atomically, like SMS verification. A
 * failed attempt keeps its slot; success clears them all.
 */
async function claimTotpVerifyAttempt(scope) {
    const token = `totp-verify-attempt:${randomBytes(16).toString("hex")}`;
    for (let slot = 1; slot <= TOTP_VERIFY_MAX_FAILED_ATTEMPTS; slot++) {
        if (await getMfaBackend().setIfNotExists(totpVerifyAttemptSlotKey(scope, slot), token, TOTP_VERIFY_FAILED_ATTEMPT_TTL_MS)) {
            return true;
        }
    }
    return false;
}
async function countTotpVerifyAttempts(scope) {
    const slots = await Promise.all(Array.from({ length: TOTP_VERIFY_MAX_FAILED_ATTEMPTS }, (_, index) => getMfaBackend().get(totpVerifyAttemptSlotKey(scope, index + 1))));
    return slots.filter((value) => value !== null).length;
}
async function clearTotpVerifyFailures(scope) {
    await Promise.all(Array.from({ length: TOTP_VERIFY_MAX_FAILED_ATTEMPTS }, (_, index) => getMfaBackend().delete(totpVerifyAttemptSlotKey(scope, index + 1))));
}
async function getTenantAuthAbuseConfig(tenantId) {
    return (await authTenantConfigSubject(tenantId))?.auth_abuse_config ?? {};
}
function validateUserAuthAbusePolicy(userId, config) {
    const userConfig = config.user;
    if (!userConfig)
        return null;
    if (userConfig.blockedUserIds?.includes(userId))
        return "user id is blocked";
    if (userConfig.allowedUserIds?.length &&
        !userConfig.allowedUserIds.includes(userId)) {
        return "user id is not allowed";
    }
    return null;
}
async function getTenantAppClientLoginMethods(tenantId, clientId) {
    const normalizedClientId = normalizePublicClientId(clientId);
    if (!normalizedClientId)
        return undefined;
    const row = (await authAppClientSubjects(tenantId)).find((client) => client.id === normalizedClientId);
    return (row?.login_methods ??
        undefined);
}
function withoutTenantMfaClaims(claims) {
    const { mfaVerifiedAt: _mfaVerifiedAt, mfaMethod: _mfaMethod, factorEnrollmentVerifiedAt: _factorEnrollmentVerifiedAt, ...rest } = claims;
    return rest;
}
async function requireTenantLoginMethodAllowed(c, tenantId, method, providerId, clientId) {
    if (!tenantId)
        return null;
    const loginMethods = (await getTenantAppClientLoginMethods(tenantId, clientId)) ??
        (await getTenantAuthAbuseConfig(tenantId)).loginMethods;
    const refusal = loginMethodRefusal(loginMethods, method, providerId);
    return refusal
        ? c.json({ ok: false, error: refusal }, 403)
        : null;
}
async function isSsoRequiredForEmailDomain(tenantId, email) {
    const domain = normalizeEmailDomain(email);
    if (!domain)
        return false;
    const result = await getDb().execute(sql `SELECT * FROM steward_bootstrap.auth_sso_domain_subject(${tenantId}, ${domain})`);
    const [row] = bootstrapRows(result);
    return row?.sso_required === true;
}
async function requireNonSsoEmailLoginAllowed(c, tenantId, email, methodLabel) {
    if (!(await isSsoRequiredForEmailDomain(tenantId, email)))
        return null;
    return c.json({
        ok: false,
        error: `${methodLabel} login is disabled because this email domain requires SSO`,
    }, 403);
}
async function isVerifiedSsoEmailDomainForTenant(tenantId, email) {
    const domain = normalizeEmailDomain(email);
    if (!domain)
        return false;
    const result = await getDb().execute(sql `SELECT * FROM steward_bootstrap.auth_sso_domain_subject(${tenantId}, ${domain})`);
    const [row] = bootstrapRows(result);
    return Boolean(row);
}
async function authTenantSubject(tenantId, userId) {
    const result = await getDb().execute(sql `SELECT * FROM steward_bootstrap.auth_tenant_subject(${tenantId}, ${userId ?? null}::uuid)`);
    return bootstrapRows(result)[0] ?? null;
}
async function tenantExists(tenantId) {
    return Boolean(await authTenantSubject(tenantId));
}
async function validateExplicitAuthTenantHint(tenantId, explicitHint) {
    if (!explicitHint)
        return null;
    if (!(await tenantExists(tenantId)))
        return `Tenant '${tenantId}' not found`;
    return null;
}
function authTenantHint(c, bodyTenantId) {
    return (c.req.header("X-Steward-Tenant")?.trim() ||
        bodyTenantId?.trim() ||
        defaultAuthTenantId());
}
function smsLoginPurpose(tenantId) {
    return `login:${tenantId}`;
}
function whatsappLoginPurpose(tenantId) {
    return `whatsapp-login:${tenantId}`;
}
// ─── JWT helpers ──────────────────────────────────────────────────────────────
/** Refresh token lifetime: 30 days */
const REFRESH_TOKEN_EXPIRY_DAYS = 30;
async function isActiveTenantMember(userId, tenantId) {
    return withVerifiedAuthTenant(tenantId, userId, async () => {
        const [row] = await getDb()
            .select({ userId: users.id })
            .from(users)
            .innerJoin(userTenants, and(eq(userTenants.userId, users.id), eq(userTenants.tenantId, tenantId)))
            .where(and(eq(users.id, userId), sql `${users.deactivatedAt} is null`));
        return Boolean(row);
    });
}
async function buildIdentityClaims(userId, tenantId) {
    return withVerifiedAuthTenant(tenantId, userId, async () => {
        const db = getDb();
        const [user] = await db.select().from(users).where(eq(users.id, userId));
        if (!user)
            throw new Error("User not found");
        const [tenantMembership] = await db
            .select({ customMetadata: userTenants.customMetadata })
            .from(userTenants)
            .where(and(eq(userTenants.userId, userId), eq(userTenants.tenantId, tenantId)));
        if (!tenantMembership)
            throw new Error("Not a member of this tenant");
        return {
            sub: user.id,
            userId: user.id,
            tenantId,
            email: user.email,
            emailVerified: user.emailVerified,
            name: user.name,
            image: user.image,
            walletAddress: user.walletAddress,
            walletChain: user.walletChain,
            customMetadata: tenantMembership.customMetadata ?? {},
        };
    });
}
function tenantIdentityJwtIssuer(tenantId) {
    return `${getIdentityJwtIssuer()}/tenants/${encodeURIComponent(tenantId)}`;
}
async function createIdentityToken(claims) {
    return signIdentityJwtPayload({
        typ: "identity",
        sub: claims.sub,
        address: claims.walletAddress ?? "",
        userId: claims.userId,
        tenantId: claims.tenantId,
        email: claims.email ?? undefined,
        emailVerified: claims.emailVerified ?? undefined,
        name: claims.name ?? undefined,
        image: claims.image ?? undefined,
        walletAddress: claims.walletAddress ?? undefined,
        walletChain: claims.walletChain ?? undefined,
        customMetadata: claims.customMetadata,
    }, ACCESS_TOKEN_EXPIRY, tenantIdentityJwtIssuer(claims.tenantId));
}
// ─── Refresh token helpers ────────────────────────────────────────────────────
function hashToken(raw) {
    return hashSha256Hex(raw);
}
/**
 * Generate a random refresh token, persist its hash in DB, return the raw value.
 * The raw token is sent to the client; only the hash is stored server-side.
 */
async function createRefreshToken(userId, tenantId, sessionClaims) {
    return withVerifiedAuthTenant(tenantId, userId, async () => {
        const db = getDb();
        const raw = randomBytes(40).toString("hex");
        const id = randomBytes(16).toString("hex");
        const tokenHash = hashToken(raw);
        const expiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRY_DAYS * 86400 * 1000);
        await db
            .insert(refreshTokens)
            .values({ id, userId, tenantId, tokenHash, expiresAt });
        if (sessionClaims && Object.keys(sessionClaims).length > 0) {
            await writeMfaJson(`refresh:claims:${tokenHash}`, sessionClaims, REFRESH_TOKEN_EXPIRY_DAYS * 86400 * 1000);
        }
        return raw;
    });
}
function refreshTokenIssuedAtSeconds(record) {
    return Math.floor(new Date(record.createdAt).getTime() / 1000);
}
async function rotateRefreshTokenForUserSession(raw, requestedTenantId) {
    const subject = await resolveRefreshTokenSubject(hashToken(raw));
    if (!subject)
        return { status: "invalid" };
    return withVerifiedAuthTenant(subject.tenantId, subject.userId, () => rotateRefreshTokenInsideTenant(raw, requestedTenantId));
}
async function resolveRefreshTokenSubject(tokenHash) {
    const result = await getDb().execute(sql `
    SELECT user_id, tenant_id
    FROM steward_bootstrap.auth_refresh_subject(${tokenHash})
  `);
    const [subject] = (Array.isArray(result)
        ? result
        : (result.rows ?? []));
    const used = subject
        ? null
        : await readMfaJson(`refresh:used:${tokenHash}`);
    const tenantId = subject?.tenant_id ?? used?.tenantId;
    const userId = subject?.user_id ?? used?.userId;
    if (!tenantId || !userId)
        return null;
    return { tenantId, userId };
}
async function rotateRefreshTokenInsideTenant(raw, requestedTenantId) {
    const db = getDb();
    const now = new Date();
    const tokenHash = hashToken(raw);
    return db.transaction(async (tx) => {
        const [refreshCandidate] = await tx
            .select({ userId: refreshTokens.userId })
            .from(refreshTokens)
            .where(and(eq(refreshTokens.tokenHash, tokenHash), gte(refreshTokens.expiresAt, now)));
        if (!refreshCandidate) {
            await tx.execute(sql `select pg_advisory_xact_lock(hashtextextended(${`refresh_token_${tokenHash}`}, 0))`);
            const used = await readMfaJson(`refresh:used:${tokenHash}`);
            if (used?.userId && used?.tenantId) {
                await tx
                    .delete(refreshTokens)
                    .where(and(eq(refreshTokens.userId, used.userId), eq(refreshTokens.tenantId, used.tenantId)));
                return {
                    status: "reused",
                    userId: used.userId,
                    tenantId: used.tenantId,
                };
            }
            await tx
                .delete(refreshTokens)
                .where(and(eq(refreshTokens.tokenHash, tokenHash), lt(refreshTokens.expiresAt, now)));
            return { status: "invalid" };
        }
        await lockUserSession(tx, refreshCandidate.userId);
        await tx.execute(sql `select pg_advisory_xact_lock(hashtextextended(${`refresh_token_${tokenHash}`}, 0))`);
        const [record] = await tx
            .select()
            .from(refreshTokens)
            .where(and(eq(refreshTokens.tokenHash, tokenHash), eq(refreshTokens.userId, refreshCandidate.userId), gte(refreshTokens.expiresAt, now)))
            .for("update");
        if (!record) {
            const used = await readMfaJson(`refresh:used:${tokenHash}`);
            if (used?.userId && used?.tenantId) {
                await tx
                    .delete(refreshTokens)
                    .where(and(eq(refreshTokens.userId, used.userId), eq(refreshTokens.tenantId, used.tenantId)));
                return {
                    status: "reused",
                    userId: used.userId,
                    tenantId: used.tenantId,
                };
            }
            await tx
                .delete(refreshTokens)
                .where(and(eq(refreshTokens.tokenHash, tokenHash), lt(refreshTokens.expiresAt, now)));
            return { status: "invalid" };
        }
        const [user] = await tx
            .select()
            .from(users)
            .where(eq(users.id, record.userId))
            .for("update");
        if (user?.deactivatedAt) {
            await tx
                .delete(refreshTokens)
                .where(eq(refreshTokens.userId, record.userId));
            return {
                status: "deactivated",
                userId: record.userId,
                tenantId: record.tenantId,
            };
        }
        const targetTenantId = requestedTenantId ?? record.tenantId;
        const switchesTenant = targetTenantId !== record.tenantId;
        const membership = await authTenantSubject(targetTenantId, record.userId);
        if (!membership?.membership_role) {
            // A refused switch leaves the caller's current session as it was; only
            // a token whose own tenant dropped the user is spent.
            if (!switchesTenant) {
                await tx
                    .delete(refreshTokens)
                    .where(and(eq(refreshTokens.userId, record.userId), eq(refreshTokens.tenantId, record.tenantId)));
            }
            return {
                status: "not_member",
                userId: record.userId,
                tenantId: record.tenantId,
            };
        }
        const revokedBefore = await revocationStore.getUserRevokedBefore(record.userId);
        if (revokedBefore !== null &&
            revokedBefore >= refreshTokenIssuedAtSeconds(record)) {
            await tx
                .delete(refreshTokens)
                .where(eq(refreshTokens.userId, record.userId));
            return {
                status: "revoked",
                userId: record.userId,
                tenantId: record.tenantId,
            };
        }
        const walletAddress = user?.walletAddress ?? "";
        const email = user?.email ?? undefined;
        const storedClaims = (await readMfaJson(`refresh:claims:${record.tokenHash}`)) ?? {};
        // A switch into another tenant is a sign-in to it: that tenant's login
        // methods apply, checked before anything is spent so a refusal keeps the
        // current session.
        if (switchesTenant) {
            const refusal = await tenantSwitchLoginRefusal(targetTenantId, storedClaims);
            if (refusal) {
                return {
                    status: "login_method_disabled",
                    userId: record.userId,
                    tenantId: record.tenantId,
                    error: refusal,
                };
            }
        }
        await getMfaBackend().delete(`refresh:claims:${record.tokenHash}`);
        // MFA freshness is scoped to the tenant where it was performed, as on
        // /user/me/tenants/switch: the switched tenant needs its own step-up.
        const sessionClaims = switchesTenant
            ? withoutTenantMfaClaims(storedClaims)
            : storedClaims;
        const newAccessToken = await createSessionToken(walletAddress, targetTenantId, {
            userId: record.userId,
            ...(email ? { email } : {}),
            ...sessionClaims,
        });
        const newRefreshToken = randomBytes(40).toString("hex");
        const newRefreshTokenHash = hashToken(newRefreshToken);
        const successorId = randomBytes(16).toString("hex");
        // Raw SQL parameters do not receive Drizzle's timestamp column encoder.
        // Keep the driver boundary primitive-only: Neon WebSocket rejects a Date
        // object before PostgreSQL can execute the rotation function.
        const successorExpiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRY_DAYS * 86400 * 1000).toISOString();
        const rotated = bootstrapRows(await tx.execute(sql `
        SELECT * FROM steward_bootstrap.auth_rotate_refresh_token(
          ${tokenHash}, ${targetTenantId}, ${successorId},
          ${newRefreshTokenHash}, ${successorExpiresAt}::timestamptz
        )
      `));
        if (rotated.length !== 1)
            return { status: "invalid" };
        // Keep a bounded predecessor link so a concurrent single-session revoke
        // that started with the just-spent token can delete its rotated successor
        // after acquiring the same user/advisory locks. Otherwise refresh can win
        // the race and leave a live replacement token after sign-out.
        await writeMfaJson(`refresh:used:${tokenHash}`, {
            userId: record.userId,
            tenantId: record.tenantId,
            successorTokenHash: newRefreshTokenHash,
        }, REFRESH_TOKEN_EXPIRY_DAYS * 86400 * 1000);
        if (Object.keys(sessionClaims).length > 0) {
            await writeMfaJson(`refresh:claims:${newRefreshTokenHash}`, sessionClaims, REFRESH_TOKEN_EXPIRY_DAYS * 86400 * 1000);
        }
        return {
            status: "valid",
            record: { ...record, tenantId: targetTenantId },
            newAccessToken,
            newRefreshToken,
        };
    });
}
/** Build the standard dual-token auth response. */
function buildAuthResponse(token, refreshToken, user) {
    return {
        ok: true,
        token,
        refreshToken,
        expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
        user,
    };
}
export { verifySessionToken } from "../services/context.js";
// ─── Nonce store (SIWE / SIWS) ───────────────────────────────────────────────
//
// Backed by the same StoreBackend abstraction the challenge/token stores use,
// so nonces persist across instances on Workers (Upstash) and across restarts
// in production (Postgres `auth_kv_store`). The default is in-memory for
// dev/test — initAuthStores() upgrades it once Redis/Postgres availability
// is known.
//
// TTL matches the previous Map GC interval (5 minutes), enforced by the
// backend itself so no setInterval cleanup is needed.
const SIWE_NONCE_TTL_MS = 5 * 60 * 1000;
function originHostFromRequest(c) {
    const origin = c.req.header("origin") ?? c.req.header("referer");
    if (!origin)
        return undefined;
    try {
        return new URL(origin).host.toLowerCase();
    }
    catch {
        return undefined;
    }
}
function requiredOriginHostFromRequest(c) {
    const originHost = originHostFromRequest(c);
    if (!originHost)
        return null;
    return getAllowedSiweDomains().includes(originHost) ? originHost : null;
}
async function setSiweNonce(nonce, record) {
    await getNonceBackend().set(nonce, JSON.stringify(record), SIWE_NONCE_TTL_MS);
}
/**
 * Atomically consume a SIWE nonce record if the nonce was present and unexpired
 * (and is now deleted).
 *
 * Store backends implement consume atomically where supported, so parallel
 * requests cannot reuse the same signed nonce.
 */
async function consumeSiweNonce(nonce) {
    const raw = await getNonceBackend().consume(nonce);
    if (!raw)
        return null;
    try {
        const parsed = JSON.parse(raw);
        return {
            allowedDomains: Array.isArray(parsed.allowedDomains)
                ? parsed.allowedDomains
                : [],
            originHost: typeof parsed.originHost === "string" ? parsed.originHost : undefined,
            tenantId: typeof parsed.tenantId === "string" ? parsed.tenantId : undefined,
        };
    }
    catch {
        return { allowedDomains: [] };
    }
}
function validateConsumedSiweNonce(record, input) {
    if (!record)
        return "Invalid or expired nonce";
    const domain = input.domain.toLowerCase();
    if (record.allowedDomains.length > 0 &&
        !record.allowedDomains.includes(domain)) {
        return "Nonce was not issued for this SIWE domain";
    }
    if (!record.originHost) {
        return "Nonce was not bound to an origin";
    }
    if (record.originHost !== domain) {
        return "Nonce origin does not match signed domain";
    }
    if (record.tenantId && record.tenantId !== input.tenantId) {
        return "Nonce tenant does not match verification tenant";
    }
    return null;
}
/**
 * Exported for the public agent-enroll routes: enrollment challenges must
 * share this initialized (Redis/Postgres in production) store instead of the
 * auth package's process-local memory singleton (SEC-052).
 */
async function issueEmailGrant(email, tenantId, scope) {
    const grantBytes = new Uint8Array(32);
    crypto.getRandomValues(grantBytes);
    const grant = uint8ArrayToBase64url(grantBytes);
    await getEmailGrantStore().set(emailGrantKey(grant), JSON.stringify({ email, tenantId, scope }));
    return grant;
}
/** Consume (single-use) a grant and return its bound identity, or null. */
async function consumeEmailGrant(grant, email, tenantId) {
    if (!grant || grant.length > 256)
        return false;
    const stored = await getEmailGrantStore().consume(emailGrantKey(grant));
    if (!stored)
        return false;
    try {
        const payload = JSON.parse(stored);
        return payload.email === email && payload.tenantId === tenantId;
    }
    catch {
        return false;
    }
}
/**
 * Peek (non-consuming) at a grant for the options phase. The grant is only
 * CONSUMED at register/verify so a failed/cancelled WebAuthn ceremony does
 * not burn the user's verification.
 */
async function peekEmailGrant(grant, email, tenantId) {
    if (!grant || grant.length > 256)
        return null;
    const stored = await getEmailGrantStore().get(emailGrantKey(grant));
    if (!stored)
        return null;
    try {
        const payload = JSON.parse(stored);
        if (payload.email !== email || payload.tenantId !== tenantId)
            return null;
        if (payload.scope === "personal")
            return "personal";
        // Previously issued grants retain their explicit tenant binding.
        return payload.scope === undefined || payload.scope === "tenant"
            ? "tenant"
            : null;
    }
    catch {
        // error-policy:J3 malformed persisted grants are invalid authentication input.
        return null;
    }
}
const OAUTH_CODE_REDEEM_LOCK_TTL_MS = 10 * 1000;
const OAUTH_CODE_REDEEM_LOCK_CLEANUP_TIMEOUT_MS = 250;
async function lockOAuthCodeRedemption(code) {
    return getOAuthCodeStore().setIfNotExists(`oauth-code-lock:${code}`, "1", OAUTH_CODE_REDEEM_LOCK_TTL_MS);
}
async function releaseOAuthCodeRedemptionLock(code) {
    let cleanupTimer;
    try {
        await Promise.race([
            getOAuthCodeStore().delete(`oauth-code-lock:${code}`),
            new Promise((_, reject) => {
                cleanupTimer = setTimeout(() => reject(new Error("OAuth redemption lock cleanup timed out")), OAUTH_CODE_REDEEM_LOCK_CLEANUP_TIMEOUT_MS);
            }),
        ]);
    }
    catch (error) {
        // Atomic consume is the single-use security boundary. Lock cleanup is
        // advisory because its bounded TTL preserves liveness when deletion is
        // unavailable or does not settle after a terminal consume result.
        logger.warn({
            details: [
                "[OAuthAuth] Redemption lock cleanup failed",
                redactedThrownDiagnostics(error),
            ],
        }, "[Login:auth] warn");
    }
    finally {
        if (cleanupTimer !== undefined)
            clearTimeout(cleanupTimer);
    }
}
async function markOidcIdTokenUsedOnce(tenantId, providerId, token, exp) {
    if (typeof exp !== "number" || !Number.isFinite(exp)) {
        return { ok: false, response: "missing-exp" };
    }
    const ttlMs = Math.floor(exp * 1000 - Date.now());
    if (ttlMs <= 0) {
        return { ok: false, response: "expired" };
    }
    const tokenHash = hashSha256Hex(token);
    const inserted = await getOAuthCodeStore().setIfNotExists(`oidc-id-token:${tenantId}:${providerId}:${tokenHash}`, "1", ttlMs);
    return inserted ? { ok: true } : { ok: false, response: "replayed" };
}
function isUnsafeUnboundOAuthProviderCodeExchangeAllowed() {
    return (process.env.STEWARD_ALLOW_UNBOUND_OAUTH_PROVIDER_CODE_EXCHANGE === "true");
}
function isValidPkceCodeVerifier(value) {
    return /^[A-Za-z0-9._~-]{43,128}$/.test(value);
}
async function pkceChallengeForVerifier(verifier, method) {
    if (method === "plain")
        return verifier;
    if (method !== "S256")
        return null;
    const bytes = new TextEncoder().encode(verifier);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return uint8ArrayToBase64url(new Uint8Array(digest));
}
function authTestInboxEnabled() {
    return process.env.NODE_ENV === "test";
}
function isEnabledTestAccount(value) {
    const testAccount = value;
    return (testAccount?.enabled === true &&
        typeof testAccount.email === "string" &&
        typeof testAccount.phone === "string" &&
        ((typeof testAccount.otpHash === "string" &&
            testAccount.otpHash.length > 0) ||
            (typeof testAccount.otp === "string" && testAccount.otp.length > 0)));
}
function testCredentialMatches(actual, expected) {
    if (!actual || !expected)
        return false;
    return (hashSha256Hex(actual.trim().toLowerCase()) ===
        hashSha256Hex(expected.trim().toLowerCase()));
}
function invalidTestAccountCredentials() {
    return {
        ok: false,
        error: "Invalid test account credentials",
    };
}
/**
 * Map typed email-delivery failures to fail-closed HTTP responses
 * (elizaOS/eliza#18452): 503 when no delivery-capable provider is configured
 * (challenge never issued), 502 when the provider rejected the send (the
 * challenge was already invalidated by EmailAuth). Returns null for any other
 * error so it propagates unchanged. Response bodies are generic — no
 * recipient, token, or provider detail.
 */
function emailDeliveryFailureResponse(c, err) {
    if (err instanceof EmailDeliveryNotConfiguredError) {
        return c.json({ ok: false, error: "Email delivery is not configured" }, 503);
    }
    if (err instanceof EmailDeliveryError) {
        return c.json({ ok: false, error: "Email could not be sent. Please try again later." }, 502);
    }
    return null;
}
function emailMagicLinkVerifySubject(token, email, tenantId) {
    return hashSha256Hex([
        tenantId.trim().toLowerCase(),
        email.trim().toLowerCase(),
        token.trim(),
    ].join(":"));
}
// ─── Vault helper ─────────────────────────────────────────────────────────────
function getVault() {
    return getConfiguredVault();
}
/**
 * Resolve and validate the tenant a user is authenticating into.
 *
 * Priority: X-Steward-Tenant header > body.tenantId > personal-<userId> fallback.
 *
 * When an explicit tenantId is requested:
 *   1. Verify the tenant exists in the `tenants` table (404 if not)
 *   2. Check if user already has a user_tenants link (always allowed if so)
 *   3. Look up join_mode from tenant_configs
 *   4. If join_mode is 'open', auto-link is allowed
 *   5. If join_mode is missing, 'invite', or 'closed', 403
 */
async function resolveAndValidateTenant(c, userId, bodyTenantId) {
    const headerTenant = c.req.header("X-Steward-Tenant")?.trim();
    const requested = headerTenant || bodyTenantId?.trim() || undefined;
    if (!requested) {
        return { ok: true, tenantId: `personal-${userId}`, isPersonal: true };
    }
    if (!isValidTenantId(requested)) {
        return { ok: false, status: 400, error: "Invalid tenant id format" };
    }
    if (isReservedTenantId(requested) && requested !== `personal-${userId}`) {
        return {
            ok: false,
            status: 403,
            error: "Personal tenants cannot be self-joined",
        };
    }
    const subject = await authTenantSubject(requested, userId);
    if (!subject) {
        return { ok: false, status: 404, error: `Tenant '${requested}' not found` };
    }
    // 2. Check if user already has a link (always allowed regardless of join_mode)
    if (subject.membership_role) {
        return { ok: true, tenantId: requested, isPersonal: false };
    }
    // 3. No existing link; check join_mode from tenant_configs
    const joinMode = subject.join_mode;
    if (joinMode === "open") {
        return { ok: true, tenantId: requested, isPersonal: false };
    }
    if (!joinMode) {
        return {
            ok: false,
            status: 403,
            error: `Tenant '${requested}' is not configured for self-join`,
        };
    }
    if (joinMode === "invite") {
        return {
            ok: false,
            status: 403,
            error: `Tenant '${requested}' requires an invitation to join`,
        };
    }
    // joinMode === "closed"
    return {
        ok: false,
        status: 403,
        error: `Tenant '${requested}' is not accepting new members`,
    };
}
async function findOrCreateUserWithStatus(email) {
    const db = getDb();
    const [existing] = await db
        .select()
        .from(users)
        .where(eq(users.email, email));
    if (existing)
        return { user: existing, isNew: false };
    const [newUser] = await db
        .insert(users)
        .values({ email, emailVerified: false })
        .returning();
    return { user: newUser, isNew: true };
}
async function findUserByEmail(email) {
    const [existing] = await getDb()
        .select()
        .from(users)
        .where(eq(users.email, email));
    return existing ?? null;
}
async function resolveEmailTenantBeforeMutation(c, requestedTenantId, existingUserId) {
    if (!requestedTenantId)
        return null;
    if (existingUserId)
        return resolveAndValidateTenant(c, existingUserId, requestedTenantId);
    if (!isValidTenantId(requestedTenantId)) {
        return { ok: false, status: 400, error: "Invalid tenant id format" };
    }
    if (isReservedTenantId(requestedTenantId)) {
        return {
            ok: false,
            status: 403,
            error: "Personal tenants cannot be self-joined",
        };
    }
    const subject = await authTenantSubject(requestedTenantId);
    if (!subject) {
        return {
            ok: false,
            status: 404,
            error: `Tenant '${requestedTenantId}' not found`,
        };
    }
    if (subject.join_mode === "open") {
        return { ok: true, tenantId: requestedTenantId, isPersonal: false };
    }
    return {
        ok: false,
        status: 403,
        error: subject.join_mode === "closed"
            ? `Tenant '${requestedTenantId}' is not accepting new members`
            : subject.join_mode === "invite"
                ? `Tenant '${requestedTenantId}' requires an invitation to join`
                : `Tenant '${requestedTenantId}' is not configured for self-join`,
    };
}
async function findOrCreateWalletUserWithStatus(walletAddress, walletChain) {
    const db = getDb();
    const [existing] = await db
        .select()
        .from(users)
        .where(and(eq(users.walletAddress, walletAddress), eq(users.walletChain, walletChain)));
    if (existing)
        return { user: existing, isNew: false };
    try {
        const [created] = await db
            .insert(users)
            .values({
            walletAddress,
            walletChain,
            email: null,
            emailVerified: false,
        })
            .returning();
        return { user: created, isNew: true };
    }
    catch (error) {
        const [concurrent] = await db
            .select()
            .from(users)
            .where(and(eq(users.walletAddress, walletAddress), eq(users.walletChain, walletChain)));
        if (concurrent)
            return { user: concurrent, isNew: false };
        throw error;
    }
}
async function findOrCreatePhoneUserWithStatus(phone, provider = "phone") {
    const phoneSubject = `phone:${hashSha256Hex(phone)}`;
    const db = getDb();
    // SMS and WhatsApp share one subject, so a link made through either channel
    // marks the number as owned.
    const links = await db
        .select({ provider: accounts.provider, user: users })
        .from(accounts)
        .innerJoin(users, eq(accounts.userId, users.id))
        .where(and(inArray(accounts.provider, ["phone", "whatsapp"]), eq(accounts.providerAccountId, phoneSubject)));
    const linked = links.find((link) => link.provider === provider);
    const [existing] = await db
        .select()
        .from(users)
        .where(eq(users.walletAddress, phoneSubject));
    // Every link and the original phone account must name one user, so neither
    // channel can sign the number in to a different account.
    const owners = new Set(links.map((link) => link.user.id));
    if (existing)
        owners.add(existing.id);
    if (owners.size > 1 || (!linked && !existing && links.length > 0)) {
        throw new ElizaError("Phone login identity needs reconciliation", {
            code: "PHONE_IDENTITY_CONFLICT",
        });
    }
    if (linked)
        return { user: linked.user, isNew: false };
    if (existing)
        return { user: existing, isNew: false };
    const [created] = await db
        .insert(users)
        .values({
        email: null,
        emailVerified: false,
        walletAddress: phoneSubject,
        walletChain: "ethereum",
    })
        .returning();
    return { user: created, isNew: true };
}
async function findOrCreateExternalAccountUserWithStatus(input) {
    const db = getDb();
    const [existingAccount] = await db
        .select({ user: users })
        .from(accounts)
        .innerJoin(users, eq(accounts.userId, users.id))
        .where(and(eq(accounts.provider, input.provider), eq(accounts.providerAccountId, input.providerAccountId)));
    if (existingAccount)
        return { user: existingAccount.user, isNew: false };
    try {
        return await db.transaction(async (tx) => {
            const [raceWinner] = await tx
                .select({ user: users })
                .from(accounts)
                .innerJoin(users, eq(accounts.userId, users.id))
                .where(and(eq(accounts.provider, input.provider), eq(accounts.providerAccountId, input.providerAccountId)));
            if (raceWinner)
                return { user: raceWinner.user, isNew: false };
            const [created] = await tx
                .insert(users)
                .values({
                email: null,
                emailVerified: false,
                name: input.name,
                image: input.image,
            })
                .returning();
            await tx.insert(accounts).values({
                userId: created.id,
                provider: input.provider,
                providerAccountId: input.providerAccountId,
            });
            return { user: created, isNew: true };
        });
    }
    catch (error) {
        const [winner] = await db
            .select({ user: users })
            .from(accounts)
            .innerJoin(users, eq(accounts.userId, users.id))
            .where(and(eq(accounts.provider, input.provider), eq(accounts.providerAccountId, input.providerAccountId)));
        if (winner)
            return { user: winner.user, isNew: false };
        throw error;
    }
}
function dispatchUserCreated(tenantId, userId, source, extra = {}) {
    dispatchWebhook(tenantId, userId, "user.created", {
        userId,
        source,
        ...extra,
    });
}
function dispatchUserAuthenticated(tenantId, userId, authMethod) {
    dispatchWebhook(tenantId, userId, "user.authenticated", {
        userId,
        ...(authMethod ? { authMethod } : {}),
    });
}
async function writeAuthLoginAudit(c, tenantId, userId, claims, metadata = {}) {
    await withVerifiedAuthTenant(tenantId, userId, () => writeAuditEvent({
        tenantId,
        actorType: "user",
        actorId: userId,
        action: "auth.login",
        resourceType: "session",
        metadata: {
            method: typeof claims?.authMethod === "string"
                ? claims.authMethod
                : "unknown",
            ...metadata,
        },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? c.req.header("x-request-id") ?? null,
    }));
}
async function findOrCreateWalletTenant(opts) {
    // The caller has verified the signature before deriving this wallet tenant.
    return withPreAuthTenant(opts.tenantId, "verified-wallet", async () => {
        const db = getDb();
        const [existingTenant] = await db
            .select()
            .from(tenants)
            .where(eq(tenants.ownerAddress, opts.ownerAddress));
        if (existingTenant) {
            return { tenant: existingTenant, isNewTenant: false };
        }
        const apiKeyPair = generateApiKey();
        const [newTenant] = await db
            .insert(tenants)
            .values({
            id: opts.tenantId,
            name: opts.tenantName,
            apiKeyHash: apiKeyPair.hash,
            ownerAddress: opts.ownerAddress,
        })
            .onConflictDoNothing()
            .returning();
        if (newTenant) {
            return {
                tenant: newTenant,
                isNewTenant: true,
                rawApiKey: apiKeyPair.key,
            };
        }
        const [retryTenant] = await db
            .select()
            .from(tenants)
            .where(eq(tenants.ownerAddress, opts.ownerAddress));
        if (retryTenant) {
            return { tenant: retryTenant, isNewTenant: false };
        }
        const [conflictingTenant] = await db
            .select()
            .from(tenants)
            .where(eq(tenants.id, opts.tenantId));
        if (conflictingTenant) {
            throw new Error("Wallet tenant id is already reserved for a different owner");
        }
        throw new Error("Failed to create tenant");
    });
}
function ethereumWalletTenantId(address) {
    return `eth:${address.toLowerCase()}`;
}
function getAllowedSiweDomains() {
    const raw = process.env.SIWE_ALLOWED_DOMAINS?.trim();
    if (raw) {
        const domains = raw
            .split(",")
            .map((entry) => entry.trim().toLowerCase())
            .filter(Boolean);
        if (domains.length > 0)
            return domains;
    }
    const appUrl = process.env.APP_URL?.trim() || "https://eliza.app";
    try {
        return [new URL(appUrl).host.toLowerCase()];
    }
    catch {
        // SEC-144: fail closed. Never derive allowed SIWE domains from the
        // request Host header — a missing or invalid APP_URL must not silently
        // disable domain binding. Set SIWE_ALLOWED_DOMAINS (or a valid APP_URL)
        // explicitly.
        return [];
    }
}
const ALLOWED_SOLANA_CHAIN_IDS = new Set(["solana", "mainnet", "devnet"]);
function isAllowedSiwsUri(uri, domain) {
    if (!uri)
        return false;
    try {
        const parsedUri = new URL(uri);
        if (parsedUri.host !== domain)
            return false;
        if (parsedUri.protocol === "https:")
            return true;
        // http:// is only acceptable for loopback hosts. Production deployments
        // never see localhost here, so the relaxation is naturally scoped to
        // dev / e2e — no env flag needed.
        if (parsedUri.protocol === "http:") {
            const host = parsedUri.hostname;
            return host === "localhost" || host === "127.0.0.1" || host === "::1";
        }
        return false;
    }
    catch {
        return false;
    }
}
function isAllowedSiwsChainId(chainId) {
    if (!chainId)
        return true;
    return ALLOWED_SOLANA_CHAIN_IDS.has(chainId.trim().toLowerCase());
}
function parseSiwsMessage(message) {
    const lines = message.split(/\r?\n/);
    if (lines.length < 2)
        return null;
    const firstLine = lines[0]?.trim();
    const publicKey = lines[1]?.trim();
    const match = firstLine?.match(/^(.*) wants you to sign in with your Solana account:$/);
    if (!match || !publicKey)
        return null;
    const statementLines = [];
    const fields = new Map();
    let inFields = false;
    for (const rawLine of lines.slice(2)) {
        const line = rawLine.trim();
        if (!line)
            continue;
        const fieldMatch = line.match(/^([A-Za-z ]+):\s*(.+)$/);
        if (fieldMatch) {
            inFields = true;
            fields.set(fieldMatch[1].toLowerCase().replace(/\s+/g, ""), fieldMatch[2]);
            continue;
        }
        if (!inFields) {
            statementLines.push(line);
        }
    }
    const nonce = fields.get("nonce");
    if (!nonce)
        return null;
    return {
        domain: match[1].trim(),
        publicKey,
        nonce,
        issuedAt: fields.get("issuedat"),
        expirationTime: fields.get("expirationtime"),
        notBefore: fields.get("notbefore"),
        uri: fields.get("uri"),
        version: fields.get("version"),
        chainId: fields.get("chainid"),
        statement: statementLines.length > 0 ? statementLines.join("\n") : undefined,
    };
}
/**
 * Ensure the user's personal tenant exists.
 * Used as a fallback when no explicit tenant is requested AND as the home for
 * the user's provisioned wallet agent (wallet always lives under personal tenant).
 */
async function ensurePersonalTenant(userId, displayName) {
    const tenantId = `personal-${userId}`;
    return withVerifiedAuthTenant(tenantId, userId, async () => {
        const { hash } = generateApiKey();
        await getDb()
            .insert(tenants)
            .values({ id: tenantId, name: displayName, apiKeyHash: hash })
            .onConflictDoNothing();
        return tenantId;
    });
}
/**
 * Link a user to a tenant in the user_tenants junction table (idempotent).
 * If the tenant doesn't exist yet, silently skips — caller must ensure the
 * tenant exists before calling this.
 */
async function ensureUserTenantLink(userId, tenantId, role = "member") {
    await withVerifiedAuthTenant(tenantId, userId, async () => {
        await getDb()
            .insert(userTenants)
            .values({ userId, tenantId, role })
            .onConflictDoNothing();
    });
}
/**
 * Provision the user's personal wallet (idempotent).
 * The wallet agent always lives under `personal-<userId>` regardless of which
 * tenant the user authenticated through — the JWT tenantId is the requesting
 * tenant, but the wallet itself stays in the personal namespace.
 */
async function provisionWalletForUser(userId, email) {
    const personalTenantId = `personal-${userId}`;
    return withVerifiedAuthTenant(personalTenantId, userId, async () => {
        await ensurePersonalTenant(userId, email);
        const vault = getVault();
        const result = await provisionUserWallet(vault, userId, email, personalTenantId);
        await getDb()
            .update(users)
            .set({
            walletAddress: result.walletAddress,
            stewardWalletId: result.agentId,
        })
            .where(eq(users.id, userId));
        await ensureUserTenantLink(userId, personalTenantId, "owner");
        return { walletAddress: result.walletAddress, personalTenantId };
    });
}
// ─── Request body helper ──────────────────────────────────────────────────────
async function safeJsonParse(c) {
    try {
        return await c.req.json();
    }
    catch {
        return null;
    }
}
async function requireSession(c) {
    const authHeader = c.req.header("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
        return {
            ok: false,
            response: c.json({ ok: false, error: "Authorization header required" }, 401),
        };
    }
    const token = authHeader.slice(7);
    const payload = await verifySessionToken(token);
    if (!payload) {
        return {
            ok: false,
            response: c.json({ ok: false, error: "Invalid or expired token" }, 401),
        };
    }
    if (!payload.userId) {
        return {
            ok: false,
            response: c.json({ ok: false, error: "Token does not contain userId" }, 400),
        };
    }
    return { ok: true, token, payload: { ...payload, userId: payload.userId } };
}
async function hasAnyDurableFactor(userId) {
    if (await hasTotpEnabled(userId))
        return true;
    if (await getSmsMfa(userId))
        return true;
    const [passkey] = await getDb()
        .select({ id: authenticators.id })
        .from(authenticators)
        .where(eq(authenticators.userId, userId))
        .limit(1);
    return Boolean(passkey);
}
function sessionHasRecentFactorEnrollmentStepUp(session, existingDurableFactor) {
    const now = Date.now();
    if (typeof session.payload.mfaVerifiedAt === "number" &&
        now - session.payload.mfaVerifiedAt >= 0 &&
        now - session.payload.mfaVerifiedAt <= FACTOR_ENROLLMENT_STEP_UP_MAX_AGE_MS) {
        return true;
    }
    if (existingDurableFactor && session.payload.authMethod !== "passkey") {
        return false;
    }
    if (typeof session.payload.factorEnrollmentVerifiedAt === "number" &&
        Number.isFinite(session.payload.factorEnrollmentVerifiedAt) &&
        now - session.payload.factorEnrollmentVerifiedAt >= 0 &&
        now - session.payload.factorEnrollmentVerifiedAt <=
            FACTOR_ENROLLMENT_STEP_UP_MAX_AGE_MS) {
        return true;
    }
    return false;
}
async function requireRecentFactorEnrollmentStepUp(c, session) {
    const existingDurableFactor = await hasAnyDurableFactor(session.payload.userId);
    if (sessionHasRecentFactorEnrollmentStepUp(session, existingDurableFactor))
        return null;
    return c.json({
        ok: false,
        error: "Recent sign-in, MFA, or passkey re-authentication is required",
    }, 403);
}
/** Fail app construction before health/readiness can accept malformed Verify config. */
export function validatePhoneAuthProviderEnvironment(env = process.env) {
    buildPhoneAuthProvidersFromEnvironment(env);
}
function isWhatsAppOtpEnabled() {
    return process.env.WHATSAPP_OTP_ENABLED === "true";
}
function isFarcasterLoginEnabled() {
    return process.env.FARCASTER_LOGIN_ENABLED === "true";
}
const TELEGRAM_LOGIN_MAX_AGE_SEC = 24 * 60 * 60;
const TELEGRAM_LOGIN_CHALLENGE_TTL_MS = 5 * 60 * 1000;
async function requiredTelegramOriginHostFromRequest(c, tenantId) {
    const originHost = originHostFromRequest(c);
    if (!originHost)
        return null;
    if (!tenantId) {
        return getAllowedSiweDomains().includes(originHost) ? originHost : null;
    }
    const config = await authTenantConfigSubject(tenantId);
    for (const allowedOrigin of config?.allowed_origins ?? []) {
        if (allowedOrigin.trim() === "*")
            continue;
        try {
            if (new URL(allowedOrigin).host.toLowerCase() === originHost)
                return originHost;
        }
        catch { }
    }
    return null;
}
function telegramLoginChallengeKey(challengeId) {
    return `telegram-login-challenge:${hashSha256Hex(challengeId)}`;
}
async function createTelegramLoginChallenge(record) {
    const challengeId = uint8ArrayToBase64url(randomBytes(32));
    const expiresAt = Date.now() + TELEGRAM_LOGIN_CHALLENGE_TTL_MS;
    await getNonceBackend().set(telegramLoginChallengeKey(challengeId), JSON.stringify({ ...record, issuedAt: Date.now() }), TELEGRAM_LOGIN_CHALLENGE_TTL_MS);
    return { challengeId, expiresAt };
}
async function consumeTelegramLoginChallenge(challengeId) {
    const raw = await getNonceBackend().consume(telegramLoginChallengeKey(challengeId));
    if (!raw)
        return null;
    try {
        const parsed = JSON.parse(raw);
        return {
            tenantId: typeof parsed.tenantId === "string" ? parsed.tenantId : undefined,
            originHost: typeof parsed.originHost === "string" ? parsed.originHost : undefined,
            issuedAt: typeof parsed.issuedAt === "number" ? parsed.issuedAt : 0,
        };
    }
    catch {
        return null;
    }
}
function validateConsumedTelegramLoginChallenge(record, input) {
    if (!record)
        return "Invalid or expired Telegram login challenge";
    if (record.tenantId !== input.tenantId) {
        return "Telegram login challenge tenant does not match verification tenant";
    }
    if (!record.originHost) {
        return "Telegram login challenge was not bound to an origin";
    }
    if (record.originHost !== input.originHost) {
        return "Telegram login challenge origin does not match verification origin";
    }
    return null;
}
async function consumeTelegramLoginHashOnce(hash, authDate) {
    const expiresAtMs = (authDate + TELEGRAM_LOGIN_MAX_AGE_SEC) * 1000;
    const ttlMs = Math.max(1_000, expiresAtMs - Date.now());
    return getMfaBackend().setIfNotExists(`telegram-login:${hashSha256Hex(hash.toLowerCase())}`, "1", ttlMs);
}
const TOTP_PENDING_TTL_MS = 10 * 60 * 1000;
const TOTP_ENABLED_TTL_MS = 10 * 365 * 24 * 60 * 60 * 1000;
const MFA_AUTH_CHALLENGE_TTL_MS = 5 * 60 * 1000;
const MFA_TOTP_STEP_CLAIM_TTL_MS = 10 * 60 * 1000;
const TOTP_STEP_SEC = 30;
function mfaKey(kind, userId) {
    return `${kind}:${userId}`;
}
function recoveryCodeConsumeKey(codeId) {
    return `recovery:code:${codeId}`;
}
function totpStepClaimKey(userId, step) {
    return `totp:step:${userId}:${step}`;
}
function smsMfaEnrollPurpose(userId) {
    return `mfa:sms:enroll:${userId}`;
}
function smsMfaManagePurpose(userId) {
    return `mfa:sms:manage:${userId}`;
}
function smsMfaChallengePurpose(challengeId) {
    return `mfa:sms:challenge:${challengeId}`;
}
function encryptMfaJson(value) {
    return JSON.stringify(getOAuthKeyStore().encrypt(JSON.stringify(value)));
}
function decryptMfaJson(value) {
    const encrypted = JSON.parse(value);
    return JSON.parse(getOAuthKeyStore().decrypt(encrypted));
}
async function readMfaJson(key) {
    const raw = await getMfaBackend().get(key);
    if (!raw)
        return null;
    try {
        return decryptMfaJson(raw);
    }
    catch (cause) {
        // An unreadable record is a key-store or payload failure, not proof that
        // the user has no second factor. Deleting it here would erase the
        // enrollment and make every caller read "absent", so a login would skip
        // the MFA challenge. Keep the bytes and fail closed instead.
        const kind = key.split(":")[0];
        throw new ElizaError(`Stored ${kind} MFA record cannot be read.`, {
            code: "MFA_RECORD_UNREADABLE",
            cause,
            context: { kind },
            severity: "ephemeral",
        });
    }
}
async function writeMfaJson(key, value, ttlMs = TOTP_ENABLED_TTL_MS) {
    await getMfaBackend().set(key, encryptMfaJson(value), ttlMs);
}
function totpStepForDrift(drift) {
    return Math.floor(Date.now() / 1000 / TOTP_STEP_SEC) + drift;
}
async function verifyStoredTotp(userId, code) {
    const stored = await readMfaJson(mfaKey("totp:enabled", userId));
    if (!stored)
        return { valid: false };
    const result = await verifyTotp(stored.secret, code, {
        stepSec: TOTP_STEP_SEC,
    });
    if (!result.valid || typeof result.drift !== "number")
        return { valid: false };
    const acceptedStep = totpStepForDrift(result.drift);
    if (stored.lastAcceptedStep !== null &&
        acceptedStep <= stored.lastAcceptedStep) {
        return { valid: false };
    }
    const claimed = await getMfaBackend().setIfNotExists(totpStepClaimKey(userId, acceptedStep), "claimed", MFA_TOTP_STEP_CLAIM_TTL_MS);
    if (!claimed)
        return { valid: false };
    return { valid: true, stored, acceptedStep };
}
class MfaRecoveryCodeStore {
    async replaceForUser(userId, codes) {
        const issuedAt = Date.now();
        const rows = codes.map((code, idx) => ({
            id: `${userId}:${issuedAt}:${idx}`,
            hash: code.hash,
            salt: code.salt,
            usedAt: null,
        }));
        await writeMfaJson(mfaKey("recovery", userId), rows);
        await Promise.all(rows.map((row) => getMfaBackend().set(recoveryCodeConsumeKey(row.id), "unused", TOTP_ENABLED_TTL_MS)));
    }
    async listForUser(userId) {
        const rows = await readMfaJson(mfaKey("recovery", userId));
        return (rows ?? []).map((row) => ({
            ...row,
            usedAt: row.usedAt ? new Date(row.usedAt) : null,
        }));
    }
    async markUsed(id, usedAt) {
        const consumed = await getMfaBackend().consume(recoveryCodeConsumeKey(id));
        if (!consumed)
            return false;
        const userId = id.split(":")[0];
        if (!userId)
            return false;
        const rows = (await readMfaJson(mfaKey("recovery", userId))) ?? [];
        const next = rows.map((row) => row.id === id ? { ...row, usedAt: usedAt.toISOString() } : row);
        await writeMfaJson(mfaKey("recovery", userId), next);
        return true;
    }
}
const recoveryCodeStore = process.env.NODE_ENV === "test"
    ? new InMemoryRecoveryCodeStore()
    : new MfaRecoveryCodeStore();
function passkeyMfaChallengeKey(userId, challengeId) {
    return `mfa:passkey:${userId}:${challengeId}`;
}
async function hasTotpEnabled(userId) {
    return Boolean(await readMfaJson(mfaKey("totp:enabled", userId)));
}
async function getSmsMfa(userId) {
    return readMfaJson(mfaKey("sms:enabled", userId));
}
async function currentSessionMfaStepUpResponse(c, session, method) {
    if (!(await isActiveTenantMember(session.payload.userId, session.payload.tenantId))) {
        return c.json({ ok: false, error: "User is not a member of this tenant" }, 403);
    }
    const [user] = await getDb()
        .select({
        id: users.id,
        email: users.email,
        walletAddress: users.walletAddress,
        walletChain: users.walletChain,
    })
        .from(users)
        .where(eq(users.id, session.payload.userId));
    const mfaClaims = {
        mfaVerifiedAt: Date.now(),
        mfaMethod: method,
        factorEnrollmentVerifiedAt: Date.now(),
    };
    const token = await createSessionToken(session.payload.address, session.payload.tenantId, {
        userId: session.payload.userId,
        email: session.payload.email,
        authMethod: session.payload.authMethod,
        ...mfaClaims,
    });
    const refreshToken = await createRefreshToken(session.payload.userId, session.payload.tenantId, mfaClaims);
    return c.json(buildAuthResponse(token, refreshToken, {
        id: user?.id ?? session.payload.userId,
        email: user?.email ?? session.payload.email ?? "",
        walletAddress: user?.walletAddress ?? session.payload.address,
        walletChain: user?.walletChain ?? undefined,
    }));
}
async function createMfaAuthChallenge(payload) {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    const challengeId = uint8ArrayToBase64url(bytes);
    const expiresAt = Date.now() + MFA_AUTH_CHALLENGE_TTL_MS;
    await writeMfaJson(`auth:challenge:${challengeId}`, { ...payload, expiresAt }, MFA_AUTH_CHALLENGE_TTL_MS);
    return { challengeId, expiresAt };
}
async function buildAuthOrMfaResponse(userId, tenantId, address, claims, user, c) {
    const sessionClaims = {
        ...claims,
        factorEnrollmentVerifiedAt: Date.now(),
    };
    const [activeUser] = await getDb()
        .select({ deactivatedAt: users.deactivatedAt })
        .from(users)
        .where(eq(users.id, userId));
    if (activeUser?.deactivatedAt) {
        return { ok: false, status: 403, error: "User is deactivated" };
    }
    if (await hasTotpEnabled(userId)) {
        const challenge = await createMfaAuthChallenge({
            mfaType: "totp",
            userId,
            tenantId,
            address,
            claims: sessionClaims,
            user,
        });
        return {
            ok: true,
            mfaRequired: true,
            mfa: {
                type: "totp",
                challengeId: challenge.challengeId,
                expiresAt: new Date(challenge.expiresAt).toISOString(),
            },
            user,
        };
    }
    const smsMfa = await getSmsMfa(userId);
    if (smsMfa) {
        const challenge = await createMfaAuthChallenge({
            mfaType: "sms",
            userId,
            tenantId,
            address,
            claims: sessionClaims,
            user,
        });
        const { expiresAt } = await getPhoneAuth().sendOtp(smsMfa.phone, smsMfaChallengePurpose(challenge.challengeId), "sms");
        return {
            ok: true,
            mfaRequired: true,
            mfa: {
                type: "sms",
                challengeId: challenge.challengeId,
                expiresAt: expiresAt.toISOString(),
            },
            user,
        };
    }
    if (c) {
        await writeAuthLoginAudit(c, tenantId, userId, claims);
    }
    const token = await createSessionToken(address, tenantId, sessionClaims);
    const refreshToken = await createRefreshToken(userId, tenantId, sessionClaims);
    dispatchUserAuthenticated(tenantId, userId, typeof claims.authMethod === "string" ? claims.authMethod : undefined);
    return buildAuthResponse(token, refreshToken, user);
}
function authExchangeJson(c, response) {
    if (response.ok === false && typeof response.error === "string") {
        const status = typeof response.status === "number" &&
            response.status >= 400 &&
            response.status < 600
            ? response.status
            : 400;
        return c.json({ ok: false, error: response.error }, status);
    }
    return c.json(response);
}
function setAuthNoStoreHeaders(c) {
    c.header("Cache-Control", "no-store, max-age=0");
    c.header("Pragma", "no-cache");
    c.header("Expires", "0");
}
const DEVICE_AUTH_TTL_MS = 10 * 60 * 1000;
const DEVICE_AUTH_DEFAULT_INTERVAL_SECONDS = 5;
const DEVICE_AUTH_MAX_SLOW_DOWNS = 3;
function normalizeDeviceUserCode(value) {
    if (typeof value !== "string")
        return undefined;
    const normalized = value.trim().toUpperCase().replace(/[\s-]/g, "");
    return /^[A-Z0-9]{8}$/.test(normalized) ? normalized : undefined;
}
function displayDeviceUserCode(value) {
    return `${value.slice(0, 4)}-${value.slice(4)}`;
}
function generateDeviceUserCode() {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const bytes = new Uint8Array(8);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join("");
}
function deviceCodeKey(deviceCode) {
    return `device-auth:device:${hashSha256Hex(deviceCode)}`;
}
function deviceUserCodeKey(userCode) {
    return `device-auth:user:${hashSha256Hex(userCode)}`;
}
async function getEnabledTenantAppClient(tenantId, clientId) {
    const client = (await authAppClientSubjects(tenantId)).find((row) => row.id === clientId);
    return client
        ? {
            id: client.id,
            allowedBundleIds: client.allowed_bundle_ids,
            allowedPackageNames: client.allowed_package_names,
        }
        : null;
}
function normalizeNativeBundleId(value) {
    if (typeof value !== "string")
        return null;
    const bundleId = value.trim();
    if (bundleId.length === 0 ||
        bundleId === "*" ||
        bundleId.length > 255 ||
        !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?)+$/.test(bundleId)) {
        return null;
    }
    return bundleId;
}
function normalizeNativePackageName(value) {
    if (typeof value !== "string")
        return null;
    const packageName = value.trim().toLowerCase();
    if (packageName.length === 0 ||
        packageName === "*" ||
        packageName.length > 255 ||
        !/^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$/.test(packageName)) {
        return null;
    }
    return packageName;
}
function readNativeClientAssertion(c, body) {
    return {
        rawBundleId: body?.native_bundle_id ??
            body?.nativeBundleId ??
            body?.bundle_id ??
            body?.bundleId ??
            c.req.header("X-Steward-Native-Bundle-Id"),
        rawPackageName: body?.native_package_name ??
            body?.nativePackageName ??
            body?.package_name ??
            body?.packageName ??
            c.req.header("X-Steward-Native-Package-Name"),
    };
}
async function assertDeviceAuthTenantAndClient(tenantId, rawClientId, nativeAssertion) {
    if (!isValidTenantId(tenantId)) {
        return { ok: false, status: 400, error: "Invalid tenant id" };
    }
    if (!(await tenantExists(tenantId))) {
        return { ok: false, status: 404, error: `Tenant '${tenantId}' not found` };
    }
    if (rawClientId === undefined || rawClientId === null || rawClientId === "") {
        return { ok: true };
    }
    const clientId = normalizePublicClientId(rawClientId);
    if (!clientId)
        return { ok: false, status: 400, error: "client_id is invalid" };
    const client = await getEnabledTenantAppClient(tenantId, clientId);
    if (!client) {
        return {
            ok: false,
            status: 404,
            error: "App client not found or disabled",
        };
    }
    const nativeBundleId = nativeAssertion?.rawBundleId === undefined
        ? undefined
        : normalizeNativeBundleId(nativeAssertion.rawBundleId);
    if (nativeAssertion?.rawBundleId !== undefined && !nativeBundleId) {
        return { ok: false, status: 400, error: "native bundle id is invalid" };
    }
    const nativePackageName = nativeAssertion?.rawPackageName === undefined
        ? undefined
        : normalizeNativePackageName(nativeAssertion.rawPackageName);
    if (nativeAssertion?.rawPackageName !== undefined && !nativePackageName) {
        return { ok: false, status: 400, error: "native package name is invalid" };
    }
    if (nativeBundleId &&
        !(client.allowedBundleIds ?? []).includes(nativeBundleId)) {
        return {
            ok: false,
            status: 400,
            error: "native bundle id is not allowed for this app client",
        };
    }
    if (nativePackageName &&
        !(client.allowedPackageNames ?? []).includes(nativePackageName)) {
        return {
            ok: false,
            status: 400,
            error: "native package name is not allowed for this app client",
        };
    }
    return {
        ok: true,
        clientId,
        ...(nativeBundleId ? { nativeBundleId } : {}),
        ...(nativePackageName ? { nativePackageName } : {}),
    };
}
async function saveDeviceAuthorizationRecord(deviceCode, record) {
    await saveDeviceAuthorizationRecordByHash(hashSha256Hex(deviceCode), record);
}
async function saveDeviceAuthorizationRecordByHash(deviceCodeHash, record) {
    const ttlMs = Math.max(1_000, record.expiresAt - Date.now());
    await writeMfaJson(`device-auth:device:${deviceCodeHash}`, record, ttlMs);
    await getMfaBackend().set(deviceUserCodeKey(record.userCode), deviceCodeHash, ttlMs);
}
async function readDeviceAuthorizationRecord(deviceCode) {
    const record = await readMfaJson(deviceCodeKey(deviceCode));
    if (!record)
        return null;
    if (record.expiresAt <= Date.now()) {
        await getMfaBackend().delete(deviceCodeKey(deviceCode));
        await getMfaBackend().delete(deviceUserCodeKey(record.userCode));
        return null;
    }
    return record;
}
async function consumeDeviceAuthorizationRecord(deviceCode) {
    const raw = await getMfaBackend().consume(deviceCodeKey(deviceCode));
    if (!raw)
        return null;
    try {
        const record = decryptMfaJson(raw);
        await getMfaBackend().delete(deviceUserCodeKey(record.userCode));
        if (record.expiresAt <= Date.now())
            return null;
        return record;
    }
    catch {
        return null;
    }
}
async function readDeviceAuthorizationRecordByUserCode(userCode) {
    const deviceCodeHash = await getMfaBackend().get(deviceUserCodeKey(userCode));
    if (!deviceCodeHash)
        return null;
    const record = await readMfaJson(`device-auth:device:${deviceCodeHash}`);
    if (!record) {
        await getMfaBackend().delete(deviceUserCodeKey(userCode));
        return null;
    }
    if (record.expiresAt <= Date.now()) {
        await getMfaBackend().delete(`device-auth:device:${deviceCodeHash}`);
        await getMfaBackend().delete(deviceUserCodeKey(userCode));
        return null;
    }
    return { deviceCodeHash, record };
}
async function getTenantOidcProviders(tenantId) {
    const config = await authTenantConfigSubject(tenantId);
    // Revalidate persisted JSON on every trust-boundary read. Older rows can
    // predate write-time validation; treating their TypeScript cast as trusted
    // would re-enable unsafe algorithms or malformed endpoint configuration.
    const normalized = normalizeOidcProviders(config?.oidc_providers ?? [], tenantId);
    return typeof normalized === "string" ? [] : normalized;
}
function selectOidcProvider(providers, providerId) {
    const enabled = providers.filter((provider) => provider.enabled !== false);
    if (providerId)
        return enabled.find((provider) => provider.id === providerId) ?? null;
    return enabled.length === 1 ? enabled[0] : null;
}
async function validateOidcJitTenant(tenantId) {
    if (!isValidTenantId(tenantId)) {
        return { ok: false, status: 403, error: "Invalid tenant id format" };
    }
    if (isReservedTenantId(tenantId)) {
        return {
            ok: false,
            status: 403,
            error: "Personal tenants cannot be self-joined",
        };
    }
    const subject = await authTenantSubject(tenantId);
    if (!subject)
        return { ok: false, status: 404, error: `Tenant '${tenantId}' not found` };
    if (subject.join_mode === "open")
        return { ok: true };
    if (!subject.join_mode) {
        return {
            ok: false,
            status: 403,
            error: `Tenant '${tenantId}' is not configured for self-join`,
        };
    }
    if (subject.join_mode === "invite") {
        return {
            ok: false,
            status: 403,
            error: `Tenant '${tenantId}' requires an invitation to join`,
        };
    }
    return {
        ok: false,
        status: 403,
        error: `Tenant '${tenantId}' is not accepting new members`,
    };
}
async function provisionOidcUser(opts) {
    const { c, tenantId, provider, subject, email, emailVerified, name, picture, tenantRole, } = opts;
    const db = getDb();
    const providerAccountId = hashSha256Hex(`${tenantId}:${provider.id}:${provider.issuer}:${subject}`);
    const providerName = "oidc";
    try {
        if (emailVerified === true && email) {
            const authAbuseConfig = await getTenantAuthAbuseConfig(tenantId);
            const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
            if (emailPolicyError) {
                return { ok: false, status: 400, error: emailPolicyError };
            }
        }
        const [existingAccount] = await db
            .select({ userId: accounts.userId })
            .from(accounts)
            .where(and(eq(accounts.provider, providerName), eq(accounts.providerAccountId, providerAccountId)));
        let user;
        let createdUser = false;
        if (existingAccount) {
            const [existingUser] = await db
                .select()
                .from(users)
                .where(eq(users.id, existingAccount.userId));
            if (!existingUser)
                return { ok: false, status: 500, error: "OIDC account user missing" };
            user = existingUser;
        }
        else {
            if (provider.allowJitProvisioning === false) {
                return {
                    ok: false,
                    status: 403,
                    error: "OIDC JIT provisioning is disabled",
                };
            }
            const jitTenant = await validateOidcJitTenant(tenantId);
            if (!jitTenant.ok)
                return jitTenant;
            const [created] = await db
                .insert(users)
                .values({
                email: null,
                emailVerified: false,
                name,
                image: picture,
            })
                .returning();
            user = created;
            await db
                .insert(accounts)
                .values({ userId: user.id, provider: providerName, providerAccountId });
            createdUser = true;
        }
        const updates = {};
        if (!user.name && name)
            updates.name = name;
        if (!user.image && picture)
            updates.image = picture;
        if (Object.keys(updates).length > 0) {
            await db.update(users).set(updates).where(eq(users.id, user.id));
            user = { ...user, ...updates };
        }
        const tenantResult = await resolveAndValidateTenant(c, user.id, tenantId);
        if (!tenantResult.ok) {
            return {
                ok: false,
                status: tenantResult.status,
                error: tenantResult.error,
            };
        }
        await ensureUserTenantLink(user.id, tenantResult.tenantId, tenantRole ?? "member");
        let walletAddress = user.walletAddress;
        const syntheticEmail = `oidc.${provider.id}.${providerAccountId}@id.steward.internal`;
        try {
            const wallet = await provisionWalletForUser(user.id, syntheticEmail);
            walletAddress = wallet.walletAddress;
        }
        catch (err) {
            logger.error({
                details: [
                    `[OidcAuth:${provider.id}] Wallet provision failed`,
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:auth] error");
            return { ok: false, status: 500, error: "Wallet provisioning failed" };
        }
        const verifiedEmail = emailVerified === true ? email : undefined;
        const claims = {
            userId: user.id,
            oidcProviderId: provider.id,
            oidcSubject: subject,
            emailVerified: emailVerified === true,
            authMethod: "oidc",
        };
        if (verifiedEmail)
            claims.email = verifiedEmail;
        await withVerifiedAuthTenant(tenantResult.tenantId, user.id, async () => {
            if (createdUser) {
                dispatchUserCreated(tenantResult.tenantId, user.id, "auth.oidc", {
                    provider: provider.id,
                    hasEmail: Boolean(verifiedEmail),
                });
            }
            await writeAuditEvent({
                tenantId: tenantResult.tenantId,
                actorType: "user",
                actorId: user.id,
                action: "auth.oidc.login",
                resourceType: "user",
                metadata: {
                    providerId: provider.id,
                    issuer: provider.issuer,
                    oidcSubject: subject,
                },
                ipAddress: c.req.header("x-forwarded-for") ?? null,
                userAgent: c.req.header("user-agent") ?? null,
                requestId: c.get("requestId") ?? null,
            });
        });
        return {
            ok: true,
            userId: user.id,
            response: await buildAuthOrMfaResponse(user.id, tenantResult.tenantId, walletAddress ?? "", claims, {
                id: user.id,
                email: verifiedEmail ?? syntheticEmail,
                emailVerified: emailVerified === true,
                walletAddress,
                oidcProviderId: provider.id,
            }),
        };
    }
    catch (err) {
        logger.error({
            details: [
                `[OidcAuth:${provider.id}] provisionOidcUser failed`,
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return {
            ok: false,
            error: "Internal server error",
        };
    }
}
async function provisionSamlUser(opts) {
    const { c, tenantId, config, subject, email, groups = [], tenantRole } = opts;
    const db = getDb();
    const providerAccountId = hashSha256Hex(`${tenantId}:${config.idpEntityId}:${subject}`);
    const providerName = "saml";
    try {
        const authAbuseConfig = await getTenantAuthAbuseConfig(tenantId);
        const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
        if (emailPolicyError)
            return { ok: false, status: 400, error: emailPolicyError };
        const [existingAccount] = await db
            .select({ userId: accounts.userId })
            .from(accounts)
            .where(and(eq(accounts.provider, providerName), eq(accounts.providerAccountId, providerAccountId)));
        let user;
        let createdUser = false;
        if (existingAccount) {
            const [existingUser] = await db
                .select()
                .from(users)
                .where(eq(users.id, existingAccount.userId));
            if (!existingUser)
                return { ok: false, status: 500, error: "SAML account user missing" };
            user = existingUser;
        }
        else {
            if (!config.allowJitProvisioning) {
                return {
                    ok: false,
                    status: 403,
                    error: "SAML JIT provisioning is disabled",
                };
            }
            const jitTenant = await validateOidcJitTenant(tenantId);
            if (!jitTenant.ok)
                return jitTenant;
            const [existingEmailUser] = await db
                .select()
                .from(users)
                .where(eq(users.email, email));
            if (existingEmailUser) {
                user = existingEmailUser;
            }
            else {
                const [created] = await db
                    .insert(users)
                    .values({ email, emailVerified: true })
                    .returning();
                user = created;
                createdUser = true;
            }
            await db
                .insert(accounts)
                .values({ userId: user.id, provider: providerName, providerAccountId })
                .onConflictDoNothing();
        }
        if (user.email !== email || user.emailVerified !== true) {
            await db
                .update(users)
                .set({ email, emailVerified: true })
                .where(eq(users.id, user.id));
            user = { ...user, email, emailVerified: true };
        }
        const tenantResult = await resolveAndValidateTenant(c, user.id, tenantId);
        if (!tenantResult.ok) {
            return {
                ok: false,
                status: tenantResult.status,
                error: tenantResult.error,
            };
        }
        await ensureUserTenantLink(user.id, tenantResult.tenantId, tenantRole ?? resolveSamlMappedRole(config, groups));
        let walletAddress = user.walletAddress;
        try {
            const wallet = await provisionWalletForUser(user.id, email);
            walletAddress = wallet.walletAddress;
        }
        catch (err) {
            logger.error({
                details: [
                    "[SamlAuth] Wallet provision failed",
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:auth] error");
            return { ok: false, status: 500, error: "Wallet provisioning failed" };
        }
        await withVerifiedAuthTenant(tenantResult.tenantId, user.id, async () => {
            if (createdUser) {
                dispatchUserCreated(tenantResult.tenantId, user.id, "auth.saml", {
                    idpEntityId: config.idpEntityId,
                });
            }
            await writeAuditEvent({
                tenantId: tenantResult.tenantId,
                actorType: "user",
                actorId: user.id,
                action: "auth.saml.login",
                resourceType: "user",
                metadata: { idpEntityId: config.idpEntityId },
                ipAddress: c.req.header("x-forwarded-for") ?? null,
                userAgent: c.req.header("user-agent") ?? null,
                requestId: c.get("requestId") ?? null,
            });
        });
        return {
            ok: true,
            userId: user.id,
            response: await buildAuthOrMfaResponse(user.id, tenantResult.tenantId, walletAddress ?? "", {
                userId: user.id,
                samlSubject: subject,
                authMethod: "saml",
                email,
                emailVerified: true,
            }, { id: user.id, email, emailVerified: true, walletAddress }),
        };
    }
    catch (err) {
        logger.error({
            details: [
                "[SamlAuth] provisionSamlUser failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return { ok: false, error: "Internal server error" };
    }
}
async function completeEmailAuth(c, email, tenantId, opts = {}) {
    const hintedTenantId = c.req.header("X-Steward-Tenant") || tenantId || defaultAuthTenantId();
    const hintedAuthAbuseConfig = await getTenantAuthAbuseConfig(hintedTenantId);
    const hintedEmailPolicyError = validateEmailAbusePolicy(email, hintedAuthAbuseConfig);
    if (hintedEmailPolicyError) {
        return { ok: false, status: 403, error: hintedEmailPolicyError };
    }
    const requestedTenantId = c.req.header("X-Steward-Tenant")?.trim() || tenantId?.trim() || undefined;
    const existingUser = await findUserByEmail(email);
    const preResolvedTenant = opts.allowTenantJoin && tenantId
        ? null
        : await resolveEmailTenantBeforeMutation(c, requestedTenantId, existingUser?.id ?? null);
    if (preResolvedTenant && !preResolvedTenant.ok) {
        return {
            ok: false,
            status: preResolvedTenant.status,
            error: preResolvedTenant.error,
        };
    }
    if (preResolvedTenant?.ok) {
        const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, preResolvedTenant.tenantId, email, "Email");
        if (ssoRequiredResponse) {
            return {
                ok: false,
                status: 403,
                error: "Email login is disabled because this email domain requires SSO",
            };
        }
    }
    const { user, isNew } = await findOrCreateUserWithStatus(email);
    const db = getDb();
    await db
        .update(users)
        .set({ emailVerified: true })
        .where(eq(users.id, user.id));
    // Provision wallet (idempotent, always under personal tenant)
    let walletAddress = user.walletAddress;
    try {
        const w = await provisionWalletForUser(user.id, email);
        walletAddress = w.walletAddress;
    }
    catch (err) {
        logger.error({
            details: [
                "[EmailAuth] Wallet provision failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
    }
    // Resolve requesting tenant and link user.
    let resolvedTenantId;
    if (opts.allowTenantJoin && tenantId) {
        if (!isValidTenantId(tenantId)) {
            return { ok: false, status: 400, error: "Invalid tenant id format" };
        }
        if (!(await tenantExists(tenantId))) {
            return {
                ok: false,
                status: 404,
                error: `Tenant '${tenantId}' not found`,
            };
        }
        resolvedTenantId = tenantId;
    }
    else {
        const tenantResult = preResolvedTenant ??
            (await resolveAndValidateTenant(c, user.id, tenantId));
        if (!tenantResult.ok) {
            return {
                ok: false,
                status: tenantResult.status,
                error: tenantResult.error,
            };
        }
        resolvedTenantId = tenantResult.tenantId;
    }
    const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
    const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
    if (emailPolicyError) {
        return { ok: false, status: 403, error: emailPolicyError };
    }
    const userPolicyError = validateUserAuthAbusePolicy(user.id, authAbuseConfig);
    if (userPolicyError) {
        return { ok: false, status: 403, error: userPolicyError };
    }
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse) {
        return {
            ok: false,
            status: 403,
            error: "Email login is disabled because this email domain requires SSO",
        };
    }
    await ensureUserTenantLink(user.id, resolvedTenantId);
    if (isNew) {
        dispatchUserCreated(resolvedTenantId, user.id, "auth.email", {
            hasEmail: true,
        });
    }
    const response = await buildAuthOrMfaResponse(user.id, resolvedTenantId, walletAddress ?? "", {
        userId: user.id,
        email,
        authMethod: "email",
    }, { id: user.id, email, walletAddress }, c);
    if (response.ok === false) {
        return {
            ok: false,
            status: typeof response.status === "number"
                ? response.status
                : 403,
            error: typeof response.error === "string"
                ? response.error
                : "Authentication failed",
        };
    }
    return {
        ok: true,
        response,
    };
}
function resolveSamlMappedRole(config, groups) {
    const precedence = [
        "admin",
        "developer",
        "billing",
        "viewer",
        "member",
    ];
    const normalizedGroups = new Set(groups.map((group) => group.trim()).filter(Boolean));
    for (const role of precedence) {
        if (config.groupRoleMappings.some((mapping) => mapping.role === role && normalizedGroups.has(mapping.group))) {
            return role;
        }
    }
    return "viewer";
}
function getEmailAuthRedirectBaseUrl() {
    return (process.env.EMAIL_AUTH_REDIRECT_BASE_URL || "https://www.elizacloud.ai").replace(/\/$/, "");
}
function buildEmailAuthRedirectUrl(params) {
    const redirectUrl = new URL("/login", `${getEmailAuthRedirectBaseUrl()}/`);
    for (const [key, value] of Object.entries(params ?? {})) {
        if (value)
            redirectUrl.searchParams.set(key, value);
    }
    return redirectUrl.toString();
}
function setRedirectFragment(url, params) {
    const fragment = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
        if (value)
            fragment.set(key, value);
    }
    url.hash = fragment.toString();
}
function redirectEmailAuthFailure(c, reason) {
    return c.redirect(buildEmailAuthRedirectUrl({
        error: "email_auth_failed",
        reason,
    }), 302);
}
function escapeOAuthCallbackHtml(value) {
    return value.replace(/[&<>"']/g, (character) => {
        switch (character) {
            case "&":
                return "&amp;";
            case "<":
                return "&lt;";
            case ">":
                return "&gt;";
            case '"':
                return "&quot;";
            default:
                return "&#39;";
        }
    });
}
function oauthCallbackPrefersHtml(c) {
    const accept = c.req.header("accept")?.toLowerCase() ?? "";
    const qualityFor = (target) => {
        const [targetType] = target.split("/");
        let bestMatch;
        for (const range of accept.split(",")) {
            const [mediaType, ...parameters] = range
                .split(";")
                .map((part) => part.trim());
            const qualityParameter = parameters.find((parameter) => parameter.startsWith("q="));
            const quality = qualityParameter ? Number(qualityParameter.slice(2)) : 1;
            const normalizedQuality = Number.isFinite(quality) && quality >= 0 && quality <= 1 ? quality : 0;
            const specificity = mediaType === target
                ? 2
                : mediaType === `${targetType}/*`
                    ? 1
                    : mediaType === "*/*"
                        ? 0
                        : -1;
            if (specificity >= 0 &&
                (!bestMatch ||
                    specificity > bestMatch.specificity ||
                    (specificity === bestMatch.specificity &&
                        normalizedQuality > bestMatch.quality))) {
                bestMatch = { specificity, quality: normalizedQuality };
            }
        }
        return bestMatch?.quality;
    };
    const htmlQuality = qualityFor("text/html") ?? 0;
    const jsonQuality = qualityFor("application/json") ?? 0;
    if (htmlQuality <= 0)
        return false;
    if (htmlQuality !== jsonQuality)
        return htmlQuality > jsonQuality;
    return c.req.header("sec-fetch-mode")?.toLowerCase() === "navigate";
}
async function oauthCallbackRecoveryFromStoredState(kind, state, providerName) {
    if (!state || state.length > 256)
        return undefined;
    try {
        const rawPayload = await getChallengeStore().get(`${kind}:${state}`);
        if (!rawPayload)
            return undefined;
        const stateData = JSON.parse(rawPayload);
        const storedProvider = kind === "oauth" ? stateData.provider : stateData.providerId;
        if (storedProvider !== providerName ||
            typeof stateData.redirectUri !== "string") {
            return undefined;
        }
        const tenantId = typeof stateData.tenantId === "string" ? stateData.tenantId : undefined;
        const clientId = typeof stateData.clientId === "string" ? stateData.clientId : undefined;
        const redirectUrl = await assertAllowedOAuthRedirectUri(stateData.redirectUri, tenantId, clientId);
        return {
            redirectUrl,
            appState: typeof stateData.appState === "string" ? stateData.appState : undefined,
        };
    }
    catch {
        // Recovery is optional. Invalid, stale, or unavailable state must never
        // replace the original callback failure or create an unvalidated link.
        return undefined;
    }
}
function oauthCallbackFailure(c, options) {
    if (options.redirectUrl && options.appState) {
        const target = buildOAuthAppErrorReturn(options.redirectUrl.toString(), options.appState, options.code, process.env.STEWARD_OAUTH_APP_ERROR_REDIRECTS);
        if (target)
            return c.redirect(target, 302);
    }
    if (!oauthCallbackPrefersHtml(c)) {
        return c.json({
            ok: false,
            error: options.message,
            code: options.code,
        }, options.status);
    }
    let recoveryLink = "";
    if (options.redirectUrl) {
        const recoveryUrl = new URL(options.redirectUrl);
        recoveryUrl.searchParams.set("error", options.code);
        if (options.appState)
            recoveryUrl.searchParams.set("state", options.appState);
        recoveryLink = `<a class="stwd-oauth-error__action" href="${escapeOAuthCallbackHtml(recoveryUrl.toString())}">Return and try again</a>`;
    }
    const escapedMessage = escapeOAuthCallbackHtml(options.message);
    const escapedCode = escapeOAuthCallbackHtml(options.code);
    const recoveryInstruction = recoveryLink
        ? recoveryLink
        : '<p class="stwd-oauth-error__hint">Close this window and restart sign-in from the application.</p>';
    const body = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign-in could not be completed | Steward</title>
  <style>
    :root { color-scheme: dark; font-family: Inter, ui-sans-serif, system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { min-height: 100vh; margin: 0; display: grid; place-items: center; padding: 24px; background: #090b10; color: #f6f7fb; }
    .stwd-oauth-error { width: min(100%, 520px); padding: 32px; border: 1px solid #2a3040; border-radius: 18px; background: #121621; box-shadow: 0 24px 70px rgb(0 0 0 / 35%); }
    .stwd-oauth-error__eyebrow { margin: 0 0 10px; color: #98a2b8; font-size: 13px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
    h1 { margin: 0; font-size: clamp(24px, 6vw, 34px); line-height: 1.15; }
    .stwd-oauth-error__message { margin: 18px 0; color: #cbd1de; line-height: 1.6; }
    .stwd-oauth-error__code { display: inline-block; margin-bottom: 24px; padding: 6px 9px; border-radius: 7px; background: #080a0f; color: #aab4ca; font-size: 12px; }
    .stwd-oauth-error__action { display: inline-block; padding: 12px 18px; border-radius: 9px; background: #f6f7fb; color: #11141c; font-weight: 750; text-decoration: none; }
    .stwd-oauth-error__action:focus-visible { outline: 3px solid #7aa2ff; outline-offset: 3px; }
    .stwd-oauth-error__hint { margin: 0; color: #98a2b8; line-height: 1.5; }
  </style>
</head>
<body>
  <main class="stwd-oauth-error" data-error-code="${escapedCode}">
    <p class="stwd-oauth-error__eyebrow">Steward authentication</p>
    <h1>Sign-in could not be completed</h1>
    <p class="stwd-oauth-error__message">${escapedMessage}</p>
    <code class="stwd-oauth-error__code">${escapedCode}</code>
    <div>${recoveryInstruction}</div>
  </main>
</body>
</html>`;
    return c.html(body, options.status, {
        "Cache-Control": "no-store",
        "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
        "Referrer-Policy": "no-referrer",
        "X-Content-Type-Options": "nosniff",
    });
}
// ─── Route group ──────────────────────────────────────────────────────────────
const auth = new Hono();
auth.use("*", async (c, next) => {
    setAuthNoStoreHeaders(c);
    await next();
});
// ── Discovery ─────────────────────────────────────────────────────────────────
/**
 * POST /sso/discover
 * Public discovery endpoint for Privy-style dashboard/team SSO routing.
 * Returns a tenant only after the email domain has been verified by a tenant
 * admin, so unverified drafts cannot hijack login.
 */
auth.post("/sso/discover", async (c) => {
    const body = await c.req.json().catch(() => null);
    const domain = normalizeEmailDomain(body && typeof body === "object"
        ? body.email
        : null);
    if (!domain) {
        return c.json({ ok: false, error: "Valid email is required" }, 400);
    }
    const result = await getDb().execute(sql `SELECT * FROM steward_bootstrap.auth_sso_discovery_subject(${domain})`);
    const rows = bootstrapRows(result);
    const data = rows.length === 1
        ? {
            domain,
            tenantId: rows[0].tenant_id,
            ssoRequired: rows[0].sso_required,
            available: true,
        }
        : { domain, tenantId: null, ssoRequired: false, available: false };
    return c.json({ ok: true, data });
});
function escapeXml(value) {
    return value
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}
function samlMetadataXml(config) {
    const entityId = escapeXml(config.spEntityId);
    const acsUrl = escapeXml(config.acsUrl);
    const nameIdFormat = escapeXml(config.nameIdFormat ??
        "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress");
    return `<?xml version="1.0" encoding="UTF-8"?>
<EntityDescriptor xmlns="urn:oasis:names:tc:SAML:2.0:metadata" entityID="${entityId}">
  <SPSSODescriptor AuthnRequestsSigned="false" WantAssertionsSigned="true" protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
    <NameIDFormat>${nameIdFormat}</NameIDFormat>
    <AssertionConsumerService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" Location="${acsUrl}" index="0" isDefault="true"/>
  </SPSSODescriptor>
</EntityDescriptor>`;
}
async function getActiveSamlSsoConfig(tenantId) {
    const row = await withPreAuthTenant(tenantId, "saml-config-read", async () => {
        const [candidate] = await getDb()
            .select()
            .from(tenantSamlSsoConfigs)
            .where(and(eq(tenantSamlSsoConfigs.tenantId, tenantId), eq(tenantSamlSsoConfigs.enabled, true), eq(tenantSamlSsoConfigs.status, "active")));
        return candidate;
    });
    if (!row)
        return null;
    const urls = buildSamlServiceProviderUrls(tenantId);
    if (row.spEntityId !== urls.spEntityId || row.acsUrl !== urls.acsUrl)
        return null;
    return {
        tenantId: row.tenantId,
        enabled: row.enabled,
        status: row.status,
        idpEntityId: row.idpEntityId,
        idpSsoUrl: row.idpSsoUrl,
        idpCertPems: row.idpCertPems,
        spEntityId: row.spEntityId,
        acsUrl: row.acsUrl,
        nameIdFormat: row.nameIdFormat ?? undefined,
        emailAttribute: row.emailAttribute,
        groupsAttribute: row.groupsAttribute ?? undefined,
        groupRoleMappings: row.groupRoleMappings,
        allowJitProvisioning: row.allowJitProvisioning,
        jitDefaultRole: "viewer",
        lastTestedAt: row.lastTestedAt,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
    };
}
async function loadSamlAuthnRequest(tenantId, relayState) {
    const request = await withPreAuthTenant(tenantId, "saml-request-read", async () => {
        const [candidate] = await getDb()
            .select()
            .from(tenantSamlAuthnRequests)
            .where(and(eq(tenantSamlAuthnRequests.tenantId, tenantId), eq(tenantSamlAuthnRequests.relayState, relayState), isNull(tenantSamlAuthnRequests.consumedAt), gte(tenantSamlAuthnRequests.expiresAt, new Date())));
        return candidate;
    });
    if (!request)
        throw new Error("Invalid or expired SAML RelayState");
    return request;
}
async function consumeSamlAuthnRequest(tenantId, relayState) {
    const request = await withPreAuthTenant(tenantId, "saml-request-consume", async () => {
        const [candidate] = await getDb()
            .update(tenantSamlAuthnRequests)
            .set({ consumedAt: new Date(), updatedAt: new Date() })
            .where(and(eq(tenantSamlAuthnRequests.tenantId, tenantId), eq(tenantSamlAuthnRequests.relayState, relayState), isNull(tenantSamlAuthnRequests.consumedAt), gte(tenantSamlAuthnRequests.expiresAt, new Date())))
            .returning();
        return candidate;
    });
    if (!request)
        throw new Error("Invalid or expired SAML RelayState");
    return request;
}
async function recordSamlAssertionReplay(tenantId, assertionId, responseId) {
    await withPreAuthTenant(tenantId, "saml-replay-record", async () => {
        await getDb()
            .insert(tenantSamlAssertionReplays)
            .values({
            tenantId,
            assertionId,
            responseId,
            expiresAt: new Date(Date.now() + 10 * 60_000),
        });
    });
}
/**
 * GET /saml/:tenantId/login
 * SP-initiated dashboard/team SSO. Stores an app-bound PKCE exchange request
 * and redirects to the tenant IdP with opaque RelayState.
 */
auth.get("/saml/:tenantId/login", async (c) => {
    const tenantId = c.req.param("tenantId");
    if (!isValidTenantId(tenantId)) {
        return c.json({ ok: false, error: "Invalid tenant id" }, 400);
    }
    const redirectUri = c.req.query("redirect_uri")?.trim() || c.req.query("redirectUri")?.trim();
    const appState = c.req.query("state")?.trim() || undefined;
    const rawClientId = c.req.query("app_client_id") ?? c.req.query("appClientId");
    const clientId = rawClientId
        ? normalizePublicClientId(rawClientId)
        : undefined;
    const responseType = c.req.query("response_type")?.trim() || "code";
    const codeChallenge = c.req.query("code_challenge")?.trim() || undefined;
    const codeChallengeMethod = c.req.query("code_challenge_method")?.trim() || "S256";
    if (!redirectUri) {
        return c.json({ ok: false, error: "redirect_uri is required" }, 400);
    }
    if (rawClientId && !clientId) {
        return c.json({ ok: false, error: "app_client_id is invalid" }, 400);
    }
    if (responseType !== "code") {
        return c.json({ ok: false, error: "response_type must be 'code'" }, 400);
    }
    if (!codeChallenge) {
        return c.json({ ok: false, error: "code_challenge is required for response_type=code" }, 400);
    }
    if (codeChallengeMethod !== "S256") {
        return c.json({ ok: false, error: "code_challenge_method must be 'S256'" }, 400);
    }
    const config = await getActiveSamlSsoConfig(tenantId);
    if (!config)
        return c.json({ ok: false, error: "SAML SSO is not configured" }, 404);
    try {
        await assertAllowedOAuthRedirectUri(redirectUri, tenantId, clientId);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Invalid redirect_uri",
        }, 400);
    }
    const relayState = randomBase64Url(32);
    const requestId = `_${randomBase64Url(32)}`;
    const built = await buildSamlAuthorizeUrl({
        relayState,
        requestId,
        idpSsoUrl: config.idpSsoUrl,
        idpEntityId: config.idpEntityId,
        idpCertPems: config.idpCertPems,
        spEntityId: config.spEntityId,
        acsUrl: config.acsUrl,
    });
    await withPreAuthTenant(tenantId, "saml-request-create", async () => {
        await getDb()
            .insert(tenantSamlAuthnRequests)
            .values({
            tenantId,
            requestId: built.requestId,
            relayState,
            redirectUri,
            appClientId: clientId,
            codeChallenge,
            codeChallengeMethod: "S256",
            expiresAt: new Date(Date.now() + 5 * 60_000),
        });
    });
    if (appState) {
        await getChallengeStore().set(`saml-app-state:${relayState}`, appState);
    }
    return c.redirect(built.url, 302);
});
/**
 * GET /saml/:tenantId/metadata
 * Public SAML SP metadata for dashboard/team SSO IdP setup.
 */
auth.get("/saml/:tenantId/metadata", async (c) => {
    const tenantId = c.req.param("tenantId");
    if (!isValidTenantId(tenantId)) {
        return c.json({ ok: false, error: "Invalid tenant id" }, 400);
    }
    const config = await getActiveSamlSsoConfig(tenantId);
    if (!config)
        return c.json({ ok: false, error: "SAML SSO is not configured" }, 404);
    return c.text(samlMetadataXml(config), 200, {
        "Content-Type": "application/samlmetadata+xml",
    });
});
auth.post("/saml/:tenantId/acs", async (c) => {
    const tenantId = c.req.param("tenantId");
    if (!isValidTenantId(tenantId)) {
        return c.json({ ok: false, error: "Invalid tenant id" }, 400);
    }
    const config = await getActiveSamlSsoConfig(tenantId);
    if (!config)
        return c.json({ ok: false, error: "SAML SSO is not configured" }, 404);
    const body = await c.req.parseBody().catch(() => null);
    const samlResponse = typeof body?.SAMLResponse === "string" ? body.SAMLResponse : "";
    const relayState = typeof body?.RelayState === "string" ? body.RelayState : "";
    if (!samlResponse || !relayState) {
        return c.json({ ok: false, error: "SAMLResponse and RelayState are required" }, 400);
    }
    let request;
    let redirectUrl;
    try {
        request = await loadSamlAuthnRequest(tenantId, relayState);
        redirectUrl = await assertAllowedOAuthRedirectUri(request.redirectUri, tenantId, request.appClientId ?? undefined);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Invalid SAML RelayState",
        }, 401);
    }
    try {
        const verified = await verifySamlAcsResponse({
            samlResponse,
            expectedRequestId: request.requestId,
            tenantId,
            idpEntityId: config.idpEntityId,
            idpSsoUrl: config.idpSsoUrl,
            idpCertPems: config.idpCertPems,
            spEntityId: config.spEntityId,
            acsUrl: config.acsUrl,
            emailAttribute: config.emailAttribute,
            groupsAttribute: config.groupsAttribute,
        });
        if (!(await isVerifiedSsoEmailDomainForTenant(tenantId, verified.email))) {
            redirectUrl.searchParams.set("error", "saml_email_domain_not_verified");
            return c.redirect(redirectUrl.toString(), 302);
        }
        try {
            await consumeSamlAuthnRequest(tenantId, relayState);
        }
        catch {
            redirectUrl.searchParams.set("error", "saml_relay_state_replay");
            return c.redirect(redirectUrl.toString(), 302);
        }
        try {
            await recordSamlAssertionReplay(tenantId, verified.assertionId, undefined);
        }
        catch {
            redirectUrl.searchParams.set("error", "saml_assertion_replay");
            return c.redirect(redirectUrl.toString(), 302);
        }
        const result = await provisionSamlUser({
            c,
            tenantId,
            config,
            subject: verified.nameId || verified.assertionId,
            email: verified.email,
            groups: verified.groups,
        });
        if (!result.ok) {
            redirectUrl.searchParams.set("error", result.error);
            return c.redirect(redirectUrl.toString(), 302);
        }
        if (result.response.ok === false || result.response.mfaRequired) {
            redirectUrl.searchParams.set("error", "auth_failed");
            return c.redirect(redirectUrl.toString(), 302);
        }
        const exchangeCode = randomBase64Url(32);
        const issuedAt = Date.now();
        const expiresAt = issuedAt + OAUTH_CODE_TTL_MS;
        await getOAuthCodeStore().set(`oauth-code:${exchangeCode}`, JSON.stringify({
            providerName: "saml",
            token: result.response.token,
            refreshToken: result.response.refreshToken,
            redirectUri: request.redirectUri,
            tenantId,
            codeChallenge: request.codeChallenge,
            codeChallengeMethod: request.codeChallengeMethod,
            expiresAt,
            expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
        }));
        const appState = await getChallengeStore().consume(`saml-app-state:${relayState}`);
        setRedirectFragment(redirectUrl, {
            code: exchangeCode,
            state: appState ?? undefined,
        });
        return c.redirect(redirectUrl.toString(), 302);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "SAML verification failed",
        }, 401);
    }
});
/**
 * GET /providers
 * Public endpoint. Returns which authentication methods are enabled on this
 * server so a client SDK (e.g. @elizaos/auth) can render the right sign-in UI.
 *
 * Passkey/email/SIWE/SIWS are always wired in this build. OAuth providers are
 * advertised when their credentials are configured.
 *
 * Env var resolution mirrors `getProviderConfig` in @stwd/auth/oauth.ts: the
 * canonical names are `<PROVIDER>_CLIENT_ID` / `<PROVIDER>_CLIENT_SECRET`.
 * `STEWARD_OAUTH_<PROVIDER>_CLIENT_ID` is also accepted for backwards-compat
 * with older deployments. Reading only the prefixed form caused production
 * to advertise OAuth as disabled even though the underlying authorize
 * endpoints had working credentials.
 */
auth.get("/providers", async (c) => {
    const oauth = getEnabledProviders();
    const tenantId = c.req.query("tenantId")?.trim() || c.req.header("X-Steward-Tenant")?.trim();
    const authAbuseConfig = tenantId
        ? await getTenantAuthAbuseConfig(tenantId)
        : {};
    const loginMethods = authAbuseConfig.loginMethods ?? {};
    const methodEnabled = (method) => loginMethods[method] !== false;
    const enabledOauth = oauth.filter((provider) => loginMethods.oauth?.[provider] !== false);
    const oidc = tenantId
        ? (await getTenantOidcProviders(tenantId))
            .filter((provider) => provider.enabled !== false)
            .filter((provider) => loginMethods.oidc?.[loginMethodProviderKey(provider.id)] !== false)
            .map((provider) => provider.id)
        : [];
    // Returns the providers payload at the top level, NOT wrapped in { ok, data }.
    // The @elizaos/auth authRequest helper returns the full parsed body as `res.data`,
    // so callers like `getProviders()` then read `res.data` and expect the
    // StewardProviders shape directly. Wrapping here in ApiResponse caused the
    // SDK to receive `{ok:true, data: {...providers}}` and treat the wrapper as
    // the provider object: every provider field became undefined and SPAs hid
    // the OAuth buttons even when the credentials were configured.
    // The `ok: true` field is preserved at the top level so older clients that
    // were checking for it keep working.
    return c.json({
        ok: true,
        passkey: methodEnabled("passkey"),
        email: methodEnabled("email"),
        sms: methodEnabled("sms"),
        whatsapp: methodEnabled("whatsapp") && isWhatsAppOtpEnabled(),
        totp: methodEnabled("totp"),
        siwe: methodEnabled("siwe"),
        siws: methodEnabled("siws"),
        google: enabledOauth.includes("google"),
        googleNative: enabledOauth.includes("google") &&
            Boolean(tenantId &&
                (await authAppClientSubjects(tenantId)).some((client) => googleNativeClientIds(client.id).length > 0 &&
                    client.login_methods?.oauth?.google !== false)),
        discord: enabledOauth.includes("discord"),
        github: enabledOauth.includes("github"),
        twitter: enabledOauth.includes("twitter"),
        telegram: methodEnabled("telegram") &&
            Boolean(process.env.TELEGRAM_BOT_TOKEN?.trim()),
        farcaster: methodEnabled("farcaster") && isFarcasterLoginEnabled(),
        linkedin: enabledOauth.includes("linkedin"),
        spotify: enabledOauth.includes("spotify"),
        twitch: enabledOauth.includes("twitch"),
        instagram: enabledOauth.includes("instagram"),
        line: enabledOauth.includes("line"),
        oauth: enabledOauth,
        jwt: oidc.length > 0,
        oidc,
        captcha: publicAuthAbuseConfig(authAbuseConfig).captcha,
    });
});
// This exchanges identity only. Cloud mobile connect/token/ack still owns the
// device credential, and provisionOAuthUser still enforces tenant policy/MFA.
auth.post("/oauth/google/native/:operation", async (c) => {
    setAuthNoStoreHeaders(c);
    const operation = c.req.param("operation");
    if (operation !== "challenge" && operation !== "verify")
        return c.notFound();
    const rl = await checkAuthRateLimit(c, `google-native-${operation}`, 60_000, 20);
    if (!rl.allowed)
        return c.json({ ok: false, error: "Too many sign-in attempts. Try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    const body = await safeJsonParse(c);
    const tenantId = typeof body?.tenantId === "string" ? body.tenantId.trim() : "";
    const clientId = normalizePublicClientId(body?.clientId);
    if (!body || !isValidTenantId(tenantId) || !clientId)
        return c.json({ ok: false, error: "A valid tenantId and clientId are required" }, 400);
    const headerTenant = c.req.header("X-Steward-Tenant")?.trim();
    if (headerTenant && headerTenant !== tenantId)
        return c.json({ ok: false, error: "tenantId does not match X-Steward-Tenant" }, 400);
    if (!(await getEnabledTenantAppClient(tenantId, clientId)))
        return c.json({ ok: false, error: "App client not found or disabled" }, 404);
    const refusal = await requireTenantLoginMethodAllowed(c, tenantId, "oauth", "google", clientId);
    if (refusal)
        return refusal;
    const androidClientIds = googleNativeClientIds(clientId);
    if (!getEnabledProviders().includes("google") ||
        androidClientIds.length === 0)
        return c.json({
            ok: false,
            error: "Native Google sign-in is not configured for this app",
        }, 503);
    const audience = getProviderConfig("google").clientId;
    if (operation === "challenge") {
        if (body.codeChallengeMethod !== "S256" ||
            typeof body.codeChallenge !== "string" ||
            !/^[A-Za-z0-9_-]{43}$/.test(body.codeChallenge))
            return c.json({ ok: false, error: "An S256 code challenge is required" }, 400);
        const challengeId = randomBase64Url(32);
        const nonce = randomBase64Url(32);
        const expiresAt = Date.now() + 5 * 60_000;
        const challenge = {
            tenantId,
            clientId,
            audience,
            nonce,
            codeChallenge: body.codeChallenge,
            expiresAt,
        };
        await getChallengeStore().set(`google-native:${challengeId}`, JSON.stringify(challenge));
        return c.json({
            ok: true,
            challengeId,
            nonce,
            serverClientId: audience,
            expiresAt: new Date(expiresAt).toISOString(),
        });
    }
    if (typeof body.challengeId !== "string" ||
        !/^[A-Za-z0-9_-]{43}$/.test(body.challengeId) ||
        typeof body.idToken !== "string" ||
        !body.idToken ||
        typeof body.codeVerifier !== "string" ||
        !isValidPkceCodeVerifier(body.codeVerifier))
        return c.json({
            ok: false,
            error: "challengeId, idToken and codeVerifier are required",
        }, 400);
    const key = `google-native:${body.challengeId}`;
    const raw = await getChallengeStore().get(key);
    if (!raw)
        return c.json({ ok: false, error: "Sign-in challenge expired or was already used" }, 401);
    const challenge = JSON.parse(raw);
    if (challenge.tenantId !== tenantId ||
        challenge.clientId !== clientId ||
        challenge.audience !== audience ||
        challenge.expiresAt <= Date.now() ||
        challenge.codeChallenge !==
            (await pkceChallengeForVerifier(body.codeVerifier, "S256")))
        return c.json({ ok: false, error: "Sign-in challenge does not match this request" }, 401);
    let verified;
    try {
        verified = await verifyGoogleNativeIdToken(body.idToken, audience, androidClientIds, challenge.nonce);
    }
    catch {
        return c.json({ ok: false, error: "Google identity could not be verified" }, 401);
    }
    // Invalid identity/proof never consumes state. Only one concurrent verified
    // request may cross the atomic consume boundary and provision a session.
    if ((await getChallengeStore().consume(key)) !== raw)
        return c.json({ ok: false, error: "Sign-in challenge was already used" }, 401);
    const replay = await markOidcIdTokenUsedOnce(tenantId, "google", body.idToken, verified.claims.exp);
    if (!replay.ok)
        return c.json({ ok: false, error: "Google identity token was already used or expired" }, 401);
    const result = await provisionOAuthUser({
        c,
        providerName: "google",
        tenantId,
        providerUser: {
            id: verified.subject,
            email: verified.email,
            verified_email: true,
            name: verified.name,
            picture: verified.picture,
        },
    });
    if (!result.ok)
        return c.json({ ok: false, error: result.error }, result.status ?? 500);
    return authExchangeJson(c, result.response);
});
auth.post("/telegram/challenge", async (c) => {
    const rl = await checkAuthRateLimit(c, "telegram-challenge", 60_000, 30);
    if (!rl.allowed) {
        return c.json({
            ok: false,
            error: "Too many Telegram login attempts. Try again later.",
        }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (body === null) {
        return c.json({ ok: false, error: "Invalid JSON in request body" }, 400);
    }
    const botToken = process.env.TELEGRAM_BOT_TOKEN?.trim();
    if (!botToken) {
        return c.json({ ok: false, error: "Telegram login is not configured" }, 503);
    }
    const requestedTenantId = typeof body?.tenantId === "string" && body.tenantId.trim()
        ? body.tenantId.trim()
        : c.req.header("X-Steward-Tenant")?.trim() || undefined;
    const methodResponse = await requireTenantLoginMethodAllowed(c, requestedTenantId, "telegram");
    if (methodResponse)
        return methodResponse;
    const originHost = await requiredTelegramOriginHostFromRequest(c, requestedTenantId);
    if (!originHost) {
        return c.json({
            ok: false,
            error: "Telegram login challenges require an allowed Origin or Referer",
        }, 400);
    }
    const challenge = await createTelegramLoginChallenge({
        tenantId: requestedTenantId,
        originHost,
    });
    return c.json({
        challengeId: challenge.challengeId,
        expiresAt: new Date(challenge.expiresAt).toISOString(),
    });
});
auth.post("/telegram/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "telegram-verify", 60_000, 20);
    if (!rl.allowed) {
        return c.json({
            ok: false,
            error: "Too many Telegram login attempts. Try again later.",
        }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body)
        return c.json({ ok: false, error: "Invalid JSON in request body" }, 400);
    const botToken = process.env.TELEGRAM_BOT_TOKEN?.trim();
    if (!botToken) {
        return c.json({ ok: false, error: "Telegram login is not configured" }, 503);
    }
    const { tenantId: requestedBodyTenantId, challengeId, ...telegramPayload } = body;
    if (typeof challengeId !== "string" || !challengeId.trim()) {
        return c.json({ ok: false, error: "challengeId is required" }, 400);
    }
    const bodyTenantId = typeof requestedBodyTenantId === "string" && requestedBodyTenantId.trim()
        ? requestedBodyTenantId.trim()
        : undefined;
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim() || undefined;
    if (bodyTenantId && headerTenantId && bodyTenantId !== headerTenantId) {
        return c.json({ ok: false, error: "tenantId and X-Steward-Tenant must match" }, 400);
    }
    const requestedTenantId = bodyTenantId || headerTenantId;
    const methodResponse = await requireTenantLoginMethodAllowed(c, requestedTenantId, "telegram");
    if (methodResponse)
        return methodResponse;
    const challengeError = validateConsumedTelegramLoginChallenge(await consumeTelegramLoginChallenge(challengeId.trim()), {
        tenantId: requestedTenantId,
        originHost: originHostFromRequest(c),
    });
    if (challengeError) {
        return c.json({ ok: false, error: challengeError }, 401);
    }
    let telegramUser;
    try {
        telegramUser = verifyTelegramLogin(telegramPayload, botToken, {
            maxAgeSec: TELEGRAM_LOGIN_MAX_AGE_SEC,
        });
    }
    catch (error) {
        return c.json({
            ok: false,
            error: error instanceof Error ? error.message : "Invalid Telegram login",
        }, 401);
    }
    const displayName = [telegramUser.firstName, telegramUser.lastName]
        .filter(Boolean)
        .join(" ")
        .trim() ||
        telegramUser.username ||
        `telegram:${telegramUser.id}`;
    const [existingTelegramAccount] = await getDb()
        .select({ userId: accounts.userId })
        .from(accounts)
        .where(and(eq(accounts.provider, "telegram"), eq(accounts.providerAccountId, telegramUser.id)));
    if (!existingTelegramAccount && requestedTenantId) {
        const jitTenant = await validateOidcJitTenant(requestedTenantId);
        if (!jitTenant.ok) {
            return c.json({ ok: false, error: jitTenant.error }, jitTenant.status);
        }
    }
    const telegramHash = typeof telegramPayload.hash === "string"
        ? telegramPayload.hash
        : String(telegramPayload.hash);
    if (!(await consumeTelegramLoginHashOnce(telegramHash, telegramUser.authDate))) {
        return c.json({ ok: false, error: "Telegram login payload was already used" }, 401);
    }
    const { user, isNew } = await findOrCreateExternalAccountUserWithStatus({
        provider: "telegram",
        providerAccountId: telegramUser.id,
        name: displayName,
        image: telegramUser.photoUrl,
    });
    try {
        const updates = {};
        if (!user.name && displayName)
            updates.name = displayName;
        if (!user.image && telegramUser.photoUrl)
            updates.image = telegramUser.photoUrl;
        if (Object.keys(updates).length > 0) {
            await getDb().update(users).set(updates).where(eq(users.id, user.id));
        }
        let walletAddress = user.walletAddress;
        try {
            const wallet = await provisionWalletForUser(user.id, `telegram:${telegramUser.id}`);
            walletAddress = wallet.walletAddress;
        }
        catch (err) {
            logger.error({
                details: [
                    "[TelegramAuth] Wallet provision failed",
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:auth] error");
        }
        const tenantResult = await resolveAndValidateTenant(c, user.id, requestedTenantId);
        if (!tenantResult.ok) {
            return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
        }
        const resolvedMethodResponse = await requireTenantLoginMethodAllowed(c, tenantResult.tenantId, "telegram");
        if (resolvedMethodResponse)
            return resolvedMethodResponse;
        await ensureUserTenantLink(user.id, tenantResult.tenantId);
        if (isNew) {
            dispatchUserCreated(tenantResult.tenantId, user.id, "auth.telegram", {
                provider: "telegram",
                hasEmail: false,
            });
        }
        const response = await buildAuthOrMfaResponse(user.id, tenantResult.tenantId, walletAddress ?? "", {
            userId: user.id,
            authMethod: "telegram",
            telegramId: telegramUser.id,
        }, {
            id: user.id,
            email: null,
            name: displayName,
            image: telegramUser.photoUrl,
            walletAddress,
            telegramId: telegramUser.id,
            telegramUsername: telegramUser.username,
        }, c);
        return authExchangeJson(c, response);
    }
    catch (error) {
        logger.error({
            details: [
                "[TelegramAuth] verify failed",
                redactedThrownDiagnostics(error),
            ],
        }, "[Login:auth] error");
        return c.json({ ok: false, error: "Telegram login failed" }, 500);
    }
});
auth.post("/farcaster/verify", async (c) => {
    if (!isFarcasterLoginEnabled()) {
        return c.json({ ok: false, error: "Farcaster login is not configured" }, 503);
    }
    const rl = await checkAuthRateLimit(c, "farcaster-verify", 60_000, 20);
    if (!rl.allowed) {
        return c.json({
            ok: false,
            error: "Too many Farcaster login attempts. Try again later.",
        }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body)
        return c.json({ ok: false, error: "Invalid JSON in request body" }, 400);
    const { tenantId: requestedBodyTenantId, ...farcasterPayload } = body;
    let farcasterUser;
    try {
        farcasterUser = await verifyFarcasterLogin(farcasterPayload, {
            expectedDomain: getAllowedSiweDomains(),
            maxMessageAgeMs: 10 * 60 * 1000,
        });
    }
    catch (error) {
        return c.json({
            ok: false,
            error: error instanceof Error ? error.message : "Invalid Farcaster login",
        }, 401);
    }
    const bodyTenantId = typeof requestedBodyTenantId === "string" && requestedBodyTenantId.trim()
        ? requestedBodyTenantId.trim()
        : undefined;
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim() || undefined;
    if (bodyTenantId && headerTenantId && bodyTenantId !== headerTenantId) {
        return c.json({ ok: false, error: "tenantId and X-Steward-Tenant must match" }, 400);
    }
    const requestedTenantId = bodyTenantId || headerTenantId;
    const methodResponse = await requireTenantLoginMethodAllowed(c, requestedTenantId, "farcaster");
    if (methodResponse)
        return methodResponse;
    const nonceError = validateConsumedSiweNonce(await consumeSiweNonce(farcasterUser.message.nonce), {
        domain: farcasterUser.message.domain,
        tenantId: requestedTenantId,
    });
    if (nonceError) {
        return c.json({ ok: false, error: nonceError }, 401);
    }
    const displayName = `farcaster:${farcasterUser.custodyAddress}`;
    const providerAccountId = `address:${farcasterUser.custodyAddress.toLowerCase()}`;
    const [existingFarcasterAccount] = await getDb()
        .select({ userId: accounts.userId })
        .from(accounts)
        .where(and(eq(accounts.provider, "farcaster"), eq(accounts.providerAccountId, providerAccountId)));
    if (!existingFarcasterAccount && requestedTenantId) {
        const jitTenant = await validateOidcJitTenant(requestedTenantId);
        if (!jitTenant.ok) {
            return c.json({ ok: false, error: jitTenant.error }, jitTenant.status);
        }
    }
    const { user, isNew } = await findOrCreateExternalAccountUserWithStatus({
        provider: "farcaster",
        providerAccountId,
        name: displayName,
    });
    try {
        const updates = {};
        if (!user.name && displayName)
            updates.name = displayName;
        if (!user.walletAddress) {
            updates.walletAddress = farcasterUser.custodyAddress;
            updates.walletChain = "ethereum";
        }
        if (Object.keys(updates).length > 0) {
            await getDb().update(users).set(updates).where(eq(users.id, user.id));
        }
        let walletAddress = user.walletAddress ?? farcasterUser.custodyAddress;
        try {
            const wallet = await provisionWalletForUser(user.id, `farcaster:${providerAccountId}`);
            walletAddress = wallet.walletAddress;
        }
        catch (err) {
            logger.error({
                details: [
                    "[FarcasterAuth] Wallet provision failed",
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:auth] error");
        }
        const tenantResult = await resolveAndValidateTenant(c, user.id, requestedTenantId);
        if (!tenantResult.ok) {
            return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
        }
        const resolvedMethodResponse = await requireTenantLoginMethodAllowed(c, tenantResult.tenantId, "farcaster");
        if (resolvedMethodResponse)
            return resolvedMethodResponse;
        await ensureUserTenantLink(user.id, tenantResult.tenantId);
        if (isNew) {
            dispatchUserCreated(tenantResult.tenantId, user.id, "auth.farcaster", {
                provider: "farcaster",
                custodyAddress: farcasterUser.custodyAddress,
                authoritativeCustody: false,
            });
        }
        const response = await buildAuthOrMfaResponse(user.id, tenantResult.tenantId, walletAddress ?? "", {
            userId: user.id,
            authMethod: "farcaster",
            custodyAddress: farcasterUser.custodyAddress,
        }, {
            id: user.id,
            email: null,
            name: displayName,
            walletAddress,
            custodyAddress: farcasterUser.custodyAddress,
        }, c);
        return authExchangeJson(c, response);
    }
    catch (error) {
        logger.error({
            details: [
                "[FarcasterAuth] verify failed",
                redactedThrownDiagnostics(error),
            ],
        }, "[Login:auth] error");
        return c.json({ ok: false, error: "Farcaster login failed" }, 500);
    }
});
/**
 * POST /jwt/login (direct OIDC id_token login)
 *
 * Accepts an id_token the client already obtained from the IdP and exchanges it
 * for a Steward session. Signature, issuer, audience, azp (OIDC §3.1.3.7), and
 * exp are verified first, then the id_token hash is marked one-time-use until
 * exp so a captured token cannot mint multiple Steward sessions.
 */
auth.post("/jwt/login", async (c) => {
    const rl = await checkAuthRateLimit(c, "jwt", 60_000, 20);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many JWT login attempts. Try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body)
        return c.json({ ok: false, error: "Invalid JSON in request body" }, 400);
    if (typeof body.tenantId !== "string" ||
        body.tenantId.trim() === "" ||
        typeof body.token !== "string" ||
        body.token.trim() === "") {
        return c.json({ ok: false, error: "tenantId and token are required" }, 400);
    }
    const tenantId = body.tenantId.trim();
    const headerTenant = c.req.header("X-Steward-Tenant")?.trim();
    if (headerTenant && headerTenant !== tenantId) {
        return c.json({ ok: false, error: "tenantId does not match X-Steward-Tenant" }, 400);
    }
    const providerId = typeof body.providerId === "string" && body.providerId.trim() !== ""
        ? body.providerId.trim()
        : undefined;
    const provider = selectOidcProvider(await getTenantOidcProviders(tenantId), providerId);
    if (!provider) {
        return c.json({ ok: false, error: "OIDC provider not found or disabled" }, 404);
    }
    if (provider.authorizationUrl || provider.tokenUrl) {
        return c.json({
            ok: false,
            error: "Direct JWT login is disabled for authorization-code OIDC providers",
        }, 403);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "oidc", provider.id);
    if (methodResponse)
        return methodResponse;
    try {
        const rawToken = body.token.trim();
        const verified = await verifyOidcJwt(tenantId, provider, rawToken);
        const replay = await markOidcIdTokenUsedOnce(tenantId, provider.id, rawToken, verified.claims.exp);
        if (!replay.ok) {
            const error = replay.response === "replayed"
                ? "OIDC id_token has already been used"
                : replay.response === "missing-exp"
                    ? "OIDC id_token exp claim is required"
                    : "OIDC id_token is expired";
            return c.json({ ok: false, error }, 401);
        }
        await withPreAuthTenant(tenantId, "oidc-login-authorization-audit", () => writeAuditEvent({
            tenantId,
            actorType: "user",
            actorId: null,
            action: "auth.oidc.login.authorized",
            resourceType: "session",
            metadata: {
                providerId: provider.id,
                issuer: provider.issuer,
                oidcSubject: verified.subject,
            },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        }));
        if (!verified.email || verified.emailVerified !== true) {
            return c.json({
                ok: false,
                error: "Enterprise OIDC SSO requires a verified email claim",
            }, 403);
        }
        if (!(await isVerifiedSsoEmailDomainForTenant(tenantId, verified.email))) {
            return c.json({
                ok: false,
                error: "Enterprise OIDC SSO email domain is not verified for this tenant",
            }, 403);
        }
        const result = await provisionOidcUser({
            c,
            tenantId,
            provider,
            subject: verified.subject,
            email: verified.email,
            emailVerified: verified.emailVerified,
            name: verified.name,
            picture: verified.picture,
        });
        if (!result.ok) {
            return c.json({ ok: false, error: result.error }, result.status ?? 500);
        }
        return authExchangeJson(c, result.response);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "OIDC token verification failed",
        }, 401);
    }
});
/**
 * GET /oidc/:provider/authorize
 *
 * Enterprise OIDC authorization-code SSO. This mirrors the built-in OAuth
 * nonce-exchange flow: Steward owns the provider callback, validates the
 * ID token, then redirects the app with a one-time code that must be redeemed
 * through /auth/oauth/exchange.
 */
auth.get("/oidc/:provider/authorize", async (c) => {
    const providerId = c.req.param("provider");
    const rl = await checkAuthRateLimit(c, `oidc-authorize:${providerId}`, 60_000, 30);
    if (!rl.allowed) {
        return c.json({
            ok: false,
            error: "Too many OIDC authorization requests. Please try again later.",
        }, 429);
    }
    const tenantId = c.req.query("tenant_id")?.trim() || c.req.query("tenantId")?.trim() || "";
    const redirectUri = c.req.query("redirect_uri")?.trim() || c.req.query("redirectUri")?.trim();
    const appState = c.req.query("state")?.trim() || undefined;
    const rawClientId = c.req.query("app_client_id") ?? c.req.query("appClientId");
    const clientId = rawClientId
        ? normalizePublicClientId(rawClientId)
        : undefined;
    const responseType = c.req.query("response_type")?.trim() || "code";
    const codeChallenge = c.req.query("code_challenge")?.trim() || undefined;
    const codeChallengeMethod = c.req.query("code_challenge_method")?.trim() || "S256";
    if (!tenantId)
        return c.json({ ok: false, error: "tenant_id is required" }, 400);
    if (!redirectUri) {
        return c.json({ ok: false, error: "redirect_uri is required" }, 400);
    }
    if (rawClientId && !clientId) {
        return c.json({ ok: false, error: "app_client_id is invalid" }, 400);
    }
    if (responseType !== "code") {
        return c.json({ ok: false, error: "response_type must be 'code'" }, 400);
    }
    if (!codeChallenge) {
        return c.json({ ok: false, error: "code_challenge is required for response_type=code" }, 400);
    }
    if (codeChallengeMethod !== "S256") {
        return c.json({ ok: false, error: "code_challenge_method must be 'S256'" }, 400);
    }
    const provider = selectOidcProvider(await getTenantOidcProviders(tenantId), providerId);
    if (!provider) {
        return c.json({ ok: false, error: "OIDC provider not found or disabled" }, 404);
    }
    if (!provider.clientId || !provider.authorizationUrl || !provider.tokenUrl) {
        return c.json({
            ok: false,
            error: "OIDC provider is not configured for authorization-code login",
        }, 400);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "oidc", provider.id, clientId);
    if (methodResponse)
        return methodResponse;
    try {
        await assertAllowedOAuthRedirectUri(redirectUri, tenantId, clientId);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Invalid redirect_uri",
        }, 400);
    }
    const state = randomBase64Url(24);
    const nonce = randomBase64Url(24);
    const codeVerifier = randomBase64Url(48);
    const providerCodeChallenge = await pkceChallengeForVerifier(codeVerifier, "S256");
    if (!providerCodeChallenge) {
        return c.json({ ok: false, error: "Failed to generate PKCE challenge" }, 500);
    }
    const callbackUrl = buildOidcCallbackUrl(c, provider.id);
    const scopes = provider.scopes?.length
        ? provider.scopes
        : ["openid", "email", "profile"];
    let authUrl;
    try {
        // Revalidate persisted rows at the action boundary before issuing a browser
        // redirect; configuration-time validation is not an execution-time trust check.
        authUrl = assertPublicHttpsEndpoint(provider.authorizationUrl, "OIDC authorization endpoint");
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error
                ? err.message
                : "Invalid OIDC authorization endpoint",
        }, 400);
    }
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("client_id", provider.clientId);
    authUrl.searchParams.set("redirect_uri", callbackUrl);
    authUrl.searchParams.set("scope", Array.from(new Set(["openid", ...scopes])).join(" "));
    authUrl.searchParams.set("state", state);
    authUrl.searchParams.set("nonce", nonce);
    authUrl.searchParams.set("code_challenge", providerCodeChallenge);
    authUrl.searchParams.set("code_challenge_method", "S256");
    await getChallengeStore().set(`oidc:${state}`, JSON.stringify({
        providerId: provider.id,
        tenantId,
        clientId,
        redirectUri,
        appState,
        codeChallenge,
        codeChallengeMethod,
        nonce,
        codeVerifier,
    }));
    return c.redirect(authUrl.toString(), 302);
});
auth.get("/oidc/:provider/callback", async (c) => {
    const providerId = c.req.param("provider");
    const code = c.req.query("code");
    const state = c.req.query("state");
    const errorParam = c.req.query("error");
    if (errorParam) {
        // Provider-supplied query text is untrusted and may contain diagnostics or
        // attacker-controlled markup. Do not reflect it to the browser.
        const recovery = await oauthCallbackRecoveryFromStoredState("oidc", state, providerId);
        return oauthCallbackFailure(c, {
            code: "oidc_authorization_failed",
            message: "The identity provider did not authorize this sign-in.",
            status: 400,
            ...recovery,
        });
    }
    if (!code || !state) {
        const recovery = await oauthCallbackRecoveryFromStoredState("oidc", state, providerId);
        return oauthCallbackFailure(c, {
            code: "oidc_callback_incomplete",
            message: "The identity provider returned an incomplete sign-in response.",
            status: 400,
            ...recovery,
        });
    }
    if (code.length > 4_096 || state.length > 256) {
        const recovery = await oauthCallbackRecoveryFromStoredState("oidc", state, providerId);
        return oauthCallbackFailure(c, {
            code: "oidc_callback_invalid",
            message: "The identity provider returned an invalid sign-in response.",
            status: 400,
            ...recovery,
        });
    }
    const stateKey = `oidc:${state}`;
    const rawPayload = await getChallengeStore().get(stateKey);
    if (!rawPayload) {
        return oauthCallbackFailure(c, {
            code: "oidc_state_expired",
            message: "This sign-in attempt is invalid or has expired.",
            status: 401,
        });
    }
    let stateData;
    try {
        stateData = JSON.parse(rawPayload);
    }
    catch {
        return oauthCallbackFailure(c, {
            code: "oidc_state_invalid",
            message: "This sign-in attempt could not be validated.",
            status: 400,
        });
    }
    if (stateData.providerId !== providerId) {
        return oauthCallbackFailure(c, {
            code: "oidc_provider_mismatch",
            message: "The identity provider does not match this sign-in attempt.",
            status: 400,
        });
    }
    const provider = selectOidcProvider(await getTenantOidcProviders(stateData.tenantId), providerId);
    if (!provider?.clientId || !provider.tokenUrl) {
        return oauthCallbackFailure(c, {
            code: "oidc_provider_unavailable",
            message: "This identity provider is not available.",
            status: 404,
        });
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, stateData.tenantId, "oidc", provider.id, stateData.clientId);
    if (methodResponse) {
        return oauthCallbackFailure(c, {
            code: "oidc_login_disabled",
            message: "OIDC sign-in is disabled for this application.",
            status: 403,
        });
    }
    let redirectUrl;
    try {
        redirectUrl = await assertAllowedOAuthRedirectUri(stateData.redirectUri, stateData.tenantId, stateData.clientId);
    }
    catch (err) {
        logger.error({
            details: [
                "[OidcAuth] Callback redirect validation failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oidc_redirect_invalid",
            message: "The application return address is not allowed.",
            status: 400,
        });
    }
    let idToken;
    try {
        idToken = await exchangeOidcAuthorizationCode({
            provider,
            tenantId: stateData.tenantId,
            code,
            redirectUri: buildOidcCallbackUrl(c, provider.id),
            codeVerifier: stateData.codeVerifier,
        });
    }
    catch (err) {
        logger.error({
            details: [
                "[OidcAuth] Callback token exchange failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oidc_token_exchange_failed",
            message: "The identity provider could not complete sign-in. Please try again.",
            status: 502,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    try {
        const verified = await verifyOidcJwt(stateData.tenantId, provider, idToken);
        if (verified.claims.nonce !== stateData.nonce) {
            return oauthCallbackFailure(c, {
                code: "oidc_nonce_mismatch",
                message: "This sign-in response could not be matched to your browser.",
                status: 401,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        if (!verified.email || verified.emailVerified !== true) {
            return oauthCallbackFailure(c, {
                code: "oidc_verified_email_required",
                message: "Enterprise OIDC sign-in requires a verified email address.",
                status: 403,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        if (!(await isVerifiedSsoEmailDomainForTenant(stateData.tenantId, verified.email))) {
            return oauthCallbackFailure(c, {
                code: "oidc_email_domain_unverified",
                message: "Your email domain is not approved for this organization.",
                status: 403,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        const consumedPayload = await getChallengeStore().consume(stateKey);
        if (consumedPayload !== rawPayload) {
            return oauthCallbackFailure(c, {
                code: "oidc_state_consumed",
                message: "This sign-in attempt is invalid or has already been used.",
                status: 401,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        await withPreAuthTenant(stateData.tenantId, "oidc-callback-authorization-audit", () => writeAuditEvent({
            tenantId: stateData.tenantId,
            actorType: "user",
            actorId: null,
            action: "auth.oidc.login.authorized",
            resourceType: "session",
            metadata: {
                providerId: provider.id,
                issuer: provider.issuer,
                oidcSubject: verified.subject,
                flow: "authorization_code",
            },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        }));
        const result = await provisionOidcUser({
            c,
            tenantId: stateData.tenantId,
            provider,
            subject: verified.subject,
            email: verified.email,
            emailVerified: verified.emailVerified,
            name: verified.name,
            picture: verified.picture,
            tenantRole: "viewer",
        });
        if (!result.ok) {
            return oauthCallbackFailure(c, {
                code: "oidc_account_provisioning_failed",
                message: "Your account could not be prepared for sign-in.",
                status: result.status ?? 500,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        if (result.response.ok === false) {
            return oauthCallbackFailure(c, {
                code: "oidc_authentication_failed",
                message: "Sign-in could not be completed.",
                status: 403,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        if (result.response.mfaRequired) {
            return oauthCallbackFailure(c, {
                code: "mfa_required",
                message: "Additional verification is required to complete sign-in.",
                status: 403,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        const exchangeCode = randomBase64Url(32);
        const issuedAt = Date.now();
        const expiresAt = issuedAt + OAUTH_CODE_TTL_MS;
        await getOAuthCodeStore().set(`oauth-code:${exchangeCode}`, JSON.stringify({
            providerName: `oidc:${provider.id}`,
            token: result.response.token,
            refreshToken: result.response.refreshToken,
            redirectUri: stateData.redirectUri,
            tenantId: stateData.tenantId,
            codeChallenge: stateData.codeChallenge,
            codeChallengeMethod: stateData.codeChallengeMethod ?? "S256",
            expiresAt,
            expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
        }));
        setRedirectFragment(redirectUrl, {
            code: exchangeCode,
            state: stateData.appState,
        });
        return c.redirect(redirectUrl.toString(), 302);
    }
    catch (err) {
        logger.error({
            details: [
                "[OidcAuth] Callback verification failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oidc_token_verification_failed",
            message: "The identity provider response could not be verified.",
            status: 401,
            redirectUrl,
            appState: stateData.appState,
        });
    }
});
/**
 * GET /test/inbox/:email
 *
 * Test-only endpoint. Returns the most recent magic-link email captured by
 * the in-memory MockEmailProvider. Gated by EMAIL_PROVIDER=mock + non-production
 * — returns 404 in any other configuration so it cannot leak in prod.
 */
auth.get("/test/inbox/:email", (c) => {
    if (!isMockEmailEnabled() || !authTestInboxEnabled()) {
        return c.json({ ok: false, error: "Not found" }, 404);
    }
    const email = decodeURIComponent(c.req.param("email"));
    const msg = MockEmailInbox.last(email);
    if (!msg) {
        return c.json({ ok: false, error: "No message" }, 404);
    }
    return c.json({
        ok: true,
        to: msg.to,
        subject: msg.subject,
        text: msg.text,
        token: msg.token,
        magicLink: msg.magicLink,
        sentAt: msg.sentAt.toISOString(),
    });
});
auth.get("/test/sms-inbox/:phone", (c) => {
    if (process.env.SMS_PROVIDER !== "mock" ||
        process.env.NODE_ENV === "production" ||
        !authTestInboxEnabled()) {
        return c.json({ ok: false, error: "Not found" }, 404);
    }
    const phone = decodeURIComponent(c.req.param("phone"));
    const msg = MockSmsInbox.last(phone);
    if (!msg) {
        return c.json({ ok: false, error: "No message" }, 404);
    }
    return c.json({
        ok: true,
        to: msg.to,
        body: msg.body,
        code: msg.code,
        sentAt: msg.sentAt.toISOString(),
    });
});
/**
 * POST /test/token
 *
 * Exchanges a tenant's explicitly enabled test-account credentials for a
 * normal short-lived session token. This mirrors Privy-style app-review and
 * automation credentials without exposing mock inboxes or bypassing tenant
 * membership for arbitrary users.
 */
auth.post("/test/token", async (c) => {
    // ⚠️ SECURITY WARNING — STEWARD_ENABLE_PROD_TEST_ACCOUNT_TOKEN ⚠️
    // This endpoint mints a real, fully-privileged session token for a tenant's
    // test-account credentials. It is hard-disabled in production by default.
    // Setting STEWARD_ENABLE_PROD_TEST_ACCOUNT_TOKEN=true in a production
    // environment is DANGEROUS: anyone who learns the (often static) test-account
    // email/phone/OTP can obtain a valid session. Only enable it for short,
    // supervised app-review / automation windows and disable it immediately
    // afterward. Never leave it enabled on an internet-reachable prod deploy.
    if (process.env.NODE_ENV === "production" &&
        process.env.STEWARD_ENABLE_PROD_TEST_ACCOUNT_TOKEN !== "true") {
        return c.json({ ok: false, error: "Test account token exchange is disabled" }, 404);
    }
    const rl = await checkAuthRateLimit(c, "test-account-token", 10_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many test account attempts. Try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    const tenantId = c.req.header("X-Steward-Tenant")?.trim() || body?.tenantId?.trim();
    if (!tenantId) {
        return c.json({ ok: false, error: "tenantId is required" }, 400);
    }
    const testAccount = (await authTenantConfigSubject(tenantId))?.test_account;
    if (!isEnabledTestAccount(testAccount)) {
        return c.json(invalidTestAccountCredentials(), 401);
    }
    const emailMatches = testCredentialMatches(body?.email, testAccount.email);
    const phoneMatches = testCredentialMatches(body?.phone, testAccount.phone);
    if (!emailMatches && !phoneMatches) {
        return c.json(invalidTestAccountCredentials(), 401);
    }
    const credentialSubject = hashSha256Hex([
        tenantId.toLowerCase(),
        emailMatches ? `email:${testAccount.email.trim().toLowerCase()}` : "",
        phoneMatches ? `phone:${testAccount.phone.trim()}` : "",
    ].join(":"));
    const credentialRl = await checkAuthRateLimit(c, "test-account-token-credential", 10 * 60_000, 5, credentialSubject);
    if (!credentialRl.allowed) {
        return c.json({ ok: false, error: "Too many test account attempts. Try again later." }, 429);
    }
    if (!testAccountOtpMatches(body?.otp, testAccount)) {
        return c.json(invalidTestAccountCredentials(), 401);
    }
    if (emailMatches) {
        const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "email");
        if (methodResponse)
            return methodResponse;
        const authResult = await completeEmailAuth(c, testAccount.email, tenantId, {
            allowTenantJoin: true,
        });
        if (!authResult.ok) {
            return c.json({ ok: false, error: authResult.error }, authResult.status);
        }
        await writeAuditEvent({
            tenantId,
            actorType: "user",
            actorId: typeof authResult.response.user === "object" &&
                authResult.response.user !== null &&
                "id" in authResult.response.user
                ? String(authResult.response.user.id)
                : null,
            action: "auth.test_account.login",
            resourceType: "session",
            metadata: { method: "email" },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: null,
        });
        return authExchangeJson(c, authResult.response);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "sms");
    if (methodResponse)
        return methodResponse;
    const { user, isNew } = await findOrCreatePhoneUserWithStatus(testAccount.phone);
    await ensurePersonalTenant(user.id, `Phone ${testAccount.phone.slice(-4)}`);
    await ensureUserTenantLink(user.id, tenantId, "member");
    if (isNew) {
        dispatchUserCreated(tenantId, user.id, "auth.test_account", {
            hasPhone: true,
        });
    }
    const response = await buildAuthOrMfaResponse(user.id, tenantId, user.walletAddress ?? "", {
        userId: user.id,
        phoneHash: hashSha256Hex(testAccount.phone),
        authMethod: "test_account",
    }, {
        id: user.id,
        email: "",
        walletAddress: user.walletAddress,
    });
    await writeAuditEvent({
        tenantId,
        actorType: "user",
        actorId: user.id,
        action: "auth.test_account.login",
        resourceType: "session",
        metadata: { method: "phone" },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: null,
    });
    return authExchangeJson(c, response);
});
// ── SMS OTP ─────────────────────────────────────────────────────────────────
auth.post("/sms/send", async (c) => {
    const rl = await checkAuthRateLimit(c, "sms-send", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!isValidE164(body?.phone)) {
        return c.json({ ok: false, error: "phone must be E.164" }, 400);
    }
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const bodyTenantId = body.tenantId?.trim();
    const resolvedTenantId = authTenantHint(c, body.tenantId);
    const tenantHintError = await validateExplicitAuthTenantHint(resolvedTenantId, Boolean(headerTenantId || bodyTenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "sms");
    if (methodResponse)
        return methodResponse;
    const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
    const phonePolicyError = validatePhoneAbusePolicy(body.phone, authAbuseConfig);
    if (phonePolicyError) {
        return c.json({ ok: false, error: phonePolicyError }, 400);
    }
    const captcha = await verifyCaptchaToken(authAbuseConfig, "sms_otp", body.captchaToken, trustedClientIp(c));
    if (!captcha.ok) {
        return c.json({ ok: false, error: captcha.error }, captcha.status);
    }
    const phoneRl = await checkAuthRateLimit(c, "sms-send-destination", 10 * 60_000, 5, body.phone);
    if (!phoneRl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    let expiresAt;
    try {
        ({ expiresAt } = await getPhoneAuth().sendOtp(body.phone, smsLoginPurpose(resolvedTenantId), "sms"));
    }
    catch (err) {
        if (err instanceof Error && err.message === "SMS provider not configured") {
            return c.json({ ok: false, error: "SMS provider not configured" }, 503);
        }
        throw err;
    }
    return c.json({ ok: true, expiresAt: expiresAt.toISOString() });
});
auth.post("/sms/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "sms-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!isValidE164(body?.phone) || typeof body?.code !== "string") {
        return c.json({ ok: false, error: "phone and code are required" }, 400);
    }
    const otpTenantId = authTenantHint(c, body.tenantId);
    const tenantHintError = await validateExplicitAuthTenantHint(otpTenantId, Boolean(c.req.header("X-Steward-Tenant") || body.tenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, otpTenantId, "sms");
    if (methodResponse)
        return methodResponse;
    const otpPurpose = smsLoginPurpose(otpTenantId);
    // Claim-first: atomically consume one attempt slot BEFORE verifying, so
    // concurrent requests cannot both pass a check-then-record boundary and
    // stretch the attempt budget (~2x under a race).
    const attemptClaim = await claimSmsVerifyAttempt(body.phone, otpPurpose);
    if (!attemptClaim) {
        return c.json({
            ok: false,
            error: "Too many invalid codes. Request a new code and try again later.",
        }, 429);
    }
    let result;
    try {
        result = await getPhoneAuth().verifyOtp(body.phone, body.code, otpPurpose);
    }
    catch (error) {
        await releaseUnattemptedSmsVerifyClaim(attemptClaim, error);
        throw error;
    }
    if (!result.valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    await clearSmsVerifyFailures(body.phone, otpPurpose);
    const { user, isNew } = await findOrCreatePhoneUserWithStatus(body.phone);
    const tenantResult = await resolveAndValidateTenant(c, user.id, body.tenantId);
    if (!tenantResult.ok) {
        return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
    }
    const authAbuseConfig = await getTenantAuthAbuseConfig(tenantResult.tenantId);
    const phonePolicyError = validatePhoneAbusePolicy(body.phone, authAbuseConfig);
    if (phonePolicyError) {
        return c.json({ ok: false, error: phonePolicyError }, 400);
    }
    await ensurePersonalTenant(user.id, `Phone ${body.phone.slice(-4)}`);
    await ensureUserTenantLink(user.id, tenantResult.tenantId, tenantResult.isPersonal ? "owner" : "member");
    if (isNew) {
        dispatchUserCreated(tenantResult.tenantId, user.id, "auth.sms", {
            hasPhone: true,
        });
    }
    return authExchangeJson(c, await buildAuthOrMfaResponse(user.id, tenantResult.tenantId, user.walletAddress ?? "", {
        userId: user.id,
        phoneHash: hashSha256Hex(body.phone),
        authMethod: "sms",
    }, {
        id: user.id,
        email: "",
        walletAddress: user.walletAddress,
    }, c));
});
auth.post("/whatsapp/send", async (c) => {
    if (!isWhatsAppOtpEnabled()) {
        return c.json({ ok: false, error: "WhatsApp OTP is not configured" }, 503);
    }
    const rl = await checkAuthRateLimit(c, "whatsapp-send", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!isValidE164(body?.phone)) {
        return c.json({ ok: false, error: "phone must be E.164" }, 400);
    }
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const bodyTenantId = body.tenantId?.trim();
    const resolvedTenantId = authTenantHint(c, body.tenantId);
    const tenantHintError = await validateExplicitAuthTenantHint(resolvedTenantId, Boolean(headerTenantId || bodyTenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "whatsapp");
    if (methodResponse)
        return methodResponse;
    const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
    const phonePolicyError = validatePhoneAbusePolicy(body.phone, authAbuseConfig);
    if (phonePolicyError) {
        return c.json({ ok: false, error: phonePolicyError }, 400);
    }
    const captcha = await verifyCaptchaToken(authAbuseConfig, "sms_otp", body.captchaToken, trustedClientIp(c));
    if (!captcha.ok) {
        return c.json({ ok: false, error: captcha.error }, captcha.status);
    }
    const phoneRl = await checkAuthRateLimit(c, "whatsapp-send-destination", 10 * 60_000, 5, body.phone);
    if (!phoneRl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    let expiresAt;
    try {
        ({ expiresAt } = await getPhoneAuth().sendOtp(body.phone, whatsappLoginPurpose(resolvedTenantId), "whatsapp"));
    }
    catch (err) {
        if (err instanceof Error && err.message === "SMS provider not configured") {
            return c.json({ ok: false, error: "WhatsApp OTP provider not configured" }, 503);
        }
        throw err;
    }
    return c.json({ ok: true, expiresAt: expiresAt.toISOString() });
});
auth.post("/whatsapp/verify", async (c) => {
    if (!isWhatsAppOtpEnabled()) {
        return c.json({ ok: false, error: "WhatsApp OTP is not configured" }, 503);
    }
    const rl = await checkAuthRateLimit(c, "whatsapp-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!isValidE164(body?.phone) || typeof body?.code !== "string") {
        return c.json({ ok: false, error: "phone and code are required" }, 400);
    }
    const otpTenantId = authTenantHint(c, body.tenantId);
    const tenantHintError = await validateExplicitAuthTenantHint(otpTenantId, Boolean(c.req.header("X-Steward-Tenant") || body.tenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, otpTenantId, "whatsapp");
    if (methodResponse)
        return methodResponse;
    const otpPurpose = whatsappLoginPurpose(otpTenantId);
    // Claim-first: atomically consume one attempt slot BEFORE verifying, so
    // concurrent requests cannot both pass a check-then-record boundary and
    // stretch the attempt budget (~2x under a race).
    const attemptClaim = await claimSmsVerifyAttempt(body.phone, otpPurpose);
    if (!attemptClaim) {
        return c.json({
            ok: false,
            error: "Too many invalid codes. Request a new code and try again later.",
        }, 429);
    }
    let result;
    try {
        result = await getPhoneAuth().verifyOtp(body.phone, body.code, otpPurpose);
    }
    catch (error) {
        await releaseUnattemptedSmsVerifyClaim(attemptClaim, error);
        throw error;
    }
    if (!result.valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    await clearSmsVerifyFailures(body.phone, otpPurpose);
    const { user, isNew } = await findOrCreatePhoneUserWithStatus(body.phone, "whatsapp");
    const tenantResult = await resolveAndValidateTenant(c, user.id, body.tenantId);
    if (!tenantResult.ok) {
        return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
    }
    const authAbuseConfig = await getTenantAuthAbuseConfig(tenantResult.tenantId);
    const phonePolicyError = validatePhoneAbusePolicy(body.phone, authAbuseConfig);
    if (phonePolicyError) {
        return c.json({ ok: false, error: phonePolicyError }, 400);
    }
    await ensurePersonalTenant(user.id, `Phone ${body.phone.slice(-4)}`);
    await ensureUserTenantLink(user.id, tenantResult.tenantId, tenantResult.isPersonal ? "owner" : "member");
    if (isNew) {
        dispatchUserCreated(tenantResult.tenantId, user.id, "auth.whatsapp", {
            hasPhone: true,
            channel: "whatsapp",
        });
    }
    return authExchangeJson(c, await buildAuthOrMfaResponse(user.id, tenantResult.tenantId, user.walletAddress ?? "", {
        userId: user.id,
        phoneHash: hashSha256Hex(body.phone),
        authMethod: "whatsapp",
    }, {
        id: user.id,
        email: "",
        walletAddress: user.walletAddress,
    }, c));
});
// ── SIWE ──────────────────────────────────────────────────────────────────────
/**
 * GET /nonce
 * Returns a fresh one-time nonce for SIWE/SIWS message construction, bound to
 * the expected domain, chainId, and optional tenant hint.
 */
auth.get("/nonce", async (c) => {
    const rl = await checkAuthRateLimit(c, "siwe-nonce", 60_000, 30);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many nonce requests. Please try again later." }, 429);
    }
    const nonce = generateNonce();
    const tenantId = c.req.header("X-Steward-Tenant")?.trim() || c.req.query("tenantId")?.trim();
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "siwe");
    if (methodResponse)
        return methodResponse;
    const originHost = requiredOriginHostFromRequest(c);
    if (!originHost) {
        return c.json({
            ok: false,
            error: "SIWE nonce requests require an allowed Origin or Referer",
        }, 400);
    }
    await setSiweNonce(nonce, {
        allowedDomains: getAllowedSiweDomains(),
        originHost,
        tenantId: tenantId || undefined,
    });
    return c.json({ nonce });
});
/**
 * POST /verify
 * Body: { message: string; signature: string }
 * Verifies SIWE, auto-creates the wallet-owned tenant, returns JWT.
 *
 * SIWE flow is wallet-address-centric: each unique address gets its own tenant.
 * If X-Steward-Tenant is provided, the JWT may target that tenant only when the
 * wallet user already has an existing membership. Supplying a tenant header does
 * not create a new membership.
 */
auth.post("/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "siwe-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.message || !body?.signature) {
        return c.json({ ok: false, error: "message and signature are required" }, 400);
    }
    // ──────────────────────────────────────────────────────────────────────────
    // Lenient EIP-55 path: the `siwe` library strictly enforces EIP-55 checksum
    // on the address line and throws "invalid EIP-55 address" when wallets emit
    // a lower-case address (wagmi default for many adapters, including the most
    // common MetaMask path). The signature is over the EXACT bytes the user
    // signed, so we MUST verify against `body.message` literally, not against a
    // normalized copy. We split the work:
    //   1. Try parsing as-is. If that works, fall through to the canonical path.
    //   2. If parsing fails because of EIP-55 casing, build a normalized copy
    //      with the address line re-checksummed via viem, parse THAT to extract
    //      fields (nonce / domain / chainId / etc), and verify the signature
    //      against the ORIGINAL untouched message with viem's verifyMessage.
    // This preserves cryptographic integrity while accepting SDK clients that
    // forgot to checksum.
    // ──────────────────────────────────────────────────────────────────────────
    function normalizeAddressLine(msg) {
        const lines = msg.split("\n");
        if (lines.length < 2)
            return msg;
        const candidate = lines[1].trim();
        if (!/^0x[a-fA-F0-9]{40}$/.test(candidate))
            return msg;
        try {
            lines[1] = getAddress(candidate);
        }
        catch {
            // not a valid hex address; let siwe surface the right error
        }
        return lines.join("\n");
    }
    let siweMessage;
    let usedNormalizedParse = false;
    try {
        siweMessage = new SiweMessage(body.message);
    }
    catch {
        // Retry with EIP-55 normalized address line.
        try {
            siweMessage = new SiweMessage(normalizeAddressLine(body.message));
            usedNormalizedParse = true;
        }
        catch {
            return c.json({ ok: false, error: "Invalid SIWE message format" }, 400);
        }
    }
    const allowedDomains = getAllowedSiweDomains();
    if (!allowedDomains.includes(siweMessage.domain.toLowerCase())) {
        return c.json({ ok: false, error: "SIWE domain not allowed" }, 401);
    }
    if (!siweMessage.issuedAt) {
        return c.json({ ok: false, error: "SIWE issuedAt is required" }, 401);
    }
    const siwePolicyError = evaluateSiwePolicy({
        domain: siweMessage.domain.toLowerCase(),
        address: siweMessage.address,
        statement: siweMessage.statement,
        uri: siweMessage.uri,
        version: siweMessage.version,
        chainId: siweMessage.chainId,
        nonce: siweMessage.nonce,
        issuedAt: siweMessage.issuedAt ?? "",
        expirationTime: siweMessage.expirationTime,
        notBefore: siweMessage.notBefore,
    }, { allowedDomains });
    if (siwePolicyError) {
        return c.json({ ok: false, error: `SIWE policy violation: ${siwePolicyError}` }, 401);
    }
    const requestedTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const methodResponse = await requireTenantLoginMethodAllowed(c, requestedTenantId, "siwe");
    if (methodResponse)
        return methodResponse;
    const nonceError = validateConsumedSiweNonce(await consumeSiweNonce(siweMessage.nonce), {
        domain: siweMessage.domain,
        tenantId: requestedTenantId,
    });
    if (nonceError) {
        return c.json({ ok: false, error: nonceError }, 401);
    }
    // Enforce SIWE temporal constraints before any signature verification path.
    // siwe.verify() bundles temporal + signature checks together, but that means
    // a signature-only fallback (EIP-1271) would silently bypass time bounds.
    // Check expiration / notBefore first so smart contract wallets cannot use
    // an expired or not-yet-valid message.
    const now = new Date();
    if (siweMessage.expirationTime) {
        const exp = new Date(siweMessage.expirationTime);
        if (Number.isNaN(exp.getTime())) {
            return c.json({ ok: false, error: "Invalid expirationTime" }, 401);
        }
        if (now >= exp) {
            return c.json({ ok: false, error: "Message expired" }, 401);
        }
    }
    if (siweMessage.notBefore) {
        const nb = new Date(siweMessage.notBefore);
        if (Number.isNaN(nb.getTime())) {
            return c.json({ ok: false, error: "Invalid notBefore" }, 401);
        }
        if (now < nb) {
            return c.json({ ok: false, error: "Message not yet valid" }, 401);
        }
    }
    // Try EOA verification first (siwe uses ECDSA recover internally). If that
    // fails, fall back to EIP-1271 for smart contract wallets (Safes, Argent, etc).
    //
    // When we used the EIP-55 normalized parse path above, siwe.verify would
    // reconstruct the message FROM the normalized fields and recover against
    // that, which won't match a signature taken over the original lower-case
    // bytes. So in that path we use viem's verifyMessage which verifies the
    // signature against the raw `body.message` literally.
    let eoaVerified = false;
    if (usedNormalizedParse) {
        try {
            eoaVerified = await viemVerifyMessage({
                address: siweMessage.address,
                message: body.message,
                signature: body.signature,
            });
        }
        catch {
            eoaVerified = false;
        }
    }
    else {
        try {
            await siweMessage.verify({ signature: body.signature });
            eoaVerified = true;
        }
        catch {
            eoaVerified = false;
        }
    }
    if (!eoaVerified) {
        const eip1271Result = await verifyEip1271({
            address: siweMessage.address,
            message: body.message,
            signature: body.signature,
            chainId: siweMessage.chainId,
        });
        if (!eip1271Result.ok) {
            return c.json({ ok: false, error: "Invalid signature" }, 401);
        }
    }
    const address = siweMessage.address.toLowerCase();
    let tenantResult;
    try {
        tenantResult = await findOrCreateWalletTenant({
            ownerAddress: address,
            tenantId: ethereumWalletTenantId(address),
            tenantName: `${address.slice(0, 6)}...${address.slice(-4)}`,
        });
    }
    catch {
        return c.json({ ok: false, error: "Failed to create tenant" }, 500);
    }
    const { user, isNew: isNewUser } = await findOrCreateWalletUserWithStatus(address, "ethereum");
    let effectiveTenantId = tenantResult.tenant.id;
    if (requestedTenantId && requestedTenantId !== tenantResult.tenant.id) {
        const tenantResolution = await resolveAndValidateTenant(c, user.id, requestedTenantId);
        if (!tenantResolution.ok) {
            return c.json({ ok: false, error: tenantResolution.error }, tenantResolution.status);
        }
        effectiveTenantId = tenantResolution.tenantId;
    }
    const effectiveMethodResponse = await requireTenantLoginMethodAllowed(c, effectiveTenantId, "siwe");
    if (effectiveMethodResponse)
        return effectiveMethodResponse;
    const authAbuseConfig = await getTenantAuthAbuseConfig(effectiveTenantId);
    const walletPolicyError = validateWalletAbusePolicy(address, "ethereum", authAbuseConfig);
    if (walletPolicyError) {
        return c.json({ ok: false, error: walletPolicyError }, 403);
    }
    await ensureUserTenantLink(user.id, effectiveTenantId, effectiveTenantId === tenantResult.tenant.id ? "owner" : "member");
    if (isNewUser) {
        dispatchUserCreated(effectiveTenantId, user.id, "auth.siwe", {
            walletChain: "ethereum",
        });
    }
    const responseData = await buildAuthOrMfaResponse(user.id, effectiveTenantId, address, {
        userId: user.id,
        authMethod: "siwe",
    }, {
        id: user.id,
        address,
        walletAddress: address,
        walletChain: "ethereum",
    });
    await writeAuditEvent({
        tenantId: effectiveTenantId,
        actorType: "user",
        actorId: user.id,
        action: "auth.login",
        resourceType: "session",
        metadata: { method: "siwe", address, walletChain: "ethereum" },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    responseData.userId = user.id;
    responseData.address = address;
    responseData.walletChain = "ethereum";
    responseData.tenant = {
        id: tenantResult.tenant.id,
        name: tenantResult.tenant.name,
    };
    if (!responseData.mfaRequired &&
        tenantResult.isNewTenant &&
        tenantResult.rawApiKey) {
        responseData.tenant.apiKey =
            tenantResult.rawApiKey;
    }
    return authExchangeJson(c, responseData);
});
auth.post("/verify/solana", async (c) => {
    const rl = await checkAuthRateLimit(c, "siws-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.message || !body?.signature || !body?.publicKey) {
        return c.json({ ok: false, error: "message, signature, and publicKey are required" }, 400);
    }
    const parsed = parseSiwsMessage(body.message);
    if (!parsed) {
        return c.json({ ok: false, error: "Invalid SIWS message format" }, 400);
    }
    if (parsed.publicKey !== body.publicKey) {
        return c.json({ ok: false, error: "publicKey does not match signed message" }, 401);
    }
    const allowedDomains = getAllowedSiweDomains();
    if (!allowedDomains.includes(parsed.domain.toLowerCase())) {
        return c.json({ ok: false, error: "SIWS domain not allowed" }, 401);
    }
    if (!isAllowedSiwsUri(parsed.uri, parsed.domain)) {
        return c.json({ ok: false, error: "SIWS uri must match the signed domain" }, 401);
    }
    if (parsed.version !== "1") {
        return c.json({ ok: false, error: 'SIWS version must be "1"' }, 401);
    }
    if (!isAllowedSiwsChainId(parsed.chainId)) {
        return c.json({
            ok: false,
            error: "SIWS chainId must be one of: solana, mainnet, devnet",
        }, 401);
    }
    // Honor the signed message's own temporal bounds, mirroring the EVM SIWE
    // path. Reject an already-expired or not-yet-valid message BEFORE consuming
    // the single-use nonce, so a stale message cannot burn a fresh nonce.
    const now = new Date();
    if (parsed.expirationTime) {
        const exp = new Date(parsed.expirationTime);
        if (Number.isNaN(exp.getTime())) {
            return c.json({ ok: false, error: "Invalid expirationTime" }, 401);
        }
        if (now >= exp) {
            return c.json({ ok: false, error: "Message expired" }, 401);
        }
    }
    if (parsed.notBefore) {
        const nb = new Date(parsed.notBefore);
        if (Number.isNaN(nb.getTime())) {
            return c.json({ ok: false, error: "Invalid notBefore" }, 401);
        }
        if (now < nb) {
            return c.json({ ok: false, error: "Message not yet valid" }, 401);
        }
    }
    const requestedTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const methodResponse = await requireTenantLoginMethodAllowed(c, requestedTenantId, "siws");
    if (methodResponse)
        return methodResponse;
    const nonceError = validateConsumedSiweNonce(await consumeSiweNonce(parsed.nonce), {
        domain: parsed.domain,
        tenantId: requestedTenantId,
    });
    if (nonceError) {
        return c.json({ ok: false, error: nonceError }, 401);
    }
    if (!verifySolanaMessageSignature(body.message, body.signature, body.publicKey)) {
        return c.json({ ok: false, error: "Invalid signature" }, 401);
    }
    let tenantResult;
    try {
        tenantResult = await findOrCreateWalletTenant({
            ownerAddress: `solana:${body.publicKey}`,
            tenantId: `solana:${body.publicKey}`,
            tenantName: `${body.publicKey.slice(0, 4)}...${body.publicKey.slice(-4)}`,
        });
    }
    catch {
        return c.json({ ok: false, error: "Failed to create tenant" }, 500);
    }
    const { user, isNew: isNewUser } = await findOrCreateWalletUserWithStatus(body.publicKey, "solana");
    let effectiveTenantId = tenantResult.tenant.id;
    if (requestedTenantId && requestedTenantId !== tenantResult.tenant.id) {
        const tenantResolution = await resolveAndValidateTenant(c, user.id, requestedTenantId);
        if (!tenantResolution.ok) {
            return c.json({ ok: false, error: tenantResolution.error }, tenantResolution.status);
        }
        effectiveTenantId = tenantResolution.tenantId;
    }
    const effectiveMethodResponse = await requireTenantLoginMethodAllowed(c, effectiveTenantId, "siws");
    if (effectiveMethodResponse)
        return effectiveMethodResponse;
    const authAbuseConfig = await getTenantAuthAbuseConfig(effectiveTenantId);
    const walletPolicyError = validateWalletAbusePolicy(body.publicKey, "solana", authAbuseConfig);
    if (walletPolicyError) {
        return c.json({ ok: false, error: walletPolicyError }, 403);
    }
    await ensureUserTenantLink(user.id, effectiveTenantId, effectiveTenantId === tenantResult.tenant.id ? "owner" : "member");
    if (isNewUser) {
        dispatchUserCreated(effectiveTenantId, user.id, "auth.siws", {
            walletChain: "solana",
        });
    }
    const responseData = await buildAuthOrMfaResponse(user.id, effectiveTenantId, body.publicKey, {
        userId: user.id,
        authMethod: "siws",
    }, {
        id: user.id,
        address: body.publicKey,
        publicKey: body.publicKey,
        walletAddress: body.publicKey,
        walletChain: "solana",
    }, c);
    responseData.userId = user.id;
    responseData.address = body.publicKey;
    responseData.publicKey = body.publicKey;
    responseData.walletChain = "solana";
    responseData.tenant = {
        id: tenantResult.tenant.id,
        name: tenantResult.tenant.name,
    };
    if (!responseData.mfaRequired &&
        tenantResult.isNewTenant &&
        tenantResult.rawApiKey) {
        responseData.tenant.apiKey =
            tenantResult.rawApiKey;
    }
    return authExchangeJson(c, responseData);
});
/**
 * GET /session
 * Requires: Authorization: Bearer <token>
 */
auth.get("/session", async (c) => {
    const authHeader = c.req.header("Authorization");
    if (!authHeader?.startsWith("Bearer "))
        return c.json({ authenticated: false });
    const token = authHeader.slice(7);
    const payload = await verifySessionToken(token);
    if (!payload)
        return c.json({ authenticated: false });
    return c.json({
        authenticated: true,
        address: payload.address,
        tenantId: payload.tenantId,
        ...(payload.email ? { email: payload.email } : {}),
        ...(payload.userId ? { userId: payload.userId } : {}),
    });
});
/**
 * POST /device/code
 * RFC 8628-style device authorization issuance.
 * Body: { tenantId, client_id?/clientId?/app_client_id?, scope? }
 */
auth.post("/device/code", async (c) => {
    const rl = await checkAuthRateLimit(c, "device-code", 60_000, 20);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many device code requests" }, 429);
    }
    const body = await safeJsonParse(c);
    const tenantId = body?.tenantId?.trim() || c.req.header("X-Steward-Tenant")?.trim();
    if (!tenantId) {
        return c.json({ ok: false, error: "tenantId is required" }, 400);
    }
    const rawClientId = body?.client_id ??
        body?.clientId ??
        body?.app_client_id ??
        body?.appClientId;
    const validation = await assertDeviceAuthTenantAndClient(tenantId, rawClientId, readNativeClientAssertion(c, body));
    if (!validation.ok) {
        return c.json({ ok: false, error: validation.error }, validation.status);
    }
    const deviceCode = randomBase64Url(32);
    let userCode = generateDeviceUserCode();
    for (let i = 0; i < 5 && (await getMfaBackend().get(deviceUserCodeKey(userCode))); i += 1) {
        userCode = generateDeviceUserCode();
    }
    if (await getMfaBackend().get(deviceUserCodeKey(userCode))) {
        return c.json({ ok: false, error: "Unable to issue device code" }, 500);
    }
    const issuedAt = Date.now();
    const record = {
        tenantId,
        ...(validation.clientId ? { clientId: validation.clientId } : {}),
        ...(validation.nativeBundleId
            ? { nativeBundleId: validation.nativeBundleId }
            : {}),
        ...(validation.nativePackageName
            ? { nativePackageName: validation.nativePackageName }
            : {}),
        userCode,
        ...(body?.scope ? { scope: body.scope.trim().slice(0, 512) } : {}),
        status: "pending",
        issuedAt,
        expiresAt: issuedAt + DEVICE_AUTH_TTL_MS,
        intervalSeconds: DEVICE_AUTH_DEFAULT_INTERVAL_SECONDS,
        slowDownCount: 0,
    };
    await saveDeviceAuthorizationRecord(deviceCode, record);
    const verificationUri = `${authCallbackBaseUrl(c)}/auth/device`;
    return c.json({
        ok: true,
        device_code: deviceCode,
        user_code: displayDeviceUserCode(userCode),
        verification_uri: verificationUri,
        verification_uri_complete: `${verificationUri}?user_code=${encodeURIComponent(displayDeviceUserCode(userCode))}`,
        expires_in: Math.floor(DEVICE_AUTH_TTL_MS / 1000),
        interval: DEVICE_AUTH_DEFAULT_INTERVAL_SECONDS,
        tenantId,
        ...(validation.clientId ? { client_id: validation.clientId } : {}),
        ...(validation.nativeBundleId
            ? { native_bundle_id: validation.nativeBundleId }
            : {}),
        ...(validation.nativePackageName
            ? { native_package_name: validation.nativePackageName }
            : {}),
    });
});
/**
 * POST /device/verify
 * Authenticated approval/denial endpoint for the user code shown on a device.
 * Body: { user_code/userCode, action?: "approve" | "deny" }
 */
auth.post("/device/verify", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "device-verify", 60_000, 10, `user:${session.payload.userId}`);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many device verification attempts" }, 429);
    }
    const body = await safeJsonParse(c);
    const userCode = normalizeDeviceUserCode(body?.user_code ?? body?.userCode);
    if (!userCode) {
        return c.json({ ok: false, error: "Valid user_code is required" }, 400);
    }
    const action = body?.action === "deny" ? "deny" : "approve";
    const found = await readDeviceAuthorizationRecordByUserCode(userCode);
    if (!found) {
        return c.json({ ok: false, error: "Invalid or expired user code" }, 404);
    }
    const { deviceCodeHash, record } = found;
    if (record.status !== "pending") {
        return c.json({ ok: false, error: "Device code has already been handled" }, 409);
    }
    if (record.tenantId !== session.payload.tenantId) {
        return c.json({ ok: false, error: "Device code tenant mismatch" }, 403);
    }
    if (!(await isActiveTenantMember(session.payload.userId, record.tenantId))) {
        return c.json({ ok: false, error: "User is not a member of this tenant" }, 403);
    }
    const next = action === "deny"
        ? { ...record, status: "denied", deniedAt: Date.now() }
        : {
            ...record,
            status: "approved",
            approvedUserId: session.payload.userId,
            approvedAt: Date.now(),
        };
    await saveDeviceAuthorizationRecordByHash(deviceCodeHash, next);
    await writeAuditEvent({
        tenantId: record.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: action === "deny" ? "auth.device.deny" : "auth.device.approve",
        resourceType: "session",
        metadata: { clientId: record.clientId ?? null },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    return c.json({ ok: true, status: next.status, tenantId: record.tenantId });
});
/**
 * POST /device/token
 * Body: { grant_type, device_code, client_id?/clientId? }
 */
auth.post("/device/token", async (c) => {
    const rl = await checkAuthRateLimit(c, "device-token", 60_000, 60);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "slow_down", interval: rl.retryAfterSecs ?? 60 }, 429);
    }
    const body = await safeJsonParse(c);
    if (body?.grant_type !== "urn:ietf:params:oauth:grant-type:device_code") {
        return c.json({ ok: false, error: "unsupported_grant_type" }, 400);
    }
    const deviceCode = body.device_code ?? body.deviceCode;
    if (typeof deviceCode !== "string" || deviceCode.trim().length < 20) {
        return c.json({ ok: false, error: "invalid_request" }, 400);
    }
    const record = await readDeviceAuthorizationRecord(deviceCode);
    if (!record) {
        return c.json({ ok: false, error: "expired_token" }, 400);
    }
    const rawClientId = body.client_id ?? body.clientId ?? body.app_client_id ?? body.appClientId;
    const clientId = rawClientId
        ? normalizePublicClientId(rawClientId)
        : undefined;
    if (rawClientId && !clientId) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    if (record.clientId && clientId !== record.clientId) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    const nativeAssertion = readNativeClientAssertion(c, body);
    const nativeBundleId = nativeAssertion.rawBundleId === undefined
        ? undefined
        : normalizeNativeBundleId(nativeAssertion.rawBundleId);
    if (nativeAssertion.rawBundleId !== undefined && !nativeBundleId) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    const nativePackageName = nativeAssertion.rawPackageName === undefined
        ? undefined
        : normalizeNativePackageName(nativeAssertion.rawPackageName);
    if (nativeAssertion.rawPackageName !== undefined && !nativePackageName) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    if (nativeBundleId && !record.nativeBundleId) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    if (nativePackageName && !record.nativePackageName) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    if (record.nativeBundleId && nativeBundleId !== record.nativeBundleId) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    if (record.nativePackageName &&
        nativePackageName !== record.nativePackageName) {
        return c.json({ ok: false, error: "invalid_client" }, 401);
    }
    if (record.status === "denied") {
        await consumeDeviceAuthorizationRecord(deviceCode);
        return c.json({ ok: false, error: "access_denied" }, 400);
    }
    const now = Date.now();
    if (record.lastPollAt &&
        now - record.lastPollAt < record.intervalSeconds * 1000 &&
        record.slowDownCount < DEVICE_AUTH_MAX_SLOW_DOWNS) {
        const next = {
            ...record,
            intervalSeconds: record.intervalSeconds + 5,
            lastPollAt: now,
            slowDownCount: record.slowDownCount + 1,
        };
        await saveDeviceAuthorizationRecord(deviceCode, next);
        return c.json({ ok: false, error: "slow_down", interval: next.intervalSeconds }, 400);
    }
    if (record.status === "pending") {
        await saveDeviceAuthorizationRecord(deviceCode, {
            ...record,
            lastPollAt: now,
        });
        return c.json({
            ok: false,
            error: "authorization_pending",
            interval: record.intervalSeconds,
        }, 400);
    }
    const consumed = await consumeDeviceAuthorizationRecord(deviceCode);
    if (consumed?.status !== "approved" || !consumed.approvedUserId) {
        return c.json({ ok: false, error: "expired_token" }, 400);
    }
    const [user] = await getDb()
        .select({
        id: users.id,
        email: users.email,
        walletAddress: users.walletAddress,
        walletChain: users.walletChain,
    })
        .from(users)
        .where(eq(users.id, consumed.approvedUserId));
    if (!user || !(await isActiveTenantMember(user.id, consumed.tenantId))) {
        return c.json({ ok: false, error: "access_denied" }, 400);
    }
    const claims = {
        userId: user.id,
        ...(user.email ? { email: user.email } : {}),
        authMethod: "device_code",
        ...(consumed.clientId ? { appClientId: consumed.clientId } : {}),
    };
    const token = await createSessionToken(user.walletAddress ?? "", consumed.tenantId, claims);
    const refreshToken = await createRefreshToken(user.id, consumed.tenantId, claims);
    await writeAuthLoginAudit(c, consumed.tenantId, user.id, claims, {
        clientId: consumed.clientId ?? null,
        grantType: "device_code",
    });
    dispatchUserAuthenticated(consumed.tenantId, user.id, "device_code");
    return c.json({
        ok: true,
        token,
        access_token: token,
        token_type: "Bearer",
        refreshToken,
        refresh_token: refreshToken,
        expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
        expires_in: ACCESS_TOKEN_EXPIRY_SECONDS,
        user: {
            id: user.id,
            email: user.email,
            walletAddress: user.walletAddress ?? undefined,
            walletChain: user.walletChain ?? undefined,
        },
    });
});
auth.get("/identity-token", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    try {
        const claims = await buildIdentityClaims(session.payload.userId, session.payload.tenantId);
        const token = await createIdentityToken(claims);
        return c.json({
            ok: true,
            token,
            expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
            claims,
            user: {
                id: claims.userId,
                email: claims.email,
                emailVerified: claims.emailVerified,
                name: claims.name,
                image: claims.image,
                walletAddress: claims.walletAddress,
                walletChain: claims.walletChain,
                customMetadata: claims.customMetadata,
            },
        });
    }
    catch (err) {
        const message = err instanceof Error ? err.message : "Identity token generation failed";
        if (err instanceof IdentityJwtConfigurationError ||
            message === "Identity JWT private key is not configured") {
            return c.json({ ok: false, error: "Identity token unavailable" }, 503);
        }
        const status = message === "Not a member of this tenant" ? 403 : 404;
        return c.json({ ok: false, error: message }, status);
    }
});
// ── TOTP MFA ─────────────────────────────────────────────────────────────────
auth.get("/mfa/totp/status", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const enabled = Boolean(await readMfaJson(mfaKey("totp:enabled", session.payload.userId)));
    const pending = Boolean(await readMfaJson(mfaKey("totp:pending", session.payload.userId)));
    return c.json({ ok: true, enabled, pending });
});
auth.post("/mfa/totp/enroll", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const existing = await readMfaJson(mfaKey("totp:enabled", session.payload.userId));
    if (existing) {
        return c.json({
            ok: false,
            error: "TOTP is already enabled; unenroll it before enrolling a new secret",
        }, 409);
    }
    const stepUpResponse = await requireRecentFactorEnrollmentStepUp(c, session);
    if (stepUpResponse)
        return stepUpResponse;
    const secret = generateTotpSecret();
    const accountName = session.payload.email ||
        session.payload.address ||
        `user:${session.payload.userId}`;
    const issuer = process.env.TOTP_ISSUER || "elizaOS";
    await writeMfaJson(mfaKey("totp:pending", session.payload.userId), { secret, createdAt: new Date().toISOString() }, TOTP_PENDING_TTL_MS);
    return c.json({
        ok: true,
        secret,
        otpauthUri: buildOtpauthUri({ issuer, accountName, secret }),
        expiresAt: new Date(Date.now() + TOTP_PENDING_TTL_MS).toISOString(),
    });
});
auth.post("/mfa/totp/verify", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-totp-verify", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (typeof body?.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const pending = await readMfaJson(mfaKey("totp:pending", session.payload.userId));
    if (pending) {
        const existing = await readMfaJson(mfaKey("totp:enabled", session.payload.userId));
        if (existing) {
            await getMfaBackend().delete(mfaKey("totp:pending", session.payload.userId));
            return c.json({
                ok: false,
                error: "TOTP is already enabled; replacement requires unenrollment first",
            }, 409);
        }
        const stepUpResponse = await requireRecentFactorEnrollmentStepUp(c, session);
        if (stepUpResponse)
            return stepUpResponse;
        const result = await verifyTotp(pending.secret, body.code, {
            stepSec: TOTP_STEP_SEC,
        });
        if (!result.valid || typeof result.drift !== "number") {
            return c.json({ ok: false, error: "Invalid code" }, 401);
        }
        const stored = {
            secret: pending.secret,
            enabledAt: new Date().toISOString(),
            lastAcceptedStep: totpStepForDrift(result.drift),
        };
        await writeAuditEvent({
            tenantId: session.payload.tenantId,
            actorType: "user",
            actorId: session.payload.userId,
            action: "mfa.enable.authorized",
            resourceType: "user",
            resourceId: session.payload.userId,
            metadata: { factor: "totp" },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        });
        await writeMfaJson(mfaKey("totp:enabled", session.payload.userId), stored);
        await getMfaBackend().delete(mfaKey("totp:pending", session.payload.userId));
        const recoveryCodes = await generateRecoveryCodes(recoveryCodeStore, session.payload.userId);
        const { issuedBefore } = await revokeUserRefreshSessions(session.payload.userId);
        await writeAuditEvent({
            tenantId: session.payload.tenantId,
            actorType: "user",
            actorId: session.payload.userId,
            action: "mfa.enabled",
            resourceType: "user",
            resourceId: session.payload.userId,
            metadata: {
                factor: "totp",
                recoveryCodesIssued: recoveryCodes.length,
                revokedRefreshTokens: true,
                revokedAccessTokensIssuedBefore: issuedBefore,
            },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        });
        dispatchWebhook(session.payload.tenantId, session.payload.userId, "mfa.enabled", {
            userId: session.payload.userId,
            factor: "totp",
            recoveryCodesIssued: recoveryCodes.length,
        });
        dispatchWebhook(session.payload.tenantId, session.payload.userId, "wallet.recovery_setup", {
            userId: session.payload.userId,
            source: "totp_enable",
            recoveryCodesIssued: recoveryCodes.length,
        });
        return c.json({ ok: true, enabled: true, recoveryCodes });
    }
    const verified = await verifyStoredTotp(session.payload.userId, body.code);
    if (!verified.valid ||
        !verified.stored ||
        typeof verified.acceptedStep !== "number") {
        return c.json({ ok: false, error: "Invalid code" }, 401);
    }
    await writeMfaJson(mfaKey("totp:enabled", session.payload.userId), {
        ...verified.stored,
        lastAcceptedStep: verified.acceptedStep,
    });
    return c.json({ ok: true, verified: true });
});
auth.post("/mfa/totp/complete", async (c) => {
    const rl = await checkAuthRateLimit(c, "mfa-totp-complete", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body?.challengeId || typeof body.challengeId !== "string") {
        return c.json({ ok: false, error: "challengeId is required" }, 400);
    }
    const hasTotpCode = typeof body.code === "string" && body.code.length > 0;
    const hasRecoveryCode = typeof body.recoveryCode === "string" && body.recoveryCode.length > 0;
    if (hasTotpCode === hasRecoveryCode) {
        return c.json({ ok: false, error: "Provide exactly one of code or recoveryCode" }, 400);
    }
    if (hasTotpCode && !/^\d{6}$/.test(body.code ?? "")) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const challengeKey = `auth:challenge:${body.challengeId}`;
    const rawChallenge = await getMfaBackend().get(challengeKey);
    const challenge = rawChallenge
        ? decryptMfaJson(rawChallenge)
        : null;
    if (challenge?.mfaType !== "totp" || Date.now() > challenge.expiresAt) {
        return c.json({ ok: false, error: "Invalid or expired MFA challenge" }, 401);
    }
    const attemptScope = `login:${challenge.userId}:${body.challengeId}`;
    if (!(await claimTotpVerifyAttempt(attemptScope))) {
        await getMfaBackend().delete(challengeKey);
        return c.json({
            ok: false,
            error: "Too many invalid codes. Start a new MFA challenge.",
        }, 429);
    }
    let method = "totp";
    if (hasRecoveryCode) {
        // SEC-146: consume the challenge BEFORE burning the recovery code. The
        // burn is irreversible, so a concurrent completion must lose on the
        // challenge consume — not forfeit a valid recovery code to a 401.
        // Consequence: an invalid recovery code now consumes the challenge too
        // (each guess needs a fresh MFA challenge), which is the fail-closed
        // direction — the per-challenge attempt counter no longer applies here.
        if ((await getMfaBackend().consume(challengeKey)) === null) {
            return c.json({ ok: false, error: "Invalid or expired MFA challenge" }, 401);
        }
        const verified = await verifyRecoveryCode(recoveryCodeStore, challenge.userId, body.recoveryCode ?? "");
        if (!verified.valid) {
            return c.json({ ok: false, error: "Invalid code" }, 401);
        }
        method = "recovery_code";
    }
    else {
        const verified = await verifyStoredTotp(challenge.userId, body.code ?? "");
        if (!verified.valid ||
            !verified.stored ||
            typeof verified.acceptedStep !== "number") {
            const failures = await countTotpVerifyAttempts(attemptScope);
            if (failures >= TOTP_VERIFY_MAX_FAILED_ATTEMPTS)
                await getMfaBackend().delete(challengeKey);
            return c.json({ ok: false, error: "Invalid code" }, 401);
        }
        if ((await getMfaBackend().consume(challengeKey)) === null) {
            return c.json({ ok: false, error: "Invalid or expired MFA challenge" }, 401);
        }
        await writeMfaJson(mfaKey("totp:enabled", challenge.userId), {
            ...verified.stored,
            lastAcceptedStep: verified.acceptedStep,
        });
    }
    await clearTotpVerifyFailures(attemptScope);
    const mfaClaims = {
        mfaVerifiedAt: Date.now(),
        mfaMethod: method,
        factorEnrollmentVerifiedAt: Date.now(),
    };
    if (!(await isActiveTenantMember(challenge.userId, challenge.tenantId))) {
        return c.json({ ok: false, error: "User is not a member of this tenant" }, 403);
    }
    await writeAuthLoginAudit(c, challenge.tenantId, challenge.userId, challenge.claims, {
        mfaMethod: method,
    });
    const token = await createSessionToken(challenge.address, challenge.tenantId, {
        ...(challenge.claims ?? {}),
        userId: challenge.userId,
        ...mfaClaims,
    });
    const refreshToken = await createRefreshToken(challenge.userId, challenge.tenantId, mfaClaims);
    dispatchUserAuthenticated(challenge.tenantId, challenge.userId, typeof challenge.claims?.authMethod === "string"
        ? challenge.claims.authMethod
        : undefined);
    return c.json(buildAuthResponse(token, refreshToken, challenge.user));
});
auth.post("/mfa/totp/step-up", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-totp-step-up", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    const hasTotpCode = typeof body?.code === "string" && body.code.length > 0;
    const hasRecoveryCode = typeof body?.recoveryCode === "string" && body.recoveryCode.length > 0;
    if (hasTotpCode === hasRecoveryCode) {
        return c.json({ ok: false, error: "Provide exactly one of code or recoveryCode" }, 400);
    }
    if (hasTotpCode && !/^\d{6}$/.test(body?.code ?? "")) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const attemptScope = `step-up:${session.payload.userId}`;
    if (!(await claimTotpVerifyAttempt(attemptScope))) {
        return c.json({ ok: false, error: "Too many invalid codes. Please try again later." }, 429);
    }
    let method = "totp";
    if (hasRecoveryCode) {
        const verified = await verifyRecoveryCode(recoveryCodeStore, session.payload.userId, body?.recoveryCode ?? "");
        if (!verified.valid) {
            return c.json({ ok: false, error: "Invalid code" }, 401);
        }
        method = "recovery_code";
    }
    else {
        const verified = await verifyStoredTotp(session.payload.userId, body?.code ?? "");
        if (!verified.valid ||
            !verified.stored ||
            typeof verified.acceptedStep !== "number") {
            return c.json({ ok: false, error: "Invalid code" }, 401);
        }
        await writeMfaJson(mfaKey("totp:enabled", session.payload.userId), {
            ...verified.stored,
            lastAcceptedStep: verified.acceptedStep,
        });
    }
    await clearTotpVerifyFailures(attemptScope);
    return currentSessionMfaStepUpResponse(c, session, method);
});
auth.get("/mfa/recovery-codes/status", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const enabled = await hasTotpEnabled(session.payload.userId);
    const remaining = enabled
        ? await unusedRecoveryCodeCount(recoveryCodeStore, session.payload.userId)
        : 0;
    return c.json({ ok: true, enabled, remaining });
});
auth.post("/mfa/recovery-codes/regenerate", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-recovery-regenerate", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (typeof body?.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const attemptScope = `manage:${session.payload.userId}:recovery-regenerate`;
    if (!(await claimTotpVerifyAttempt(attemptScope))) {
        return c.json({ ok: false, error: "Too many invalid codes. Please try again later." }, 429);
    }
    const verified = await verifyStoredTotp(session.payload.userId, body.code);
    if (!verified.valid ||
        !verified.stored ||
        typeof verified.acceptedStep !== "number") {
        return c.json({ ok: false, error: "Invalid code" }, 401);
    }
    await clearTotpVerifyFailures(attemptScope);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.recovery_codes.regenerate.authorized",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: {},
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    await writeMfaJson(mfaKey("totp:enabled", session.payload.userId), {
        ...verified.stored,
        lastAcceptedStep: verified.acceptedStep,
    });
    const recoveryCodes = await generateRecoveryCodes(recoveryCodeStore, session.payload.userId);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.recovery_codes.regenerate",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: { recoveryCodesIssued: recoveryCodes.length },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    dispatchWebhook(session.payload.tenantId, session.payload.userId, "wallet.recovery_setup", {
        userId: session.payload.userId,
        source: "recovery_code_regenerate",
        recoveryCodesIssued: recoveryCodes.length,
    });
    return c.json({ ok: true, recoveryCodes });
});
// ── SMS MFA ──────────────────────────────────────────────────────────────────
function maskedPhone(phone) {
    return phone.length <= 4 ? "****" : `***${phone.slice(-4)}`;
}
auth.get("/mfa/sms/status", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const enabled = await getSmsMfa(session.payload.userId);
    const pending = await readMfaJson(mfaKey("sms:pending", session.payload.userId));
    return c.json({
        ok: true,
        enabled: Boolean(enabled),
        pending: Boolean(pending),
        phone: enabled
            ? maskedPhone(enabled.phone)
            : pending
                ? maskedPhone(pending.phone)
                : undefined,
    });
});
auth.post("/mfa/sms/enroll", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-sms-enroll", 60_000, 3);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!isValidE164(body?.phone)) {
        return c.json({ ok: false, error: "phone must be E.164" }, 400);
    }
    const existing = await getSmsMfa(session.payload.userId);
    if (existing) {
        return c.json({
            ok: false,
            error: "SMS MFA is already enabled; unenroll it before enrolling a new phone",
        }, 409);
    }
    const stepUpResponse = await requireRecentFactorEnrollmentStepUp(c, session);
    if (stepUpResponse)
        return stepUpResponse;
    let expiresAt;
    try {
        ({ expiresAt } = await getPhoneAuth().sendOtp(body.phone, smsMfaEnrollPurpose(session.payload.userId), "sms"));
    }
    catch (err) {
        if (err instanceof Error && err.message === "SMS provider not configured") {
            return c.json({ ok: false, error: "SMS provider not configured" }, 503);
        }
        throw err;
    }
    await writeMfaJson(mfaKey("sms:pending", session.payload.userId), {
        phone: body.phone,
        purpose: smsMfaEnrollPurpose(session.payload.userId),
        createdAt: new Date().toISOString(),
    }, TOTP_PENDING_TTL_MS);
    return c.json({
        ok: true,
        phone: maskedPhone(body.phone),
        expiresAt: expiresAt.toISOString(),
    });
});
auth.post("/mfa/sms/verify", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-sms-verify", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (typeof body?.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const pending = await readMfaJson(mfaKey("sms:pending", session.payload.userId));
    if (!pending) {
        return c.json({ ok: false, error: "No pending SMS MFA enrollment" }, 404);
    }
    const stepUpResponse = await requireRecentFactorEnrollmentStepUp(c, session);
    if (stepUpResponse)
        return stepUpResponse;
    const pendingPurpose = pending.purpose ?? smsMfaEnrollPurpose(session.payload.userId);
    // Claim-first: atomically consume one attempt slot BEFORE verifying, so
    // concurrent requests cannot both pass a check-then-record boundary.
    const attemptClaim = await claimSmsVerifyAttempt(pending.phone, pendingPurpose);
    if (!attemptClaim) {
        return c.json({
            ok: false,
            error: "Too many invalid SMS verification attempts. Request a new code.",
        }, 429);
    }
    let verified;
    try {
        verified = await getPhoneAuth().verifyOtp(pending.phone, body.code, pendingPurpose);
    }
    catch (error) {
        await releaseUnattemptedSmsVerifyClaim(attemptClaim, error);
        throw error;
    }
    if (!verified.valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    await clearSmsVerifyFailures(pending.phone, pendingPurpose);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.enable.authorized",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: { factor: "sms", phoneHash: hashSha256Hex(pending.phone) },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    await writeMfaJson(mfaKey("sms:enabled", session.payload.userId), {
        phone: pending.phone,
        enabledAt: new Date().toISOString(),
    });
    await getMfaBackend().delete(mfaKey("sms:pending", session.payload.userId));
    const { issuedBefore } = await revokeUserRefreshSessions(session.payload.userId);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.enabled",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: {
            factor: "sms",
            phoneHash: hashSha256Hex(pending.phone),
            revokedRefreshTokens: true,
            revokedAccessTokensIssuedBefore: issuedBefore,
        },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    dispatchWebhook(session.payload.tenantId, session.payload.userId, "mfa.enabled", {
        userId: session.payload.userId,
        factor: "sms",
        phoneHash: hashSha256Hex(pending.phone),
    });
    return c.json({ ok: true, enabled: true, phone: maskedPhone(pending.phone) });
});
auth.post("/mfa/sms/send", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-sms-send", 60_000, 3);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const smsMfa = await getSmsMfa(session.payload.userId);
    if (!smsMfa) {
        return c.json({ ok: false, error: "SMS MFA is not enabled" }, 404);
    }
    let expiresAt;
    try {
        ({ expiresAt } = await getPhoneAuth().sendOtp(smsMfa.phone, smsMfaManagePurpose(session.payload.userId), "sms"));
    }
    catch (err) {
        if (err instanceof Error && err.message === "SMS provider not configured") {
            return c.json({ ok: false, error: "SMS provider not configured" }, 503);
        }
        throw err;
    }
    return c.json({
        ok: true,
        phone: maskedPhone(smsMfa.phone),
        expiresAt: expiresAt.toISOString(),
    });
});
auth.post("/mfa/sms/complete", async (c) => {
    const rl = await checkAuthRateLimit(c, "mfa-sms-complete", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body?.challengeId || typeof body.challengeId !== "string") {
        return c.json({ ok: false, error: "challengeId is required" }, 400);
    }
    if (typeof body.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const challengeKey = `auth:challenge:${body.challengeId}`;
    const rawChallenge = await getMfaBackend().get(challengeKey);
    const challenge = rawChallenge
        ? decryptMfaJson(rawChallenge)
        : null;
    if (challenge?.mfaType !== "sms" || Date.now() > challenge.expiresAt) {
        return c.json({ ok: false, error: "Invalid or expired MFA challenge" }, 401);
    }
    const smsMfa = await getSmsMfa(challenge.userId);
    if (!smsMfa) {
        return c.json({ ok: false, error: "SMS MFA is not enabled" }, 401);
    }
    const otpPurpose = smsMfaChallengePurpose(body.challengeId);
    // Claim-first: atomically consume one attempt slot BEFORE verifying, so
    // concurrent requests cannot both pass a check-then-record boundary.
    const attemptClaim = await claimSmsVerifyAttempt(smsMfa.phone, otpPurpose);
    if (!attemptClaim) {
        return c.json({
            ok: false,
            error: "Too many invalid codes. Request a new code and try again later.",
        }, 429);
    }
    let verified;
    try {
        verified = await getPhoneAuth().verifyOtp(smsMfa.phone, body.code, otpPurpose);
    }
    catch (error) {
        await releaseUnattemptedSmsVerifyClaim(attemptClaim, error);
        throw error;
    }
    if (!verified.valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    if ((await getMfaBackend().consume(challengeKey)) === null) {
        return c.json({ ok: false, error: "Invalid or expired MFA challenge" }, 401);
    }
    await clearSmsVerifyFailures(smsMfa.phone, otpPurpose);
    const mfaClaims = {
        mfaVerifiedAt: Date.now(),
        mfaMethod: "sms",
        factorEnrollmentVerifiedAt: Date.now(),
    };
    if (!(await isActiveTenantMember(challenge.userId, challenge.tenantId))) {
        return c.json({ ok: false, error: "User is not a member of this tenant" }, 403);
    }
    await writeAuthLoginAudit(c, challenge.tenantId, challenge.userId, challenge.claims, {
        mfaMethod: "sms",
    });
    const token = await createSessionToken(challenge.address, challenge.tenantId, {
        ...(challenge.claims ?? {}),
        userId: challenge.userId,
        ...mfaClaims,
    });
    const refreshToken = await createRefreshToken(challenge.userId, challenge.tenantId, mfaClaims);
    dispatchUserAuthenticated(challenge.tenantId, challenge.userId, typeof challenge.claims?.authMethod === "string"
        ? challenge.claims.authMethod
        : undefined);
    return c.json(buildAuthResponse(token, refreshToken, challenge.user));
});
auth.post("/mfa/sms/step-up", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-sms-step-up", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (typeof body?.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const smsMfa = await getSmsMfa(session.payload.userId);
    if (!smsMfa) {
        return c.json({ ok: false, error: "SMS MFA is not enabled" }, 404);
    }
    const otpPurpose = smsMfaManagePurpose(session.payload.userId);
    // Claim-first: atomically consume one attempt slot BEFORE verifying, so
    // concurrent requests cannot both pass a check-then-record boundary.
    const attemptClaim = await claimSmsVerifyAttempt(smsMfa.phone, otpPurpose);
    if (!attemptClaim) {
        return c.json({
            ok: false,
            error: "Too many invalid SMS verification attempts. Request a new code.",
        }, 429);
    }
    let verified;
    try {
        verified = await getPhoneAuth().verifyOtp(smsMfa.phone, body.code, otpPurpose);
    }
    catch (error) {
        await releaseUnattemptedSmsVerifyClaim(attemptClaim, error);
        throw error;
    }
    if (!verified.valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    await clearSmsVerifyFailures(smsMfa.phone, otpPurpose);
    return currentSessionMfaStepUpResponse(c, session, "sms");
});
auth.post("/mfa/passkey/options", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    if (!session.payload.userId) {
        return c.json({ ok: false, error: "User session is required" }, 403);
    }
    const rl = await checkAuthRateLimit(c, "mfa-passkey-options", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, session.payload.tenantId, "passkey");
    if (methodResponse)
        return methodResponse;
    const passkeyAuth = getPasskeyAuth(c.req.header("origin"));
    const passkeys = await getDb()
        .select({
        credentialId: authenticators.credentialId,
        rpId: authenticators.rpId,
        transports: authenticators.transports,
    })
        .from(authenticators)
        .where(eq(authenticators.userId, session.payload.userId));
    // Explicitly cross-RP credentials cannot satisfy this RP's WebAuthn
    // challenge. Legacy NULL provenance stays eligible so the browser can
    // adjudicate it, and a successful assertion will safely backfill the RP.
    const eligiblePasskeys = passkeys.filter((credential) => credential.rpId === null || credential.rpId === passkeyAuth.rpID);
    if (eligiblePasskeys.length === 0) {
        return c.json({ ok: false, error: "No passkey is registered for this user" }, 404);
    }
    const options = await passkeyAuth.generateAuthenticationOptions(`mfa:${session.payload.userId}`, {
        allowCredentials: eligiblePasskeys.map((credential) => ({
            id: credential.credentialId,
            transports: (credential.transports ?? []),
        })),
    });
    const challengeId = options.challenge;
    await getChallengeStore().set(passkeyMfaChallengeKey(session.payload.userId, challengeId), options.challenge);
    return c.json({ ...options, challengeId });
});
const completePasskeyMfaHandler = async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    if (!session.payload.userId) {
        return c.json({ ok: false, error: "User session is required" }, 403);
    }
    const rl = await checkAuthRateLimit(c, "mfa-passkey-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body?.challengeId || typeof body.challengeId !== "string") {
        return c.json({ ok: false, error: "challengeId is required" }, 400);
    }
    if (!body.response?.id || typeof body.response.id !== "string") {
        return c.json({ ok: false, error: "response.id is required" }, 400);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, session.payload.tenantId, "passkey");
    if (methodResponse)
        return methodResponse;
    const [cred] = await getDb()
        .select()
        .from(authenticators)
        .where(and(eq(authenticators.userId, session.payload.userId), eq(authenticators.credentialId, body.response.id)));
    if (!cred) {
        return c.json({ ok: false, error: "Passkey MFA verification failed" }, 401);
    }
    const passkeyAuth = getPasskeyAuth(c.req.header("origin"));
    if (cred.rpId !== null && cred.rpId !== passkeyAuth.rpID) {
        return c.json({ ok: false, error: "Passkey MFA verification failed" }, 401);
    }
    let verification;
    try {
        const challengeKey = passkeyMfaChallengeKey(session.payload.userId, body.challengeId);
        const expectedChallenge = await getChallengeStore().get(challengeKey);
        if (!expectedChallenge) {
            return c.json({ ok: false, error: "Invalid or expired passkey challenge" }, 401);
        }
        verification = await passkeyAuth.verifyAuthentication(body.response, expectedChallenge, cred.credentialPublicKey, cred.counter);
        if ((await getChallengeStore().consume(challengeKey)) === null) {
            return c.json({ ok: false, error: "Invalid or expired passkey challenge" }, 401);
        }
    }
    catch {
        return c.json({ ok: false, error: "Passkey MFA verification failed" }, 400);
    }
    if (!verification.verified) {
        return c.json({ ok: false, error: "Passkey MFA verification failed" }, 401);
    }
    if (!(await isActiveTenantMember(session.payload.userId, session.payload.tenantId))) {
        return c.json({ ok: false, error: "User is not a member of this tenant" }, 403);
    }
    // SEC-141: reject counter regression. Once an authenticator has reported a
    // non-zero counter, a response whose counter does not exceed the stored
    // value indicates a cloned/exported credential. Authenticators that never
    // increment (always 0) keep a stored counter of 0 and are unaffected.
    if (cred.counter > 0 &&
        verification.authenticationInfo.newCounter <= cred.counter) {
        logger.warn({
            details: [
                `[PasskeyAuth] MFA counter regression for credential ${cred.id}: stored ${cred.counter}, got ${verification.authenticationInfo.newCounter}`,
            ],
        }, "[Login:auth] warn");
        return c.json({ ok: false, error: "Passkey MFA verification failed" }, 401);
    }
    const updatedMfaCounters = await getDb()
        .update(authenticators)
        .set({
        counter: verification.authenticationInfo.newCounter,
        // A verified assertion proves a legacy credential's RP provenance.
        ...(cred.rpId === null ? { rpId: passkeyAuth.rpID } : {}),
    })
        .where(and(eq(authenticators.id, cred.id), eq(authenticators.counter, cred.counter)))
        .returning({ id: authenticators.id });
    if (updatedMfaCounters.length !== 1) {
        logger.warn({
            details: [
                `[PasskeyAuth] Concurrent MFA counter update rejected for credential ${cred.id}`,
            ],
        }, "[Login:auth] warn");
        return c.json({ ok: false, error: "Passkey MFA verification failed" }, 401);
    }
    const [user] = await getDb()
        .select({
        id: users.id,
        email: users.email,
        walletAddress: users.walletAddress,
        walletChain: users.walletChain,
    })
        .from(users)
        .where(eq(users.id, session.payload.userId));
    const mfaClaims = {
        mfaVerifiedAt: Date.now(),
        mfaMethod: "passkey",
        factorEnrollmentVerifiedAt: Date.now(),
    };
    const token = await createSessionToken(session.payload.address, session.payload.tenantId, {
        userId: session.payload.userId,
        email: session.payload.email,
        authMethod: session.payload.authMethod,
        ...mfaClaims,
    });
    const refreshToken = await createRefreshToken(session.payload.userId, session.payload.tenantId, mfaClaims);
    return c.json(buildAuthResponse(token, refreshToken, {
        id: user?.id ?? session.payload.userId,
        email: user?.email ?? session.payload.email ?? "",
        walletAddress: user?.walletAddress ?? session.payload.address,
        walletChain: user?.walletChain ?? undefined,
    }));
};
auth.post("/mfa/passkey/complete", completePasskeyMfaHandler);
auth.post("/mfa/passkey/verify", completePasskeyMfaHandler);
auth.post("/mfa/sms/unenroll", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-sms-unenroll", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (typeof body?.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const smsMfa = await getSmsMfa(session.payload.userId);
    if (!smsMfa) {
        return c.json({ ok: false, error: "SMS MFA is not enabled" }, 404);
    }
    const otpPurpose = smsMfaManagePurpose(session.payload.userId);
    // Claim-first: atomically consume one attempt slot BEFORE verifying, so
    // concurrent requests cannot both pass a check-then-record boundary.
    const attemptClaim = await claimSmsVerifyAttempt(smsMfa.phone, otpPurpose);
    if (!attemptClaim) {
        return c.json({
            ok: false,
            error: "Too many invalid codes. Request a new code and try again later.",
        }, 429);
    }
    let verified;
    try {
        verified = await getPhoneAuth().verifyOtp(smsMfa.phone, body.code, otpPurpose);
    }
    catch (error) {
        await releaseUnattemptedSmsVerifyClaim(attemptClaim, error);
        throw error;
    }
    if (!verified.valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    await clearSmsVerifyFailures(smsMfa.phone, otpPurpose);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.disable.authorized",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: { factor: "sms", phoneHash: hashSha256Hex(smsMfa.phone) },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    await getMfaBackend().delete(mfaKey("sms:enabled", session.payload.userId));
    const { issuedBefore } = await revokeUserRefreshSessions(session.payload.userId);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.disabled",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: {
            factor: "sms",
            phoneHash: hashSha256Hex(smsMfa.phone),
            revokedRefreshTokens: true,
            revokedAccessTokensIssuedBefore: issuedBefore,
        },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    dispatchWebhook(session.payload.tenantId, session.payload.userId, "mfa.disabled", {
        userId: session.payload.userId,
        factor: "sms",
        phoneHash: hashSha256Hex(smsMfa.phone),
    });
    return c.json({ ok: true });
});
auth.post("/mfa/totp/unenroll", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const rl = await checkAuthRateLimit(c, "mfa-totp-unenroll", 60_000, 5);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (typeof body?.code !== "string" || !/^\d{6}$/.test(body.code)) {
        return c.json({ ok: false, error: "code must be 6 digits" }, 400);
    }
    const attemptScope = `manage:${session.payload.userId}:totp-unenroll`;
    if (!(await claimTotpVerifyAttempt(attemptScope))) {
        return c.json({ ok: false, error: "Too many invalid codes. Please try again later." }, 429);
    }
    const verified = await verifyStoredTotp(session.payload.userId, body.code);
    if (!verified.valid) {
        return c.json({ ok: false, error: "Invalid code" }, 401);
    }
    await clearTotpVerifyFailures(attemptScope);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.disable.authorized",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: { factor: "totp" },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    await getMfaBackend().delete(mfaKey("totp:enabled", session.payload.userId));
    await getMfaBackend().delete(mfaKey("recovery", session.payload.userId));
    const { issuedBefore } = await revokeUserRefreshSessions(session.payload.userId);
    await writeAuditEvent({
        tenantId: session.payload.tenantId,
        actorType: "user",
        actorId: session.payload.userId,
        action: "mfa.disabled",
        resourceType: "user",
        resourceId: session.payload.userId,
        metadata: {
            factor: "totp",
            revokedRefreshTokens: true,
            revokedAccessTokensIssuedBefore: issuedBefore,
        },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    dispatchWebhook(session.payload.tenantId, session.payload.userId, "mfa.disabled", {
        userId: session.payload.userId,
        factor: "totp",
    });
    return c.json({ ok: true });
});
/**
 * POST /logout
 * Revokes the presented access token's JTI until its natural expiry. If a
 * refresh token is supplied, it is revoked too so logout cannot be bypassed by
 * silently rotating the same session back in.
 */
auth.post("/logout", async (c) => {
    const body = await safeJsonParse(c);
    const authHeader = c.req.header("Authorization");
    let auditCtx = {};
    if (authHeader?.startsWith("Bearer ")) {
        let payload;
        try {
            payload = await verifyToken(authHeader.slice(7));
        }
        catch (error) {
            // error-policy:J3 invalid or expired credentials are already unusable; storage failures still propagate.
            if (!(error instanceof joseErrors.JWTExpired ||
                error instanceof joseErrors.JWTInvalid ||
                error instanceof joseErrors.JWTClaimValidationFailed ||
                error instanceof joseErrors.JWSInvalid ||
                error instanceof joseErrors.JWSSignatureVerificationFailed))
                throw error;
        }
        if (payload &&
            typeof payload.jti === "string" &&
            typeof payload.exp === "number") {
            if (payload.tenantId) {
                await writeAuditEvent({
                    tenantId: payload.tenantId,
                    actorType: "user",
                    actorId: payload.userId ?? null,
                    action: "auth.logout.authorized",
                    resourceType: "session",
                    resourceId: payload.jti,
                    ipAddress: c.req.header("x-forwarded-for") ?? null,
                    userAgent: c.req.header("user-agent") ?? null,
                    requestId: c.get("requestId") ?? null,
                });
            }
            await revocationStore.revokeToken(payload.jti, payload.exp);
            auditCtx = {
                tenantId: payload.tenantId,
                userId: payload.userId,
                jti: payload.jti,
            };
        }
    }
    if (body?.refreshToken) {
        const tokenHash = hashToken(body.refreshToken);
        const subject = await resolveRefreshTokenSubject(tokenHash);
        const [revokedRefresh] = subject
            ? await withVerifiedAuthTenant(subject.tenantId, subject.userId, () => getDb()
                .delete(refreshTokens)
                .where(eq(refreshTokens.tokenHash, tokenHash))
                .returning())
            : [];
        if (!auditCtx.tenantId && revokedRefresh) {
            auditCtx = {
                tenantId: revokedRefresh.tenantId,
                userId: revokedRefresh.userId,
                jti: auditCtx.jti,
            };
        }
    }
    if (auditCtx.tenantId) {
        await writeAuditEvent({
            tenantId: auditCtx.tenantId,
            actorType: "user",
            actorId: auditCtx.userId ?? null,
            action: "auth.logout",
            resourceType: "session",
            resourceId: auditCtx.jti ?? null,
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        });
    }
    return c.json({ ok: true });
});
/**
 * POST /refresh
 * Body: { refreshToken: string }
 * Validates the refresh token, rotates it (one-time use), issues new access + refresh tokens.
 * Supports silent re-auth without user interaction when the access token nears expiry.
 */
auth.post("/refresh", async (c) => {
    const rl = await checkAuthRateLimit(c, "refresh", 60_000, 60);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.refreshToken) {
        return c.json({ ok: false, error: "refreshToken is required" }, 400);
    }
    if (body.tenantId !== undefined && !isValidTenantId(body.tenantId)) {
        return c.json({ ok: false, error: "Invalid tenant id format" }, 400);
    }
    const rotatedRefresh = await rotateRefreshTokenForUserSession(body.refreshToken, body.tenantId);
    if (rotatedRefresh.status === "reused") {
        await withVerifiedAuthTenant(rotatedRefresh.tenantId, rotatedRefresh.userId, async () => {
            const { issuedBefore: revokedBefore } = await revokeUserRefreshSessions(rotatedRefresh.userId);
            await writeAuditEvent({
                tenantId: rotatedRefresh.tenantId,
                actorType: "user",
                actorId: rotatedRefresh.userId,
                action: "auth.refresh.reuse_detected",
                resourceType: "session",
                metadata: {
                    revokedRefreshTokens: true,
                    revokedAccessTokensIssuedBefore: revokedBefore,
                },
                ipAddress: c.req.header("x-forwarded-for") ?? null,
                userAgent: c.req.header("user-agent") ?? null,
                requestId: c.get("requestId") ?? null,
            });
        });
        return c.json({
            ok: false,
            error: "Refresh token reuse detected. Please sign in again.",
        }, 401);
    }
    if (rotatedRefresh.status === "invalid") {
        return c.json({ ok: false, error: "Invalid or expired refresh token" }, 401);
    }
    if (rotatedRefresh.status === "deactivated") {
        return c.json({ ok: false, error: "User is deactivated" }, 403);
    }
    if (rotatedRefresh.status === "not_member") {
        return c.json({ ok: false, error: "Not a member of this tenant" }, 403);
    }
    if (rotatedRefresh.status === "revoked") {
        return c.json({ ok: false, error: "Session was revoked. Please sign in again." }, 401);
    }
    if (rotatedRefresh.status === "login_method_disabled") {
        return c.json({ ok: false, error: rotatedRefresh.error }, 403);
    }
    const { record, newAccessToken, newRefreshToken } = rotatedRefresh;
    await withVerifiedAuthTenant(record.tenantId, record.userId, async () => {
        const db = getDb();
        try {
            await writeAuditEvent({
                tenantId: record.tenantId,
                actorType: "user",
                actorId: record.userId,
                action: "auth.refresh",
                resourceType: "session",
                metadata: { rotated: true },
                ipAddress: c.req.header("x-forwarded-for") ?? null,
                userAgent: c.req.header("user-agent") ?? null,
                requestId: c.get("requestId") ?? null,
            });
        }
        catch (err) {
            await db
                .delete(refreshTokens)
                .where(eq(refreshTokens.tokenHash, hashToken(newRefreshToken)));
            throw err;
        }
    });
    dispatchUserAuthenticated(record.tenantId, record.userId, "refresh");
    return c.json({
        ok: true,
        token: newAccessToken,
        refreshToken: newRefreshToken,
        expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
    });
});
/**
 * POST /revoke
 * Body: { refreshToken: string }
 * Revokes a specific refresh token (sign out from this session/device).
 */
auth.post("/revoke", async (c) => {
    const body = await safeJsonParse(c);
    if (!body?.refreshToken) {
        return c.json({ ok: false, error: "refreshToken is required" }, 400);
    }
    const tokenHash = hashToken(body.refreshToken);
    const subject = await resolveRefreshTokenSubject(tokenHash);
    if (!subject)
        return c.json({ ok: true });
    const revoked = await withVerifiedAuthTenant(subject.tenantId, subject.userId, () => getDb().transaction(async (tx) => {
        const [candidate] = await tx
            .select()
            .from(refreshTokens)
            .where(eq(refreshTokens.tokenHash, tokenHash));
        const usedBeforeLock = candidate
            ? null
            : await readMfaJson(`refresh:used:${tokenHash}`);
        const userId = candidate?.userId ?? usedBeforeLock?.userId;
        if (userId)
            await lockUserSession(tx, userId);
        await tx.execute(sql `select pg_advisory_xact_lock(hashtextextended(${`refresh_token_${tokenHash}`}, 0))`);
        // Re-read after both locks: rotation may have replaced the candidate while
        // this revoke waited for the user-wide session lock.
        const used = await readMfaJson(`refresh:used:${tokenHash}`);
        const hashes = [tokenHash];
        if (used?.successorTokenHash)
            hashes.push(used.successorTokenHash);
        return tx
            .delete(refreshTokens)
            .where(inArray(refreshTokens.tokenHash, hashes))
            .returning();
    }));
    const existing = revoked[0];
    if (existing) {
        await writeAuditEvent({
            tenantId: existing.tenantId,
            actorType: "user",
            actorId: existing.userId,
            action: "auth.refresh_token.revoke.authorized",
            resourceType: "session",
            metadata: { tokenId: existing.id },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        });
    }
    for (const revokedToken of revoked) {
        await writeAuditEvent({
            tenantId: revokedToken.tenantId,
            actorType: "user",
            actorId: revokedToken.userId,
            action: "auth.refresh_token.revoke",
            resourceType: "session",
            metadata: { tokenId: revokedToken.id },
            ipAddress: c.req.header("x-forwarded-for") ?? null,
            userAgent: c.req.header("user-agent") ?? null,
            requestId: c.get("requestId") ?? null,
        });
    }
    return c.json({ ok: true });
});
/**
 * DELETE /sessions
 * Requires: Authorization: Bearer <access-token>
 * Revokes ALL refresh tokens for the authenticated user (sign out everywhere / all devices).
 */
auth.delete("/sessions", async (c) => {
    const authHeader = c.req.header("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
        return c.json({ ok: false, error: "Authorization header required" }, 401);
    }
    const payload = await verifySessionToken(authHeader.slice(7));
    if (!payload) {
        return c.json({ ok: false, error: "Invalid or expired token" }, 401);
    }
    if (!payload.userId) {
        return c.json({ ok: false, error: "Token does not contain userId" }, 400);
    }
    await writeAuditEvent({
        tenantId: payload.tenantId,
        actorType: "user",
        actorId: payload.userId,
        action: "auth.sessions.revoke_all.authorized",
        resourceType: "session",
        resourceId: payload.jti ?? null,
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    const { revoked, issuedBefore } = await revokeUserRefreshSessions(payload.userId);
    if (payload.jti && payload.exp) {
        await revocationStore.revokeToken(payload.jti, payload.exp);
    }
    await writeAuditEvent({
        tenantId: payload.tenantId,
        actorType: "user",
        actorId: payload.userId,
        action: "auth.sessions.revoke_all",
        resourceType: "session",
        metadata: {
            revokedRefreshTokenCount: revoked.length,
            revokedUserTokensIssuedBefore: issuedBefore,
        },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    return c.json({ ok: true });
});
// ── Passkey registration ───────────────────────────────────────────────────────
/**
 * POST /passkey/register/options
 * Body: { email, emailGrant? }
 * Verified-email enrollment returns 409 when the account already has a
 * passkey for this RP, while authenticated sessions can add devices.
 */
auth.post("/passkey/register/options", async (c) => {
    // Pre-auth reachable via the email-grant path — rate limit like the other
    // pre-auth passkey endpoints.
    const optionsRl = await checkAuthRateLimit(c, "passkey-register-options", 60_000, 20);
    if (!optionsRl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email) {
        return c.json({ ok: false, error: "email is required" }, 400);
    }
    const email = body.email.toLowerCase().trim();
    const db = getDb();
    const emailGrant = typeof body.emailGrant === "string" && body.emailGrant.length > 0
        ? body.emailGrant
        : null;
    const usingEmailGrant = emailGrant !== null;
    // Two ways in: an authenticated session (add-passkey for logged-in users)
    // or a verified-email grant from /email/otp/verify (Privy-style signup:
    // email → 6-digit code → Touch ID, no session required). The grant proves
    // ownership of the email, which is what blocks account pre-hijack.
    let userId;
    let userEmail;
    let ssoTenantId;
    if (emailGrant !== null) {
        const resolvedTenantId = c.req.header("X-Steward-Tenant")?.trim() ||
            body.tenantId?.trim() ||
            defaultAuthTenantId();
        const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "passkey");
        if (methodResponse)
            return methodResponse;
        // Peek (not consume): the grant is only burned at register/verify so a
        // cancelled Touch ID prompt doesn't cost the user their verification.
        const grantScope = await peekEmailGrant(emailGrant, email, resolvedTenantId);
        const personalRequest = !(c.req.header("X-Steward-Tenant")?.trim() || body.tenantId?.trim());
        if (!grantScope || (grantScope === "personal") !== personalRequest) {
            return c.json({ ok: false, error: "Invalid or expired email grant" }, 401);
        }
        const { user } = await findOrCreateUserWithStatus(email);
        userId = user.id;
        userEmail = user.email;
        ssoTenantId = resolvedTenantId;
    }
    else {
        const session = await requireSession(c);
        if (!session.ok)
            return session.response;
        const sessionMethodResponse = await requireTenantLoginMethodAllowed(c, session.payload.tenantId, "passkey");
        if (sessionMethodResponse)
            return sessionMethodResponse;
        const [user] = await db
            .select()
            .from(users)
            .where(eq(users.id, session.payload.userId));
        if (!user || user.email?.toLowerCase().trim() !== email) {
            return c.json({
                ok: false,
                error: "Passkey registration requires an authenticated matching email session",
            }, 403);
        }
        if (!user.emailVerified) {
            return c.json({
                ok: false,
                error: "Email must be verified before registering a passkey",
            }, 403);
        }
        const stepUpResponse = await requireRecentFactorEnrollmentStepUp(c, session);
        if (stepUpResponse)
            return stepUpResponse;
        userId = user.id;
        userEmail = user.email;
        ssoTenantId = session.payload.tenantId;
    }
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, ssoTenantId, email, "Passkey");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const passkeyAuth = getPasskeyAuth(c.req.header("origin"));
    const existingCreds = await db
        .select({
        credentialId: authenticators.credentialId,
        rpId: authenticators.rpId,
    })
        .from(authenticators)
        .where(eq(authenticators.userId, userId));
    // The verified-email path exists to establish the account's first passkey.
    // Only provenance that explicitly matches the current RP can trigger the
    // recovery signal. A cross-RP credential must not block registration here,
    // and a legacy NULL row is ambiguous: keep it in excludeCredentials so the
    // browser can safely adjudicate whether it belongs to this RP.
    if (usingEmailGrant &&
        existingCreds.some((cred) => cred.rpId === passkeyAuth.rpID)) {
        return c.json({
            ok: false,
            error: "A passkey already exists for this email. Sign in with it instead.",
            code: "passkey_already_registered",
        }, 409);
    }
    const sameOrLegacyCreds = existingCreds.filter((cred) => cred.rpId === null || cred.rpId === passkeyAuth.rpID);
    const attachment = body.authenticatorAttachment === "platform" ||
        body.authenticatorAttachment === "cross-platform"
        ? body.authenticatorAttachment
        : undefined;
    const options = await passkeyAuth.generateRegistrationOptions(userId, userEmail ?? email, sameOrLegacyCreds.map((cred) => cred.credentialId), attachment ? { authenticatorAttachment: attachment } : undefined);
    return c.json(options);
});
/**
 * POST /passkey/register/verify
 * Body: { email, response, tenantId? }
 * Headers: X-Steward-Tenant (optional)
 * Verifies registration, stores credential, provisions wallet, returns JWT.
 */
auth.post("/passkey/register/verify", async (c) => {
    // Distinct endpoint key from login's "passkey-verify" so registration and
    // login verification do not share one bucket.
    const rl = await checkAuthRateLimit(c, "passkey-register-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email || !body?.response) {
        return c.json({ ok: false, error: "email and response are required" }, 400);
    }
    const db = getDb();
    const email = body.email.toLowerCase().trim();
    // Session path (logged-in add-passkey) or verified-email-grant path
    // (Privy-style signup). The grant is CONSUMED here — single use — and
    // proves email ownership, so completing registration also marks the
    // email verified.
    let user;
    const usingGrant = typeof body.emailGrant === "string" && body.emailGrant.length > 0;
    let grantTenantId = null;
    let grantScope = null;
    if (usingGrant) {
        // PEEK only here. The grant is consumed AFTER the WebAuthn ceremony
        // succeeds (below) so a failed/cancelled ceremony doesn't burn the
        // user's OTP verification, while consumption before any state change
        // keeps it strictly single-use.
        grantTenantId =
            c.req.header("X-Steward-Tenant")?.trim() ||
                body.tenantId?.trim() ||
                defaultAuthTenantId();
        grantScope = await peekEmailGrant(body.emailGrant, email, grantTenantId);
        const personalRequest = !(c.req.header("X-Steward-Tenant")?.trim() || body.tenantId?.trim());
        if (!grantScope || (grantScope === "personal") !== personalRequest) {
            return c.json({ ok: false, error: "Invalid or expired email grant" }, 401);
        }
        const found = await findOrCreateUserWithStatus(email);
        user = found.user;
    }
    else {
        const session = await requireSession(c);
        if (!session.ok)
            return session.response;
        const [sessionUser] = await db
            .select()
            .from(users)
            .where(eq(users.id, session.payload.userId));
        if (!sessionUser ||
            sessionUser.email?.toLowerCase().trim() !== email ||
            !sessionUser.emailVerified) {
            return c.json({
                ok: false,
                error: "Passkey registration requires an authenticated verified email session",
            }, 403);
        }
        const stepUpResponse = await requireRecentFactorEnrollmentStepUp(c, session);
        if (stepUpResponse)
            return stepUpResponse;
        user = sessionUser;
    }
    // Tenant resolution uses the SAME join_mode-gated path as oauth and
    // magic-link signup (resolveAndValidateTenant). The email grant proves
    // address ownership — it must NOT also become a side door around
    // invite-only tenants. Open-signup tenants set join_mode=open in config.
    const tenantResult = await resolveAndValidateTenant(c, user.id, body.tenantId);
    if (!tenantResult.ok) {
        return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
    }
    const tenantId = tenantResult.tenantId;
    if (usingGrant &&
        tenantId !== grantTenantId &&
        !(grantScope === "personal" &&
            tenantResult.isPersonal &&
            tenantId === `personal-${user.id}`)) {
        // Explicit tenant grants cannot become personal or cross-tenant authority.
        // Tenant-less grants can resolve only to this verified user's personal tenant.
        return c.json({ ok: false, error: "Invalid or expired email grant" }, 401);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "passkey");
    if (methodResponse)
        return methodResponse;
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, tenantId, email, "Passkey");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const passkeyAuth = getPasskeyAuth(c.req.header("origin"));
    let verification;
    try {
        verification = await passkeyAuth.verifyRegistration(user.id, body.response);
    }
    catch (err) {
        logger.warn({
            details: [
                "[PasskeyAuth] Registration failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] warn");
        return c.json({
            ok: false,
            error: "Registration verification failed",
        }, 400);
    }
    if (!verification.verified || !verification.registrationInfo) {
        return c.json({ ok: false, error: "Registration verification failed" }, 400);
    }
    if (usingGrant && grantTenantId) {
        // Ceremony succeeded — NOW consume the grant (atomic single-use gate
        // before any state is written). A replayed request with the same grant
        // fails here even if it carries a valid ceremony response.
        const consumed = await consumeEmailGrant(body.emailGrant, email, grantTenantId);
        if (!consumed) {
            return c.json({ ok: false, error: "Invalid or expired email grant" }, 401);
        }
        // The OTP proved address ownership.
        await db
            .update(users)
            .set({ emailVerified: true })
            .where(eq(users.id, user.id));
        user = { ...user, emailVerified: true };
    }
    const { credential, credentialDeviceType, credentialBackedUp } = verification.registrationInfo;
    await db
        .insert(authenticators)
        .values({
        userId: user.id,
        credentialId: credential.id,
        credentialPublicKey: uint8ArrayToBase64url(credential.publicKey),
        rpId: passkeyAuth.rpID,
        counter: credential.counter,
        credentialDeviceType,
        credentialBackedUp,
        transports: body.response.response
            ?.transports ?? [],
    })
        .onConflictDoNothing();
    // Provision the user's personal wallet (idempotent)
    let walletAddress = user.walletAddress;
    try {
        const w = await provisionWalletForUser(user.id, email);
        walletAddress = w.walletAddress;
    }
    catch (err) {
        logger.error({
            details: [
                "[PasskeyAuth] Wallet provision failed on register",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
    }
    // Link the user only after tenant authorization has been validated.
    await ensureUserTenantLink(user.id, tenantId);
    return authExchangeJson(c, await buildAuthOrMfaResponse(user.id, tenantId, walletAddress ?? "", {
        userId: user.id,
        email,
        authMethod: "passkey",
    }, {
        id: user.id,
        email,
        walletAddress,
    }, c));
});
// ── Passkey authentication ────────────────────────────────────────────────────
/**
 * POST /passkey/login/options
 * Body: { email }
 * Returns privacy-preserving discoverable-credential options. `allowCredentials`
 * is intentionally empty for every email so this pre-auth route cannot reveal
 * whether an account or passkey exists.
 */
auth.post("/passkey/login/options", async (c) => {
    const rl = await checkAuthRateLimit(c, "passkey-options", 60_000, 20);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body?.email) {
        return c.json({ ok: false, error: "email is required" }, 400);
    }
    const optionTenantId = authTenantHint(c, body.tenantId);
    const tenantHintError = await validateExplicitAuthTenantHint(optionTenantId, Boolean(c.req.header("X-Steward-Tenant") || body.tenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, optionTenantId, "passkey");
    if (methodResponse)
        return methodResponse;
    const email = body.email.toLowerCase().trim();
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, optionTenantId, email, "Passkey");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const options = await getPasskeyAuth(c.req.header("origin")).generateAuthenticationOptions(email);
    const challengeId = options.challenge;
    await getChallengeStore().set(`passkey-login:${email}:${challengeId}`, options.challenge);
    return c.json({ ...options, allowCredentials: [], challengeId });
});
/**
 * POST /passkey/login/verify
 * Body: { email, response, tenantId? }
 * Headers: X-Steward-Tenant (optional)
 * Verifies authentication, updates counter, links user to tenant, returns JWT.
 */
auth.post("/passkey/login/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "passkey-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email || !body?.response) {
        return c.json({ ok: false, error: "email and response are required" }, 400);
    }
    if (!body.challengeId || typeof body.challengeId !== "string") {
        return c.json({ ok: false, error: "challengeId is required" }, 400);
    }
    const email = body.email.toLowerCase().trim();
    const db = getDb();
    const [user] = await db.select().from(users).where(eq(users.email, email));
    if (!user) {
        return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
    }
    // Resolve tenant policy before consuming the one-time WebAuthn challenge.
    const tenantResult = await resolveAndValidateTenant(c, user.id, body.tenantId);
    if (!tenantResult.ok) {
        return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
    }
    const { tenantId } = tenantResult;
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "passkey");
    if (methodResponse)
        return methodResponse;
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, tenantId, email, "Passkey");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const [cred] = await db
        .select()
        .from(authenticators)
        .where(and(eq(authenticators.userId, user.id), eq(authenticators.credentialId, body.response.id)));
    if (!cred) {
        return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
    }
    const passkeyAuth = getPasskeyAuth(c.req.header("origin"));
    if (cred.rpId !== null && cred.rpId !== passkeyAuth.rpID) {
        return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
    }
    let verification;
    try {
        const expectedChallenge = await getChallengeStore().consume(`passkey-login:${email}:${body.challengeId}`);
        if (!expectedChallenge) {
            return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
        }
        verification = await passkeyAuth.verifyAuthentication(body.response, expectedChallenge, cred.credentialPublicKey, cred.counter);
    }
    catch (err) {
        logger.warn({
            details: [
                "[PasskeyAuth] Authentication failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] warn");
        return c.json({
            ok: false,
            error: "Passkey authentication failed",
        }, 400);
    }
    if (!verification.verified) {
        return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
    }
    // SEC-141: reject counter regression. Once an authenticator has reported a
    // non-zero counter, a response whose counter does not exceed the stored
    // value indicates a cloned/exported credential. Authenticators that never
    // increment (always 0) keep a stored counter of 0 and are unaffected.
    if (cred.counter > 0 &&
        verification.authenticationInfo.newCounter <= cred.counter) {
        logger.warn({
            details: [
                `[PasskeyAuth] Counter regression for credential ${cred.id}: stored ${cred.counter}, got ${verification.authenticationInfo.newCounter}`,
            ],
        }, "[Login:auth] warn");
        return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
    }
    // Update counter to prevent replay attacks
    const updatedCounters = await db
        .update(authenticators)
        .set({
        counter: verification.authenticationInfo.newCounter,
        // A verified assertion proves a legacy credential's RP provenance.
        ...(cred.rpId === null ? { rpId: passkeyAuth.rpID } : {}),
    })
        .where(and(eq(authenticators.id, cred.id), eq(authenticators.counter, cred.counter)))
        .returning({ id: authenticators.id });
    if (updatedCounters.length !== 1) {
        logger.warn({
            details: [
                `[PasskeyAuth] Concurrent counter update rejected for credential ${cred.id}`,
            ],
        }, "[Login:auth] warn");
        return c.json({ ok: false, error: "Passkey authentication failed" }, 401);
    }
    // Ensure wallet is provisioned (idempotent)
    let walletAddress = user.walletAddress;
    if (!walletAddress) {
        try {
            const w = await provisionWalletForUser(user.id, email);
            walletAddress = w.walletAddress;
        }
        catch (err) {
            logger.error({
                details: [
                    "[PasskeyAuth] Wallet provision failed on login",
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:auth] error");
        }
    }
    else {
        // Wallet exists — still ensure personal tenant is in place
        await ensurePersonalTenant(user.id, email);
    }
    await ensureUserTenantLink(user.id, tenantId);
    return authExchangeJson(c, await buildAuthOrMfaResponse(user.id, tenantId, walletAddress ?? "", {
        userId: user.id,
        email,
        authMethod: "passkey",
    }, {
        id: user.id,
        email,
        walletAddress,
    }, c));
});
// ── Email magic link ──────────────────────────────────────────────────────────
/** Tenant-wide ceiling on code-only emails per minute (all IPs, all addresses). */
const EMAIL_CODE_SEND_TENANT_MAX_PER_MINUTE = 120;
async function checkEmailCodeSendTenantBudget(c, tenantId) {
    const tenantRl = await checkAuthRateLimit(c, "email-code-send-tenant", 60_000, EMAIL_CODE_SEND_TENANT_MAX_PER_MINUTE, `tenant:${tenantId}`);
    if (tenantRl.allowed)
        return null;
    return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
}
/**
 * Checks shared by every email sign-in send: tenant hint, login method, SSO
 * domain, tenant email policy, captcha and the per-address budget (5 per 10
 * minutes, one bucket for every email sign-in endpoint so they cannot be
 * combined to exceed it).
 */
async function preflightEmailSignInSend(c, body) {
    const email = body.email.toLowerCase().trim();
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const bodyTenantId = body.tenantId?.trim();
    const resolvedTenantId = headerTenantId || bodyTenantId || defaultAuthTenantId();
    const tenantHintError = await validateExplicitAuthTenantHint(resolvedTenantId, Boolean(headerTenantId || bodyTenantId));
    if (tenantHintError) {
        return {
            ok: false,
            response: c.json({ ok: false, error: tenantHintError }, 404),
        };
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "email");
    if (methodResponse)
        return { ok: false, response: methodResponse };
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse)
        return { ok: false, response: ssoRequiredResponse };
    const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
    const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
    if (emailPolicyError) {
        return {
            ok: false,
            response: c.json({ ok: false, error: emailPolicyError }, 400),
        };
    }
    const captcha = await verifyCaptchaToken(authAbuseConfig, "email_otp", body.captchaToken, trustedClientIp(c));
    if (!captcha.ok) {
        return {
            ok: false,
            response: c.json({ ok: false, error: captcha.error }, captcha.status),
        };
    }
    const emailRl = await checkAuthRateLimit(c, "email-send-destination", 10 * 60_000, 5, email);
    if (!emailRl.allowed) {
        return {
            ok: false,
            response: c.json({ ok: false, error: "Too many requests. Please try again later." }, 429),
        };
    }
    return { ok: true, email, tenantId: resolvedTenantId };
}
/**
 * POST /email/send
 * Body: { email, tenantId?, captchaToken?, delivery? }
 * Sends a sign-in email, returns expiry time. By default the email carries a
 * magic link and a six-digit code. `delivery: "code"` sends only the code (no
 * link token is issued); it is kept for compatibility, and native apps should
 * call POST /email/code/send, which applies the same checks and limits.
 */
auth.post("/email/send", async (c) => {
    // Tiered limits: the per-IP burst is generous (30/min) because one IP is
    // often an office/NAT/dev box full of legit users; the tight anti-abuse
    // backstop is email-send-destination (5 per 10min per address) below.
    const rl = await checkAuthRateLimit(c, "email-send", 60_000, 30);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email) {
        return c.json({ ok: false, error: "email is required" }, 400);
    }
    if (body.delivery !== undefined &&
        body.delivery !== "code" &&
        body.delivery !== "link_and_code") {
        return c.json({ ok: false, error: 'delivery must be "code" or "link_and_code"' }, 400);
    }
    const delivery = body.delivery === "code" ? "code" : "link_and_code";
    const preflight = await preflightEmailSignInSend(c, body);
    if (!preflight.ok)
        return preflight.response;
    const { email, tenantId: resolvedTenantId } = preflight;
    if (delivery === "code") {
        const tenantLimited = await checkEmailCodeSendTenantBudget(c, resolvedTenantId);
        if (tenantLimited)
            return tenantLimited;
    }
    const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
    let sent;
    try {
        sent = await emailAuth.sendMagicLink(email, {
            tenantId: resolvedTenantId,
            delivery,
        });
    }
    catch (err) {
        // Fail closed: ok:true only after the provider accepted the message. On
        // typed delivery failures the challenge is not redeemable (never issued
        // for 503; invalidated by EmailAuth for 502).
        const deliveryFailure = emailDeliveryFailureResponse(c, err);
        if (deliveryFailure)
            return deliveryFailure;
        throw err;
    }
    const { expiresAt, challengeId, pollSecret } = sent;
    return c.json({
        ok: true,
        data: { expiresAt: expiresAt.toISOString(), challengeId, pollSecret },
    });
});
/**
 * POST /email/code/send
 * Body: { email, tenantId?, captchaToken? }
 * Returns 200 { ok: true, data: { expiresAt, codeLength: 6 } }
 *
 * Native in-app email sign-in. Emails ONLY a six-digit code,
 * rendered with the sign-in code template: the email has no link, and no link
 * token is ever published, so nothing in it can sign in a browser or consume
 * the challenge. The app redeems the code through POST /email/code/verify,
 * which returns the Steward session the app passes as Bearer to Cloud's
 * mobile_pkce connect.
 *
 * The code: crypto-random, 10-minute TTL, stored only as an HMAC keyed by a
 * server secret and bound to {email, tenant} (the lookup is by that HMAC, so
 * no stored secret is compared byte by byte), single use (consumed on
 * success), superseded by any later send to the same address, and locked
 * after 5 failed attempts. Limits: 30/min per IP, 5 per 10 min per address
 * (shared with /email/send), EMAIL_CODE_SEND_TENANT_MAX_PER_MINUTE per tenant;
 * verify adds 10/min per IP and 5 per 10 min per tenant+address. No poll
 * secret is returned: a native client never polls.
 */
auth.post("/email/code/send", async (c) => {
    setAuthNoStoreHeaders(c);
    const rl = await checkAuthRateLimit(c, "email-code-send", 60_000, 30);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (typeof body?.email !== "string" ||
        !body.email.trim() ||
        (body.tenantId !== undefined && typeof body.tenantId !== "string") ||
        (body.captchaToken !== undefined && typeof body.captchaToken !== "string")) {
        return c.json({ ok: false, error: "email is required" }, 400);
    }
    const preflight = await preflightEmailSignInSend(c, {
        email: body.email,
        tenantId: body.tenantId,
        captchaToken: body.captchaToken,
    });
    if (!preflight.ok)
        return preflight.response;
    const { email, tenantId } = preflight;
    const tenantLimited = await checkEmailCodeSendTenantBudget(c, tenantId);
    if (tenantLimited)
        return tenantLimited;
    const emailAuth = await getEmailAuthForTenant(tenantId);
    let sent;
    try {
        sent = await emailAuth.sendMagicLink(email, { tenantId, delivery: "code" });
    }
    catch (err) {
        const deliveryFailure = emailDeliveryFailureResponse(c, err);
        if (deliveryFailure)
            return deliveryFailure;
        throw err;
    }
    return c.json({
        ok: true,
        data: { expiresAt: sent.expiresAt.toISOString(), codeLength: 6 },
    });
});
/**
 * GET /callback/email
 * Query: ?token=<token>&email=<email>&tenantId=<tenantId?>
 * Mirrors POST /email/verify for browser clicks from magic link emails,
 * but redirects to the dashboard login page instead of returning JSON.
 */
auth.get("/callback/email", async (c) => {
    const rl = await checkAuthRateLimit(c, "email-callback", 60_000, 10);
    if (!rl.allowed) {
        return redirectEmailAuthFailure(c, "rate_limited");
    }
    const token = c.req.query("token");
    const emailParam = c.req.query("email");
    const tenantId = c.req.query("tenantId");
    if (!token || !emailParam) {
        return redirectEmailAuthFailure(c, "missing_params");
    }
    const email = emailParam.toLowerCase().trim();
    const resolvedTenantId = tenantId || defaultAuthTenantId();
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "email");
    if (methodResponse)
        return redirectEmailAuthFailure(c, "method_disabled");
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse)
        return redirectEmailAuthFailure(c, "sso_required");
    const tokenRl = await checkAuthRateLimit(c, "email-callback-token", 10 * 60_000, 5, emailMagicLinkVerifySubject(token, email, resolvedTenantId));
    if (!tokenRl.allowed) {
        return redirectEmailAuthFailure(c, "rate_limited");
    }
    let result;
    try {
        const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
        result = await emailAuth.verifyMagicLink(token, email, resolvedTenantId);
    }
    catch {
        return redirectEmailAuthFailure(c, "invalid_link");
    }
    if (!result.valid) {
        return redirectEmailAuthFailure(c, "invalid_link");
    }
    if (result.tenantId && result.tenantId !== resolvedTenantId) {
        return redirectEmailAuthFailure(c, "tenant_mismatch");
    }
    if (result.email.toLowerCase().trim() !== email) {
        return redirectEmailAuthFailure(c, "email_mismatch");
    }
    const authResult = await completeEmailAuth(c, email, tenantId);
    if (!authResult.ok) {
        const reason = authResult.status === 404 ? "tenant_not_found" : "tenant_forbidden";
        return redirectEmailAuthFailure(c, reason);
    }
    if (authResult.response.mfaRequired) {
        return redirectEmailAuthFailure(c, "mfa_required");
    }
    const emailRedirectUrl = buildEmailAuthRedirectUrl();
    const nonceBytes = new Uint8Array(32);
    crypto.getRandomValues(nonceBytes);
    const exchangeCode = uint8ArrayToBase64url(nonceBytes);
    const issuedAt = Date.now();
    const expiresAt = issuedAt + OAUTH_CODE_TTL_MS;
    await getOAuthCodeStore().set(`oauth-code:${exchangeCode}`, JSON.stringify({
        token: authResult.response.token,
        refreshToken: authResult.response.refreshToken,
        redirectUri: emailRedirectUrl,
        tenantId: tenantId ?? null,
        expiresAt,
        expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
    }));
    const redirectUrl = new URL(emailRedirectUrl);
    setRedirectFragment(redirectUrl, {
        code: exchangeCode,
        auth: "email",
        tenantId,
    });
    return c.redirect(redirectUrl.toString(), 302);
});
/**
 * POST /email/verify
 * Body: { token, email, tenantId? }
 * Headers: X-Steward-Tenant (optional)
 * Verifies the magic link token, provisions user + wallet, links to tenant, returns JWT.
 */
auth.post("/email/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "email-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many verification attempts. Try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.token || !body?.email) {
        return c.json({ ok: false, error: "token and email are required" }, 400);
    }
    const email = body.email.toLowerCase().trim();
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const bodyTenantId = body.tenantId?.trim();
    const resolvedTenantId = headerTenantId || bodyTenantId || defaultAuthTenantId();
    const tenantHintError = await validateExplicitAuthTenantHint(resolvedTenantId, Boolean(headerTenantId || bodyTenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "email");
    if (methodResponse)
        return methodResponse;
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const tokenRl = await checkAuthRateLimit(c, "email-verify-token", 10 * 60_000, 5, emailMagicLinkVerifySubject(body.token, email, resolvedTenantId));
    if (!tokenRl.allowed) {
        return c.json({ ok: false, error: "Too many verification attempts. Try again later." }, 429);
    }
    const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
    const result = await emailAuth.verifyMagicLink(body.token, email, resolvedTenantId);
    if (!result.valid || result.email.toLowerCase().trim() !== email) {
        return c.json({ ok: false, error: "Invalid or expired magic link" }, 401);
    }
    if (result.tenantId && result.tenantId !== resolvedTenantId) {
        return c.json({ ok: false, error: "Magic link tenant mismatch" }, 401);
    }
    const authResult = await completeEmailAuth(c, email, body.tenantId);
    if (!authResult.ok) {
        return c.json({ ok: false, error: authResult.error }, authResult.status);
    }
    return authExchangeJson(c, authResult.response);
});
auth.post("/email/code/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "email-code-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many verification attempts. Try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email || !body?.code) {
        return c.json({ ok: false, error: "email and code are required" }, 400);
    }
    const email = body.email.toLowerCase().trim();
    const code = body.code.trim();
    const resolvedTenantId = c.req.header("X-Steward-Tenant") || body.tenantId || defaultAuthTenantId();
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "email");
    if (methodResponse)
        return methodResponse;
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const attemptRl = await checkAuthRateLimit(c, "email-code-verify-target", 10 * 60_000, 5, `${resolvedTenantId}:${hashSha256Hex(email)}`);
    if (!attemptRl.allowed) {
        return c.json({ ok: false, error: "Too many verification attempts. Try again later." }, 429);
    }
    const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
    const result = await emailAuth.verifyEmailLoginCode(email, code, resolvedTenantId);
    if (!result.valid) {
        return c.json({
            ok: false,
            error: result.reason === "locked"
                ? "Too many verification attempts. Try again later."
                : "Invalid or expired code",
        }, result.reason === "locked" ? 429 : 401);
    }
    const authResult = await completeEmailAuth(c, email, body.tenantId);
    if (!authResult.ok) {
        return c.json({ ok: false, error: authResult.error }, authResult.status);
    }
    return authExchangeJson(c, authResult.response);
});
auth.post("/email/status", async (c) => {
    const rl = await checkAuthRateLimit(c, "email-status", 60_000, 120);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.challengeId || !body?.pollSecret) {
        return c.json({ ok: false, error: "challengeId and pollSecret are required" }, 400);
    }
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const bodyTenantId = body.tenantId?.trim();
    const resolvedTenantId = headerTenantId || bodyTenantId || defaultAuthTenantId();
    const tenantHintError = await validateExplicitAuthTenantHint(resolvedTenantId, Boolean(headerTenantId || bodyTenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
    const status = await emailAuth.getEmailLoginStatus(body.challengeId, body.pollSecret);
    return c.json({
        ok: true,
        data: {
            status: status.status,
            ...(status.status === "pending" ? { expiresAt: status.expiresAt } : {}),
        },
    });
});
// ── Email OTP (Privy-style verified signup) ───────────────────────────────
//
// POST /auth/email/otp/send    — email a 6-digit one-time code.
// POST /auth/email/otp/verify  — exchange a correct code for a short-lived
//                                single-use verified-email GRANT. The grant
//                                unlocks passkey registration for that exact
//                                {email, tenant} without a session, enabling
//                                email → code → Touch ID signup while keeping
//                                unverified registration (pre-hijack) closed.
auth.post("/email/otp/send", async (c) => {
    // Tiered limits: generous per-IP burst (30/min — shared NATs must not
    // block); email-otp-send-destination (5 per 10min per address) below is the
    // tight anti-abuse backstop.
    const rl = await checkAuthRateLimit(c, "email-otp-send", 60_000, 30);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email) {
        return c.json({ ok: false, error: "email is required" }, 400);
    }
    const email = body.email.toLowerCase().trim();
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim();
    const bodyTenantId = body.tenantId?.trim();
    const resolvedTenantId = headerTenantId || bodyTenantId || defaultAuthTenantId();
    const tenantHintError = await validateExplicitAuthTenantHint(resolvedTenantId, Boolean(headerTenantId || bodyTenantId));
    if (tenantHintError) {
        return c.json({ ok: false, error: tenantHintError }, 404);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "email");
    if (methodResponse)
        return methodResponse;
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
    const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
    if (emailPolicyError) {
        return c.json({ ok: false, error: emailPolicyError }, 400);
    }
    const captcha = await verifyCaptchaToken(authAbuseConfig, "email_otp", body.captchaToken, trustedClientIp(c));
    if (!captcha.ok) {
        return c.json({ ok: false, error: captcha.error }, captcha.status);
    }
    const emailRl = await checkAuthRateLimit(c, "email-otp-send-destination", 10 * 60_000, 5, email);
    if (!emailRl.allowed) {
        return c.json({ ok: false, error: "Too many requests. Please try again later." }, 429);
    }
    const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
    let expiresAt;
    try {
        ({ expiresAt } = await emailAuth.sendOtp(email, {
            tenantId: resolvedTenantId,
        }));
    }
    catch (err) {
        // Fail closed: mirror /email/send — no ok:true without an acceptance
        // receipt, and EmailAuth keeps an unaccepted code non-redeemable.
        const deliveryFailure = emailDeliveryFailureResponse(c, err);
        if (deliveryFailure)
            return deliveryFailure;
        throw err;
    }
    return c.json({
        ok: true,
        data: { expiresAt: expiresAt.toISOString() },
    });
});
auth.post("/email/otp/verify", async (c) => {
    const rl = await checkAuthRateLimit(c, "email-otp-verify", 60_000, 10);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many verification attempts. Try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    if (!body?.email || !body?.code) {
        return c.json({ ok: false, error: "email and code are required" }, 400);
    }
    const email = body.email.toLowerCase().trim();
    const code = body.code.trim();
    const resolvedTenantId = c.req.header("X-Steward-Tenant") || body.tenantId || defaultAuthTenantId();
    const methodResponse = await requireTenantLoginMethodAllowed(c, resolvedTenantId, "email");
    if (methodResponse)
        return methodResponse;
    const ssoRequiredResponse = await requireNonSsoEmailLoginAllowed(c, resolvedTenantId, email, "Email");
    if (ssoRequiredResponse)
        return ssoRequiredResponse;
    // Per-{email,tenant} attempt limiter so 6 digits can't be brute-forced:
    // 5 attempts / 10 min regardless of source IP.
    const attemptRl = await checkAuthRateLimit(c, "email-otp-verify-target", 10 * 60_000, 5, `${resolvedTenantId}:${email}`);
    if (!attemptRl.allowed) {
        return c.json({ ok: false, error: "Too many verification attempts. Try again later." }, 429);
    }
    const emailAuth = await getEmailAuthForTenant(resolvedTenantId);
    const valid = await emailAuth.verifyOtp(email, code, resolvedTenantId);
    if (!valid) {
        return c.json({ ok: false, error: "Invalid or expired code" }, 401);
    }
    const grant = await issueEmailGrant(email, resolvedTenantId, c.req.header("X-Steward-Tenant") || body.tenantId ? "tenant" : "personal");
    return c.json({
        ok: true,
        data: {
            emailGrant: grant,
            expiresInSeconds: Math.floor(EMAIL_GRANT_TTL_MS / 1000),
        },
    });
});
// ── Guest (ephemeral / anonymous) accounts — Privy parity ─────────────────────
//
// POST /auth/guest          — mint an ephemeral guest user + bounded session.
// POST /auth/guest/upgrade  — promote a guest into a full account by attaching a
//                             verified identity, preserving the user id + data.
//
// A guest carries strictly LIMITED authority: it is linked to its tenant with
// role "guest", which does NOT satisfy requireTenantLevel(), so guest sessions
// are denied from owner/admin/tenant-config/key-import/export actions. The
// guest session is hard-bounded by users.guest_expires_at (enforced server-side
// in verifySessionToken, fail-closed), independent of the access-token exp.
/** Guest session role — deliberately below "member" so requireTenantLevel() is false. */
const GUEST_TENANT_ROLE = "guest";
/** Default guest session lifetime (24h) and hard cap (7d). Bounded + revocable. */
const GUEST_DEFAULT_LIFETIME_MS = 24 * 3600 * 1000;
const GUEST_MAX_LIFETIME_MS = 7 * 24 * 3600 * 1000;
/** Parse a duration string like "30m", "24h", "7d" into ms. Null on parse error. */
function parseGuestLifetimeMs(input) {
    if (input === undefined || input === null || input === "")
        return GUEST_DEFAULT_LIFETIME_MS;
    if (typeof input !== "string")
        return null;
    const m = /^(\d+)\s*(s|m|h|d)$/i.exec(input.trim());
    if (!m)
        return null;
    const n = Number(m[1]);
    if (!Number.isFinite(n) || n <= 0)
        return null;
    const unit = m[2].toLowerCase();
    const mult = unit === "s"
        ? 1000
        : unit === "m"
            ? 60_000
            : unit === "h"
                ? 3_600_000
                : 86_400_000;
    return Math.min(n * mult, GUEST_MAX_LIFETIME_MS);
}
/**
 * Resolve + gate the tenant a guest is created into. A guest may only be minted
 * into the default tenant or an explicitly "open"-join tenant; reserved/personal
 * tenants of other users and invite/closed tenants are refused (fail-closed).
 */
async function resolveGuestTenant(c, bodyTenantId) {
    const headerTenant = c.req.header("X-Steward-Tenant")?.trim();
    const requested = headerTenant ||
        (typeof bodyTenantId === "string" ? bodyTenantId.trim() : "") ||
        defaultAuthTenantId();
    if (!isValidTenantId(requested)) {
        return { ok: false, status: 400, error: "Invalid tenant id format" };
    }
    if (isReservedTenantId(requested)) {
        return {
            ok: false,
            status: 403,
            error: "Guests cannot be created in a personal tenant",
        };
    }
    const subject = await authTenantSubject(requested);
    if (!subject) {
        return { ok: false, status: 404, error: `Tenant '${requested}' not found` };
    }
    if (requested === defaultAuthTenantId()) {
        return { ok: true, tenantId: requested, isPersonal: false };
    }
    if (subject.join_mode === "open") {
        return { ok: true, tenantId: requested, isPersonal: false };
    }
    return {
        ok: false,
        status: 403,
        error: `Tenant '${requested}' does not accept guest sign-in`,
    };
}
auth.post("/guest", async (c) => {
    const rl = await checkAuthRateLimit(c, "guest-create", 60_000, 20);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many guest sign-in attempts. Try again later." }, 429);
    }
    const body = await safeJsonParse(c);
    // A malformed JSON body is tolerated (guest create takes no required fields),
    // but if a body was sent it must be an object so we don't silently ignore a
    // mistyped tenantId/expiresIn.
    if (body !== null && (typeof body !== "object" || Array.isArray(body))) {
        return c.json({ ok: false, error: "Request body must be a JSON object" }, 400);
    }
    const lifetimeMs = parseGuestLifetimeMs(body?.expiresIn);
    if (lifetimeMs === null) {
        return c.json({ ok: false, error: "'expiresIn' must be like '30m', '24h', '7d'" }, 400);
    }
    const tenantResult = await resolveGuestTenant(c, body?.tenantId);
    if (!tenantResult.ok) {
        return c.json({ ok: false, error: tenantResult.error }, tenantResult.status);
    }
    const tenantId = tenantResult.tenantId;
    const guestExpiresAt = new Date(Date.now() + lifetimeMs);
    const db = getDb();
    const [guest] = await db
        .insert(users)
        .values({
        email: null,
        emailVerified: false,
        isGuest: true,
        guestExpiresAt,
    })
        .returning();
    // Link the guest to the requesting tenant with the LIMITED "guest" role so the
    // session cannot satisfy requireTenantLevel(). onConflictDoNothing keeps this
    // idempotent against a racing insert on the (userId, tenantId) unique index.
    await withVerifiedAuthTenant(tenantId, guest.id, async () => {
        await getDb()
            .insert(userTenants)
            .values({ userId: guest.id, tenantId, role: GUEST_TENANT_ROLE })
            .onConflictDoNothing();
    });
    // Provision the guest's wallet under its own personal namespace so it has a
    // wallet/agents immediately AND those rows survive a later upgrade unchanged.
    let walletAddress = guest.walletAddress;
    try {
        const provisioned = await provisionWalletForUser(guest.id, `guest-${guest.id}`);
        walletAddress = provisioned.walletAddress;
    }
    catch (err) {
        logger.error({
            details: [
                "[GuestAuth] Wallet provision failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
    }
    const sessionClaims = {
        userId: guest.id,
        tenantId,
        guest: true,
        guestExpiresAt: guestExpiresAt.toISOString(),
        authMethod: "guest",
    };
    const token = await createSessionToken(walletAddress ?? "", tenantId, sessionClaims);
    const refreshToken = await createRefreshToken(guest.id, tenantId, sessionClaims);
    await writeAuditEvent({
        tenantId,
        actorType: "user",
        actorId: guest.id,
        action: "auth.guest.created",
        resourceType: "session",
        metadata: { method: "guest", guestExpiresAt: guestExpiresAt.toISOString() },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    dispatchUserAuthenticated(tenantId, guest.id, "guest");
    return c.json(buildAuthResponse(token, refreshToken, {
        id: guest.id,
        isGuest: true,
        guestExpiresAt: guestExpiresAt.toISOString(),
        email: null,
        walletAddress: walletAddress ?? null,
        tenantId,
    }));
});
auth.delete("/guest", async (c) => {
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const userId = session.payload.userId;
    const tenantId = session.payload.tenantId;
    const db = getDb();
    const [user] = await db
        .select({
        id: users.id,
        isGuest: users.isGuest,
        deactivatedAt: users.deactivatedAt,
    })
        .from(users)
        .where(eq(users.id, userId));
    if (!user)
        return c.json({ ok: false, error: "User not found" }, 404);
    if (!user.isGuest) {
        return c.json({
            ok: false,
            error: "Only guest accounts can be deleted with this endpoint",
        }, 409);
    }
    await writeAuditEvent({
        tenantId,
        actorType: "user",
        actorId: userId,
        action: "auth.guest.delete.authorized",
        resourceType: "user",
        resourceId: userId,
        metadata: { method: "guest" },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    await db.transaction(async (tx) => {
        await tx
            .update(users)
            .set({ deactivatedAt: new Date() })
            .where(eq(users.id, userId));
        await tx.delete(refreshTokens).where(eq(refreshTokens.userId, userId));
    });
    await revocationStore.revokeUserTokens(userId);
    await writeAuditEvent({
        tenantId,
        actorType: "user",
        actorId: userId,
        action: "auth.guest.deleted",
        resourceType: "user",
        resourceId: userId,
        metadata: {
            method: "guest",
            wasAlreadyDeactivated: user.deactivatedAt !== null,
        },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    return c.json({
        ok: true,
        deleted: true,
        userId,
    });
});
auth.post("/guest/upgrade", async (c) => {
    const rl = await checkAuthRateLimit(c, "guest-upgrade", 60_000, 20);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many upgrade attempts. Try again later." }, 429);
    }
    const session = await requireSession(c);
    if (!session.ok)
        return session.response;
    const userId = session.payload.userId;
    const tenantId = session.payload.tenantId;
    const body = await safeJsonParse(c);
    // Only email-magic-link upgrade is supported here. The identity MUST be
    // verified (a valid, unexpired magic-link token) BEFORE any promotion — never
    // promote on an unverified/claimed email.
    if (!body || (body.method !== undefined && body.method !== "email")) {
        return c.json({
            ok: false,
            error: "Unsupported upgrade method — only 'email' is supported",
        }, 400);
    }
    const magicLinkToken = typeof body.token === "string" ? body.token.trim() : "";
    const rawEmail = typeof body.email === "string" ? body.email.trim() : "";
    if (!magicLinkToken || !rawEmail) {
        return c.json({ ok: false, error: "token and email are required to upgrade a guest" }, 400);
    }
    const email = rawEmail.toLowerCase();
    const emailAuth = await getEmailAuthForTenant(tenantId);
    // The shared link+code challenge binds each token to {email, tenant}; pass
    // both so verification enforces the binding (token-only calls fail closed).
    const result = await emailAuth.verifyMagicLink(magicLinkToken, email, tenantId);
    if (!result.valid || result.email.toLowerCase().trim() !== email) {
        return c.json({ ok: false, error: "Invalid or expired magic link" }, 401);
    }
    if (result.tenantId && result.tenantId !== tenantId) {
        return c.json({ ok: false, error: "Magic link tenant mismatch" }, 401);
    }
    const db = getDb();
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user)
        return c.json({ ok: false, error: "User not found" }, 404);
    // Idempotent replay: re-running the upgrade with the SAME verified email on an
    // already-upgraded account is a no-op success (same id, no re-guesting).
    if (!user.isGuest) {
        if (user.email && user.email.toLowerCase() === email) {
            const token = await createSessionToken(user.walletAddress ?? "", tenantId, {
                userId,
                tenantId,
                authMethod: "email",
            });
            const refreshToken = await createRefreshToken(userId, tenantId, {
                userId,
                tenantId,
                authMethod: "email",
            });
            return c.json(buildAuthResponse(token, refreshToken, {
                id: userId,
                isGuest: false,
                email: user.email,
                walletAddress: user.walletAddress ?? null,
                tenantId,
                alreadyUpgraded: true,
            }));
        }
        return c.json({ ok: false, error: "Account is already a full user" }, 409);
    }
    // Reject upgrading an expired guest (fail-closed): the session is dead.
    if (user.guestExpiresAt && user.guestExpiresAt.getTime() <= Date.now()) {
        return c.json({ ok: false, error: "Guest session has expired" }, 401);
    }
    // The verified email must not already belong to a DIFFERENT user, or upgrading
    // would either collide on the unique email index or hijack another identity.
    const existingByEmail = await findUserByEmail(email);
    if (existingByEmail && existingByEmail.id !== userId) {
        return c.json({ ok: false, error: "Email is already associated with another account" }, 409);
    }
    // Promote in a single transaction, preserving users.id and every owned row
    // (agents/wallets/memberships are keyed by user id and are untouched). The
    // membership role is raised guest -> member only; never auto-escalated to
    // admin/owner, and the tenant is never changed (no cross-tenant escalation).
    await db.transaction(async (tx) => {
        await tx
            .update(users)
            .set({ email, emailVerified: true, isGuest: false, guestExpiresAt: null })
            .where(eq(users.id, userId));
        await tx
            .update(userTenants)
            .set({ role: "member" })
            .where(and(eq(userTenants.userId, userId), eq(userTenants.tenantId, tenantId), eq(userTenants.role, GUEST_TENANT_ROLE)));
    });
    const sessionClaims = {
        userId,
        tenantId,
        authMethod: "email",
    };
    const token = await createSessionToken(user.walletAddress ?? "", tenantId, sessionClaims);
    const refreshToken = await createRefreshToken(userId, tenantId, sessionClaims);
    await writeAuditEvent({
        tenantId,
        actorType: "user",
        actorId: userId,
        action: "auth.guest.upgraded",
        resourceType: "user",
        resourceId: userId,
        metadata: { method: "email" },
        ipAddress: c.req.header("x-forwarded-for") ?? null,
        userAgent: c.req.header("user-agent") ?? null,
        requestId: c.get("requestId") ?? null,
    });
    dispatchUserAuthenticated(tenantId, userId, "email");
    return c.json(buildAuthResponse(token, refreshToken, {
        id: userId,
        isGuest: false,
        email,
        walletAddress: user.walletAddress ?? null,
        tenantId,
    }));
});
// ── OAuth authorization-code flow ─────────────────────────────────────────────
/**
 * Provider `prompt` values an /authorize caller may pass through. Native
 * clients use `select_account` so the provider always shows an account picker:
 * the user picks the intended Google account, and the final redirect follows a
 * user gesture, which is what lets Android deliver it to a verified App Link.
 * Anything not listed (including `none`, which would silently reuse a session)
 * is rejected rather than dropped, so a caller never believes a prompt was
 * honoured when it was not.
 */
const OAUTH_PROMPT_PASSTHROUGH = {
    google: new Set(["select_account", "consent", "select_account consent"]),
};
export function resolveOAuthPromptPassthrough(providerName, rawPrompt) {
    if (rawPrompt === undefined)
        return { ok: true };
    const prompt = rawPrompt.trim().replace(/\s+/g, " ");
    if (!prompt)
        return { ok: true };
    if (!OAUTH_PROMPT_PASSTHROUGH[providerName]?.has(prompt)) {
        return { ok: false, error: "prompt is not supported for this provider" };
    }
    return { ok: true, prompt };
}
/**
 * GET /oauth/:provider/authorize
 * Query: ?redirect_uri=<url>&tenant_id=<id>
 *
 * Generates an OAuth authorization URL, stores the CSRF state in the challenge
 * store (keyed as `oauth:<state>`), then redirects the user to the provider.
 */
// Read-only readiness for any registered application. Never issues a credential.
auth.get("/oauth/google/app-readiness", async (c) => {
    c.header("Cache-Control", "no-store");
    const tenantId = c.req.query("tenant_id");
    const redirectUri = c.req.query("redirect_uri");
    if (!tenantId ||
        tenantId.length > 100 ||
        !redirectUri ||
        redirectUri.length > 2048) {
        return c.json({ ok: false, error: "App sign-in unavailable" }, 400);
    }
    try {
        const target = new URL(redirectUri);
        if (target.protocol !== "https:" ||
            target.username ||
            target.password ||
            target.hash ||
            target.search) {
            return c.json({ ok: false, error: "App sign-in unavailable" }, 400);
        }
    }
    catch {
        return c.json({ ok: false, error: "App sign-in unavailable" }, 400);
    }
    const rl = await checkAuthRateLimit(c, "app-auth-readiness", 60_000, 30);
    if (!rl.allowed)
        return c.json({ ok: false, error: "Try again later" }, 429);
    try {
        const denied = await requireTenantLoginMethodAllowed(c, tenantId, "oauth", "google");
        if (denied)
            return c.json({ ok: false, error: "App sign-in unavailable" }, 403);
        await assertAllowedOAuthRedirectUri(redirectUri, tenantId);
        getProviderConfig("google");
        const errorReturn = buildOAuthAppErrorReturn(redirectUri, "s".repeat(43), "access_denied", process.env.STEWARD_OAUTH_APP_ERROR_REDIRECTS);
        if (!errorReturn)
            throw new Error("App error returns are not configured");
        return c.json({ ok: true, appAuth: 1, tenantId, redirectUri });
    }
    catch {
        return c.json({ ok: false, error: "App sign-in unavailable" }, 503);
    }
});
auth.get("/oauth/:provider/authorize", async (c) => {
    const providerName = c.req.param("provider");
    if (!isBuiltInProvider(providerName)) {
        return c.json({ ok: false, error: `Unknown provider: ${providerName}` }, 400);
    }
    const rl = await checkAuthRateLimit(c, `oauth-authorize:${providerName}`, 60_000, 30);
    if (!rl.allowed) {
        return c.json({
            ok: false,
            error: "Too many OAuth authorization requests. Please try again later.",
        }, 429);
    }
    const redirectUri = c.req.query("redirect_uri");
    const appState = c.req.query("state")?.trim() || undefined;
    const promptResult = resolveOAuthPromptPassthrough(providerName, c.req.query("prompt"));
    if (!promptResult.ok) {
        return c.json({ ok: false, error: promptResult.error }, 400);
    }
    // `mfa=exchange` (native apps): when the account needs a second factor, the
    // callback returns an ordinary one-time code to redirect_uri instead of the
    // HTML error page, and POST /oauth/exchange (PKCE-checked as usual) answers
    // with the MFA challenge so the app can finish through /auth/mfa/*/complete
    // in its own screens. Without it, MFA accounts keep the error page.
    const rawMfaMode = c.req.query("mfa");
    if (rawMfaMode !== undefined && rawMfaMode !== "exchange") {
        return c.json({ ok: false, error: "mfa must be 'exchange' when present" }, 400);
    }
    const mfaMode = rawMfaMode === "exchange" ? "exchange" : undefined;
    // Accept both `tenant_id` (snake_case, canonical) and `tenantId` (camelCase)
    // so integrators sending either shape land on the right tenant. Whitespace
    // is trimmed defensively for the same reason we trim headers elsewhere.
    const tenantId = c.req.query("tenant_id")?.trim() ||
        c.req.query("tenantId")?.trim() ||
        undefined;
    const rawClientId = c.req.query("client_id") ?? c.req.query("clientId");
    const clientId = rawClientId
        ? normalizePublicClientId(rawClientId)
        : undefined;
    if (rawClientId && !clientId) {
        return c.json({ ok: false, error: "client_id is invalid" }, 400);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, tenantId, "oauth", providerName, clientId);
    if (methodResponse)
        return methodResponse;
    // Default to the nonce-exchange flow so access and refresh tokens stay out
    // of browser history, server access logs, Referer headers, and copied URLs.
    // Token-in-query redirects are an explicitly unsafe compatibility mode.
    const responseType = c.req.query("response_type")?.trim() || "code";
    const codeChallenge = c.req.query("code_challenge")?.trim() || undefined;
    const codeChallengeMethod = c.req.query("code_challenge_method")?.trim() || "S256";
    if (!redirectUri) {
        return c.json({ ok: false, error: "redirect_uri is required" }, 400);
    }
    if (responseType !== undefined &&
        responseType !== "code" &&
        responseType !== "token") {
        return c.json({ ok: false, error: "response_type must be 'code' or 'token'" }, 400);
    }
    if (responseType === "token") {
        return c.json({
            ok: false,
            error: "response_type=token is disabled because it exposes tokens in URLs; use response_type=code",
        }, 400);
    }
    if (responseType === "code") {
        if (!codeChallenge) {
            return c.json({
                ok: false,
                error: "code_challenge is required for response_type=code",
            }, 400);
        }
        if (codeChallengeMethod !== "S256") {
            return c.json({ ok: false, error: "code_challenge_method must be 'S256'" }, 400);
        }
    }
    let oauthClient;
    try {
        oauthClient = new OAuthClient(getProviderConfig(providerName));
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Provider not configured",
        }, 503);
    }
    try {
        await assertAllowedOAuthRedirectUri(redirectUri, tenantId, clientId);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Invalid redirect_uri",
        }, 400);
    }
    // Generate a cryptographically random state value
    const stateBytes = new Uint8Array(16);
    crypto.getRandomValues(stateBytes);
    const state = Array.from(stateBytes)
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
    const callbackUrl = buildOAuthCallbackUrl(c, providerName);
    const oidcNonce = providerName === "apple" ? randomBase64Url(24) : undefined;
    const generatedAuth = oauthClient.generateAuthUrl(state, callbackUrl);
    let authUrl = generatedAuth.url;
    const codeVerifier = generatedAuth.codeVerifier;
    if (oidcNonce) {
        const url = new URL(authUrl);
        url.searchParams.set("nonce", oidcNonce);
        authUrl = url.toString();
    }
    if (promptResult.prompt) {
        const url = new URL(authUrl);
        url.searchParams.set("prompt", promptResult.prompt);
        authUrl = url.toString();
    }
    // Store state metadata in the challenge store — include PKCE verifier when present
    const statePayload = JSON.stringify({
        provider: providerName,
        tenantId,
        clientId,
        redirectUri,
        responseType,
        appState,
        codeChallenge,
        codeChallengeMethod,
        ...(mfaMode ? { mfaMode } : {}),
        ...(oidcNonce ? { oidcNonce } : {}),
        ...(codeVerifier ? { codeVerifier } : {}),
    });
    await getChallengeStore().set(`oauth:${state}`, statePayload);
    return c.redirect(authUrl, 302);
});
/**
 * GET /oauth/:provider/callback
 * Handles the redirect from the OAuth provider.
 *
 * Flow:
 *   1. Validate state (CSRF)
 *   2. Exchange code for access token
 *   3. Fetch user profile from provider
 *   4. Find/create user by email
 *   5. Upsert entry in `accounts` table
 *   6. Link user to requested tenant
 *   7. Mint JWT → redirect to app redirect_uri with ?token=<jwt>
 */
auth.get("/oauth/:provider/callback", async (c) => {
    const providerName = c.req.param("provider");
    const code = c.req.query("code");
    const state = c.req.query("state");
    const errorParam = c.req.query("error");
    if (errorParam) {
        // Provider-controlled text may contain markup, credentials, or diagnostics.
        // Keep the browser response stable and non-reflective.
        const recovery = await oauthCallbackRecoveryFromStoredState("oauth", state, providerName);
        return oauthCallbackFailure(c, {
            code: "oauth_authorization_failed",
            message: "The provider did not authorize this sign-in.",
            status: 400,
            ...recovery,
        });
    }
    if (!isBuiltInProvider(providerName)) {
        return oauthCallbackFailure(c, {
            code: "oauth_provider_unknown",
            message: "This sign-in provider is not supported.",
            status: 400,
        });
    }
    if (!code || !state) {
        const recovery = await oauthCallbackRecoveryFromStoredState("oauth", state, providerName);
        return oauthCallbackFailure(c, {
            code: "oauth_callback_incomplete",
            message: "The provider returned an incomplete sign-in response.",
            status: 400,
            ...recovery,
        });
    }
    // Load state before provider calls, then consume it only after provider token
    // exchange and identity verification succeed. Invalid provider codes must not
    // burn a legitimate browser login attempt's one-time state.
    const stateKey = `oauth:${state}`;
    const rawPayload = await getChallengeStore().get(stateKey);
    if (!rawPayload) {
        return oauthCallbackFailure(c, {
            code: "oauth_state_expired",
            message: "This sign-in attempt is invalid or has expired.",
            status: 401,
        });
    }
    let stateData;
    try {
        stateData = JSON.parse(rawPayload);
    }
    catch {
        return oauthCallbackFailure(c, {
            code: "oauth_state_invalid",
            message: "This sign-in attempt could not be validated.",
            status: 400,
        });
    }
    if (stateData.provider !== providerName) {
        return oauthCallbackFailure(c, {
            code: "oauth_provider_mismatch",
            message: "The provider does not match this sign-in attempt.",
            status: 400,
        });
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, stateData.tenantId, "oauth", providerName, stateData.clientId);
    if (methodResponse) {
        return oauthCallbackFailure(c, {
            code: "oauth_login_disabled",
            message: "OAuth sign-in is disabled for this application.",
            status: 403,
        });
    }
    let redirectUrl;
    try {
        redirectUrl = await assertAllowedOAuthRedirectUri(stateData.redirectUri, stateData.tenantId, stateData.clientId);
    }
    catch (err) {
        logger.error({
            details: [
                "[OAuthAuth] Callback redirect validation failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oauth_redirect_invalid",
            message: "The application return address is not allowed.",
            status: 400,
        });
    }
    let oauthClient;
    try {
        oauthClient = new OAuthClient(getProviderConfig(providerName));
    }
    catch (err) {
        logger.error({
            details: [
                "[OAuthAuth] Callback provider setup failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oauth_provider_unavailable",
            message: "This sign-in provider is not available.",
            status: 503,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    const callbackUrl = buildOAuthCallbackUrl(c, providerName);
    if (providerName === "apple") {
        oauthClient.setExpectedNonce(stateData.oidcNonce);
    }
    // Exchange code for access token — pass codeVerifier for PKCE providers (e.g. Twitter)
    let tokenResponse;
    try {
        tokenResponse = await oauthClient.exchangeCode(code, callbackUrl, stateData.codeVerifier);
    }
    catch (err) {
        logger.error({
            details: [
                "[OAuthAuth] Callback token exchange failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oauth_token_exchange_failed",
            message: "The provider could not complete sign-in. Please try again.",
            status: 502,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    // Fetch user info from provider
    let providerUser;
    try {
        providerUser = await oauthClient.getUserInfo(tokenResponse.access_token);
    }
    catch (err) {
        logger.error({
            details: [
                "[OAuthAuth] Callback profile fetch failed",
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return oauthCallbackFailure(c, {
            code: "oauth_profile_fetch_failed",
            message: "The provider profile could not be loaded. Please try again.",
            status: 502,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    // Twitter and some providers do not return an email address.
    // Generate a synthetic internal email so findOrCreateUser() can still work.
    // This email is never displayed or sent — it is purely an internal identity key.
    if (!providerUser.email) {
        if (!providerUser.id) {
            return oauthCallbackFailure(c, {
                code: "oauth_identity_incomplete",
                message: "The provider did not return enough account information.",
                status: 400,
                redirectUrl,
                appState: stateData.appState,
            });
        }
        providerUser = {
            ...providerUser,
            email: oauthSyntheticEmail(providerName, providerUser.id),
            syntheticEmailGenerated: true,
        };
    }
    const consumedPayload = await getChallengeStore().consume(stateKey);
    if (consumedPayload !== rawPayload) {
        return oauthCallbackFailure(c, {
            code: "oauth_state_consumed",
            message: "This sign-in attempt is invalid or has already been used.",
            status: 401,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    // Create/find user + provision wallet + link tenant
    const result = await provisionOAuthUser({
        c,
        providerName,
        providerUser,
        tokenResponse,
        tenantId: stateData.tenantId,
    });
    if (!result.ok) {
        const isUnverifiedEmail = result.error ===
            "Provider email must be verified before OAuth sign-in is allowed";
        return oauthCallbackFailure(c, {
            code: isUnverifiedEmail
                ? "oauth_verified_email_required"
                : "oauth_account_provisioning_failed",
            message: isUnverifiedEmail
                ? "Provider email must be verified before OAuth sign-in is allowed."
                : "Your account could not be prepared for sign-in.",
            status: result.status ?? 500,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    if (result.response.ok === false) {
        return oauthCallbackFailure(c, {
            code: "oauth_authentication_failed",
            message: "Sign-in could not be completed.",
            status: 403,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    if (result.response.mfaRequired) {
        if (stateData.mfaMode === "exchange" && stateData.codeChallenge) {
            // Same one-time, PKCE-bound, redirect- and tenant-bound code as a
            // success; it redeems to the MFA challenge instead of tokens.
            const mfaExchangeCode = uint8ArrayToBase64url(crypto.getRandomValues(new Uint8Array(32)));
            await getOAuthCodeStore().set(`oauth-code:${mfaExchangeCode}`, JSON.stringify({
                providerName,
                mfaRequired: true,
                mfa: result.response.mfa,
                user: result.response.user,
                redirectUri: stateData.redirectUri,
                tenantId: stateData.tenantId ?? null,
                codeChallenge: stateData.codeChallenge,
                codeChallengeMethod: stateData.codeChallengeMethod ?? "S256",
                expiresAt: Date.now() + OAUTH_CODE_TTL_MS,
            }));
            setRedirectFragment(redirectUrl, {
                code: mfaExchangeCode,
                state: stateData.appState,
            });
            return c.redirect(redirectUrl.toString(), 302);
        }
        return oauthCallbackFailure(c, {
            code: "mfa_required",
            message: "Additional verification is required to complete sign-in.",
            status: 403,
            redirectUrl,
            appState: stateData.appState,
        });
    }
    // Nonce-exchange path: issue a one-time, short-lived (60s) code that the
    // caller's backend trades for the real tokens via POST /oauth/exchange.
    // This keeps the tokens off the address bar / browser history / Referer /
    // upstream access logs / any window the user copy-pastes. The pair
    // {redirectUri, tenantId} is bound to the code so a stolen code cannot be
    // redeemed against a different redirect_uri or pivoted to another tenant.
    const nonceBytes = new Uint8Array(32);
    crypto.getRandomValues(nonceBytes);
    const exchangeCode = uint8ArrayToBase64url(nonceBytes);
    const issuedAt = Date.now();
    const expiresAt = issuedAt + OAUTH_CODE_TTL_MS;
    const codePayload = JSON.stringify({
        providerName,
        token: result.response.token,
        refreshToken: result.response.refreshToken,
        user: result.response.user,
        redirectUri: stateData.redirectUri,
        tenantId: stateData.tenantId ?? null,
        codeChallenge: stateData.codeChallenge,
        codeChallengeMethod: stateData.codeChallengeMethod ?? "S256",
        expiresAt,
        expiresIn: ACCESS_TOKEN_EXPIRY_SECONDS,
    });
    await getOAuthCodeStore().set(`oauth-code:${exchangeCode}`, codePayload);
    setRedirectFragment(redirectUrl, {
        code: exchangeCode,
        state: stateData.appState,
    });
    return c.redirect(redirectUrl.toString(), 302);
});
/**
 * POST /auth/oauth/exchange
 *
 * Nonce-exchange endpoint for the `response_type=code` OAuth flow above.
 * Trades a one-time `code` for the real `{token, refreshToken, expiresAt}`
 * payload. The code is bound to the `redirect_uri` and `tenant_id` that were
 * supplied at /authorize time; both must match or the exchange is rejected.
 *
 * Body: { code: string; redirect_uri: string; tenant_id?: string | null }
 * Returns 200 { ok: true, token, refreshToken, expiresIn, expiresAt }
 * Errors:
 *   400 invalid_request        — missing/blank `code` or `redirect_uri`
 *   401 code_invalid           — unknown / already-consumed / expired code
 *   401 code_expired           — found but past `expiresAt` (defense-in-depth;
 *                                the store TTL already evicts these)
 *   401 code_redirect_mismatch — `redirect_uri` does not match
 *   401 code_tenant_mismatch   — `tenant_id` does not match
 *
 * Invalid redemption attempts do not burn the code. A short lock serializes
 * valid redemption so the code remains single-use without letting a bad PKCE
 * verifier kill the user's login.
 */
auth.post("/oauth/exchange", async (c) => {
    const rl = await checkAuthRateLimit(c, "oauth-exchange", 60_000, 30);
    if (!rl.allowed) {
        return c.json({
            ok: false,
            error: "Too many OAuth exchange attempts. Try again later.",
        }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    const code = typeof body?.code === "string" ? body.code.trim() : "";
    const redirectUri = typeof body?.redirect_uri === "string"
        ? body.redirect_uri.trim()
        : typeof body?.redirectUri === "string"
            ? body.redirectUri.trim()
            : "";
    const rawTenantId = typeof body?.tenant_id === "string"
        ? body.tenant_id.trim()
        : typeof body?.tenantId === "string"
            ? body.tenantId.trim()
            : "";
    const tenantId = rawTenantId.length > 0 ? rawTenantId : null;
    const codeVerifier = typeof body?.code_verifier === "string"
        ? body.code_verifier.trim()
        : typeof body?.codeVerifier === "string"
            ? body.codeVerifier.trim()
            : "";
    if (!code || !redirectUri) {
        return c.json({ ok: false, error: "code and redirect_uri are required" }, 400);
    }
    const codeKey = `oauth-code:${code}`;
    const raw = await getOAuthCodeStore().get(codeKey);
    if (!raw) {
        return c.json({
            ok: false,
            error: "Invalid or already-used code",
            code: "code_invalid",
        }, 401);
    }
    let payload;
    try {
        payload = JSON.parse(raw);
    }
    catch {
        return c.json({ ok: false, error: "Malformed code payload", code: "code_invalid" }, 401);
    }
    if (Date.now() > payload.expiresAt) {
        return c.json({ ok: false, error: "Code expired", code: "code_expired" }, 401);
    }
    if (payload.codeChallenge) {
        if (!codeVerifier || !isValidPkceCodeVerifier(codeVerifier)) {
            return c.json({
                ok: false,
                error: "Invalid code verifier",
                code: "code_verifier_invalid",
            }, 401);
        }
        const computedChallenge = await pkceChallengeForVerifier(codeVerifier, payload.codeChallengeMethod ?? "S256");
        if (!computedChallenge || computedChallenge !== payload.codeChallenge) {
            return c.json({
                ok: false,
                error: "Code verifier mismatch",
                code: "code_verifier_mismatch",
            }, 401);
        }
    }
    if (payload.redirectUri !== redirectUri) {
        return c.json({
            ok: false,
            error: "redirect_uri does not match the one issued with the code",
            code: "code_redirect_mismatch",
        }, 401);
    }
    if ((payload.tenantId ?? null) !== tenantId) {
        return c.json({
            ok: false,
            error: "tenant_id does not match the one issued with the code",
            code: "code_tenant_mismatch",
        }, 401);
    }
    const methodResponse = await requireTenantLoginMethodAllowed(c, payload.tenantId ?? undefined, "oauth", payload.providerName);
    if (methodResponse)
        return methodResponse;
    if (!(await lockOAuthCodeRedemption(code))) {
        return c.json({
            ok: false,
            error: "OAuth code is already being redeemed",
            code: "code_in_use",
        }, 409);
    }
    try {
        const consumed = await getOAuthCodeStore().consume(codeKey);
        if (!consumed) {
            return c.json({
                ok: false,
                error: "Invalid or already-used code",
                code: "code_invalid",
            }, 401);
        }
        if (consumed !== raw) {
            return c.json({
                ok: false,
                error: "OAuth code changed during redemption",
                code: "code_invalid",
            }, 401);
        }
    }
    finally {
        await releaseOAuthCodeRedemptionLock(code);
    }
    if (payload.mfaRequired === true) {
        return c.json({
            ok: true,
            mfaRequired: true,
            mfa: payload.mfa,
            ...(payload.user ? { user: payload.user } : {}),
        });
    }
    return c.json({
        ok: true,
        token: payload.token,
        refreshToken: payload.refreshToken,
        ...(payload.user ? { user: payload.user } : {}),
        expiresIn: payload.expiresIn,
        expiresAt: payload.expiresAt,
    });
});
/**
 * POST /oauth/:provider/token
 * SPA / popup flow — the client has already obtained the code.
 *
 * Body: { code: string; redirectUri: string; tenantId?: string; codeVerifier?: string }
 * Returns: { ok: true; token: string; user: { id, email, walletAddress } }
 */
auth.post("/oauth/:provider/token", async (c) => {
    const providerName = c.req.param("provider");
    if (!isBuiltInProvider(providerName)) {
        return c.json({ ok: false, error: `Unknown provider: ${providerName}` }, 400);
    }
    const rl = await checkAuthRateLimit(c, `oauth-token:${providerName}`, 60_000, 20);
    if (!rl.allowed) {
        return c.json({ ok: false, error: "Too many OAuth token attempts. Try again later." }, 429, { "Retry-After": String(rl.retryAfterSecs ?? 60) });
    }
    const body = await safeJsonParse(c);
    if (!body?.code || !body?.redirectUri) {
        return c.json({ ok: false, error: "code and redirectUri are required" }, 400);
    }
    const bodyTenantId = body.tenantId?.trim() || undefined;
    const headerTenantId = c.req.header("X-Steward-Tenant")?.trim() || undefined;
    if (bodyTenantId && headerTenantId && bodyTenantId !== headerTenantId) {
        return c.json({ ok: false, error: "tenantId and X-Steward-Tenant must match" }, 400);
    }
    const requestedTenantId = bodyTenantId || headerTenantId;
    const methodResponse = await requireTenantLoginMethodAllowed(c, requestedTenantId, "oauth", providerName);
    if (methodResponse)
        return methodResponse;
    try {
        await assertAllowedOAuthRedirectUri(body.redirectUri, requestedTenantId);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Invalid redirectUri",
        }, 400);
    }
    const boundCodeKey = `oauth-code:${body.code}`;
    const boundCode = await getOAuthCodeStore().get(boundCodeKey);
    if (boundCode) {
        let payload;
        try {
            payload = JSON.parse(boundCode);
        }
        catch {
            return c.json({ ok: false, error: "Malformed OAuth code payload" }, 401);
        }
        if (Date.now() > payload.expiresAt) {
            return c.json({ ok: false, error: "OAuth code expired" }, 401);
        }
        if (payload.redirectUri !== body.redirectUri) {
            return c.json({ ok: false, error: "OAuth code redirectUri mismatch" }, 401);
        }
        if ((payload.tenantId ?? null) !== (requestedTenantId ?? null)) {
            return c.json({ ok: false, error: "OAuth code tenant mismatch" }, 401);
        }
        if (payload.providerName && payload.providerName !== providerName) {
            return c.json({ ok: false, error: "OAuth code provider mismatch" }, 401);
        }
        const payloadMethodResponse = await requireTenantLoginMethodAllowed(c, payload.tenantId ?? undefined, "oauth", payload.providerName ?? providerName);
        if (payloadMethodResponse)
            return payloadMethodResponse;
        if (payload.codeChallenge) {
            const verifier = body.codeVerifier?.trim() ?? "";
            if (!verifier || !isValidPkceCodeVerifier(verifier)) {
                return c.json({ ok: false, error: "Invalid code verifier" }, 401);
            }
            const computedChallenge = await pkceChallengeForVerifier(verifier, payload.codeChallengeMethod ?? "S256");
            if (!computedChallenge || computedChallenge !== payload.codeChallenge) {
                return c.json({ ok: false, error: "Code verifier mismatch" }, 401);
            }
        }
        if (!(await lockOAuthCodeRedemption(body.code))) {
            return c.json({ ok: false, error: "OAuth code is already being redeemed" }, 409);
        }
        try {
            const consumed = await getOAuthCodeStore().consume(boundCodeKey);
            if (!consumed || consumed !== boundCode) {
                return c.json({ ok: false, error: "Invalid or already-used code" }, 401);
            }
        }
        finally {
            await releaseOAuthCodeRedemptionLock(body.code);
        }
        return c.json({
            ok: true,
            token: payload.token,
            refreshToken: payload.refreshToken,
            ...(payload.user ? { user: payload.user } : {}),
            expiresIn: payload.expiresIn,
            expiresAt: payload.expiresAt,
        });
    }
    if (!isUnsafeUnboundOAuthProviderCodeExchangeAllowed()) {
        return c.json({
            ok: false,
            error: "Unbound OAuth provider code exchange is disabled; use /auth/oauth/:provider/authorize and /auth/oauth/exchange",
        }, 401);
    }
    let oauthClient;
    try {
        oauthClient = new OAuthClient(getProviderConfig(providerName));
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Provider not configured",
        }, 503);
    }
    let tokenResponse;
    try {
        tokenResponse = await oauthClient.exchangeCode(body.code, body.redirectUri, body.codeVerifier);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Token exchange failed",
        }, 502);
    }
    let providerUser;
    try {
        providerUser = await oauthClient.getUserInfo(tokenResponse.access_token);
    }
    catch (err) {
        return c.json({
            ok: false,
            error: err instanceof Error ? err.message : "Failed to fetch user info",
        }, 502);
    }
    // Twitter and some providers do not return an email address.
    // Generate a synthetic internal email so findOrCreateUser() can still work.
    if (!providerUser.email) {
        if (!providerUser.id) {
            return c.json({ ok: false, error: "Provider returned neither email nor user ID" }, 400);
        }
        providerUser = {
            ...providerUser,
            email: oauthSyntheticEmail(providerName, providerUser.id),
            syntheticEmailGenerated: true,
        };
    }
    const result = await provisionOAuthUser({
        c,
        providerName,
        providerUser,
        tokenResponse,
        tenantId: requestedTenantId,
    });
    if (!result.ok) {
        return c.json({ ok: false, error: result.error }, result.status ?? 500);
    }
    return authExchangeJson(c, result.response);
});
function oauthSyntheticEmail(providerName, providerUserId) {
    return `${providerName}.${providerUserId}@id.steward.internal`;
}
async function provisionOAuthUser(opts) {
    const { c, providerName, providerUser, tokenResponse, tenantId } = opts;
    const db = getDb();
    const email = providerUser.email.toLowerCase().trim();
    const isInternalSyntheticEmail = email.endsWith("@id.steward.internal");
    try {
        if (isInternalSyntheticEmail &&
            providerUser.syntheticEmailGenerated !== true) {
            return {
                ok: false,
                status: 403,
                error: "Provider email uses a reserved internal domain",
            };
        }
        if (!providerUser.syntheticEmailGenerated &&
            providerUser.verified_email !== true) {
            return {
                ok: false,
                status: 403,
                error: "Provider email must be verified before OAuth sign-in is allowed",
            };
        }
        const requestedTenantId = c.req.header("X-Steward-Tenant")?.trim() || tenantId?.trim();
        const [existingUser] = await db
            .select()
            .from(users)
            .where(eq(users.email, email));
        let resolvedTenantId;
        if (existingUser) {
            const tenantResult = await resolveAndValidateTenant(c, existingUser.id, tenantId);
            if (!tenantResult.ok) {
                return {
                    ok: false,
                    status: tenantResult.status,
                    error: tenantResult.error,
                };
            }
            resolvedTenantId = tenantResult.tenantId;
        }
        else if (requestedTenantId) {
            const tenantResult = await validateOidcJitTenant(requestedTenantId);
            if (!tenantResult.ok) {
                return {
                    ok: false,
                    status: tenantResult.status,
                    error: tenantResult.error,
                };
            }
            resolvedTenantId = requestedTenantId;
        }
        if (resolvedTenantId) {
            const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
            const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
            if (emailPolicyError) {
                return {
                    ok: false,
                    status: 400,
                    error: emailPolicyError,
                };
            }
            if (!providerUser.syntheticEmailGenerated &&
                (await isSsoRequiredForEmailDomain(resolvedTenantId, email))) {
                return {
                    ok: false,
                    status: 403,
                    error: "OAuth login is disabled because this email domain requires SSO",
                };
            }
        }
        // 1. Find or create global user record after tenant/policy checks that can
        // be evaluated without a new personal tenant.
        const { user, isNew } = existingUser
            ? { user: existingUser, isNew: false }
            : await findOrCreateUserWithStatus(email);
        if (!resolvedTenantId) {
            const tenantResult = await resolveAndValidateTenant(c, user.id, tenantId);
            if (!tenantResult.ok) {
                return {
                    ok: false,
                    status: tenantResult.status,
                    error: tenantResult.error,
                };
            }
            resolvedTenantId = tenantResult.tenantId;
            const authAbuseConfig = await getTenantAuthAbuseConfig(resolvedTenantId);
            const emailPolicyError = validateEmailAbusePolicy(email, authAbuseConfig);
            if (emailPolicyError) {
                return {
                    ok: false,
                    status: 400,
                    error: emailPolicyError,
                };
            }
            if (!providerUser.syntheticEmailGenerated &&
                (await isSsoRequiredForEmailDomain(resolvedTenantId, email))) {
                return {
                    ok: false,
                    status: 403,
                    error: "OAuth login is disabled because this email domain requires SSO",
                };
            }
        }
        // Update name/image if we have richer data from the provider and the user doesn't have it yet
        const updates = {};
        if (!user.name && providerUser.name)
            updates.name = providerUser.name;
        if (!user.image && providerUser.picture)
            updates.image = providerUser.picture;
        if (!user.emailVerified && providerUser.verified_email)
            updates.emailVerified = true;
        if (Object.keys(updates).length > 0) {
            await db.update(users).set(updates).where(eq(users.id, user.id));
        }
        // 2. Upsert the OAuth account link (provider + providerAccountId → user).
        // Provider tokens are stored encrypted with the deployment master password.
        // If STEWARD_MASTER_PASSWORD changes, operators must run a decrypt +
        // re-encrypt rotation pass before switching the application to the new
        // password, otherwise existing OAuth provider tokens cannot be decrypted.
        // Native ID-token sign-in establishes identity, not Google API access.
        // Omit token fields so an existing Gmail/Calendar grant stays intact.
        const providerCredentials = tokenResponse
            ? {
                ...encryptOAuthProviderTokens(tokenResponse.access_token, tokenResponse.refresh_token ?? null),
                expiresAt: tokenResponse.expires_in
                    ? Math.floor(Date.now() / 1000) + tokenResponse.expires_in
                    : null,
            }
            : {};
        const [insertedAccount] = await db
            .insert(accounts)
            .values({
            userId: user.id,
            provider: providerName,
            providerAccountId: providerUser.id,
            ...providerCredentials,
        })
            .onConflictDoNothing({
            target: [accounts.provider, accounts.providerAccountId],
        })
            .returning({ id: accounts.id });
        if (!insertedAccount) {
            const [currentAccount] = await db
                .select({ id: accounts.id, userId: accounts.userId })
                .from(accounts)
                .where(and(eq(accounts.provider, providerName), eq(accounts.providerAccountId, providerUser.id)));
            if (!currentAccount || currentAccount.userId !== user.id) {
                return {
                    ok: false,
                    status: 403,
                    error: "OAuth account is already linked to another user",
                };
            }
            if (tokenResponse) {
                const [updatedAccount] = await db
                    .update(accounts)
                    .set({
                    ...providerCredentials,
                })
                    .where(and(eq(accounts.id, currentAccount.id), eq(accounts.userId, user.id)))
                    .returning({ id: accounts.id });
                if (!updatedAccount) {
                    return {
                        ok: false,
                        status: 403,
                        error: "OAuth account ownership changed during sign-in",
                    };
                }
            }
        }
        // 3. Provision personal wallet (idempotent)
        let walletAddress = user.walletAddress;
        try {
            const w = await provisionWalletForUser(user.id, email);
            walletAddress = w.walletAddress;
        }
        catch (err) {
            logger.error({
                details: [
                    `[OAuthAuth:${providerName}] Wallet provision failed`,
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:auth] error");
        }
        // 4. Link user to the already-authorized requesting tenant.
        await ensureUserTenantLink(user.id, resolvedTenantId);
        if (isNew) {
            dispatchUserCreated(resolvedTenantId, user.id, "auth.oauth", {
                provider: providerName,
                hasEmail: true,
            });
        }
        return {
            ok: true,
            response: await buildAuthOrMfaResponse(user.id, resolvedTenantId, walletAddress ?? "", {
                userId: user.id,
                email,
                authMethod: "oauth",
                oauthProviderId: providerName,
            }, { id: user.id, email, walletAddress }, c),
        };
    }
    catch (err) {
        logger.error({
            details: [
                `[OAuthAuth:${providerName}] provisionOAuthUser failed`,
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:auth] error");
        return {
            ok: false,
            error: "Internal server error",
        };
    }
}
/**
 * Build the canonical OAuth callback URL for the given provider.
 * APP_URL is mandatory in production so a forged Host/X-Forwarded-Proto header
 * cannot influence the provider redirect_uri.
 */
function authCallbackBaseUrl(c) {
    const configured = process.env.APP_URL?.trim();
    if (configured)
        return configured.replace(/\/$/, "");
    if (process.env.NODE_ENV === "production") {
        throw new Error("APP_URL is required for OAuth/OIDC callback URLs in production");
    }
    return `${c.req.header("x-forwarded-proto") ?? "https"}://${c.req.header("host") ?? "localhost"}`;
}
function buildOAuthCallbackUrl(c, providerName) {
    const appUrl = authCallbackBaseUrl(c);
    return `${appUrl}/auth/oauth/${encodeURIComponent(providerName)}/callback`;
}
function buildOidcCallbackUrl(c, providerId) {
    const appUrl = authCallbackBaseUrl(c);
    return `${appUrl}/auth/oidc/${encodeURIComponent(providerId)}/callback`;
}
function randomBase64Url(byteLength) {
    const bytes = new Uint8Array(byteLength);
    crypto.getRandomValues(bytes);
    return uint8ArrayToBase64url(bytes);
}
const OIDC_TOKEN_EXCHANGE_TIMEOUT_MS = 10_000;
const OIDC_TOKEN_EXCHANGE_MAX_BYTES = 64 * 1024;
async function postPublicOidcTokenEndpoint(tokenUrl, body) {
    const url = assertPublicHttpsEndpoint(tokenUrl, "OIDC token endpoint");
    assertPinnedDnsTransportSupported("OIDC token endpoint");
    const bodyText = body.toString();
    if (new TextEncoder().encode(bodyText).length > 16 * 1024) {
        throw new Error("OIDC token endpoint request is too large");
    }
    const response = await fetchPinnedResponse(url, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: bodyText,
    }, {
        lookup: createPublicInternetLookup("OIDC token endpoint"),
        timeoutMs: OIDC_TOKEN_EXCHANGE_TIMEOUT_MS,
        maxBytes: OIDC_TOKEN_EXCHANGE_MAX_BYTES,
        rejectRedirects: true,
    });
    return {
        ok: response.ok,
        status: response.status,
        text: await response.text(),
    };
}
async function exchangeOidcAuthorizationCode(opts) {
    const { provider, tenantId, code, redirectUri, codeVerifier } = opts;
    if (!provider.clientId || !provider.tokenUrl) {
        throw new Error("OIDC provider is not configured for authorization-code login");
    }
    const body = new URLSearchParams({
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
        client_id: provider.clientId,
        code_verifier: codeVerifier,
    });
    if (provider.clientSecretEnv) {
        // Defense in depth: legacy rows may predate the config-time allowlist, so
        // re-enforce the tenant-bound env namespace before reading any secret
        // (SEC-005: a cross-tenant env reference must never reach the exchange).
        if (!isAllowedOidcClientSecretEnvForTenant(provider.clientSecretEnv, tenantId)) {
            throw new Error("OIDC client secret env is outside the allowed tenant namespace");
        }
        const secret = process.env[provider.clientSecretEnv];
        if (!secret)
            throw new Error(`OIDC client secret env ${provider.clientSecretEnv} is not set`);
        body.set("client_secret", secret);
    }
    let response;
    try {
        response = await postPublicOidcTokenEndpoint(provider.tokenUrl, body);
    }
    catch (error) {
        // Keep resolver, TLS, socket, and certificate diagnostics server-side.
        // They may contain configured hostnames or runtime network details and are
        // not useful to an unauthenticated callback client.
        logger.warn({
            details: [
                "[OIDC] Token endpoint request failed",
                redactedThrownDiagnostics(error),
            ],
        }, "[Login:auth] warn");
        throw new Error("OIDC token endpoint request failed");
    }
    const text = response.text;
    let payload;
    try {
        payload = text ? JSON.parse(text) : null;
    }
    catch {
        throw new Error("OIDC token endpoint returned invalid JSON");
    }
    if (!response.ok) {
        // SEC-139: the IdP-supplied `error` string is untrusted text. Do not echo
        // it into logs or the client-facing 502 response.
        const idpError = payload &&
            typeof payload === "object" &&
            "error" in payload &&
            typeof payload.error === "string"
            ? payload.error
            : undefined;
        if (idpError) {
            logger.warn({ details: ["[OIDC] Token endpoint rejected authorization code"] }, "[Login:auth] warn");
        }
        throw new Error("OIDC token endpoint rejected authorization code");
    }
    if (!payload ||
        typeof payload !== "object" ||
        !("id_token" in payload) ||
        typeof payload.id_token !== "string" ||
        payload.id_token.trim() === "") {
        throw new Error("OIDC token endpoint did not return an id_token");
    }
    return payload.id_token.trim();
}
export { auth as authRoutes };
//# sourceMappingURL=auth.js.map