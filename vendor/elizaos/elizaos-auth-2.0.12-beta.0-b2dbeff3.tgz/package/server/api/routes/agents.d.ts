import { type Context } from "hono";
import { agentPolicies } from "../../db/index.js";
import { type AppVariables } from "../services/context.js";
export declare const agentRoutes: any;
/**
 * Exact policy compare-and-swap fence used after authorizing an agent-token
 * tightening. The attribution fields are part of the expected snapshot too:
 * two concurrent requests that produce identical limits but claim different
 * reasons must not both commit against the same audit `before` state.
 */
export declare function buildAgentPolicyCompareAndSwapPredicate(agentId: string, tenantId: string, expected: typeof agentPolicies.$inferSelect): import("drizzle-orm").SQL<unknown> | undefined;
export declare function createAgentBatch(c: Context<{
    Variables: AppVariables;
}>): Promise<Response>;
//# sourceMappingURL=agents.d.ts.map