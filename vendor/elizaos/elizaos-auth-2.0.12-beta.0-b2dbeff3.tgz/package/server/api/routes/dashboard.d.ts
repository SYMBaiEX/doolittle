/**
 * Aggregates wallet activity for the cloud wallet page after tenant and recent
 * MFA authorization. Storage and chain failures propagate to the API boundary.
 */
export declare const dashboardRoutes: any;
//# sourceMappingURL=dashboard.d.ts.map