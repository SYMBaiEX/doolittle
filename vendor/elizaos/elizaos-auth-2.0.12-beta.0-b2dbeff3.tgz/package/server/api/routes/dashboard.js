/**
 * Aggregates wallet activity for the cloud wallet page after tenant and recent
 * MFA authorization. Storage and chain failures propagate to the API boundary.
 */
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { Hono } from "hono";
import { requireLoginValue } from "../../../required.js";
import { approvalQueue, db, ensureAgentForTenant, getPolicySet, getTransactionStats, requireTenantLevel, setNoStoreHeaders, toTxRecord, transactions, vault, } from "../services/context.js";
import { isRecentMfaTimestamp } from "../services/recent-mfa.js";
export const dashboardRoutes = new Hono();
function hasRecentSessionMfa(c, maxAgeMs = 5 * 60_000) {
    return isRecentMfaTimestamp(c.get("sessionMfaVerifiedAt"), maxAgeMs);
}
// ─── GET /dashboard/:agentId — aggregated agent dashboard ─────────────────────
dashboardRoutes.get("/:agentId", async (c) => {
    const tenantId = c.get("tenantId");
    const agentId = c.req.param("agentId");
    if (!requireTenantLevel(c)) {
        return c.json({ ok: false, error: "Tenant-level auth required" }, 403);
    }
    if (!hasRecentSessionMfa(c)) {
        return c.json({ ok: false, error: "Dashboard data requires recent MFA verification" }, 403);
    }
    setNoStoreHeaders(c);
    // Get agent identity
    const agent = await ensureAgentForTenant(tenantId, agentId);
    if (!agent) {
        return c.json({ ok: false, error: "Agent not found" }, 404);
    }
    // Run queries in parallel
    const [policyRules, txStats, recentTxRows, pendingApprovalsResult, balanceResult,] = await Promise.all([
        // Policies
        getPolicySet(tenantId, agentId),
        // Spend stats
        getTransactionStats(agentId),
        // Recent transactions (last 5)
        db
            .select()
            .from(transactions)
            .where(eq(transactions.agentId, agentId))
            .orderBy(desc(transactions.createdAt))
            .limit(5),
        // Pending approvals count
        db
            .select({ count: sql `count(*)` })
            .from(approvalQueue)
            .where(and(eq(approvalQueue.agentId, agentId), eq(approvalQueue.status, "pending"))),
        // Balance — try to get from vault
        vault.getBalance(tenantId, agentId),
    ]);
    // Get monthly spend
    const oneMonthAgo = new Date(Date.now() - 30 * 86400_000);
    const [monthlyStats] = await db
        .select({
        spentThisMonth: sql `coalesce(sum((${transactions.value})::numeric), 0)::text`,
    })
        .from(transactions)
        .where(and(eq(transactions.agentId, agentId), gte(transactions.createdAt, oneMonthAgo), sql `${transactions.status} in ('signed', 'broadcast', 'confirmed')`));
    const spentToday = txStats.spentToday.toString();
    const spentThisWeek = txStats.spentThisWeek.toString();
    const spentThisMonth = requireLoginValue(monthlyStats, "monthly transaction aggregate").spentThisMonth;
    const formatWei = (wei) => {
        const n = Number(BigInt(wei)) / 1e18;
        return n.toFixed(6);
    };
    const dashboard = {
        agent,
        balances: {
            evm: {
                native: balanceResult.native.toString(),
                nativeFormatted: balanceResult.nativeFormatted,
                chainId: balanceResult.chainId,
                symbol: balanceResult.symbol,
            },
        },
        spend: {
            today: spentToday,
            thisWeek: spentThisWeek,
            thisMonth: spentThisMonth,
            todayFormatted: formatWei(spentToday),
            thisWeekFormatted: formatWei(spentThisWeek),
            thisMonthFormatted: formatWei(spentThisMonth),
        },
        policies: policyRules,
        pendingApprovals: Number(requireLoginValue(pendingApprovalsResult[0], "pending approval aggregate")
            .count),
        recentTransactions: recentTxRows.map(toTxRecord),
    };
    return c.json({
        ok: true,
        data: dashboard,
    });
});
//# sourceMappingURL=dashboard.js.map