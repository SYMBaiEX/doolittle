export declare const tenantConfigRoutes: any;
//# sourceMappingURL=tenant-config.d.ts.map