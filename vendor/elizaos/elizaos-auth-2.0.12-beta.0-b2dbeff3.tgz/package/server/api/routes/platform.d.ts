import { type Context } from "hono";
import { type AppVariables } from "../services/context.js";
declare const platform: any;
export declare function bindPlatformTenantDatabase(c: Context<{
    Variables: AppVariables;
}>, next: () => Promise<void>): Promise<unknown>;
export { platform as platformRoutes };
//# sourceMappingURL=platform.d.ts.map