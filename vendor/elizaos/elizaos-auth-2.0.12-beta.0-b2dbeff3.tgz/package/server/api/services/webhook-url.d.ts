export declare function validateWebhookUrl(url: string): string | null;
export type DnsAnswer = {
    address: string;
    family: number;
};
export type DnsResolver = (hostname: string) => Promise<DnsAnswer[]>;
/**
 * SEC-017: `validateWebhookUrl` only inspects the hostname STRING, so a name
 * like `169.254.169.254.nip.io` (public DNS → link-local) or a DNS rebinding
 * (public A record at config time, private at fetch time) passes it. This
 * async variant additionally resolves the hostname and rejects when ANY
 * answer is a non-public address, failing closed on resolution errors. Use it
 * at registration time AND at delivery time (fresh answers close the
 * config→fetch rebinding window). The resolver is injectable for tests.
 */
export declare function validateWebhookUrlResolved(url: string, resolver?: DnsResolver): Promise<string | null>;
//# sourceMappingURL=webhook-url.d.ts.map