import { buildPhoneAuthProvidersFromEnvironment } from "../../auth/phone-provider.js";
export { buildTwilioVerifyProviderFromEnvironment } from "../../auth/phone-provider.js";
/** Owns login stores and configuration-dependent providers across runtime restarts. */
import { randomBytes } from "node:crypto";
import { ElizaError, logger } from "@elizaos/core";
import { sql } from "drizzle-orm";
import { ACCESS_TOKEN_EXPIRY, buildBackend, ChallengeStore, EmailAuth, hashSha256Hex, isDevSecretAllowed, isSmsDestinationAllowed, MemoryBackend, MockEmailProvider, magicLinkTemplateValues, otpTemplateValues, PasskeyAuth, PhoneAuth, ResendProvider, renderCustomTemplate, SmsChallengeInProgressError, SmsDestinationNotAllowedError, SmsSendBudgetExceededError, SmsVerificationNotAttemptedError, signAccessToken, smsSendGlobalMaxPerHour, TokenStore, } from "../../auth/index.js";
import { revocationStore } from "../../auth/revocation.js";
import { getDb, } from "../../db/index.js";
import { runtimeEnvironmentValue } from "../../shared/runtime-env.js";
import { KeyStore } from "../../wallet/index.js";
import { defaultAuthTenantId } from "../services/default-auth-tenant.js";
import { checkGlobalAuthBudget } from "./auth-rate-limit.js";
export const SMS_VERIFY_MAX_FAILED_ATTEMPTS = 5;
const SMS_VERIFY_FAILED_ATTEMPT_TTL_MS = 10 * 60 * 1000;
function smsVerifyAttemptKey(phone, purpose) {
    return `sms-verify-attempts:${hashSha256Hex(`${purpose}:${phone}`)}`;
}
export function smsVerifyAttemptSlotKey(phone, purpose, slot) {
    return `${smsVerifyAttemptKey(phone, purpose)}:${slot}`;
}
/**
 * Atomically reserve one of the five verification-attempt slots. Using
 * set-if-absent slots keeps the limit correct under concurrent requests on
 * every shipped backend without relying on a read-then-write counter.
 */
export async function claimSmsVerifyAttempt(phone, purpose) {
    for (let slot = 1; slot <= SMS_VERIFY_MAX_FAILED_ATTEMPTS; slot++) {
        const key = smsVerifyAttemptSlotKey(phone, purpose, slot);
        const token = `sms-verify-attempt:${randomBytes(16).toString("hex")}`;
        if (await getMfaBackend().setIfNotExists(key, token, SMS_VERIFY_FAILED_ATTEMPT_TTL_MS)) {
            return { key, token };
        }
    }
    return null;
}
/** Release only the exact slot generation claimed by this request. */
async function releaseSmsVerifyAttempt(claim) {
    try {
        return await getMfaBackend().compareDelete(claim.key, claim.token);
    }
    catch {
        // Rollback is best-effort and generation-exact. A storage outage keeps the
        // slot consumed (fail closed) without replacing the original provider error.
        return false;
    }
}
/**
 * Roll back claim-first accounting only when no provider check could have run.
 * Timeout/5xx/malformed outcomes retain the slot because the remote service may
 * already have evaluated the guess.
 */
export async function releaseUnattemptedSmsVerifyClaim(claim, error) {
    if (!(error instanceof SmsChallengeInProgressError) &&
        !(error instanceof SmsVerificationNotAttemptedError)) {
        return false;
    }
    return releaseSmsVerifyAttempt(claim);
}
export async function clearSmsVerifyFailures(phone, purpose) {
    await Promise.all(Array.from({ length: SMS_VERIFY_MAX_FAILED_ATTEMPTS }, (_, index) => getMfaBackend().delete(smsVerifyAttemptSlotKey(phone, purpose, index + 1))));
}
export function bootstrapRows(result) {
    return (Array.isArray(result)
        ? result
        : (result?.rows ?? []));
}
export async function authTenantConfigSubject(tenantId) {
    const result = await getDb().execute(sql `SELECT * FROM steward_bootstrap.auth_tenant_config_subject(${tenantId})`);
    return bootstrapRows(result)[0] ?? null;
}
export async function authAppClientSubjects(tenantId) {
    const result = await getDb().execute(sql `SELECT * FROM steward_bootstrap.auth_app_clients_subject(${tenantId})`);
    return bootstrapRows(result);
}
const LOGIN_METHOD_NAMES = new Set([
    "passkey",
    "email",
    "sms",
    "whatsapp",
    "totp",
    "siwe",
    "siws",
    "telegram",
    "farcaster",
    "oauth",
    "oidc",
]);
export function loginMethodProviderKey(providerId) {
    return providerId?.trim().toLowerCase() ?? "";
}
/**
 * The refusal a tenant's login methods give a sign-in by `method` (through
 * `providerId` for OAuth and OIDC), or null when the sign-in is allowed.
 */
export function loginMethodRefusal(loginMethods, method, providerId) {
    if (!loginMethods)
        return null;
    if (method === "oauth" || method === "oidc") {
        const disabled = loginMethods[method]?.[loginMethodProviderKey(providerId)] === false;
        if (!disabled)
            return null;
        return `${method === "oauth" ? "OAuth" : "OIDC"} login is disabled for this tenant`;
    }
    return loginMethods[method] === false
        ? `${method} login is disabled for this tenant`
        : null;
}
/**
 * A switch into another tenant is a sign-in to it, so the target tenant's
 * login methods apply to the method (and provider) recorded on the session.
 * Returns the refusal, or null when the switch is allowed.
 */
export async function tenantSwitchLoginRefusal(tenantId, claims) {
    const method = claims.authMethod;
    if (typeof method !== "string" || !LOGIN_METHOD_NAMES.has(method)) {
        return null;
    }
    const providerId = method === "oidc"
        ? claims.oidcProviderId
        : method === "oauth"
            ? claims.oauthProviderId
            : undefined;
    return loginMethodRefusal((await authTenantConfigSubject(tenantId))?.auth_abuse_config?.loginMethods, method, typeof providerId === "string" ? providerId : undefined);
}
export async function createSessionToken(address, tenantId, extra, expiresIn = ACCESS_TOKEN_EXPIRY) {
    if (typeof extra?.userId === "string") {
        const cutoff = await revocationStore.getUserRevokedBefore(extra.userId);
        if (cutoff !== null && Math.floor(Date.now() / 1000) <= cutoff) {
            // JWT timestamps have second precision. A successful sign-in immediately
            // after enrollment must not mint another token at the revoked timestamp.
            // Unlink deliberately places its cutoff one second ahead, so allow that
            // existing fence as well, with a bounded wait of at most two seconds.
            // Never future-date it or weaken the inclusive revocation comparison.
            const delay = (cutoff + 1) * 1000 - Date.now();
            if (delay > 2000) {
                throw new ElizaError("Session clock is behind the revocation timestamp", {
                    code: "LOGIN_SESSION_CLOCK_BEHIND",
                });
            }
            await new Promise((resolve) => setTimeout(resolve, Math.max(0, delay) + 1));
            if (Math.floor(Date.now() / 1000) <= cutoff) {
                throw new ElizaError("Session clock did not advance past revocation", {
                    code: "LOGIN_SESSION_CLOCK_BEHIND",
                });
            }
        }
    }
    return signAccessToken({ address, tenantId, ...extra }, expiresIn);
}
let _nonceBackend = null;
export function getNonceBackend() {
    if (_nonceBackend)
        return _nonceBackend;
    // Lazily fall back to a fresh in-memory backend if initAuthStores() hasn't
    // been called yet (e.g. tests or Workers cold-boot before middleware runs).
    // initAuthStores() will replace this with a Redis or Postgres-backed one.
    // `MemoryBackend` is imported at the top of this ESM module; a bare `require`
    // is not defined under Node, so the fallback threw before it could build one.
    _nonceBackend = new MemoryBackend();
    return _nonceBackend;
}
// ─── PasskeyAuth singleton ────────────────────────────────────────────────────
// ─── Store backend initialization ────────────────────────────────────────────
let _challengeStore = null;
let _tokenStore = null;
let _oauthCodeStore = null;
let _mfaBackend = null;
let _importSessionBackend = null;
let _authStoreSources = {
    challenge: "memory",
    token: "memory",
    siweNonce: "memory",
    mfa: "memory",
    importSession: "memory",
};
let _phoneAuth = null;
/**
 * One-time OAuth nonce-exchange codes (response_type=code) live for 60s —
 * long enough for the user's browser to redirect back and the caller's
 * backend to POST the code to /oauth/exchange, short enough that a captured
 * code in an access log or Referer leak is useless by the time anyone reads
 * it. Codes are single-use (consume() deletes on first read).
 */
export const OAUTH_CODE_TTL_MS = 60 * 1000;
/**
 * Initialize auth token/challenge stores with the best available backend.
 * Call this during server startup AFTER initRedis() has been called.
 *
 * @param usePostgres  Pass true if the DB connection is known to be available.
 */
export async function initAuthStores(usePostgres = false) {
    releaseAuthStores();
    const { getRedisClient } = await import("../middleware/redis.js");
    const redisClient = getRedisClient();
    const [{ backend: challengeBackend, source: challengeSource }, { backend: tokenBackend, source: tokenSource }, { backend: nonceBackend, source: nonceSource }, { backend: mfaBackend, source: mfaSource }, { backend: importSessionBackend, source: importSessionSource },] = await Promise.all([
        buildBackend("challenge", redisClient, usePostgres),
        buildBackend("token", redisClient, usePostgres),
        buildBackend("siwe-nonce", redisClient, usePostgres),
        buildBackend("mfa", redisClient, usePostgres),
        buildBackend("import-session", redisClient, usePostgres),
    ]);
    logger.info({
        details: [
            `[steward:auth] challenge store: ${challengeSource}, token store: ${tokenSource}, ` +
                `siwe-nonce store: ${nonceSource}, mfa store: ${mfaSource}, ` +
                `import-session store: ${importSessionSource}`,
        ],
    }, "[Login:auth] info");
    _challengeStore = new ChallengeStore({ backend: challengeBackend });
    _tokenStore = new TokenStore({ backend: tokenBackend });
    _nonceBackend = nonceBackend;
    _mfaBackend = mfaBackend;
    _authStoreSources = {
        challenge: challengeSource,
        token: tokenSource,
        siweNonce: nonceSource,
        mfa: mfaSource,
        importSession: importSessionSource,
    };
    // Reuse the challenge backend (Redis when available) for OAuth nonce codes
    // so they survive worker restarts and round-robin between isolates. The
    // 60s TTL is enforced at write time by ChallengeStore.
    _oauthCodeStore = new ChallengeStore({
        backend: challengeBackend,
        ttlMs: OAUTH_CODE_TTL_MS,
    });
    // Verified-email grants share the challenge backend (Redis-backed in prod)
    // so an OTP verified on one worker can register a passkey on another.
    _emailGrantStore = new ChallengeStore({
        backend: challengeBackend,
        ttlMs: EMAIL_GRANT_TTL_MS,
    });
    _importSessionBackend = importSessionBackend;
    const { initUserLinkChallengeStores } = await import("../services/account-link-stores.js");
    initUserLinkChallengeStores(challengeBackend);
    // Reset singletons so they pick up the new stores on next use
    _passkeyAuth = null;
    _phoneAuth = null;
    _passkeyAuthByOrigin.clear();
    _emailAuthByTenant.clear();
}
export function getChallengeStore() {
    _challengeStore ??= new ChallengeStore();
    return _challengeStore;
}
export function getOAuthCodeStore() {
    _oauthCodeStore ??= new ChallengeStore({ ttlMs: OAUTH_CODE_TTL_MS });
    return _oauthCodeStore;
}
// ── Verified-email grants (Privy-style OTP signup) ──────────────────────────
//
// POST /email/otp/verify exchanges a correct 6-digit code for a short-lived,
// single-use grant proving ownership of {email, tenantId}. The passkey
// register endpoints accept this grant in place of a session so a BRAND-NEW
// user can go email -> code -> Touch ID without ever holding a session,
// while keeping unverified registration (account pre-hijack) impossible.
export const EMAIL_GRANT_TTL_MS = 5 * 60 * 1000;
let _emailGrantStore = null;
export function getEmailGrantStore() {
    _emailGrantStore ??= new ChallengeStore({ ttlMs: EMAIL_GRANT_TTL_MS });
    return _emailGrantStore;
}
export function emailGrantKey(grant) {
    return `email-otp-grant:${hashSha256Hex(grant)}`;
}
/**
 * Test-only seam for exercising verified-email enrollment routes without
 * sending or scraping an OTP. Production grants are still issued exclusively
 * by /email/otp/verify.
 */
export async function _seedEmailGrantForTests(grant, email, tenantId, scope = "tenant") {
    await getEmailGrantStore().set(emailGrantKey(grant), JSON.stringify({ email: email.toLowerCase().trim(), tenantId, scope }));
}
function getTokenStore() {
    _tokenStore ??= new TokenStore();
    return _tokenStore;
}
export function getMfaBackend() {
    if (_mfaBackend)
        return _mfaBackend;
    _mfaBackend = new MemoryBackend();
    return _mfaBackend;
}
export function getImportSessionBackend() {
    if (_importSessionBackend)
        return _importSessionBackend;
    _importSessionBackend = new MemoryBackend();
    return _importSessionBackend;
}
function getAuthStoreSources() {
    return { ..._authStoreSources };
}
/**
 * Refuse ephemeral auth state in production and Workers deployments. Losing or
 * partitioning challenge, token, nonce, MFA, or import-session state across
 * processes can break single-use guarantees. A single-instance deployment may
 * explicitly acknowledge that trade-off, but it must never happen silently.
 */
export function assertAuthStoresAreSafe(sources = getAuthStoreSources()) {
    const requiresDurableStores = process.env.NODE_ENV === "production" ||
        process.env.STEWARD_RUNTIME === "workers";
    if (!requiresDurableStores ||
        process.env.STEWARD_ALLOW_MEMORY_AUTH_STORES === "true")
        return;
    const memoryStores = Object.entries(sources)
        .filter(([, source]) => source === "memory")
        .map(([name]) => name);
    if (memoryStores.length > 0) {
        throw new Error(`Durable auth storage is required; memory-backed stores: ${memoryStores.join(", ")}. ` +
            "Configure Redis/Postgres or explicitly set STEWARD_ALLOW_MEMORY_AUTH_STORES=true " +
            "for a single-instance deployment.");
    }
}
export function encryptImportSessionJson(value) {
    return JSON.stringify(getOAuthKeyStore().encrypt(JSON.stringify(value)));
}
export function decryptImportSessionJson(value) {
    const encrypted = JSON.parse(value);
    return JSON.parse(getOAuthKeyStore().decrypt(encrypted));
}
let _passkeyAuth = null;
const _passkeyAuthByOrigin = new Map();
/**
 * Get PasskeyAuth for a specific origin (multi-tenant passkey support).
 * Derives rpID from the Origin header so passkeys work on waifu.fun,
 * elizacloud.ai, or any other tenant domain.
 *
 * Allowed origins: PASSKEY_ALLOWED_ORIGINS env (comma-separated),
 * defaults to PASSKEY_ORIGIN.
 *
 * rpID resolution rule (apex-folding):
 *   When the request hostname is a strict subdomain of an allowed origin's
 *   hostname (e.g. request `www.waifu.fun`, allowed `https://waifu.fun`),
 *   we use the SHORTER allowed hostname as rpID. This keeps a single
 *   credential valid across apex + www and avoids breaking users who
 *   registered under one form when their canonical host changes (e.g.
 *   apex 307s to www, or vice versa).
 *
 *   WebAuthn allows rpID to be any registrable suffix of the request
 *   origin hostname, and the resulting credential is then scoped to
 *   apex + all subdomains.
 */
function resolveRpID(requestHostname, allowedOrigins, fallback) {
    let best = requestHostname;
    for (const o of allowedOrigins) {
        let host;
        try {
            host = new URL(o).hostname;
        }
        catch {
            continue;
        }
        if (host === requestHostname) {
            // Exact match. Prefer shortest match seen so far so apex wins over www.
            if (host.length < best.length || best === requestHostname)
                best = host;
        }
        else if (requestHostname.endsWith(`.${host}`) &&
            // shortest match wins
            (best === requestHostname || host.length < best.length)) {
            best = host;
        }
    }
    if (!best)
        return fallback;
    return best;
}
export function getPasskeyAuth(requestOrigin) {
    const defaultRpID = process.env.PASSKEY_RP_ID || "eliza.app";
    const defaultOrigin = process.env.PASSKEY_ORIGIN || "https://eliza.app";
    const rpName = process.env.PASSKEY_RP_NAME || "elizaOS";
    // If no origin provided, use the default singleton
    if (!requestOrigin) {
        if (!_passkeyAuth) {
            const origins = (process.env.PASSKEY_ALLOWED_ORIGINS || defaultOrigin)
                .split(",")
                .map((o) => o.trim())
                .filter(Boolean);
            _passkeyAuth = new PasskeyAuth({
                rpName,
                rpID: defaultRpID,
                origin: origins.length > 1 ? origins : defaultOrigin,
                challengeStore: getChallengeStore(),
            });
        }
        return _passkeyAuth;
    }
    // Parse origin to get hostname
    let requestHostname;
    try {
        requestHostname = new URL(requestOrigin).hostname;
    }
    catch {
        return getPasskeyAuth(); // invalid origin, fall back to default
    }
    // Validate against allowed origins
    const allowed = (process.env.PASSKEY_ALLOWED_ORIGINS || defaultOrigin)
        .split(",")
        .map((o) => o.trim())
        .filter(Boolean);
    if (!allowed.includes(requestOrigin) && requestHostname !== defaultRpID) {
        return getPasskeyAuth(); // not in allowed list, use default
    }
    // Apex-fold: if the request hostname is a subdomain of any allowed origin,
    // use the allowed origin's apex hostname as rpID so the credential is
    // shared across apex + all subdomains.
    const rpID = resolveRpID(requestHostname, allowed, defaultRpID);
    // Cache per rpID
    const cached = _passkeyAuthByOrigin.get(rpID);
    if (cached)
        return cached;
    // Origin list passed to PasskeyAuth covers all variants the browser may
    // present (apex + www) so SimpleWebAuthn accepts assertions from either.
    const acceptedOrigins = allowed.length > 0 ? allowed : [requestOrigin];
    const auth = new PasskeyAuth({
        rpName,
        rpID,
        origin: acceptedOrigins,
        challengeStore: getChallengeStore(),
    });
    _passkeyAuthByOrigin.set(rpID, auth);
    return auth;
}
// ─── EmailAuth cache ──────────────────────────────────────────────────────────
const _emailAuthByTenant = new Map();
let _emailKeyStore = null;
let _oauthKeyStore = null;
function getEmailKeyStore() {
    if (_emailKeyStore)
        return _emailKeyStore;
    const masterPassword = process.env.STEWARD_MASTER_PASSWORD;
    if (!masterPassword) {
        if (!isDevSecretAllowed()) {
            throw new Error("STEWARD_MASTER_PASSWORD is required. For local development only, set STEWARD_ALLOW_DEV_SECRETS=true to use the insecure dev key.");
        }
        _emailKeyStore = new KeyStore("dev-secret");
        return _emailKeyStore;
    }
    _emailKeyStore = new KeyStore(masterPassword);
    return _emailKeyStore;
}
export function getOAuthKeyStore() {
    if (_oauthKeyStore)
        return _oauthKeyStore;
    const masterPassword = process.env.STEWARD_MASTER_PASSWORD;
    if (!masterPassword) {
        if (!isDevSecretAllowed()) {
            throw new Error("STEWARD_MASTER_PASSWORD is required to encrypt OAuth provider tokens. For local development only, set STEWARD_ALLOW_DEV_SECRETS=true to use the insecure dev key.");
        }
        _oauthKeyStore = new KeyStore("dev-secret");
        return _oauthKeyStore;
    }
    _oauthKeyStore = new KeyStore(masterPassword);
    return _oauthKeyStore;
}
export function encryptOAuthProviderTokens(accessToken, refreshToken) {
    const keyStore = getOAuthKeyStore();
    const encryptedAccessToken = keyStore.encrypt(accessToken);
    const encryptedRefreshToken = refreshToken
        ? keyStore.encrypt(refreshToken)
        : null;
    return {
        accessTokenEncrypted: encryptedAccessToken.ciphertext,
        accessTokenIv: encryptedAccessToken.iv,
        accessTokenTag: encryptedAccessToken.tag,
        accessTokenSalt: encryptedAccessToken.salt,
        refreshTokenEncrypted: encryptedRefreshToken?.ciphertext ?? null,
        refreshTokenIv: encryptedRefreshToken?.iv ?? null,
        refreshTokenTag: encryptedRefreshToken?.tag ?? null,
        refreshTokenSalt: encryptedRefreshToken?.salt ?? null,
    };
}
export function isMockEmailEnabled() {
    if (process.env.EMAIL_PROVIDER === "mock" &&
        process.env.NODE_ENV === "production") {
        throw new Error("EMAIL_PROVIDER=mock is forbidden in production. Unset EMAIL_PROVIDER or set RESEND_API_KEY.");
    }
    return (process.env.EMAIL_PROVIDER === "mock" &&
        process.env.NODE_ENV !== "production");
}
/**
 * Build EmailAuth renderer overrides from deployer-supplied raw templates
 * (tenant_configs.email_config.templates). Branded markup is instance CONFIG,
 * not repo code: when a tenant carries its own subject/text/html we render it
 * with {{placeholder}} substitution; otherwise fall through to the built-in
 * templateId resolution.
 */
function buildTemplateRenderers(templates) {
    if (!templates)
        return {};
    const magicLink = templates.magicLink;
    const otp = templates.otp;
    return {
        ...(magicLink
            ? {
                templateRenderer: (_templateId, data) => renderCustomTemplate(magicLink, magicLinkTemplateValues(data)),
            }
            : {}),
        ...(otp
            ? {
                otpTemplateRenderer: (_templateId, data) => renderCustomTemplate(otp, otpTemplateValues(data)),
            }
            : {}),
    };
}
function globalEmailMagicLinkBaseUrl() {
    const emailBaseUrl = runtimeEnvironmentValue("EMAIL_MAGIC_LINK_BASE_URL")?.trim();
    if (emailBaseUrl) {
        const parsed = new URL(emailBaseUrl);
        const normalized = emailBaseUrl.replace(/\/$/, "");
        if (!["http:", "https:"].includes(parsed.protocol) ||
            parsed.username ||
            parsed.password ||
            parsed.search ||
            parsed.hash ||
            parsed.origin !== normalized) {
            throw new Error("EMAIL_MAGIC_LINK_BASE_URL must be a credential-free HTTP(S) origin");
        }
        return parsed.origin;
    }
    return (runtimeEnvironmentValue("APP_URL")?.trim().replace(/\/$/, "") ||
        "https://eliza.app");
}
function globalEmailMagicLinkCallbackPath() {
    const callbackPath = runtimeEnvironmentValue("EMAIL_MAGIC_LINK_CALLBACK_PATH")?.trim();
    if (!callbackPath)
        return undefined;
    if (!callbackPath.startsWith("/") || callbackPath.startsWith("//")) {
        throw new Error("EMAIL_MAGIC_LINK_CALLBACK_PATH must be a root-relative path");
    }
    return callbackPath;
}
function globalEmailBrandName() {
    const brandName = runtimeEnvironmentValue("EMAIL_BRAND_NAME")?.trim();
    if (!brandName)
        return undefined;
    if (brandName.length > 100 || /[\r\n]/.test(brandName)) {
        throw new Error("EMAIL_BRAND_NAME must be a single-line string of at most 100 characters");
    }
    return brandName;
}
function buildGlobalEmailAuth(overrides) {
    const resendKey = process.env.RESEND_API_KEY;
    // Mock takes precedence in non-production for deterministic e2e testing.
    const provider = isMockEmailEnabled()
        ? new MockEmailProvider()
        : resendKey
            ? new ResendProvider({
                apiKey: resendKey,
                from: process.env.EMAIL_FROM || "login@eliza.app",
            })
            : undefined;
    return new EmailAuth({
        from: process.env.EMAIL_FROM || "login@eliza.app",
        baseUrl: overrides?.baseUrl?.replace(/\/$/, "") || globalEmailMagicLinkBaseUrl(),
        callbackPath: overrides?.callbackPath || globalEmailMagicLinkCallbackPath(),
        provider,
        tokenStore: getTokenStore(),
        templateId: overrides?.templateId,
        brandName: overrides?.brandName || globalEmailBrandName(),
        subjectOverride: overrides?.subjectOverride,
        replyTo: overrides?.replyTo,
        ...buildTemplateRenderers(overrides?.templates),
    });
}
function parseEncryptedEmailApiKey(value) {
    const parsed = JSON.parse(value);
    if (!parsed.ciphertext || !parsed.iv || !parsed.tag || !parsed.salt) {
        throw new Error("Invalid tenant email config encryption payload");
    }
    return {
        ciphertext: parsed.ciphertext,
        iv: parsed.iv,
        tag: parsed.tag,
        salt: parsed.salt,
    };
}
async function loadTenantEmailConfig(tenantId) {
    return (await authTenantConfigSubject(tenantId))?.email_config ?? null;
}
async function createEmailAuthForTenant(tenantId) {
    const emailConfig = await loadTenantEmailConfig(tenantId);
    // Per-tenant magic-link override: when a tenant supplies its own
    // `magicLinkBaseUrl` we build the link against that origin so the click
    // lands on the tenant's app (e.g. https://waifu.fun/auth/email/verify)
    // instead of Steward's built-in callback (which redirects to
    // EMAIL_AUTH_REDIRECT_BASE_URL and is hard-defaulted to elizacloud.ai).
    const magicLinkBaseUrl = emailConfig?.magicLinkBaseUrl;
    const callbackPath = magicLinkBaseUrl
        ? emailConfig?.magicLinkCallbackPath || "/auth/email/verify"
        : undefined; // let EmailAuth fall through to its DEFAULT_CALLBACK
    if (!emailConfig?.apiKeyEncrypted) {
        // No per-tenant Resend config (or only magic-link override) — use the
        // global env-backed provider but still honor the per-tenant magic-link
        // AND template overrides if present. Without the template pass-through a
        // tenant that sets only `templateId` (no own Resend key) silently got the
        // Steward-branded default email instead of its configured branding.
        return buildGlobalEmailAuth({
            baseUrl: magicLinkBaseUrl,
            callbackPath,
            templateId: emailConfig?.templateId,
            brandName: emailConfig?.brandName,
            subjectOverride: emailConfig?.subjectOverride,
            replyTo: emailConfig?.replyTo,
            templates: emailConfig?.templates,
        });
    }
    // We've already returned via buildGlobalEmailAuth above when apiKeyEncrypted
    // is missing, so it's safe to assume `emailConfig.from + apiKeyEncrypted`
    // are both present here.
    const from = emailConfig.from || process.env.EMAIL_FROM || "login@eliza.app";
    const provider = emailConfig.provider === "resend" && emailConfig.apiKeyEncrypted
        ? new ResendProvider({
            apiKey: getEmailKeyStore().decrypt(parseEncryptedEmailApiKey(emailConfig.apiKeyEncrypted)),
            from,
            replyTo: emailConfig.replyTo,
        })
        : undefined;
    const baseUrl = magicLinkBaseUrl?.replace(/\/$/, "") || globalEmailMagicLinkBaseUrl();
    return new EmailAuth({
        from,
        baseUrl,
        callbackPath: callbackPath || globalEmailMagicLinkCallbackPath(),
        provider,
        tokenStore: getTokenStore(),
        templateId: emailConfig.templateId,
        brandName: emailConfig.brandName || globalEmailBrandName(),
        subjectOverride: emailConfig.subjectOverride,
        replyTo: emailConfig.replyTo,
        ...buildTemplateRenderers(emailConfig.templates),
    });
}
export async function getEmailAuthForTenant(tenantId) {
    const cached = _emailAuthByTenant.get(tenantId);
    if (cached)
        return cached;
    const pending = createEmailAuthForTenant(tenantId).catch((error) => {
        _emailAuthByTenant.delete(tenantId);
        throw error;
    });
    _emailAuthByTenant.set(tenantId, pending);
    return pending;
}
export function invalidateEmailAuthForTenant(tenantId) {
    _emailAuthByTenant.delete(tenantId);
}
export function getPhoneAuth() {
    if (_phoneAuth)
        return _phoneAuth;
    const { provider, managedProvider } = buildPhoneAuthProvidersFromEnvironment();
    if (!provider && !managedProvider && process.env.NODE_ENV === "production")
        throw new Error("SMS provider not configured");
    _phoneAuth = new PhoneAuth({
        provider,
        managedProvider,
        tokenStore: new TokenStore({ backend: getMfaBackend() }),
        sendGuard: guardSmsSend,
    });
    return _phoneAuth;
}
/**
 * SMS pumping guard for every OTP send: a deployment-wide destination policy
 * (default US + Canada) and a deployment-wide hourly ceiling. Per-IP and
 * per-destination limits stay at the routes; pumping rotates both.
 */
async function guardSmsSend(phone) {
    if (!isSmsDestinationAllowed(phone)) {
        logger.warn({
            details: [`[SmsGuard] refused destination prefix ${phone.slice(0, 4)}`],
        }, "[Login:auth] warn");
        throw new SmsDestinationNotAllowedError();
    }
    const max = smsSendGlobalMaxPerHour();
    if (max === 0)
        return;
    const budget = await checkGlobalAuthBudget("sms-send-global", 3_600_000, max);
    if (!budget.allowed) {
        logger.error({
            details: [
                `[SmsGuard] ALERT: deployment-wide SMS budget of ${max}/hour is used up; OTP sends are refused until the window resets`,
            ],
        }, "[Login:auth] error");
        throw new SmsSendBudgetExceededError(budget.retryAfterSecs);
    }
}
const OAUTH_REDIRECT_ALLOWLIST_ENV_KEYS = [
    "STEWARD_OAUTH_ALLOWED_REDIRECTS",
    "STEWARD_OAUTH_REDIRECT_ALLOWLIST",
];
function parseOAuthRedirectAllowlistEnv() {
    const entries = new Set();
    for (const envName of OAUTH_REDIRECT_ALLOWLIST_ENV_KEYS) {
        const raw = process.env[envName];
        if (!raw)
            continue;
        for (const entry of raw.split(",")) {
            const trimmed = entry.trim();
            if (trimmed && trimmed !== "*") {
                entries.add(trimmed);
            }
        }
    }
    return [...entries];
}
function parseOAuthRedirectUri(redirectUri) {
    let redirectUrl;
    try {
        redirectUrl = new URL(redirectUri);
    }
    catch {
        throw new Error("redirect_uri must be a valid absolute URL");
    }
    if (redirectUrl.protocol === "http:") {
        const host = redirectUrl.hostname.toLowerCase();
        const isLoopback = host === "localhost" || host === "127.0.0.1" || host === "::1";
        if (!isLoopback) {
            throw new Error("redirect_uri must use https except for loopback development origins");
        }
    }
    else if (redirectUrl.protocol !== "https:") {
        throw new Error("redirect_uri must use https");
    }
    if (redirectUrl.username || redirectUrl.password) {
        throw new Error("redirect_uri must not contain credentials");
    }
    return redirectUrl;
}
function isOAuthRedirectEntryMatch(redirectUrl, allowedEntry) {
    let allowedUrl;
    try {
        allowedUrl = new URL(allowedEntry);
    }
    catch {
        return false;
    }
    if (allowedUrl.protocol !== "https:" && allowedUrl.protocol !== "http:") {
        return false;
    }
    const isOriginOnly = allowedUrl.pathname === "/" &&
        !allowedUrl.search &&
        !allowedUrl.hash &&
        !allowedUrl.username;
    if (isOriginOnly) {
        return (allowedUrl.origin === redirectUrl.origin &&
            redirectUrl.pathname === "/" &&
            !redirectUrl.search &&
            !redirectUrl.hash);
    }
    return (allowedUrl.origin === redirectUrl.origin &&
        allowedUrl.pathname === redirectUrl.pathname &&
        allowedUrl.search === redirectUrl.search);
}
export function normalizePublicClientId(value) {
    if (typeof value !== "string")
        return undefined;
    const id = value.trim().toLowerCase();
    return /^[a-z0-9][a-z0-9_-]{2,63}$/.test(id) ? id : undefined;
}
async function getAllowedOAuthRedirectEntries(tenantId, clientId) {
    const explicitTenantId = tenantId?.trim() || undefined;
    const resolvedTenantId = explicitTenantId || defaultAuthTenantId();
    const entries = new Set();
    const normalizedClientId = normalizePublicClientId(clientId);
    const appClientRows = await authAppClientSubjects(resolvedTenantId);
    if (normalizedClientId) {
        const client = appClientRows.find((candidate) => candidate.id === normalizedClientId);
        if (client) {
            for (const entry of client.allowed_redirect_urls ?? []) {
                const trimmed = entry.trim();
                if (trimmed && trimmed !== "*")
                    entries.add(trimmed);
            }
        }
        return [...entries];
    }
    const config = await authTenantConfigSubject(resolvedTenantId);
    for (const entry of config?.allowed_redirect_urls ?? []) {
        const trimmed = entry.trim();
        if (trimmed && trimmed !== "*") {
            entries.add(trimmed);
        }
    }
    for (const client of appClientRows) {
        for (const entry of client.allowed_redirect_urls ?? []) {
            const trimmed = entry.trim();
            if (trimmed && trimmed !== "*")
                entries.add(trimmed);
        }
    }
    if (!explicitTenantId) {
        for (const entry of parseOAuthRedirectAllowlistEnv()) {
            entries.add(entry);
        }
    }
    return [...entries];
}
export async function assertAllowedOAuthRedirectUri(redirectUri, tenantId, clientId) {
    const redirectUrl = parseOAuthRedirectUri(redirectUri);
    const allowlist = await getAllowedOAuthRedirectEntries(tenantId, clientId);
    if (allowlist.length === 0) {
        throw new Error("OAuth redirect_uri allowlist is not configured for this tenant. Configure tenant allowedRedirectUrls or STEWARD_OAUTH_ALLOWED_REDIRECTS.");
    }
    if (!allowlist.some((entry) => isOAuthRedirectEntryMatch(redirectUrl, entry))) {
        throw new Error("redirect_uri is not allowed for this tenant");
    }
    return redirectUrl;
}
export { getChallengeStore as getAuthChallengeStore };
/** Release only owned memory; durable challenges remain available after restart. */
export function releaseAuthStores() {
    _authStoreSources = {
        challenge: "memory",
        token: "memory",
        siweNonce: "memory",
        mfa: "memory",
        importSession: "memory",
    };
    for (const store of [
        _challengeStore,
        _tokenStore,
        _oauthCodeStore,
        _emailGrantStore,
    ])
        store?.destroy();
    for (const backend of [_nonceBackend, _mfaBackend, _importSessionBackend]) {
        if (backend instanceof MemoryBackend)
            backend.destroy();
    }
    _challengeStore = null;
    _tokenStore = null;
    _oauthCodeStore = null;
    _emailGrantStore = null;
    _nonceBackend = null;
    _mfaBackend = null;
    _importSessionBackend = null;
    _phoneAuth = null;
    _passkeyAuth = null;
    _emailKeyStore = null;
    _oauthKeyStore = null;
    _passkeyAuthByOrigin.clear();
    _emailAuthByTenant.clear();
}
//# sourceMappingURL=auth-lifecycle.js.map