const PUBLIC_API_ERROR_MESSAGES = {
    resource_already_exists: "Resource already exists",
    resource_not_found: "Resource not found",
    unsupported_chain: "Unsupported chain",
};
/** A typed error whose public text is selected from a closed, stable table. */
export class PublicApiError extends Error {
    code;
    publicMessage;
    constructor(code) {
        const publicMessage = PUBLIC_API_ERROR_MESSAGES[code];
        super(publicMessage);
        this.code = code;
        this.name = "PublicApiError";
        this.publicMessage = publicMessage;
    }
}
export function sanitizePublicError(error) {
    return error instanceof PublicApiError
        ? error.publicMessage
        : "Internal server error";
}
//# sourceMappingURL=public-error.js.map