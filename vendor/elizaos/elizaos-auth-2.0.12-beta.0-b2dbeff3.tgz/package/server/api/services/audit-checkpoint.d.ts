/**
 * Ed25519 audit checkpoint signer.
 *
 * The per-tenant audit chain (services/audit.ts) is tamper-evident but keyed
 * with a SYMMETRIC HMAC secret: only the operator (who holds
 * STEWARD_AUDIT_HMAC_KEY) can verify it. An third-party auditor cannot
 * independently confirm the chain without being handed that secret — which
 * would also let them forge it.
 *
 * A checkpoint fixes this. At bundle time we sign a small, canonical statement
 * about the chain head with an Ed25519 PRIVATE key (STEWARD_AUDIT_SIGNING_KEY)
 * whose PUBLIC key can be published freely. Anyone holding only the public key
 * can verify:
 *   - the operator asserted "at time T, tenant X's chain head was seq=N with
 *     hmac=H, containing `expectedCount` events above `floorSeq`",
 *   - and that assertion has not been altered.
 *
 * Combined with the exported event list (whose linkage an auditor recomputes
 * locally — see scripts/verify-evidence-bundle.mjs), this proves the exported
 * set is exactly the set the operator committed to at signing time.
 *
 * WHAT A CHECKPOINT DOES NOT PROVE: it does not prevent an operator who holds
 * BOTH the HMAC key and the signing key from constructing a self-consistent but
 * fabricated history and then signing it. The Ed25519 signature raises the bar
 * from "trust the operator's secret HMAC" to "trust the operator's published,
 * append-only, third-party-witnessable checkpoints"; anchoring beyond that
 * (third-party timestamping / transparency log) requires a separately trusted
 * witness. The optional RFC 3161 hook anchors the canonical payload digest and
 * keeps that narrower claim explicit.
 *
 * Zero new dependencies: uses node:crypto Ed25519 primitives.
 */
import { type KeyObject } from "node:crypto";
declare function sha256Hex(bytes: Uint8Array): string;
/**
 * The canonical CONTENT fields of one audit event, matching (field-for-field,
 * name-for-name) the encoding that services/audit.ts commits to in the HMAC
 * chain. The offline verifier reproduces this exact shape from the bundle so it
 * can recompute the content digest WITHOUT the HMAC key.
 */
export interface CheckpointEventContent {
    tenantId: string;
    seq: number;
    actorType: string;
    actorId: string | null;
    action: string;
    resourceType: string | null;
    resourceId: string | null;
    metadata: Record<string, unknown>;
    ipAddress: string | null;
    userAgent: string | null;
    requestId: string | null;
    createdAt: string;
}
/** Canonical byte encoding of one event's content. Uses snake_case field names
 * to match the HMAC chain's canonicalization exactly. */
export declare function canonicalEventContentBytes(ev: CheckpointEventContent): Uint8Array;
/**
 * SHA-256 content commitment over an ordered list of events. Computed as a
 * rolling hash: digest_0 = SHA-256("steward-audit-events/v1"); digest_i =
 * SHA-256(digest_{i-1} || SHA-256(canonical_event_i)). Order-sensitive and
 * content-sensitive, so any insertion, removal, reorder, or field mutation
 * changes the result. Returns "" for an empty list. The verifier recomputes
 * this identically from the bundle events.
 */
export declare function eventsContentDigest(events: CheckpointEventContent[]): string;
export { sha256Hex };
/** Canonical checkpoint payload. Field order here is NOT authoritative — the
 * signed bytes come from `canonicalCheckpointBytes`, which sorts keys. */
export interface CheckpointPayload {
    /** Schema version of the checkpoint payload. */
    v: 1;
    /** Tenant whose chain this checkpoint commits to. */
    tenantId: string;
    /** Sequence number of the chain head at checkpoint time. */
    seq: number;
    /** Hex-encoded HMAC of the head event. */
    headHmac: string;
    /** Number of live events at/above `floorSeq` committed by this checkpoint. */
    expectedCount: number;
    /** Retention floor: events at or below this seq have been archived+dropped. */
    floorSeq: number;
    /** ISO-8601 timestamp the checkpoint was produced. */
    timestamp: string;
    /** Software version that produced the checkpoint (provenance breadcrumb). */
    softwareVersion: string;
    /**
     * Hex SHA-256 commitment over the canonical CONTENT of every event in the
     * bundle (not just the chain pointers). Signing this authenticates each
     * exported event's fields to an offline auditor who lacks the HMAC key: any
     * post-export mutation of an event's action/metadata/actor/timestamp/etc.
     * changes this digest and breaks the signature. Empty-string when the bundle
     * carries no events. See `eventsContentDigest`.
     */
    eventsDigest: string;
    /** Seq of the first event committed by `eventsDigest` (0 when none). */
    eventsFromSeq: number;
    /** Seq of the last event committed by `eventsDigest` (0 when none). */
    eventsToSeq: number;
}
export interface SignedCheckpoint {
    payload: CheckpointPayload;
    /** Base64 Ed25519 signature over `canonicalCheckpointBytes(payload)`. */
    signature: string;
    /** SPKI PEM of the Ed25519 public key (safe to publish). */
    publicKey: string;
}
/**
 * Deterministic canonical JSON encoding of a checkpoint payload.
 *
 * Keys are sorted; there is no insignificant whitespace. This is the EXACT byte
 * sequence that gets signed and that the offline verifier must reconstruct. Any
 * change to a field (or key ordering) changes the signed bytes, so a verifier
 * that reconstructs it independently detects any post-signing mutation.
 */
export declare function canonicalCheckpointBytes(payload: CheckpointPayload): Uint8Array;
declare class AuditSigningKeyError extends Error {
    constructor(message: string);
}
export { AuditSigningKeyError };
/**
 * Parse STEWARD_AUDIT_SIGNING_KEY into an Ed25519 private KeyObject. Accepts:
 *   - PKCS#8 PEM ("-----BEGIN PRIVATE KEY-----")
 *   - raw 32-byte seed as hex (64 chars)
 *   - raw 32-byte seed as base64 / base64url
 *
 * Throws AuditSigningKeyError on anything that isn't one of those, or that
 * parses but isn't an Ed25519 key.
 */
export declare function parseSigningKey(raw: string): KeyObject;
/** SPKI PEM of the public half of an Ed25519 private key. */
export declare function publicKeyPem(privateKey: KeyObject): string;
export interface AuditCheckpointSigner {
    sign(payload: CheckpointPayload): SignedCheckpoint;
    readonly publicKeyPem: string;
}
/**
 * Build a signer from an explicit key string. Prefer `getCheckpointSigner`
 * (env-backed, cached) in application code; this exists for tests and for the
 * bundle route to construct a signer from configured env.
 */
export declare function createCheckpointSigner(rawKey: string): AuditCheckpointSigner;
/**
 * Whether an audit signing key is configured. Callers (bundle route) use this
 * to decide between hard-fail (production) and disabled-with-warning (dev).
 */
export declare function isCheckpointSigningConfigured(): boolean;
/**
 * Cached env-backed signer. Throws AuditSigningKeyError if
 * STEWARD_AUDIT_SIGNING_KEY is unset or invalid — callers must gate on
 * `isCheckpointSigningConfigured()` first if they want to handle absence
 * gracefully.
 */
export declare function getCheckpointSigner(): AuditCheckpointSigner;
/** Test hook: drop the cached signer so a changed env var takes effect. */
export declare function resetCheckpointSignerCache(): void;
/**
 * Verify a signed checkpoint with its embedded public key. Used by the online
 * bundle path as a self-check; the authoritative third-party check is the
 * standalone offline verifier.
 */
export declare function verifyCheckpoint(checkpoint: SignedCheckpoint): boolean;
//# sourceMappingURL=audit-checkpoint.d.ts.map