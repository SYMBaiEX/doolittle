import { type AppendRequiredAudit, type AuditEventInput, appendAuditEvent, appendAuditEventWithinTx, getDb, withTenantAuditedTransaction, withTenantAuditQueue, writeAuditEvent } from "../../db/index.js";
import { type CheckpointPayload } from "./audit-checkpoint.js";
import { type AuditCheckpointAnchorProof } from "./audit-checkpoint-anchor.js";
/**
 * The canonicalization contract an offline verifier must reproduce per event.
 * Single source of truth (spec §6.2): the route re-exports this. Bumped only
 * alongside a verifier change.
 */
export declare const BUNDLE_CANONICALIZATION_SPEC: string;
export type { AuditActorType as ActorType } from "../../db/index.js";
/**
 * Minimal read surface a snapshot transaction (or the db) must expose so the
 * The case correlator can run `verifyAuditChain` + `readAuditBundleData` inside
 * ONE coherent snapshot. Both the Drizzle db and a Drizzle tx satisfy this; we
 * alias to the db's own type so the internal `.execute(sql\`...\`)` calls keep
 * their existing typing when an executor is supplied.
 */
export type AuditReadExecutor = Pick<ReturnType<typeof getDb>, "execute">;
/** Build the high-water aggregate read, bounded when doctor supplies maxRows. */
export declare function auditRowAggregateQuery(tenantId: string, genesisSeq: number, maxRows?: number): import("drizzle-orm").SQL<unknown>;
export type { AppendRequiredAudit, AuditEventInput };
export { appendAuditEvent, appendAuditEventWithinTx, withTenantAuditedTransaction, withTenantAuditQueue, writeAuditEvent, };
/**
 * Records best-effort telemetry after an operation has committed, logging failures.
 * Security-sensitive operations must await writeAuditEvent and fail if their
 * durable audit record cannot be written.
 */
export declare function trackAuditEvent(ev: AuditEventInput): Promise<void>;
/**
 * Walk the chain for a tenant and verify every HMAC.
 *
 * Returns `{ valid: true, count }` if the entire range verifies, otherwise
 * `{ valid: false, brokenAt }` pointing to the first row whose digest does
 * not match the expected value computed from its predecessor.
 */
export declare function verifyAuditChain(tenantId: string, opts?: {
    fromSeq?: number;
    toSeq?: number;
    requireHead?: boolean;
    /** Hard cap enforced by the SQL read itself (LIMIT maxRows + 1). */
    maxRows?: number;
    /**
     * Optional read executor (a snapshot transaction) so callers can verify a
     * chain segment WITHIN a single coherent snapshot alongside other reads
     * (§4.1/§4.3 KC06). Defaults to `getDb()`; behavior is otherwise
     * identical. Must expose `.execute(sql)` like the Drizzle db/tx.
     */
    executor?: AuditReadExecutor;
}): Promise<{
    valid: true;
    count: number;
} | {
    valid: false;
    brokenAt: number;
    limitExceeded?: boolean;
}>;
/**
 * A single event as it appears in an offline-verifiable evidence bundle. All
 * fields that feed the row's canonicalization are included so an third-party
 * verifier can reconstruct linkage (prevHash === prior hmac) WITHOUT the HMAC
 * key. `prevHash`/`hmac` are hex. Row HMACs are NOT recomputable offline (that
 * needs the secret key) — the bundle proves linkage + head match, not per-row
 * recomputation.
 */
export interface BundleEvent {
    seq: number;
    prevHash: string;
    hmac: string;
    actorType: string;
    actorId: string | null;
    action: string;
    resourceType: string | null;
    resourceId: string | null;
    metadata: Record<string, unknown>;
    ipAddress: string | null;
    userAgent: string | null;
    requestId: string | null;
    createdAt: string;
}
export interface AuditChainHeadInfo {
    /** Head sequence per the out-of-band high-water-mark. */
    expectedSeq: number;
    /** Live event count committed by the high-water-mark. */
    expectedCount: number;
    /** Hex HMAC of the head event. */
    headHmac: string;
    /** Retention floor (0 when nothing archived). */
    floorSeq: number;
}
export interface AuditBundleData {
    head: AuditChainHeadInfo | null;
    events: BundleEvent[];
    /** Hex HMAC of the newest event actually present in `events` (bundle head). */
    bundleHeadHmac: string | null;
    /** Seq of the newest event in `events`. */
    bundleHeadSeq: number | null;
}
/**
 * Read the events in [fromSeq, toSeq] for a tenant plus the chain-head
 * high-water-mark, formatted for an evidence bundle. Pure read; does not touch
 * the HMAC writer or verifier state.
 */
export declare function readAuditBundleData(tenantId: string, fromSeq: number, toSeq: number, executor?: AuditReadExecutor): Promise<AuditBundleData>;
/**
 * The self-contained, offline-verifiable signed bundle envelope shared by
 * `/audit/bundle` and `/v2/provider-actions/:id/evidence`. Factored out of
 * the route (spec §6.2) so both surfaces sign identically — one signing path,
 * one checkpoint-persistence policy, one canonicalization contract.
 */
export interface SignedAuditBundle {
    version: 1;
    tenantId: string;
    range: {
        from: number;
        to: number;
        includesHead: boolean;
    };
    canonicalizationSpec: string;
    events: BundleEvent[];
    checkpoint: {
        payload: CheckpointPayload;
        signature: string;
        publicKey: string;
        anchor?: AuditCheckpointAnchorProof;
    };
    generatedAt: string;
}
/**
 * Sign a checkpoint over the chain head + a content digest over exactly the
 * bundle's events, persist the checkpoint best-effort (provenance only; the
 * bundle is authoritative regardless), and return the self-contained
 * signed bundle envelope.
 *
 * `bundleData` MUST come from `readAuditBundleData(tenantId, from, to)` (ideally
 * within the SAME snapshot executor as the caller's other reads). `from`/`to`
 * are the requested range bounds used only for the advisory `range` field; the
 * signed digest brackets the events actually present.
 *
 * Throws `AuditSigningKeyError` if the signing key is unavailable (the caller
 * maps it to 503). All other signing failures throw a generic Error.
 */
export declare function signAuditBundle(tenantId: string, from: number, to: number, bundleData: AuditBundleData): Promise<SignedAuditBundle>;
//# sourceMappingURL=audit.d.ts.map