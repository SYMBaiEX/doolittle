export declare function isRpcError(error: unknown): boolean;
/** Return only a stable public classification; provider text may contain credentials. */
export declare function extractRpcErrorMessage(error: unknown): string;
//# sourceMappingURL=rpc-error.d.ts.map