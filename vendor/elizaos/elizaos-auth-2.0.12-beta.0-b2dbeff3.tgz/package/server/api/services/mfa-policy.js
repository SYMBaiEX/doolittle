import { eq } from "drizzle-orm";
import { getDb, tenantConfigs } from "../../db/index.js";
export async function readTenantMfaPolicy(tenantId) {
    const [row] = await getDb()
        .select({ authAbuseConfig: tenantConfigs.authAbuseConfig })
        .from(tenantConfigs)
        .where(eq(tenantConfigs.tenantId, tenantId));
    return row?.authAbuseConfig?.mfa ?? {};
}
export function tenantMfaMaxAgeMs(policy, action) {
    const seconds = action
        ? (policy.maxAgeFor?.[action] ?? policy.maxAgeSeconds)
        : policy.maxAgeSeconds;
    return typeof seconds === "number" && Number.isFinite(seconds)
        ? Math.max(30, Math.min(3600, Math.floor(seconds))) * 1000
        : 5 * 60_000;
}
export function tenantMfaRequiredFor(policy, action) {
    return policy.requireFor?.[action] !== false;
}
export function tenantMfaDisabledFor(policy, action) {
    return policy.disableFor?.[action] === true;
}
//# sourceMappingURL=mfa-policy.js.map