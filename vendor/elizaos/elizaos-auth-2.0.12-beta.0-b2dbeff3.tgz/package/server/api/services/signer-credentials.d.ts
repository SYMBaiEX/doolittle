export declare function createSignerCredentialHash(secret: string): Promise<string>;
export declare function verifySignerCredential(secret: string, storedHash: string): Promise<boolean>;
//# sourceMappingURL=signer-credentials.d.ts.map