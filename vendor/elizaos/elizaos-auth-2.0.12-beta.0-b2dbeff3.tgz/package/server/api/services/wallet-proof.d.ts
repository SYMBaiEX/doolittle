export declare function verifySolanaMessageSignature(message: string, signature: string, publicKey: string): boolean;
export declare function looksLikeAuthMessage(message: string): boolean;
//# sourceMappingURL=wallet-proof.d.ts.map