import type { Context, Next } from "hono";
import { getDb, type TenantTransactionCharacteristics } from "../../db/index.js";
import { type AggregationLookup, PolicyEngine } from "../../policy-engine/index.js";
import { type AgentIdentity, type PolicyRule, type PriceOracle, type SignRequest, type Tenant, type TenantConfig } from "../../shared/index.js";
import type { Vault } from "../../wallet/index.js";
import { WebhookDispatcher } from "../../webhooks/index.js";
export { API_VERSION } from "./version.js";
export declare const DEFAULT_TENANT_ID = "default";
export declare const RATE_LIMIT_WINDOW_MS: number;
export declare const RATE_LIMIT_MAX_REQUESTS: number;
/**
 * User access token TTL. Refresh tokens (30d) handle long-lived sessions.
 */
export declare const JWT_EXPIRY = "15m";
export declare const AGENT_SCOPE = "agent";
export declare const PROXY_SCOPE = "api:proxy";
/** Scope prefix on tokens minted by the capability issuance layer
 * (`cap:<manifest>`, see @stwd/plugin-capabilities — the core never imports
 * plugin packages, so the prefix is mirrored here). These are least-privilege
 * credentials for the capability surface ONLY; the tenant gate below refuses
 * them so they can never act as general agent credentials. */
export declare const CAPABILITY_TOKEN_SCOPE_PREFIX = "cap:";
export declare function normalizeAgentTokenScopes(scopes?: string[]): string[];
export declare function parseAgentTokenScopes(value: unknown): string[] | null;
export declare function hasAgentTokenScope(scopes: readonly string[] | undefined, required?: string): boolean;
export declare function setNoStoreHeaders(c: Pick<Context, "header">): void;
export declare function createSessionToken(address: string, tenantId: string): Promise<string>;
export declare function createAgentToken(agentId: string, tenantId: string, expiresIn?: string, scopes?: string[]): Promise<string>;
/** Mint while holding the same agent-row lock used by deletion. */
export declare function createAgentTokenForExistingAgent(agentId: string, tenantId: string, expiresIn?: string, scopes?: string[]): Promise<string | null>;
export declare function verifySessionToken(token: string): Promise<{
    address: string;
    tenantId: string;
    agentId?: string;
    scope?: string;
    scopes?: string[];
    typ?: string;
    tokenType?: string;
    userId?: string;
    email?: string;
    mfaVerifiedAt?: number;
    mfaMethod?: string;
    jti?: string;
    exp?: number;
    iat?: number;
    authMethod?: string;
    factorEnrollmentVerifiedAt?: number;
} | null>;
export declare function isValidAgentId(id: unknown): id is string;
export declare function isValidTenantId(id: unknown): id is string;
export declare function isNonEmptyString(value: unknown): value is string;
export declare function isValidAddress(value: unknown): boolean;
export declare function isValidSolanaAddress(value: unknown): boolean;
export declare function isValidAnyAddress(value: unknown): boolean;
export declare function safeJsonParse<T>(c: Context): Promise<T | null>;
export declare function sanitizeErrorMessage(error: unknown): string;
export { PublicApiError } from "./public-error.js";
export { extractRpcErrorMessage, isRpcError } from "./rpc-error.js";
type DbHandle = ReturnType<typeof getDb>;
export declare const db: DbHandle;
export declare const vault: Vault;
export declare const policyEngine: PolicyEngine;
export declare const priceOracle: PriceOracle;
export declare const webhookDispatcher: WebhookDispatcher;
export declare const tenantConfigs: Map<string, TenantConfig>;
/** Initializes the default tenant against the current database before the listener opens. */
export declare function initializeDefaultTenant(): Promise<void>;
export type AuthenticatedPrincipal = {
    type: "tenant" | "user" | "agent";
    id: string;
};
import type { AppVariables } from "../../shared/index.js";
export type { AppVariables };
export declare function getTenantPayload(tenant: Tenant): Omit<Tenant, "apiKeyHash"> & TenantConfig;
export declare function findTenant(tenantId: string): Promise<Tenant | undefined>;
export declare function ensureAgentForTenant(tenantId: string, agentId: string): Promise<AgentIdentity | undefined>;
export declare function getPolicySet(tenantId: string, agentId: string): Promise<PolicyRule[]>;
export declare function getScopedPolicySet(tenantId: string, agentId: string, policyIds: readonly string[] | undefined): Promise<PolicyRule[]>;
export declare function loadConditionSetsForPolicies(tenantId: string, policySet: PolicyRule[]): Promise<Record<string, string[]>>;
export declare function getConditionSetIdsFromPolicies(policySet: PolicyRule[]): string[];
export declare function getConditionSetReferenceValidationError(tenantId: string, policySet: PolicyRule[]): Promise<string | null>;
/**
 * Materialise the rolling-aggregate lookup for a policy set's `aggregation`
 * conditions. Snapshots are computed from the authoritative Redis tracker —
 * never from caller-supplied request fields — and exposed to the engine as a
 * synchronous lookup. Any snapshot that cannot be sourced is simply omitted
 * from the map, which makes the evaluator fail closed (deny) for that
 * condition.
 *
 * Callers wire the returned lookup onto the `aggregations` field of the
 * evaluation context. The recording side (recordAggregationEvent) must be
 * driven on transaction commit, inside the same per-agent serialization window
 * used for spend caps, so the aggregate cannot be raced.
 */
export declare function loadAggregationsForPolicies(policySet: PolicyRule[], request: SignRequest, now?: number): Promise<AggregationLookup>;
export declare function getTransactionStats(agentId: string, chainId?: number): Promise<{
    recentTxCount1h: number;
    recentTxCount24h: number;
    spentToday: bigint;
    spentThisWeek: bigint;
    additionalUsdSpentTodayMicros: bigint;
    additionalUsdSpentThisWeekMicros: bigint;
}>;
export declare function withAuthenticatedTenantDatabase<T>(tenantId: string, method: string, subject: string, callback: () => Promise<T>, userId?: string, characteristics?: TenantTransactionCharacteristics): Promise<T>;
export declare function continueWithTenantDatabase(tenantId: string, method: string, subject: string, next: Next, userId?: string): Promise<unknown>;
export declare function tenantAuth(c: Context<{
    Variables: AppVariables;
}>, next: Next, options?: {
    requireTenantMatch?: string;
    bindTenantDatabase?: boolean;
}): Promise<Response | void>;
export declare function sessionAuth(c: Context<{
    Variables: AppVariables;
}>, next: Next): Promise<Response | void>;
export declare function getAuthenticatedPrincipal(c: Context<{
    Variables: AppVariables;
}>): AuthenticatedPrincipal;
export declare function isSameAuthenticatedPrincipal(left: {
    type: string;
    id: string;
}, right: {
    type: string;
    id: string;
}): boolean;
export declare function formatAuthenticatedPrincipal(principal: AuthenticatedPrincipal): string;
export declare function requireAgentAccess(c: Context<{
    Variables: AppVariables;
}>): boolean;
export declare function requireTenantLevel(c: Context<{
    Variables: AppVariables;
}>): boolean;
/**
 * dashboardAuthMiddleware
 * Accepts a session JWT (Bearer token) issued by the auth routes.
 * Extracts userId and tenantId, looks up the tenant, and sets context variables
 * so dashboard routes can make authenticated API calls on behalf of the user.
 *
 * The dashboard is user-centric (not API-key-centric) so only session JWTs are
 * accepted here — no API key fallback.
 */
export declare function dashboardAuthMiddleware(c: Context<{
    Variables: AppVariables;
}>, next: Next): Promise<Response | void>;
export { agentKeyQuorums, agentSigners, agents, agentWallets, approvalQueue, autoApprovalRules, conditionSetItems, conditionSets, encryptedChainKeys, encryptedKeys, intents, pendingProxyRequests, policies, tenants, toPolicyRule, toSignRequest, toTxRecord, transactions, vaultSigningFreezes, webhookConfigs, webhookDeliveries, } from "../../db/index.js";
export type { AgentBalance, AgentIdentity, ApiResponse, PolicyRule, RpcRequest, RpcResponse, SignRequest, SignSolanaTransactionRequest, SignTypedDataRequest, Tenant, TenantConfig, } from "../../shared/index.js";
//# sourceMappingURL=context.d.ts.map