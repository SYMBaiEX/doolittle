declare const PUBLIC_API_ERROR_MESSAGES: {
    readonly resource_already_exists: "Resource already exists";
    readonly resource_not_found: "Resource not found";
    readonly unsupported_chain: "Unsupported chain";
};
export type PublicApiErrorCode = keyof typeof PUBLIC_API_ERROR_MESSAGES;
/** A typed error whose public text is selected from a closed, stable table. */
export declare class PublicApiError extends Error {
    readonly code: PublicApiErrorCode;
    readonly publicMessage: string;
    constructor(code: PublicApiErrorCode);
}
export declare function sanitizePublicError(error: unknown): string;
export {};
//# sourceMappingURL=public-error.d.ts.map