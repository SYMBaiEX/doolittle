import { type ExecutionAuthorization, type ExecutionCapability, type NormalizedEvmExecutionPayload, type PolicyRule, type SignRequest } from "../../shared/index.js";
export declare const EXECUTION_AUTHORIZATION_TTL_MS = 60000;
export declare class ExecutionAuthorizationError extends Error {
    readonly code: "missing_signature" | "invalid_signature" | "expired" | "context_mismatch" | "nonce_consumed" | "secret_unavailable";
    constructor(message: string, code: "missing_signature" | "invalid_signature" | "expired" | "context_mismatch" | "nonce_consumed" | "secret_unavailable");
}
export declare function canonicalJson(value: unknown): string;
export declare function sha256Hex(value: unknown): string;
/**
 * Canonical normalized EVM sign intent. Delegates to the SINGLE shared
 * normalizer so the API minting side and the GovernedVault verification side
 * digest byte-identical payloads. Throws on malformed numeric caller fields.
 */
export declare function executionPayloadForEvmSign(request: SignRequest): NormalizedEvmExecutionPayload;
export declare function executionPayloadDigestForEvmSign(request: SignRequest): string;
export declare function policyRevisionHashForAgent(agentId: string): Promise<string>;
export declare function policyRevisionHashForPolicySet(policySet: readonly PolicyRule[]): string;
export interface MintExecutionAuthorizationInput {
    requestId: string;
    tenantId: string;
    agentId: string;
    capability: ExecutionCapability;
    payloadDigest: string;
    backend: ExecutionAuthorization["backend"];
    backendIdentityDigest?: string;
    policyRevisionHash?: string;
    approvalId?: string;
    idempotencyKey?: string;
    now?: Date;
}
export declare function mintExecutionAuthorization(input: MintExecutionAuthorizationInput): Promise<ExecutionAuthorization>;
export interface ConsumeExecutionAuthorizationContext {
    tenantId: string;
    agentId: string;
    capability: ExecutionCapability;
    backend: ExecutionAuthorization["backend"];
    backendIdentityDigest?: string;
    payloadDigest: string;
}
export declare function consumeExecutionAuthorization(authorization: ExecutionAuthorization, expected: ConsumeExecutionAuthorizationContext): Promise<void>;
export declare function verifyExecutionAuthorization(authorization: ExecutionAuthorization, expected: ConsumeExecutionAuthorizationContext): void;
//# sourceMappingURL=execution-authorization.d.ts.map