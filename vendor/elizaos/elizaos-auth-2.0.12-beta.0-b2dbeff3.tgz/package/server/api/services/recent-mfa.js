/** Validate a privileged MFA step-up without accepting any future timestamp. */
export function isRecentMfaTimestamp(verifiedAt, maxAgeMs, nowMs = Date.now()) {
    if (typeof verifiedAt !== "number" ||
        !Number.isFinite(verifiedAt) ||
        !Number.isFinite(maxAgeMs) ||
        maxAgeMs < 0 ||
        !Number.isFinite(nowMs)) {
        return false;
    }
    const ageMs = nowMs - verifiedAt;
    return ageMs >= 0 && ageMs <= maxAgeMs;
}
//# sourceMappingURL=recent-mfa.js.map