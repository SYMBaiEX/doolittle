import { SecretVault, Vault } from "../../wallet/index.js";
export type VaultMode = "local" | "kms-envelope:aws" | "kms-envelope:pkcs11";
export type ExternalCustodyProviderName = "aws-kms";
/**
 * Explicit acknowledgement that this deployment runs the weakest custody
 * posture (`local`: AES-256-GCM at rest, plaintext key bytes in application
 * memory at sign time) in production. Set to `"true"` to proceed.
 *
 * This mirrors the adapter-registry `STEWARD_ALLOW_MOCK_ADAPTERS` gate: a silent
 * weak default in production becomes a deliberate, recorded operator decision.
 * Unlike the `STEWARD_ALLOW_*` family (which unblocks an otherwise-refused
 * capability), this flag does not change WHAT local mode can do — it only forces
 * the operator to acknowledge the posture before the root of trust boots.
 *
 * See docs/security/custody-posture.md for the full threat model.
 */
export declare const LOCAL_CUSTODY_ACK_ENV = "STEWARD_ACK_LOCAL_CUSTODY";
export declare class LocalCustodyAcknowledgementRequiredError extends Error {
    readonly code = "local_custody_acknowledgement_required";
    constructor();
}
export declare const VAULT_SIGNING_CAPABILITIES: readonly ["sign_transaction", "sign_message", "sign_raw_hash", "sign_raw_digest", "sign_typed_data", "sign_user_operation", "sign_eip7702_authorization", "sign_solana_transaction", "sign_solana_message", "sign_bitcoin_psbt", "sign_monero_transfer"];
export type VaultSigningCapability = (typeof VAULT_SIGNING_CAPABILITIES)[number];
export declare const VAULT_CAPABILITY_REGISTRY: Readonly<Record<VaultMode, Readonly<Record<VaultSigningCapability, true>>>>;
export interface ConfiguredVaultOptions {
    allowDevSecretFallback?: boolean;
    fallbackPassword?: string;
}
/**
 * True when the resolved custody mode materializes plaintext private-key bytes
 * in this process's memory at sign time. This is the honest boundary from
 * VISION.md: `local` AND both `kms-envelope:*` modes decrypt the key to a
 * plaintext string in-process before signing. Only an external-custody provider
 * (wired via VaultConfig.externalKeyCustodyProvider, not a vault-factory mode)
 * keeps plaintext out of this process entirely.
 *
 * The acknowledgement gate below is scoped narrowly to `local` — the weakest
 * mode, where the key is ALSO plaintext at rest inside the app's own DB unless
 * an operator adds a KMS/HSM wrap. KMS-envelope modes already require explicit
 * KMS configuration, which is itself a deliberate operator decision.
 */
export declare function modeExposesPlaintextAtSignTime(mode: VaultMode): boolean;
/**
 * Fail closed if this deployment would silently boot the weakest custody
 * posture in production. The root of trust must never boot weak SILENTLY:
 * production + local plaintext custody + no explicit acknowledgement => throw.
 *
 * Development/test ergonomics are unchanged (the gate only fires when
 * NODE_ENV === "production"). Stronger modes (KMS-envelope) pass without the
 * ack because selecting them is already an explicit configuration decision.
 */
export declare function assertProductionCustodyAcknowledged(mode: VaultMode): void;
export declare function resolveMasterPassword(options: ConfiguredVaultOptions): string;
export declare function createConfiguredVault(options?: ConfiguredVaultOptions): Vault;
export declare function getConfiguredVault(options?: ConfiguredVaultOptions): Vault;
export declare function configuredVaultStartupLogLine(): string;
export declare function clearConfiguredVaults(): void;
/** Credential custody uses the current root and is released with wallet custody. */
export declare function getConfiguredSecretVault(): SecretVault;
//# sourceMappingURL=vault-factory.d.ts.map