import type { agentSigners } from "../../db/index.js";
export declare function signerHasPermission(permissions: readonly string[], required: string): boolean;
export declare function redactSignerMetadata(metadata: Record<string, unknown>): Record<string, unknown>;
export declare function toSignerResponse(row: typeof agentSigners.$inferSelect): {
    id: string;
    tenantId: string;
    agentId: string;
    signerType: string;
    subjectType: string;
    subjectId: string;
    keyType: string;
    publicKey: string | null;
    address: string | null;
    chainFamily: "evm" | "solana" | "bitcoin" | "monero" | null;
    label: string | null;
    permissions: string[];
    policyIds: string[];
    metadata: Record<string, unknown>;
    hasCredential: boolean;
    status: string;
    createdBy: string | null;
    createdAt: Date;
    updatedAt: Date;
};
//# sourceMappingURL=signer-policy.d.ts.map