import { sql } from "drizzle-orm";
function userSessionLockKey(userId) {
    return `user_session_${userId}`;
}
export async function lockUserSession(tx, userId) {
    await tx.execute(sql `select pg_advisory_xact_lock(hashtextextended(${userSessionLockKey(userId)}, 0))`);
}
export async function lockUserSessions(tx, userIds) {
    for (const userId of [...new Set(userIds)].sort()) {
        await lockUserSession(tx, userId);
    }
}
//# sourceMappingURL=session-lock.js.map