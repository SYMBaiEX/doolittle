import type { TenantSamlSsoConfig, TenantSamlSsoUpdate } from "../../shared/index.js";
export declare function buildSamlServiceProviderUrls(tenantId: string): {
    spEntityId: string;
    acsUrl: string;
    metadataUrl: string;
};
export declare function normalizeSamlSsoUpdate(tenantId: string, value: unknown): Omit<TenantSamlSsoConfig, "createdAt" | "updatedAt" | "lastTestedAt"> | string;
export declare function sanitizeSamlSsoUpdate(value: unknown): TenantSamlSsoUpdate | string;
//# sourceMappingURL=saml-sso-config.d.ts.map