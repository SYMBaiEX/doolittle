export declare const PLAINTEXT_KEY_EXPORT_ACKNOWLEDGEMENT = "I understand this response contains plaintext private keys";
type EnvLike = Record<string, string | undefined>;
export declare function plaintextKeyExportResponseGateError(body: unknown, env?: EnvLike): string | null;
export {};
//# sourceMappingURL=key-export-plaintext-gate.d.ts.map