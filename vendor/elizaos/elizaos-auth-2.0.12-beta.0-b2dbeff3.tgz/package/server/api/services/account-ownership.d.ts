import { getDb } from "../../db/index.js";
export declare function activeTenantOwnerCount(tx: Pick<ReturnType<typeof getDb>, "select">, tenantId: string, excludeUserId?: string): Promise<number>;
export declare function userHasLinkedThirdPartyWallet(userId: string): Promise<boolean>;
//# sourceMappingURL=account-ownership.d.ts.map