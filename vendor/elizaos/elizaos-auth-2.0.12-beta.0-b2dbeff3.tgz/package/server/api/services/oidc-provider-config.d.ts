import type { TenantOidcProviderConfig } from "../../shared/index.js";
/**
 * Tenant-configured OIDC client secrets may only be sourced from env vars in
 * this dedicated namespace. Without the prefix, a tenant admin could point
 * `clientSecretEnv` at any platform secret (e.g. STEWARD_JWT_SECRET) and have
 * it POSTed to a tenant-controlled tokenUrl during code exchange (SEC-005).
 */
export declare const OIDC_CLIENT_SECRET_ENV_PREFIX = "STEWARD_TENANT_OIDC_SECRET_";
/**
 * SEC-005 residual: the bare namespace above is platform-wide, so a tenant
 * admin could reference ANOTHER tenant's OIDC secret env var. Bind the env
 * name to the configuring tenant: it must start with
 * STEWARD_TENANT_OIDC_SECRET_<TENANT_KEY>_, where TENANT_KEY is the tenant id
 * uppercased with non-env-safe characters mapped to "_".
 *
 * Note: distinct tenant ids whose only differences are separator characters
 * (e.g. "acme-corp" vs "acme.corp") share a TENANT_KEY. Tenant ids are
 * provisioned by platform admins, not tenant admins, so this collision cannot
 * be attacker-created; operators should avoid separator-only-distinct ids.
 */
export declare function oidcClientSecretEnvPrefixForTenant(tenantId: string): string;
export declare function isAllowedOidcClientSecretEnv(name: string): boolean;
export declare function isAllowedOidcClientSecretEnvForTenant(name: string, tenantId: string): boolean;
export declare function normalizeOidcProviders(value: unknown, tenantId: string): TenantOidcProviderConfig[] | string;
//# sourceMappingURL=oidc-provider-config.d.ts.map