export { buildTwilioVerifyProviderFromEnvironment } from "../../auth/phone-provider.js";
import { ChallengeStore, EmailAuth, PasskeyAuth, PhoneAuth, type StoreBackend } from "../../auth/index.js";
import { type accounts, type TenantEmailConfig } from "../../db/index.js";
import type { TenantAuthAbuseConfig, TenantTestAccountConfig } from "../../shared/index.js";
import { KeyStore } from "../../wallet/index.js";
export declare const SMS_VERIFY_MAX_FAILED_ATTEMPTS = 5;
export declare function smsVerifyAttemptSlotKey(phone: string, purpose: string, slot: number): string;
type SmsVerifyAttemptClaim = {
    key: string;
    token: string;
};
/**
 * Atomically reserve one of the five verification-attempt slots. Using
 * set-if-absent slots keeps the limit correct under concurrent requests on
 * every shipped backend without relying on a read-then-write counter.
 */
export declare function claimSmsVerifyAttempt(phone: string, purpose: string): Promise<SmsVerifyAttemptClaim | null>;
/**
 * Roll back claim-first accounting only when no provider check could have run.
 * Timeout/5xx/malformed outcomes retain the slot because the remote service may
 * already have evaluated the guess.
 */
export declare function releaseUnattemptedSmsVerifyClaim(claim: SmsVerifyAttemptClaim, error: unknown): Promise<boolean>;
export declare function clearSmsVerifyFailures(phone: string, purpose: string): Promise<void>;
export declare function bootstrapRows<T>(result: unknown): T[];
type AuthTenantConfigSubject = {
    auth_abuse_config: TenantAuthAbuseConfig;
    allowed_origins: string[];
    email_config: TenantEmailConfig | null;
    oidc_providers: unknown;
    test_account: TenantTestAccountConfig;
    allowed_redirect_urls: string[];
};
type AuthAppClientSubject = {
    id: string;
    allowed_redirect_urls: string[];
    login_methods: TenantAuthAbuseConfig["loginMethods"] | null;
    allowed_bundle_ids: string[];
    allowed_package_names: string[];
};
export declare function authTenantConfigSubject(tenantId: string): Promise<AuthTenantConfigSubject | null>;
export declare function authAppClientSubjects(tenantId: string): Promise<AuthAppClientSubject[]>;
export type LoginMethodName = "passkey" | "email" | "sms" | "whatsapp" | "totp" | "siwe" | "siws" | "telegram" | "farcaster" | "oauth" | "oidc";
export declare function loginMethodProviderKey(providerId: string | undefined): string;
/**
 * The refusal a tenant's login methods give a sign-in by `method` (through
 * `providerId` for OAuth and OIDC), or null when the sign-in is allowed.
 */
export declare function loginMethodRefusal(loginMethods: TenantAuthAbuseConfig["loginMethods"] | undefined, method: LoginMethodName, providerId?: string): string | null;
/**
 * A switch into another tenant is a sign-in to it, so the target tenant's
 * login methods apply to the method (and provider) recorded on the session.
 * Returns the refusal, or null when the switch is allowed.
 */
export declare function tenantSwitchLoginRefusal(tenantId: string, claims: Record<string, unknown>): Promise<string | null>;
export declare function createSessionToken(address: string, tenantId: string, extra?: Record<string, unknown>, expiresIn?: string): Promise<string>;
export declare function getNonceBackend(): import("../../auth/index.js").StoreBackend;
type AuthStoreSource = "redis" | "postgres" | "pglite" | "memory";
type AuthStoreSources = {
    challenge: AuthStoreSource;
    token: AuthStoreSource;
    siweNonce: AuthStoreSource;
    mfa: AuthStoreSource;
    importSession: AuthStoreSource;
};
/**
 * One-time OAuth nonce-exchange codes (response_type=code) live for 60s —
 * long enough for the user's browser to redirect back and the caller's
 * backend to POST the code to /oauth/exchange, short enough that a captured
 * code in an access log or Referer leak is useless by the time anyone reads
 * it. Codes are single-use (consume() deletes on first read).
 */
export declare const OAUTH_CODE_TTL_MS: number;
/**
 * Initialize auth token/challenge stores with the best available backend.
 * Call this during server startup AFTER initRedis() has been called.
 *
 * @param usePostgres  Pass true if the DB connection is known to be available.
 */
export declare function initAuthStores(usePostgres?: boolean): Promise<void>;
export declare function getChallengeStore(): ChallengeStore;
export declare function getOAuthCodeStore(): ChallengeStore;
export declare const EMAIL_GRANT_TTL_MS: number;
export declare function getEmailGrantStore(): ChallengeStore;
export declare function emailGrantKey(grant: string): string;
export type EmailGrantScope = "personal" | "tenant";
/**
 * Test-only seam for exercising verified-email enrollment routes without
 * sending or scraping an OTP. Production grants are still issued exclusively
 * by /email/otp/verify.
 */
export declare function _seedEmailGrantForTests(grant: string, email: string, tenantId: string, scope?: EmailGrantScope): Promise<void>;
export declare function getMfaBackend(): StoreBackend;
export declare function getImportSessionBackend(): StoreBackend;
/**
 * Refuse ephemeral auth state in production and Workers deployments. Losing or
 * partitioning challenge, token, nonce, MFA, or import-session state across
 * processes can break single-use guarantees. A single-instance deployment may
 * explicitly acknowledge that trade-off, but it must never happen silently.
 */
export declare function assertAuthStoresAreSafe(sources?: AuthStoreSources): void;
export declare function encryptImportSessionJson(value: unknown): string;
export declare function decryptImportSessionJson<T>(value: string): T;
export declare function getPasskeyAuth(requestOrigin?: string): PasskeyAuth;
export declare function getOAuthKeyStore(): KeyStore;
type OAuthEncryptedTokenFields = Pick<typeof accounts.$inferInsert, "accessTokenEncrypted" | "accessTokenIv" | "accessTokenTag" | "accessTokenSalt" | "refreshTokenEncrypted" | "refreshTokenIv" | "refreshTokenTag" | "refreshTokenSalt">;
export declare function encryptOAuthProviderTokens(accessToken: string, refreshToken?: string | null): OAuthEncryptedTokenFields;
export declare function isMockEmailEnabled(): boolean;
export declare function getEmailAuthForTenant(tenantId: string): Promise<EmailAuth>;
export declare function invalidateEmailAuthForTenant(tenantId: string): void;
export declare function getPhoneAuth(): PhoneAuth;
export declare function normalizePublicClientId(value: unknown): string | undefined;
export declare function assertAllowedOAuthRedirectUri(redirectUri: string, tenantId?: string, clientId?: string): Promise<URL>;
export { getChallengeStore as getAuthChallengeStore };
/** Release only owned memory; durable challenges remain available after restart. */
export declare function releaseAuthStores(): void;
//# sourceMappingURL=auth-lifecycle.d.ts.map