import { ChallengeStore, type StoreBackend } from "../../auth/index.js";
export declare const WALLET_LINK_CHALLENGE_TTL_MS: number;
export declare const SOCIAL_LINK_CHALLENGE_TTL_MS: number;
export declare const OAUTH_LINK_CHALLENGE_TTL_MS: number;
export declare let walletLinkChallenges: ChallengeStore;
export declare let socialLinkChallenges: ChallengeStore;
export declare let oauthLinkChallenges: ChallengeStore;
/** Bind account-link challenges to auth startup's selected durable backend. */
export declare function initUserLinkChallengeStores(backend: StoreBackend): void;
//# sourceMappingURL=account-link-stores.d.ts.map