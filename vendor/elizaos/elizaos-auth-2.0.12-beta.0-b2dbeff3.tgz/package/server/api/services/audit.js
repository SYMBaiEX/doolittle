import { canonicalize, computeHmac, rowsFromExecute, toU8, } from "../../db/audit-codec.js";
/**
 * Tamper-evident audit log writer & verifier.
 *
 * Every audit event extends a per-tenant HMAC chain. Each row's `hmac`
 * commits to `prev_hash || canonical_json(event)` keyed by
 * STEWARD_AUDIT_HMAC_KEY. Mutating any historical row breaks verification
 * of every subsequent row.
 *
 * Trust boundary: the HMAC key is held in app config, separate from
 * Postgres credentials. An attacker with DB-only write access cannot
 * forge rows that pass verification.
 *
 * Concurrency: writers serialize chain extensions per tenant with
 * `pg_advisory_xact_lock(hashtextextended('steward_audit_'||tenant_id, 0))`.
 * Cross-tenant writes do not contend.
 */
import { timingSafeEqual } from "node:crypto";
import { logger } from "@elizaos/core";
import { sql } from "drizzle-orm";
import { appendAuditEvent, appendAuditEventWithinTx, auditCheckpoints, getDb, waitUntilTenantDatabaseTask, withTenantAuditedTransaction, withTenantAuditQueue, writeAuditEvent, } from "../../db/index.js";
import { observeAuditCheckpoint, redactedThrownDiagnostics, } from "../../shared/index.js";
import { eventsContentDigest, getCheckpointSigner, } from "./audit-checkpoint.js";
import { AuditCheckpointAnchorError, configuredAuditCheckpointAnchor, maybeAnchorAuditCheckpoint, } from "./audit-checkpoint-anchor.js";
import { API_VERSION } from "./version.js";
/**
 * The canonicalization contract an offline verifier must reproduce per event.
 * Single source of truth (spec §6.2): the route re-exports this. Bumped only
 * alongside a verifier change.
 */
export const BUNDLE_CANONICALIZATION_SPEC = "steward-audit-hmac-chain/v1: hmac = HMAC-SHA256(key, prev_hash_bytes || " +
    "canonical_json(event)); canonical_json sorts object keys, drops whitespace, " +
    "encodes null for absent fields and ISO-8601 for timestamps. Offline verifier " +
    "checks event linkage (each prevHash === prior hmac) + head == checkpoint, and " +
    "the Ed25519 signature over the canonical checkpoint payload. Per-row HMAC " +
    "recomputation requires the operator's secret key and is NOT part of offline " +
    "verification.";
/** Build the high-water aggregate read, bounded when doctor supplies maxRows. */
export function auditRowAggregateQuery(tenantId, genesisSeq, maxRows) {
    return maxRows === undefined
        ? sql `SELECT MAX(seq) AS max_seq, COUNT(*) AS cnt FROM audit_events WHERE tenant_id = ${tenantId} AND seq >= ${genesisSeq}`
        : sql `SELECT MAX(seq) AS max_seq, COUNT(*) AS cnt
          FROM (
            SELECT seq FROM audit_events
            WHERE tenant_id = ${tenantId} AND seq >= ${genesisSeq}
            ORDER BY seq ASC
            LIMIT ${maxRows + 1}
          ) AS bounded_audit_events`;
}
export { appendAuditEvent, appendAuditEventWithinTx, withTenantAuditedTransaction, withTenantAuditQueue, writeAuditEvent, };
const ZERO_HASH = new Uint8Array(32);
function u8Equals(a, b) {
    if (a.length !== b.length)
        return false;
    return timingSafeEqual(a, b);
}
// Minimum entropy for the audit HMAC key: 32 bytes. Hex-encoded keys must be
// >= 64 hex chars (= 32 bytes); raw/passphrase keys must be >= 32 chars.
const MIN_HMAC_RAW_BYTES = 32;
let warnedDevFallback = false;
let cachedKey = null;
function getHmacKey() {
    if (cachedKey)
        return cachedKey;
    const env = process.env.STEWARD_AUDIT_HMAC_KEY;
    if (env && env.length > 0) {
        const isHex = /^[0-9a-fA-F]+$/.test(env) && env.length % 2 === 0;
        // Hex keys decode to env.length/2 bytes; raw keys count chars directly.
        const effectiveBytes = isHex ? env.length / 2 : env.length;
        if (effectiveBytes < MIN_HMAC_RAW_BYTES) {
            throw new Error(`STEWARD_AUDIT_HMAC_KEY is too weak: needs >= ${MIN_HMAC_RAW_BYTES} bytes of entropy ` +
                `(>= ${MIN_HMAC_RAW_BYTES * 2} hex chars, or >= ${MIN_HMAC_RAW_BYTES} raw chars). ` +
                "Generate with `openssl rand -hex 32`.");
        }
        cachedKey =
            isHex && env.length >= MIN_HMAC_RAW_BYTES * 2
                ? toU8(env)
                : new TextEncoder().encode(env);
        return cachedKey;
    }
    if (process.env.NODE_ENV === "production") {
        throw new Error("STEWARD_AUDIT_HMAC_KEY is required in production. Generate with `openssl rand -hex 32`.");
    }
    // Default-deny: the dev fallback is only allowed with an explicit opt-in
    // consistent with the rest of the repo (STEWARD_ALLOW_DEV_SECRETS).
    if (process.env.STEWARD_ALLOW_DEV_SECRETS !== "true") {
        throw new Error("STEWARD_AUDIT_HMAC_KEY is required. For local development only, set " +
            "STEWARD_ALLOW_DEV_SECRETS=true to use the insecure dev key.");
    }
    if (!warnedDevFallback) {
        warnedDevFallback = true;
        logger.warn({
            details: [
                "⚠️ [audit] STEWARD_AUDIT_HMAC_KEY not set — using INSECURE dev fallback " +
                    "(STEWARD_ALLOW_DEV_SECRETS=true). Audit chain is NOT tamper-evident. Never use in production.",
            ],
        }, "[Login:audit] warn");
    }
    cachedKey = new TextEncoder().encode("dev-audit-hmac-key-do-not-use-in-production-aaaaaaaaaaaaaaaaaaaaaaaa");
    return cachedKey;
}
/**
 * Records best-effort telemetry after an operation has committed, logging failures.
 * Security-sensitive operations must await writeAuditEvent and fail if their
 * durable audit record cannot be written.
 */
export function trackAuditEvent(ev) {
    return waitUntilTenantDatabaseTask(() => writeAuditEvent(ev).catch((err) => {
        logger.error({
            details: [
                `[audit] Failed to write event ${ev.action} for tenant ${ev.tenantId}`,
                redactedThrownDiagnostics(err),
            ],
        }, "[Login:audit] error");
    }));
}
/**
 * Walk the chain for a tenant and verify every HMAC.
 *
 * Returns `{ valid: true, count }` if the entire range verifies, otherwise
 * `{ valid: false, brokenAt }` pointing to the first row whose digest does
 * not match the expected value computed from its predecessor.
 */
export async function verifyAuditChain(tenantId, opts = {}) {
    const key = getHmacKey();
    const db = opts.executor ?? getDb();
    const requestedFromSeq = opts.fromSeq ?? 1;
    const toSeq = opts.toSeq;
    const maxRows = opts.maxRows;
    if (maxRows !== undefined &&
        (!Number.isSafeInteger(maxRows) || maxRows <= 0 || maxRows > 1_000_000)) {
        throw new Error("maxRows must be a positive safe integer no greater than 1000000");
    }
    // Out-of-band high-water-mark: persisted atomically with each append. Lets us
    // detect tail-truncation / whole-chain deletion that walking the surviving
    // rows alone cannot (an open-ended walk of a truncated chain still "verifies").
    const headRows = rowsFromExecute(await db.execute(sql `SELECT expected_seq, expected_count, head_hmac, floor_seq, floor_hmac
          FROM audit_chain_heads WHERE tenant_id = ${tenantId} LIMIT 1`));
    const head = headRows[0];
    if (!head && opts.requireHead) {
        return { valid: false, brokenAt: requestedFromSeq };
    }
    const floorSeq = head?.floor_seq != null ? Number(head.floor_seq) : 0;
    const floorHmac = head?.floor_hmac != null ? toU8(head.floor_hmac) : null;
    // Genesis prevHash: after a retention archive+drop, the chain restarts from a
    // stored floor anchor rather than the public ZERO_HASH (which an attacker
    // could re-derive to forge a fresh seq=1). Below the floor, rows are gone.
    const genesisSeq = floorSeq + 1;
    let prevHash = floorSeq > 0 && floorHmac ? floorHmac : ZERO_HASH;
    // Full-chain verification (request starts at or before the live genesis):
    // compare on-disk reality against the high-water-mark to catch truncation.
    const isFullChainVerify = requestedFromSeq <= genesisSeq;
    if (isFullChainVerify && head) {
        const expectedSeqHwm = Number(head.expected_seq);
        const expectedCount = Number(head.expected_count);
        const aggRows = rowsFromExecute(await db.execute(auditRowAggregateQuery(tenantId, genesisSeq, maxRows)));
        const actualMaxSeq = aggRows[0]?.max_seq != null ? Number(aggRows[0].max_seq) : 0;
        const actualCount = aggRows[0]?.cnt != null ? Number(aggRows[0].cnt) : 0;
        const expectedLiveCount = expectedCount - (genesisSeq - 1);
        if (maxRows !== undefined && actualCount > maxRows) {
            return {
                valid: false,
                brokenAt: genesisSeq + maxRows,
                limitExceeded: true,
            };
        }
        // Missing newest rows (tail truncation) or whole-chain deletion: the stored
        // head outranks / outcounts what survives on disk. Point brokenAt at the
        // first missing seq.
        if (actualMaxSeq < expectedSeqHwm || actualCount < expectedLiveCount) {
            return {
                valid: false,
                brokenAt: actualMaxSeq + 1 < genesisSeq ? genesisSeq : actualMaxSeq + 1,
            };
        }
    }
    // A request that starts at genesis but there is NO head row yet means either a
    // never-written tenant (count 0, fine) or a head row that was itself deleted
    // alongside the chain — handled by the walk + final count comparison below.
    // Rows below the floor have been archived+dropped; never expect them on disk.
    const effectiveFromSeq = Math.max(requestedFromSeq, genesisSeq);
    if (effectiveFromSeq > genesisSeq) {
        const predecessorRows = rowsFromExecute(await db.execute(sql `SELECT hmac FROM audit_events WHERE tenant_id = ${tenantId} AND seq = ${effectiveFromSeq - 1} LIMIT 1`));
        const predecessor = predecessorRows[0];
        if (predecessor) {
            prevHash = toU8(predecessor.hmac);
        }
    }
    const rows = rowsFromExecute(await db.execute(toSeq !== undefined
        ? maxRows !== undefined
            ? sql `SELECT * FROM audit_events WHERE tenant_id = ${tenantId} AND seq BETWEEN ${effectiveFromSeq} AND ${toSeq} ORDER BY seq ASC LIMIT ${maxRows + 1}`
            : sql `SELECT * FROM audit_events WHERE tenant_id = ${tenantId} AND seq BETWEEN ${effectiveFromSeq} AND ${toSeq} ORDER BY seq ASC`
        : maxRows !== undefined
            ? sql `SELECT * FROM audit_events WHERE tenant_id = ${tenantId} AND seq >= ${effectiveFromSeq} ORDER BY seq ASC LIMIT ${maxRows + 1}`
            : sql `SELECT * FROM audit_events WHERE tenant_id = ${tenantId} AND seq >= ${effectiveFromSeq} ORDER BY seq ASC`));
    if (maxRows !== undefined && rows.length > maxRows) {
        return {
            valid: false,
            brokenAt: effectiveFromSeq + maxRows,
            limitExceeded: true,
        };
    }
    let count = 0;
    let expectedSeq = effectiveFromSeq;
    for (const row of rows) {
        const rowSeq = Number(row.seq);
        if (rowSeq !== expectedSeq) {
            return { valid: false, brokenAt: expectedSeq };
        }
        const rowHmac = toU8(row.hmac);
        const rowPrev = toU8(row.prev_hash);
        if (!u8Equals(rowPrev, prevHash)) {
            return { valid: false, brokenAt: rowSeq };
        }
        const created = row.created_at instanceof Date
            ? row.created_at
            : new Date(row.created_at);
        const canonical = canonicalize({
            tenant_id: row.tenant_id,
            seq: Number(row.seq),
            actor_type: row.actor_type,
            actor_id: row.actor_id,
            action: row.action,
            resource_type: row.resource_type,
            resource_id: row.resource_id,
            metadata: row.metadata ?? {},
            ip_address: row.ip_address,
            user_agent: row.user_agent,
            request_id: row.request_id,
            created_at: created.toISOString(),
        });
        const expected = computeHmac(key, prevHash, canonical);
        if (!u8Equals(rowHmac, expected)) {
            return { valid: false, brokenAt: rowSeq };
        }
        prevHash = rowHmac;
        count++;
        expectedSeq++;
    }
    if (toSeq !== undefined && expectedSeq <= toSeq) {
        return { valid: false, brokenAt: expectedSeq };
    }
    return { valid: true, count };
}
// ─── Evidence bundle support ──────────────────────────────────────────────────
function toHex(value) {
    const bytes = toU8(value);
    let hex = "";
    for (let i = 0; i < bytes.length; i++) {
        hex += bytes[i].toString(16).padStart(2, "0");
    }
    return hex;
}
/**
 * Read the events in [fromSeq, toSeq] for a tenant plus the chain-head
 * high-water-mark, formatted for an evidence bundle. Pure read; does not touch
 * the HMAC writer or verifier state.
 */
export async function readAuditBundleData(tenantId, fromSeq, toSeq, executor) {
    const db = executor ?? getDb();
    const headRows = rowsFromExecute(await db.execute(sql `SELECT expected_seq, expected_count, head_hmac, floor_seq
          FROM audit_chain_heads WHERE tenant_id = ${tenantId} LIMIT 1`));
    const headRow = headRows[0];
    const head = headRow
        ? {
            expectedSeq: Number(headRow.expected_seq),
            expectedCount: Number(headRow.expected_count),
            headHmac: toHex(headRow.head_hmac),
            floorSeq: headRow.floor_seq != null ? Number(headRow.floor_seq) : 0,
        }
        : null;
    const rows = rowsFromExecute(await db.execute(sql `SELECT seq, prev_hash, hmac, actor_type, actor_id, action, resource_type,
                 resource_id, metadata, ip_address, user_agent, request_id, created_at
          FROM audit_events
          WHERE tenant_id = ${tenantId} AND seq BETWEEN ${fromSeq} AND ${toSeq}
          ORDER BY seq ASC`));
    const events = rows.map((row) => {
        const created = row.created_at instanceof Date
            ? row.created_at
            : new Date(row.created_at);
        return {
            seq: Number(row.seq),
            prevHash: toHex(row.prev_hash),
            hmac: toHex(row.hmac),
            actorType: row.actor_type,
            actorId: row.actor_id,
            action: row.action,
            resourceType: row.resource_type,
            resourceId: row.resource_id,
            metadata: row.metadata ?? {},
            ipAddress: row.ip_address,
            userAgent: row.user_agent,
            requestId: row.request_id,
            createdAt: created.toISOString(),
        };
    });
    const last = events.length > 0 ? events[events.length - 1] : null;
    return {
        head,
        events,
        bundleHeadHmac: last ? last.hmac : null,
        bundleHeadSeq: last ? last.seq : null,
    };
}
/**
 * Sign a checkpoint over the chain head + a content digest over exactly the
 * bundle's events, persist the checkpoint best-effort (provenance only; the
 * bundle is authoritative regardless), and return the self-contained
 * signed bundle envelope.
 *
 * `bundleData` MUST come from `readAuditBundleData(tenantId, from, to)` (ideally
 * within the SAME snapshot executor as the caller's other reads). `from`/`to`
 * are the requested range bounds used only for the advisory `range` field; the
 * signed digest brackets the events actually present.
 *
 * Throws `AuditSigningKeyError` if the signing key is unavailable (the caller
 * maps it to 503). All other signing failures throw a generic Error.
 */
export async function signAuditBundle(tenantId, from, to, bundleData) {
    // Imported lazily-at-module-eval via require-style static imports below.
    const { head, events } = bundleData;
    const digestEvents = events.map((ev) => ({
        tenantId,
        seq: ev.seq,
        actorType: ev.actorType,
        actorId: ev.actorId,
        action: ev.action,
        resourceType: ev.resourceType,
        resourceId: ev.resourceId,
        metadata: ev.metadata,
        ipAddress: ev.ipAddress,
        userAgent: ev.userAgent,
        requestId: ev.requestId,
        createdAt: ev.createdAt,
    }));
    const signer = getCheckpointSigner();
    const nowIso = new Date().toISOString();
    const checkpointPayload = {
        v: 1,
        tenantId,
        seq: head?.expectedSeq ?? 0,
        headHmac: head?.headHmac ?? "",
        expectedCount: head?.expectedCount ?? 0,
        floorSeq: head?.floorSeq ?? 0,
        timestamp: nowIso,
        softwareVersion: API_VERSION,
        eventsDigest: eventsContentDigest(digestEvents),
        eventsFromSeq: events.length > 0 ? events[0].seq : 0,
        eventsToSeq: events.length > 0 ? events[events.length - 1].seq : 0,
    };
    const signed = signer.sign(checkpointPayload);
    // Default/off mode returns synchronously without constructing a sink or
    // touching the network. Required mode throws instead of emitting an
    // unanchored bundle; best-effort mode logs and preserves the v1 envelope.
    const anchorConfiguration = configuredAuditCheckpointAnchor();
    const anchor = await maybeAnchorAuditCheckpoint(signed, anchorConfiguration);
    // Process-local operational gauge only. Durable checkpoint evidence is the
    // signed payload/table below and remains authoritative across restarts.
    try {
        observeAuditCheckpoint(Date.parse(checkpointPayload.timestamp));
    }
    catch {
        // Monitoring is best-effort and cannot affect evidence generation.
    }
    // Persist the checkpoint (append-only provenance). Best-effort: a persistence
    // failure must not deny the auditor their signed bundle (self-contained).
    // Unanchored empty exports retain the historical no-row behavior. Once a
    // third-party proof exists, however, persist it even for the signed empty
    // checkpoint: required mode must never return a proof that has no durable
    // checkpoint binding.
    if (head || anchor) {
        try {
            await getDb()
                .insert(auditCheckpoints)
                .values({
                tenantId,
                seq: checkpointPayload.seq,
                headHmac: hexToBytesLocal(checkpointPayload.headHmac),
                payload: checkpointPayload,
                signature: signed.signature,
                publicKey: signed.publicKey,
                anchorProof: anchor,
                anchorVerifiedAt: anchor ? new Date(anchor.verifiedAt) : undefined,
            });
        }
        catch (err) {
            if (anchor && anchorConfiguration.mode === "required") {
                throw new AuditCheckpointAnchorError("Required RFC 3161 checkpoint proof could not be persisted atomically", { cause: err });
            }
            logger.error({
                details: [
                    `[audit] checkpoint persistence failed for tenant ${tenantId}`,
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:audit] error");
        }
    }
    const includesHead = head != null &&
        bundleData.bundleHeadSeq != null &&
        bundleData.bundleHeadSeq === head.expectedSeq;
    return {
        version: 1,
        tenantId,
        range: { from, to, includesHead },
        canonicalizationSpec: BUNDLE_CANONICALIZATION_SPEC,
        events,
        checkpoint: {
            payload: signed.payload,
            signature: signed.signature,
            publicKey: signed.publicKey,
            ...(anchor ? { anchor } : {}),
        },
        generatedAt: new Date().toISOString(),
    };
}
function hexToBytesLocal(hex) {
    const clean = hex.startsWith("0x") ? hex.slice(2) : hex;
    const out = new Uint8Array(clean.length / 2);
    for (let i = 0; i < out.length; i++) {
        out[i] = Number.parseInt(clean.slice(i * 2, i * 2 + 2), 16);
    }
    return out;
}
//# sourceMappingURL=audit.js.map