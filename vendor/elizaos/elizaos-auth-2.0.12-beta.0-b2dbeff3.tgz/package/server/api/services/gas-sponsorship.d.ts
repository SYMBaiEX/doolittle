import type { GasSponsorshipMode, GasSponsorshipProvider, SponsoredGasSpendSummary, TenantGasSponsorshipConfig } from "../../shared/index.js";
type SponsoredGasChainFamily = "evm" | "solana";
export declare function normalizeGasSponsorshipConfig(value: unknown): TenantGasSponsorshipConfig | string;
export declare function readTenantGasSponsorshipConfig(tenantId: string): Promise<TenantGasSponsorshipConfig>;
export declare function publicGasSponsorshipState(config: TenantGasSponsorshipConfig): {
    enabled: boolean;
    provider: GasSponsorshipProvider | null;
    mode?: GasSponsorshipMode;
    circuitBreakerEnabled?: boolean;
};
export declare function resolveGasSponsorshipRequest(input: {
    tenantId: string;
    agentId?: string;
    chainId: number;
    caip2?: string;
    sponsor?: boolean;
}): Promise<{
    requested: false;
    sponsored: false;
} | {
    requested: true;
    sponsored: true;
    provider: GasSponsorshipProvider;
    mode: GasSponsorshipMode;
    estimatedUsd: number | null;
} | {
    requested: true;
    sponsored: false;
    error: string;
    status: number;
}>;
export declare function recordSponsoredGasEvent(input: {
    tenantId: string;
    agentId: string;
    userId?: string | null;
    txId?: string | null;
    chainFamily?: SponsoredGasChainFamily;
    chainId?: number | null;
    caip2?: string | null;
    provider: GasSponsorshipProvider | string;
    mode: GasSponsorshipMode | string;
    status?: string;
    reservedUsd?: number | string | null;
    actualUsd?: number | string | null;
    txHash?: string | null;
    userOperationHash?: string | null;
    signature?: string | null;
    requestHash?: string | null;
    metadata?: Record<string, unknown>;
}): Promise<void>;
export declare function reserveSponsoredGasEvent(input: {
    tenantId: string;
    agentId: string;
    txId: string;
    chainFamily?: SponsoredGasChainFamily;
    chainId?: number | null;
    caip2?: string | null;
    provider: GasSponsorshipProvider | string;
    mode: GasSponsorshipMode | string;
    reservedUsd: number;
    metadata?: Record<string, unknown>;
}): Promise<undefined | string>;
export declare function normalizeGasSpendQuery(input: {
    walletIds?: string[];
    startTimestamp?: number;
    endTimestamp?: number;
}): {
    walletIds: string[];
    start: Date;
    end: Date;
} | string;
export declare function querySponsoredGasSpend(input: {
    tenantId: string;
    walletIds: string[];
    start: Date;
    end: Date;
}): Promise<SponsoredGasSpendSummary>;
export {};
//# sourceMappingURL=gas-sponsorship.d.ts.map