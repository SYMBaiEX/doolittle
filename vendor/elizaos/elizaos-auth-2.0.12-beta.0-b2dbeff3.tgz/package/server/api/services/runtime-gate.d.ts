/**
 * runtime-gate.ts — pure logic behind the Bun entry's global rate limiter
 * (index.ts). Extracted so the derivation and eviction rules are unit-testable
 * (index.ts itself boots a server at module scope and cannot be imported by
 * tests).
 *
 * Client-supplied forwarding headers are honored only when the operator
 * declares the trusted proxy-hop count (`STEWARD_TRUSTED_PROXY_HOPS`):
 *
 *   - each proxy appends the peer it observed, so with N trusted hops the real
 *     client is the entry N positions from the RIGHT of the XFF list — every
 *     entry to its left is attacker-controlled prefix and ignored;
 *   - with zero trusted hops (default) both forwarding headers are ignored and
 *     the socket peer is used;
 *   - when the chain is shorter than the configured trust, no forwarded entry
 *     is trustworthy; fall back to the socket peer instead of accepting a
 *     client-supplied leftmost value.
 *
 * `X-Real-IP` is never consulted: it carries no chain semantics, so the hop
 * count cannot be applied to it, and whenever XFF is absent/short a direct
 * client can simply spoof it to rotate rate-limit identities. This matches the
 * auth-route resolver (routes/auth.ts), which deliberately ignores it too.
 *
 * The log is also capped (`STEWARD_RATE_LIMIT_MAX_KEYS`): when full it sweeps
 * expired entries inline and then fails CLOSED (429) rather than letting the
 * map grow without bound.
 */
export declare const DEFAULT_RATE_LIMIT_MAX_KEYS = 10000;
/**
 * Key in the Hono `env` bag (app.fetch's second argument) through which a
 * server entry point hands the app the socket peer it observed (Bun's
 * `server.requestIP`). Unlike any request header, this value is set by the
 * runtime and cannot be client-influenced, so downstream rate limiters may
 * key on it when no trusted forwarding config exists (SEC-014 posture
 * extended to the per-route auth limiter). Runtimes without a socket (e.g.
 * Cloudflare Workers) simply never set it.
 */
export declare const SOCKET_PEER_ENV_KEY = "steward.socketPeer";
/** Read the entry-injected socket peer from a Hono context's env bag. */
export declare function socketPeerFromEnv(env: unknown): string | undefined;
export declare function parseNonNegativeInt(value: string | undefined, fallback: number): number;
export declare function parsePositiveInt(value: string | undefined, fallback: number): number;
/**
 * Derive the rate-limit key for a request. `peerAddress` is the socket peer
 * (`server.requestIP()` on Bun; null when the runtime cannot provide it).
 */
export declare function resolveClientIp(headers: Headers, peerAddress: string | null, trustedProxyHops: number): string;
export type RateLimitVerdict = {
    limited: false;
} | {
    limited: true;
    retryAfterSeconds: number;
};
/**
 * Fixed-window in-memory limiter with a hard cap on tracked keys. Only safe
 * for the single-process Bun entry (the Workers entry must not use it).
 */
export declare class InMemoryRateLimiter {
    private readonly maxRequests;
    private readonly windowMs;
    private readonly maxKeys;
    private readonly log;
    constructor(maxRequests: number, windowMs: number, maxKeys?: number);
    check(key: string, now?: number): RateLimitVerdict;
    sweep(now?: number): void;
    clear(): void;
    get size(): number;
}
//# sourceMappingURL=runtime-gate.d.ts.map