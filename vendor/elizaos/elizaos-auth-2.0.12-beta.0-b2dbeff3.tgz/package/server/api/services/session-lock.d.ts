import { type SQLWrapper } from "drizzle-orm";
export declare function lockUserSession(tx: {
    execute: (query: string | SQLWrapper) => unknown;
}, userId: string): Promise<void>;
export declare function lockUserSessions(tx: {
    execute: (query: string | SQLWrapper) => unknown;
}, userIds: string[]): Promise<void>;
//# sourceMappingURL=session-lock.d.ts.map