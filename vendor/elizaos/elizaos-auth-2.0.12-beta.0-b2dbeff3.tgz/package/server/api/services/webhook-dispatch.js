import { randomUUID } from "node:crypto";
import { logger } from "@elizaos/core";
import { and, eq } from "drizzle-orm";
import { hasTenantTransactionDatabase, waitUntilTenantDatabaseTask, webhookConfigs, webhookDeliveries, } from "../../db/index.js";
import { redactedThrownDiagnostics, } from "../../shared/index.js";
import { redactWebhookSecrets } from "../../shared/webhook-redaction.js";
import { decryptWebhookSecret, encryptWebhookSecret, isEncryptedWebhookSecret, PersistentQueue, } from "../../webhooks/index.js";
import { db } from "./context.js";
import { acceptsConfiguredWebhookEvent, toConfiguredWebhookEventType, webhookEventRegistry, } from "./webhook-events.js";
const deliveryQueue = new PersistentQueue();
const activeDeliveries = new Set();
/** Drain deliveries emitted by requests before closing the runtime database. */
export async function drainWebhookDeliveries() {
    while (activeDeliveries.size > 0)
        await Promise.allSettled(activeDeliveries);
}
export { redactWebhookSecrets } from "../../shared/webhook-redaction.js";
export function dispatchWebhook(tenantId, agentId, type, data) {
    const configuredType = toConfiguredWebhookEventType(type);
    // A plugin-declared event is one that is NOT
    // a core configured/alias type but IS present in the runtime
    // WebhookEventRegistry (core ∪ plugin-declared) because the plugin host merged
    // it in. We thread the raw plugin event name into the configured fan-out so a
    // tenant can subscribe to a plugin event specifically (events: ["plugin.evt"]).
    // The configured fan-out only ever matches a plugin event when it is
    // registry-valid AND a config explicitly lists it, so an arbitrary
    // unregistered string can never masquerade as a configured event.
    const isPluginEvent = configuredType === null && webhookEventRegistry.has(type);
    const redactedData = redactWebhookSecrets(data);
    // `type` has passed the emission gate above (it is a configured/aliasable core
    // event OR a plugin event registered in the runtime registry). The widened
    // DispatchableWebhookEventType carries the `(string & {})` arm for plugin
    // events; cast to the WebhookEvent field type now that the name is validated.
    const eventType = (configuredType ?? type);
    const event = {
        type: eventType,
        tenantId,
        agentId,
        data: redactedData,
        timestamp: new Date(),
    };
    // Persist request-emitted events before their tenant transaction closes.
    // The runtime worker delivers them after commit, outside that transaction.
    const delivery = waitUntilTenantDatabaseTask(() => dispatchConfiguredWebhooks(event, configuredType, isPluginEvent ? type : null).catch((error) => {
        logger.error({
            details: [
                "[webhooks] Failed to dispatch configured webhooks",
                redactedThrownDiagnostics(error),
            ],
        }, "[Login:webhook-dispatch] error");
    }));
    activeDeliveries.add(delivery);
    void delivery.then(() => {
        activeDeliveries.delete(delivery);
    }, (error) => {
        activeDeliveries.delete(delivery);
        logger.error({ details: [redactedThrownDiagnostics(error)] }, "[Login:webhook-dispatch] delivery lease failed");
    });
    // SEC-101: the unverifiable tenant-route webhookUrl field is retired. The
    // former second fan-out through a bare URL both duplicate-delivered each
    // event and could only sign with a process-wide key. Persisted /webhooks
    // endpoints with receiver-known per-endpoint secrets are now the sole path.
}
export async function dispatchTestWebhook(config) {
    const event = {
        type: "webhook.test",
        tenantId: config.tenantId,
        agentId: "dashboard",
        data: {
            test: true,
            webhookConfigId: config.id,
            actorId: config.actorId ?? null,
        },
        timestamp: new Date(),
    };
    return dispatchConfiguredWebhook(event, {
        ...config,
        maxRetries: 0,
        retryBackoffMs: 0,
    });
}
export async function dispatchReplayWebhook(config) {
    const originalTimestamp = typeof config.originalPayload.timestamp === "string" ||
        config.originalPayload.timestamp instanceof Date
        ? new Date(config.originalPayload.timestamp)
        : new Date(config.originalCreatedAt);
    const event = {
        type: config.originalEventType,
        tenantId: config.tenantId,
        agentId: typeof config.originalPayload.agentId === "string"
            ? config.originalPayload.agentId
            : (config.originalAgentId ?? undefined),
        data: config.originalPayload.data &&
            typeof config.originalPayload.data === "object"
            ? redactWebhookSecrets(config.originalPayload.data)
            : {},
        timestamp: Number.isNaN(originalTimestamp.getTime())
            ? new Date(config.originalCreatedAt)
            : originalTimestamp,
    };
    return dispatchConfiguredWebhook(event, {
        ...config,
        replayedFromDeliveryId: config.replayedFromDeliveryId,
    });
}
async function dispatchConfiguredWebhooks(event, configuredType, pluginEventType = null) {
    const configs = await db
        .select()
        .from(webhookConfigs)
        .where(and(eq(webhookConfigs.tenantId, event.tenantId), eq(webhookConfigs.enabled, true)));
    await Promise.all(configs
        .filter((config) => {
        // Plugin-declared event (registry-valid, not a core configured type): a
        // config matches when it explicitly lists the event OR is a catch-all
        // (no events filter). It can never match by being a core configured type.
        if (pluginEventType) {
            return (config.events.length === 0 ||
                config.events.includes(pluginEventType));
        }
        return configuredType
            ? acceptsConfiguredWebhookEvent(config.events, configuredType)
            : config.events.length === 0;
    })
        .map((config) => dispatchConfiguredWebhook(event, {
        id: config.id,
        url: config.url,
        secret: config.secret,
        events: config.events,
        maxRetries: config.maxRetries,
        retryBackoffMs: config.retryBackoffMs,
    }, hasTenantTransactionDatabase())));
}
async function dispatchConfiguredWebhook(event, config, deferDelivery = false) {
    const signingSecret = decryptWebhookSecret(config.secret);
    // Plaintext compatibility rows are upgraded lazily with a compare-and-set.
    // This avoids requiring the encryption key during migrations or racing
    // concurrently booting replicas; delivery rows snapshot only ciphertext.
    // A dormant compatibility row remains plaintext until delivery or rotation.
    const encryptedSecret = isEncryptedWebhookSecret(config.secret)
        ? config.secret
        : encryptWebhookSecret(signingSecret);
    if (encryptedSecret !== config.secret) {
        await db
            .update(webhookConfigs)
            .set({ secret: encryptedSecret, updatedAt: new Date() })
            .where(and(eq(webhookConfigs.id, config.id), eq(webhookConfigs.tenantId, event.tenantId), eq(webhookConfigs.secret, config.secret)));
    }
    const deliveryId = randomUUID();
    const signedAt = Math.floor(Date.now() / 1000);
    const eventWithDelivery = {
        ...event,
        deliveryId,
        webhookConfigId: config.id,
        signedAt,
        ...(config.replayedFromDeliveryId
            ? { replayedFromDeliveryId: config.replayedFromDeliveryId }
            : {}),
    };
    const [delivery] = await db
        .insert(webhookDeliveries)
        .values({
        id: deliveryId,
        tenantId: event.tenantId,
        webhookConfigId: config.id,
        agentId: event.agentId,
        eventType: event.type,
        replayedFromDeliveryId: config.replayedFromDeliveryId ?? null,
        payload: eventWithDelivery,
        url: config.url,
        secret: encryptedSecret,
        events: config.events,
        status: "pending",
        attempts: 0,
        maxAttempts: config.maxRetries + 1,
        nextRetryAt: new Date(),
    })
        .returning();
    if (!delivery) {
        throw new Error("Failed to create webhook delivery record");
    }
    if (deferDelivery)
        return delivery;
    await deliveryQueue.processDelivery(delivery.id, event.tenantId);
    const updated = await deliveryQueue.getDelivery(delivery.id, event.tenantId);
    if (!updated)
        throw new Error("Webhook delivery disappeared after dispatch");
    return updated;
}
//# sourceMappingURL=webhook-dispatch.js.map