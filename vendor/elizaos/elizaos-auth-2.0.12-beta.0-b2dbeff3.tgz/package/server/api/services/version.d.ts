/**
 * Exposes the login API protocol version without loading the request context.
 * Audit signing also consumes this value in maintenance scripts and tests.
 */
export declare const API_VERSION: string;
//# sourceMappingURL=version.d.ts.map