/**
 * Both writes happen under the user's session lock. The revocation line is
 * written through the same transaction: a database-backed store then commits it
 * with the deleted refresh tokens, and on the single-connection embedded
 * database it does not queue behind this transaction, which would never end.
 */
export declare function revokeUserRefreshSessions(userId: string): Promise<{
    revoked: {
        id: string;
        createdAt: Date;
        tenantId: string;
        expiresAt: Date;
        userId: string;
        tokenHash: string;
    }[];
    issuedBefore: number;
}>;
//# sourceMappingURL=refresh-session-revocation.d.ts.map