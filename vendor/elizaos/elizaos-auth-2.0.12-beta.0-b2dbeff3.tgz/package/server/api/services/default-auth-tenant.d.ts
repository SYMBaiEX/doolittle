/** Resolve the tenant-less auth target from the active request's immutable environment. */
export declare function defaultAuthTenantId(): string;
//# sourceMappingURL=default-auth-tenant.d.ts.map