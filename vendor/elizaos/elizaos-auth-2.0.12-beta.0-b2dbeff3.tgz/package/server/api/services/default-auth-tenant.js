import { runtimeEnvironmentValue } from "../../shared/runtime-env.js";
/** Resolve the tenant-less auth target from the active request's immutable environment. */
export function defaultAuthTenantId() {
    return (runtimeEnvironmentValue("STEWARD_DEFAULT_TENANT_ID")?.trim() || "default");
}
//# sourceMappingURL=default-auth-tenant.js.map