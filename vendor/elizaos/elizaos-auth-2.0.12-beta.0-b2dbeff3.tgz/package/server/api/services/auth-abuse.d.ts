import type { TenantAuthAbuseConfig, TenantCaptchaAction } from "../../shared/index.js";
export declare function normalizeAuthAbuseConfig(value: unknown): TenantAuthAbuseConfig | string;
export declare function publicAuthAbuseConfig(config: TenantAuthAbuseConfig): TenantAuthAbuseConfig;
/** Lower-cased domain of an email address, or null when it is not a valid host name. */
export declare function normalizeEmailDomain(value: unknown): string | null;
export declare function validateEmailAbusePolicy(email: string, config: TenantAuthAbuseConfig): string | null;
export declare function validateWalletAbusePolicy(walletAddress: string, chain: "ethereum" | "solana", config: TenantAuthAbuseConfig): string | null;
export declare function validatePhoneAbusePolicy(phone: string, config: TenantAuthAbuseConfig): string | null;
export declare function verifyCaptchaToken(config: TenantAuthAbuseConfig, action: TenantCaptchaAction, token: string | undefined, remoteIp?: string): Promise<{
    ok: true;
} | {
    ok: false;
    status: number;
    error: string;
}>;
//# sourceMappingURL=auth-abuse.d.ts.map