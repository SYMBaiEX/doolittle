import type { TenantMfaPolicyConfig } from "../../../contracts/index.js";
export declare function readTenantMfaPolicy(tenantId: string): Promise<TenantMfaPolicyConfig>;
export declare function tenantMfaMaxAgeMs(policy: TenantMfaPolicyConfig, action?: keyof NonNullable<TenantMfaPolicyConfig["requireFor"]>): number;
export declare function tenantMfaRequiredFor(policy: TenantMfaPolicyConfig, action: keyof NonNullable<TenantMfaPolicyConfig["requireFor"]>): boolean;
export declare function tenantMfaDisabledFor(policy: TenantMfaPolicyConfig, action: keyof NonNullable<TenantMfaPolicyConfig["disableFor"]>): boolean;
//# sourceMappingURL=mfa-policy.d.ts.map