/**
 * Optional third-party anchoring for signed audit checkpoints.
 *
 * Disabled means exactly disabled: no sink is constructed and no network call
 * is made. RFC 3161 is the reference implementation; the interface is public
 * so another append-only witness can be supplied without changing bundle
 * assembly.
 */
import { type SignedCheckpoint } from "./audit-checkpoint.js";
export type AuditCheckpointAnchorMode = "off" | "best-effort" | "required";
export interface Rfc3161CheckpointAnchorProof {
    v: 1;
    type: "rfc3161";
    sinkId: string;
    hashAlgorithm: "sha256";
    /** SHA-256 of canonicalCheckpointBytes(checkpoint.payload). */
    checkpointDigest: string;
    /** Request nonce, verified inside the signed TSTInfo by OpenSSL. */
    nonce: string;
    policyOid: string;
    genTime: string;
    accuracyMillis: number;
    verifiedAt: string;
    /** SHA-256 of the operator-configured acquisition trust-anchor PEM bytes. */
    trustAnchorSha256: string;
    /** Base64 DER TimeStampResp, including the TSA certificate when supplied. */
    timestampResponse: string;
}
/** Provider-native evidence from an operator-registered append-only witness. */
export interface CustomCheckpointAnchorProof {
    v: 1;
    type: "custom";
    /** Must equal the provider name used at registration/configuration. */
    provider: string;
    sinkId: string;
    hashAlgorithm: "sha256";
    /** SHA-256 of canonicalCheckpointBytes(checkpoint.payload). */
    checkpointDigest: string;
    /** Time at which the registered verifier accepted this exact proof. */
    verifiedAt: string;
    /** Opaque, JSON-serializable provider proof retained append-only in the bundle/DB. */
    evidence: Record<string, unknown>;
}
export type AuditCheckpointAnchorProof = Rfc3161CheckpointAnchorProof | CustomCheckpointAnchorProof;
export interface AuditCheckpointAnchorSink {
    readonly id: string;
    anchor(checkpoint: SignedCheckpoint): Promise<AuditCheckpointAnchorProof>;
}
export type AuditCheckpointAnchorSinkFactory = () => AuditCheckpointAnchorSink;
export type AuditCheckpointAnchorProofVerifier = (checkpoint: SignedCheckpoint, proof: CustomCheckpointAnchorProof) => Promise<void> | void;
/** Register an operator-supplied append-only witness implementation. */
export declare function registerAuditCheckpointAnchorSink(provider: string, factory: AuditCheckpointAnchorSinkFactory, verify: AuditCheckpointAnchorProofVerifier): () => void;
export interface Rfc3161TimestampSinkOptions {
    url: string;
    timeoutMs?: number;
    fetch?: typeof globalThis.fetch;
    caFile: string;
    untrustedFile?: string;
    expectedPolicyOid?: string;
    maxPastAgeMs?: number;
    maxFutureSkewMs?: number;
    opensslPath?: string;
}
export declare class AuditCheckpointAnchorError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
/** Digest anchored by the TSA. The Ed25519 signature authenticates these bytes separately. */
export declare function auditCheckpointAnchorDigest(checkpoint: SignedCheckpoint): string;
/**
 * DER TimeStampReq v1 with SHA-256 MessageImprint, an unpredictable 128-bit
 * nonce, and certReq=true. The nonce is mandatory: it prevents a previously
 * issued token from satisfying a new required-mode acquisition.
 */
export declare function createRfc3161TimestampQuery(checkpointDigest: string, nonceBytes?: Uint8Array): Uint8Array;
/** Reject malformed, denied, or token-less TSA responses before attaching them. */
export declare function assertGrantedRfc3161Response(bytes: Uint8Array): void;
export interface VerifiedRfc3161Token {
    policyOid: string;
    genTime: string;
    accuracyMillis: number;
    trustAnchorSha256: string;
}
/**
 * Strict acquisition verification. `openssl ts -verify -queryfile` validates
 * the TimeStampResp/CMS SignedData/TSTInfo structure, signed message imprint,
 * signed nonce, signer EKU/signature, and certificate path to `caFile`.
 */
export declare function verifyRfc3161TimestampResponse(input: {
    query: Uint8Array;
    response: Uint8Array;
    caFile: string;
    untrustedFile?: string;
    expectedPolicyOid?: string;
    opensslPath?: string;
    requestStartedAt: number;
    verifiedAt?: number;
    maxPastAgeMs: number;
    maxFutureSkewMs: number;
}): VerifiedRfc3161Token;
export declare class Rfc3161TimestampSink implements AuditCheckpointAnchorSink {
    readonly id = "rfc3161";
    private readonly url;
    private readonly timeoutMs;
    private readonly fetchImpl;
    private readonly options;
    constructor(options: Rfc3161TimestampSinkOptions);
    anchor(checkpoint: SignedCheckpoint): Promise<Rfc3161CheckpointAnchorProof>;
}
export declare function configuredAuditCheckpointAnchor(): {
    mode: AuditCheckpointAnchorMode;
    sink?: AuditCheckpointAnchorSink;
    provider?: string;
    verify?: AuditCheckpointAnchorProofVerifier;
};
/** Anchor according to environment policy; required mode never degrades silently. */
export declare function maybeAnchorAuditCheckpoint(checkpoint: SignedCheckpoint, configured?: {
    mode: AuditCheckpointAnchorMode;
    sink?: AuditCheckpointAnchorSink;
    provider?: string;
    verify?: AuditCheckpointAnchorProofVerifier;
}): Promise<AuditCheckpointAnchorProof | undefined>;
//# sourceMappingURL=audit-checkpoint-anchor.d.ts.map