/** Legacy confidential clients may omit PKCE; supplied bindings must use S256. */
export declare function validOAuthLinkPkce(challenge: unknown, method: unknown): boolean;
/** Verify the stored binding before any provider exchange or account mutation. */
export declare function matchesOAuthLinkPkce(challenge: unknown, method: unknown, verifier: unknown): boolean;
//# sourceMappingURL=oauth-link-pkce.d.ts.map