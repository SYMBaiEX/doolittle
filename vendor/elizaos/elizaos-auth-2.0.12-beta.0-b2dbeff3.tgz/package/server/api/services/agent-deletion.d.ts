import { type AuditEventInput } from "./audit.js";
export type AgentDeletionResult = "deleted" | "missing" | "blocked_by_upstream_lease" | "blocked_by_executing_proxy" | "blocked_by_unresolved_execution";
interface DeleteAgentAuthorityInput {
    tenantId: string;
    agentId: string;
    completionAudit: AuditEventInput;
    beforeDelete?: () => Promise<void>;
}
/**
 * Retire every local authority owned by an agent in one required-audit
 * transaction. Upstream provider credentials are deliberately not revoked or
 * relabeled here: deletion is refused until their independent lifecycle has
 * reached a terminal, secret-free state.
 */
export declare function deleteAgentAuthority(input: DeleteAgentAuthorityInput): Promise<AgentDeletionResult>;
export {};
//# sourceMappingURL=agent-deletion.d.ts.map