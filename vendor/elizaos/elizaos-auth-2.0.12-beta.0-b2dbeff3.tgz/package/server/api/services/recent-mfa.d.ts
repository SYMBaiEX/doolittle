/** Validate a privileged MFA step-up without accepting any future timestamp. */
export declare function isRecentMfaTimestamp(verifiedAt: unknown, maxAgeMs: number, nowMs?: number): boolean;
//# sourceMappingURL=recent-mfa.d.ts.map