import type { Context } from "hono";
/**
 * Best-effort trustworthy client IP, or undefined when none can be derived.
 *
 * - cf-connecting-ip is honored only when STEWARD_TRUST_CLOUDFLARE=true AND
 *   origin ingress is locked to Cloudflare. This service is served directly
 *   by Railway today (no cf-ray), so the flag stays unset and the header is
 *   ignored as client-forgeable.
 * - x-envoy-external-address: Railway's Envoy edge sets this to the single
 *   external client address it observed (possibly with a :port). It is only
 *   consulted once the operator has configured trusted proxy hops — on a bare
 *   deployment a client could set it — and it
 *   identifies the CLIENT only when that edge is the outermost trusted hop,
 *   so with hops >= 2 the positional x-forwarded-for read stays authoritative
 *   and Envoy's value is never used as a fallback.
 * - x-forwarded-for: each trusted proxy APPENDS the peer it observed, so with
 *   N trusted hops the trustworthy entry is the N-th from the RIGHT. The
 *   left-most entry is client-supplied and is never read.
 * - x-real-ip is deliberately not consulted: no proxy in this topology sets
 *   it authoritatively, so a client-set value would pass through verbatim.
 *
 * Every candidate is validated with isIP (after unambiguous :port stripping)
 * so header garbage can never become a rate-limit key or a captcha remoteip.
 * Callers seeing undefined must degrade to a partitioned coarse subject —
 * never a shared "global" bucket, never open.
 */
export declare function trustedClientIp(c: Context): string | undefined;
/**
 * Coarsen an IP for rate-limit keying. IPv4 keys as itself; IPv4-mapped IPv6
 * unwraps to the embedded IPv4 in BOTH spellings (::ffff:a.b.c.d and the hex
 * form ::ffff:aabb:ccdd) so mapped clients share one bucket instead of all
 * collapsing into 0::/64 or splitting across spellings; native IPv6 keys by
 * /64 — providers delegate whole /64s, so full-address buckets would let one
 * host mint 2^64 independent budgets while distinct subscribers almost never
 * share a /64.
 */
export declare function clientIpBucket(ip: string): string;
/**
 * Check a client rate limit for auth endpoints, backed by the Redis sliding
 * window. Subjects come from authRateLimitSubject (trusted client IP, or a
 * coarse per-host fallback whose budget is widened by
 * AUTH_RATE_LIMIT_FALLBACK_HEADROOM) unless subjectOverride is given. The
 * subject is always hashed into the Redis key, so neither PII (destination
 * emails/phones) nor header-controlled bytes ever reach Redis. In production,
 * Redis must be available unless STEWARD_ALLOW_AUTH_RATE_LIMIT_SOFT_FAIL=true
 * (full soft-fail, break-glass only) or the bounded outage valve admits the
 * request (Redis configured but unreachable only). We deliberately do not
 * keep an in-memory fallback Map as a limiter: it is incorrect across
 * multiple instances and impossible on Cloudflare Workers (no shared state
 * across isolates); the outage valve is a single bounded counter, not a
 * per-client map.
 *
 * @param c        - Hono context (used to derive the client subject)
 * @param endpoint - Short name used as part of the Redis key
 * @param windowMs - Window length in milliseconds
 * @param max      - Max requests in the window (×5 for coarse fallback subjects)
 * @param subjectOverride - Per-target subject (e.g. destination email); hashed at key build
 */
type EmbeddedRateLimiter = (key: string, windowMs: number, maximum: number) => Promise<{
    allowed: boolean;
    retryAfterSecs: number;
}>;
/** Binds login attempt budgets to the database owned by the embedded entry. */
export declare function setDatabaseAuthRateLimiter(limiter: EmbeddedRateLimiter | undefined): void;
export declare function checkAuthRateLimit(c: Context, endpoint: string, windowMs: number, max: number, subjectOverride?: string): Promise<{
    allowed: boolean;
    retryAfterSecs?: number;
}>;
/**
 * One deployment-wide budget (no client subject), e.g. the SMS send ceiling
 * that stops pumping traffic rotating IPs and destinations. Same backing store
 * and outage semantics as checkAuthRateLimit; needs no request context.
 */
export declare function checkGlobalAuthBudget(endpoint: string, windowMs: number, max: number): Promise<{
    allowed: boolean;
    retryAfterSecs: number;
}>;
export {};
//# sourceMappingURL=auth-rate-limit.d.ts.map