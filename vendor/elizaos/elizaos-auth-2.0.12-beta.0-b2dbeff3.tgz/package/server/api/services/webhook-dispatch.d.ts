import { webhookDeliveries } from "../../db/index.js";
import { type DispatchableWebhookEventType } from "./webhook-events.js";
/** Drain deliveries emitted by requests before closing the runtime database. */
export declare function drainWebhookDeliveries(): Promise<void>;
export { redactWebhookSecrets } from "../../shared/webhook-redaction.js";
export declare function dispatchWebhook(tenantId: string, agentId: string, type: DispatchableWebhookEventType, data: Record<string, unknown>): void;
export declare function dispatchTestWebhook(config: {
    id: string;
    tenantId: string;
    url: string;
    secret: string;
    events: string[];
    actorId?: string | null;
}): Promise<typeof webhookDeliveries.$inferSelect>;
export declare function dispatchReplayWebhook(config: {
    id: string;
    tenantId: string;
    url: string;
    secret: string;
    events: string[];
    maxRetries: number;
    retryBackoffMs: number;
    replayedFromDeliveryId: string;
    originalPayload: Record<string, unknown>;
    originalEventType: string;
    originalAgentId?: string | null;
    originalCreatedAt: Date | string;
}): Promise<typeof webhookDeliveries.$inferSelect>;
//# sourceMappingURL=webhook-dispatch.d.ts.map