import type { PolicyRule } from "../../shared/index.js";
export declare function validatePolicyRule(policy: unknown): policy is PolicyRule;
export declare function getPolicyRuleValidationError(policy: unknown): string | null;
export declare function getPolicyRulesValidationError(policies: unknown[]): string | null;
//# sourceMappingURL=policy-validation.d.ts.map