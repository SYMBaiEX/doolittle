import type { TenantTestAccountConfig } from "../../shared/index.js";
type TenantTestAccountConfigWithHash = TenantTestAccountConfig & {
    otpHash?: string;
};
export declare function hashTestAccountOtp(otp: string): string;
export declare function testAccountOtpMatches(actual: string | undefined, config: Pick<TenantTestAccountConfigWithHash, "otp" | "otpHash">): boolean;
export declare function createTenantTestAccountConfig(): {
    testAccount: Required<Pick<TenantTestAccountConfig, "enabled" | "email" | "phone" | "createdAt" | "updatedAt">> & Required<Pick<TenantTestAccountConfigWithHash, "otpHash">>;
    otp: string;
};
export declare function publicTestAccount(config: TenantTestAccountConfig | undefined, otp?: string): TenantTestAccountConfig;
export declare function redactedTestAccount(config: TenantTestAccountConfig | undefined): TenantTestAccountConfig;
export {};
//# sourceMappingURL=test-account-credentials.d.ts.map