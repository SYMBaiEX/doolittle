/**
 * EIP-1271 verification helper.
 *
 * Smart contract wallets (Safe, Argent, etc.) cannot use ECDSA recover. They
 * implement `isValidSignature(bytes32 hash, bytes signature) returns (bytes4)`
 * and the magic value `0x1626ba7e` indicates a valid signature.
 *
 * Reference: https://eips.ethereum.org/EIPS/eip-1271
 *
 * We do this manually with viem rather than passing an ethers provider into
 * siwe (siwe@3 still depends on ethers). This way we avoid pulling in ethers
 * just for EIP-1271 verification.
 */
import { type Address, type Hex, type PublicClient } from "viem";
export interface ChainRpcConfig {
    /** Chain ID (e.g. 1 for mainnet, 8453 for Base, 56 for BSC). */
    chainId: number;
    /** JSON-RPC URL. */
    rpcUrl: string;
}
/**
 * Resolve an RPC URL for a given chain ID.
 *
 * Override priority:
 * 1. `SIWE_RPC_<CHAIN_ID>` env var (for production: private RPC URLs)
 * 2. `DEFAULT_PUBLIC_RPCS` fallback for major chains — non-production only
 *
 * SEC-140: the hardcoded public RPCs are a single point of compromise for the
 * EIP-1271 `isValidSignature` decision — a compromised or MITM'd public RPC
 * can forge the magic value and log in as any contract wallet on that chain.
 * Production therefore fails closed (null → "no_rpc") unless the operator
 * configures `SIWE_RPC_<CHAIN_ID>`; the public fallback remains for
 * development convenience.
 *
 * Returns null if no RPC is available for this chain.
 */
export declare function resolveRpcUrl(chainId: number): string | null;
/**
 * Build a viem PublicClient for the given chain. Returns null if no RPC is
 * configured for the chain.
 *
 * Exposed so tests can mock the factory.
 */
export type PublicClientFactory = (chainId: number) => PublicClient | null;
export declare const defaultPublicClientFactory: PublicClientFactory;
export interface VerifyEip1271Args {
    /** Smart contract wallet address (the signer). */
    address: Address;
    /** Original SIWE message text (will be hashed with EIP-191 personal_sign prefix). */
    message: string;
    /** Signature bytes (any length; smart contracts decide what's valid). */
    signature: Hex;
    /** Chain ID where the smart contract wallet is deployed. */
    chainId: number;
    /** Optional override of the public client factory (for tests). */
    clientFactory?: PublicClientFactory;
}
export interface VerifyEip1271Result {
    ok: boolean;
    /** Reason when ok=false. */
    reason?: "no_rpc" | "contract_call_failed" | "signature_invalid";
    /** Wrapped error if a thrown exception caused a contract_call_failed. */
    error?: unknown;
}
/**
 * Verify a signature against a smart contract wallet's `isValidSignature` method.
 *
 * Returns:
 *   { ok: true } if the contract returns the EIP-1271 magic value
 *   { ok: false, reason: "no_rpc" } if no RPC is configured for the chain
 *   { ok: false, reason: "contract_call_failed" } if the RPC call threw
 *     (contract not deployed, address is an EOA, etc.)
 *   { ok: false, reason: "signature_invalid" } if the contract returned a
 *     non-magic value
 */
export declare function verifyEip1271(args: VerifyEip1271Args): Promise<VerifyEip1271Result>;
//# sourceMappingURL=eip1271.d.ts.map