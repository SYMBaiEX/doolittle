export declare function redactWalletMetadataSecrets(metadata: Record<string, unknown> | null | undefined): Record<string, unknown>;
//# sourceMappingURL=wallet-metadata.d.ts.map