export declare function normalizeOptionalText(value: unknown, field: string, maxLength: number): string | null;
export declare function parseCustomTokenList(value: string | undefined): string[] | string | undefined;
export declare function parseOptionalChainId(value: string | undefined): number | string | undefined;
export declare function normalizeInvitationExpiry(value: unknown): Date;
export declare function parseDurationSeconds(value: string): number | null;
export declare function parseHttpTime(value: string | undefined): number | null;
export declare function parseBasicAuth(value: string | undefined | null): {
    username: string;
    password: string;
} | null;
//# sourceMappingURL=route-inputs.d.ts.map