/**
 * Redis-backed real-time enforcement helpers for vault and proxy routes.
 *
 * These supplement the policy engine (which checks DB-based stats) with
 * real-time Redis counters. The policy engine remains the source of truth
 * for policy definitions; Redis provides fast, sliding-window enforcement.
 */
import { type PolicyRule } from "../../shared/index.js";
interface RateLimitParams {
    maxTxPerHour: number;
    maxTxPerDay: number;
}
interface RateLimitHeaderInput {
    limit: number;
    remaining: number;
    resetMs: number;
    retryAfterMs?: number;
}
/**
 * Extract rate-limit parameters from an agent's policy set.
 * Returns null if no enabled rate-limit policy exists.
 */
export declare function extractRateLimitPolicy(policies: PolicyRule[]): RateLimitParams | null;
/**
 * Extract spend-limit parameters from policies.
 *
 * Note: The policy engine uses wei-based spend limits for on-chain transactions.
 * For Redis enforcement, we need USD-based limits. This function extracts the raw
 * wei values; callers should convert to USD using current ETH price if needed.
 *
 * For proxy API call tracking, USD is used directly via the cost estimator.
 */
export declare function extractSpendLimitPolicy(policies: PolicyRule[]): {
    maxPerDay: string;
    maxPerWeek: string;
} | null;
export interface RedisEnforcementResult {
    allowed: boolean;
    reason?: string;
    /** Rate limit headers to include in response */
    headers?: Record<string, string>;
}
export declare function formatRateLimitHeaders(input: RateLimitHeaderInput): Record<string, string>;
/**
 * Run Redis-backed rate limit checks before signing.
 *
 * Checks both hourly and daily windows using sliding-window counters.
 */
export declare function enforceRateLimit(agentId: string, policies: PolicyRule[]): Promise<RedisEnforcementResult>;
/**
 * Record a spend event after successful vault transaction.
 *
 * Converts the native-token wei value to USD via the price oracle (bigint-safe,
 * per-chain native price) before recording. This is for real-time budget
 * tracking; the policy engine's DB-based tracking remains the source of truth.
 */
export declare function recordVaultSpend(agentId: string, tenantId: string, valueWei: string, chainId: number): Promise<void>;
export {};
//# sourceMappingURL=redis-enforcement.d.ts.map