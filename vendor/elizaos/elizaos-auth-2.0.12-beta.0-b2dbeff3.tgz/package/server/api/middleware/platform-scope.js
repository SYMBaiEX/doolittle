import { hasPlatformScope } from "../../auth/index.js";
export function requirePlatformRouteScope(c, scope) {
    if (hasPlatformScope(c.get("platformScopes"), scope))
        return null;
    return c.json({
        ok: false,
        error: `Platform route requires scoped platform key with ${scope}`,
    }, 403);
}
//# sourceMappingURL=platform-scope.js.map