/**
 * request-logger.ts — drop-in replacement for hono's `logger()` that never
 * writes the request QUERY STRING to logs.
 *
 * SEC-015: hono's global logger records `url.slice(url.indexOf("/", 8))` —
 * the full path INCLUDING the query string. Live one-time credentials flow
 * through query strings on GET auth callbacks mounted in this app
 * (`GET /auth/callback/email?token=…`, `GET /auth/oauth/:provider/callback
 * ?code=…&state=…`), so anyone with log access (aggregators, container logs)
 * could replay an unconsumed magic-link token to mint a session. This logger
 * keeps hono's output format but logs only the path (`getPath` strips the
 * query), so credentials in query strings never reach stdout.
 */
export declare const requestLogger: (fn?: (message: string) => void) => any;
//# sourceMappingURL=request-logger.d.ts.map