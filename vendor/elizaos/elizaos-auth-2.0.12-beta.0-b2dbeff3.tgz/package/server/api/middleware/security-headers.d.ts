/**
 * Security response headers — SOC2 CC6.7 (data in transit).
 *
 * Applies HSTS, a deny-by-default CSP, MIME-sniff lock, framing denial,
 * referrer policy, and a restrictive Permissions-Policy. HSTS is skipped for localhost/127.0.0.1
 * and IPv6 loopback hosts and can be disabled globally via STEWARD_HSTS_DISABLED=true for
 * private dev deploys without HTTPS.
 */
import type { MiddlewareHandler } from "hono";
export declare function isHstsEnabled(): boolean;
export declare const securityHeaders: MiddlewareHandler;
//# sourceMappingURL=security-headers.d.ts.map