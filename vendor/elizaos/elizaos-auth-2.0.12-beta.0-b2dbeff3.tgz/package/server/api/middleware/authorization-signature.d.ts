import { KeyStore } from "../../wallet/index.js";
export type AuthorizationSignatureOptions = {
    required?: boolean;
    secrets?: string[];
    appSecretResolver?: (request: Request) => Promise<string[]> | string[];
    tenantKeyStoreFactory?: (masterPassword: string, masterSalt: string | undefined, domain: "secret-vault") => Pick<KeyStore, "decrypt">;
};
export declare function createAuthorizationSignature(input: {
    method: string;
    url: string;
    tenantId?: string;
    authorization?: string;
    apiKey?: string;
    platformKey?: string;
    signerId?: string;
    signerSecret?: string;
    quorumId?: string;
    quorumCredentials?: string;
    timestamp?: string;
    expiresAt?: string;
    idempotencyKey?: string;
    body?: string | ArrayBuffer;
}, secret: string): Promise<string>;
export type AuthorizationCanonicalInput = {
    method: string;
    url: string;
    tenantId?: string;
    authorization?: string;
    apiKey?: string;
    platformKey?: string;
    signerId?: string;
    signerSecret?: string;
    quorumId?: string;
    quorumCredentials?: string;
    timestamp?: string;
    expiresAt?: string;
    idempotencyKey?: string;
    body?: string | ArrayBuffer;
};
/**
 * Build the exact canonical request string that BOTH the HMAC and the P-256
 * verification paths sign. Exported so asymmetric clients (and tests) can
 * reproduce the precise string the middleware reconstructs from the request —
 * keeping the two mechanisms byte-for-byte interchangeable. Changing this
 * changes the wire format for both schemes simultaneously.
 */
export declare function buildAuthorizationCanonicalString(input: AuthorizationCanonicalInput): Promise<string>;
export declare function authorizationSignature(options?: AuthorizationSignatureOptions): any;
export declare const requireAuthorizationSignature: any;
//# sourceMappingURL=authorization-signature.d.ts.map