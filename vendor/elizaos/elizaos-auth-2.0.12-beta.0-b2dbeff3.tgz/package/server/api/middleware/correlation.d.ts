/**
 * Validates or generates a request correlation ID and exposes it to downstream
 * handlers and the response so structured logs can identify the same request.
 */
declare module "hono" {
    interface ContextVariableMap {
        requestId: string;
    }
}
export declare const correlationId: any;
/**
 * Helper to get the current request ID from context.
 * Returns "unknown" if not in a request context.
 */
export declare function getRequestId(c: {
    get: (key: "requestId") => string | undefined;
}): string;
//# sourceMappingURL=correlation.d.ts.map