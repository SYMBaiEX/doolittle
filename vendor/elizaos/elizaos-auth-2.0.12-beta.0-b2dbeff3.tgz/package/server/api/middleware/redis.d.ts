/**
 * Redis middleware — initializes the Redis client and exposes
 * rate-limiting + spend-tracking helpers on the Hono context.
 *
 * When Redis is not configured, the middleware is a no-op and the helpers
 * return documented local-development defaults. If Redis is configured and a
 * money-path/rate-limit helper cannot read it, the helper fails closed.
 */
import { type IoredisLike, type RateLimitResult, type SpendPeriod } from "../../redis/index.js";
/**
 * Try to connect to Redis on startup. If it fails, route-level helpers decide
 * whether to use local-development defaults or fail closed based on whether
 * Redis was configured for this deployment.
 */
export declare function initRedis(env?: Record<string, unknown>): Promise<boolean>;
export declare function isRedisAvailable(): boolean;
export declare function isSpendTelemetryAvailable(): boolean;
export declare function isRateLimitAvailable(): boolean;
export declare function isRedisConfigured(): boolean;
/**
 * Return the active Redis client (real ioredis or upstash adapter), or null
 * if Redis is not available. Call isRedisAvailable() first to check.
 */
export declare function getRedisClient(): IoredisLike | null;
export declare function shutdownRedis(): Promise<void>;
/**
 * Check rate limit for an agent's vault signing requests.
 *
 * Key format: ratelimit:vault:{agentId}:{windowMs}
 */
export declare function checkAgentRateLimit(agentId: string, windowMs: number, maxRequests: number): Promise<RateLimitResult>;
/**
 * Check rate limit for proxy requests.
 *
 * Key format: ratelimit:proxy:{agentId}:{host}:{windowMs}
 */
export declare function checkProxyRateLimit(agentId: string, host: string, windowMs: number, maxRequests: number): Promise<RateLimitResult>;
/**
 * Check if an agent's spending would exceed their limit.
 */
export declare function checkAgentSpendLimit(agentId: string, limitUsd: number, period: SpendPeriod): Promise<{
    allowed: boolean;
    spent: number;
    remaining: number;
}>;
/**
 * Record a spend event after a successful transaction/request.
 */
export declare function recordAgentSpend(agentId: string, tenantId: string, costUsd: number, host: string): Promise<void>;
//# sourceMappingURL=redis.d.ts.map