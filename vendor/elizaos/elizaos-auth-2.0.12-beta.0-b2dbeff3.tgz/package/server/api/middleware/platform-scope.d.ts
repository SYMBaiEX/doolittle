import type { Context } from "hono";
import type { AppVariables } from "../../shared/index.js";
export declare function requirePlatformRouteScope(c: Context<{
    Variables: AppVariables;
}>, scope: string): Response | null;
//# sourceMappingURL=platform-scope.d.ts.map