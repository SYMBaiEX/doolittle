type IdempotencyStatus = "processing" | "completed";
type IdempotencyEntry = {
    fingerprint: string;
    status: IdempotencyStatus;
    createdAt: number;
    expiresAt: number;
    response?: {
        status: number;
        headers: [string, string][];
        body: ArrayBuffer;
    };
};
export type IdempotencyMetricCounters = {
    observed: number;
    reserved: number;
    completed: number;
    replayed: number;
    conflicts: number;
    inFlightConflicts: number;
    suppressedAuthResponses: number;
    invalidKeys: number;
    storeErrors: number;
    skippedUnsafeContext: number;
    releasedOnError: number;
};
export type TenantIdempotencyMetricsSnapshot = {
    tenantId: string;
    generatedAt: string;
    windowStartedAt: string;
    lastSeenAt: string | null;
    ttlMs: number;
    counters: IdempotencyMetricCounters;
};
export type IdempotencyStore = {
    get(key: string): Promise<IdempotencyEntry | undefined>;
    reserve?(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<IdempotencyEntry | undefined>;
    setProcessing(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<void>;
    setCompleted(key: string, response?: NonNullable<IdempotencyEntry["response"]>): Promise<void>;
    delete(key: string): Promise<void>;
};
export declare function getTenantIdempotencyMetrics(tenantId: string, ttlMs?: number): Promise<TenantIdempotencyMetricsSnapshot>;
export declare function resetIdempotencyMetricsForTests(): void;
export declare class MemoryIdempotencyStore implements IdempotencyStore {
    private readonly maxEntries;
    private entries;
    constructor(maxEntries?: number);
    get(key: string): Promise<IdempotencyEntry | undefined>;
    setProcessing(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<void>;
    reserve(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<IdempotencyEntry | undefined>;
    setCompleted(key: string, response?: NonNullable<IdempotencyEntry["response"]>): Promise<void>;
    delete(key: string): Promise<void>;
    clear(): void;
    private collectExpired;
}
export declare class RedisIdempotencyStore implements IdempotencyStore {
    private readonly fallback;
    private client;
    get(key: string): Promise<IdempotencyEntry | undefined>;
    setProcessing(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<void>;
    reserve(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<IdempotencyEntry | undefined>;
    setCompleted(key: string, response?: NonNullable<IdempotencyEntry["response"]>): Promise<void>;
    delete(key: string): Promise<void>;
}
/** Uses the runtime-owned database and its existing durable key/value store. */
export declare class DatabaseIdempotencyStore implements IdempotencyStore {
    private readonly backend;
    get(key: string): Promise<IdempotencyEntry | undefined>;
    setProcessing(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<void>;
    reserve(key: string, entry: Omit<IdempotencyEntry, "status" | "response">): Promise<IdempotencyEntry | undefined>;
    setCompleted(key: string, response?: NonNullable<IdempotencyEntry["response"]>): Promise<void>;
    delete(key: string): Promise<void>;
}
export declare let defaultIdempotencyStore: IdempotencyStore;
/** Select before constructing the app; reset when the owning runtime stops. */
export declare function setDatabaseIdempotencyStore(enabled: boolean): void;
export declare function idempotencyMiddleware(options?: {
    store?: IdempotencyStore;
    ttlMs?: number;
}): any;
export {};
//# sourceMappingURL=idempotency.d.ts.map