/**
 * global-rate-limit.ts — global Redis-backed sliding-window rate limiter for
 * the Cloudflare Workers entry (SEC-068).
 *
 * The Bun entry enforces a global in-memory IP limiter pre-dispatch
 * (`index.ts` runtimeGate). On Workers there is no shared per-isolate state,
 * so only route-specific limiters (auth, vault, proxy) applied and every
 * other endpoint was unthrottled. app.ts mounts this middleware across all
 * routes when it detects the Workers runtime; it reuses the auth surface's
 * shared limiter so subject derivation (trusted client IP, coarse per-host
 * fallback), the bounded Redis-outage valve, and the production fail-closed
 * posture stay identical across entries.
 */
import type { Context, Next } from "hono";
export declare function workersGlobalRateLimit(c: Context, next: Next): Promise<Response | undefined>;
//# sourceMappingURL=global-rate-limit.d.ts.map