/**
 * tenant-cors.ts — Per-tenant dynamic CORS middleware
 *
 * Replaces the global `cors({ origin: "*" })` setup with a middleware that:
 *  - Reads the tenant from the X-Steward-Tenant header
 *  - Looks up that tenant's allowed_origins from tenant_configs
 *  - Validates the request Origin against the list
 *  - Falls back to wildcard (*) for tenants with no configured origins (dev mode)
 *  - Fails closed when tenant origin configuration cannot be loaded
 *  - Caches origin lists in memory with a 60 s TTL to avoid per-request DB hits
 *
 * Usage in index.ts:
 *   import { tenantCors } from "./middleware/tenant-cors";
 *   app.use("*", tenantCors);
 */
import type { Context, Next } from "hono";
/** Evict a tenant's origin list from cache (call after updating tenant config). */
export declare function invalidateTenantCorsCache(tenantId: string): void;
export declare function tenantCors(c: Context, next: Next): Promise<Response | undefined>;
//# sourceMappingURL=tenant-cors.d.ts.map