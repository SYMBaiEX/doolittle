export type RequestExpiryOptions = {
    required?: boolean;
    maxClockSkewMs?: number;
    timestampTtlMs?: number;
    now?: () => number;
};
export declare function requestExpiry(options?: RequestExpiryOptions): any;
export declare const requireRequestExpiry: any;
//# sourceMappingURL=request-expiry.d.ts.map