/**
 * Internal reputation scoring for Steward agents.
 *
 * Produces a 0-100 score used by reputation-based policy evaluators
 * to dynamically gate or scale transaction permissions.
 */
export interface ReputationInput {
    totalTransactions: number;
    successRate: number;
    policyViolationRate: number;
    accountAgeDays: number;
}
/**
 * Calculate an internal reputation score from on-platform metrics.
 *
 * Weights:
 *   success rate        40%
 *   violation inverse   30%
 *   account age         20%  (caps at 365 days)
 *   transaction volume  10%  (caps at 1000 txs)
 *
 * @returns integer 0-100
 */
export declare function calculateInternalReputation(input: ReputationInput): number;
//# sourceMappingURL=reputation.d.ts.map