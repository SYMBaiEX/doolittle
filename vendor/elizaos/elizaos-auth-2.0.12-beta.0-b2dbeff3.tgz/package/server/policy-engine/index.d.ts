/** Exposes transaction policy evaluation, aggregation and approval contracts for the identity service. */
export type { AuditHook, PolicyEngineOptions, PolicyEvaluatedEvent, PolicyEvaluationContext, PolicySimulationRequest, ProxySimulationRequest, TransactionSimulationRequest, } from "./engine.js";
export { PolicyEngine } from "./engine.js";
export type { EvaluatorContext } from "./evaluators.js";
export { evaluatePolicy } from "./evaluators.js";
export type { AggregationEvaluatorContext, AggregationLookup, AggregationQuery, AggregationSnapshot, } from "./evaluators/aggregation.js";
export { aggregationLookupFromMap, aggregationQueriesForPolicies, aggregationQueryKey, evaluateAggregation, NAMED_WINDOW_SECONDS, resolveScopeKey, resolveWindowSeconds, } from "./evaluators/aggregation.js";
export type { LeverageCapContext } from "./evaluators/leverage-cap.js";
export { evaluateLeverageCap } from "./evaluators/leverage-cap.js";
export type { ReputationScalingConfig } from "./evaluators/reputation-scaling.js";
export { computeScaledLimit, evaluateReputationScaling, } from "./evaluators/reputation-scaling.js";
export type { ReputationThresholdConfig } from "./evaluators/reputation-threshold.js";
export { evaluateReputationThreshold } from "./evaluators/reputation-threshold.js";
export type { VenueAllowlistContext } from "./evaluators/venue-allowlist.js";
export { evaluateVenueAllowlist } from "./evaluators/venue-allowlist.js";
export type { ManualApprovalSignal } from "./manual-approval.js";
export { resultRequiresManualApproval } from "./manual-approval.js";
export type { RegisteredPolicyEvaluator } from "./policy-rule-registry.js";
export { CORE_POLICY_RULE_TYPES, evaluateRegisteredPolicy, PolicyRuleRegistry, PolicyRuleRegistryError, policyRuleRegistry, } from "./policy-rule-registry.js";
export type { ReputationInput } from "./reputation.js";
export { calculateInternalReputation } from "./reputation.js";
//# sourceMappingURL=index.d.ts.map