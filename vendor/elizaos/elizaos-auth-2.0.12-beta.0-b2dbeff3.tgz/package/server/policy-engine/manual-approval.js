/**
 * Read the manual-approval signal off any policy result. Returns `true` only
 * for a non-passing result that explicitly opted into manual review. Passing
 * results and plain failures both return `false`, so callers fail closed.
 */
export function resultRequiresManualApproval(result) {
    return result.passed === false && result.requiresManualApproval === true;
}
//# sourceMappingURL=manual-approval.js.map