import { type PolicyResult, type PolicyRule, type PriceOracle, type SignRequest, type TypedDataDomain, type TypedDataField } from "../shared/index.js";
import type { AggregationLookup } from "./evaluators/aggregation.js";
export interface TransactionSimulationRequest extends SignRequest {
    kind?: "transaction";
}
export interface ProxySimulationRequest {
    kind: "proxy";
    method: string;
    url: string;
    body?: unknown;
    data?: unknown;
    value?: string;
    chainId?: number;
}
export type PolicySimulationRequest = TransactionSimulationRequest | ProxySimulationRequest;
export interface PolicyEvaluationContext {
    request: SignRequest;
    recentTxCount24h: number;
    recentTxCount1h: number;
    /**
     * Rolling spend sums in the base unit of `request.chainId` ONLY. Callers
     * MUST scope these counters to the request's chain — a cross-chain sum
     * mixes incomparable units (wei/lamports/piconero) and corrupts both the
     * wei caps and the USD-priced caps (SEC-039).
     */
    spentToday: bigint;
    spentThisWeek: bigint;
    /** Cross-rail USD spend, kept separate from chain-native counters. */
    additionalUsdSpentTodayMicros?: bigint;
    additionalUsdSpentThisWeekMicros?: bigint;
    /** Optional price oracle for USD-based policy evaluation */
    priceOracle?: PriceOracle;
    /** Optional reputation score for reputation-based policies */
    reputationScore?: number;
    /** Sprint 4: trading venue (for `venue-allowlist`). */
    venue?: string;
    /** Sprint 4: requested leverage multiple (for `leverage-cap`). */
    leverage?: number;
    /** Sprint 4: pre-computed USD value of the action. */
    valueUsd?: number;
    /**
     * Privy-style condition set items keyed by conditionSetId. Callers load these
     * from tenant-scoped storage before evaluating policies.
     */
    conditionSets?: Record<string, string[]>;
    /**
     * Authoritative rolling-aggregate lookup for `aggregation` policies. The API
     * wires this from a Redis-backed provider before evaluating; when absent,
     * aggregation policies fail closed (deny).
     */
    aggregations?: AggregationLookup;
    /**
     * Decoded EIP-712 typed-data payload for `typed-data` policies. The API wires
     * this from the validated sign-typed-data request body; absent on ordinary
     * transaction signs.
     */
    typedData?: {
        domain: TypedDataDomain;
        types: Record<string, TypedDataField[]>;
        primaryType: string;
        value: Record<string, unknown>;
    };
    rawSigning?: {
        chain: string;
        curve: string;
    };
    /**
     * Capability-invoke context for `capability-intent` policies. The capability
     * invoke route (W-1c) wires this from the resolved capability; absent on
     * ordinary transaction signs, so capability policies stay inert on tx signing
     * (mirrors the `typedData` seam).
     */
    capability?: {
        name: string;
        args: Record<string, unknown>;
        host: string;
        path: string;
        method: string;
    };
    /**
     * Trailing-hour capability-invoke count (distinct from `recentTxCount1h`). The
     * invoke route (W-1c) wires this so `capability-intent`'s `maxCallsPerHour`
     * constraint can be enforced; absent => that constraint fails closed (deny).
     */
    capabilityInvokeCount1h?: number;
}
export interface EvaluationResult {
    approved: boolean;
    results: PolicyResult[];
    requiresManualApproval: boolean;
}
/**
 * `policy.evaluated` audit event.
 *
 * Engine emits one of these per `evaluate()` call when an audit hook is
 * attached. The shape is intentionally JSON-serialisable so callers can
 * persist it as a row in any audit log table without further mapping.
 * Contains no private keys, no SIWE signatures, no oracle internals.
 */
export interface PolicyEvaluatedEvent {
    event: "policy.evaluated";
    agentId: string;
    tenantId: string;
    venue?: string;
    leverage?: number;
    verdict: "ALLOW" | "NACK" | "NEEDS_MANUAL";
    results: PolicyResult[];
    /** Caller-provided correlation id (e.g. trade-session id, request id). */
    correlationId?: string;
    timestamp: string;
}
export type AuditHook = (event: PolicyEvaluatedEvent) => void | Promise<void>;
export interface PolicyEngineOptions {
    /**
     * Sprint 4: optional sink for `policy.evaluated` audit events. Trade-
     * sessions wires this to the proxy audit log so every evaluation is
     * traceable to its inputs and verdict. Failures inside the hook are
     * swallowed so they don't block the trade — but counted on
     * `auditHookFailures` and logged, so a persistently failing hook cannot
     * silently disable the audit trail (SEC-104).
     */
    auditHook?: AuditHook;
}
/**
 * Policy Engine — evaluates a set of policy rules against a transaction request.
 *
 * Logic:
 * - All enabled policies must pass for auto-approval
 * - If auto-approve-threshold fails but all other policies pass, tx is queued for manual approval
 * - If any hard policy (spending-limit, approved-addresses, rate-limit, time-window) fails, tx is rejected
 */
export declare class PolicyEngine {
    private readonly auditHook?;
    private auditHookFailureCount;
    constructor(options?: PolicyEngineOptions);
    /**
     * Number of audit-hook failures swallowed since engine construction. A
     * growing count means the policy audit trail is silently going dark — hook
     * failures must never block a trade, but they must not be invisible either
     * (SEC-104).
     */
    get auditHookFailures(): number;
    /**
     * Evaluate all policies for an agent's transaction request.
     *
     * Now async to support USD-based evaluations that require price oracle lookups.
     */
    evaluate(policies: PolicyRule[], ctx: PolicyEvaluationContext & {
        correlationId?: string;
    }): Promise<EvaluationResult>;
    private emitAuditEvent;
    /**
     * Evaluate policy simulation input. Transaction requests use the full policy set;
     * proxy/API-call requests only apply rate/spend style controls that are meaningful
     * without an on-chain recipient.
     */
    simulate(policies: PolicyRule[], ctx: Omit<PolicyEvaluationContext, "request"> & {
        request: PolicySimulationRequest;
    }): Promise<EvaluationResult>;
}
//# sourceMappingURL=engine.d.ts.map