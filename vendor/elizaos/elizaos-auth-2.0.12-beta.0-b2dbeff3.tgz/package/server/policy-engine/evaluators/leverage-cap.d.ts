import type { PolicyResult, PolicyRule } from "../../shared/index.js";
export interface LeverageCapContext {
    leverage?: number;
}
export declare function evaluateLeverageCap(rule: PolicyRule, ctx: LeverageCapContext): PolicyResult;
//# sourceMappingURL=leverage-cap.d.ts.map