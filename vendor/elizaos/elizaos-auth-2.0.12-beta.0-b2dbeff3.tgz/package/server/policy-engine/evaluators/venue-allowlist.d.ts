import type { PolicyResult, PolicyRule } from "../../shared/index.js";
export interface VenueAllowlistContext {
    venue?: string;
}
export declare function evaluateVenueAllowlist(rule: PolicyRule, ctx: VenueAllowlistContext): PolicyResult;
//# sourceMappingURL=venue-allowlist.d.ts.map