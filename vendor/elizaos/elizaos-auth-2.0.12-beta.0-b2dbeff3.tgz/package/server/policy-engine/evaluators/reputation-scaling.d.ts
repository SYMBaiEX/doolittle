/**
 * Reputation-scaling policy evaluator.
 *
 * Dynamically computes a per-transaction spending limit based on the
 * agent's reputation score. Higher reputation = higher limit.
 */
import type { PolicyResult, PolicyRule } from "../../shared/index.js";
export interface ReputationScalingConfig {
    /** Base per-tx limit in wei (score = 0) */
    baseMaxPerTx: string;
    /** Maximum per-tx limit in wei (score = 100) */
    maxMaxPerTx: string;
    /** Interpolation curve */
    curve: "linear" | "logarithmic";
}
export interface ReputationScalingContext {
    reputationScore?: number;
    txValue: bigint;
}
/**
 * Compute the effective limit for a given reputation score and config.
 *
 * Total on the score: a non-finite score (NaN/±Infinity from a corrupt
 * reputation feed) is treated as 0 — the lowest limit — rather than throwing
 * inside `BigInt(NaN)` (SEC-105).
 */
export declare function computeScaledLimit(config: ReputationScalingConfig, score: number): bigint;
export declare function evaluateReputationScaling(rule: PolicyRule, ctx: ReputationScalingContext): PolicyResult;
//# sourceMappingURL=reputation-scaling.d.ts.map