/**
 * Reputation-threshold policy evaluator.
 *
 * Gates transactions based on the agent's reputation score.
 * If no score is available in context, falls back to the configured fallbackAction.
 *
 * Each configurable action maps to a distinct engine outcome when the score is
 * below `minScore` (or when no score is available and `fallbackAction` applies):
 *   - `approve`          → `passed: true` (the policy does not block this tx).
 *                         EXCEPTION: as a `fallbackAction` with NO score wired
 *                         it fails closed (deny) — otherwise every rule is a
 *                         hidden default-allow while no score source exists
 *                         (SEC-040).
 *   - `require-approval` → `passed: false` + `requiresManualApproval: true`
 *                          (the engine routes the tx to the manual-approval
 *                          queue instead of hard-rejecting it).
 *   - `block`            → `passed: false` (hard deny).
 *   - anything else      → `passed: false` (fail closed / hard deny).
 *
 * `requiresManualApproval` is an engine-internal signal (see
 * `ManualApprovalSignal` / `engine.ts`); it is structurally compatible with the
 * public `PolicyResult` shape so it never leaks into persisted/serialised
 * results, but the engine honours it for non-`auto-approve-threshold` policies.
 */
import type { PolicyResult, PolicyRule } from "../../shared/index.js";
import type { ManualApprovalSignal } from "../manual-approval.js";
export interface ReputationThresholdConfig {
    minScore: number;
    action: "approve" | "require-approval" | "block";
    source: "internal" | "onchain" | "combined";
    fallbackAction: "approve" | "require-approval" | "block";
}
export interface ReputationThresholdContext {
    reputationScore?: number;
}
export declare function evaluateReputationThreshold(rule: PolicyRule, ctx: ReputationThresholdContext): PolicyResult & ManualApprovalSignal;
//# sourceMappingURL=reputation-threshold.d.ts.map