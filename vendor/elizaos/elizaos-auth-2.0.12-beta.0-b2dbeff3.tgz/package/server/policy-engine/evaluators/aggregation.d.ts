import type { AggregationConditionConfig, AggregationMetric, AggregationScope, PolicyResult, PolicyRule, PriceOracle, SignRequest } from "../../shared/index.js";
/**
 * Resolved rolling-window query the evaluator hands to the provider/lookup.
 * Deterministic given (rule, request, now) so it is trivially testable.
 */
export interface AggregationQuery {
    agentId: string;
    tenantId: string;
    metric: AggregationMetric;
    /** Resolved positive window length in seconds. */
    windowSeconds: number;
    scope: AggregationScope;
    /**
     * Scope discriminator. Empty string for `agent` scope; lowercased recipient
     * address for `per_recipient`; decimal chainId for `per_chain`.
     */
    scopeKey: string;
}
/**
 * A point-in-time snapshot of the rolling aggregate, materialised by the
 * provider from authoritative data. All values are bigint to keep money math
 * exact:
 *   - value_sum         → sum of base units (wei/lamports) in the window
 *   - tx_count          → number of qualifying transactions in the window
 *   - unique_recipients → distinct `to` addresses in the window
 *
 * For USD-denominated `value_sum` conditions the evaluator does the conversion
 * itself via the oracle; the snapshot is always the raw base-unit sum.
 */
export interface AggregationSnapshot {
    /** The aggregate value over the resolved window, in raw integer units. */
    value: bigint;
}
/**
 * Synchronous lookup the evaluation context exposes. Returning `undefined`
 * means "the authoritative aggregate is unavailable" and the evaluator DENIES.
 * Implementations MUST precompute snapshots from server-side state (Redis
 * rolling counters / tx history) before evaluation — they must not derive the
 * value from the request.
 */
export type AggregationLookup = (query: AggregationQuery) => AggregationSnapshot | undefined;
export interface AggregationEvaluatorContext {
    request: SignRequest;
    /** Authoritative rolling-aggregate lookup. Absent → fail closed (deny). */
    aggregations?: AggregationLookup;
    /** Required for USD-denominated conditions; absent → fail closed (deny). */
    priceOracle?: PriceOracle;
    /** Evaluation timestamp in ms (defaults to Date.now()); injectable for tests. */
    now?: number;
}
declare const NAMED_WINDOW_SECONDS: Record<string, number>;
/** Resolve the configured window to a positive integer number of seconds. */
declare function resolveWindowSeconds(config: AggregationConditionConfig): number | null;
/** Derive the scope discriminator from the request for the configured scope. */
declare function resolveScopeKey(scope: AggregationScope, request: SignRequest): string | null;
/**
 * Evaluate a single aggregation condition. Pure aside from the optional async
 * oracle call required by USD denomination.
 */
export declare function evaluateAggregation(rule: PolicyRule, ctx: AggregationEvaluatorContext): Promise<PolicyResult>;
/**
 * Build a stable string key for an {@link AggregationQuery}. Used by callers
 * that precompute snapshots into a map and then expose a synchronous
 * {@link AggregationLookup} over it (the evaluator must stay synchronous while
 * the real provider is async).
 */
export declare function aggregationQueryKey(query: AggregationQuery): string;
/**
 * Resolve the deterministic set of {@link AggregationQuery} a policy set needs
 * for a given request. Returns only the queries for well-formed `aggregation`
 * policies; malformed ones are skipped here and re-validated (and denied) by
 * the evaluator. A caller materialises a snapshot for each query, builds a map
 * keyed by {@link aggregationQueryKey}, and passes a synchronous lookup over it
 * as `ctx.aggregations`.
 */
export declare function aggregationQueriesForPolicies(policies: PolicyRule[], request: SignRequest): AggregationQuery[];
/**
 * Convenience: build a synchronous {@link AggregationLookup} from a precomputed
 * map of `aggregationQueryKey(query) → bigint`. A missing entry yields
 * `undefined`, which makes the evaluator fail closed (deny).
 */
export declare function aggregationLookupFromMap(snapshots: ReadonlyMap<string, bigint>): AggregationLookup;
export { NAMED_WINDOW_SECONDS, resolveScopeKey, resolveWindowSeconds };
//# sourceMappingURL=aggregation.d.ts.map