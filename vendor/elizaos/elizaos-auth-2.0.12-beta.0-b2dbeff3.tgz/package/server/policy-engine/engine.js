import { logger } from "@elizaos/core";
import { redactedThrownDiagnostics, } from "../shared/index.js";
import { evaluatePolicy } from "./evaluators.js";
import { resultRequiresManualApproval, } from "./manual-approval.js";
function isProxyRequest(request) {
    return (request.kind === "proxy" ||
        ("method" in request && "url" in request && !("to" in request)));
}
function extractProxyValue(request) {
    if (request.value !== undefined)
        return String(request.value);
    const candidates = [request.body, request.data];
    for (const candidate of candidates) {
        if (candidate && typeof candidate === "object" && "value" in candidate) {
            const value = candidate.value;
            if (value !== undefined && value !== null)
                return String(value);
        }
    }
    return "0";
}
/**
 * Policy Engine — evaluates a set of policy rules against a transaction request.
 *
 * Logic:
 * - All enabled policies must pass for auto-approval
 * - If auto-approve-threshold fails but all other policies pass, tx is queued for manual approval
 * - If any hard policy (spending-limit, approved-addresses, rate-limit, time-window) fails, tx is rejected
 */
export class PolicyEngine {
    auditHook;
    auditHookFailureCount = 0;
    constructor(options = {}) {
        if (options.auditHook)
            this.auditHook = options.auditHook;
    }
    /**
     * Number of audit-hook failures swallowed since engine construction. A
     * growing count means the policy audit trail is silently going dark — hook
     * failures must never block a trade, but they must not be invisible either
     * (SEC-104).
     */
    get auditHookFailures() {
        return this.auditHookFailureCount;
    }
    /**
     * Evaluate all policies for an agent's transaction request.
     *
     * Now async to support USD-based evaluations that require price oracle lookups.
     */
    async evaluate(policies, ctx) {
        if (policies.length === 0) {
            // "No policies configured" is a deny and MUST be audited like any other
            // — returning before emitAuditEvent leaves no trace of the rejection
            // (SEC-104).
            const evaluationResult = {
                approved: false,
                results: [],
                requiresManualApproval: false,
            };
            await this.emitAuditEvent(ctx, [], evaluationResult);
            return evaluationResult;
        }
        const evaluatorCtx = {
            request: ctx.request,
            recentTxCount24h: ctx.recentTxCount24h,
            recentTxCount1h: ctx.recentTxCount1h,
            spentToday: ctx.spentToday,
            spentThisWeek: ctx.spentThisWeek,
            additionalUsdSpentTodayMicros: ctx.additionalUsdSpentTodayMicros,
            additionalUsdSpentThisWeekMicros: ctx.additionalUsdSpentThisWeekMicros,
            priceOracle: ctx.priceOracle,
            reputationScore: ctx.reputationScore,
            venue: ctx.venue,
            leverage: ctx.leverage,
            valueUsd: ctx.valueUsd,
            conditionSets: ctx.conditionSets,
            aggregations: ctx.aggregations,
            typedData: ctx.typedData,
            rawSigning: ctx.rawSigning,
            capability: ctx.capability,
            capabilityInvokeCount1h: ctx.capabilityInvokeCount1h,
        };
        // SEC-104: an evaluator throw rejects `Promise.all` past the audit call
        // below, erasing the denial from the audit trail. Emit a NACK event before
        // propagating so even a 500-surfacing failure stays traceable. (SEC-105
        // makes config-malformation a structured deny; this catch is the residual
        // guard for unexpected evaluator bugs.)
        let results;
        try {
            results = await Promise.all(policies.map((policy) => evaluatePolicy(policy, evaluatorCtx)));
        }
        catch (err) {
            await this.emitAuditEvent(ctx, [], {
                approved: false,
                results: [],
                requiresManualApproval: false,
            });
            throw err;
        }
        // Same falsy check as evaluatePolicy: a rule with `enabled: undefined`/
        // null/0 is disabled for pass purposes, so an all-such policy set hits
        // this deny-all branch instead of auto-approving everything (SEC-103).
        if (policies.every((policy) => !policy.enabled)) {
            const evaluationResult = {
                approved: false,
                results,
                requiresManualApproval: false,
            };
            await this.emitAuditEvent(ctx, results, evaluationResult);
            return evaluationResult;
        }
        const hardPolicies = results.filter((r) => r.type !== "auto-approve-threshold");
        const autoApproveResults = results.filter((r) => r.type === "auto-approve-threshold");
        // A hard policy either passed, failed-soft (explicitly requesting manual
        // review), or failed-hard. The engine treats these three distinctly:
        //   - any hard-fail            ⇒ outright reject (default-deny preserved)
        //   - no hard-fail, but ≥1 soft ⇒ route to manual approval
        //   - all pass                 ⇒ proceed to the auto-approve check
        // `resultRequiresManualApproval` returns true ONLY for a non-passing result
        // that explicitly opted in, so a plain failure (block, default-deny,
        // missing inputs, unknown policy type) always counts as a hard-fail and
        // cannot be upgraded to "needs manual approval".
        const hardFailed = hardPolicies.some((r) => !r.passed && !resultRequiresManualApproval(r));
        const allHardPass = hardPolicies.every((r) => r.passed);
        const autoApprovePass = autoApproveResults.length === 0 ||
            autoApproveResults.every((r) => r.passed);
        let evaluationResult;
        if (hardFailed) {
            // A hard policy failed without requesting manual review - reject.
            evaluationResult = {
                approved: false,
                results,
                requiresManualApproval: false,
            };
        }
        else if (allHardPass && autoApprovePass) {
            evaluationResult = {
                approved: true,
                results,
                requiresManualApproval: false,
            };
        }
        else {
            // No hard failure, but either a hard policy requested manual review
            // (e.g. reputation-threshold `require-approval`) and/or the value exceeds
            // the auto-approve threshold. Queue for manual approval rather than deny.
            evaluationResult = {
                approved: false,
                results,
                requiresManualApproval: true,
            };
        }
        await this.emitAuditEvent(ctx, results, evaluationResult);
        return evaluationResult;
    }
    async emitAuditEvent(ctx, results, evaluation) {
        if (!this.auditHook)
            return;
        const verdict = evaluation.approved
            ? "ALLOW"
            : evaluation.requiresManualApproval
                ? "NEEDS_MANUAL"
                : "NACK";
        const event = {
            event: "policy.evaluated",
            agentId: ctx.request.agentId,
            tenantId: ctx.request.tenantId,
            ...(ctx.venue !== undefined ? { venue: ctx.venue } : {}),
            ...(ctx.leverage !== undefined ? { leverage: ctx.leverage } : {}),
            verdict,
            results,
            ...(ctx.correlationId !== undefined
                ? { correlationId: ctx.correlationId }
                : {}),
            timestamp: new Date().toISOString(),
        };
        try {
            await this.auditHook(event);
        }
        catch (err) {
            // Audit failures must never block a trade. The engine swallows, but not
            // silently (SEC-104): count and log every failure so a persistently
            // failing hook is visible to operators instead of quietly disabling the
            // whole policy audit trail.
            this.auditHookFailureCount += 1;
            logger.warn({
                details: [
                    `[steward] policy audit hook failed (${this.auditHookFailureCount} since engine start); policy.evaluated events are being dropped`,
                    redactedThrownDiagnostics(err),
                ],
            }, "[Login:engine] warn");
        }
    }
    /**
     * Evaluate policy simulation input. Transaction requests use the full policy set;
     * proxy/API-call requests only apply rate/spend style controls that are meaningful
     * without an on-chain recipient.
     */
    async simulate(policies, ctx) {
        if (!isProxyRequest(ctx.request)) {
            const { kind: _kind, ...request } = ctx.request;
            return this.evaluate(policies, { ...ctx, request });
        }
        const proxyPolicies = policies.filter((policy) => ["rate-limit", "spending-limit", "auto-approve-threshold"].includes(policy.type));
        const syntheticRequest = {
            agentId: "proxy-simulation",
            tenantId: "proxy-simulation",
            to: "0x0000000000000000000000000000000000000000",
            value: extractProxyValue(ctx.request),
            data: typeof ctx.request.data === "string" ? ctx.request.data : undefined,
            chainId: ctx.request.chainId ?? 84532,
        };
        return this.evaluate(proxyPolicies, { ...ctx, request: syntheticRequest });
    }
}
//# sourceMappingURL=engine.js.map