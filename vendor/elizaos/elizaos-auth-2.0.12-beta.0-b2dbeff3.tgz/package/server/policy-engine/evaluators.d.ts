import { type PolicyResult, type PolicyRule, type PriceOracle, type SignRequest, type TypedDataDomain, type TypedDataField } from "../shared/index.js";
import { type AggregationLookup } from "./evaluators/aggregation.js";
import type { ManualApprovalSignal } from "./manual-approval.js";
export interface EvaluatorContext {
    request: SignRequest;
    recentTxCount24h: number;
    recentTxCount1h: number;
    /**
     * Rolling spend sums in the base unit of `request.chainId` ONLY (wei for
     * EVM, lamports for Solana, piconero for Monero...). Callers MUST scope
     * these counters to the request's chain: a cross-chain sum mixes
     * incomparable units, and the USD path re-prices it at this request's chain
     * price — silently under- or over-enforcing the cap (SEC-039).
     */
    spentToday: bigint;
    spentThisWeek: bigint;
    /**
     * Additional committed or conservatively-pending spend denominated in USD
     * micros. This is kept separate from the chain-native counters above: adding
     * USDC base units (or a quoted native equivalent) to wei/lamports would
     * corrupt raw-denominated limits. USD limits apply these amounts
     * conjunctively after pricing the chain-native counters.
     */
    additionalUsdSpentTodayMicros?: bigint;
    additionalUsdSpentThisWeekMicros?: bigint;
    /** Optional price oracle for USD-based policy evaluation */
    priceOracle?: PriceOracle;
    /** Optional reputation score for reputation-based policies */
    reputationScore?: number;
    /**
     * Sprint 4: trading venue the request is destined for. Required by the
     * `venue-allowlist` evaluator. Trade-sessions sets this from the venue
     * adapter dispatch step; non-trade signing requests leave it undefined.
     */
    venue?: string;
    /**
     * Sprint 4: requested leverage multiple (e.g. 2 = 2x). Required by the
     * `leverage-cap` evaluator. Undefined for non-leveraged trades and for
     * spot transfers.
     */
    leverage?: number;
    /**
     * Optional pre-computed USD value of the action. Trade-sessions can
     * populate this so evaluators don't all re-quote the oracle.
     */
    valueUsd?: number;
    conditionSets?: Record<string, string[]>;
    /**
     * Authoritative rolling-aggregate lookup for `aggregation` policies. Callers
     * wire this from a server-side provider (Redis rolling counters / tx
     * history). When absent, aggregation policies fail closed (deny).
     */
    aggregations?: AggregationLookup;
    /**
     * Decoded EIP-712 typed-data payload for `typed-data` policies. Populated
     * ONLY by the typed-data signing route; absent on ordinary transaction
     * signs. A `typed-data` policy is "not applicable" (passes) when this is
     * undefined, so it cannot interfere with normal tx signing.
     */
    typedData?: {
        domain: TypedDataDomain;
        types: Record<string, TypedDataField[]>;
        primaryType: string;
        value: Record<string, unknown>;
    };
    rawSigning?: {
        chain: string;
        curve: string;
    };
    /**
     * Capability-invoke context for `capability-intent` policies. Populated ONLY
     * by the capability invoke route (W-1c); absent on ordinary signing requests,
     * so a `capability-intent` policy is "not applicable" (passes) when this is
     * undefined. Symmetry with `typedData`: capability policies cannot interfere
     * with transaction signing, and transaction policies cannot interfere with
     * capability invokes.
     */
    capability?: {
        name: string;
        args: Record<string, unknown>;
        host: string;
        path: string;
        method: string;
        /** Immutable server-supplied instant for time-window constraints. */
        evaluatedAt?: string;
    };
    /**
     * Rolling count of capability INVOKES in the trailing hour (distinct from
     * `recentTxCount1h`, which counts transaction signs). Populated ONLY by the
     * capability invoke route (W-1c) alongside `capability`. When a
     * `capability-intent` rule sets `constraints.maxCallsPerHour` but this count
     * is absent, the rule FAILS CLOSED (deny) rather than borrowing the tx
     * counter, so an unwired invoke path can never silently pass a rate cap.
     */
    capabilityInvokeCount1h?: number;
}
/**
 * Evaluate a single policy rule against a transaction request.
 * Returns pass/fail with reason, plus an optional `requiresManualApproval`
 * signal (see `./manual-approval`) that the engine honours to route a
 * non-passing "hard" policy to the manual-approval queue instead of a hard
 * deny. The signal is optional, so the return value is structurally still a
 * `PolicyResult`; evaluators that never set it behave exactly as before.
 *
 * Now async to support USD-based evaluations that need price lookups.
 */
export declare function evaluatePolicy(rule: PolicyRule, ctx: EvaluatorContext): Promise<PolicyResult & ManualApprovalSignal>;
//# sourceMappingURL=evaluators.d.ts.map