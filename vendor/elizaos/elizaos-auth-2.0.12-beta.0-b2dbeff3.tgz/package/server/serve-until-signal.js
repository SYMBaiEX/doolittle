/** Reports service readiness and closes owned connections on process termination. */
import { logger } from "@elizaos/core";
export async function serveUntilSignal(server) {
    logger.info({ port: server.port }, "[Login] Identity API listening");
    await new Promise((resolve, reject) => {
        const shutdown = () => {
            process.off("SIGINT", shutdown);
            process.off("SIGTERM", shutdown);
            server.stop().then(resolve, reject);
        };
        process.once("SIGINT", shutdown);
        process.once("SIGTERM", shutdown);
    });
}
//# sourceMappingURL=serve-until-signal.js.map