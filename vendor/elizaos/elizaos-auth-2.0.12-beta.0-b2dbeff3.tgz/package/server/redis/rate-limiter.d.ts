/**
 * Sliding window rate limiter using Redis sorted sets.
 *
 * Uses MULTI/EXEC for atomic check-and-increment.
 * Keys auto-expire after the window passes.
 *
 * Key format: ratelimit:{key}
 * (Caller provides the full key, e.g. ratelimit:{agentId}:{host}:{window})
 */
export interface RateLimitResult {
    /** Whether the request is allowed */
    allowed: boolean;
    /** Remaining requests in the current window */
    remaining: number;
    /** Milliseconds until the window resets (oldest entry expires) */
    resetMs: number;
}
/**
 * Check and increment a sliding window rate limit.
 *
 * Uses a sorted set where:
 * - Score = timestamp (ms)
 * - Member = unique request ID (timestamp + random suffix to avoid collisions)
 *
 * The window slides: we remove all entries older than (now - windowMs),
 * then count remaining entries to determine if under the limit.
 *
 * @param key - Rate limit key (e.g. "ratelimit:agent-123:api.openai.com:60000")
 * @param windowMs - Window size in milliseconds
 * @param maxRequests - Maximum requests allowed in the window
 */
export declare function checkRateLimit(key: string, windowMs: number, maxRequests: number): Promise<RateLimitResult>;
/**
 * Get current rate limit status without incrementing.
 *
 * ADVISORY ONLY: `allowed` (count < maxRequests) mirrors the atomic gate's
 * admit condition but does not itself reserve a slot — enforcement is
 * checkRateLimit. Use this for display, not as the gate.
 */
export declare function getRateLimitStatus(key: string, windowMs: number, maxRequests: number): Promise<RateLimitResult>;
//# sourceMappingURL=rate-limiter.d.ts.map