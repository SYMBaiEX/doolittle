import type { RateLimitResult } from "./rate-limiter.js";
export declare function isCloudflareRateLimitConfigured(): boolean;
export declare function cloudflareRateLimit(operation: "check" | "status", key: string, windowMs: number, maxRequests: number): Promise<RateLimitResult>;
//# sourceMappingURL=cloudflare-rate-limit.d.ts.map