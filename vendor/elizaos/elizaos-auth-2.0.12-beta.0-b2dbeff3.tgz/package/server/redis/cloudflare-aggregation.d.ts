export declare function isCloudflareAggregationConfigured(): boolean;
export declare function cloudflareAggregation(operation: "record" | "read", input: {
    now: number;
    records: Array<{
        key: string;
        member: string;
    }>;
} | {
    now: number;
    key: string;
    windowStart: number;
}): Promise<string[]>;
//# sourceMappingURL=cloudflare-aggregation.d.ts.map