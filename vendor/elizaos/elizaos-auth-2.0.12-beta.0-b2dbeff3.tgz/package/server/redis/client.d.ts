/**
 * Redis client singleton for Steward.
 *
 * Selects an implementation based on the `REDIS_DRIVER` env var:
 *   - "ioredis" (default)  — long-lived TCP connection via the `ioredis`
 *                            package. Used by Bun/Node entry points and
 *                            `getRedis()` returns the underlying client
 *                            unchanged for backward compatibility.
 *   - "upstash"            — HTTP-only adapter over `@upstash/redis`. Used by
 *                            Cloudflare Workers (no TCP). The adapter exposes
 *                            the subset of ioredis method shapes that the
 *                            rate-limiter, spend-tracker, policy-cache, and
 *                            auth `RedisLike` consumer rely on.
 *
 * Reading the connection URL:
 *   - ioredis : REDIS_URL (default redis://localhost:6379). In production the
 *               URL must use rediss:// (TLS) unless it points at localhost or
 *               STEWARD_ALLOW_INSECURE_REDIS=true is set (assertRedisUrlTls).
 *   - upstash : KV_REST_API_URL + KV_REST_API_TOKEN
 *               (or UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN).
 *               In production the REST URL must be https:// — the REST token
 *               rides every request, so http:// exposes it cleartext — unless
 *               it targets localhost or STEWARD_ALLOW_INSECURE_REDIS=true is
 *               set (assertUpstashRestUrlTls).
 */
import { type RedisOptions } from "ioredis";
import { type IoredisLike } from "./upstash-adapter.js";
export type RedisDriver = "ioredis" | "upstash";
/**
 * Refuse to start in production if REDIS_URL is not using TLS (rediss://).
 * Redis carries spend-limit state, rate-limit state, policy cache, and auth KV
 * (SIWE nonces), so a cleartext link lets a network-positioned attacker read
 * and tamper with enforcement data. Localhost connections are exempt. Set
 * STEWARD_ALLOW_INSECURE_REDIS=true to override for private-network
 * deployments (logs a loud warning), matching the STEWARD_ALLOW_INSECURE_DB
 * posture in server/db.
 */
export declare function assertRedisUrlTls(url: string, env?: NodeJS.ProcessEnv): void;
/**
 * SEC-032, upstash path: the Upstash REST token authenticates every request,
 * so a cleartext http:// endpoint exposes it (and lets a network-positioned
 * attacker read/tamper with spend-limit, rate-limit, and auth KV state) even
 * though the ioredis path is TLS-asserted. In production require https://
 * unless the endpoint is loopback; STEWARD_ALLOW_INSECURE_REDIS=true overrides
 * (loud warning), matching assertRedisUrlTls.
 */
export declare function assertUpstashRestUrlTls(url: string, env?: NodeJS.ProcessEnv): void;
/** Trust an optional private CA only for this Redis connection. */
export declare function getRedisTlsOptions(url: string, env?: NodeJS.ProcessEnv): RedisOptions["tls"];
export declare function getRedisDriver(): RedisDriver;
/**
 * Get the Redis client singleton.
 * Creates the connection on first call.
 */
export declare function getRedis(): IoredisLike;
/**
 * Disconnect and reset the singleton (useful for tests).
 */
export declare function disconnectRedis(): Promise<void>;
export type { IoredisLike };
//# sourceMappingURL=client.d.ts.map