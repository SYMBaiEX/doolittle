/**
 * Rolling-window aggregation tracker (Privy "aggregations" parity).
 *
 * Backs the policy-engine `aggregation` policy type. Records authoritative
 * per-agent activity into Redis sorted sets keyed by timestamp, then
 * materialises rolling-window aggregates (value sums, tx counts, unique
 * recipients) grouped by scope (agent / per-recipient / per-chain).
 *
 * The aggregate is ALWAYS computed here from server-side records — it is never
 * read from a caller-supplied request body. The policy evaluator consumes a
 * precomputed snapshot map and fails closed when a snapshot is absent.
 *
 * Sorted-set model (mirrors the sliding-window rate-limiter):
 *   key    = agg:{agentId}:{metricFamily}:{scope}:{scopeKey}
 *   score  = event timestamp (ms)
 *   member = "{ts}:{seq}|{payload}"
 *            payload is the wei amount for value sums, the lowercased recipient
 *            for unique-recipient sets, or empty for plain counts. The
 *            "{ts}:{seq}" prefix keeps members unique within a millisecond.
 *
 * Window boundary: a window of S seconds at time `now` covers the HALF-OPEN
 * interval `(now - S*1000, now]`. An event exactly S seconds old has aged out
 * and is excluded; an event at `now` is included. This matches the evaluator's
 * documented convention so off-by-one window math cannot flip a verdict.
 */
export type AggregationMetricFamily = "value" | "count" | "recipients";
export type AggregationScope = "agent" | "per_recipient" | "per_chain";
/** A single authoritative activity event to fold into the rolling aggregates. */
export interface AggregationEvent {
    agentId: string;
    /** Recipient address (lowercased on write). Required for per_recipient scope. */
    to: string;
    /** Numeric chain id. Required for per_chain scope. */
    chainId: number;
    /** Transferred value in raw base units (wei/lamports), decimal string. */
    valueRaw: string;
    /** Event time in ms; defaults to now. Injectable for tests. */
    timestamp?: number;
}
/** Query describing the rolling aggregate the evaluator wants materialised. */
export interface AggregationSnapshotQuery {
    agentId: string;
    metric: "value_sum" | "tx_count" | "unique_recipients";
    windowSeconds: number;
    scope: AggregationScope;
    /** "" for agent scope, lowercased recipient, or decimal chainId. */
    scopeKey: string;
}
/**
 * Record one authoritative activity event. Call this AFTER a transaction is
 * committed/settled (mirrors how spend/rate counters are written), inside the
 * same per-agent serialization window used for spend caps.
 */
export declare function recordAggregationEvent(event: AggregationEvent): Promise<void>;
/**
 * Materialise a single rolling-window snapshot from authoritative records.
 * Returns the aggregate as a bigint (raw base units / counts). Returns null on
 * any I/O or parse failure so the caller can fail closed (deny).
 */
export declare function getAggregationSnapshot(query: AggregationSnapshotQuery, now?: number): Promise<bigint | null>;
//# sourceMappingURL=aggregation-tracker.d.ts.map