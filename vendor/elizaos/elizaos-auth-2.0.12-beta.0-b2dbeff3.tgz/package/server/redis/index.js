/** Exposes Redis connections, rate limits, transaction spend and policy caches. */
export { getAggregationSnapshot, recordAggregationEvent, } from "./aggregation-tracker.js";
export { assertRedisUrlTls, assertUpstashRestUrlTls, disconnectRedis, getRedis, getRedisDriver, getRedisTlsOptions, } from "./client.js";
export { getCachedPolicies, invalidateCache, invalidateTenantCache, setCachedPolicies, } from "./policy-cache.js";
export { checkRateLimit, getRateLimitStatus, } from "./rate-limiter.js";
export { checkSpendLimit, getSpend, getSpendByHost, recordSpend, reserveSpend, settleReservedSpend, } from "./spend-tracker.js";
export { createUpstashIoredisAdapter } from "./upstash-adapter.js";
//# sourceMappingURL=index.js.map