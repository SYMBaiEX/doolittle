/**
 * Upstash REST → ioredis-shaped adapter.
 *
 * Lets the existing rate-limiter, spend-tracker, policy-cache, and auth-store
 * code keep using the ioredis call shapes they already know, while routing
 * through Upstash's HTTP/REST API at runtime. This is what makes the Steward
 * API work on Cloudflare Workers (no TCP, no long-lived connection).
 *
 * The adapter is intentionally narrow — only the operations Steward actually
 * uses are mapped. Adding a new operation is a one-line forward.
 *
 * Differences vs ioredis worth knowing:
 *   - `set(key, value, "PX", ttlMs)` → `set(key, value, { px: ttlMs })`
 *   - `setex(key, ttl, value)`       → `setex(key, ttl, value)`  (same)
 *   - `zrange(key, 0, 0, "WITHSCORES")` → returns [member, score, ...]
 *     (Upstash returns [{member, score}], we flatten)
 *   - `multi()/.exec()` returns the raw result array; we wrap it in the
 *     `[err, val]` tuple shape that ioredis (and our existing code) expects.
 *   - `scan(cursor, "MATCH", pattern, "COUNT", n)` → `scan(cursor, {match, count})`
 */
import type { Redis as UpstashRedis } from "@upstash/redis";
/**
 * Subset of the ioredis surface that Steward consumes. Both the real
 * ioredis client and the upstash adapter satisfy this shape.
 */
export interface IoredisLike {
    set(key: string, value: string): Promise<string | null>;
    set(key: string, value: string, mode: "PX", ttlMs: number): Promise<string | null>;
    set(key: string, value: string, mode: "PX", ttlMs: number, condition: "NX"): Promise<string | null>;
    get(key: string): Promise<string | null>;
    getdel(key: string): Promise<string | null>;
    del(...keys: string[]): Promise<number>;
    setex(key: string, ttlSeconds: number, value: string): Promise<string>;
    expire(key: string, ttlSeconds: number): Promise<number>;
    pexpire(key: string, ttlMs: number): Promise<number>;
    hincrby(key: string, field: string, increment: number): Promise<number>;
    hset(key: string, field: string, value: string): Promise<number>;
    hget(key: string, field: string): Promise<string | null>;
    hgetall(key: string): Promise<Record<string, string>>;
    zadd(key: string, score: number, member: string): Promise<number | null>;
    zcard(key: string): Promise<number>;
    zrem(key: string, ...members: string[]): Promise<number>;
    zrange(key: string, start: number, stop: number, withscores?: "WITHSCORES"): Promise<string[]>;
    zremrangebyscore(key: string, min: number, max: number): Promise<number>;
    scan(cursor: string | number, match: "MATCH", pattern: string, count: "COUNT", countValue: number): Promise<[string, string[]]>;
    eval(script: string, numKeys: number, ...args: (string | number)[]): Promise<unknown>;
    multi(): IoredisPipelineLike;
    ping(): Promise<string>;
    quit?(): Promise<unknown>;
}
export interface IoredisPipelineLike {
    zremrangebyscore(key: string, min: number, max: number): IoredisPipelineLike;
    zadd(key: string, score: number, member: string): IoredisPipelineLike;
    zcard(key: string): IoredisPipelineLike;
    zrange(key: string, start: number, stop: number, withscores?: "WITHSCORES"): IoredisPipelineLike;
    pexpire(key: string, ttlMs: number): IoredisPipelineLike;
    hincrby(key: string, field: string, increment: number): IoredisPipelineLike;
    hset(key: string, field: string, value: string): IoredisPipelineLike;
    expire(key: string, ttlSeconds: number): IoredisPipelineLike;
    /**
     * Queue a server-side Lua script inside the transaction. ioredis positional
     * form (numKeys, ...keysThenArgs) — the Upstash implementation maps it to
     * (script, keys[], args[]). Used by the spend-tracker settle clamp.
     */
    eval(script: string, numKeys: number, ...args: (string | number)[]): IoredisPipelineLike;
    /**
     * Returns ioredis-style [err, value] tuples for each queued command, in
     * order. Errors are swallowed into the per-command tuple so callers see
     * `null` in the err slot on success and an Error instance on failure.
     */
    exec(): Promise<Array<[Error | null, unknown]> | null>;
}
/**
 * Wrap an `@upstash/redis` client in an ioredis-shaped facade.
 */
export declare function createUpstashIoredisAdapter(upstash: UpstashRedis): IoredisLike;
//# sourceMappingURL=upstash-adapter.d.ts.map