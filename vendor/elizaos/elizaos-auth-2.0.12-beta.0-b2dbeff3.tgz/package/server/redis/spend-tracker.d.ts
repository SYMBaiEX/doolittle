/**
 * Per-agent spend tracking with time-bucketed Redis keys.
 *
 * Key format: spend:{agentId}:{period}:{dateKey}
 * Values stored as USD cents (integer) to avoid floating point issues.
 *
 * TTLs:
 *   day   → 2 days   (172800s)
 *   week  → 8 days   (691200s)
 *   month → 32 days  (2764800s)
 */
export type SpendPeriod = "day" | "week" | "month";
type SpendLimitMap = Partial<Record<SpendPeriod, number>>;
export interface SpendLimitSnapshot {
    allowed: boolean;
    spent: number;
    reserved: number;
    effectiveSpent: number;
    remaining: number;
}
export interface SpendReservation {
    reservedUsd: number;
    periods: SpendPeriod[];
    buckets: Array<{
        period: SpendPeriod;
        dateKey: string;
        key: string;
    }>;
}
/**
 * ISO-8601 week number + ISO week-year (Thursday-based). Days near a year
 * boundary may belong to the previous/next ISO week-year, so we return both.
 */
export declare function isoWeek(date: Date): {
    isoYear: number;
    isoWeek: number;
};
/**
 * Record a spend event. Increments the spend counter for all periods
 * (day, week, month) atomically.
 *
 * Also stores per-host breakdown as hash fields.
 *
 * @param agentId - The agent's ID
 * @param tenantId - The tenant's ID (stored in hash for querying)
 * @param costUsd - Cost in USD (e.g. 0.03 for 3 cents)
 * @param host - The API host (e.g. "api.openai.com")
 */
export declare function recordSpend(agentId: string, tenantId: string, costUsd: number, host: string): Promise<void>;
/**
 * Reserve in-flight spend before a request leaves the proxy.
 *
 * The reservation is kept separate from settled spend but checkSpendLimit counts
 * both fields. Each period is incremented first and rolled back if the effective
 * spend crosses that period's configured limit.
 */
export declare function reserveSpend(agentId: string, tenantId: string, reserveUsd: number, limits: SpendLimitMap): Promise<SpendReservation>;
/**
 * Settle an earlier reservation after the upstream response is known.
 *
 * If actual spend cannot be calculated, callers should pass the reserved amount
 * to avoid turning parsing failures into free budget bypasses.
 */
export declare function settleReservedSpend(agentId: string, tenantId: string, reservedUsd: number, actualUsd: number, host: string, periods: SpendPeriod[], buckets?: SpendReservation["buckets"]): Promise<void>;
/**
 * Get total spend for an agent in a given period.
 *
 * @returns Spend in USD
 */
export declare function getSpend(agentId: string, period: SpendPeriod, date?: Date): Promise<number>;
/**
 * Check if an agent is within their spend limit.
 *
 * ADVISORY ONLY: this is a status read with no pending amount, so `allowed`
 * means "budget not yet fully consumed". The real enforcement is the atomic
 * gate in reserveSpend — never admit a request on this alone.
 *
 * @returns Whether the agent can spend more, how much they've spent, and remaining budget
 */
export declare function checkSpendLimit(agentId: string, limitUsd: number, period: SpendPeriod): Promise<SpendLimitSnapshot>;
/**
 * Get per-host spend breakdown for an agent in a given period.
 */
export declare function getSpendByHost(agentId: string, period: SpendPeriod, date?: Date): Promise<Record<string, number>>;
export {};
//# sourceMappingURL=spend-tracker.d.ts.map