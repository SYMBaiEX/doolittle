/**
 * Upstash REST → ioredis-shaped adapter.
 *
 * Lets the existing rate-limiter, spend-tracker, policy-cache, and auth-store
 * code keep using the ioredis call shapes they already know, while routing
 * through Upstash's HTTP/REST API at runtime. This is what makes the Steward
 * API work on Cloudflare Workers (no TCP, no long-lived connection).
 *
 * The adapter is intentionally narrow — only the operations Steward actually
 * uses are mapped. Adding a new operation is a one-line forward.
 *
 * Differences vs ioredis worth knowing:
 *   - `set(key, value, "PX", ttlMs)` → `set(key, value, { px: ttlMs })`
 *   - `setex(key, ttl, value)`       → `setex(key, ttl, value)`  (same)
 *   - `zrange(key, 0, 0, "WITHSCORES")` → returns [member, score, ...]
 *     (Upstash returns [{member, score}], we flatten)
 *   - `multi()/.exec()` returns the raw result array; we wrap it in the
 *     `[err, val]` tuple shape that ioredis (and our existing code) expects.
 *   - `scan(cursor, "MATCH", pattern, "COUNT", n)` → `scan(cursor, {match, count})`
 */
class UpstashPipeline {
    upstash;
    ops = [];
    constructor(upstash) {
        this.upstash = upstash;
    }
    zremrangebyscore(key, min, max) {
        this.ops.push((m) => m.zremrangebyscore(key, min, max));
        return this;
    }
    zadd(key, score, member) {
        this.ops.push((m) => m.zadd(key, { score, member }));
        return this;
    }
    zcard(key) {
        this.ops.push((m) => m.zcard(key));
        return this;
    }
    zrange(key, start, stop, withscores) {
        this.ops.push((m) => m.zrange(key, start, stop, { withScores: withscores === "WITHSCORES" }));
        return this;
    }
    pexpire(key, ttlMs) {
        this.ops.push((m) => m.pexpire(key, ttlMs));
        return this;
    }
    hincrby(key, field, increment) {
        this.ops.push((m) => m.hincrby(key, field, increment));
        return this;
    }
    hset(key, field, value) {
        this.ops.push((m) => m.hset(key, { [field]: value }));
        return this;
    }
    expire(key, ttlSeconds) {
        this.ops.push((m) => m.expire(key, ttlSeconds));
        return this;
    }
    eval(script, numKeys, ...args) {
        // Same positional→array mapping as the client-level eval below.
        const keys = args.slice(0, numKeys).map(String);
        const argv = args.slice(numKeys).map(String);
        this.ops.push((m) => m.eval(script, keys, argv));
        return this;
    }
    async exec() {
        const multi = this.upstash.multi();
        for (const op of this.ops)
            op(multi);
        let raw;
        try {
            raw = (await multi.exec());
        }
        catch (err) {
            // Upstash throws a single error if the whole transaction fails.
            // Mirror ioredis: every slot gets the same error.
            const error = err instanceof Error ? err : new Error(String(err));
            return this.ops.map(() => [error, null]);
        }
        return this.ops.map((_, i) => [null, raw[i]]);
    }
}
// ─── Adapter ──────────────────────────────────────────────────────────────────
/**
 * Wrap an `@upstash/redis` client in an ioredis-shaped facade.
 */
export function createUpstashIoredisAdapter(upstash) {
    return {
        // Strings
        async set(key, value, mode, ttlMs, condition) {
            if (mode === "PX" && typeof ttlMs === "number") {
                return condition === "NX"
                    ? upstash.set(key, value, { px: ttlMs, nx: true })
                    : upstash.set(key, value, { px: ttlMs });
            }
            return upstash.set(key, value);
        },
        async get(key) {
            // Upstash auto-deserializes any value that looks like JSON — booleans,
            // numbers, arrays, objects — even though our callers store the value as
            // a string and call JSON.parse themselves (e.g. policy-cache stores
            // JSON.stringify(policies)). If we don't normalize back to a string,
            // policy-cache double-parses, treats the value as corrupted, and deletes
            // the entry, defeating the cache under the Upstash driver.
            const raw = (await upstash.get(key));
            if (raw === null || raw === undefined)
                return null;
            if (typeof raw === "string")
                return raw;
            try {
                return JSON.stringify(raw);
            }
            catch {
                return null;
            }
        },
        async getdel(key) {
            // Upstash supports GETDEL natively, preserving the atomic
            // read-and-delete that one-time-token consumption relies on.
            //
            // Apply the same normalization as get(): Upstash auto-deserializes any
            // value that looks like JSON, but our callers store values as strings
            // and JSON.parse them themselves (e.g. consumeSiweNonce does
            // JSON.parse(raw)). If we returned the deserialized object, the caller's
            // JSON.parse would coerce it to "[object Object]" and silently lose the
            // record. Normalizing back to a string keeps the round-trip intact.
            const raw = (await upstash.getdel(key));
            if (raw === null || raw === undefined)
                return null;
            if (typeof raw === "string")
                return raw;
            try {
                return JSON.stringify(raw);
            }
            catch {
                return null;
            }
        },
        async del(...keys) {
            if (keys.length === 0)
                return 0;
            return upstash.del(...keys);
        },
        setex(key, ttlSeconds, value) {
            return upstash.setex(key, ttlSeconds, value);
        },
        expire(key, ttlSeconds) {
            return upstash.expire(key, ttlSeconds);
        },
        pexpire(key, ttlMs) {
            return upstash.pexpire(key, ttlMs);
        },
        // Hashes
        hincrby(key, field, increment) {
            return upstash.hincrby(key, field, increment);
        },
        async hset(key, field, value) {
            return upstash.hset(key, { [field]: value });
        },
        async hget(key, field) {
            const v = await upstash.hget(key, field);
            return v ?? null;
        },
        async hgetall(key) {
            const all = await upstash.hgetall(key);
            return all ?? {};
        },
        // Sorted sets
        zadd(key, score, member) {
            return upstash.zadd(key, { score, member });
        },
        zcard(key) {
            return upstash.zcard(key);
        },
        zrem(key, ...members) {
            if (members.length === 0)
                return Promise.resolve(0);
            return upstash.zrem(key, ...members);
        },
        async zrange(key, start, stop, withscores) {
            const result = (await upstash.zrange(key, start, stop, {
                withScores: withscores === "WITHSCORES",
            }));
            if (withscores !== "WITHSCORES") {
                return result.map((r) => String(r));
            }
            // Upstash with withScores returns [member, score, member, score, ...].
            // ioredis returns the same flat shape, so we just stringify.
            return result.map((r) => String(r));
        },
        zremrangebyscore(key, min, max) {
            return upstash.zremrangebyscore(key, min, max);
        },
        // Scan
        async scan(cursor, _match, pattern, _count, countValue) {
            const [next, keys] = await upstash.scan(cursor, {
                match: pattern,
                count: countValue,
            });
            return [String(next), keys];
        },
        // Scripting — Upstash runs EVAL server-side, preserving the atomicity the
        // rate-limiter/spend-tracker scripts rely on. ioredis takes positional
        // (numKeys, ...keysThenArgs); Upstash takes (script, keys[], args[]).
        async eval(script, numKeys, ...args) {
            const keys = args.slice(0, numKeys).map(String);
            const argv = args.slice(numKeys).map(String);
            return upstash.eval(script, keys, argv);
        },
        // Pipeline / transaction
        multi() {
            return new UpstashPipeline(upstash);
        },
        // Connection lifecycle
        async ping() {
            const result = await upstash.ping();
            return result ?? "PONG";
        },
        // Upstash has no persistent connection to close; quit() is a no-op.
        async quit() {
            return "OK";
        },
    };
}
//# sourceMappingURL=upstash-adapter.js.map