export declare function isCloudflareSpendMetricsConfigured(): boolean;
export declare function recordCloudflareSpendMetrics(input: {
    buckets: Array<{
        key: string;
        ttlSeconds: number;
    }>;
    units: number;
    tenantId: string;
    host: string;
}): Promise<void>;
export declare function readCloudflareSpendMetrics(key: string): Promise<{
    total: number;
    hosts: Record<string, number>;
}>;
export declare function recordCloudflareReplayMetric(tenantId: string, counter: string, now: number, ttlSeconds: number): Promise<void>;
export declare function readCloudflareReplayMetrics(tenantId: string): Promise<Record<string, string> | null>;
//# sourceMappingURL=cloudflare-spend-metrics.d.ts.map