/**
 * Policy definition cache backed by Redis.
 *
 * Caches policy definitions with a 30-second TTL to reduce DB queries
 * during high-throughput proxy operation.
 *
 * Key format: policies:{tenantId}:{agentId}
 */
/**
 * Minimal policy interface — matches what the policy engine needs.
 * Using a loose type here to avoid coupling to server/shared versioning.
 */
export interface CachedPolicy {
    id: string;
    type: string;
    name: string;
    enabled: boolean;
    priority: number;
    definition: Record<string, unknown>;
    scope?: Record<string, unknown>;
}
/**
 * Get cached policies for an agent.
 *
 * @returns Cached policies array, or null if cache miss / expired.
 */
export declare function getCachedPolicies(agentId: string, tenantId: string): Promise<CachedPolicy[] | null>;
/**
 * Cache policies for an agent.
 *
 * @param ttlSeconds - Cache TTL in seconds (default: 30)
 */
export declare function setCachedPolicies(agentId: string, tenantId: string, policies: CachedPolicy[], ttlSeconds?: number): Promise<void>;
/**
 * Invalidate cached policies for an agent.
 * Called on policy CRUD operations to ensure fresh data.
 */
export declare function invalidateCache(agentId: string, tenantId?: string): Promise<void>;
/**
 * Invalidate ALL policy caches for a tenant.
 * Useful when tenant-wide policies change.
 */
export declare function invalidateTenantCache(tenantId: string): Promise<void>;
//# sourceMappingURL=policy-cache.d.ts.map