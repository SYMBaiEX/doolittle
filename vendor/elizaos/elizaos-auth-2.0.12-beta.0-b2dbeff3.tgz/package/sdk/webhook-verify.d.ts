/**
 * Webhook signature verification — for consumers receiving HMAC-signed events.
 *
 * Server side (packages/webhooks/dispatcher.ts) signs with HMAC-SHA-256 over a
 * versioned canonical string and ships the digest in `X-Steward-Signature`.
 *
 * Scheme v2 (current): the header value is `v2=<hex>` and the signed material is
 *   `v2:${timestamp}.${deliveryId}.${eventType}.${body}`
 * binding the dispatch timestamp, a stable per-delivery nonce (`X-Steward-Delivery-Id`)
 * and the event type (`X-Steward-Event`) into the HMAC. This prevents replaying a
 * captured/persisted event with a tampered event type, and deliveryId is stable across retries while each attempt gets a fresh timestamp.
 *
 * Legacy (backward-compat, opt-in): a bare hex digest over `${timestamp}.${body}`
 * or — with `allowLegacyBodySignature` — the raw body. Body-only signatures have no
 * replay protection. Retained only for receivers still on the old scheme.
 *
 * Both sign and verify paths use only the Web Crypto / Subtle Crypto APIs
 * so the helper works in browsers, Workers, and Node 20+ without any
 * runtime-specific code paths.
 */
/**
 * Compute the canonical hex signature for `body` with `secret`. Exposed so
 * tests and self-checks can produce expected values without re-implementing
 * the HMAC details.
 */
export declare function signWebhookPayload(body: string, secret: string): Promise<string>;
export interface VerifyWebhookOptions {
    /** Maximum age in seconds. Default 300 (5 minutes). Set Infinity to skip. */
    toleranceSec?: number;
    /** Defaults to Date.now()/1000 — injectable for deterministic testing. */
    nowSec?: number;
    /**
     * Accept legacy signatures computed over the raw body when no timestamp is
     * present. Body-only signatures have no replay protection.
     */
    allowLegacyBodySignature?: boolean;
    /**
     * Accept the pre-v2 `${timestamp}.${body}` scheme (no nonce/event binding).
     * Defaults to FALSE: the legacy scheme has no nonce/event binding and is a pure
     * downgrade risk now that the dispatcher only emits v2. Set to `true` only for a
     * documented external sender that has not yet migrated to v2.
     */
    allowLegacyTimestampSignature?: boolean;
    /** Event type from `X-Steward-Event`. Required to verify a v2 signature. */
    eventType?: string | null;
    /** Stable delivery id (nonce) from `X-Steward-Delivery-Id`. Required for v2. */
    deliveryId?: string | null;
}
export interface VerifyWebhookResult {
    valid: boolean;
    /** Set when `valid` is false. Coarse enum so callers can log without leaking detail. */
    reason?: "missing-signature" | "bad-signature" | "stale-timestamp" | "bad-timestamp";
    /** Signature scheme that verified (when valid). */
    scheme?: "v2" | "legacy-timestamp" | "legacy-body";
    /** Stable delivery id (nonce); use to dedup replays. Present for v2. */
    deliveryId?: string;
}
/**
 * Verify an inbound webhook against the shared secret. The `signature` arg
 * is the raw value of `X-Steward-Signature`; `timestamp` is the optional
 * `X-Steward-Timestamp` header. `body` MUST be the raw request body as the
 * server saw it — re-serialized JSON will not match because key ordering
 * and whitespace differ.
 */
export declare function verifyWebhookSignature(body: string, signature: string | null | undefined, secret: string, timestamp?: string | number | null, options?: VerifyWebhookOptions): Promise<VerifyWebhookResult>;
//# sourceMappingURL=webhook-verify.d.ts.map