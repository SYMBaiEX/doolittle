import { generateCodeChallenge, generateCodeVerifier } from "../contracts/index.js";
import type { LoginAuthConfig, LoginAuthResult, LoginCurrentUserResult, LoginDeviceCodeOptions, LoginDeviceCodeResult, LoginDeviceTokenPendingResult, LoginDeviceVerifyResult, LoginEmailGrantResult, LoginEmailOtpResult, LoginEmailResult, LoginEmailSignInStatusResult, LoginFarcasterLoginConfig, LoginFarcasterLoginPayload, LoginGuestDeleteResult, LoginGuestSignInOptions, LoginGuestState, LoginGuestUpgradeEmailInput, LoginIdentityTokenResult, LoginJwtLoginConfig, LoginMfaRequiredResult, LoginOAuthConfig, LoginOAuthResult, LoginPasskeyAlreadyRegisteredErrorData, LoginProviders, LoginRecoveryCodeStatus, LoginRecoveryCodesResult, LoginSession, LoginSmsMfaEnrollResult, LoginSmsMfaStatus, LoginSmsMfaVerifyResult, LoginSmsOtpResult, LoginTelegramLoginConfig, LoginTelegramLoginPayload, LoginTenantMembership, LoginTestAccountLoginOptions, LoginTotpEnrollResult, LoginTotpStatus, LoginTotpVerifyResult, LoginWhatsAppOtpResult } from "./auth-types.js";
import { LoginApiError } from "./transport.js";
declare function getOAuthCallbackParams(url: URL): {
    code?: string;
    state?: string;
    error?: string;
};
/**
 * Bind an OAuth callback message to the exact popup opened for this attempt.
 * Checking only `event.origin` lets any same-origin window race the real popup
 * and inject a forged error/code. PKCE/state still protect the token exchange,
 * but rejecting unrelated windows avoids callback confusion and denial of
 * service before those checks run.
 */
declare function isTrustedOAuthPopupMessage(event: Pick<MessageEvent, "origin" | "source">, popup: Window, expectedOrigin: string): boolean;
/** Narrow an SDK error to the stable existing-passkey recovery contract. */
export declare function isLoginPasskeyAlreadyRegisteredError(error: unknown): error is LoginApiError<LoginPasskeyAlreadyRegisteredErrorData>;
export declare class LoginAuth {
    private readonly baseUrl;
    private readonly storage;
    private readonly tenantId;
    private readonly authProxyUrl;
    private readonly listeners;
    private refreshPromise;
    private rotationTail;
    private sessionGeneration;
    constructor({ baseUrl, storage, onSessionChange, tenantId, authProxyUrl, allowInsecureBaseUrl, }: LoginAuthConfig);
    getBaseUrl(): string;
    /** Returns the configured default tenantId, if any. */
    getTenantId(): string | undefined;
    /**
     * Returns the current session decoded from the stored JWT, or null if not signed in.
     */
    getSession(): LoginSession | null;
    /**
     * Returns true if the access token is within REFRESH_THRESHOLD_SECS of expiry.
     * Call `refreshSession()` proactively when this returns true.
     */
    isNearExpiry(): boolean;
    /**
     * Returns the raw access JWT string, or null if not signed in.
     * Automatically triggers a background refresh if the token is near expiry.
     */
    getToken(): string | null;
    /** Returns the stored refresh token, or null if not available. */
    getRefreshToken(): string | null;
    /**
     * Returns true if there is a valid (non-expired) session.
     */
    isAuthenticated(): boolean;
    /**
     * Fetch the authenticated user's bootstrap payload. When a tenant is
     * configured, it is sent as both query and header so backend app-level
     * create-on-login wallet config can resolve without exposing platform keys.
     */
    getCurrentUser(options?: {
        tenantId?: string;
    }): Promise<LoginCurrentUserResult>;
    /**
     * Create or replace the current local session with a bounded guest account.
     * Guest sessions are persisted through the configured storage just like other
     * auth flows, so reloads can continue until the server-side guest expiry.
     */
    signInAsGuest(options?: LoginGuestSignInOptions): Promise<LoginAuthResult>;
    /**
     * Returns guest lifecycle state for the current session, including the
     * 30-day expiry warning copy consumers can surface in their own UI.
     */
    getGuestState(): LoginGuestState;
    /**
     * Upgrade the current guest into a full user using a verified email magic-link
     * token. This is intentionally guest-only: callers signed into a full account
     * must not use this path to merge guest data into an existing identity.
     */
    upgradeGuestWithEmail(input: LoginGuestUpgradeEmailInput): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    /**
     * Explicitly delete the current guest account server-side and clear local
     * persisted tokens. Full accounts are rejected locally and by the API.
     */
    deleteGuest(): Promise<LoginGuestDeleteResult>;
    getIdentityToken(): Promise<LoginIdentityTokenResult>;
    /**
     * Clears the stored session (both tokens) and notifies listeners.
     */
    signOut(): void;
    /**
     * Exchange the stored refresh token for a new access token + rotated refresh token.
     * Stores both tokens and notifies session listeners.
     * Returns the new session, or null if the refresh token is missing or invalid.
     */
    refreshSession(): Promise<LoginSession | null>;
    private refreshDirect;
    /**
     * Revoke this device's access and refresh tokens before clearing local state.
     * A failed server acknowledgement rejects so the caller can offer a retry.
     */
    revokeSession(): Promise<void>;
    private revokeSessionOnce;
    requestDeviceCode(options?: LoginDeviceCodeOptions): Promise<LoginDeviceCodeResult>;
    verifyDeviceCode(userCode: string, action?: "approve" | "deny"): Promise<LoginDeviceVerifyResult>;
    pollDeviceToken(input: {
        deviceCode: string;
        clientId?: string;
    }): Promise<LoginAuthResult | LoginDeviceTokenPendingResult>;
    /**
     * Register a listener that fires whenever the session changes.
     * Returns a cleanup function that removes the listener.
     */
    onSessionChange(callback: (session: LoginSession | null) => void): () => void;
    /**
     * Sign in with a discoverable passkey.
     *
     * Login options deliberately have the same successful shape whether an
     * account has passkeys or not, so this method never infers account state or
     * falls back to registration from the options response. Use `addPasskey`
     * only after independently proving control of the email address.
     *
     * Requires a browser environment and `@simplewebauthn/browser` installed.
     * Throws `LoginApiError` in Node or when the dependency is missing.
     */
    signInWithPasskey(email: string, _options?: {
        fallbackToRegistration?: false;
    }): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    /**
     * Register a new passkey for the given email, regardless of whether the
     * user already has other passkeys on other relying parties (RPs).
     *
     * Use this after a successful magic-link / OAuth sign-in to offer the
     * user one-tap passkey login on the current device. Existing passkeys
     * for this user on OTHER RPs (e.g. a passkey from `elizacloud.ai` when
     * the user is now on `waifu.fun`) won’t be removed; this just adds a
     * fresh credential bound to the current origin’s RP.
     *
     * Unlike `signInWithPasskey`, this method explicitly starts registration and
     * therefore requires an authenticated session or verified-email grant.
     *
     * Requires a browser environment and `@simplewebauthn/browser` installed.
     * Throws `LoginApiError` otherwise.
     */
    addPasskey(email: string, options?: {
        emailGrant?: string;
    }): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    private completePasskeyLogin;
    private completePasskeyRegister;
    /**
     * Send a magic link to the given email address.
     * Returns `{ ok: true, expiresAt }` — the actual sign-in happens in `verifyEmailCallback`.
     */
    signInWithEmail(email: string, captchaToken?: string): Promise<LoginEmailResult>;
    /**
     * Exchange a magic link token for a session JWT.
     * Call this from the callback URL handler with the `token` and `email` query params.
     */
    verifyEmailCallback(token: string, email: string): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    verifyEmailSignInCode(email: string, code: string): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    pollEmailSignInStatus(challengeId: string, pollSecret: string): Promise<LoginEmailSignInStatusResult>;
    sendSmsOtp(phone: string, captchaToken?: string): Promise<LoginSmsOtpResult>;
    verifySmsOtp(phone: string, code: string): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    sendWhatsAppOtp(phone: string, captchaToken?: string): Promise<LoginWhatsAppOtpResult>;
    verifyWhatsAppOtp(phone: string, code: string): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    /**
     * Email a 6-digit one-time code (Privy-style signup). Unlike
     * `signInWithEmail` (magic link), this issues a code the user types back
     * via `verifyEmailOtp` to obtain an `emailGrant`. The grant lets a
     * brand-new, signed-out user register their first passkey with
     * `addPasskey(email, { emailGrant })` — no prior session required.
     */
    sendEmailOtp(email: string, captchaToken?: string): Promise<LoginEmailOtpResult>;
    /**
     * Exchange the 6-digit code from `sendEmailOtp` for a short-lived,
     * single-use `emailGrant` proving ownership of the email. Pass the grant
     * to `addPasskey(email, { emailGrant })`.
     *
     * NOTE: this does NOT sign the user in by itself — it returns proof of
     * email ownership, intentionally decoupled so the caller drives the
     * passkey registration step.
     */
    verifyEmailOtp(email: string, code: string): Promise<LoginEmailGrantResult>;
    getTestAccessToken(options: LoginTestAccountLoginOptions): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    signInWithTelegram(payload: LoginTelegramLoginPayload, config?: LoginTelegramLoginConfig): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    signInWithFarcaster(payload: LoginFarcasterLoginPayload, config?: LoginFarcasterLoginConfig): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    getTotpStatus(): Promise<LoginTotpStatus>;
    enrollTotp(): Promise<LoginTotpEnrollResult>;
    verifyTotp(code: string): Promise<LoginTotpVerifyResult>;
    completeTotpMfa(challengeId: string, code: string): Promise<LoginAuthResult>;
    completeRecoveryCodeMfa(challengeId: string, recoveryCode: string): Promise<LoginAuthResult>;
    stepUpWithTotp(code: string): Promise<LoginAuthResult>;
    stepUpWithRecoveryCode(recoveryCode: string): Promise<LoginAuthResult>;
    getRecoveryCodeStatus(): Promise<LoginRecoveryCodeStatus>;
    regenerateRecoveryCodes(code: string): Promise<LoginRecoveryCodesResult>;
    unenrollTotp(code: string): Promise<{
        ok: boolean;
    }>;
    getSmsMfaStatus(): Promise<LoginSmsMfaStatus>;
    enrollSmsMfa(phone: string): Promise<LoginSmsMfaEnrollResult>;
    verifySmsMfa(code: string): Promise<LoginSmsMfaVerifyResult>;
    sendSmsMfaCode(): Promise<LoginSmsMfaEnrollResult>;
    completeSmsMfa(challengeId: string, code: string): Promise<LoginAuthResult>;
    stepUpWithSms(code: string): Promise<LoginAuthResult>;
    completePasskeyMfa(): Promise<LoginAuthResult>;
    unenrollSmsMfa(code: string): Promise<{
        ok: boolean;
    }>;
    /**
     * Sign in with an Ethereum wallet via SIWE (EIP-4361).
     *
     * @param address  - The signer's EVM address (checksummed or lowercase).
     * @param signMessage - Async function that signs an arbitrary string with the wallet.
     *                      Compatible with ethers.js `signer.signMessage`, viem's `walletClient.signMessage`,
     *                      or any custom implementation.
     * @param chainId    - The EVM chain id the wallet is connected to (e.g. 1, 8453, 56).
     *                      Defaults to Ethereum mainnet (1) when omitted. The web app should
     *                      pass the real connected chain id (e.g. from wagmi `useChainId()`)
     *                      so the signed message and EIP-1271 verification reflect reality.
     *
     * Flow: GET /auth/nonce → build SIWE message → caller signs → POST /auth/verify → store JWT.
     */
    signInWithSIWE(address: string, signMessage: (msg: string) => Promise<string>, chainId?: number): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    /**
     * Sign in with a Solana wallet via Sign-In With Solana.
     */
    signInWithSolana(publicKey: string, signMessage: (message: Uint8Array) => Promise<Uint8Array>, chain?: string): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    private providersCache;
    private static readonly PROVIDERS_CACHE_TTL_MS;
    /**
     * Fetch the list of enabled authentication providers from the server.
     * Results are cached for 5 minutes to avoid hammering the endpoint on every render.
     */
    getProviders(forceRefresh?: boolean): Promise<LoginProviders>;
    signInWithJwt(token: string, config: LoginJwtLoginConfig): Promise<LoginAuthResult | LoginMfaRequiredResult>;
    /**
     * Sign in with an OAuth provider using a popup-based PKCE flow.
     *
     * In a browser environment, opens a popup to the provider's authorization page,
     * listens for the callback, and exchanges the code for a session.
     *
     * In non-browser environments (Node), throws with the authorization URL.
     * Use `handleOAuthCallback` to complete the flow after redirect.
     *
     * @param provider - OAuth provider name (e.g. "google", "discord")
     * @param config   - Optional configuration overrides
     */
    signInWithOAuth(provider: string, config?: Partial<Omit<LoginOAuthConfig, "provider">>): Promise<LoginOAuthResult | LoginMfaRequiredResult>;
    /**
     * Complete an OAuth flow from a redirect callback (non-popup flow).
     *
     * Call this from your callback route handler after the OAuth provider
     * redirects back with `code` and `state` query parameters.
     *
     * @param provider - OAuth provider name (e.g. "google", "discord")
     * @param params   - The URL search params from the callback (code, state, error)
     */
    handleOAuthCallback(provider: string, params: {
        code?: string;
        state?: string;
        error?: string;
    }): Promise<LoginOAuthResult | LoginMfaRequiredResult>;
    /**
     * Exchange an OAuth authorization code for session tokens via PKCE.
     */
    private exchangeOAuthCode;
    /**
     * Wait for the OAuth popup to redirect back to the callback URL.
     * Polls the popup location and listens for postMessage as a fallback.
     */
    private waitForPopupCallback;
    /**
     * List all tenants/apps the current user belongs to.
     * Requires an active session.
     */
    listTenants(): Promise<LoginTenantMembership[]>;
    /** Join an open tenant/app. Invite-only tenants require acceptTenantInvitation. */
    joinTenant(tenantId: string): Promise<LoginTenantMembership>;
    /**
     * Accept a tenant invitation using a single-use invite token.
     * Requires an active personal session with a verified email.
     */
    acceptTenantInvitation(tenantId: string, token: string): Promise<{
        tenantId: string;
        role: string;
        invitationId: string;
    }>;
    /**
     * Leave a tenant/app. Cannot leave your personal tenant.
     * Requires an active session.
     */
    leaveTenant(tenantId: string): Promise<void>;
    /**
     * Switch the active tenant context by refreshing the session with a new tenantId.
     * Returns the new session, or null if the switch failed (user may need to re-auth).
     */
    switchTenant(tenantId: string): Promise<LoginSession | null>;
    /**
     * Refresh the session through the same-origin auth proxy (`authProxyUrl`),
     * which holds the refresh token in an HttpOnly cookie. The proxy rotates the
     * cookie itself; only the new access token comes back to JS-readable storage.
     */
    private refreshViaProxy;
    /**
     * Serialize cookie-backed token rotation across tabs in browsers that expose
     * the Web Locks API. The lock is origin-scoped, matching the HttpOnly cookie;
     * a waiting tab therefore sends the newly rotated cookie after its predecessor
     * completes instead of replaying the predecessor's one-time token.
     */
    private rotateSession;
    /** Serialize every one-time refresh-token mutation within this instance. */
    private runSerializedRotation;
    /**
     * Hand a freshly issued refresh token to the same-origin auth proxy, which
     * stores it in an HttpOnly cookie. Fails closed: when the deposit cannot be
     * completed the whole sign-in is aborted rather than silently downgrading to
     * JS-readable token storage.
     */
    private depositRefreshToken;
    private storeAndReturn;
    private storeExchangeResponse;
    private clearLocalTokens;
    private readLogoutEpoch;
    private publishLogoutEpoch;
    private deleteProxyCookieUnlocked;
    private runProxyMutation;
    private clearToken;
    private notifyListeners;
}
export { generateCodeChallenge as _generateCodeChallenge, generateCodeVerifier as _generateCodeVerifier, getOAuthCallbackParams as _getOAuthCallbackParams, isTrustedOAuthPopupMessage as _isTrustedOAuthPopupMessage, };
//# sourceMappingURL=auth.d.ts.map