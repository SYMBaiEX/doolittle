/** Shared browser/host session cookie and header names. No platform dependencies. */
export declare const SESSION_COOKIE_NAME = "eliza_session";
export declare const CSRF_COOKIE_NAME = "eliza_csrf";
export declare const CSRF_HEADER_NAME = "x-eliza-csrf";
/**
 * Epoch-ms time of the last real user interaction, sent on same-origin API
 * requests so an idle-timeout policy slides on user activity, not polling.
 */
export declare const LAST_ACTIVITY_HEADER_NAME = "x-eliza-last-activity";
//# sourceMappingURL=session-constants.d.ts.map