/**
 * Applies the shared credential-transport policy for LoginClient and LoginAuth.
 * Non-loopback endpoints require HTTPS unless the caller explicitly accepts an
 * insecure transport; embedded credentials, queries and fragments are rejected.
 */
/** Remove trailing URL separators in one bounded pass. */
export declare function stripTrailingSlashes(value: string): string;
/**
 * Throws unless `baseUrl` is HTTPS or targets loopback. Operators on trusted
 * private networks may opt out explicitly with `allowInsecureBaseUrl`, which
 * still warns loudly at construction.
 */
export declare function assertSecureBaseUrl(baseUrl: string, allowInsecureBaseUrl?: boolean): void;
//# sourceMappingURL=base-url.d.ts.map