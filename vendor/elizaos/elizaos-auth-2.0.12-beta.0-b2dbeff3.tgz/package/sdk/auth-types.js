/** Defines authentication providers, browser session state and login flow results. */
export {};
//# sourceMappingURL=auth-types.js.map