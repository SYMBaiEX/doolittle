import { hmacSha256Hex } from "../contracts/index.js";
import { boundedPositiveInteger, DEFAULT_MAX_RESPONSE_BODY_BYTES, DEFAULT_REQUEST_TIMEOUT_MS, fetchLoginJson, fetchLoginText, LoginApiError, MAX_REQUEST_TIMEOUT_MS, MAX_RESPONSE_BODY_BYTES, } from "./transport.js";
export { LoginApiError } from "./transport.js";
/** Sends authenticated identity and wallet requests to the host-owned login service. */
import { assertSecureBaseUrl, stripTrailingSlashes } from "./base-url.js";
// Keep in lockstep with the equivalent list in EVERY other SDK (go, java,
// python, ruby, rust, swift, csharp, flutter): mutations under these prefixes
// are HMAC-signed, and divergence silently downgrades integrity (SEC-049).
const SENSITIVE_SIGNED_PATHS = [
    "/vault",
    "/agents",
    "/policies",
    "/secrets",
    "/trade",
    "/v1/trade",
    "/approvals",
    "/intents",
    "/user",
    "/webhooks",
    "/tenants",
    "/platform",
    "/condition-sets",
    "/condition_sets",
    "/v1/condition_sets",
    "/global-wallet",
];
const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);
async function sha256Hex(input) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
    return [...new Uint8Array(digest)]
        .map((byte) => byte.toString(16).padStart(2, "0"))
        .join("");
}
function randomIdempotencyKey() {
    if (typeof crypto.randomUUID === "function")
        return crypto.randomUUID();
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = [...bytes]
        .map((byte) => byte.toString(16).padStart(2, "0"))
        .join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function isSensitiveMutatingRequest(path, method) {
    return (MUTATING_METHODS.has(method.toUpperCase()) &&
        SENSITIVE_SIGNED_PATHS.some((prefix) => path === prefix || path.startsWith(`${prefix}/`)));
}
function parseAgentIdentity(agent) {
    return {
        ...agent,
        createdAt: new Date(agent.createdAt),
    };
}
function parsePlatformTenantUser(user) {
    return {
        ...user,
        joinedAt: new Date(user.joinedAt),
        createdAt: new Date(user.createdAt),
        updatedAt: new Date(user.updatedAt),
    };
}
function parsePlatformTenantInvitation(invitation) {
    return {
        ...invitation,
        acceptedAt: invitation.acceptedAt ? new Date(invitation.acceptedAt) : null,
        revokedAt: invitation.revokedAt ? new Date(invitation.revokedAt) : null,
        expiresAt: new Date(invitation.expiresAt),
        createdAt: new Date(invitation.createdAt),
        updatedAt: invitation.updatedAt
            ? new Date(invitation.updatedAt)
            : undefined,
    };
}
function parseTenantAdminUser(user) {
    return {
        ...user,
        joinedAt: new Date(user.joinedAt),
        deactivatedAt: user.deactivatedAt ? new Date(user.deactivatedAt) : null,
        createdAt: new Date(user.createdAt),
        updatedAt: new Date(user.updatedAt),
    };
}
function parseTenantAdminUserEvents(result) {
    return {
        ...result,
        events: result.events.map((event) => ({
            ...event,
            createdAt: new Date(event.createdAt),
        })),
    };
}
function parsePlatformUserIdentity(user) {
    return {
        ...user,
        deactivatedAt: user.deactivatedAt ? new Date(user.deactivatedAt) : null,
        createdAt: new Date(user.createdAt),
        updatedAt: new Date(user.updatedAt),
    };
}
function parseTxRecord(tx) {
    return {
        ...tx,
        createdAt: tx.createdAt instanceof Date ? tx.createdAt : new Date(tx.createdAt),
        signedAt: tx.signedAt
            ? tx.signedAt instanceof Date
                ? tx.signedAt
                : new Date(tx.signedAt)
            : undefined,
        confirmedAt: tx.confirmedAt
            ? tx.confirmedAt instanceof Date
                ? tx.confirmedAt
                : new Date(tx.confirmedAt)
            : undefined,
    };
}
function signerHeaders(options) {
    if (!options?.signerId &&
        !options?.signerSecret &&
        !options?.keyQuorumId &&
        !options?.keyQuorumCredentials?.length) {
        return undefined;
    }
    const headers = {};
    if (options.signerId)
        headers["X-Steward-Signer-Id"] = options.signerId;
    if (options.signerSecret)
        headers["X-Steward-Signer-Secret"] = options.signerSecret;
    if (options.keyQuorumId)
        headers["X-Steward-Key-Quorum-Id"] = options.keyQuorumId;
    if (options.keyQuorumCredentials?.length) {
        headers["X-Steward-Key-Quorum-Credentials"] = JSON.stringify(options.keyQuorumCredentials);
    }
    return headers;
}
export function isLoginMfaRequiredError(error) {
    return error instanceof LoginApiError && error.mfaRequired;
}
export function isLoginBroadcastOutcomeUnknown(result) {
    return ("code" in result &&
        result.code === "external_broadcast_outcome_unknown" &&
        result.reconciliationRequired === true);
}
function isBrowserRuntime() {
    return (typeof globalThis.window !== "undefined" &&
        typeof globalThis.document !== "undefined");
}
export class LoginClient {
    baseUrl;
    apiKey;
    appId;
    appSecret;
    platformKey;
    bearerToken;
    tenantId;
    requestSigningSecret;
    requestSigningKeyId;
    requestTimeoutMs;
    maxResponseBodyBytes;
    constructor({ baseUrl, apiKey, appId, appSecret, platformKey, bearerToken, tenantId, requestSigningSecret, requestSigningKeyId, allowUnsafeBrowserSecrets, allowInsecureBaseUrl, requestTimeoutMs, maxResponseBodyBytes, }) {
        if (isBrowserRuntime() &&
            !allowUnsafeBrowserSecrets &&
            (apiKey || appSecret || platformKey || requestSigningSecret)) {
            throw new LoginApiError("apiKey, appSecret, platformKey, and requestSigningSecret must not be used in browser runtimes; use bearerToken or set allowUnsafeBrowserSecrets only for audited local tools.", 0);
        }
        assertSecureBaseUrl(baseUrl, allowInsecureBaseUrl);
        this.baseUrl = stripTrailingSlashes(baseUrl);
        this.apiKey = apiKey;
        this.appId = appId;
        this.appSecret = appSecret;
        this.platformKey = platformKey;
        this.bearerToken = bearerToken;
        this.tenantId = tenantId;
        this.requestSigningSecret = requestSigningSecret;
        this.requestSigningKeyId = requestSigningKeyId;
        this.requestTimeoutMs = boundedPositiveInteger("requestTimeoutMs", requestTimeoutMs, DEFAULT_REQUEST_TIMEOUT_MS, MAX_REQUEST_TIMEOUT_MS);
        this.maxResponseBodyBytes = boundedPositiveInteger("maxResponseBodyBytes", maxResponseBodyBytes, DEFAULT_MAX_RESPONSE_BODY_BYTES, MAX_RESPONSE_BODY_BYTES);
    }
    getBaseUrl() {
        return this.baseUrl;
    }
    platformUsers = {
        create: async (input) => {
            const response = await this.request("/platform/users", {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
        getIdentity: async (userId) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return parsePlatformUserIdentity(response.data);
        },
        updateCustomMetadata: async (userId, customMetadata) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}/metadata`, {
                method: "PATCH",
                body: JSON.stringify({ customMetadata }),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return parsePlatformUserIdentity(response.data);
        },
        deactivate: async (userId, deactivated = true) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}/deactivate`, {
                method: "PATCH",
                body: JSON.stringify({ deactivated }),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return {
                ...response.data,
                deactivatedAt: response.data.deactivatedAt
                    ? new Date(response.data.deactivatedAt)
                    : null,
            };
        },
        delete: async (userId) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}`, { method: "DELETE" });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
        lookup: async (opts) => {
            const params = new URLSearchParams();
            if (opts.email)
                params.set("email", opts.email);
            if (opts.phone)
                params.set("phone", opts.phone);
            if (opts.walletAddress)
                params.set("walletAddress", opts.walletAddress);
            if (opts.walletExternalId)
                params.set("walletExternalId", opts.walletExternalId);
            if (opts.smartWalletId)
                params.set("smartWalletId", opts.smartWalletId);
            if (opts.customAuthId)
                params.set("customAuthId", opts.customAuthId);
            if (opts.provider)
                params.set("provider", opts.provider);
            if (opts.providerAccountId)
                params.set("providerAccountId", opts.providerAccountId);
            if (opts.tenantId)
                params.set("tenantId", opts.tenantId);
            const response = await this.request(`/platform/users/lookup?${params.toString()}`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return {
                user: response.data.user
                    ? parsePlatformUserIdentity(response.data.user)
                    : null,
            };
        },
        getUserByEmailAddress: async (email, opts) => this.platformUsers.lookup({ email, tenantId: opts?.tenantId }),
        getUserByPhoneNumber: async (phone, opts) => this.platformUsers.lookup({ phone, tenantId: opts?.tenantId }),
        getUserByWalletAddress: async (walletAddress, opts) => this.platformUsers.lookup({ walletAddress, tenantId: opts?.tenantId }),
        getUserByWalletExternalId: async (walletExternalId, opts) => this.platformUsers.lookup({ walletExternalId, tenantId: opts.tenantId }),
        getUserBySmartWalletAddress: async (smartWalletId, opts) => this.platformUsers.lookup({ smartWalletId, tenantId: opts?.tenantId }),
        getUserByCustomAuthId: async (customAuthId, opts) => this.platformUsers.lookup({ customAuthId, tenantId: opts?.tenantId }),
        getUserByProviderAccount: async (provider, providerAccountId, opts) => this.platformUsers.lookup({
            provider,
            providerAccountId,
            tenantId: opts?.tenantId,
        }),
        getUserByDiscordUsername: async (username, opts) => this.platformUsers.getUserByProviderAccount("discord", username, opts),
        getUserByGithubUsername: async (username, opts) => this.platformUsers.getUserByProviderAccount("github", username, opts),
        getUserByFarcasterId: async (fid, opts) => this.platformUsers.getUserByProviderAccount("farcaster", fid, opts),
        getUserByInstagramUsername: async (username, opts) => this.platformUsers.getUserByProviderAccount("instagram", username, opts),
        getUserBySpotifySubject: async (subject, opts) => this.platformUsers.getUserByProviderAccount("spotify", subject, opts),
        getUserByTelegramUserId: async (id, opts) => this.platformUsers.getUserByProviderAccount("telegram", id, opts),
        getUserByTelegramUsername: async (username, opts) => this.platformUsers.getUserByProviderAccount("telegram", username, opts),
        getUserByTwitchUsername: async (username, opts) => this.platformUsers.getUserByProviderAccount("twitch", username, opts),
        getUserByTwitterSubject: async (subject, opts) => this.platformUsers.getUserByProviderAccount("twitter", subject, opts),
        getUserByTwitterUsername: async (username, opts) => this.platformUsers.getUserByProviderAccount("twitter", username, opts),
        search: async (tenantId, opts) => {
            const params = new URLSearchParams();
            if (opts?.q)
                params.set("q", opts.q);
            if (opts?.email)
                params.set("email", opts.email);
            if (opts?.walletExternalId)
                params.set("walletExternalId", opts.walletExternalId);
            if (opts?.limit)
                params.set("limit", String(opts.limit));
            if (opts?.offset)
                params.set("offset", String(opts.offset));
            const qs = params.toString();
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/users${qs ? `?${qs}` : ""}`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return {
                ...response.data,
                users: response.data.users.map(parsePlatformTenantUser),
            };
        },
        get: async (tenantId, userId) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return parsePlatformTenantUser(response.data);
        },
        updateMetadata: async (tenantId, userId, metadata) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}/metadata`, {
                method: "PATCH",
                body: JSON.stringify(metadata),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return parsePlatformTenantUser(response.data);
        },
        listInvitations: async (tenantId, opts) => {
            const params = new URLSearchParams();
            if (opts?.status)
                params.set("status", opts.status);
            if (opts?.limit)
                params.set("limit", String(opts.limit));
            if (opts?.offset)
                params.set("offset", String(opts.offset));
            const qs = params.toString();
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/invitations${qs ? `?${qs}` : ""}`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return {
                invitations: response.data.invitations.map(parsePlatformTenantInvitation),
            };
        },
        createInvitation: async (tenantId, input) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/invitations`, {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return {
                token: response.data.token,
                emailSent: response.data.emailSent,
                invitation: parsePlatformTenantInvitation(response.data.invitation),
            };
        },
        revokeInvitation: async (tenantId, invitationId) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/invitations/${encodeURIComponent(invitationId)}`, { method: "DELETE" }, true);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
        },
        linkAccount: async (userId, input) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}/accounts`, {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
        unlinkAccount: async (userId, provider, providerAccountId, opts) => {
            const params = new URLSearchParams();
            if (opts?.force)
                params.set("force", "true");
            const qs = params.toString();
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}/accounts/${encodeURIComponent(provider)}/${encodeURIComponent(providerAccountId)}${qs ? `?${qs}` : ""}`, { method: "DELETE" }, true);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
        },
        transferAccount: async (fromUserId, provider, providerAccountId, input) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(fromUserId)}/accounts/${encodeURIComponent(provider)}/${encodeURIComponent(providerAccountId)}/transfer`, {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
        assignWalletExternalId: async (userId, input) => {
            const response = await this.request(`/platform/users/${encodeURIComponent(userId)}/wallet/external-id`, {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
        resolveWalletExternalId: async (input) => {
            const response = await this.request("/platform/users/wallet/external-id", {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return {
                user: response.data.user
                    ? parsePlatformUserIdentity(response.data.user)
                    : null,
            };
        },
        connectOrCreateByWalletExternalId: async (input) => {
            const response = await this.request("/platform/users/wallet/external-id/connect-or-create", {
                method: "POST",
                body: JSON.stringify(input),
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
    };
    platformApps = {
        getGasSpend: async (input) => {
            const params = new URLSearchParams();
            params.set("tenant_id", input.tenantId);
            if (input.walletIds?.length) {
                params.set("wallet_ids", input.walletIds.join(","));
            }
            if (input.walletExternalIds?.length) {
                params.set("wallet_external_ids", input.walletExternalIds.join(","));
            }
            if (input.startTimestamp !== undefined) {
                params.set("start_timestamp", String(input.startTimestamp));
            }
            if (input.endTimestamp !== undefined) {
                params.set("end_timestamp", String(input.endTimestamp));
            }
            const response = await this.request(`/platform/apps/gas_spend?${params.toString()}`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data;
        },
    };
    platformTestAccounts = {
        get: async (tenantId) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/test-account`);
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data.testAccount;
        },
        enable: async (tenantId) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/test-account`, {
                method: "POST",
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data.testAccount;
        },
        disable: async (tenantId) => {
            const response = await this.request(`/platform/tenants/${encodeURIComponent(tenantId)}/test-account`, {
                method: "DELETE",
            });
            if (!response.ok)
                throw new LoginApiError(response.error, response.status, response.data);
            return response.data.testAccount;
        },
    };
    async createWallet(agentId, name, platformId) {
        const response = await this.request("/agents", {
            method: "POST",
            body: JSON.stringify({ id: agentId, name, platformId }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return parseAgentIdentity(response.data);
    }
    async signTransaction(agentId, tx, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify(tx),
        });
        if (response.ok) {
            return response.data;
        }
        if (response.status === 202 && this.isPendingApproval(response.data)) {
            return response.data;
        }
        if (response.status === 202 &&
            this.isBroadcastOutcomeUnknown(response.data)) {
            return response.data;
        }
        throw new LoginApiError(response.error, response.status, response.data);
    }
    async quoteTransfer(agentId, input) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/actions/transfer/quote`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async createTransferAction(agentId, input, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/actions/transfer`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async createSendCallsAction(agentId, input, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/actions/send-calls`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async getTransferAction(agentId, actionId) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/actions/${encodeURIComponent(actionId)}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async getPolicies(agentId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Replace the policy set for an agent. Returns the stored policies
     * (with server-assigned ids where applicable).
     */
    async setPolicies(agentId, policies) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies`, {
            method: "PUT",
            body: JSON.stringify(policies),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        // Older API builds returned no body; fall back to the input on void.
        return response.data ?? policies;
    }
    async listPolicyRules(agentId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies/rules`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data.rules;
    }
    async createPolicyRule(agentId, rule) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies/rules`, {
            method: "POST",
            body: JSON.stringify(rule),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    async getPolicyRule(agentId, ruleId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies/rules/${encodeURIComponent(ruleId)}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    async updatePolicyRule(agentId, ruleId, update) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies/rules/${encodeURIComponent(ruleId)}`, {
            method: "PATCH",
            body: JSON.stringify(update),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    async deletePolicyRule(agentId, ruleId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/policies/rules/${encodeURIComponent(ruleId)}`, { method: "DELETE" });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    async getAgent(agentId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return parseAgentIdentity(response.data);
    }
    async listAgents() {
        const response = await this.request("/agents");
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data.map(parseAgentIdentity);
    }
    /**
     * Return a compact history feed for an agent. Each entry is a
     * `{ timestamp, value }` pair - suitable for trend charts and volume
     * windows. For the full signed-transaction objects, prefer
     * {@link getTransactionHistory}.
     */
    async getHistory(agentId) {
        const records = await this.getTransactionHistory(agentId);
        return records.map((tx) => ({
            timestamp: Math.floor((tx.createdAt instanceof Date
                ? tx.createdAt.getTime()
                : new Date(tx.createdAt).getTime()) / 1000),
            value: tx.request?.value ?? "0",
        }));
    }
    /**
     * Return the full transaction history for an agent as `TxRecord[]`.
     * Includes status, policy results, tx hash, timestamps, and the
     * original sign request.
     */
    async getTransactionHistory(agentId) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/history`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        const records = Array.isArray(response.data)
            ? response.data
            : response.data.transactions;
        return records.map(parseTxRecord);
    }
    async listTransactions(agentId, opts) {
        const params = new URLSearchParams();
        if (opts?.status)
            params.set("status", opts.status);
        if (opts?.actionType)
            params.set("actionType", opts.actionType);
        if (opts?.txHash)
            params.set("txHash", opts.txHash);
        if (opts?.referenceId)
            params.set("referenceId", opts.referenceId);
        if (opts?.limit)
            params.set("limit", String(opts.limit));
        if (opts?.offset)
            params.set("offset", String(opts.offset));
        const qs = params.toString();
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/transactions${qs ? `?${qs}` : ""}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return {
            ...response.data,
            transactions: response.data.transactions.map(parseTxRecord),
        };
    }
    async getTransaction(agentId, txId) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/transactions/${encodeURIComponent(txId)}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return parseTxRecord(response.data);
    }
    async updateTransactionLifecycle(agentId, txId, input) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/transactions/${encodeURIComponent(txId)}/lifecycle`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return parseTxRecord(response.data);
    }
    async replaceTransaction(agentId, txId, input) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/transactions/${encodeURIComponent(txId)}/replace`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return parseTxRecord(response.data);
    }
    async signMessage(agentId, message, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign-message`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify({ message }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    async signRawHash(agentId, input) {
        const { signerId: _signerId, signerSecret: _signerSecret, keyQuorumId: _keyQuorumId, keyQuorumCredentials: _keyQuorumCredentials, ...body } = input;
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign-raw-hash`, {
            method: "POST",
            headers: signerHeaders(input),
            body: JSON.stringify(body),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Sign EIP-712 typed data (`eth_signTypedData_v4`).
     * Used for DEX approvals, ERC-20 permits, and structured data signatures.
     */
    async signTypedData(agentId, input, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign-typed-data`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Sign an ERC-4337 EntryPoint v0.7 user operation (`eth_signUserOperation`).
     * `to` and `value` are required for policy evaluation until calldata extraction is configured.
     */
    async signUserOperation(agentId, input, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign-user-operation`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Sign an EIP-7702 set-code authorization for inclusion in an authorizationList.
     */
    async signAuthorization(agentId, input, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign-authorization`, {
            method: "POST",
            headers: signerHeaders(options),
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Sign a serialized Solana transaction.
     * Pass a base64-encoded transaction; optionally broadcast via Solana RPC.
     */
    async signSolanaTransaction(agentId, input, options) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/sign-solana`, {
            method: "POST",
            headers: options?.idempotencyKey
                ? { "Idempotency-Key": options.idempotencyKey }
                : undefined,
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Proxy a read-only RPC call to the appropriate chain provider.
     * Signing/state-modifying methods are blocked server-side.
     */
    async rpcPassthrough(agentId, input) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/rpc`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Get the on-chain native balance for an agent wallet.
     * Optionally pass a chainId to query a specific network (defaults to the server's active chain).
     */
    async getBalance(agentId, chainId) {
        const params = chainId ? `?chainId=${chainId}` : "";
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/balance${params}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Get all wallet addresses for an agent across all chain families.
     * New agents have both EVM and Solana addresses; legacy agents have EVM only.
     */
    async getAddresses(agentId) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/addresses`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Export the private keys for the authenticated user's personal wallet.
     * Requires a user session token (Bearer JWT).
     */
    async exportUserWalletKey(input = {}) {
        const response = await this.request("/user/me/wallet/export", {
            method: "POST",
            body: input.walletIndex === undefined
                ? undefined
                : JSON.stringify({ walletIndex: input.walletIndex }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Initialize a one-time encrypted private-key import session for the
     * authenticated user's embedded wallet. Requires a personal user session with
     * recent MFA and the audited import feature flags.
     */
    async initializeEncryptedUserWalletKeyImport(chain, input = {}) {
        const response = await this.request("/user/me/wallet/import/init", {
            method: "POST",
            body: JSON.stringify({
                chain,
                ...(input.walletIndex === undefined
                    ? {}
                    : { walletIndex: input.walletIndex }),
            }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Submit an encrypted private-key import envelope for the authenticated user's
     * embedded wallet. Plaintext privateKey fields are rejected by the API.
     */
    async submitEncryptedUserWalletKeyImport(input) {
        const response = await this.request("/user/me/wallet/import/submit", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Get the authenticated user's embedded wallet native balance.
     * Requires a personal user session token (Bearer JWT).
     */
    async getUserWallet(input) {
        const params = new URLSearchParams();
        if (typeof input === "number") {
            params.set("chainId", String(input));
        }
        else if (input) {
            if (input.chainId !== undefined)
                params.set("chainId", String(input.chainId));
            if (input.walletIndex !== undefined)
                params.set("walletIndex", String(input.walletIndex));
        }
        const qs = params.toString();
        const response = await this.request(`/user/me/wallet${qs ? `?${qs}` : ""}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** Privy-style alias for the authenticated user's embedded wallet balance. */
    async getUserWalletBalance(input) {
        return this.getUserWallet(input);
    }
    /**
     * Provision the authenticated user's embedded wallet if needed.
     * Requires a personal user session token (Bearer JWT).
     */
    async createUserWallet(input = {}) {
        const response = await this.request("/user/me/wallet", {
            method: "POST",
            body: input.walletIndex === undefined
                ? undefined
                : JSON.stringify({ walletIndex: input.walletIndex }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** Privy-style alias for authenticated user-wallet provisioning. */
    async provisionUserWallet(input = {}) {
        return this.createUserWallet(input);
    }
    /**
     * Provision the authenticated user's wallet from a one-time BIP-39 recovery
     * phrase. Requires a user session token with recent MFA and only works before
     * a user wallet already exists.
     */
    async setupUserWalletRecovery(input = {}) {
        const response = await this.request("/user/me/wallet/recovery/setup", {
            method: "POST",
            body: input.walletIndex === undefined
                ? undefined
                : JSON.stringify({ walletIndex: input.walletIndex }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Restore/import the authenticated user's mnemonic-backed wallet. Requires a
     * user session with recent MFA. The mnemonic is sent once and is never returned.
     */
    async restoreUserWalletRecovery(input) {
        const response = await this.request("/user/me/wallet/recovery/restore", {
            method: "POST",
            body: JSON.stringify({
                mnemonic: input.mnemonic,
                ...(input.walletIndex === undefined
                    ? {}
                    : { walletIndex: input.walletIndex }),
            }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Claim a tenant-admin pregenerated wallet for the authenticated user.
     * Requires a personal user session with recent MFA and no existing user wallet.
     */
    async claimPregeneratedUserWallet(input) {
        const response = await this.request("/user/me/wallet/claim-pregenerated", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /**
     * Sign a native transfer with the authenticated user's embedded wallet.
     * Broadcast requests require an idempotency key server-side.
     */
    async signUserWalletTransaction(input, options) {
        const response = await this.request("/user/me/wallet/sign", {
            method: "POST",
            headers: options?.idempotencyKey
                ? { "Idempotency-Key": options.idempotencyKey }
                : undefined,
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** Sign a message with the authenticated user's embedded wallet when server-side unsafe signing is enabled. */
    async signUserWalletMessage(message, input = {}) {
        const response = await this.request("/user/me/wallet/sign-message", {
            method: "POST",
            body: JSON.stringify({
                message,
                ...(input.walletIndex === undefined
                    ? {}
                    : { walletIndex: input.walletIndex }),
            }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** List the authenticated user's embedded-wallet transaction history. */
    async getUserWalletHistory(opts) {
        const params = new URLSearchParams();
        if (opts?.limit)
            params.set("limit", String(opts.limit));
        if (opts?.offset)
            params.set("offset", String(opts.offset));
        if (opts?.walletIndex !== undefined)
            params.set("walletIndex", String(opts.walletIndex));
        const qs = params.toString();
        const response = await this.request(`/user/me/wallet/history${qs ? `?${qs}` : ""}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return {
            ...response.data,
            transactions: response.data.transactions.map(parseTxRecord),
        };
    }
    /** Get active/default policy rules for the authenticated user's embedded wallet. */
    async getUserWalletPolicies(input = {}) {
        const params = new URLSearchParams();
        if (input.walletIndex !== undefined)
            params.set("walletIndex", String(input.walletIndex));
        const qs = params.toString();
        const response = await this.request(`/user/me/wallet/policies${qs ? `?${qs}` : ""}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** List additional signer credentials for the authenticated user's embedded wallet. */
    async listUserWalletSigners(input = {}) {
        const params = new URLSearchParams();
        if (input.walletIndex !== undefined)
            params.set("walletIndex", String(input.walletIndex));
        if (input.status)
            params.set("status", input.status);
        const qs = params.toString();
        const response = await this.request(`/user/me/wallet/signers${qs ? `?${qs}` : ""}`);
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data.signers;
    }
    /**
     * Create a server-issued signer credential for the authenticated user's embedded wallet.
     * The returned credentialSecret is shown once.
     */
    async createUserWalletSigner(input = {}) {
        const { walletIndex, ...body } = input;
        const response = await this.request("/user/me/wallet/signers", {
            method: "POST",
            body: JSON.stringify({
                ...body,
                ...(walletIndex === undefined ? {} : { walletIndex }),
            }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** Revoke an additional signer credential on the authenticated user's embedded wallet. */
    async revokeUserWalletSigner(signerId, input = {}) {
        const params = new URLSearchParams();
        if (input.walletIndex !== undefined)
            params.set("walletIndex", String(input.walletIndex));
        const qs = params.toString();
        const response = await this.request(`/user/me/wallet/signers/${encodeURIComponent(signerId)}${qs ? `?${qs}` : ""}`, { method: "DELETE" });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** List linked accounts for the authenticated user. Requires user JWT. */
    async listUserAccounts() {
        const response = await this.request("/user/me/accounts");
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Get the authenticated user's aggregated account, wallets, portfolio, and spend. */
    async getUserAccount(opts = {}) {
        const params = new URLSearchParams();
        if (opts.chainId)
            params.set("chainId", String(opts.chainId));
        if (opts.tokens?.length)
            params.set("tokens", opts.tokens.join(","));
        const qs = params.toString();
        const response = await this.request(`/user/me/account${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Privy-style alias for the authenticated user's aggregated account summary. */
    async getUserAccountAggregation(opts = {}) {
        const params = new URLSearchParams();
        if (opts.chainId)
            params.set("chainId", String(opts.chainId));
        if (opts.tokens?.length)
            params.set("tokens", opts.tokens.join(","));
        const qs = params.toString();
        const response = await this.request(`/user/me/aggregation${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List active push subscriptions for the authenticated user. Requires user JWT. */
    async listUserPushSubscriptions() {
        const response = await this.request("/user/me/push-subscriptions");
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Register or refresh a push subscription for the authenticated user. Requires user JWT. */
    async registerUserPushSubscription(input) {
        const response = await this.request("/user/me/push-subscriptions", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Revoke a push subscription for the authenticated user. Requires user JWT. */
    async revokeUserPushSubscription(subscriptionId) {
        const response = await this.request(`/user/me/push-subscriptions/${encodeURIComponent(subscriptionId)}`, {
            method: "DELETE",
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Preview a global-wallet consent request for a tenant app. Requires user JWT. */
    async getGlobalWalletConsentRequest(input) {
        const params = new URLSearchParams({ app_id: input.appId });
        if (input.origin)
            params.set("origin", input.origin);
        if (input.redirectUri)
            params.set("redirect_uri", input.redirectUri);
        if (input.walletIndex !== undefined)
            params.set("wallet_index", String(input.walletIndex));
        for (const scope of input.scopes ?? [])
            params.append("scope", scope);
        const response = await this.request(`/global-wallet/consent/request?${params.toString()}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Approve global-wallet access for a tenant app. Requires user JWT with recent MFA. */
    async approveGlobalWalletConsent(input) {
        const response = await this.request("/global-wallet/consent/approve", {
            method: "POST",
            body: JSON.stringify({
                app_id: input.appId,
                origin: input.origin,
                redirect_uri: input.redirectUri,
                scopes: input.scopes,
                wallet_index: input.walletIndex,
            }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List global-wallet app consents for the authenticated user. Requires user JWT. */
    async listGlobalWalletConsents() {
        const response = await this.request("/global-wallet/consents");
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Revoke a global-wallet app consent. Requires user JWT with recent MFA. */
    async revokeGlobalWalletConsent(consentId) {
        const response = await this.request(`/global-wallet/consents/${encodeURIComponent(consentId)}/revoke`, {
            method: "POST",
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Call the global-wallet RPC bridge. Write methods require explicit server-side enablement. */
    async confirmGlobalWalletAction(input) {
        const response = await this.request("/global-wallet/rpc/confirm", {
            method: "POST",
            body: JSON.stringify({
                app_id: input.appId,
                origin: input.origin,
                method: input.method,
                params: input.params,
                wallet_index: input.walletIndex,
            }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Scan a global-wallet transaction request before confirming/executing it. */
    async scanGlobalWalletTransaction(input) {
        const response = await this.request("/global-wallet/rpc/scan", {
            method: "POST",
            body: JSON.stringify({
                app_id: input.appId,
                origin: input.origin,
                method: input.method ?? "eth_sendTransaction",
                params: input.params,
                wallet_index: input.walletIndex,
            }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Call the global-wallet RPC bridge. Write methods require a one-time action confirmation. */
    async globalWalletRpc(input) {
        const response = await this.request("/global-wallet/rpc", {
            method: "POST",
            body: JSON.stringify({
                app_id: input.appId,
                origin: input.origin,
                method: input.method,
                params: input.params,
                confirmation_id: input.confirmationId,
                id: input.id,
                jsonrpc: input.jsonrpc,
                wallet_index: input.walletIndex,
            }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Create a one-time message for linking an Ethereum wallet to the authenticated user. */
    async createUserEthereumWalletLinkNonce(address) {
        const response = await this.request("/user/me/accounts/wallet/ethereum/nonce", {
            method: "POST",
            body: JSON.stringify(address ? { address } : {}),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Link an Ethereum wallet to the authenticated user using the signed nonce message. */
    async linkUserEthereumWallet(input) {
        const response = await this.request("/user/me/accounts/wallet/ethereum", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Create a one-time message for linking a Solana wallet to the authenticated user. */
    async createUserSolanaWalletLinkNonce(publicKey) {
        const response = await this.request("/user/me/accounts/wallet/solana/nonce", {
            method: "POST",
            body: JSON.stringify(publicKey ? { publicKey } : {}),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Link a Solana wallet to the authenticated user using the signed nonce message. */
    async linkUserSolanaWallet(input) {
        const response = await this.request("/user/me/accounts/wallet/solana", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Create a one-time state challenge for linking an OAuth account. */
    async createUserOAuthAccountLinkChallenge(provider, input) {
        const response = await this.request(`/user/me/accounts/oauth/${encodeURIComponent(provider)}/challenge`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Link an OAuth account to the authenticated user using an authorization code and state. */
    async linkUserOAuthAccount(provider, input) {
        const response = await this.request(`/user/me/accounts/oauth/${encodeURIComponent(provider)}/token`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Send an OTP for linking a phone number to the authenticated user. */
    async sendUserPhoneAccountLinkOtp(phone, channel = "sms") {
        const response = await this.request(`/user/me/accounts/phone/${channel}/send`, {
            method: "POST",
            body: JSON.stringify({ phone }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Verify an OTP and link a phone number to the authenticated user. */
    async verifyUserPhoneAccountLinkOtp(input, channel = "sms") {
        const response = await this.request(`/user/me/accounts/phone/${channel}/verify`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Link a Telegram Login Widget account to the authenticated user. */
    async createUserTelegramAccountLinkChallenge() {
        const response = await this.request("/user/me/accounts/telegram/challenge", {
            method: "POST",
            body: JSON.stringify({}),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Link a Telegram Login Widget account to the authenticated user. */
    async linkUserTelegramAccount(input) {
        const response = await this.request("/user/me/accounts/telegram", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Create a one-time nonce for linking a Farcaster account to the authenticated user. */
    async createUserFarcasterAccountLinkNonce() {
        const response = await this.request("/user/me/accounts/farcaster/nonce", {
            method: "POST",
            body: JSON.stringify({}),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Link a Farcaster SIWF account to the authenticated user. */
    async linkUserFarcasterAccount(input) {
        const response = await this.request("/user/me/accounts/farcaster", {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Unlink a linked account from the authenticated user. Requires another login method. */
    async unlinkUserAccount(provider, providerAccountId) {
        const response = await this.request(`/user/me/accounts/${encodeURIComponent(provider)}/${encodeURIComponent(providerAccountId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /**
     * Export the private keys for a vault agent.
     * Requires tenant-level authentication.
     */
    async exportAgentKey(agentId) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/export`, { method: "POST" });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** Initialize a one-time encrypted private-key import session for a vault agent. */
    async initializeEncryptedAgentKeyImport(agentId, chain) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/import/init`, {
            method: "POST",
            body: JSON.stringify({ chain }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    /** Submit an encrypted private-key import envelope for a vault agent. */
    async submitEncryptedAgentKeyImport(agentId, input) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/import/submit`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return response.data;
    }
    // ─── Tenant Config ─────────────────────────────────────────────
    /** Get the control-plane configuration for a tenant. */
    async getTenantConfig(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/config`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Update the control-plane configuration for a tenant. */
    async updateTenantConfig(tenantId, config) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/config`, {
            method: "PUT",
            body: JSON.stringify(config),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List tenant app origins used for CORS, passkeys, SIWE/SIWS, and OAuth redirects. */
    async listAppOrigins(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-origins`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Add one or more tenant app origins. Requires tenant-admin MFA server-side. */
    async addAppOrigin(tenantId, origin) {
        return this.addAppOrigins(tenantId, [origin]);
    }
    /** Add one or more tenant app origins. Requires tenant-admin MFA server-side. */
    async addAppOrigins(tenantId, origins) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-origins`, {
            method: "POST",
            body: JSON.stringify({ origins }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Remove one tenant app origin. Requires tenant-admin MFA server-side. */
    async removeAppOrigin(tenantId, origin) {
        return this.removeAppOrigins(tenantId, [origin]);
    }
    /** Remove one or more tenant app origins. Requires tenant-admin MFA server-side. */
    async removeAppOrigins(tenantId, origins) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-origins`, {
            method: "DELETE",
            body: JSON.stringify({ origins }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** List tenant redirect URLs used for OAuth and email auth callbacks. */
    async listRedirectUrls(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/redirect-urls`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Add one tenant redirect URL. Requires tenant-admin MFA server-side. */
    async addRedirectUrl(tenantId, url) {
        return this.addRedirectUrls(tenantId, [url]);
    }
    /** Add one or more tenant redirect URLs. Requires tenant-admin MFA server-side. */
    async addRedirectUrls(tenantId, urls) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/redirect-urls`, {
            method: "POST",
            body: JSON.stringify({ urls }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Remove one tenant redirect URL. Requires tenant-admin MFA server-side. */
    async removeRedirectUrl(tenantId, url) {
        return this.removeRedirectUrls(tenantId, [url]);
    }
    /** Remove one or more tenant redirect URLs. Requires tenant-admin MFA server-side. */
    async removeRedirectUrls(tenantId, urls) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/redirect-urls`, {
            method: "DELETE",
            body: JSON.stringify({ urls }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** List tenant app clients/environments. Requires tenant-admin MFA server-side. */
    async listTenantAppClients(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.clients;
    }
    /** Replace the tenant app client/environment registry. Requires tenant-admin MFA server-side. */
    async replaceTenantAppClients(tenantId, clients) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients`, {
            method: "PUT",
            body: JSON.stringify({ clients }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.clients;
    }
    /** Create one tenant app client/environment. Requires tenant-admin MFA server-side. */
    async createTenantAppClient(tenantId, client) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients`, {
            method: "POST",
            body: JSON.stringify({ client }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.client;
    }
    /** Delete one tenant app client/environment. Requires tenant-admin MFA server-side. */
    async deleteTenantAppClient(tenantId, clientId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients/${encodeURIComponent(clientId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.clients;
    }
    /** List app-client secret metadata. Raw secrets are never returned by this endpoint. */
    async listTenantAppClientSecrets(tenantId, clientId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients/${encodeURIComponent(clientId)}/secrets`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Rotate an app-client secret. Returns the raw appSecret once. */
    async rotateTenantAppClientSecret(tenantId, clientId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients/${encodeURIComponent(clientId)}/secrets`, { method: "POST" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Revoke one app-client secret immediately. */
    async revokeTenantAppClientSecret(tenantId, clientId, secretId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/app-clients/${encodeURIComponent(clientId)}/secrets/${encodeURIComponent(secretId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.secret;
    }
    /** List tenant app access allowlist entries for email, domain, wallet, and phone login. */
    async listAccessAllowlistEntries(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/access-allowlist`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Add one tenant app access allowlist entry. Requires tenant-admin MFA server-side. */
    async addAccessAllowlistEntry(tenantId, entry) {
        return this.addAccessAllowlistEntries(tenantId, [entry]);
    }
    /** Add one or more tenant app access allowlist entries. Requires tenant-admin MFA server-side. */
    async addAccessAllowlistEntries(tenantId, entries) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/access-allowlist`, {
            method: "POST",
            body: JSON.stringify({ entries }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Remove one tenant app access allowlist entry. Requires tenant-admin MFA server-side. */
    async removeAccessAllowlistEntry(tenantId, entry) {
        if ("id" in entry) {
            return this.removeAccessAllowlistEntries(tenantId, { ids: [entry.id] });
        }
        return this.removeAccessAllowlistEntries(tenantId, { entries: [entry] });
    }
    /** Remove tenant app access allowlist entries by id or by type/value pair. */
    async removeAccessAllowlistEntries(tenantId, input) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/access-allowlist`, {
            method: "DELETE",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.entries;
    }
    /** Get tenant-scoped OIDC/JWT login provider configuration. */
    async getTenantOidcProviders(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/oidc-providers`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.providers;
    }
    /** Discover whether an email domain should route to tenant SSO. */
    async discoverSso(email) {
        const response = await this.request("/auth/sso/discover", {
            method: "POST",
            body: JSON.stringify({ email }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List tenant verified/draft SSO email domains. Requires tenant-admin MFA server-side. */
    async listTenantSsoDomains(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/sso-domains`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.domains;
    }
    /** Create or reset a tenant SSO email-domain verification token. */
    async createTenantSsoDomain(tenantId, input) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/sso-domains`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.domain;
    }
    /** Mark a tenant SSO domain verified after out-of-band DNS/manual verification. */
    async verifyTenantSsoDomain(tenantId, domain) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/sso-domains/${encodeURIComponent(domain)}/verify`, { method: "POST" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.domain;
    }
    /** Delete a tenant SSO domain. */
    async deleteTenantSsoDomain(tenantId, domain) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/sso-domains/${encodeURIComponent(domain)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
    }
    /** Get tenant SAML dashboard/team SSO config and generated SP URLs. */
    async getTenantSamlSso(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/saml-sso`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Replace tenant SAML dashboard/team SSO config. Requires tenant-admin MFA server-side. */
    async updateTenantSamlSso(tenantId, input) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/saml-sso`, {
            method: "PUT",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.config;
    }
    /** Delete tenant SAML dashboard/team SSO config. */
    async deleteTenantSamlSso(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/saml-sso`, {
            method: "DELETE",
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
    }
    /** Replace tenant-scoped OIDC/JWT login provider configuration. */
    async updateTenantOidcProviders(tenantId, providers) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/oidc-providers`, {
            method: "PUT",
            body: JSON.stringify({ providers }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.providers;
    }
    /** Get tenant-scoped auth abuse and login method controls. */
    async getTenantAuthAbuseConfig(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/auth-abuse-config`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.authAbuseConfig;
    }
    /** Replace tenant-scoped auth abuse and login method controls. */
    async updateTenantAuthAbuseConfig(tenantId, authAbuseConfig) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/auth-abuse-config`, {
            method: "PUT",
            body: JSON.stringify({ authAbuseConfig }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.authAbuseConfig;
    }
    /** Get tenant gas sponsorship/paymaster configuration. */
    async getTenantGasSponsorshipConfig(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/gas-sponsorship`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.gasSponsorshipConfig;
    }
    /** Replace tenant gas sponsorship/paymaster configuration. Requires tenant-admin MFA server-side. */
    async updateTenantGasSponsorshipConfig(tenantId, gasSponsorshipConfig) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/gas-sponsorship`, {
            method: "PATCH",
            body: JSON.stringify({ gasSponsorshipConfig }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.gasSponsorshipConfig;
    }
    /** Get the production security checklist for a tenant deployment. Requires tenant-admin MFA server-side. */
    async getTenantSecurityChecklist(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/security-checklist`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Get privacy-preserving idempotency counters for a tenant. Requires tenant-admin MFA server-side. */
    async getTenantIdempotencyMetrics(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/idempotency-metrics`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List tenant request-signing key metadata. Requires tenant-admin MFA server-side. */
    async listTenantRequestSigningKeys(tenantId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/request-signing-keys`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.keys;
    }
    /** Rotate tenant request-signing keys and reveal the new secret once. */
    async rotateTenantRequestSigningKey(tenantId, input = {}) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/request-signing-keys`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Revoke a tenant request-signing key. Requires tenant-admin MFA server-side. */
    async revokeTenantRequestSigningKey(tenantId, keyId) {
        const response = await this.request(`/tenants/${encodeURIComponent(tenantId)}/request-signing-keys/${encodeURIComponent(keyId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.key;
    }
    // ─── Agent Dashboard ──────────────────────────────────────────
    /** Lists the caller-requested agent approval page using the current session authority. */
    async listPendingApprovals(agentId, options = {}) {
        const params = new URLSearchParams();
        if (options.limit !== undefined)
            params.set("limit", String(options.limit));
        if (options.offset !== undefined)
            params.set("offset", String(options.offset));
        const query = params.toString();
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/pending${query ? `?${query}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        if (!response.data ||
            !Array.isArray(response.data.approvals) ||
            !response.data.approvals.every((approval) => approval &&
                typeof approval === "object" &&
                typeof approval.queueId === "string" &&
                approval.status === "pending" &&
                typeof approval.requestedAt === "string" &&
                approval.transaction &&
                typeof approval.transaction === "object" &&
                !Array.isArray(approval.transaction) &&
                typeof approval.transaction.id === "string")) {
            throw new LoginApiError("Pending approvals response is invalid", 502, response.data);
        }
        return response.data.approvals;
    }
    /** Get the aggregated dashboard for an agent (balance, spend, policies, recent tx, pending approvals). */
    async getAgentDashboard(agentId) {
        const response = await this.request(`/dashboard/${encodeURIComponent(agentId)}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Get on-chain and realtime spend accounting for an agent. */
    async getAgentSpend(agentId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/spend`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Get the aggregated digital asset account for an agent. */
    async getAgentAccount(agentId, opts = {}) {
        const params = new URLSearchParams();
        if (opts.chainId)
            params.set("chainId", String(opts.chainId));
        if (opts.tokens?.length)
            params.set("tokens", opts.tokens.join(","));
        const qs = params.toString();
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/account${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Privy-style alias for an agent's aggregated digital asset account. */
    async getAgentAccountAggregation(agentId, opts = {}) {
        const params = new URLSearchParams();
        if (opts.chainId)
            params.set("chainId", String(opts.chainId));
        if (opts.tokens?.length)
            params.set("tokens", opts.tokens.join(","));
        const qs = params.toString();
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/aggregation${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async listAgentSigners(agentId, opts) {
        const params = new URLSearchParams();
        if (opts?.status)
            params.set("status", opts.status);
        const qs = params.toString();
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/signers${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.signers;
    }
    async createAgentSigner(agentId, input) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/signers`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Privy-style alias for agent signer authorization-key inventory. */
    async listAuthorizationKeys(agentId, opts) {
        return this.listAgentSigners(agentId, opts);
    }
    /** Privy-style alias for registering an agent signer authorization key. */
    async createAuthorizationKey(agentId, input) {
        return this.createAgentSigner(agentId, input);
    }
    async updateAgentSigner(agentId, signerId, input) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/signers/${encodeURIComponent(signerId)}`, {
            method: "PATCH",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Privy-style alias for updating an agent signer authorization key. */
    async updateAuthorizationKey(agentId, keyId, input) {
        return this.updateAgentSigner(agentId, keyId, input);
    }
    async revokeAgentSigner(agentId, signerId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/signers/${encodeURIComponent(signerId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Privy-style alias for revoking an agent signer authorization key. */
    async revokeAuthorizationKey(agentId, keyId) {
        return this.revokeAgentSigner(agentId, keyId);
    }
    async listAgentKeyQuorums(agentId, opts) {
        const params = new URLSearchParams();
        if (opts?.status)
            params.set("status", opts.status);
        const qs = params.toString();
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/key-quorums${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data.quorums;
    }
    async createAgentKeyQuorum(agentId, input) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/key-quorums`, {
            method: "POST",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async updateAgentKeyQuorum(agentId, quorumId, input) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/key-quorums/${encodeURIComponent(quorumId)}`, {
            method: "PATCH",
            body: JSON.stringify(input),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    async revokeAgentKeyQuorum(agentId, quorumId) {
        const response = await this.request(`/agents/${encodeURIComponent(agentId)}/key-quorums/${encodeURIComponent(quorumId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    // ─── Approvals ────────────────────────────────────────────────
    /**
     * Execute an approved vault transaction through the policy-revalidating
     * vault route. The generic approval endpoint deliberately cannot sign or
     * broadcast vault transactions.
     */
    async approveVaultTransaction(agentId, txId) {
        const response = await this.request(`/vault/${encodeURIComponent(agentId)}/approve/${encodeURIComponent(txId)}`, {
            method: "POST",
            body: JSON.stringify({}),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List approval queue entries for the tenant. */
    async listApprovals(opts) {
        const params = new URLSearchParams();
        if (opts?.status)
            params.set("status", opts.status);
        if (opts?.agentId !== undefined)
            params.set("agentId", opts.agentId);
        if (opts?.limit !== undefined)
            params.set("limit", String(opts.limit));
        if (opts?.offset !== undefined)
            params.set("offset", String(opts.offset));
        if (opts?.cursorRequestedAt !== undefined)
            params.set("cursorRequestedAt", opts.cursorRequestedAt);
        if (opts?.cursorId !== undefined)
            params.set("cursorId", opts.cursorId);
        const qs = params.toString();
        const response = await this.request(`/approvals${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Approve a pending transaction. */
    async approveTransaction(txId, opts) {
        const response = await this.request(`/approvals/${encodeURIComponent(txId)}/approve`, {
            method: "POST",
            body: JSON.stringify(opts ?? {}),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Deny a pending transaction. */
    async denyTransaction(txId, reason, deniedBy) {
        const response = await this.request(`/approvals/${encodeURIComponent(txId)}/deny`, {
            method: "POST",
            body: JSON.stringify({ reason, deniedBy }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Poll one held proxy request through the control-plane API. */
    async getPendingProxyRequest(id) {
        const response = await this.request(`/approvals/proxy/${encodeURIComponent(id)}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** List approval-gated proxy requests for an operator. */
    async listPendingProxyRequests(status) {
        const qs = status ? `?status=${encodeURIComponent(status)}` : "";
        const response = await this.request(`/approvals/proxy${qs}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Approve a held proxy request. It executes exactly once when the agent polls the proxy. */
    async approveProxyRequest(id) {
        const response = await this.request(`/approvals/proxy/${encodeURIComponent(id)}/approve`, {
            method: "POST",
            body: "{}",
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Deny a held proxy request without forwarding it. */
    async denyProxyRequest(id, reason) {
        const response = await this.request(`/approvals/proxy/${encodeURIComponent(id)}/deny`, {
            method: "POST",
            body: JSON.stringify({ reason }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Get approval statistics for the tenant. */
    async getApprovalStats() {
        const response = await this.request("/approvals/stats");
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    // ─── Auto-Approval Rules ─────────────────────────────────────
    /** Get auto-approval rules for the tenant. */
    async getAutoApprovalRules() {
        const response = await this.request("/approvals/rules");
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Create or update auto-approval rules. */
    async updateAutoApprovalRules(rules) {
        const response = await this.request("/approvals/rules", {
            method: "PUT",
            body: JSON.stringify(rules),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    // ─── User Tenants ─────────────────────────────
    /** List the tenants the authenticated user is a member of. Requires user JWT. */
    async listUserTenants() {
        const response = await this.request("/user/me/tenants");
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Search users in a tenant directory. Requires user JWT, tenant admin role, and recent MFA. */
    async listTenantUsers(tenantId, opts) {
        const params = new URLSearchParams();
        if (opts?.q)
            params.set("q", opts.q);
        if (opts?.email)
            params.set("email", opts.email);
        if (opts?.walletExternalId)
            params.set("walletExternalId", opts.walletExternalId);
        if (opts?.limit)
            params.set("limit", String(opts.limit));
        if (opts?.offset)
            params.set("offset", String(opts.offset));
        const qs = params.toString();
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return {
            ...response.data,
            users: response.data.users.map(parseTenantAdminUser),
        };
    }
    /** Report existing tenant users that violate the one third-party wallet policy. Requires user JWT, tenant admin role, and recent MFA. */
    async getTenantWalletPolicyViolations(tenantId, opts) {
        const params = new URLSearchParams();
        if (opts?.limit)
            params.set("limit", String(opts.limit));
        if (opts?.offset)
            params.set("offset", String(opts.offset));
        const qs = params.toString();
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/wallet-policy/violations${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Remove one linked third-party wallet from a tenant member as audited one-wallet-policy remediation. Requires user JWT, tenant admin role, and recent MFA. */
    async remediateTenantWalletPolicyViolation(tenantId, userId, accountId) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}/wallet-policy/wallets/${encodeURIComponent(accountId)}`, { method: "DELETE" });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Bulk-remediate selected linked third-party wallets from tenant members. Requires user JWT, tenant admin role, and recent MFA. */
    async bulkRemediateTenantWalletPolicyViolations(tenantId, wallets) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/wallet-policy/remediations`, {
            method: "POST",
            body: JSON.stringify({ wallets }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return response.data;
    }
    /** Export the tenant-scoped user directory as CSV. Requires user JWT, tenant admin role, and recent MFA. */
    async exportTenantUsersCsv(tenantId, opts) {
        const params = new URLSearchParams();
        if (opts?.q)
            params.set("q", opts.q);
        if (opts?.email)
            params.set("email", opts.email);
        if (opts?.limit)
            params.set("limit", String(opts.limit));
        const qs = params.toString();
        const url = `${this.baseUrl}/user/me/tenants/${encodeURIComponent(tenantId)}/users/export${qs ? `?${qs}` : ""}`;
        const { response, text } = await fetchLoginText(url, { headers: this.buildHeaders() }, {
            requestTimeoutMs: this.requestTimeoutMs,
            maxResponseBodyBytes: this.maxResponseBodyBytes,
        });
        if (!response.ok)
            throw new LoginApiError(`Tenant user export failed: ${response.status}`, response.status);
        return text;
    }
    /** Read a tenant-scoped user record. Requires user JWT, tenant admin role, and recent MFA. */
    async getTenantUser(tenantId, userId) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return parseTenantAdminUser(response.data);
    }
    /** List tenant-scoped activity for a user. Requires user JWT, tenant admin role, and recent MFA. */
    async listTenantUserEvents(tenantId, userId, opts) {
        const params = new URLSearchParams();
        if (opts?.limit)
            params.set("limit", String(opts.limit));
        if (opts?.offset)
            params.set("offset", String(opts.offset));
        const qs = params.toString();
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}/events${qs ? `?${qs}` : ""}`);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return parseTenantAdminUserEvents(response.data);
    }
    /** Update a tenant user's team role. Requires user JWT, tenant admin role, and recent MFA. */
    async updateTenantUserRole(tenantId, userId, role) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}/role`, {
            method: "PATCH",
            body: JSON.stringify({ role }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return parseTenantAdminUser(response.data);
    }
    /** Replace tenant-scoped custom metadata. Requires user JWT, tenant admin role, and recent MFA. */
    async updateTenantUserMetadata(tenantId, userId, tenantCustomMetadata) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}/metadata`, {
            method: "PATCH",
            body: JSON.stringify({ tenantCustomMetadata }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return parseTenantAdminUser(response.data);
    }
    /** Deactivate or reactivate an app-scoped tenant user. Requires user JWT, admin role, and MFA. */
    async setTenantUserDeactivated(tenantId, userId, deactivated = true) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}/deactivate`, {
            method: "PATCH",
            body: JSON.stringify({ deactivated }),
        });
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
        return parseTenantAdminUser(response.data);
    }
    /** Remove a user from the current tenant. Requires user JWT, tenant admin role, and recent MFA. */
    async removeTenantUser(tenantId, userId) {
        const response = await this.request(`/user/me/tenants/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}`, { method: "DELETE" }, true);
        if (!response.ok)
            throw new LoginApiError(response.error, response.status, response.data);
    }
    /**
     * Create multiple agent wallets in a single request.
     * Optionally supply a shared policy set to apply to every created agent.
     */
    async createWalletBatch(agents, policies) {
        const normalizedAgents = agents.map(({ externalId, platformId, ...agent }) => ({
            ...agent,
            platformId: platformId ?? externalId,
        }));
        const response = await this.request("/agents/batch", {
            method: "POST",
            body: JSON.stringify({
                agents: normalizedAgents,
                applyPolicies: policies,
            }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        const result = response.data;
        return {
            ...result,
            created: result.created.map(parseAgentIdentity),
        };
    }
    /**
     * Privy-style alias for homogeneous server-wallet batch creation.
     * `externalId` maps to the immutable per-tenant wallet `platformId`.
     */
    async createWalletsBatch(wallets, policies) {
        const response = await this.request("/wallets/batch", {
            method: "POST",
            body: JSON.stringify({ wallets, applyPolicies: policies }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        const result = response.data;
        return {
            ...result,
            created: result.created.map(parseAgentIdentity),
        };
    }
    /**
     * Pre-generate encrypted wallets that can later be claimed by end users.
     * Claim tokens are returned once; the login service stores only token hashes.
     */
    async createPregeneratedUserWallets(input) {
        const response = await this.request("/agents/pregenerated", {
            method: "POST",
            body: JSON.stringify({
                count: input.count,
                namePrefix: input.namePrefix,
                applyPolicies: input.policies,
                claimExpiresInSeconds: input.claimExpiresInSeconds,
            }),
        });
        if (!response.ok) {
            throw new LoginApiError(response.error, response.status, response.data);
        }
        return {
            ...response.data,
            wallets: response.data.wallets.map((wallet) => ({
                ...wallet,
                agent: parseAgentIdentity(wallet.agent),
            })),
        };
    }
    async request(path, init = {}, allowEmpty = false) {
        const { response, payload } = await this.fetchJson(path, init);
        if (!payload ||
            typeof payload !== "object" ||
            Array.isArray(payload) ||
            typeof payload.ok !== "boolean") {
            throw new LoginApiError("Received an invalid response envelope from login API", response.status);
        }
        if (!response.ok || !payload.ok) {
            return {
                ok: false,
                status: response.status,
                error: typeof payload.error === "string"
                    ? payload.error
                    : `Request failed with status ${response.status}`,
                data: payload.data,
            };
        }
        if (typeof payload.data === "undefined") {
            if (!allowEmpty)
                throw new LoginApiError("Login API response is missing required data", response.status);
            return { ok: true, status: response.status, data: undefined };
        }
        return {
            ok: true,
            status: response.status,
            data: payload.data,
        };
    }
    buildHeaders(headers) {
        const merged = new Headers(headers);
        if (!merged.has("Content-Type")) {
            merged.set("Content-Type", "application/json");
        }
        if (!merged.has("Accept")) {
            merged.set("Accept", "application/json");
        }
        if (this.platformKey) {
            merged.set("X-Steward-Platform-Key", this.platformKey);
        }
        else if (this.bearerToken) {
            merged.set("Authorization", `Bearer ${this.bearerToken}`);
        }
        else if (this.appId && this.appSecret) {
            merged.set("Authorization", `Basic ${btoa(`${this.appId}:${this.appSecret}`)}`);
            merged.set("X-Steward-App-Id", this.appId);
        }
        else if (this.apiKey) {
            merged.set("X-Steward-Key", this.apiKey);
        }
        if (this.tenantId) {
            merged.set("X-Steward-Tenant", this.tenantId);
        }
        return merged;
    }
    async buildRequestHeaders(path, init) {
        const headers = this.buildHeaders(init.headers);
        const method = (init.method ?? "GET").toUpperCase();
        if (!this.requestSigningSecret || !isSensitiveMutatingRequest(path, method))
            return headers;
        if (!headers.has("X-Steward-Request-Timestamp")) {
            headers.set("X-Steward-Request-Timestamp", String(Math.floor(Date.now() / 1000)));
        }
        if (!headers.has("Idempotency-Key")) {
            headers.set("Idempotency-Key", randomIdempotencyKey());
        }
        if (this.requestSigningKeyId && !headers.has("X-Steward-Signing-Key-Id")) {
            headers.set("X-Steward-Signing-Key-Id", this.requestSigningKeyId);
        }
        const body = typeof init.body === "string" ? init.body : "";
        const bodyHash = await sha256Hex(body);
        const authHash = await sha256Hex(headers.get("Authorization") ?? "");
        const apiKeyHash = await sha256Hex(headers.get("X-Steward-Key") ?? "");
        const platformKeyHash = await sha256Hex(headers.get("X-Steward-Platform-Key") ?? "");
        const signerIdHash = await sha256Hex(headers.get("X-Steward-Signer-Id") ?? "");
        const signerSecretHash = await sha256Hex(headers.get("X-Steward-Signer-Secret") ?? "");
        const quorumIdHash = await sha256Hex(headers.get("X-Steward-Key-Quorum-Id") ?? "");
        const quorumCredentialsHash = await sha256Hex(headers.get("X-Steward-Key-Quorum-Credentials") ?? "");
        const canonical = [
            "steward-request-signature-v1",
            method,
            path,
            headers.get("X-Steward-Tenant") ?? "",
            authHash,
            apiKeyHash,
            platformKeyHash,
            signerIdHash,
            signerSecretHash,
            quorumIdHash,
            quorumCredentialsHash,
            headers.get("X-Steward-Request-Timestamp") ?? "",
            headers.get("X-Steward-Request-Expires-At") ?? "",
            headers.get("Idempotency-Key") ?? "",
            bodyHash,
        ].join("\n");
        headers.set("X-Steward-Signature", `v1=${await hmacSha256Hex(this.requestSigningSecret, canonical)}`);
        return headers;
    }
    async fetchJson(path, init) {
        return fetchLoginJson(`${this.baseUrl}${path}`, init, {
            requestTimeoutMs: this.requestTimeoutMs,
            maxResponseBodyBytes: this.maxResponseBodyBytes,
        }, () => this.buildRequestHeaders(path, init));
    }
    isPendingApproval(data) {
        return (typeof data !== "undefined" &&
            "status" in data &&
            data.status === "pending_approval");
    }
    isBroadcastOutcomeUnknown(data) {
        return (typeof data !== "undefined" &&
            "code" in data &&
            data.code === "external_broadcast_outcome_unknown" &&
            "reconciliationRequired" in data &&
            data.reconciliationRequired === true &&
            "txHash" in data &&
            typeof data.txHash === "string" &&
            "txId" in data &&
            typeof data.txId === "string");
    }
}
//# sourceMappingURL=client.js.map