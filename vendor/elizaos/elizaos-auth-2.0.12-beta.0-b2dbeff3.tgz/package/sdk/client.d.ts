import { LoginApiError } from "./transport.js";
export { LoginApiError } from "./transport.js";
import type { AgentAccountSummary, AgentBalance, AgentDashboardResponse, AgentIdentity, AgentKeyQuorum, AgentKeyQuorumCreate, AgentKeyQuorumStatus, AgentKeyQuorumUpdate, AgentSigner, AgentSignerCreate, AgentSignerCreateResult, AgentSignerStatus, AgentSignerUpdate, AgentSpendSummary, ApprovalQueueEntry, ApprovalStats, AuthorizationKey, AuthorizationKeyCreate, AuthorizationKeyCreateResult, AuthorizationKeyUpdate, AutoApprovalRule, ChainFamily, EncryptedAgentKeyImportInitResult, EncryptedAgentKeyImportResult, EncryptedAgentKeyImportSubmitInput, EncryptedUserWalletKeyImportInitResult, EncryptedUserWalletKeyImportResult, EncryptedUserWalletKeyImportSubmitInput, ExportKeyResult, PendingProxyRequest, PendingProxyRequestStatus, PlatformLinkAccountResult, PlatformTenantInvitationCreateResult, PlatformTenantInvitationListResult, PlatformTenantUser, PlatformTransferAccountResult, PlatformUserCreateInput, PlatformUserCreateResult, PlatformUserDeactivateResult, PlatformUserDeleteResult, PlatformUserIdentity, PlatformUserLookupResult, PlatformUserSearchResult, PlatformWalletExternalIdAssignInput, PlatformWalletExternalIdAssignResult, PlatformWalletExternalIdConnectOrCreateInput, PlatformWalletExternalIdConnectOrCreateResult, PolicyResult, PolicyRule, PregeneratedUserWalletClaimResult, PregeneratedUserWalletCreateResult, RpcResponse, SponsoredGasSpendSummary, SsoDiscoveryResult, TenantAccessAllowlistEntry, TenantAccessAllowlistEntryInput, TenantAdminUser, TenantAdminUserEventsResult, TenantAdminUserSearchResult, TenantAppClient, TenantAppClientSecret, TenantAppClientSecretCreateResult, TenantAuthAbuseConfig, TenantControlPlaneConfig, TenantGasSponsorshipConfig, TenantIdempotencyMetrics, TenantMembership, TenantOidcProviderConfig, TenantRequestSigningKey, TenantRequestSigningKeyCreateResult, TenantSamlSsoConfig, TenantSamlSsoUpdate, TenantSecurityChecklist, TenantSsoDomain, TenantTeamRole, TenantTestAccountConfig, TenantWalletPolicyBulkRemediationItem, TenantWalletPolicyBulkRemediationResponse, TenantWalletPolicyRemediationResult, TenantWalletPolicyViolationReport, TxRecord, TypedDataDomain, TypedDataField, UserAccountSummary, UserPushSubscriptionInput, UserPushSubscriptionListResult, UserPushSubscriptionResult, UserWalletCreateResult, UserWalletHistoryResult, UserWalletRecoveryRestoreResult, UserWalletRecoverySetupResult, UserWalletSigner, UserWalletSignerCreate, UserWalletSignerCreateResult, UserWalletSignMessageResult, UserWalletSignResult } from "./types.js";
export interface BatchAgentSpec {
    id: string;
    name: string;
    /** login-native immutable per-tenant wallet external identifier. */
    platformId?: string;
    /** Privy-style alias for platformId. Ignored when platformId is supplied. */
    externalId?: string;
}
export interface BatchCreateResult {
    created: AgentIdentity[];
    errors: Array<{
        id: string;
        error: string;
    }>;
}
export interface WalletBatchSpec {
    /** Client-side reference id used only for partial-failure reporting. */
    id: string;
    name: string;
    /** Immutable per-tenant wallet external id. */
    externalId?: string;
}
export type WalletBatchCreateResult = BatchCreateResult;
export type GetBalanceResult = AgentBalance;
export interface UserWalletSelector {
    walletIndex?: number;
}
export interface UserWalletBalanceInput extends UserWalletSelector {
    chainId?: number;
}
export interface LoginClientConfig {
    baseUrl: string;
    apiKey?: string;
    /** Privy-style app id for server auth, sent as Basic auth username and X-Steward-App-Id. */
    appId?: string;
    /** Privy-style app secret for server auth, sent only through Basic auth. */
    appSecret?: string;
    /** Platform management key - sent as `X-Steward-Platform-Key`. */
    platformKey?: string;
    /** Agent-scoped JWT - sent as `Authorization: Bearer <token>`. Preferred over apiKey when both are set. */
    bearerToken?: string;
    tenantId?: string;
    /** Optional HMAC secret used to sign sensitive mutating requests. */
    requestSigningSecret?: string;
    /** Optional tenant request-signing key id, sent as `X-Steward-Signing-Key-Id`. */
    requestSigningKeyId?: string;
    /**
     * Server-grade credentials are blocked in browser runtimes by default because
     * injected scripts can read request headers. Prefer bearerToken in browsers.
     */
    allowUnsafeBrowserSecrets?: boolean;
    /**
     * Permit a plaintext non-loopback baseUrl (warns at construction). HTTPS is
     * required by default so credentials never travel cleartext off-loopback.
     */
    allowInsecureBaseUrl?: boolean;
    /**
     * End-to-end request deadline, including request-header signing, receipt of
     * response headers, and consumption of the response body. Defaults to 30s.
     */
    requestTimeoutMs?: number;
    /**
     * Maximum decoded response-body bytes accepted from the API. Defaults to
     * 8 MiB and can never exceed the SDK's 16 MiB safety ceiling.
     */
    maxResponseBodyBytes?: number;
}
export interface QuorumSignerCredential {
    signerId: string;
    signerSecret: string;
}
export interface LoginSignerAuthOptions {
    /** Delegated signer id for non-admin flows. */
    signerId?: string;
    /** One-time-issued signer credential secret for delegated flows. */
    signerSecret?: string;
    /** Key quorum id for multi-signer non-admin flows. */
    keyQuorumId?: string;
    /** Signer-bound credentials that satisfy the key quorum threshold. */
    keyQuorumCredentials?: QuorumSignerCredential[];
}
export interface SignTransactionInput {
    to: string;
    value: string;
    data?: string;
    chainId?: number;
    broadcast?: boolean;
}
export type SignTransactionOptions = LoginSignerAuthOptions;
export interface SignTypedDataInput {
    domain: TypedDataDomain;
    types: Record<string, TypedDataField[]>;
    primaryType: string;
    value: Record<string, unknown>;
}
export type SignTypedDataOptions = LoginSignerAuthOptions;
export interface SignUserOperationInput {
    userOperation: {
        sender: string;
        nonce: string;
        initCode?: string;
        callData: string;
        verificationGasLimit: string;
        callGasLimit: string;
        preVerificationGas: string;
        maxPriorityFeePerGas: string;
        maxFeePerGas: string;
        paymasterAndData?: string;
    };
    entryPoint?: string;
    chainId: number;
    /** Explicit policy recipient until calldata-level extraction is configured. */
    to: string;
    /** Explicit policy value in wei until calldata-level extraction is configured. */
    value: string;
    /** Optional caller-supplied ID mirrored in action payloads and lifecycle webhooks. */
    referenceId?: string;
}
export type SignUserOperationOptions = LoginSignerAuthOptions;
export interface SignAuthorizationInput {
    contractAddress: string;
    /** EIP-7702 allows 0 to designate any chain. */
    chainId: number;
    nonce: number;
    /** Optional caller-supplied ID mirrored in action payloads and lifecycle webhooks. */
    referenceId?: string;
}
export type SignAuthorizationOptions = LoginSignerAuthOptions;
export interface SignSolanaTransactionInput {
    transaction: string;
    chainId?: number;
    broadcast?: boolean;
}
export interface RpcPassthroughInput {
    method: string;
    params?: unknown[];
    chainId: number;
}
export interface LoginPendingApproval {
    status: "pending_approval";
    results: PolicyResult[];
}
/**
 * The provider produced a deterministic transaction hash, but the login service could
 * not prove whether the upstream broadcast was accepted. Callers must
 * reconcile `txHash` and must not submit the intent again.
 */
export interface LoginBroadcastOutcomeUnknown {
    code: "external_broadcast_outcome_unknown";
    txId: string;
    txHash: string;
    reconciliationRequired: true;
}
export interface LoginHistoryEntry {
    timestamp: number;
    value: string;
}
export interface SignMessageResult {
    signature: string;
}
export type SignMessageOptions = LoginSignerAuthOptions;
export interface SignRawHashInput {
    hash: `0x${string}`;
    /** Optional caller-supplied ID mirrored in audit metadata. */
    referenceId?: string;
    /** Delegated signer or key quorum authentication for non-admin unsafe signing flows. */
    signerId?: LoginSignerAuthOptions["signerId"];
    signerSecret?: LoginSignerAuthOptions["signerSecret"];
    keyQuorumId?: LoginSignerAuthOptions["keyQuorumId"];
    keyQuorumCredentials?: LoginSignerAuthOptions["keyQuorumCredentials"];
}
export interface SignRawHashResult {
    signature: string;
    hash: `0x${string}`;
    walletAddress: string;
}
type IdempotencyOptions = {
    idempotencyKey?: string;
};
/**
 * Result of creating a wallet. For new agents, includes `walletAddresses`
 * with both EVM and Solana addresses.
 */
export type CreateWalletResult = AgentIdentity;
export interface GetAddressesResult {
    agentId: string;
    addresses: Array<{
        chainFamily: ChainFamily;
        address: string;
    }>;
}
export interface AdapterTokenRef {
    address: string;
    symbol?: string;
    decimals?: number;
}
export interface AdapterUnsignedIntent {
    signed: false;
    kind: "evm-tx" | "evm-typed-data" | "abstract-intent";
    chainId: number;
    to: string;
    value: string;
    data?: string;
    owner: string;
    category: string;
    provider: string;
    metadata?: Record<string, unknown>;
}
export type AdapterRegistryDescription = Record<string, unknown>;
export type GetHistoryResult = LoginHistoryEntry[];
export type SignTransactionResult = {
    txHash: string;
    caip2?: string;
} | {
    signedTx: string;
    caip2?: string;
} | LoginPendingApproval | LoginBroadcastOutcomeUnknown;
export interface TransferActionQuoteInput {
    to: string;
    /** ERC20 token contract address. Defaults to native chain asset. */
    token?: "native" | string;
    value?: string;
    amountWei?: string;
    chainId?: number;
    broadcast?: boolean;
    /** Optional caller-supplied ID mirrored in action payloads and lifecycle webhooks. */
    referenceId?: string;
    /** Request tenant-configured gas sponsorship for supported execution paths. */
    sponsor?: boolean;
}
export type WalletActionOptions = LoginSignerAuthOptions;
export interface UserLinkedAccount {
    id: string;
    provider: string;
    providerAccountId: string;
    expiresAt: number | null;
    type?: string;
    embeddedWallets?: Array<{
        address: string;
    }>;
    smartWallets?: Array<{
        address: string;
    }>;
    providerApp?: {
        id: string;
        name: string | null;
        logoUrl: string | null;
    };
    firstVerifiedAt?: string | Date;
    latestVerifiedAt?: string | Date;
}
export interface UserAccountsResult {
    accounts: UserLinkedAccount[];
    primaryLoginMethods: Array<{
        provider: "email" | "wallet";
        providerAccountId: string;
    }>;
}
export interface GlobalWalletAppSummary {
    id: string;
    appId: string;
    tenantId: string;
    name: string;
    environment: string;
    origin: string;
    redirectUri: string | null;
}
export interface GlobalWalletConsent {
    id: string;
    tenantId: string;
    clientId: string;
    appId: string;
    origin: string;
    redirectUri: string | null;
    walletAgentId: string | null;
    walletAddress: string | null;
    walletIndex: number | null;
    scopes: string[];
    status: string;
    grantedAt: string | Date;
    lastUsedAt: string | Date | null;
    expiresAt: string | Date | null;
    revokedAt: string | Date | null;
    createdAt: string | Date;
    updatedAt: string | Date;
}
export interface GlobalWalletConsentRequest {
    app: GlobalWalletAppSummary;
    requestedScopes: string[];
    wallet: {
        agentId: string;
        address: string;
        walletIndex: number;
    };
    consent: GlobalWalletConsent | null;
}
export interface GlobalWalletApproveResult {
    consent: GlobalWalletConsent;
    wallet: {
        agentId: string;
        address: string;
        walletIndex: number;
    };
}
export interface GlobalWalletRpcResult<T = unknown> {
    jsonrpc: string;
    id: unknown;
    result: T;
}
export interface GlobalWalletActionConfirmation {
    confirmationId: string;
    method: "personal_sign" | "eth_signTypedData_v4" | "eth_sendTransaction" | string;
    wallet?: {
        agentId: string;
        address: string;
        walletIndex: number;
    };
    expiresAt: string;
}
export interface GlobalWalletTransactionScan {
    method: "eth_sendTransaction";
    wallet: {
        address: string;
        agentId: string;
        walletIndex: number;
    };
    transaction: {
        from?: string;
        to: string;
        valueWei: string;
        data?: string;
        chainId: number;
    };
    blocked: boolean;
    riskLevel: "low" | "medium" | "high" | "blocked";
    warnings: Array<{
        code: string;
        severity: "info" | "warning" | "error";
        message: string;
    }>;
    confirmationRequired: boolean;
    executionSupported: boolean;
    unsupportedReason?: string | null;
}
export interface UserAccountUnlinkResult {
    deleted: boolean;
    issuedBefore: number;
}
export interface UserEthereumWalletLinkNonce {
    nonce: string;
    message: string;
    expiresIn: number;
    address?: string;
}
export interface UserEthereumWalletLinkResult {
    account: UserLinkedAccount;
    isNew: boolean;
}
export interface UserSolanaWalletLinkNonce {
    nonce: string;
    message: string;
    expiresIn: number;
    publicKey?: string;
}
export interface UserSolanaWalletLinkResult {
    account: UserLinkedAccount;
    isNew: boolean;
}
export interface UserOAuthAccountLinkResult {
    account: UserLinkedAccount;
    isNew: boolean;
}
export interface UserOAuthAccountLinkChallenge {
    state: string;
    redirectUri: string;
    expiresIn: number;
    /** Present for S256 challenges; the redirect must also be registered with the provider. */
    authorizationUrl?: string;
}
export interface UserPhoneAccountLinkSendResult {
    phone: string;
    expiresAt: string;
}
export interface UserPhoneAccountLinkResult {
    account: UserLinkedAccount;
    isNew: boolean;
}
export interface UserSocialAccountLinkResult {
    account: UserLinkedAccount;
    isNew: boolean;
}
export interface UserSocialAccountLinkChallenge {
    challengeId?: string;
    nonce?: string;
    expiresIn: number;
}
export type AgentPolicyRuleCreate = Omit<PolicyRule, "id" | "enabled"> & {
    id?: string;
    enabled?: boolean;
};
export type AgentPolicyRuleUpdate = Partial<Omit<PolicyRule, "id">> & {
    id?: never;
};
export interface TransferActionQuote {
    quoteId: string;
    type: "transfer";
    chainId: number;
    from: string;
    to: string;
    value: string;
    token: "native" | string;
    expiresAt: string;
    request: {
        to: string;
        token: "native" | string;
        value: string;
        chainId: number;
        broadcast: boolean;
        referenceId?: string;
        sponsor?: boolean;
    };
}
export interface SendCallsActionInput {
    calls: Array<{
        to: string;
        value?: string;
        data?: string;
    }>;
    chainId?: number;
    broadcast?: boolean;
    /** Optional caller-supplied ID mirrored in action payloads and lifecycle webhooks. */
    referenceId?: string;
    /** Request tenant-configured gas sponsorship for supported execution paths. */
    sponsor?: boolean;
}
export type TransferActionStatus = "pending_approval" | "rejected" | "signed" | "broadcast" | "confirmed" | "failed" | "outcome_unknown";
export interface TransferAction {
    id: string;
    type: "transfer";
    status: TransferActionStatus;
    chainId: number;
    to: string;
    value: string;
    token: "native" | string;
    txHash?: string;
    signedTx?: string;
    sponsorship?: {
        requested: boolean;
        sponsored: boolean;
        provider?: string;
        mode?: string;
        estimatedUsd?: number | null;
    };
    policyResults?: PolicyResult[];
    createdAt?: string;
    signedAt?: string;
    confirmedAt?: string;
}
export interface SendCallsAction {
    id: string;
    type: "send_calls";
    status: "pending_approval" | "rejected";
    chainId: number;
    calls: Array<{
        to: string;
        value: string;
        data?: string;
    }>;
    totalValue: string;
    sponsorship?: {
        requested: boolean;
        sponsored: boolean;
        provider?: string;
        mode?: string;
        estimatedUsd?: number | null;
    };
    policyResults?: Array<PolicyResult & {
        callIndex?: number;
    }>;
}
export type SignTypedDataResult = {
    signature: string;
};
export type SignUserOperationResult = {
    signature: string;
    userOperationHash: string;
    entryPoint: string;
    chainId: number;
    txId: string;
};
export type SignAuthorizationResult = {
    authorization: {
        contractAddress: string;
        chainId: number;
        nonce: number;
        r: string;
        s: string;
        yParity: 0 | 1;
    };
    txId: string;
};
export type SignSolanaTransactionResult = {
    signature: string;
    broadcast: boolean;
    chainId?: number;
    caip2?: string;
};
export type RpcPassthroughResult = RpcResponse;
export type TransactionListResult = {
    transactions: TxRecord[];
    limit: number;
    offset: number;
};
export type VaultApprovalResult = {
    txId: string;
    txHash?: string;
    signedTx?: string;
};
export type TransactionLifecycleEventType = "transaction.broadcasted" | "transaction.confirmed" | "transaction.execution_reverted" | "transaction.replaced" | "transaction.failed" | "transaction.provider_error" | "transaction.still_pending";
export interface TransactionLifecycleUpdateInput {
    type: TransactionLifecycleEventType;
    txHash?: string;
    replacementTxHash?: string;
    reason?: string;
    error?: string;
    provider?: string;
    blockNumber?: string | number;
    confirmations?: number;
}
export interface TransactionReplaceInput {
    replacementTxHash: string;
    reason?: string;
    provider?: string;
    blockNumber?: string | number;
    confirmations?: number;
}
export interface LoginMfaRequiredErrorData {
    mfaRequired?: true;
    reason?: string;
    maxAgeSeconds?: number;
    mfaVerifiedAt?: number | null;
}
export type LoginErrorResponse = {
    results?: PolicyResult[];
} & LoginMfaRequiredErrorData;
export declare function isLoginMfaRequiredError(error: unknown): error is LoginApiError<LoginMfaRequiredErrorData>;
export declare function isLoginBroadcastOutcomeUnknown(result: SignTransactionResult): result is LoginBroadcastOutcomeUnknown;
export declare class LoginClient {
    private readonly baseUrl;
    private readonly apiKey?;
    private readonly appId?;
    private readonly appSecret?;
    private readonly platformKey?;
    private readonly bearerToken?;
    private readonly tenantId?;
    private readonly requestSigningSecret?;
    private readonly requestSigningKeyId?;
    private readonly requestTimeoutMs;
    private readonly maxResponseBodyBytes;
    constructor({ baseUrl, apiKey, appId, appSecret, platformKey, bearerToken, tenantId, requestSigningSecret, requestSigningKeyId, allowUnsafeBrowserSecrets, allowInsecureBaseUrl, requestTimeoutMs, maxResponseBodyBytes, }: LoginClientConfig);
    getBaseUrl(): string;
    readonly platformUsers: {
        create: (input: PlatformUserCreateInput) => Promise<PlatformUserCreateResult>;
        getIdentity: (userId: string) => Promise<PlatformUserIdentity>;
        updateCustomMetadata: (userId: string, customMetadata: Record<string, unknown>) => Promise<PlatformUserIdentity>;
        deactivate: (userId: string, deactivated?: boolean) => Promise<PlatformUserDeactivateResult>;
        delete: (userId: string) => Promise<PlatformUserDeleteResult>;
        lookup: (opts: {
            email?: string;
            phone?: string;
            walletAddress?: string;
            walletExternalId?: string;
            smartWalletId?: string;
            customAuthId?: string;
            provider?: string;
            providerAccountId?: string;
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByEmailAddress: (email: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByPhoneNumber: (phone: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByWalletAddress: (walletAddress: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByWalletExternalId: (walletExternalId: string, opts: {
            tenantId: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserBySmartWalletAddress: (smartWalletId: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByCustomAuthId: (customAuthId: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByProviderAccount: (provider: string, providerAccountId: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByDiscordUsername: (username: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByGithubUsername: (username: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByFarcasterId: (fid: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByInstagramUsername: (username: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserBySpotifySubject: (subject: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByTelegramUserId: (id: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByTelegramUsername: (username: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByTwitchUsername: (username: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByTwitterSubject: (subject: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        getUserByTwitterUsername: (username: string, opts?: {
            tenantId?: string;
        }) => Promise<PlatformUserLookupResult>;
        search: (tenantId: string, opts?: {
            q?: string;
            email?: string;
            walletExternalId?: string;
            limit?: number;
            offset?: number;
        }) => Promise<PlatformUserSearchResult>;
        get: (tenantId: string, userId: string) => Promise<PlatformTenantUser>;
        updateMetadata: (tenantId: string, userId: string, metadata: {
            customMetadata?: Record<string, unknown>;
            tenantCustomMetadata?: Record<string, unknown>;
        }) => Promise<PlatformTenantUser>;
        listInvitations: (tenantId: string, opts?: {
            status?: "pending" | "accepted" | "revoked" | "expired" | "all";
            limit?: number;
            offset?: number;
        }) => Promise<PlatformTenantInvitationListResult>;
        createInvitation: (tenantId: string, input: {
            email: string;
            role?: Exclude<TenantTeamRole, "owner"> | string;
            expiresInSeconds?: number;
            invitedByUserId?: string;
            sendEmail?: boolean;
        }) => Promise<PlatformTenantInvitationCreateResult>;
        revokeInvitation: (tenantId: string, invitationId: string) => Promise<void>;
        linkAccount: (userId: string, input: {
            provider: string;
            providerAccountId: string;
            tenantId?: string;
        }) => Promise<PlatformLinkAccountResult>;
        unlinkAccount: (userId: string, provider: string, providerAccountId: string, opts?: {
            force?: boolean;
        }) => Promise<void>;
        transferAccount: (fromUserId: string, provider: string, providerAccountId: string, input: {
            toUserId: string;
            force?: boolean;
        }) => Promise<PlatformTransferAccountResult>;
        assignWalletExternalId: (userId: string, input: PlatformWalletExternalIdAssignInput) => Promise<PlatformWalletExternalIdAssignResult>;
        resolveWalletExternalId: (input: PlatformWalletExternalIdAssignInput) => Promise<PlatformUserLookupResult>;
        connectOrCreateByWalletExternalId: (input: PlatformWalletExternalIdConnectOrCreateInput) => Promise<PlatformWalletExternalIdConnectOrCreateResult>;
    };
    readonly platformApps: {
        getGasSpend: (input: {
            tenantId: string;
            walletIds?: string[];
            walletExternalIds?: string[];
            startTimestamp?: number;
            endTimestamp?: number;
        }) => Promise<SponsoredGasSpendSummary>;
    };
    readonly platformTestAccounts: {
        get: (tenantId: string) => Promise<TenantTestAccountConfig>;
        enable: (tenantId: string) => Promise<TenantTestAccountConfig>;
        disable: (tenantId: string) => Promise<TenantTestAccountConfig>;
    };
    createWallet(agentId: string, name: string, platformId?: string): Promise<CreateWalletResult>;
    signTransaction(agentId: string, tx: SignTransactionInput, options?: SignTransactionOptions): Promise<SignTransactionResult>;
    quoteTransfer(agentId: string, input: TransferActionQuoteInput): Promise<TransferActionQuote>;
    createTransferAction(agentId: string, input: TransferActionQuoteInput, options?: WalletActionOptions): Promise<TransferAction>;
    createSendCallsAction(agentId: string, input: SendCallsActionInput, options?: WalletActionOptions): Promise<SendCallsAction>;
    getTransferAction(agentId: string, actionId: string): Promise<TransferAction>;
    getPolicies(agentId: string): Promise<PolicyRule[]>;
    /**
     * Replace the policy set for an agent. Returns the stored policies
     * (with server-assigned ids where applicable).
     */
    setPolicies(agentId: string, policies: PolicyRule[]): Promise<PolicyRule[]>;
    listPolicyRules(agentId: string): Promise<PolicyRule[]>;
    createPolicyRule(agentId: string, rule: AgentPolicyRuleCreate): Promise<PolicyRule>;
    getPolicyRule(agentId: string, ruleId: string): Promise<PolicyRule>;
    updatePolicyRule(agentId: string, ruleId: string, update: AgentPolicyRuleUpdate): Promise<PolicyRule>;
    deletePolicyRule(agentId: string, ruleId: string): Promise<PolicyRule>;
    getAgent(agentId: string): Promise<AgentIdentity>;
    listAgents(): Promise<AgentIdentity[]>;
    /**
     * Return a compact history feed for an agent. Each entry is a
     * `{ timestamp, value }` pair - suitable for trend charts and volume
     * windows. For the full signed-transaction objects, prefer
     * {@link getTransactionHistory}.
     */
    getHistory(agentId: string): Promise<GetHistoryResult>;
    /**
     * Return the full transaction history for an agent as `TxRecord[]`.
     * Includes status, policy results, tx hash, timestamps, and the
     * original sign request.
     */
    getTransactionHistory(agentId: string): Promise<TxRecord[]>;
    listTransactions(agentId: string, opts?: {
        status?: string;
        actionType?: string;
        txHash?: string;
        referenceId?: string;
        limit?: number;
        offset?: number;
    }): Promise<TransactionListResult>;
    getTransaction(agentId: string, txId: string): Promise<TxRecord>;
    updateTransactionLifecycle(agentId: string, txId: string, input: TransactionLifecycleUpdateInput): Promise<TxRecord>;
    replaceTransaction(agentId: string, txId: string, input: TransactionReplaceInput): Promise<TxRecord>;
    signMessage(agentId: string, message: string, options?: SignMessageOptions): Promise<SignMessageResult>;
    signRawHash(agentId: string, input: SignRawHashInput): Promise<SignRawHashResult>;
    /**
     * Sign EIP-712 typed data (`eth_signTypedData_v4`).
     * Used for DEX approvals, ERC-20 permits, and structured data signatures.
     */
    signTypedData(agentId: string, input: SignTypedDataInput, options?: SignTypedDataOptions): Promise<SignTypedDataResult>;
    /**
     * Sign an ERC-4337 EntryPoint v0.7 user operation (`eth_signUserOperation`).
     * `to` and `value` are required for policy evaluation until calldata extraction is configured.
     */
    signUserOperation(agentId: string, input: SignUserOperationInput, options?: SignUserOperationOptions): Promise<SignUserOperationResult>;
    /**
     * Sign an EIP-7702 set-code authorization for inclusion in an authorizationList.
     */
    signAuthorization(agentId: string, input: SignAuthorizationInput, options?: SignAuthorizationOptions): Promise<SignAuthorizationResult>;
    /**
     * Sign a serialized Solana transaction.
     * Pass a base64-encoded transaction; optionally broadcast via Solana RPC.
     */
    signSolanaTransaction(agentId: string, input: SignSolanaTransactionInput, options?: IdempotencyOptions): Promise<SignSolanaTransactionResult>;
    /**
     * Proxy a read-only RPC call to the appropriate chain provider.
     * Signing/state-modifying methods are blocked server-side.
     */
    rpcPassthrough(agentId: string, input: RpcPassthroughInput): Promise<RpcPassthroughResult>;
    /**
     * Get the on-chain native balance for an agent wallet.
     * Optionally pass a chainId to query a specific network (defaults to the server's active chain).
     */
    getBalance(agentId: string, chainId?: number): Promise<GetBalanceResult>;
    /**
     * Get all wallet addresses for an agent across all chain families.
     * New agents have both EVM and Solana addresses; legacy agents have EVM only.
     */
    getAddresses(agentId: string): Promise<GetAddressesResult>;
    /**
     * Export the private keys for the authenticated user's personal wallet.
     * Requires a user session token (Bearer JWT).
     */
    exportUserWalletKey(input?: UserWalletSelector): Promise<ExportKeyResult>;
    /**
     * Initialize a one-time encrypted private-key import session for the
     * authenticated user's embedded wallet. Requires a personal user session with
     * recent MFA and the audited import feature flags.
     */
    initializeEncryptedUserWalletKeyImport(chain: "evm" | "solana", input?: UserWalletSelector): Promise<EncryptedUserWalletKeyImportInitResult>;
    /**
     * Submit an encrypted private-key import envelope for the authenticated user's
     * embedded wallet. Plaintext privateKey fields are rejected by the API.
     */
    submitEncryptedUserWalletKeyImport(input: EncryptedUserWalletKeyImportSubmitInput): Promise<EncryptedUserWalletKeyImportResult>;
    /**
     * Get the authenticated user's embedded wallet native balance.
     * Requires a personal user session token (Bearer JWT).
     */
    getUserWallet(input?: number | UserWalletBalanceInput): Promise<GetBalanceResult>;
    /** Privy-style alias for the authenticated user's embedded wallet balance. */
    getUserWalletBalance(input?: number | UserWalletBalanceInput): Promise<GetBalanceResult>;
    /**
     * Provision the authenticated user's embedded wallet if needed.
     * Requires a personal user session token (Bearer JWT).
     */
    createUserWallet(input?: UserWalletSelector): Promise<UserWalletCreateResult>;
    /** Privy-style alias for authenticated user-wallet provisioning. */
    provisionUserWallet(input?: UserWalletSelector): Promise<UserWalletCreateResult>;
    /**
     * Provision the authenticated user's wallet from a one-time BIP-39 recovery
     * phrase. Requires a user session token with recent MFA and only works before
     * a user wallet already exists.
     */
    setupUserWalletRecovery(input?: UserWalletSelector): Promise<UserWalletRecoverySetupResult>;
    /**
     * Restore/import the authenticated user's mnemonic-backed wallet. Requires a
     * user session with recent MFA. The mnemonic is sent once and is never returned.
     */
    restoreUserWalletRecovery(input: {
        mnemonic: string;
        walletIndex?: number;
    }): Promise<UserWalletRecoveryRestoreResult>;
    /**
     * Claim a tenant-admin pregenerated wallet for the authenticated user.
     * Requires a personal user session with recent MFA and no existing user wallet.
     */
    claimPregeneratedUserWallet(input: {
        tenantId: string;
        claimToken: string;
        walletIndex?: number;
    }): Promise<PregeneratedUserWalletClaimResult>;
    /**
     * Sign a native transfer with the authenticated user's embedded wallet.
     * Broadcast requests require an idempotency key server-side.
     */
    signUserWalletTransaction(input: SignTransactionInput & UserWalletSelector, options?: {
        idempotencyKey?: string;
    }): Promise<UserWalletSignResult>;
    /** Sign a message with the authenticated user's embedded wallet when server-side unsafe signing is enabled. */
    signUserWalletMessage(message: string, input?: UserWalletSelector): Promise<UserWalletSignMessageResult>;
    /** List the authenticated user's embedded-wallet transaction history. */
    getUserWalletHistory(opts?: {
        limit?: number;
        offset?: number;
        walletIndex?: number;
    }): Promise<UserWalletHistoryResult>;
    /** Get active/default policy rules for the authenticated user's embedded wallet. */
    getUserWalletPolicies(input?: UserWalletSelector): Promise<PolicyRule[]>;
    /** List additional signer credentials for the authenticated user's embedded wallet. */
    listUserWalletSigners(input?: UserWalletSelector & {
        status?: AgentSignerStatus;
    }): Promise<UserWalletSigner[]>;
    /**
     * Create a server-issued signer credential for the authenticated user's embedded wallet.
     * The returned credentialSecret is shown once.
     */
    createUserWalletSigner(input?: UserWalletSignerCreate): Promise<UserWalletSignerCreateResult>;
    /** Revoke an additional signer credential on the authenticated user's embedded wallet. */
    revokeUserWalletSigner(signerId: string, input?: UserWalletSelector): Promise<UserWalletSigner>;
    /** List linked accounts for the authenticated user. Requires user JWT. */
    listUserAccounts(): Promise<UserAccountsResult>;
    /** Get the authenticated user's aggregated account, wallets, portfolio, and spend. */
    getUserAccount(opts?: {
        chainId?: number;
        tokens?: string[];
    }): Promise<UserAccountSummary>;
    /** Privy-style alias for the authenticated user's aggregated account summary. */
    getUserAccountAggregation(opts?: {
        chainId?: number;
        tokens?: string[];
    }): Promise<UserAccountSummary>;
    /** List active push subscriptions for the authenticated user. Requires user JWT. */
    listUserPushSubscriptions(): Promise<UserPushSubscriptionListResult>;
    /** Register or refresh a push subscription for the authenticated user. Requires user JWT. */
    registerUserPushSubscription(input: UserPushSubscriptionInput): Promise<UserPushSubscriptionResult>;
    /** Revoke a push subscription for the authenticated user. Requires user JWT. */
    revokeUserPushSubscription(subscriptionId: string): Promise<UserPushSubscriptionResult>;
    /** Preview a global-wallet consent request for a tenant app. Requires user JWT. */
    getGlobalWalletConsentRequest(input: {
        appId: string;
        origin?: string;
        redirectUri?: string;
        scopes?: string[];
        walletIndex?: number;
    }): Promise<GlobalWalletConsentRequest>;
    /** Approve global-wallet access for a tenant app. Requires user JWT with recent MFA. */
    approveGlobalWalletConsent(input: {
        appId: string;
        origin?: string;
        redirectUri?: string;
        scopes?: string[];
        walletIndex?: number;
    }): Promise<GlobalWalletApproveResult>;
    /** List global-wallet app consents for the authenticated user. Requires user JWT. */
    listGlobalWalletConsents(): Promise<{
        consents: GlobalWalletConsent[];
    }>;
    /** Revoke a global-wallet app consent. Requires user JWT with recent MFA. */
    revokeGlobalWalletConsent(consentId: string): Promise<{
        consent: GlobalWalletConsent;
    }>;
    /** Call the global-wallet RPC bridge. Write methods require explicit server-side enablement. */
    confirmGlobalWalletAction(input: {
        appId: string;
        origin?: string;
        method: "personal_sign" | "eth_signTypedData_v4" | "eth_sendTransaction" | string;
        params?: unknown;
        walletIndex?: number;
    }): Promise<GlobalWalletActionConfirmation>;
    /** Scan a global-wallet transaction request before confirming/executing it. */
    scanGlobalWalletTransaction(input: {
        appId: string;
        origin?: string;
        method?: "eth_sendTransaction";
        params: unknown;
        walletIndex?: number;
    }): Promise<GlobalWalletTransactionScan>;
    /** Call the global-wallet RPC bridge. Write methods require a one-time action confirmation. */
    globalWalletRpc<T = unknown>(input: {
        appId: string;
        origin?: string;
        method: string;
        params?: unknown;
        confirmationId?: string;
        id?: unknown;
        jsonrpc?: string;
        walletIndex?: number;
    }): Promise<GlobalWalletRpcResult<T>>;
    /** Create a one-time message for linking an Ethereum wallet to the authenticated user. */
    createUserEthereumWalletLinkNonce(address?: string): Promise<UserEthereumWalletLinkNonce>;
    /** Link an Ethereum wallet to the authenticated user using the signed nonce message. */
    linkUserEthereumWallet(input: {
        address: string;
        message: string;
        signature: string;
    }): Promise<UserEthereumWalletLinkResult>;
    /** Create a one-time message for linking a Solana wallet to the authenticated user. */
    createUserSolanaWalletLinkNonce(publicKey?: string): Promise<UserSolanaWalletLinkNonce>;
    /** Link a Solana wallet to the authenticated user using the signed nonce message. */
    linkUserSolanaWallet(input: {
        publicKey: string;
        message: string;
        signature: string;
    }): Promise<UserSolanaWalletLinkResult>;
    /** Create a one-time state challenge for linking an OAuth account. */
    createUserOAuthAccountLinkChallenge(provider: string, input: {
        redirectUri: string;
        codeChallenge?: string;
        codeChallengeMethod?: string;
    }): Promise<UserOAuthAccountLinkChallenge>;
    /** Link an OAuth account to the authenticated user using an authorization code and state. */
    linkUserOAuthAccount(provider: string, input: {
        code: string;
        redirectUri: string;
        state: string;
        codeVerifier?: string;
    }): Promise<UserOAuthAccountLinkResult>;
    /** Send an OTP for linking a phone number to the authenticated user. */
    sendUserPhoneAccountLinkOtp(phone: string, channel?: "sms" | "whatsapp"): Promise<UserPhoneAccountLinkSendResult>;
    /** Verify an OTP and link a phone number to the authenticated user. */
    verifyUserPhoneAccountLinkOtp(input: {
        phone: string;
        code: string;
    }, channel?: "sms" | "whatsapp"): Promise<UserPhoneAccountLinkResult>;
    /** Link a Telegram Login Widget account to the authenticated user. */
    createUserTelegramAccountLinkChallenge(): Promise<UserSocialAccountLinkChallenge>;
    /** Link a Telegram Login Widget account to the authenticated user. */
    linkUserTelegramAccount(input: Record<string, unknown>): Promise<UserSocialAccountLinkResult>;
    /** Create a one-time nonce for linking a Farcaster account to the authenticated user. */
    createUserFarcasterAccountLinkNonce(): Promise<UserSocialAccountLinkChallenge>;
    /** Link a Farcaster SIWF account to the authenticated user. */
    linkUserFarcasterAccount(input: {
        message: string;
        signature: string;
        custodyAddress?: string;
        address?: string;
        fid?: string | number;
        username?: string;
        displayName?: string;
        pfpUrl?: string;
        pfp?: string;
    }): Promise<UserSocialAccountLinkResult>;
    /** Unlink a linked account from the authenticated user. Requires another login method. */
    unlinkUserAccount(provider: string, providerAccountId: string): Promise<UserAccountUnlinkResult>;
    /**
     * Export the private keys for a vault agent.
     * Requires tenant-level authentication.
     */
    exportAgentKey(agentId: string): Promise<ExportKeyResult>;
    /** Initialize a one-time encrypted private-key import session for a vault agent. */
    initializeEncryptedAgentKeyImport(agentId: string, chain: "evm" | "solana"): Promise<EncryptedAgentKeyImportInitResult>;
    /** Submit an encrypted private-key import envelope for a vault agent. */
    submitEncryptedAgentKeyImport(agentId: string, input: EncryptedAgentKeyImportSubmitInput): Promise<EncryptedAgentKeyImportResult>;
    /** Get the control-plane configuration for a tenant. */
    getTenantConfig(tenantId: string): Promise<TenantControlPlaneConfig>;
    /** Update the control-plane configuration for a tenant. */
    updateTenantConfig(tenantId: string, config: Partial<TenantControlPlaneConfig>): Promise<TenantControlPlaneConfig>;
    /** List tenant app origins used for CORS, passkeys, SIWE/SIWS, and OAuth redirects. */
    listAppOrigins(tenantId: string): Promise<string[]>;
    /** Add one or more tenant app origins. Requires tenant-admin MFA server-side. */
    addAppOrigin(tenantId: string, origin: string): Promise<string[]>;
    /** Add one or more tenant app origins. Requires tenant-admin MFA server-side. */
    addAppOrigins(tenantId: string, origins: string[]): Promise<string[]>;
    /** Remove one tenant app origin. Requires tenant-admin MFA server-side. */
    removeAppOrigin(tenantId: string, origin: string): Promise<string[]>;
    /** Remove one or more tenant app origins. Requires tenant-admin MFA server-side. */
    removeAppOrigins(tenantId: string, origins: string[]): Promise<string[]>;
    /** List tenant redirect URLs used for OAuth and email auth callbacks. */
    listRedirectUrls(tenantId: string): Promise<string[]>;
    /** Add one tenant redirect URL. Requires tenant-admin MFA server-side. */
    addRedirectUrl(tenantId: string, url: string): Promise<string[]>;
    /** Add one or more tenant redirect URLs. Requires tenant-admin MFA server-side. */
    addRedirectUrls(tenantId: string, urls: string[]): Promise<string[]>;
    /** Remove one tenant redirect URL. Requires tenant-admin MFA server-side. */
    removeRedirectUrl(tenantId: string, url: string): Promise<string[]>;
    /** Remove one or more tenant redirect URLs. Requires tenant-admin MFA server-side. */
    removeRedirectUrls(tenantId: string, urls: string[]): Promise<string[]>;
    /** List tenant app clients/environments. Requires tenant-admin MFA server-side. */
    listTenantAppClients(tenantId: string): Promise<TenantAppClient[]>;
    /** Replace the tenant app client/environment registry. Requires tenant-admin MFA server-side. */
    replaceTenantAppClients(tenantId: string, clients: TenantAppClient[]): Promise<TenantAppClient[]>;
    /** Create one tenant app client/environment. Requires tenant-admin MFA server-side. */
    createTenantAppClient(tenantId: string, client: TenantAppClient): Promise<TenantAppClient>;
    /** Delete one tenant app client/environment. Requires tenant-admin MFA server-side. */
    deleteTenantAppClient(tenantId: string, clientId: string): Promise<TenantAppClient[]>;
    /** List app-client secret metadata. Raw secrets are never returned by this endpoint. */
    listTenantAppClientSecrets(tenantId: string, clientId: string): Promise<{
        appId: string;
        secrets: TenantAppClientSecret[];
    }>;
    /** Rotate an app-client secret. Returns the raw appSecret once. */
    rotateTenantAppClientSecret(tenantId: string, clientId: string): Promise<TenantAppClientSecretCreateResult>;
    /** Revoke one app-client secret immediately. */
    revokeTenantAppClientSecret(tenantId: string, clientId: string, secretId: string): Promise<TenantAppClientSecret>;
    /** List tenant app access allowlist entries for email, domain, wallet, and phone login. */
    listAccessAllowlistEntries(tenantId: string): Promise<TenantAccessAllowlistEntry[]>;
    /** Add one tenant app access allowlist entry. Requires tenant-admin MFA server-side. */
    addAccessAllowlistEntry(tenantId: string, entry: TenantAccessAllowlistEntryInput): Promise<TenantAccessAllowlistEntry[]>;
    /** Add one or more tenant app access allowlist entries. Requires tenant-admin MFA server-side. */
    addAccessAllowlistEntries(tenantId: string, entries: TenantAccessAllowlistEntryInput[]): Promise<TenantAccessAllowlistEntry[]>;
    /** Remove one tenant app access allowlist entry. Requires tenant-admin MFA server-side. */
    removeAccessAllowlistEntry(tenantId: string, entry: TenantAccessAllowlistEntryInput | {
        id: string;
    }): Promise<TenantAccessAllowlistEntry[]>;
    /** Remove tenant app access allowlist entries by id or by type/value pair. */
    removeAccessAllowlistEntries(tenantId: string, input: {
        ids?: string[];
        entries?: TenantAccessAllowlistEntryInput[];
    }): Promise<TenantAccessAllowlistEntry[]>;
    /** Get tenant-scoped OIDC/JWT login provider configuration. */
    getTenantOidcProviders(tenantId: string): Promise<TenantOidcProviderConfig[]>;
    /** Discover whether an email domain should route to tenant SSO. */
    discoverSso(email: string): Promise<SsoDiscoveryResult>;
    /** List tenant verified/draft SSO email domains. Requires tenant-admin MFA server-side. */
    listTenantSsoDomains(tenantId: string): Promise<TenantSsoDomain[]>;
    /** Create or reset a tenant SSO email-domain verification token. */
    createTenantSsoDomain(tenantId: string, input: {
        domain: string;
        ssoRequired?: boolean;
    }): Promise<TenantSsoDomain>;
    /** Mark a tenant SSO domain verified after out-of-band DNS/manual verification. */
    verifyTenantSsoDomain(tenantId: string, domain: string): Promise<TenantSsoDomain>;
    /** Delete a tenant SSO domain. */
    deleteTenantSsoDomain(tenantId: string, domain: string): Promise<void>;
    /** Get tenant SAML dashboard/team SSO config and generated SP URLs. */
    getTenantSamlSso(tenantId: string): Promise<{
        config: TenantSamlSsoConfig | null;
        serviceProvider: {
            spEntityId: string;
            acsUrl: string;
            metadataUrl: string;
        };
    }>;
    /** Replace tenant SAML dashboard/team SSO config. Requires tenant-admin MFA server-side. */
    updateTenantSamlSso(tenantId: string, input: TenantSamlSsoUpdate): Promise<TenantSamlSsoConfig>;
    /** Delete tenant SAML dashboard/team SSO config. */
    deleteTenantSamlSso(tenantId: string): Promise<void>;
    /** Replace tenant-scoped OIDC/JWT login provider configuration. */
    updateTenantOidcProviders(tenantId: string, providers: TenantOidcProviderConfig[]): Promise<TenantOidcProviderConfig[]>;
    /** Get tenant-scoped auth abuse and login method controls. */
    getTenantAuthAbuseConfig(tenantId: string): Promise<TenantAuthAbuseConfig>;
    /** Replace tenant-scoped auth abuse and login method controls. */
    updateTenantAuthAbuseConfig(tenantId: string, authAbuseConfig: TenantAuthAbuseConfig): Promise<TenantAuthAbuseConfig>;
    /** Get tenant gas sponsorship/paymaster configuration. */
    getTenantGasSponsorshipConfig(tenantId: string): Promise<TenantGasSponsorshipConfig>;
    /** Replace tenant gas sponsorship/paymaster configuration. Requires tenant-admin MFA server-side. */
    updateTenantGasSponsorshipConfig(tenantId: string, gasSponsorshipConfig: TenantGasSponsorshipConfig): Promise<TenantGasSponsorshipConfig>;
    /** Get the production security checklist for a tenant deployment. Requires tenant-admin MFA server-side. */
    getTenantSecurityChecklist(tenantId: string): Promise<TenantSecurityChecklist>;
    /** Get privacy-preserving idempotency counters for a tenant. Requires tenant-admin MFA server-side. */
    getTenantIdempotencyMetrics(tenantId: string): Promise<TenantIdempotencyMetrics>;
    /** List tenant request-signing key metadata. Requires tenant-admin MFA server-side. */
    listTenantRequestSigningKeys(tenantId: string): Promise<TenantRequestSigningKey[]>;
    /** Rotate tenant request-signing keys and reveal the new secret once. */
    rotateTenantRequestSigningKey(tenantId: string, input?: {
        name?: string;
    }): Promise<TenantRequestSigningKeyCreateResult>;
    /** Revoke a tenant request-signing key. Requires tenant-admin MFA server-side. */
    revokeTenantRequestSigningKey(tenantId: string, keyId: string): Promise<TenantRequestSigningKey>;
    /** Lists the caller-requested agent approval page using the current session authority. */
    listPendingApprovals(agentId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<Array<{
        queueId: string;
        status: string;
        requestedAt: string;
        transaction: TxRecord;
    }>>;
    /** Get the aggregated dashboard for an agent (balance, spend, policies, recent tx, pending approvals). */
    getAgentDashboard(agentId: string): Promise<AgentDashboardResponse>;
    /** Get on-chain and realtime spend accounting for an agent. */
    getAgentSpend(agentId: string): Promise<AgentSpendSummary>;
    /** Get the aggregated digital asset account for an agent. */
    getAgentAccount(agentId: string, opts?: {
        chainId?: number;
        tokens?: string[];
    }): Promise<AgentAccountSummary>;
    /** Privy-style alias for an agent's aggregated digital asset account. */
    getAgentAccountAggregation(agentId: string, opts?: {
        chainId?: number;
        tokens?: string[];
    }): Promise<AgentAccountSummary>;
    listAgentSigners(agentId: string, opts?: {
        status?: AgentSignerStatus;
    }): Promise<AgentSigner[]>;
    createAgentSigner(agentId: string, input: AgentSignerCreate): Promise<AgentSignerCreateResult>;
    /** Privy-style alias for agent signer authorization-key inventory. */
    listAuthorizationKeys(agentId: string, opts?: {
        status?: AgentSignerStatus;
    }): Promise<AuthorizationKey[]>;
    /** Privy-style alias for registering an agent signer authorization key. */
    createAuthorizationKey(agentId: string, input: AuthorizationKeyCreate): Promise<AuthorizationKeyCreateResult>;
    updateAgentSigner(agentId: string, signerId: string, input: AgentSignerUpdate): Promise<AgentSigner>;
    /** Privy-style alias for updating an agent signer authorization key. */
    updateAuthorizationKey(agentId: string, keyId: string, input: AuthorizationKeyUpdate): Promise<AuthorizationKey>;
    revokeAgentSigner(agentId: string, signerId: string): Promise<AgentSigner>;
    /** Privy-style alias for revoking an agent signer authorization key. */
    revokeAuthorizationKey(agentId: string, keyId: string): Promise<AuthorizationKey>;
    listAgentKeyQuorums(agentId: string, opts?: {
        status?: AgentKeyQuorumStatus;
    }): Promise<AgentKeyQuorum[]>;
    createAgentKeyQuorum(agentId: string, input: AgentKeyQuorumCreate): Promise<AgentKeyQuorum>;
    updateAgentKeyQuorum(agentId: string, quorumId: string, input: AgentKeyQuorumUpdate): Promise<AgentKeyQuorum>;
    revokeAgentKeyQuorum(agentId: string, quorumId: string): Promise<AgentKeyQuorum>;
    /**
     * Execute an approved vault transaction through the policy-revalidating
     * vault route. The generic approval endpoint deliberately cannot sign or
     * broadcast vault transactions.
     */
    approveVaultTransaction(agentId: string, txId: string): Promise<VaultApprovalResult>;
    /** List approval queue entries for the tenant. */
    listApprovals(opts?: {
        status?: string;
        agentId?: string;
        limit?: number;
        offset?: number;
        cursorRequestedAt?: string;
        cursorId?: string;
    }): Promise<ApprovalQueueEntry[]>;
    /** Approve a pending transaction. */
    approveTransaction(txId: string, opts?: {
        comment?: string;
        approvedBy?: string;
    }): Promise<ApprovalQueueEntry>;
    /** Deny a pending transaction. */
    denyTransaction(txId: string, reason: string, deniedBy?: string): Promise<ApprovalQueueEntry>;
    /** Poll one held proxy request through the control-plane API. */
    getPendingProxyRequest(id: string): Promise<PendingProxyRequest>;
    /** List approval-gated proxy requests for an operator. */
    listPendingProxyRequests(status?: PendingProxyRequestStatus): Promise<PendingProxyRequest[]>;
    /** Approve a held proxy request. It executes exactly once when the agent polls the proxy. */
    approveProxyRequest(id: string): Promise<{
        id: string;
        status: PendingProxyRequestStatus;
    }>;
    /** Deny a held proxy request without forwarding it. */
    denyProxyRequest(id: string, reason?: string): Promise<{
        id: string;
        status: PendingProxyRequestStatus;
    }>;
    /** Get approval statistics for the tenant. */
    getApprovalStats(): Promise<ApprovalStats>;
    /** Get auto-approval rules for the tenant. */
    getAutoApprovalRules(): Promise<AutoApprovalRule | null>;
    /** Create or update auto-approval rules. */
    updateAutoApprovalRules(rules: Partial<AutoApprovalRule>): Promise<AutoApprovalRule>;
    /** List the tenants the authenticated user is a member of. Requires user JWT. */
    listUserTenants(): Promise<TenantMembership[]>;
    /** Search users in a tenant directory. Requires user JWT, tenant admin role, and recent MFA. */
    listTenantUsers(tenantId: string, opts?: {
        q?: string;
        email?: string;
        walletExternalId?: string;
        limit?: number;
        offset?: number;
    }): Promise<TenantAdminUserSearchResult>;
    /** Report existing tenant users that violate the one third-party wallet policy. Requires user JWT, tenant admin role, and recent MFA. */
    getTenantWalletPolicyViolations(tenantId: string, opts?: {
        limit?: number;
        offset?: number;
    }): Promise<TenantWalletPolicyViolationReport>;
    /** Remove one linked third-party wallet from a tenant member as audited one-wallet-policy remediation. Requires user JWT, tenant admin role, and recent MFA. */
    remediateTenantWalletPolicyViolation(tenantId: string, userId: string, accountId: string): Promise<TenantWalletPolicyRemediationResult>;
    /** Bulk-remediate selected linked third-party wallets from tenant members. Requires user JWT, tenant admin role, and recent MFA. */
    bulkRemediateTenantWalletPolicyViolations(tenantId: string, wallets: TenantWalletPolicyBulkRemediationItem[]): Promise<TenantWalletPolicyBulkRemediationResponse>;
    /** Export the tenant-scoped user directory as CSV. Requires user JWT, tenant admin role, and recent MFA. */
    exportTenantUsersCsv(tenantId: string, opts?: {
        q?: string;
        email?: string;
        limit?: number;
    }): Promise<string>;
    /** Read a tenant-scoped user record. Requires user JWT, tenant admin role, and recent MFA. */
    getTenantUser(tenantId: string, userId: string): Promise<TenantAdminUser>;
    /** List tenant-scoped activity for a user. Requires user JWT, tenant admin role, and recent MFA. */
    listTenantUserEvents(tenantId: string, userId: string, opts?: {
        limit?: number;
        offset?: number;
    }): Promise<TenantAdminUserEventsResult>;
    /** Update a tenant user's team role. Requires user JWT, tenant admin role, and recent MFA. */
    updateTenantUserRole(tenantId: string, userId: string, role: TenantTeamRole): Promise<TenantAdminUser>;
    /** Replace tenant-scoped custom metadata. Requires user JWT, tenant admin role, and recent MFA. */
    updateTenantUserMetadata(tenantId: string, userId: string, tenantCustomMetadata: Record<string, unknown>): Promise<TenantAdminUser>;
    /** Deactivate or reactivate an app-scoped tenant user. Requires user JWT, admin role, and MFA. */
    setTenantUserDeactivated(tenantId: string, userId: string, deactivated?: boolean): Promise<TenantAdminUser>;
    /** Remove a user from the current tenant. Requires user JWT, tenant admin role, and recent MFA. */
    removeTenantUser(tenantId: string, userId: string): Promise<void>;
    /**
     * Create multiple agent wallets in a single request.
     * Optionally supply a shared policy set to apply to every created agent.
     */
    createWalletBatch(agents: BatchAgentSpec[], policies?: PolicyRule[]): Promise<BatchCreateResult>;
    /**
     * Privy-style alias for homogeneous server-wallet batch creation.
     * `externalId` maps to the immutable per-tenant wallet `platformId`.
     */
    createWalletsBatch(wallets: WalletBatchSpec[], policies?: PolicyRule[]): Promise<WalletBatchCreateResult>;
    /**
     * Pre-generate encrypted wallets that can later be claimed by end users.
     * Claim tokens are returned once; the login service stores only token hashes.
     */
    createPregeneratedUserWallets(input: {
        count?: number;
        namePrefix?: string;
        policies?: PolicyRule[];
        claimExpiresInSeconds?: number;
    }): Promise<PregeneratedUserWalletCreateResult>;
    private request;
    private buildHeaders;
    private buildRequestHeaders;
    private fetchJson;
    private isPendingApproval;
    private isBroadcastOutcomeUnknown;
}
//# sourceMappingURL=client.d.ts.map