/** A foreground signal requests a canonical read; it never proves an OAuth grant. */
export type AccountReturnBinding = Readonly<{
    client?: object;
    environment: string;
    userId: string;
    organizationId: string;
    sessionId: string;
    credentialId: string;
}>;
export declare function sameAccountReturnBinding(a: AccountReturnBinding | null, b: AccountReturnBinding | null): boolean;
type Listener = {
    remove(): Promise<void> | void;
};
export declare function watchForegroundAccountReturn(options: {
    binding: AccountReturnBinding;
    current: () => AccountReturnBinding | null;
    foreground: () => boolean;
    refresh: () => void;
    onVisibilityChange: (listener: () => void) => () => void;
    onFocus: (listener: () => void) => () => void;
    onNativeResume?: (listener: () => void) => Promise<Listener>;
}): {
    ready: Promise<void>;
    isCurrent: () => boolean;
    arm(): () => void;
    close(): void;
};
export interface WorkspaceAppReturnPort {
    prepare(binding: AccountReturnBinding): Promise<{
        supported: boolean;
        redirectUrl?: string;
        state?: string;
    }>;
    consume(binding: AccountReturnBinding): Promise<{
        result: "none" | "connected" | "denied" | "failed";
        connectionId?: string;
    }>;
    cancel(state: string): Promise<void>;
    subscribe(listener: () => void): Promise<{
        remove(): void | Promise<void>;
    }>;
}
/** Product configuration for the registered Workspace AppReturn v2 callback. */
export interface WorkspaceAppReturnConfig {
    readonly callbackUrl: string;
    readonly pluginName: string;
    readonly methods: readonly string[];
}
/** Callback and bridge identifiers are host inputs. No credential or provider grant is accepted here. */
export declare function createWorkspaceAppReturn(input: WorkspaceAppReturnConfig): Readonly<{
    redirectAllowed: (value: string) => boolean;
    prepare: (port: WorkspaceAppReturnPort | undefined, binding: AccountReturnBinding, current: () => AccountReturnBinding | null) => Promise<{
        redirectUrl: string;
        state: string;
    } | undefined>;
    available: (headers: unknown) => boolean;
    watch: (port: WorkspaceAppReturnPort, binding: AccountReturnBinding, current: () => AccountReturnBinding | null, onReturn: (result: {
        result: "connected" | "denied" | "failed";
        connectionId?: string;
    }) => void, onError: () => void) => {
        ready: Promise<void>;
        close(): void;
    };
}>;
export {};
//# sourceMappingURL=app-return.d.ts.map