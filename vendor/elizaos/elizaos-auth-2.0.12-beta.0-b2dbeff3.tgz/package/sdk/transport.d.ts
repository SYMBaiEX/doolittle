export declare class LoginApiError<TData = unknown> extends Error {
    readonly status: number;
    readonly data?: TData;
    readonly mfaRequired: boolean;
    constructor(message: string, status: number, data?: TData);
}
export declare const DEFAULT_REQUEST_TIMEOUT_MS = 30000;
export declare const MAX_REQUEST_TIMEOUT_MS: number;
export declare const DEFAULT_MAX_RESPONSE_BODY_BYTES: number;
export declare const MAX_RESPONSE_BODY_BYTES: number;
export declare function boundedPositiveInteger(name: string, value: number | undefined, fallback: number, maximum: number): number;
export interface LoginTransportOptions {
    requestTimeoutMs?: number;
    maxResponseBodyBytes?: number;
}
/**
 * Login requests never follow a redirect. They ask for `"manual"` because the
 * Cloudflare Workers runtime rejects `redirect: "error"` outright, and this
 * turns any redirect response (a real 3xx, or a browser `opaqueredirect`) into
 * the same rejected request `"error"` produced.
 */
export declare function refuseLoginRedirect(response: Response): Promise<Response>;
export declare function fetchLoginText(url: string, init?: RequestInit, options?: LoginTransportOptions, prepareHeaders?: () => Promise<Headers>): Promise<{
    response: Response;
    text: string;
}>;
export declare function fetchLoginJson<T>(url: string, init?: RequestInit, options?: LoginTransportOptions, prepareHeaders?: () => Promise<Headers>): Promise<{
    response: Response;
    payload: T;
}>;
//# sourceMappingURL=transport.d.ts.map