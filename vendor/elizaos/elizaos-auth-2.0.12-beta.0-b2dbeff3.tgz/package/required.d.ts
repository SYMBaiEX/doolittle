export declare function requireLoginValue<T>(value: T | null | undefined, field: string): T;
//# sourceMappingURL=required.d.ts.map