/**
 * Local desktop KMS adapter that derives persistent symmetric keys from a caller-provided root key.
 */
import { createHmac, createPrivateKey, createPublicKey, sign as nodeSign, verify as nodeVerify, randomBytes, scryptSync, timingSafeEqual, } from "node:crypto";
import { aeadDecrypt, aeadEncrypt } from "./crypto/aead.js";
import { hkdfSha256 } from "./crypto/hkdf.js";
import { parseKeyId, withVersion } from "./key-namespace.js";
import { KeyNotFoundError, KmsError, } from "./types.js";
const HKDF_DOMAIN = "elizaos.security.local-kms.v1";
export class LocalKmsAdapter {
    rootKey;
    constructor(opts) {
        if (opts.rootKey.length !== 32) {
            throw new KmsError("LocalKmsAdapter rootKey must be 32 bytes");
        }
        this.rootKey = opts.rootKey;
    }
    static fromPassphrase(passphrase, salt) {
        const rootKey = new Uint8Array(scryptSync(passphrase, salt, 32));
        return new LocalKmsAdapter({ rootKey });
    }
    deriveSym(keyId, version) {
        const info = Buffer.from(`${HKDF_DOMAIN}|sym|${keyId}|v${version}`, "utf8");
        return hkdfSha256(this.rootKey, 32, info);
    }
    deriveEd25519PrivateKey(keyId, version) {
        const info = Buffer.from(`${HKDF_DOMAIN}|sign|ed25519|${keyId}|v${version}`, "utf8");
        const seed = Buffer.from(hkdfSha256(this.rootKey, 32, info));
        const pkcs8 = Buffer.concat([
            Buffer.from("302e020100300506032b657004220420", "hex"),
            seed,
        ]);
        return createPrivateKey({ key: pkcs8, format: "der", type: "pkcs8" });
    }
    version(keyId) {
        return parseKeyId(keyId).version;
    }
    async getOrCreateKey(keyId, _opts = {}) {
        return { keyId, version: this.version(keyId) };
    }
    async rotateKey(keyId) {
        const newVersion = this.version(keyId) + 1;
        const rotatedKeyId = withVersion(keyId, newVersion);
        return { keyId: rotatedKeyId, newVersion };
    }
    async listKeyVersions(keyId) {
        return [this.version(keyId)];
    }
    async encrypt(keyId, plaintext, aad) {
        const version = this.version(keyId);
        const k = this.deriveSym(keyId, version);
        const out = aeadEncrypt(k, plaintext, aad);
        return { ...out, keyId, keyVersion: version };
    }
    async decrypt(keyId, ciphertext, nonce, authTag, aad, keyVersion) {
        const currentVersion = this.version(keyId);
        const version = keyVersion ?? currentVersion;
        if (version !== currentVersion) {
            throw new KeyNotFoundError(keyId, version);
        }
        const k = this.deriveSym(keyId, version);
        return aeadDecrypt(k, ciphertext, nonce, authTag, aad);
    }
    async hmac(keyId, data) {
        const version = this.version(keyId);
        const info = Buffer.from(`${HKDF_DOMAIN}|hmac|${keyId}|v${version}`, "utf8");
        const macKey = hkdfSha256(this.rootKey, 32, info);
        const mac = createHmac("sha256", Buffer.from(macKey))
            .update(Buffer.from(data))
            .digest();
        return new Uint8Array(mac);
    }
    async hmacVerify(keyId, data, tag) {
        const version = this.version(keyId);
        const info = Buffer.from(`${HKDF_DOMAIN}|hmac|${keyId}|v${version}`, "utf8");
        const macKey = hkdfSha256(this.rootKey, 32, info);
        const expected = createHmac("sha256", Buffer.from(macKey))
            .update(Buffer.from(data))
            .digest();
        return (expected.length === tag.length &&
            timingSafeEqual(expected, Buffer.from(tag)));
    }
    async sign(keyId, data, algo = "ed25519") {
        if (algo === "ed25519") {
            const version = this.version(keyId);
            const privateKey = this.deriveEd25519PrivateKey(keyId, version);
            const signature = nodeSign(null, Buffer.from(data), privateKey);
            return {
                signature: new Uint8Array(signature),
                algorithm: algo,
                keyId,
                keyVersion: version,
            };
        }
        throw new KmsError(`LocalKmsAdapter does not support persistent ${algo} signing; use ed25519 or Steward KMS`);
    }
    async verify(keyId, data, signature, algo = "ed25519") {
        if (algo === "ed25519") {
            const version = this.version(keyId);
            const privateKey = this.deriveEd25519PrivateKey(keyId, version);
            const publicKey = createPublicKey(privateKey);
            return nodeVerify(null, Buffer.from(data), publicKey, Buffer.from(signature));
        }
        throw new KmsError(`LocalKmsAdapter does not support persistent ${algo} verification; use ed25519 or Steward KMS`);
    }
    async getPublicKey(keyId) {
        const version = this.version(keyId);
        const privateKey = this.deriveEd25519PrivateKey(keyId, version);
        const publicKey = createPublicKey(privateKey);
        return new Uint8Array(publicKey.export({ format: "der", type: "spki" }));
    }
}
export function randomRootKey() {
    return new Uint8Array(randomBytes(32));
}
//# sourceMappingURL=local-adapter.js.map