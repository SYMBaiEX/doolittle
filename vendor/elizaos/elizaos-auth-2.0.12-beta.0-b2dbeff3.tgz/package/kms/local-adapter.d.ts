/**
 * Local desktop KMS adapter that derives persistent symmetric keys from a caller-provided root key.
 */
import { type EncryptResult, type GetOrCreateKeyOptions, type KeyHandle, type KeyId, type KeyVersion, type KmsClient, type SignatureAlgorithm, type SignResult } from "./types.js";
/**
 * Single-user desktop adapter.
 *
 * Wraps `@elizaos/auth/vault`'s master-key resolution (OS keychain → scrypt passphrase)
 * to obtain a 32-byte root key, then derives per-`keyId` / per-version subkeys
 * via HKDF-SHA256. Signing keys are held in-process (regenerated on boot from
 * the same root via deterministic HKDF + ed25519 seed expansion).
 *
 * The version embedded in `keyId` is authoritative, so rotation returns a new
 * versioned key id that callers persist with ciphertext. No process-local
 * active-version state can roll back after restart.
 *
 * Symmetric and Ed25519 keys are deterministically derived so the same desktop
 * install can decrypt and verify its own data after restart. RSA is rejected
 * because a process-local fallback would produce unverifiable signatures after
 * restart.
 */
export interface LocalKmsOptions {
    /** 32-byte root key. Caller resolves via `@elizaos/auth/vault` master-key API. */
    rootKey: Uint8Array;
}
export declare class LocalKmsAdapter implements KmsClient {
    private readonly rootKey;
    constructor(opts: LocalKmsOptions);
    static fromPassphrase(passphrase: string, salt: string): LocalKmsAdapter;
    private deriveSym;
    private deriveEd25519PrivateKey;
    private version;
    getOrCreateKey(keyId: KeyId, _opts?: GetOrCreateKeyOptions): Promise<KeyHandle>;
    rotateKey(keyId: KeyId): Promise<{
        keyId: KeyId;
        newVersion: KeyVersion;
    }>;
    listKeyVersions(keyId: KeyId): Promise<KeyVersion[]>;
    encrypt(keyId: KeyId, plaintext: Uint8Array, aad?: Uint8Array): Promise<EncryptResult>;
    decrypt(keyId: KeyId, ciphertext: Uint8Array, nonce: Uint8Array, authTag: Uint8Array, aad?: Uint8Array, keyVersion?: KeyVersion): Promise<Uint8Array>;
    hmac(keyId: KeyId, data: Uint8Array): Promise<Uint8Array>;
    hmacVerify(keyId: KeyId, data: Uint8Array, tag: Uint8Array): Promise<boolean>;
    sign(keyId: KeyId, data: Uint8Array, algo?: SignatureAlgorithm): Promise<SignResult>;
    verify(keyId: KeyId, data: Uint8Array, signature: Uint8Array, algo?: SignatureAlgorithm): Promise<boolean>;
    getPublicKey(keyId: KeyId): Promise<Uint8Array>;
}
export declare function randomRootKey(): Uint8Array;
//# sourceMappingURL=local-adapter.d.ts.map