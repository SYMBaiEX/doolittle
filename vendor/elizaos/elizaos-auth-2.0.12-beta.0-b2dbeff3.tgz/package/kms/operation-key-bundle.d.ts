/**
 * Wraps one random 64-byte operation key bundle with an existing KMS client's
 * AEAD encrypt/decrypt methods. The first half is an AES-256 DEK and the second
 * half is an operation-scoped HMAC key. A fresh envelope is decrypted and
 * compared immediately before callers can persist or use it; deterministic
 * receipts are computed locally and require no additional KMS server API.
 */
import { ElizaError } from "@elizaos/core";
import type { KmsClient } from "./types.js";
export declare const KMS_AEAD_OPERATION_KEY_BUNDLE_V1: Readonly<{
    format: "kms-aead-operation-key-bundle-v1";
    plaintextBytes: 64;
    wrappedBytes: 92;
    dek: Readonly<{
        offsetBytes: 0;
        bytes: 32;
    }>;
    contentHmac: Readonly<{
        offsetBytes: 32;
        bytes: 32;
    }>;
    nonceBytes: 12;
    authTagBytes: 16;
}>;
export declare const KMS_AEAD_OPERATION_KEY_BUNDLE_LOCAL_RECEIPT_DERIVATION: "elizaos.kms-aead-operation-key-bundle.local-receipt.v1";
export interface KmsAeadOperationKeyBundleWrapped {
    format: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_V1.format;
    keyId: string;
    keyVersion: number;
    plaintextBytes: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_V1.plaintextBytes;
    nonceBytes: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_V1.nonceBytes;
    authTagBytes: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_V1.authTagBytes;
    bytes: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_V1.wrappedBytes;
    sha256: string;
    localReceiptDerivation: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_LOCAL_RECEIPT_DERIVATION;
    localReceiptDigest: string;
    /** Exact nonce || ciphertext || authentication-tag envelope. */
    wrappedKeyBundle: Uint8Array;
}
export interface KmsAeadOperationKeyBundleHandle {
    readonly format: typeof KMS_AEAD_OPERATION_KEY_BUNDLE_V1.format;
    readonly dek: Uint8Array;
    readonly contentHmacKey: Uint8Array;
    readonly released: boolean;
}
export interface AcquireKmsAeadOperationKeyBundleInput {
    keyId: string;
    keyVersion: number;
    canonicalContext: Uint8Array;
}
export interface UnwrapKmsAeadOperationKeyBundleInput {
    wrapped: Readonly<KmsAeadOperationKeyBundleWrapped>;
    canonicalContext: Uint8Array;
}
export declare class KmsAeadOperationKeyBundleError extends ElizaError {
    readonly name = "KmsAeadOperationKeyBundleError";
    constructor(code: string, message: string, options?: {
        cause?: unknown;
    });
}
/** Recompute the provider-independent receipt for an exact envelope/context. */
export declare function computeKmsAeadOperationKeyBundleLocalReceiptDigest(input: {
    keyId: string;
    keyVersion: number;
    canonicalContext: Uint8Array;
    wrappedKeyBundle: Uint8Array;
}): string;
/** Unified acquire/unwrap/release provider over any conforming KMS client. */
export declare class KmsAeadOperationKeyBundleProvider {
    private readonly kms;
    private readonly ownedHandles;
    constructor(kms: Pick<KmsClient, "encrypt" | "decrypt">);
    private own;
    private decryptAndVerify;
    acquire(input: Readonly<AcquireKmsAeadOperationKeyBundleInput>): Promise<{
        handle: KmsAeadOperationKeyBundleHandle;
        wrapped: KmsAeadOperationKeyBundleWrapped;
    }>;
    unwrap(input: Readonly<UnwrapKmsAeadOperationKeyBundleInput>): Promise<KmsAeadOperationKeyBundleHandle>;
    release(handle: KmsAeadOperationKeyBundleHandle): true;
}
//# sourceMappingURL=operation-key-bundle.d.ts.map