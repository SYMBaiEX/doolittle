/**
 * Verifies direct-provider credentials with bounded diagnostics and catalogs.
 * OpenRouter authentication uses its current-key endpoint because the public
 * model catalog does not prove credential ownership; new account providers
 * never reflect their untrusted failure bodies across the enrollment boundary.
 */
import type { DirectAccountProvider } from "../auth/types.js";
/** Provider base URL for a direct-API key, honoring the *_BASE_URL overrides. */
export declare function directProviderBaseUrl(providerId: DirectAccountProvider): string;
export interface DirectApiProbeResult {
    ok: boolean;
    status: number;
    error?: string;
    latencyMs: number;
    /**
     * Complete OpenRouter/xAI model catalog within the response-size safety
     * bound. Other direct providers never read a successful body.
     */
    modelIds?: string[];
    /** True when the catalog response exceeded the byte safety bound. */
    modelCatalogTruncated?: boolean;
    /**
     * True when the key authenticated but the optional catalog could not be
     * fetched (non-2xx status or transport failure). Distinct from an empty
     * catalog so callers can show "catalog unavailable" rather than "no models".
     */
    modelCatalogUnavailable?: boolean;
}
/**
 * Verify a direct-API key against a provider-owned authenticated endpoint.
 * OpenRouter uses `/key` and only then reads its authenticated `/models` catalog;
 * xAI authenticates through `/models` and reads that bounded catalog; every
 * other provider authenticates through `/models` and never reads a 2xx body.
 */
export declare function probeDirectApiKey(providerId: DirectAccountProvider, apiKey: string): Promise<DirectApiProbeResult>;
//# sourceMappingURL=direct-api-probe.d.ts.map