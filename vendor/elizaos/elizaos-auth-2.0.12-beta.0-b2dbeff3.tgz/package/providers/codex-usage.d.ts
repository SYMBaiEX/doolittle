/**
 * Reads subscription usage for account probes and pool refresh without exposing credentials.
 * Subscription OAuth authenticates against the ChatGPT usage endpoint rather
 * than the API billing service. Absent windows are optional; malformed present
 * values must not become a successful snapshot with missing usage.
 */
/** Parsed rate-limit windows from a valid wham/usage payload. */
export interface CodexUsageSnapshot {
    /** Primary (5h session) window used percent, clamped to 0..100. */
    sessionPct?: number;
    /** Secondary (7-day) window used percent, clamped to 0..100. */
    weeklyPct?: number;
    /** Primary-window reset, epoch milliseconds. */
    resetsAt?: number;
    /** e.g. "plus" | "pro" — surfaced for display, never branched on. */
    planType?: string;
    /** Account email when the payload carries it. */
    email?: string;
}
/**
 * Probe the Codex usage endpoint with a subscription access token.
 *
 * Headers: `Authorization: Bearer` + `ChatGPT-Account-Id` + the codex-cli
 * User-Agent (the endpoint rejects unknown clients). Throws a typed
 * `ElizaError` on any transport, HTTP, JSON, or shape failure; returns the
 * validated windows on success.
 */
export declare function fetchCodexUsage(accessToken: string, accountId: string | undefined, fetchImpl?: typeof fetch): Promise<CodexUsageSnapshot>;
//# sourceMappingURL=codex-usage.d.ts.map