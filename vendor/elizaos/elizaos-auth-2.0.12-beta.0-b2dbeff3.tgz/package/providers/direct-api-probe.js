/** Provider base URL for a direct-API key, honoring the *_BASE_URL overrides. */
export function directProviderBaseUrl(providerId) {
    switch (providerId) {
        case "anthropic-api":
            return (process.env.ANTHROPIC_BASE_URL?.trim() || "https://api.anthropic.com/v1");
        case "openai-api":
            return process.env.OPENAI_BASE_URL?.trim() || "https://api.openai.com/v1";
        case "deepseek-api":
            return (process.env.DEEPSEEK_BASE_URL?.trim() || "https://api.deepseek.com");
        case "zai-api":
            return (process.env.ZAI_BASE_URL?.trim() ||
                process.env.Z_AI_BASE_URL?.trim() ||
                "https://api.z.ai/api/paas/v4");
        case "moonshot-api":
            return (process.env.MOONSHOT_BASE_URL?.trim() ||
                process.env.KIMI_BASE_URL?.trim() ||
                "https://api.moonshot.ai/v1");
        case "cerebras-api":
            return (process.env.CEREBRAS_BASE_URL?.trim() || "https://api.cerebras.ai/v1");
        case "openrouter-api":
            return (process.env.OPENROUTER_BASE_URL?.trim() ||
                "https://openrouter.ai/api/v1");
        case "xai-api":
            return process.env.XAI_BASE_URL?.trim() || "https://api.x.ai/v1";
    }
}
/** Providers whose successful probe also reads a bounded model catalog. */
const CATALOG_PROVIDERS = new Set([
    "openrouter-api",
    "xai-api",
]);
const MAX_MODEL_CATALOG_BYTES = 1_048_576;
const MAX_PROBE_FAILURE_BODY_BYTES = 64 * 1024;
async function readProbeFailureBody(response) {
    try {
        const declaredLength = Number(response.headers.get("content-length"));
        if (Number.isFinite(declaredLength) &&
            declaredLength > MAX_PROBE_FAILURE_BODY_BYTES) {
            return `[response body rejected: ${declaredLength} bytes exceeds the ${MAX_PROBE_FAILURE_BODY_BYTES}-byte probe diagnostic limit]`;
        }
        if (!response.body) {
            const body = await response.text();
            const bytes = new TextEncoder().encode(body);
            if (bytes.length <= MAX_PROBE_FAILURE_BODY_BYTES)
                return body;
            return `[response body rejected: ${bytes.length} bytes exceeds the ${MAX_PROBE_FAILURE_BODY_BYTES}-byte probe diagnostic limit]`;
        }
        const reader = response.body.getReader();
        const chunks = [];
        let byteLength = 0;
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            byteLength += value.byteLength;
            if (byteLength > MAX_PROBE_FAILURE_BODY_BYTES) {
                await reader.cancel();
                return `[response body rejected: more than ${MAX_PROBE_FAILURE_BODY_BYTES} bytes exceeds the probe diagnostic limit]`;
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(byteLength);
        let offset = 0;
        for (const chunk of chunks) {
            bytes.set(chunk, offset);
            offset += chunk.byteLength;
        }
        return new TextDecoder().decode(bytes);
    }
    catch (cause) {
        // error-policy:J4 explicit diagnostic degrade — the HTTP status remains the
        // authoritative failed probe; only the optional provider body is unavailable.
        return `[response body unavailable: ${cause instanceof Error ? cause.message : String(cause)}]`;
    }
}
async function readBoundedResponseText(response) {
    const reader = response.body?.getReader();
    if (!reader)
        return { text: "", truncated: false };
    const chunks = [];
    let total = 0;
    while (true) {
        const next = await reader.read();
        if (next.done)
            break;
        if (total + next.value.byteLength > MAX_MODEL_CATALOG_BYTES) {
            await reader.cancel();
            return { text: "", truncated: true };
        }
        chunks.push(next.value);
        total += next.value.byteLength;
    }
    const merged = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
        merged.set(chunk, offset);
        offset += chunk.byteLength;
    }
    return {
        text: new TextDecoder("utf-8", { fatal: true }).decode(merged),
        truncated: false,
    };
}
function parseBoundedModelIds(text) {
    let parsed;
    try {
        parsed = JSON.parse(text);
    }
    catch {
        // error-policy:J3 provider catalog JSON is untrusted. A malformed optional
        // catalog does not turn a successful authenticated probe into fake models.
        return { modelCatalogUnavailable: true };
    }
    if (!parsed || typeof parsed !== "object" || !("data" in parsed)) {
        return { modelCatalogUnavailable: true };
    }
    const data = parsed.data;
    if (!Array.isArray(data))
        return { modelCatalogUnavailable: true };
    const unique = new Set();
    for (const item of data) {
        if (!item || typeof item !== "object" || !("id" in item)) {
            return { modelCatalogUnavailable: true };
        }
        const id = item.id;
        if (typeof id !== "string")
            return { modelCatalogUnavailable: true };
        const normalized = id.trim();
        if (!normalized)
            return { modelCatalogUnavailable: true };
        unique.add(normalized);
    }
    return { modelIds: [...unique] };
}
async function readModelCatalog(response) {
    if (!response.ok)
        return { modelCatalogUnavailable: true };
    const catalogBody = await readBoundedResponseText(response);
    if (catalogBody.truncated) {
        return { modelCatalogTruncated: true, modelCatalogUnavailable: true };
    }
    return parseBoundedModelIds(catalogBody.text);
}
async function readAuthenticatedModelCatalog(response) {
    try {
        return await readModelCatalog(response);
    }
    catch {
        // error-policy:J4 user-facing degrade — authentication already succeeded;
        // a malformed, oversized, or unreadable catalog is unavailable metadata,
        // not a fabricated credential failure.
        return { modelCatalogUnavailable: true };
    }
}
async function fetchOpenRouterCatalog(baseUrl, apiKey, signal) {
    try {
        const response = await fetch(`${baseUrl}/models`, {
            method: "GET",
            signal,
            headers: { Authorization: `Bearer ${apiKey}` },
        });
        return await readModelCatalog(response);
    }
    catch {
        // error-policy:J4 user-facing degrade — the catalog is optional metadata
        // fetched after `/key` has already proven the credential. A transport
        // failure becomes the explicit `modelCatalogUnavailable` state that the
        // account test route and UI render, never an empty "no models" catalog.
        return { modelCatalogUnavailable: true };
    }
}
/**
 * Verify a direct-API key against a provider-owned authenticated endpoint.
 * OpenRouter uses `/key` and only then reads its authenticated `/models` catalog;
 * xAI authenticates through `/models` and reads that bounded catalog; every
 * other provider authenticates through `/models` and never reads a 2xx body.
 */
export async function probeDirectApiKey(providerId, apiKey) {
    const start = Date.now();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10_000);
    try {
        const baseUrl = directProviderBaseUrl(providerId).replace(/\/+$/, "");
        const response = providerId === "anthropic-api"
            ? await fetch(`${baseUrl}/models?limit=1`, {
                method: "GET",
                signal: controller.signal,
                headers: {
                    "anthropic-version": "2023-06-01",
                    "x-api-key": apiKey,
                },
            })
            : await fetch(`${baseUrl}/${providerId === "openrouter-api" ? "key" : "models"}`, {
                method: "GET",
                signal: controller.signal,
                headers: {
                    Authorization: `Bearer ${apiKey}`,
                },
            });
        if (!response.ok) {
            const preserveProviderDiagnostic = providerId !== "openrouter-api" && providerId !== "xai-api";
            const diagnostic = preserveProviderDiagnostic
                ? `: ${await readProbeFailureBody(response)}`
                : "";
            return {
                ok: false,
                status: response.status,
                // Provider bodies are untrusted and have historically included request
                // diagnostics. Never reflect one across the account API boundary where
                // it could echo credentials into UI state, logs, or evidence.
                error: preserveProviderDiagnostic
                    ? `${providerId} ${response.status}${diagnostic}`
                    : `${providerId} credential probe failed (HTTP ${response.status})`,
                latencyMs: Date.now() - start,
            };
        }
        // Only the catalog providers read a successful body; every other direct
        // provider keeps its historical status-only probe and never reads one.
        const catalog = providerId === "openrouter-api"
            ? await fetchOpenRouterCatalog(baseUrl, apiKey, controller.signal)
            : CATALOG_PROVIDERS.has(providerId)
                ? await readAuthenticatedModelCatalog(response)
                : {};
        return {
            ok: true,
            status: response.status,
            latencyMs: Date.now() - start,
            ...(catalog.modelIds ? { modelIds: catalog.modelIds } : {}),
            ...(catalog.modelCatalogTruncated ? { modelCatalogTruncated: true } : {}),
            ...(catalog.modelCatalogUnavailable
                ? { modelCatalogUnavailable: true }
                : {}),
        };
    }
    catch (err) {
        // error-policy:J1 boundary translation — callers need a typed failed probe
        // for transport/timeout failures, distinct from an authenticated HTTP status.
        return {
            ok: false,
            status: 0,
            error: err instanceof Error ? err.message : String(err),
            latencyMs: Date.now() - start,
        };
    }
    finally {
        clearTimeout(timer);
        // Header-only success and rejected diagnostic bodies must release their transport.
        controller.abort();
    }
}
//# sourceMappingURL=direct-api-probe.js.map