/**
 * Credential storage and token refresh for subscription providers.
 *
 * Credentials live under `<stateDir>/auth/{providerId}/{accountId}.json`
 * (see `account-storage.ts` for the on-disk format and atomic-write
 * details). The `loadCredentials` / `saveCredentials` /
 * `deleteCredentials` / `hasValidCredentials` / `getAccessToken`
 * helpers all default to `accountId="default"` so callers that pre-date
 * multi-account support keep working without changes.
 *
 * `saveCredentials` is the login commit path and may create a record. A token
 * refresh commits through `updateAccountCredentialsIfUnchanged` instead: the
 * grant is spent outside the storage lock, so the result is only persisted if
 * the account still exists and still holds the storage generation the refresh was
 * started from. Otherwise the result is discarded in favour of the current
 * stored state (a concurrent logout or re-login wins).
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { getElizaNamespace, logger, resolveStateDir, resolveUserPath, } from "@elizaos/core";
import { ElizaError } from "@elizaos/core/protocol";
import { resolveAliasedEnvValue } from "@elizaos/host/protocol";
import { carryForwardIdToken, commitAccountDeletions, deleteAccount, listAccounts, loadAccount, preflightProviderAccountDeletions, saveAccount, updateAccountCredentialsIfUnchanged, } from "./account-storage.js";
import { refreshAnthropicToken } from "./anthropic.js";
import { refreshCodexToken } from "./openai-codex.js";
import { accountRefreshMutex } from "./refresh-mutex.js";
import { ensureBuiltinSubscriptionAuthProviders } from "./subscription-auth/builtin-providers.js";
import { getSubscriptionAuthProvider } from "./subscription-auth/registry.js";
import { isCodingPlanKeySubscriptionProvider, isExternalCliSubscriptionProvider, isOAuthSubscriptionProvider, isSubscriptionProvider, isUnavailableSubscriptionProvider, SUBSCRIPTION_PROVIDER_IDS, SUBSCRIPTION_PROVIDER_METADATA, } from "./types.js";
const DEFAULT_ACCOUNT_ID = "default";
/** Buffer before expiry to trigger refresh (5 minutes) */
const REFRESH_BUFFER_MS = 5 * 60 * 1000;
function tokenFailure(kind, message, extra = {}) {
    return {
        ok: false,
        kind,
        message,
        ...(extra.expiresAt !== undefined ? { expiresAt: extra.expiresAt } : {}),
        ...(extra.minRemainingMs !== undefined
            ? { minRemainingMs: extra.minRemainingMs }
            : {}),
    };
}
function classifyRefreshError(err) {
    const message = err instanceof Error ? err.message : String(err);
    if (/\b(?:401|403|invalid[_ ]?grant|invalid[_ ]?token|unauthor|forbidden|re-?auth|revoked|(?:access |refresh |oauth |jwt |session |credential )?token (?:has |is )?expired|expired[_ ]?(?:access[_ ]?|refresh[_ ]?|oauth[_ ]?|jwt[_ ]?)?token|(?:credential|jwt|session) (?:has |is )?expired)\b/i.test(message)) {
        return "auth";
    }
    if (/\b(?:5\d\d|timeout|timed? ?out|fetch failed|network|ECONNRESET|ETIMEDOUT|EAI_AGAIN|socket hang up|service unavailable|bad gateway)\b/i.test(message)) {
        return "transient";
    }
    return "transient";
}
function recordToStored(record) {
    return {
        provider: record.providerId,
        credentials: record.credentials,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
    };
}
/**
 * Save credentials for a provider account.
 *
 * The `accountId` defaults to `"default"`. New accounts are persisted
 * with `source: "oauth"` and `label: "Default"` (or the existing
 * record's label when overwriting).
 */
export function saveCredentials(provider, credentials, accountId, storagePolicy) {
    const existing = loadAccount(provider, accountId, storagePolicy);
    const now = Date.now();
    const mergedCredentials = existing
        ? carryForwardIdToken(existing.credentials, credentials)
        : credentials;
    const record = {
        id: accountId,
        providerId: provider,
        label: existing?.label ??
            (accountId === DEFAULT_ACCOUNT_ID ? "Default" : accountId),
        source: existing?.source ?? "oauth",
        credentials: mergedCredentials,
        createdAt: existing?.createdAt ?? now,
        updatedAt: now,
        ...(existing?.lastUsedAt !== undefined
            ? { lastUsedAt: existing.lastUsedAt }
            : {}),
        ...(existing?.organizationId !== undefined
            ? { organizationId: existing.organizationId }
            : {}),
        ...(existing?.userId !== undefined ? { userId: existing.userId } : {}),
        ...(existing?.email !== undefined ? { email: existing.email } : {}),
    };
    return saveAccount(record, storagePolicy);
}
/**
 * Load stored credentials for a provider account.
 * Returns `null` when no account is configured for the given id.
 */
export function loadCredentials(provider, accountId = DEFAULT_ACCOUNT_ID, storagePolicy) {
    const record = loadAccount(provider, accountId, storagePolicy);
    if (!record)
        return null;
    return recordToStored(record);
}
/**
 * Delete stored credentials for a provider account.
 */
export function deleteCredentials(provider, accountId, storagePolicy) {
    deleteAccount(provider, accountId, storagePolicy);
}
export function preflightProviderCredentialDeletion(providers, storagePolicy) {
    return preflightProviderAccountDeletions(providers, storagePolicy);
}
/**
 * Delete every stored credential account for a provider.
 */
export function deleteProviderCredentials(provider, storagePolicy) {
    const plan = preflightProviderCredentialDeletion([provider], storagePolicy);
    return commitAccountDeletions(plan);
}
/**
 * Check if credentials exist and are not expired.
 */
export function hasValidCredentials(provider, accountId = DEFAULT_ACCOUNT_ID, storagePolicy) {
    const record = loadAccount(provider, accountId, storagePolicy);
    if (!record)
        return false;
    return record.credentials.expires > Date.now();
}
/**
 * List all accounts configured for a provider.
 */
export function listProviderAccounts(provider, storagePolicy) {
    return listAccounts(provider, storagePolicy);
}
export async function getAccessToken(provider, accountId = DEFAULT_ACCOUNT_ID, opts) {
    const returnOutcome = opts?.outcome === true;
    const finish = (outcome) => returnOutcome ? outcome : outcome.ok ? outcome.accessToken : null;
    // The token must have at least this much life left to be returned without a
    // refresh. Never below the historical buffer; a non-positive/NaN override is
    // ignored (fail-safe: a bad value can't disable the refresh).
    const raw = opts?.minRemainingMs;
    const effectiveBufferMs = typeof raw === "number" && Number.isFinite(raw) && raw > REFRESH_BUFFER_MS
        ? raw
        : REFRESH_BUFFER_MS;
    const requestedWidenedLifetime = effectiveBufferMs > REFRESH_BUFFER_MS;
    if (!isSubscriptionProvider(provider)) {
        const direct = loadAccount(provider, accountId, opts?.storagePolicy);
        if (!direct) {
            return finish(tokenFailure("auth", "No credential is stored"));
        }
        // Direct API keys can't be refreshed; a still-valid key is returned even if
        // it is inside the widened window (there is nothing to refresh into).
        if (direct.credentials.expires <= Date.now()) {
            return finish(tokenFailure("auth", "Stored credential is expired", {
                expiresAt: direct.credentials.expires,
            }));
        }
        return finish({
            ok: true,
            accessToken: direct.credentials.access,
            expiresAt: direct.credentials.expires,
            refreshed: false,
        });
    }
    const initial = loadCredentials(provider, accountId, opts?.storagePolicy);
    if (!initial) {
        return finish(tokenFailure("auth", "No credential is stored"));
    }
    if (initial.credentials.expires > Date.now() + effectiveBufferMs) {
        return finish({
            ok: true,
            accessToken: initial.credentials.access,
            expiresAt: initial.credentials.expires,
            refreshed: false,
        });
    }
    if (isCodingPlanKeySubscriptionProvider(provider)) {
        if (initial.credentials.expires > Date.now() && !requestedWidenedLifetime) {
            return finish({
                ok: true,
                accessToken: initial.credentials.access,
                expiresAt: initial.credentials.expires,
                refreshed: false,
            });
        }
        return finish(initial.credentials.expires > Date.now()
            ? tokenFailure("insufficient-lifetime", "Credential cannot be refreshed to satisfy the requested lifetime", {
                expiresAt: initial.credentials.expires,
                minRemainingMs: effectiveBufferMs,
            })
            : tokenFailure("auth", "Stored credential is expired", {
                expiresAt: initial.credentials.expires,
            }));
    }
    if (isExternalCliSubscriptionProvider(provider) ||
        isUnavailableSubscriptionProvider(provider)) {
        logger.info(`[auth] ${provider} is not an importable OAuth credential; use its first-party coding client or supported coding endpoint.`);
        return finish(tokenFailure("auth", `${provider} cannot provide importable OAuth tokens`));
    }
    return accountRefreshMutex.acquire(`${provider}:${accountId}`, async () => {
        // Re-read after acquiring the lock — a concurrent caller may have
        // already refreshed the token, in which case we want the new one.
        const stored = loadAccount(provider, accountId, opts?.storagePolicy);
        if (!stored) {
            return finish(tokenFailure("auth", "No credential is stored"));
        }
        const { credentials } = stored;
        if (credentials.expires > Date.now() + effectiveBufferMs) {
            return finish({
                ok: true,
                accessToken: credentials.access,
                expiresAt: credentials.expires,
                refreshed: false,
            });
        }
        // Refused BEFORE the grant is spent, not after. Anthropic and Codex rotate
        // refresh tokens on use (one-time-use), so throwing after the refresh would
        // discard the rotated token while the stored one is already consumed — every
        // later refresh 401s and the account needs manual re-auth. In front of the
        // await this costs nothing.
        if (!opts?.storagePolicy) {
            throw new ElizaError("Refreshing a stored credential requires an explicit account storage policy", {
                code: "AUTH_CREDENTIAL_MUTATION_POLICY_REQUIRED",
                context: { provider, accountId },
                severity: "fatal",
            });
        }
        logger.info(`[auth] Refreshing ${provider} token for account "${accountId}"...`);
        let refreshed;
        try {
            if (provider === "anthropic-subscription") {
                refreshed = await refreshAnthropicToken(credentials.refresh);
            }
            else if (provider === "openai-codex") {
                refreshed = await refreshCodexToken(credentials.refresh);
            }
            else if (!isOAuthSubscriptionProvider(provider)) {
                logger.error(`[auth] Unknown provider: ${provider}`);
                return finish(tokenFailure("auth", `Unknown credential provider: ${provider}`));
            }
            else {
                logger.error(`[auth] Refresh unsupported for provider: ${provider}`);
                return finish(tokenFailure("auth", `Refresh unsupported for provider: ${provider}`));
            }
        }
        catch (err) {
            // error-policy:J1 Provider refresh failures become typed outcomes at the
            // credential boundary so pool callers can distinguish auth from outages.
            logger.error(`[auth] Failed to refresh ${provider} token for "${accountId}": ${err}`);
            return finish(tokenFailure(classifyRefreshError(err), err instanceof Error ? err.message : String(err)));
        }
        // The grant was spent outside the storage lock. Commit only if the record
        // is still the one the refresh started from; a logout or re-login that
        // landed meanwhile owns the account now and the refresh result is dropped.
        const commit = updateAccountCredentialsIfUnchanged(provider, accountId, stored.credentialGeneration, refreshed, opts.storagePolicy);
        if (commit.kind === "missing") {
            logger.warn(`[auth] Discarded ${provider} refresh for "${accountId}": the account was removed while the refresh was in flight`);
            return finish(tokenFailure("auth", "Credential was removed while the refresh was in flight"));
        }
        if (commit.kind === "changed") {
            logger.warn(`[auth] Discarded ${provider} refresh for "${accountId}": the stored credential was replaced while the refresh was in flight`);
            const current = commit.record.credentials;
            if (current.expires > Date.now() + effectiveBufferMs) {
                return finish({
                    ok: true,
                    accessToken: current.access,
                    expiresAt: current.expires,
                    refreshed: false,
                });
            }
            return finish(current.expires > Date.now()
                ? tokenFailure("insufficient-lifetime", "Replacement credential does not satisfy the requested lifetime", { expiresAt: current.expires, minRemainingMs: effectiveBufferMs })
                : tokenFailure("auth", "Replacement credential is expired", {
                    expiresAt: current.expires,
                }));
        }
        if (refreshed.expires <= Date.now() + effectiveBufferMs) {
            return finish(tokenFailure("insufficient-lifetime", "Refreshed token does not satisfy the requested lifetime", { expiresAt: refreshed.expires, minRemainingMs: effectiveBufferMs }));
        }
        return finish({
            ok: true,
            accessToken: refreshed.access,
            expiresAt: refreshed.expires,
            refreshed: true,
        });
    });
}
function readConfiguredAnthropicSetupToken() {
    const namespace = getElizaNamespace();
    const explicitConfig = resolveAliasedEnvValue("ELIZA_CONFIG_PATH")?.trim();
    const configPath = explicitConfig
        ? resolveUserPath(explicitConfig)
        : path.join(resolveStateDir(), `${namespace}.json`);
    try {
        const parsed = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        const token = parsed.env?.__anthropicSubscriptionToken;
        return typeof token === "string" && token.trim() ? token.trim() : null;
    }
    catch (error) {
        // error-policy:J4 optional setup-token discovery degrades to unavailable;
        // malformed or unreadable config must not block unrelated auth providers.
        logger.debug(`[auth] Anthropic setup token config unavailable: ${String(error)}`);
        return null;
    }
}
function subscriptionStatusMetadata(provider) {
    const metadata = SUBSCRIPTION_PROVIDER_METADATA[provider];
    return {
        available: metadata.availability !== "unavailable",
        allowedClient: metadata.allowedClient,
        loginHint: metadata.setupHint,
        billingMode: metadata.billingMode,
        ...(metadata.availabilityReason
            ? { availabilityReason: metadata.availabilityReason }
            : {}),
    };
}
/**
 * Whether a vendor's registered subscription-auth descriptor discovers a
 * *configured* external credential right now (a CLI login on disk, a tool on
 * PATH). Used for the availability notices in
 * {@link applySubscriptionCredentialsLocal}.
 */
function hasConfiguredExternalCredential(provider) {
    const discovered = getSubscriptionAuthProvider(provider)?.detectExternalCredentials?.();
    if (discovered == null)
        return false;
    const rows = Array.isArray(discovered) ? discovered : [discovered];
    return rows.some((row) => row.configured);
}
export function getSubscriptionStatus() {
    ensureBuiltinSubscriptionAuthProviders();
    const rows = [];
    for (const provider of SUBSCRIPTION_PROVIDER_IDS) {
        const metadata = subscriptionStatusMetadata(provider);
        const accounts = listProviderAccounts(provider);
        for (const account of accounts) {
            rows.push({
                ...metadata,
                provider,
                accountId: account.id,
                label: account.label,
                configured: true,
                valid: account.credentials.expires > Date.now(),
                expiresAt: account.credentials.expires,
                source: isCodingPlanKeySubscriptionProvider(provider) &&
                    account.source === "api-key"
                    ? "coding-plan-key"
                    : "app",
            });
        }
        // Read the Claude Code OAuth blob exactly once per provider —
        // `readClaudeCodeOAuthBlob()` shells out to `security` on macOS
        // and calling it twice doubled the cost of every status poll.
        const claudeBlob = provider === "anthropic-subscription" ? readClaudeCodeOAuthBlob() : null;
        if (provider === "anthropic-subscription") {
            let importedClaudeAuth = null;
            let claudeSource = null;
            if (claudeBlob?.accessToken) {
                importedClaudeAuth = claudeBlob.accessToken;
                claudeSource = "claude-code-cli";
            }
            else {
                importedClaudeAuth = readConfiguredAnthropicSetupToken();
                if (importedClaudeAuth)
                    claudeSource = "setup-token";
            }
            if (importedClaudeAuth) {
                const blobExpiresAt = claudeBlob?.expiresAt ?? null;
                const blobValid = claudeBlob
                    ? blobExpiresAt === null || blobExpiresAt > Date.now()
                    : true;
                const accountId = claudeSource === "claude-code-cli"
                    ? "claude-code-cli"
                    : "setup-token";
                const label = claudeSource === "claude-code-cli"
                    ? "Claude Code CLI"
                    : "Setup Token";
                rows.push({
                    ...metadata,
                    provider,
                    accountId,
                    label,
                    configured: true,
                    valid: blobValid,
                    expiresAt: blobExpiresAt,
                    source: claudeSource,
                });
            }
        }
        // Credentials this vendor manages outside eliza's own account store (a
        // Codex/Gemini CLI login, an unavailable-provider notice) are contributed
        // by the vendor's registered subscription-auth descriptor, so host `auth/`
        // no longer branches per vendor.
        const discovered = getSubscriptionAuthProvider(provider)?.detectExternalCredentials?.();
        if (discovered != null) {
            const discoveredRows = Array.isArray(discovered)
                ? discovered
                : [discovered];
            for (const row of discoveredRows) {
                rows.push({
                    ...metadata,
                    provider,
                    accountId: row.accountId,
                    label: row.label,
                    configured: row.configured,
                    valid: row.valid,
                    expiresAt: row.expiresAt,
                    source: row.source,
                });
            }
        }
    }
    return rows;
}
function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
/**
 * Read and validate local Claude Code credential metadata for status and discovery.
 * Persisted access tokens may be expired while the CLI refreshes its own login;
 * callers distinguish presence from validity without exchanging the credential.
 */
function readClaudeCodeOAuthBlob() {
    const parse = (raw, source) => {
        try {
            const parsed = JSON.parse(raw);
            if (!isRecord(parsed))
                return null;
            const oauth = parsed.claudeAiOauth;
            if (!isRecord(oauth))
                return null;
            const accessTokenFields = [oauth.accessToken, oauth.access_token].filter((value) => value !== undefined);
            if (accessTokenFields.length === 0 ||
                accessTokenFields.some((value) => typeof value !== "string" || !value.trim())) {
                return null;
            }
            const accessToken = oauth.accessToken ?? oauth.access_token;
            if (typeof accessToken !== "string")
                return null;
            const refreshTokenFields = [
                oauth.refreshToken,
                oauth.refresh_token,
            ].filter((value) => value !== undefined);
            if (refreshTokenFields.some((value) => value !== null && typeof value !== "string")) {
                return null;
            }
            const refreshTokenValue = oauth.refreshToken ?? oauth.refresh_token ?? null;
            const refreshToken = typeof refreshTokenValue === "string" ? refreshTokenValue : null;
            const expiresAtFields = [oauth.expiresAt, oauth.expires_at].filter((value) => value !== undefined);
            if (expiresAtFields.some((value) => value !== null &&
                (typeof value !== "number" || !Number.isFinite(value) || value < 0))) {
                return null;
            }
            const expiresAtValue = oauth.expiresAt ?? oauth.expires_at ?? null;
            const expiresAt = typeof expiresAtValue === "number" ? expiresAtValue : null;
            return {
                accessToken: accessToken.trim(),
                refreshToken,
                expiresAt,
                source,
            };
        }
        catch {
            // error-policy:J3 stored CLI credentials are untrusted input; malformed
            // JSON produces the explicit invalid/unavailable signal.
            return null;
        }
    };
    // 1. Try ~/.claude/.credentials.json
    const credPath = path.join(os.homedir(), ".claude", ".credentials.json");
    try {
        if (fs.existsSync(credPath)) {
            const raw = fs.readFileSync(credPath, "utf-8");
            const blob = parse(raw, "credentials file");
            if (blob)
                return blob;
        }
    }
    catch (error) {
        // error-policy:J4 Claude CLI credentials are an optional external source;
        // inability to read them leaves that source explicitly unavailable.
        logger.debug(`[auth] Claude Code credential file unavailable: ${String(error)}`);
    }
    return null;
}
function isSubscriptionCredentialApplicationDisabled() {
    const disabled = process.env.ELIZA_DISABLE_SUBSCRIPTION_CREDENTIALS?.trim().toLowerCase();
    return (disabled === "1" ||
        disabled === "true" ||
        disabled === "yes" ||
        disabled === "on");
}
/**
 * Local-only, synchronous part of subscription credential application.
 *
 * Reads stored accounts from disk and reports which coding-agent surfaces
 * they enable. `_config` is accepted for call-site compatibility; subscriptions
 * never mutate it. Performs no network
 * I/O, so it is safe to await on the blocking boot path. Local Claude Code
 * credential discovery is handled by {@link applySubscriptionCredentialsDeferred}.
 *
 * None of the Anthropic / Codex / Gemini / coding-plan branches mutate `config`
 * or `process.env` — they are purely informational logging. No subscription
 * sets `model.primary`: none has a runtime text handler.
 */
export function applySubscriptionCredentialsLocal(_config) {
    if (isSubscriptionCredentialApplicationDisabled()) {
        logger.info("[auth] Subscription credential application disabled by ELIZA_DISABLE_SUBSCRIPTION_CREDENTIALS");
        return;
    }
    ensureBuiltinSubscriptionAuthProviders();
    // ── Anthropic subscription ──────────────────────────────────────────
    //
    // Anthropic subscription tokens (sk-ant-oat*) are restricted to the
    // Claude Code CLI by Anthropic's TOS. They must NOT be used for direct
    // API calls from the elizaOS runtime. The subscription token only flows
    // to spawned coding-agent CLI sessions via the orchestrator plugin
    // (which ARE Claude Code). If the user has only a subscription and no
    // API key, the runtime simply won't have an Anthropic provider — they
    // need an API key or Eliza Cloud for the main agent.
    const anthropicAccounts = listProviderAccounts("anthropic-subscription");
    if (anthropicAccounts.length > 0) {
        const labels = anthropicAccounts
            .map((a) => `"${a.label}" (${a.id})`)
            .join(", ");
        logger.info(`[auth] Anthropic subscription accounts configured: ${labels} — available for coding agents (Claude Code CLI). ` +
            "Not applied to runtime env. Add an API key or connect Eliza Cloud for the main agent.");
    }
    // ── OpenAI Codex subscription ────────────────────────────────────────
    //
    // Codex subscriptions power task-agent (Codex CLI) subprocesses only; there
    // is no Codex-backed chat provider. Do not inject their OAuth access tokens into OPENAI_API_KEY:
    // the normal OpenAI API path expects scoped API keys.
    const codexAccounts = listProviderAccounts("openai-codex");
    if (codexAccounts.length > 0) {
        const labels = codexAccounts
            .map((a) => `"${a.label}" (${a.id})`)
            .join(", ");
        logger.info(`[auth] OpenAI Codex subscription accounts configured: ${labels} — available for Codex coding agents. ` +
            "Not applied to OPENAI_API_KEY; add a direct OpenAI API key for @elizaos/plugin-openai runtime inference.");
    }
    else {
        if (hasConfiguredExternalCredential("openai-codex")) {
            logger.info("[auth] OpenAI Codex CLI auth detected — available for Codex coding agents. " +
                "Not applied to OPENAI_API_KEY; add a direct OpenAI API key for @elizaos/plugin-openai runtime inference.");
        }
    }
    const geminiAccounts = listProviderAccounts("gemini-cli");
    if (geminiAccounts.length > 0 ||
        hasConfiguredExternalCredential("gemini-cli")) {
        logger.info("[auth] Gemini CLI subscription surface detected/configured — available through the external Gemini CLI, but not wired to the coding-agent orchestrator. " +
            "Not applied to GOOGLE_API_KEY or GOOGLE_GENERATIVE_AI_API_KEY.");
    }
    for (const provider of ["zai-coding", "kimi-coding"]) {
        const accounts = listProviderAccounts(provider);
        if (accounts.length === 0)
            continue;
        const labels = accounts.map((a) => `"${a.label}" (${a.id})`).join(", ");
        const envName = provider === "zai-coding" ? "ZAI_API_KEY" : "MOONSHOT_API_KEY";
        logger.info(`[auth] ${provider} coding-plan accounts configured: ${labels} — available only for the provider's dedicated coding endpoint. ` +
            `Not applied to ${envName}.`);
    }
    // Subscriptions never set `model.primary`: none of them has a runtime text
    // handler, so chat must be configured through a separate provider.
}
/**
 * Apply subscription credentials to the environment.
 * Called at startup to make credentials available to elizaOS plugins.
 *
 * Combines local account diagnostics
 * ({@link applySubscriptionCredentialsLocal}) with local Claude Code credential
 * discovery ({@link applySubscriptionCredentialsDeferred}). Startup can call
 * either phase separately; API routes and hot reload use this combined form.
 *
 * **Claude subscription tokens are NOT applied to the runtime environment.**
 * Anthropic's TOS only permits Claude subscription tokens to be used through
 * the Claude Code CLI itself. Eliza honours this by keeping the token
 * available for the task-agent orchestrator (which spawns `claude` CLI
 * subprocesses) but never injecting it into `process.env.ANTHROPIC_API_KEY`.
 *
 * Codex / ChatGPT subscription tokens are also CLI credentials. They are used
 * by Codex task agents only, never injected into `OPENAI_API_KEY`.
 */
export async function applySubscriptionCredentials(config) {
    applySubscriptionCredentialsLocal(config);
    await applySubscriptionCredentialsDeferred();
}
/**
 * Discover locally stored Claude Code credentials for startup diagnostics.
 *
 * The CLI owns its credential lifecycle, including refreshing expired tokens.
 * Discovery reads its file without exchanging or importing credentials and
 * reports presence without claiming that the provider accepted the login.
 */
export async function applySubscriptionCredentialsDeferred() {
    if (isSubscriptionCredentialApplicationDisabled())
        return;
    if (listProviderAccounts("anthropic-subscription").length > 0)
        return;
    if (readClaudeCodeOAuthBlob()) {
        logger.info("[auth] Detected local Claude Code CLI credentials. The CLI manages refresh. " +
            "Add an API key or connect Eliza Cloud for the main agent.");
    }
}
//# sourceMappingURL=credentials.js.map