export interface OAuthCredentials {
    access: string;
    refresh: string;
    expires: number;
    /**
     * OIDC id_token, when the provider issues one. Codex (`openai-codex`)
     * requires it in `~/.codex/auth.json` (`tokens.id_token`) for chatgpt-mode
     * auth, so a pooled account must persist it for its materialized CODEX_HOME
     * to authenticate. Optional — other providers don't use it.
     */
    idToken?: string;
}
export type SubscriptionProvider = "anthropic-subscription" | "openai-codex" | "gemini-cli" | "zai-coding" | "kimi-coding" | "deepseek-coding";
export type OAuthSubscriptionProvider = "anthropic-subscription" | "openai-codex";
export type CodingPlanKeySubscriptionProvider = "zai-coding" | "kimi-coding";
export type ExternalCliSubscriptionProvider = "gemini-cli";
export type UnavailableSubscriptionProvider = "deepseek-coding";
export type DirectAccountProvider = "anthropic-api" | "openai-api" | "deepseek-api" | "zai-api" | "moonshot-api" | "cerebras-api" | "openrouter-api" | "xai-api";
export type AccountCredentialProvider = SubscriptionProvider | DirectAccountProvider;
export declare const SUBSCRIPTION_PROVIDER_IDS: readonly ["anthropic-subscription", "openai-codex", "gemini-cli", "zai-coding", "kimi-coding", "deepseek-coding"];
export declare const OAUTH_SUBSCRIPTION_PROVIDER_IDS: readonly ["anthropic-subscription", "openai-codex"];
export declare const CODING_PLAN_KEY_SUBSCRIPTION_PROVIDER_IDS: readonly ["zai-coding", "kimi-coding"];
export declare const EXTERNAL_CLI_SUBSCRIPTION_PROVIDER_IDS: readonly ["gemini-cli"];
export declare const UNAVAILABLE_SUBSCRIPTION_PROVIDER_IDS: readonly ["deepseek-coding"];
export declare const DIRECT_ACCOUNT_PROVIDER_IDS: readonly ["anthropic-api", "openai-api", "deepseek-api", "zai-api", "moonshot-api", "cerebras-api", "openrouter-api", "xai-api"];
export declare const ACCOUNT_CREDENTIAL_PROVIDER_IDS: readonly ["anthropic-subscription", "openai-codex", "gemini-cli", "zai-coding", "kimi-coding", "deepseek-coding", "anthropic-api", "openai-api", "deepseek-api", "zai-api", "moonshot-api", "cerebras-api", "openrouter-api", "xai-api"];
export declare function isSubscriptionProvider(value: unknown): value is SubscriptionProvider;
export declare function isDirectAccountProvider(value: unknown): value is DirectAccountProvider;
export declare function isOAuthSubscriptionProvider(value: unknown): value is OAuthSubscriptionProvider;
export declare function isCodingPlanKeySubscriptionProvider(value: unknown): value is CodingPlanKeySubscriptionProvider;
export declare function isExternalCliSubscriptionProvider(value: unknown): value is ExternalCliSubscriptionProvider;
export declare function isUnavailableSubscriptionProvider(value: unknown): value is UnavailableSubscriptionProvider;
export declare function isAccountCredentialProvider(value: unknown): value is AccountCredentialProvider;
export declare const DIRECT_ACCOUNT_PROVIDER_ENV: Record<DirectAccountProvider, string>;
/** Direct accounts served through the OpenAI-compatible credential bridge. */
export declare const OPENAI_COMPAT_BASE_BY_DIRECT_PROVIDER: Readonly<Partial<Record<DirectAccountProvider, string>>>;
/** Maps subscription provider IDs to their model provider short names. */
export declare const SUBSCRIPTION_PROVIDER_MAP: Record<SubscriptionProvider, string>;
export declare const CODING_PLAN_PROVIDER_BASE_URL: Record<CodingPlanKeySubscriptionProvider, string>;
export type SubscriptionProviderAuthMode = "oauth" | "external-cli" | "coding-plan-key" | "unavailable";
export type SubscriptionProviderBillingMode = "subscription-coding-plan" | "subscription-coding-cli";
export type SubscriptionProviderAvailability = "available" | "external" | "unavailable";
export interface SubscriptionProviderMetadata {
    providerId: SubscriptionProvider;
    displayName: string;
    selectionIds: readonly string[];
    allowedClient: string;
    billingMode: SubscriptionProviderBillingMode;
    authMode: SubscriptionProviderAuthMode;
    availability: SubscriptionProviderAvailability;
    setupHint: string;
    directProviderId?: DirectAccountProvider;
    defaultBaseUrl?: string;
    probePath?: string;
    availabilityReason?: string;
}
export declare const SUBSCRIPTION_PROVIDER_METADATA: Record<SubscriptionProvider, SubscriptionProviderMetadata>;
export declare function getSubscriptionProviderMetadata(provider: SubscriptionProvider): SubscriptionProviderMetadata;
export interface StoredCredentials {
    provider: AccountCredentialProvider;
    credentials: OAuthCredentials;
    createdAt: number;
    updatedAt: number;
}
//# sourceMappingURL=types.d.ts.map