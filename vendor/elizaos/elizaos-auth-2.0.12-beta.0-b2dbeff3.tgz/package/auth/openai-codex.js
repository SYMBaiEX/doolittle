/**
 * OpenAI Codex (ChatGPT Plus/Pro subscription) OAuth flow
 *
 * Uses inlined OAuth (vendored helpers).
 * Handles local callback server + manual code paste fallback.
 */
import { logger } from "@elizaos/core";
import { loginOpenAICodex, refreshOpenAICodexToken, } from "./vendor/pi-oauth/openai-codex-login.js";
/**
 * Start the OpenAI Codex OAuth flow.
 * Starts a local callback server on port 1455 and returns the auth URL.
 */
export function startCodexLogin() {
    return new Promise((resolveFlow, rejectFlow) => {
        let authUrl = "";
        let flowState = "";
        let resolveManual = null;
        let closeServer = null;
        let credentials;
        const manualPromise = new Promise((resolve) => {
            resolveManual = resolve;
        });
        try {
            credentials = loginOpenAICodex({
                onAuth: ({ url }) => {
                    authUrl = url;
                    try {
                        const parsed = new URL(url);
                        flowState = parsed.searchParams.get("state") || "";
                    }
                    catch {
                        // error-policy:J3 the authorization URL is vendor input; an invalid
                        // URL yields an explicit empty state rather than a fabricated value.
                    }
                    resolveFlow({
                        get authUrl() {
                            return authUrl;
                        },
                        state: flowState,
                        submitCode: (code) => resolveManual?.(code),
                        credentials,
                        close: () => closeServer?.(),
                    });
                },
                onPrompt: async () => manualPromise,
                onManualCodeInput: () => manualPromise,
                onProgress: () => { },
                originator: "eliza",
            }).then((creds) => ({
                access: creds.access,
                refresh: creds.refresh,
                expires: creds.expires,
                ...(creds.idToken ? { idToken: creds.idToken } : {}),
            }));
            void credentials.catch((err) => {
                // error-policy:J5 this rejection is also exposed on `flow.credentials`;
                // observe it here so pre-onAuth failures reject the outer flow promise.
                // If the flow fails before `onAuth` runs (e.g. the local callback
                // server can't bind), resolveFlow was never called and the outer
                // Promise<CodexFlow> would hang forever. Reject it so the caller of
                // startCodexLogin() gets the error instead of awaiting indefinitely.
                // After onAuth has resolved the flow this reject has no additional effect.
                rejectFlow(err);
                logger.warn(`[auth] OpenAI Codex credential flow failed: ${err}`);
            });
        }
        catch (err) {
            // error-policy:J1 OAuth construction boundary translation — synchronous
            // vendor setup failures reject the public flow immediately.
            rejectFlow(err);
            return;
        }
        closeServer = () => {
            resolveManual?.("");
        };
    });
}
/**
 * Refresh an expired OpenAI Codex token.
 */
export async function refreshCodexToken(refreshToken) {
    const refreshed = await refreshOpenAICodexToken(refreshToken);
    return {
        access: refreshed.access,
        refresh: refreshed.refresh,
        expires: refreshed.expires,
        ...(refreshed.idToken ? { idToken: refreshed.idToken } : {}),
    };
}
//# sourceMappingURL=openai-codex.js.map