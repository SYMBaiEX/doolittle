/**
 * Shared classifier for access-token expiry phrases emitted by provider and
 * coding-agent auth failures. It only recognizes explicit expiry language; a
 * bare 401 or unauthorized response can be revoked credentials and must be
 * handled by the caller's broader auth classifier.
 */
/** UI-facing reason derived after a failure is already known to be auth-shaped. */
export type CodingAuthFailureReason = "token_expired" | "needs_reauth" | "rate_limited" | "unknown";
/** Returns true for explicit REFRESH-token expiry language — a genuinely
 * dead credential (the holder can no longer self-refresh), distinct from a
 * recoverable access-token expiry. */
export declare function isRefreshTokenExpiryText(text: string | null | undefined): boolean;
/** Returns true only for explicit access-token expiry language. */
export declare function isTokenExpiryText(text: string | null | undefined): boolean;
/** Refines an auth-shaped provider error without widening the auth classifier. */
export declare function classifyAuthFailureReason(text: string | null | undefined): CodingAuthFailureReason;
//# sourceMappingURL=token-expiry.d.ts.map