/**
 * Per-account credential storage.
 *
 * Layout: `<stateDir>/auth/{providerId}/{accountId}.json` (mode 0600,
 * atomic writes). Multiple accounts per provider are supported. Every mutator
 * requires a branded root/owner policy; isolated policies are physically
 * confined to the OS temporary directory and no operation may cross its
 * canonical provider directory. Records persist as versioned AES-GCM
 * envelopes encrypted with the vault master key; legacy plaintext records
 * are validated and re-encrypted atomically on first read.
 */
import { randomBytes, randomUUID } from "node:crypto";
import fs from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { logger, resolveStateDir } from "@elizaos/core";
import { ElizaError } from "@elizaos/core/protocol";
import { CryptoError, decrypt, encrypt } from "../vault/crypto.js";
import { loadDefaultMasterKeySync } from "../vault/master-key.js";
import { ACCOUNT_CREDENTIAL_PROVIDER_IDS, } from "./types.js";
const ACCOUNT_STORAGE_POLICY = Symbol("account-storage-policy");
const ACCOUNT_STORAGE_ROOT_IDENTITY = Symbol("account-storage-root-identity");
const ACCOUNT_DELETION_PLAN = Symbol("account-deletion-plan");
const STORAGE_LOCK_DIRECTORY = ".credential-storage.lock";
const STORAGE_LOCK_OWNER_FILE = "owner.json";
const STORAGE_GENERATION_FILE = ".credential-storage-generation";
const STORAGE_LOCK_WAIT_MS = 20;
const STORAGE_LOCK_TIMEOUT_MS = 15_000;
const STORAGE_LOCK_STALE_MS = 120_000;
function storageError(code, message, context, cause) {
    return new ElizaError(message, {
        code,
        context,
        severity: "fatal",
        ...(cause !== undefined ? { cause } : {}),
    });
}
function isPathAtOrWithin(parent, target) {
    const relative = path.relative(parent, target);
    return (relative === "" ||
        (relative !== ".." &&
            !relative.startsWith(`..${path.sep}`) &&
            !path.isAbsolute(relative)));
}
function resolvePhysicalPath(target) {
    let existingAncestor = path.resolve(target);
    const missingSegments = [];
    while (!fs.existsSync(existingAncestor)) {
        const parent = path.dirname(existingAncestor);
        if (parent === existingAncestor) {
            return path.resolve(target);
        }
        missingSegments.unshift(path.basename(existingAncestor));
        existingAncestor = parent;
    }
    return path.resolve(fs.realpathSync(existingAncestor), ...missingSegments);
}
function assertContained(parent, target, operation) {
    const lexicalParent = path.resolve(parent);
    const lexicalTarget = path.resolve(target);
    const physicalParent = resolvePhysicalPath(lexicalParent);
    const physicalTarget = resolvePhysicalPath(lexicalTarget);
    if (!isPathAtOrWithin(lexicalParent, lexicalTarget) ||
        !isPathAtOrWithin(physicalParent, physicalTarget)) {
        throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", `Credential ${operation} target escapes its canonical storage directory`, {
            operation,
            parent: lexicalParent,
            target: lexicalTarget,
            physicalParent,
            physicalTarget,
        });
    }
}
function fsyncDirectory(directory) {
    if (process.platform === "win32")
        return;
    const descriptor = fs.openSync(directory, fs.constants.O_RDONLY | (fs.constants.O_DIRECTORY ?? 0));
    try {
        fs.fsyncSync(descriptor);
    }
    finally {
        fs.closeSync(descriptor);
    }
}
function sleepSync(milliseconds) {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT)), 0, 0, milliseconds);
}
function assertRegularDirectory(directory, operation) {
    let stat;
    try {
        stat = fs.lstatSync(directory);
    }
    catch (cause) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_ROOT_CHANGED", `Credential ${operation} directory is unavailable`, { directory, operation }, cause);
    }
    if (stat.isSymbolicLink() || !stat.isDirectory()) {
        throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", `Credential ${operation} directory must be a real directory`, { directory, operation });
    }
    return stat;
}
function readGenerationFile(authRoot) {
    const generationFile = path.join(authRoot, STORAGE_GENERATION_FILE);
    if (!fs.existsSync(generationFile))
        return 0;
    let descriptor;
    try {
        descriptor = fs.openSync(generationFile, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
        const stat = fs.fstatSync(descriptor);
        if (!stat.isFile()) {
            throw storageError("AUTH_CREDENTIAL_GENERATION_INVALID", "Credential storage generation is not a regular file", { generationFile });
        }
        const raw = fs.readFileSync(descriptor, "utf8").trim();
        if (!/^\d+$/.test(raw)) {
            throw storageError("AUTH_CREDENTIAL_GENERATION_INVALID", "Credential storage generation is malformed", { generationFile });
        }
        const generation = Number(raw);
        if (!Number.isSafeInteger(generation) || generation < 0) {
            throw storageError("AUTH_CREDENTIAL_GENERATION_INVALID", "Credential storage generation is outside the supported range", { generationFile, generation: raw });
        }
        return generation;
    }
    catch (cause) {
        if (cause.code === "ELOOP") {
            throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", "Credential storage generation cannot be a symbolic link", { generationFile }, cause);
        }
        throw cause;
    }
    finally {
        if (descriptor !== undefined)
            fs.closeSync(descriptor);
    }
}
function ensureAuthRoot(policy) {
    assertStoragePolicy(policy);
    fs.mkdirSync(policy.authRoot, { recursive: true, mode: 0o700 });
    assertStoragePolicy(policy);
    assertContained(policy.stateRoot, policy.authRoot, "auth-directory");
    assertRegularDirectory(policy.authRoot, "auth");
}
function processIsAlive(pid) {
    try {
        process.kill(pid, 0);
        return true;
    }
    catch (cause) {
        return cause.code !== "ESRCH";
    }
}
function readLockOwner(ownerFile) {
    try {
        const descriptor = fs.openSync(ownerFile, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
        try {
            const stat = fs.fstatSync(descriptor);
            if (!stat.isFile())
                return null;
            let value;
            try {
                value = JSON.parse(fs.readFileSync(descriptor, "utf8"));
            }
            catch {
                // error-policy:J3 another process may observe the owner file between
                // its exclusive creation and durable JSON write; the directory age
                // determines whether an ownerless lock is reclaimable.
                return null;
            }
            if (!value || typeof value !== "object")
                return null;
            const owner = value;
            return Number.isSafeInteger(owner.pid) && typeof owner.token === "string"
                ? { pid: owner.pid, token: owner.token }
                : null;
        }
        finally {
            fs.closeSync(descriptor);
        }
    }
    catch (cause) {
        if (cause.code === "ENOENT")
            return null;
        throw cause;
    }
}
function removeStaleLock(policy, lockDir) {
    const stat = fs.lstatSync(lockDir, { throwIfNoEntry: false });
    // The owner can release its lock after our mkdir observed EEXIST. Retry
    // acquisition so the generation fence runs under the newly acquired lock.
    if (!stat)
        return true;
    if (stat.isSymbolicLink() || !stat.isDirectory()) {
        throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", "Credential storage lock cannot be a symbolic link or non-directory", { lockDir });
    }
    const owner = readLockOwner(path.join(lockDir, STORAGE_LOCK_OWNER_FILE));
    const expired = Date.now() - stat.mtimeMs >= STORAGE_LOCK_STALE_MS;
    if (owner && processIsAlive(owner.pid))
        return false;
    if (!owner && !expired)
        return false;
    const quarantine = `${lockDir}.stale.${process.pid}.${randomUUID()}`;
    assertContained(policy.authRoot, quarantine, "stale-lock-quarantine");
    try {
        fs.renameSync(lockDir, quarantine);
    }
    catch (cause) {
        if (cause.code === "ENOENT")
            return true;
        throw cause;
    }
    fs.rmSync(quarantine, { recursive: true, force: false });
    fsyncDirectory(policy.authRoot);
    return true;
}
function acquireStorageLock(policy, operation) {
    ensureAuthRoot(policy);
    const lockDir = path.join(policy.authRoot, STORAGE_LOCK_DIRECTORY);
    const ownerFile = path.join(lockDir, STORAGE_LOCK_OWNER_FILE);
    assertContained(policy.authRoot, lockDir, "storage-lock");
    const startedAt = Date.now();
    while (true) {
        try {
            fs.mkdirSync(lockDir, { mode: 0o700 });
            const token = randomUUID();
            let descriptor;
            try {
                descriptor = fs.openSync(ownerFile, fs.constants.O_WRONLY |
                    fs.constants.O_CREAT |
                    fs.constants.O_EXCL |
                    fs.constants.O_NOFOLLOW, 0o600);
                fs.writeFileSync(descriptor, JSON.stringify({ operation, pid: process.pid, token }), "utf8");
                fs.fsyncSync(descriptor);
            }
            finally {
                if (descriptor !== undefined)
                    fs.closeSync(descriptor);
            }
            fsyncDirectory(lockDir);
            fsyncDirectory(policy.authRoot);
            assertStoragePolicy(policy);
            const currentGeneration = readGenerationFile(policy.authRoot);
            const policyGeneration = policy[ACCOUNT_STORAGE_ROOT_IDENTITY].generation;
            if (currentGeneration !== policyGeneration) {
                fs.unlinkSync(ownerFile);
                fs.rmdirSync(lockDir);
                fsyncDirectory(policy.authRoot);
                throw storageError("AUTH_CREDENTIAL_STORAGE_GENERATION_CHANGED", "Credential storage policy predates the latest reset", { currentGeneration, operation, policyGeneration });
            }
            return { lockDir, ownerFile, policy, token };
        }
        catch (cause) {
            const errorCode = cause.code;
            if (errorCode === "ENOENT") {
                // error-policy:J2 The auth root vanished between lock creation and
                // the generation check — a concurrent full reset removed it. The
                // fence held (nothing was written); surface the typed generation
                // error the reset contract promises instead of the raw ENOENT.
                throw storageError("AUTH_CREDENTIAL_STORAGE_GENERATION_CHANGED", "Credential storage policy predates the latest reset", {
                    operation,
                    policyGeneration: policy[ACCOUNT_STORAGE_ROOT_IDENTITY].generation,
                }, cause);
            }
            if (errorCode !== "EEXIST")
                throw cause;
            if (removeStaleLock(policy, lockDir))
                continue;
            if (Date.now() - startedAt >= STORAGE_LOCK_TIMEOUT_MS) {
                throw storageError("AUTH_CREDENTIAL_STORAGE_LOCK_TIMEOUT", "Timed out waiting for the credential storage lock", { lockDir, operation, timeoutMs: STORAGE_LOCK_TIMEOUT_MS }, cause);
            }
            sleepSync(STORAGE_LOCK_WAIT_MS);
            assertStoragePolicy(policy);
        }
    }
}
function releaseStorageLock(lock) {
    assertStoragePolicy(lock.policy);
    const owner = readLockOwner(lock.ownerFile);
    if (!owner || owner.pid !== process.pid || owner.token !== lock.token) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_LOCK_OWNERSHIP_LOST", "Credential storage lock ownership changed before release", { lockDir: lock.lockDir });
    }
    const entries = fs.readdirSync(lock.lockDir);
    if (entries.length !== 1 || entries[0] !== STORAGE_LOCK_OWNER_FILE) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_LOCK_OWNERSHIP_LOST", "Credential storage lock contains unexpected entries", { entries, lockDir: lock.lockDir });
    }
    fs.unlinkSync(lock.ownerFile);
    fs.rmdirSync(lock.lockDir);
    fsyncDirectory(lock.policy.authRoot);
}
function withStorageLock(policy, operation, callback) {
    const lock = acquireStorageLock(policy, operation);
    let result;
    try {
        result = callback();
    }
    catch (cause) {
        try {
            releaseStorageLock(lock);
        }
        catch (releaseError) {
            throw storageError("AUTH_CREDENTIAL_STORAGE_LOCK_RELEASE_FAILED", "Credential operation failed and its storage lock could not be released", { operation, releaseError: String(releaseError) }, cause);
        }
        throw cause;
    }
    releaseStorageLock(lock);
    return result;
}
function createAccountStoragePolicy(stateRoot, owner) {
    if (!stateRoot.trim() || !path.isAbsolute(stateRoot)) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_POLICY_INVALID", "Account storage policy requires an absolute state root", { owner, stateRoot });
    }
    const canonicalStateRoot = resolvePhysicalPath(stateRoot);
    fs.mkdirSync(canonicalStateRoot, { recursive: true, mode: 0o700 });
    const stateRootStat = assertRegularDirectory(canonicalStateRoot, "state-root");
    if (owner === "isolated-test") {
        const canonicalTempRoot = fs.realpathSync.native(tmpdir());
        if (canonicalStateRoot === canonicalTempRoot ||
            !isPathAtOrWithin(canonicalTempRoot, canonicalStateRoot)) {
            throw storageError("AUTH_CREDENTIAL_ISOLATED_ROOT_REQUIRED", "Isolated account storage must resolve beneath the OS temporary directory", {
                owner,
                stateRoot: path.resolve(stateRoot),
                physicalStateRoot: canonicalStateRoot,
                temporaryRoot: canonicalTempRoot,
            });
        }
    }
    const authRoot = path.join(canonicalStateRoot, "auth");
    let generation = 0;
    if (fs.existsSync(authRoot)) {
        assertContained(canonicalStateRoot, authRoot, "auth-directory");
        assertRegularDirectory(authRoot, "auth");
        generation = readGenerationFile(authRoot);
    }
    return Object.freeze({
        stateRoot: canonicalStateRoot,
        authRoot,
        owner,
        [ACCOUNT_STORAGE_POLICY]: true,
        [ACCOUNT_STORAGE_ROOT_IDENTITY]: Object.freeze({
            dev: stateRootStat.dev,
            generation,
            ino: stateRootStat.ino,
        }),
    });
}
export function createRuntimeAccountStoragePolicy(stateRoot) {
    return createAccountStoragePolicy(stateRoot, "runtime");
}
export function createIsolatedAccountStoragePolicy(stateRoot) {
    return createAccountStoragePolicy(stateRoot, "isolated-test");
}
function defaultReadPolicy() {
    return createRuntimeAccountStoragePolicy(resolveStateDir());
}
function assertStoragePolicy(policy) {
    if (policy?.[ACCOUNT_STORAGE_POLICY] !== true) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_POLICY_INVALID", "Credential operation requires a policy created by account-storage", {});
    }
    const rootIdentity = policy[ACCOUNT_STORAGE_ROOT_IDENTITY];
    let rootStat;
    try {
        rootStat = fs.lstatSync(policy.stateRoot);
    }
    catch (cause) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_ROOT_CHANGED", "Account storage root is no longer accessible", { stateRoot: policy.stateRoot }, cause);
    }
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_ROOT_CHANGED", "Account storage root is no longer the directory owned by this policy", { stateRoot: policy.stateRoot });
    }
    const physicalStateRoot = resolvePhysicalPath(policy.stateRoot);
    if (physicalStateRoot !== policy.stateRoot ||
        rootStat.dev !== rootIdentity.dev ||
        rootStat.ino !== rootIdentity.ino) {
        throw storageError("AUTH_CREDENTIAL_STORAGE_ROOT_CHANGED", "Account storage root changed after policy creation", {
            stateRoot: policy.stateRoot,
            physicalStateRoot,
            expectedDev: rootIdentity.dev,
            expectedIno: rootIdentity.ino,
            actualDev: rootStat.dev,
            actualIno: rootStat.ino,
        });
    }
    assertContained(policy.stateRoot, policy.authRoot, "policy");
    if (policy.owner === "isolated-test") {
        const canonicalTempRoot = fs.realpathSync.native(tmpdir());
        if (!isPathAtOrWithin(canonicalTempRoot, policy.stateRoot)) {
            throw storageError("AUTH_CREDENTIAL_ISOLATED_ROOT_REQUIRED", "Isolated account storage no longer resolves beneath the OS temporary directory", { stateRoot: policy.stateRoot, temporaryRoot: canonicalTempRoot });
        }
    }
}
function isEnvelope(value) {
    const candidate = value;
    return (candidate !== null &&
        typeof candidate === "object" &&
        candidate.schemaVersion === 2 &&
        typeof candidate.ciphertext === "string");
}
/** Persisted cryptographic identity; package renames must not change these bytes. */
function accountAad(provider, accountId) {
    return `@elizaos/auth/account/${provider}/${accountId}`;
}
/**
 * Test processes and isolated-test policies never touch the real vault master
 * key: each isolated auth root gets its own ephemeral in-process key, so a
 * test cannot decrypt (or corrupt) developer credentials even if pointed at a
 * real state directory by mistake.
 */
const testKeys = new Map();
function isTestProcess() {
    const argv = process.argv.join(" ").toLowerCase();
    return (process.env.NODE_ENV === "test" ||
        process.env.VITEST === "true" ||
        process.env.BUN_ENV === "test" ||
        argv.includes("vitest") ||
        argv.includes("bun test"));
}
function masterKey(policy) {
    if (policy.owner !== "isolated-test" && !isTestProcess()) {
        return loadDefaultMasterKeySync();
    }
    const root = path.resolve(policy.authRoot);
    const existing = testKeys.get(root);
    if (existing)
        return existing;
    const created = randomBytes(32);
    testKeys.set(root, created);
    return created;
}
const ACCOUNT_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._@-]{0,127}$/;
export function assertCanonicalAccountId(accountId) {
    if (typeof accountId !== "string" ||
        !ACCOUNT_ID_PATTERN.test(accountId) ||
        accountId.includes("..") ||
        path.isAbsolute(accountId) ||
        path.win32.isAbsolute(accountId)) {
        throw storageError("AUTH_CREDENTIAL_ACCOUNT_ID_INVALID", "Account id must be a canonical filename-safe identifier", { accountId: String(accountId).slice(0, 160) });
    }
}
function providerDir(provider, policy) {
    assertStoragePolicy(policy);
    if (fs.existsSync(policy.authRoot)) {
        assertRegularDirectory(policy.authRoot, "auth");
    }
    const dir = path.resolve(policy.authRoot, provider);
    assertContained(policy.authRoot, dir, "provider-directory");
    if (fs.existsSync(dir) && fs.lstatSync(dir).isSymbolicLink()) {
        throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", "Credential provider directory cannot be a symbolic link", { dir, provider });
    }
    return dir;
}
function accountFile(provider, accountId, policy) {
    assertCanonicalAccountId(accountId);
    const dir = providerDir(provider, policy);
    const file = path.resolve(dir, `${accountId}.json`);
    assertContained(dir, file, "account-file");
    return file;
}
function ensureProviderDir(provider, policy) {
    assertStoragePolicy(policy);
    fs.mkdirSync(policy.authRoot, { recursive: true, mode: 0o700 });
    assertContained(policy.stateRoot, policy.authRoot, "auth-directory");
    if (fs.lstatSync(policy.authRoot).isSymbolicLink()) {
        throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", "Credential auth directory cannot be a symbolic link", { authRoot: policy.authRoot });
    }
    const dir = providerDir(provider, policy);
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    assertContained(policy.authRoot, dir, "provider-directory");
    fsyncDirectory(policy.authRoot);
    return dir;
}
function writeAccountFile(provider, accountId, policy, value, resolveKey = () => masterKey(policy)) {
    const dir = providerDir(provider, policy);
    const file = accountFile(provider, accountId, policy);
    const temporaryFile = path.join(dir, `.${accountId}.${process.pid}.${randomUUID()}.tmp`);
    assertContained(dir, temporaryFile, "temporary-account-file");
    let descriptor;
    try {
        descriptor = fs.openSync(temporaryFile, fs.constants.O_WRONLY |
            fs.constants.O_CREAT |
            fs.constants.O_EXCL |
            fs.constants.O_NOFOLLOW, 0o600);
        const envelope = {
            schemaVersion: 2,
            ciphertext: encrypt(resolveKey(), JSON.stringify(value), accountAad(provider, accountId)),
        };
        fs.writeFileSync(descriptor, JSON.stringify(envelope, null, 2), "utf8");
        fs.fsyncSync(descriptor);
        fs.closeSync(descriptor);
        descriptor = undefined;
        assertStoragePolicy(policy);
        assertContained(dir, temporaryFile, "temporary-account-file");
        assertContained(dir, file, "account-file");
        fs.renameSync(temporaryFile, file);
        fsyncDirectory(dir);
    }
    finally {
        if (descriptor !== undefined)
            fs.closeSync(descriptor);
        if (fs.existsSync(temporaryFile)) {
            const stat = fs.lstatSync(temporaryFile);
            if (!stat.isSymbolicLink())
                fs.rmSync(temporaryFile, { force: true });
        }
    }
}
function statMatches(actual, expected) {
    return (actual.dev === expected.dev &&
        actual.ino === expected.ino &&
        actual.size === expected.size &&
        actual.mtimeMs === expected.mtimeMs);
}
function readRegularFileNoFollow(file, policy, operation) {
    let descriptor;
    try {
        descriptor = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
        const stat = fs.fstatSync(descriptor);
        if (!stat.isFile()) {
            throw storageError("AUTH_CREDENTIAL_TARGET_NOT_REGULAR_FILE", `Credential ${operation} target is not a regular file`, { file, operation });
        }
        assertStoragePolicy(policy);
        const pathStat = fs.lstatSync(file);
        if (pathStat.isSymbolicLink() ||
            pathStat.dev !== stat.dev ||
            pathStat.ino !== stat.ino) {
            throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", `Credential ${operation} target changed while it was opened`, { file, operation });
        }
        return { contents: fs.readFileSync(descriptor), stat };
    }
    catch (cause) {
        if (cause.code === "ELOOP") {
            throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", `Credential ${operation} target cannot be a symbolic link`, { file, operation }, cause);
        }
        throw cause;
    }
    finally {
        if (descriptor !== undefined)
            fs.closeSync(descriptor);
    }
}
function preflightAccountDeletionsUnlocked(accounts, policy) {
    assertStoragePolicy(policy);
    const targets = [];
    const seen = new Set();
    for (const { provider, accountId } of accounts) {
        const file = accountFile(provider, accountId, policy);
        if (seen.has(file))
            continue;
        seen.add(file);
        let descriptor;
        try {
            descriptor = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
            const stat = fs.fstatSync(descriptor);
            if (!stat.isFile()) {
                throw storageError("AUTH_CREDENTIAL_TARGET_NOT_REGULAR_FILE", "Credential deletion target is not a regular file", { accountId, file, provider });
            }
            targets.push({
                accountId,
                contents: fs.readFileSync(descriptor),
                file,
                mode: stat.mode & 0o777,
                provider,
                stat: {
                    dev: stat.dev,
                    ino: stat.ino,
                    mtimeMs: stat.mtimeMs,
                    size: stat.size,
                },
            });
        }
        catch (error) {
            if (error.code === "ENOENT") {
                targets.push({ accountId, file, provider });
                continue;
            }
            if (error.code === "ELOOP") {
                throw storageError("AUTH_CREDENTIAL_TARGET_NOT_REGULAR_FILE", "Credential deletion target cannot be a symbolic link", { accountId, file, provider }, error);
            }
            throw error;
        }
        finally {
            if (descriptor !== undefined)
                fs.closeSync(descriptor);
        }
    }
    return Object.freeze({
        policy,
        targets: Object.freeze(targets),
        [ACCOUNT_DELETION_PLAN]: true,
    });
}
function listProviderCredentialFilesUnlocked(providers, policy) {
    const files = [];
    for (const provider of providers) {
        const dir = providerDir(provider, policy);
        if (!fs.existsSync(dir))
            continue;
        assertRegularDirectory(dir, "provider");
        for (const entry of fs.readdirSync(dir)) {
            if (!entry.endsWith(".json"))
                continue;
            if (entry.endsWith(".tmp.json") || entry.endsWith(".json.tmp"))
                continue;
            const accountId = entry.slice(0, -".json".length);
            assertCanonicalAccountId(accountId);
            files.push(accountFile(provider, accountId, policy));
        }
    }
    return files.sort();
}
function preflightProviderAccountDeletionsUnlocked(providers, policy) {
    assertStoragePolicy(policy);
    const accounts = [];
    for (const provider of providers) {
        const dir = providerDir(provider, policy);
        if (!fs.existsSync(dir))
            continue;
        for (const entry of fs.readdirSync(dir)) {
            if (!entry.endsWith(".json"))
                continue;
            if (entry.endsWith(".tmp.json") || entry.endsWith(".json.tmp"))
                continue;
            const accountId = entry.slice(0, -".json".length);
            assertCanonicalAccountId(accountId);
            accounts.push({ provider, accountId });
        }
    }
    const plan = preflightAccountDeletionsUnlocked(accounts, policy);
    return Object.freeze({
        ...plan,
        providerInventory: Object.freeze([...providers]),
    });
}
function commitAccountDeletionsUnlocked(plan) {
    if (plan?.[ACCOUNT_DELETION_PLAN] !== true) {
        throw storageError("AUTH_CREDENTIAL_DELETE_PLAN_INVALID", "Credential deletion requires a preflighted plan", {});
    }
    assertStoragePolicy(plan.policy);
    if (plan.providerInventory) {
        const currentFiles = listProviderCredentialFilesUnlocked(plan.providerInventory, plan.policy);
        const plannedFiles = plan.targets
            .filter((target) => target.stat !== undefined)
            .map((target) => target.file)
            .sort();
        if (currentFiles.length !== plannedFiles.length ||
            currentFiles.some((file, index) => file !== plannedFiles[index])) {
            throw storageError("AUTH_CREDENTIAL_DELETE_INVENTORY_CHANGED", "Credential inventory changed after deletion preflight", { currentFiles, plannedFiles });
        }
    }
    const existingTargets = plan.targets.filter((target) => target.stat !== undefined &&
        target.contents !== undefined &&
        target.mode !== undefined);
    for (const target of existingTargets) {
        const currentFile = accountFile(target.provider, target.accountId, plan.policy);
        if (currentFile !== target.file) {
            throw storageError("AUTH_CREDENTIAL_DELETE_TARGET_CHANGED", "Credential deletion target changed after preflight", { currentFile, plannedFile: target.file });
        }
        const stat = fs.lstatSync(target.file);
        if (stat.isSymbolicLink() || !statMatches(stat, target.stat)) {
            throw storageError("AUTH_CREDENTIAL_DELETE_TARGET_CHANGED", "Credential deletion target changed after preflight", { accountId: target.accountId, file: target.file });
        }
    }
    const deleted = [];
    try {
        for (const target of existingTargets) {
            fs.unlinkSync(target.file);
            deleted.push(target);
        }
        for (const directory of new Set(existingTargets.map((target) => path.dirname(target.file)))) {
            fsyncDirectory(directory);
        }
    }
    catch (error) {
        const rollbackFailures = [];
        for (const target of deleted.reverse()) {
            try {
                const descriptor = fs.openSync(target.file, fs.constants.O_WRONLY |
                    fs.constants.O_CREAT |
                    fs.constants.O_EXCL |
                    fs.constants.O_NOFOLLOW, target.mode);
                try {
                    fs.writeFileSync(descriptor, target.contents);
                    fs.fsyncSync(descriptor);
                }
                finally {
                    fs.closeSync(descriptor);
                }
                fsyncDirectory(path.dirname(target.file));
            }
            catch (rollbackError) {
                rollbackFailures.push(`${target.file}: ${rollbackError instanceof Error ? rollbackError.message : String(rollbackError)}`);
            }
        }
        throw storageError("AUTH_CREDENTIAL_DELETE_TRANSACTION_FAILED", "Credential deletion failed and was rolled back", { deleted: deleted.length, rollbackFailures }, error);
    }
    return deleted.length;
}
export function preflightAccountDeletions(accounts, policy) {
    return withStorageLock(policy, "preflight-account-deletions", () => preflightAccountDeletionsUnlocked(accounts, policy));
}
export function preflightProviderAccountDeletions(providers, policy) {
    return withStorageLock(policy, "preflight-provider-deletions", () => preflightProviderAccountDeletionsUnlocked(providers, policy));
}
export function commitAccountDeletions(plan) {
    if (plan?.[ACCOUNT_DELETION_PLAN] !== true) {
        throw storageError("AUTH_CREDENTIAL_DELETE_PLAN_INVALID", "Credential deletion requires a preflighted plan", {});
    }
    return withStorageLock(plan.policy, "commit-account-deletions", () => commitAccountDeletionsUnlocked(plan));
}
function isAccountCredentialRecord(value) {
    if (!value || typeof value !== "object")
        return false;
    const v = value;
    const credentials = v.credentials && typeof v.credentials === "object"
        ? v.credentials
        : null;
    const finiteTimestamp = (candidate) => typeof candidate === "number" &&
        Number.isFinite(candidate) &&
        candidate >= 0;
    const optionalString = (candidate) => candidate === undefined || typeof candidate === "string";
    return (typeof v.id === "string" &&
        typeof v.providerId === "string" &&
        ACCOUNT_CREDENTIAL_PROVIDER_IDS.includes(v.providerId) &&
        typeof v.label === "string" &&
        v.label.length > 0 &&
        (v.source === "oauth" || v.source === "api-key") &&
        credentials !== null &&
        typeof credentials.access === "string" &&
        credentials.access.length > 0 &&
        typeof credentials.refresh === "string" &&
        finiteTimestamp(credentials.expires) &&
        optionalString(credentials.idToken) &&
        (v.credentialGeneration === undefined ||
            (typeof v.credentialGeneration === "string" &&
                /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u.test(v.credentialGeneration))) &&
        finiteTimestamp(v.createdAt) &&
        finiteTimestamp(v.updatedAt) &&
        (v.lastUsedAt === undefined || finiteTimestamp(v.lastUsedAt)) &&
        optionalString(v.organizationId) &&
        optionalString(v.userId) &&
        optionalString(v.email));
}
/**
 * Decode raw account-file bytes into a validated record. Envelope files are
 * decrypted with the policy-scoped master key and a per-provider/account AAD
 * so a ciphertext cannot be replayed under a different identity; legacy
 * plaintext files and authenticated schema-v2 compatibility envelopes are
 * flagged for canonical re-encryption. Any decrypt or schema failure throws —
 * a credential that cannot be proven intact is never returned.
 */
function decodeAccountRecord(contents, file, provider, policy, resolveKey = () => masterKey(policy)) {
    let parsed;
    try {
        parsed = JSON.parse(contents.toString("utf8"));
    }
    catch (cause) {
        throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential record contains malformed JSON", { file }, cause);
    }
    if (!isEnvelope(parsed)) {
        return {
            record: parseAccountCredentialRecord(parsed, file),
            requiresRewrite: true,
        };
    }
    let decrypted;
    let requiresRewrite = false;
    try {
        const key = resolveKey();
        const accountId = path.basename(file, ".json");
        let plaintext;
        try {
            plaintext = decrypt(key, parsed.ciphertext, accountAad(provider, accountId));
        }
        catch (cause) {
            // error-policy:J3 schema-v2 compatibility accepts only authenticated bytes under the intervening namespace.
            if (!(cause instanceof CryptoError))
                throw cause;
            plaintext = decrypt(key, parsed.ciphertext, `@elizaos/credentials/auth/account/${provider}/${accountId}`);
            requiresRewrite = true;
        }
        decrypted = JSON.parse(plaintext);
    }
    catch (cause) {
        // error-policy:J2 both authenticated formats must fail closed with the decoding cause preserved.
        throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential envelope failed authenticated decryption", { file, provider }, cause);
    }
    return {
        record: parseAccountCredentialRecord(decrypted, file),
        requiresRewrite,
    };
}
function parseAccountCredentialRecord(parsed, file) {
    if (!isAccountCredentialRecord(parsed)) {
        throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential record does not match the complete persisted schema", { file });
    }
    try {
        assertCanonicalAccountId(parsed.id);
    }
    catch (cause) {
        throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential record contains a non-canonical account id", { file }, cause);
    }
    return parsed;
}
function listAccountsUnlocked(provider, policy) {
    assertStoragePolicy(policy);
    const dir = providerDir(provider, policy);
    if (!fs.existsSync(dir))
        return [];
    assertContained(policy.authRoot, dir, "list-provider-directory");
    assertRegularDirectory(dir, "list-provider");
    // One key resolution per locked read; the next operation observes key changes.
    let key;
    const resolveKey = () => (key ??= masterKey(policy));
    const entries = fs.readdirSync(dir);
    const records = [];
    for (const entry of entries) {
        if (!entry.endsWith(".json"))
            continue;
        if (entry.endsWith(".tmp.json") || entry.endsWith(".json.tmp"))
            continue;
        const filePath = path.join(dir, entry);
        assertContained(dir, filePath, "list-account-file");
        const { contents } = readRegularFileNoFollow(filePath, policy, "list-account");
        const { record: parsed, requiresRewrite } = decodeAccountRecord(contents, filePath, provider, policy, resolveKey);
        if (parsed.providerId !== provider) {
            throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential record provider does not match its directory", {
                actualProvider: parsed.providerId,
                expectedProvider: provider,
                filePath,
            });
        }
        if (`${parsed.id}.json` !== entry) {
            throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential record id does not match its filename", { accountId: parsed.id, entry, filePath });
        }
        records.push(ensureCredentialGeneration(parsed, requiresRewrite, policy, resolveKey));
    }
    records.sort((a, b) => {
        const aTime = Number.isFinite(a.createdAt) ? a.createdAt : 0;
        const bTime = Number.isFinite(b.createdAt) ? b.createdAt : 0;
        return aTime - bTime;
    });
    return records;
}
function loadAccountUnlocked(provider, accountId, policy) {
    assertStoragePolicy(policy);
    const file = accountFile(provider, accountId, policy);
    let contents;
    try {
        contents = readRegularFileNoFollow(file, policy, "load-account").contents;
    }
    catch (cause) {
        if (cause.code === "ENOENT")
            return null;
        throw cause;
    }
    const { record: parsed, requiresRewrite } = decodeAccountRecord(contents, file, provider, policy);
    if (parsed.providerId !== provider || parsed.id !== accountId) {
        throw storageError("AUTH_CREDENTIAL_RECORD_CORRUPT", "Credential record provider or account id does not match its path", {
            accountId,
            actualAccountId: parsed.id,
            actualProvider: parsed.providerId,
            file,
            provider,
        });
    }
    return ensureCredentialGeneration(parsed, requiresRewrite, policy);
}
/** Persists legacy encryption and missing replacement identity atomically inside the storage lock. */
function ensureCredentialGeneration(record, requiresRewrite, policy, resolveKey = () => masterKey(policy)) {
    const next = {
        ...record,
        credentialGeneration: record.credentialGeneration ?? randomUUID(),
    };
    if (requiresRewrite || record.credentialGeneration === undefined) {
        writeAccountFile(next.providerId, next.id, policy, next, resolveKey);
        logger.info(`[auth] Migrated ${next.providerId} account "${next.id}" storage`);
    }
    return next;
}
export function listAccounts(provider, policy = defaultReadPolicy()) {
    return withStorageLock(policy, "list-accounts", () => listAccountsUnlocked(provider, policy));
}
export function loadAccount(provider, accountId, policy = defaultReadPolicy()) {
    assertCanonicalAccountId(accountId);
    return withStorageLock(policy, "load-account", () => loadAccountUnlocked(provider, accountId, policy));
}
function collectResetDirectory(directory, policy, files, directories) {
    assertContained(policy.authRoot, directory, "reset-directory");
    assertRegularDirectory(directory, "reset");
    directories.push(directory);
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
        const target = path.join(directory, entry.name);
        assertContained(directory, target, "reset-artifact");
        if (entry.isSymbolicLink()) {
            throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", "Credential reset inventory cannot contain symbolic links", { target });
        }
        if (entry.isDirectory()) {
            collectResetDirectory(target, policy, files, directories);
            continue;
        }
        if (!entry.isFile()) {
            throw storageError("AUTH_CREDENTIAL_TARGET_NOT_REGULAR_FILE", "Credential reset inventory contains a non-regular artifact", { target });
        }
        const { contents, stat } = readRegularFileNoFollow(target, policy, "reset-preflight");
        files.push({
            contents,
            file: target,
            mode: stat.mode & 0o777,
            stat: {
                dev: stat.dev,
                ino: stat.ino,
                mtimeMs: stat.mtimeMs,
                size: stat.size,
            },
        });
    }
}
function preflightCredentialResetUnlocked(policy) {
    assertStoragePolicy(policy);
    if (!fs.existsSync(policy.authRoot)) {
        return Object.freeze({
            directories: Object.freeze([]),
            files: Object.freeze([]),
        });
    }
    assertRegularDirectory(policy.authRoot, "auth");
    const files = [];
    const directories = [];
    for (const entry of fs.readdirSync(policy.authRoot, {
        withFileTypes: true,
    })) {
        if (entry.name === STORAGE_LOCK_DIRECTORY ||
            entry.name === STORAGE_GENERATION_FILE) {
            continue;
        }
        const target = path.join(policy.authRoot, entry.name);
        assertContained(policy.authRoot, target, "reset-root-artifact");
        const credentialDirectory = entry.isDirectory() &&
            (entry.name === "_codex-home" ||
                (!entry.name.startsWith(".") && !entry.name.startsWith("_")));
        if (credentialDirectory) {
            collectResetDirectory(target, policy, files, directories);
            continue;
        }
        if (entry.name === "_codex-home" ||
            (!entry.name.startsWith(".") &&
                !entry.name.startsWith("_") &&
                entry.isSymbolicLink())) {
            throw storageError("AUTH_CREDENTIAL_PATH_ESCAPE", "Credential reset root artifact cannot be a symbolic link", { target });
        }
        if (entry.name === "_pool-metadata.json" ||
            entry.name.startsWith("_pool-metadata.json.")) {
            if (entry.isSymbolicLink() || !entry.isFile()) {
                throw storageError("AUTH_CREDENTIAL_TARGET_NOT_REGULAR_FILE", "Account-pool metadata reset target must be a regular file", { target });
            }
            const { contents, stat } = readRegularFileNoFollow(target, policy, "reset-pool-metadata");
            files.push({
                contents,
                file: target,
                mode: stat.mode & 0o777,
                stat: {
                    dev: stat.dev,
                    ino: stat.ino,
                    mtimeMs: stat.mtimeMs,
                    size: stat.size,
                },
            });
        }
    }
    return Object.freeze({
        directories: Object.freeze(directories.sort()),
        files: Object.freeze(files.sort((a, b) => a.file.localeCompare(b.file))),
    });
}
function sameResetInventory(left, right) {
    return (left.directories.length === right.directories.length &&
        left.directories.every((directory, index) => directory === right.directories[index]) &&
        left.files.length === right.files.length &&
        left.files.every((file, index) => file.file === right.files[index]?.file));
}
function verifyResetPlanUnlocked(plan, policy) {
    const current = preflightCredentialResetUnlocked(policy);
    if (!sameResetInventory(plan, current)) {
        throw storageError("AUTH_CREDENTIAL_RESET_INVENTORY_CHANGED", "Credential artifact inventory changed after reset preflight", {
            currentDirectories: current.directories,
            currentFiles: current.files.map((entry) => entry.file),
            plannedDirectories: plan.directories,
            plannedFiles: plan.files.map((entry) => entry.file),
        });
    }
    for (const [index, planned] of plan.files.entries()) {
        const actual = current.files[index];
        if (!actual || !statMatches(actual.stat, planned.stat)) {
            throw storageError("AUTH_CREDENTIAL_RESET_TARGET_CHANGED", "Credential artifact changed after reset preflight", { file: planned.file });
        }
    }
}
function restoreResetPlanUnlocked(plan) {
    const failures = [];
    for (const directory of [...plan.directories].sort((a, b) => a.length - b.length)) {
        try {
            fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
        }
        catch (cause) {
            failures.push(`${directory}: ${String(cause)}`);
        }
    }
    for (const artifact of plan.files) {
        try {
            fs.mkdirSync(path.dirname(artifact.file), {
                recursive: true,
                mode: 0o700,
            });
            const descriptor = fs.openSync(artifact.file, fs.constants.O_WRONLY |
                fs.constants.O_CREAT |
                fs.constants.O_EXCL |
                fs.constants.O_NOFOLLOW, artifact.mode);
            try {
                fs.writeFileSync(descriptor, artifact.contents);
                fs.fsyncSync(descriptor);
            }
            finally {
                fs.closeSync(descriptor);
            }
            fsyncDirectory(path.dirname(artifact.file));
        }
        catch (cause) {
            failures.push(`${artifact.file}: ${String(cause)}`);
        }
    }
    return failures;
}
function deleteResetPlanUnlocked(plan, policy) {
    verifyResetPlanUnlocked(plan, policy);
    const deletedFiles = [];
    const removedDirectories = [];
    try {
        for (const artifact of plan.files) {
            fs.unlinkSync(artifact.file);
            deletedFiles.push(artifact);
        }
        for (const directory of [...plan.directories].sort((a, b) => b.length - a.length)) {
            fs.rmdirSync(directory);
            removedDirectories.push(directory);
        }
        fsyncDirectory(policy.authRoot);
    }
    catch (cause) {
        const rollbackFailures = restoreResetPlanUnlocked({
            directories: removedDirectories,
            files: deletedFiles,
        });
        throw storageError("AUTH_CREDENTIAL_RESET_DELETE_FAILED", "Credential reset deletion failed and was rolled back", { rollbackFailures }, cause);
    }
}
function writeStorageGenerationUnlocked(policy, generation) {
    const generationFile = path.join(policy.authRoot, STORAGE_GENERATION_FILE);
    const temporaryFile = `${generationFile}.${process.pid}.${randomUUID()}.tmp`;
    assertContained(policy.authRoot, generationFile, "generation-file");
    assertContained(policy.authRoot, temporaryFile, "temporary-generation-file");
    let descriptor;
    try {
        descriptor = fs.openSync(temporaryFile, fs.constants.O_WRONLY |
            fs.constants.O_CREAT |
            fs.constants.O_EXCL |
            fs.constants.O_NOFOLLOW, 0o600);
        fs.writeFileSync(descriptor, `${generation}\n`, "utf8");
        fs.fsyncSync(descriptor);
        fs.closeSync(descriptor);
        descriptor = undefined;
        fs.renameSync(temporaryFile, generationFile);
        fsyncDirectory(policy.authRoot);
    }
    finally {
        if (descriptor !== undefined)
            fs.closeSync(descriptor);
        if (fs.existsSync(temporaryFile))
            fs.rmSync(temporaryFile, { force: true });
    }
}
export function withAccountStorageMutation(policy, operation, callback) {
    return withStorageLock(policy, operation, () => callback({
        loadAccount: (provider, accountId) => {
            assertCanonicalAccountId(accountId);
            return loadAccountUnlocked(provider, accountId, policy);
        },
        saveAccount: (record) => saveAccountUnlocked(record, policy),
    }));
}
/**
 * Deletes every credential-bearing artifact as one fenced transaction, runs
 * the caller's config/environment mutation under the same cross-process lock,
 * and advances the generation before admitting any waiting writer.
 */
export function resetAccountCredentialStorage(policy, mutateResetState) {
    return withStorageLock(policy, "reset-account-credential-storage", () => {
        const plan = preflightCredentialResetUnlocked(policy);
        deleteResetPlanUnlocked(plan, policy);
        try {
            mutateResetState();
            const currentGeneration = policy[ACCOUNT_STORAGE_ROOT_IDENTITY].generation;
            writeStorageGenerationUnlocked(policy, currentGeneration + 1);
        }
        catch (cause) {
            const rollbackFailures = restoreResetPlanUnlocked(plan);
            throw storageError("AUTH_CREDENTIAL_RESET_TRANSACTION_FAILED", "Credential reset failed and credential artifacts were rolled back", { rollbackFailures }, cause);
        }
        return plan.files.length;
    });
}
function saveAccountUnlocked(record, policy) {
    assertStoragePolicy(policy);
    assertCanonicalAccountId(record.id);
    const persistedRecord = record;
    if (!isAccountCredentialRecord(persistedRecord)) {
        throw storageError("AUTH_CREDENTIAL_RECORD_INVALID", "Credential mutation requires a complete persisted record", { accountId: record.id, provider: record.providerId });
    }
    ensureProviderDir(record.providerId, policy);
    const next = {
        ...record,
        credentialGeneration: randomUUID(),
        updatedAt: Date.now(),
    };
    writeAccountFile(record.providerId, record.id, policy, next);
    logger.info(`[auth] Saved ${record.providerId} account "${record.id}" (label="${record.label}")`);
    return next;
}
export function saveAccount(record, policy) {
    assertCanonicalAccountId(record.id);
    return withStorageLock(policy, "save-account", () => saveAccountUnlocked(record, policy));
}
/** Updates current metadata under the storage lock without replacing credentials or recreating deleted accounts. */
export function updateAccountMetadata(provider, accountId, metadata, policy, expectedGeneration) {
    assertCanonicalAccountId(accountId);
    return withStorageLock(policy, "update-account-metadata", () => {
        const existing = loadAccountUnlocked(provider, accountId, policy);
        if (!existing)
            return { kind: "missing" };
        if (expectedGeneration !== undefined &&
            existing.credentialGeneration !== expectedGeneration) {
            return { kind: "changed", record: existing };
        }
        const next = {
            ...existing,
            ...(metadata.label !== undefined ? { label: metadata.label } : {}),
            ...(metadata.email !== undefined ? { email: metadata.email } : {}),
            ...(metadata.organizationId !== undefined
                ? { organizationId: metadata.organizationId }
                : {}),
            ...(metadata.userId !== undefined ? { userId: metadata.userId } : {}),
            updatedAt: Date.now(),
        };
        if (!isAccountCredentialRecord(next)) {
            throw storageError("AUTH_ACCOUNT_METADATA_INVALID", "Account metadata must contain valid identity fields", { accountId, provider });
        }
        writeAccountFile(provider, accountId, policy, next);
        return { kind: "updated", record: next };
    });
}
export function deleteAccount(provider, accountId, policy) {
    assertCanonicalAccountId(accountId);
    withStorageLock(policy, "delete-account", () => {
        const plan = preflightAccountDeletionsUnlocked([{ provider, accountId }], policy);
        if (commitAccountDeletionsUnlocked(plan) > 0) {
            logger.info(`[auth] Deleted ${provider} account "${accountId}"`);
        }
    });
}
/**
 * Keeps the stored OIDC id_token when a token grant re-issues access and
 * refresh tokens without one. Codex's chatgpt-mode auth loader requires
 * `tokens.id_token` to be present (a stale one is tolerated, a missing one
 * fails "Authentication required"), and OAuth refresh grants normally omit it.
 */
export function carryForwardIdToken(existing, incoming) {
    return incoming.idToken === undefined && existing.idToken
        ? { ...incoming, idToken: existing.idToken }
        : incoming;
}
/**
 * Replaces an existing account's credentials only if the record still exists
 * and still holds `expectedGeneration`. This is the only commit path for a token
 * refresh: it never creates a record, so a refresh that resolves after the
 * account was removed cannot resurrect it, and it never overwrites credentials
 * written by a newer login or adoption, even if refresh tokens are unchanged.
 * Record metadata (label, source, identity, timestamps other than
 * `updatedAt`) is preserved and the id_token is carried forward.
 */
export function updateAccountCredentialsIfUnchanged(provider, accountId, expectedGeneration, credentials, policy) {
    assertCanonicalAccountId(accountId);
    if (typeof expectedGeneration !== "string" ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u.test(expectedGeneration)) {
        throw storageError("AUTH_CREDENTIAL_UPDATE_EXPECTATION_INVALID", "A conditional credential update needs the storage generation it started from", { accountId, provider });
    }
    return withStorageLock(policy, "update-account-credentials", () => {
        const existing = loadAccountUnlocked(provider, accountId, policy);
        if (!existing)
            return { kind: "missing" };
        if (existing.credentialGeneration !== expectedGeneration) {
            return { kind: "changed", record: existing };
        }
        const next = {
            ...existing,
            credentials: carryForwardIdToken(existing.credentials, credentials),
            credentialGeneration: randomUUID(),
            updatedAt: Date.now(),
        };
        writeAccountFile(provider, accountId, policy, next);
        logger.info(`[auth] Updated ${provider} account "${accountId}" credentials after refresh`);
        return { kind: "updated", record: next };
    });
}
export function touchAccount(provider, accountId, policy) {
    assertCanonicalAccountId(accountId);
    withStorageLock(policy, "touch-account", () => {
        const existing = loadAccountUnlocked(provider, accountId, policy);
        if (!existing)
            return;
        const next = {
            ...existing,
            lastUsedAt: Date.now(),
        };
        writeAccountFile(provider, accountId, policy, next);
    });
}
//# sourceMappingURL=account-storage.js.map