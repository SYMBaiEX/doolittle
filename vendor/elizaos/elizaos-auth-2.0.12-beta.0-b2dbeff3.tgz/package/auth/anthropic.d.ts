/**
 * Anthropic OAuth flow (Claude Pro/Max subscription)
 *
 * Uses inlined PKCE + token exchange (vendored OAuth helpers).
 * The callback API is adapted to a start/exchange pattern for HTTP route handlers.
 */
import type { OAuthCredentials } from "./types.js";
import { exchangeAnthropicAuthorizationCode } from "./vendor/pi-oauth/anthropic-login.js";
export { exchangeAnthropicAuthorizationCode };
export interface AnthropicFlow {
    authUrl: string;
    /** Provide the authorization code (format: code#state) to complete the flow */
    submitCode: (code: string) => void;
    /** Resolves with credentials once submitCode() is called */
    credentials: Promise<OAuthCredentials>;
}
/**
 * Start the Anthropic OAuth flow.
 * Returns an auth URL and a way to submit the code + get credentials.
 */
export declare function startAnthropicLogin(): Promise<AnthropicFlow>;
/**
 * Refresh an expired Anthropic token.
 */
export declare function refreshAnthropicToken(refreshToken: string): Promise<OAuthCredentials>;
//# sourceMappingURL=anthropic.d.ts.map