/**
 * Per-account credential storage.
 *
 * Layout: `<stateDir>/auth/{providerId}/{accountId}.json` (mode 0600,
 * atomic writes). Multiple accounts per provider are supported. Every mutator
 * requires a branded root/owner policy; isolated policies are physically
 * confined to the OS temporary directory and no operation may cross its
 * canonical provider directory. Records persist as versioned AES-GCM
 * envelopes encrypted with the vault master key; legacy plaintext records
 * are validated and re-encrypted atomically on first read.
 */
import fs from "node:fs";
import { type AccountCredentialProvider, type OAuthCredentials } from "./types.js";
export interface AccountCredentialRecord {
    /** accountId, e.g. "default" or a uuid */
    id: string;
    providerId: AccountCredentialProvider;
    /** user-facing name (e.g. "Personal", "Work") */
    label: string;
    source: "oauth" | "api-key";
    /**
     * Existing OAuth credential blob — `{ access, refresh, expires }`
     * for OAuth accounts; for `api-key` accounts only `access` is
     * meaningful (refresh is the empty string and expires is `0` /
     * a distant-expiry sentinel by convention of the caller).
     */
    credentials: OAuthCredentials;
    /** Storage-owned replacement identity; absent only on legacy records and write inputs. */
    credentialGeneration?: string;
    createdAt: number;
    updatedAt: number;
    lastUsedAt?: number;
    organizationId?: string;
    userId?: string;
    email?: string;
}
/** A loaded record has a persisted generation assigned under the storage lock. */
export type LoadedAccountCredentialRecord = AccountCredentialRecord & {
    credentialGeneration: string;
};
export type AccountStorageOwner = "runtime" | "isolated-test";
declare const ACCOUNT_STORAGE_POLICY: unique symbol;
declare const ACCOUNT_STORAGE_ROOT_IDENTITY: unique symbol;
interface AccountStorageRootIdentity {
    dev: number;
    generation: number;
    ino: number;
}
export interface AccountStoragePolicy {
    readonly stateRoot: string;
    readonly authRoot: string;
    readonly owner: AccountStorageOwner;
    readonly [ACCOUNT_STORAGE_POLICY]: true;
    readonly [ACCOUNT_STORAGE_ROOT_IDENTITY]: AccountStorageRootIdentity;
}
interface PlannedAccountDeletion {
    accountId: string;
    contents?: Buffer;
    file: string;
    mode?: number;
    provider: AccountCredentialProvider;
    stat?: Pick<fs.Stats, "dev" | "ino" | "mtimeMs" | "size">;
}
declare const ACCOUNT_DELETION_PLAN: unique symbol;
export interface AccountDeletionPlan {
    readonly policy: AccountStoragePolicy;
    readonly targets: readonly PlannedAccountDeletion[];
    readonly providerInventory?: readonly AccountCredentialProvider[];
    readonly [ACCOUNT_DELETION_PLAN]: true;
}
export declare function createRuntimeAccountStoragePolicy(stateRoot: string): AccountStoragePolicy;
export declare function createIsolatedAccountStoragePolicy(stateRoot: string): AccountStoragePolicy;
export declare function assertCanonicalAccountId(accountId: string): void;
export declare function preflightAccountDeletions(accounts: readonly {
    provider: AccountCredentialProvider;
    accountId: string;
}[], policy: AccountStoragePolicy): AccountDeletionPlan;
export declare function preflightProviderAccountDeletions(providers: readonly AccountCredentialProvider[], policy: AccountStoragePolicy): AccountDeletionPlan;
export declare function commitAccountDeletions(plan: AccountDeletionPlan): number;
export declare function listAccounts(provider: AccountCredentialProvider, policy?: AccountStoragePolicy): AccountCredentialRecord[];
export declare function loadAccount(provider: AccountCredentialProvider, accountId: string, policy?: AccountStoragePolicy): LoadedAccountCredentialRecord | null;
/**
 * Serializes a non-account credential artifact mutation with account writes
 * and reset. The callback must stay inside `policy.authRoot` and must not call
 * another account-storage operation while the lock is held.
 */
export interface AccountStorageMutationScope {
    loadAccount(provider: AccountCredentialProvider, accountId: string): AccountCredentialRecord | null;
    saveAccount(record: AccountCredentialRecord): void;
}
export declare function withAccountStorageMutation<T>(policy: AccountStoragePolicy, operation: string, callback: (scope: AccountStorageMutationScope) => T): T;
/**
 * Deletes every credential-bearing artifact as one fenced transaction, runs
 * the caller's config/environment mutation under the same cross-process lock,
 * and advances the generation before admitting any waiting writer.
 */
export declare function resetAccountCredentialStorage(policy: AccountStoragePolicy, mutateResetState: () => void): number;
export declare function saveAccount(record: AccountCredentialRecord, policy: AccountStoragePolicy): LoadedAccountCredentialRecord;
/** Editable account identity fields; credentials and their generation are storage-owned. */
export type AccountMetadataUpdate = Partial<Pick<AccountCredentialRecord, "label" | "email" | "organizationId" | "userId">>;
/** Updates current metadata under the storage lock without replacing credentials or recreating deleted accounts. */
export declare function updateAccountMetadata(provider: AccountCredentialProvider, accountId: string, metadata: AccountMetadataUpdate, policy: AccountStoragePolicy, expectedGeneration?: string): AccountCredentialUpdateOutcome;
export declare function deleteAccount(provider: AccountCredentialProvider, accountId: string, policy: AccountStoragePolicy): void;
/**
 * Result of a compare-and-swap credential update. `missing` means no record
 * exists for the account any more (it was deleted after the caller read it);
 * `changed` means a record exists but its storage-owned generation is no longer
 * the one the caller started from (another writer replaced the record, even
 * when credential values are identical) and carries that current record so the caller can act on it.
 */
export type AccountCredentialUpdateOutcome = {
    kind: "updated";
    record: AccountCredentialRecord;
} | {
    kind: "missing";
} | {
    kind: "changed";
    record: AccountCredentialRecord;
};
/**
 * Keeps the stored OIDC id_token when a token grant re-issues access and
 * refresh tokens without one. Codex's chatgpt-mode auth loader requires
 * `tokens.id_token` to be present (a stale one is tolerated, a missing one
 * fails "Authentication required"), and OAuth refresh grants normally omit it.
 */
export declare function carryForwardIdToken(existing: OAuthCredentials, incoming: OAuthCredentials): OAuthCredentials;
/**
 * Replaces an existing account's credentials only if the record still exists
 * and still holds `expectedGeneration`. This is the only commit path for a token
 * refresh: it never creates a record, so a refresh that resolves after the
 * account was removed cannot resurrect it, and it never overwrites credentials
 * written by a newer login or adoption, even if refresh tokens are unchanged.
 * Record metadata (label, source, identity, timestamps other than
 * `updatedAt`) is preserved and the id_token is carried forward.
 */
export declare function updateAccountCredentialsIfUnchanged(provider: AccountCredentialProvider, accountId: string, expectedGeneration: string, credentials: OAuthCredentials, policy: AccountStoragePolicy): AccountCredentialUpdateOutcome;
export declare function touchAccount(provider: AccountCredentialProvider, accountId: string, policy: AccountStoragePolicy): void;
export {};
//# sourceMappingURL=account-storage.d.ts.map