/**
 * OAuth flow orchestration registry.
 *
 * Wraps the provider-specific programmatic OAuth helpers
 * (`startAnthropicOAuthFlowRaw` from
 * `vendor/pi-oauth/anthropic-login.ts` and the loopback-listener flow
 * in `openai-codex.ts`) with:
 *
 *   - a 15-minute timeout per flow,
 *   - automatic `saveAccount(...)` after token exchange,
 *   - an in-memory registry keyed by `sessionId` so the HTTP API can
 *     stream progress over SSE and the CLI can `await` completion,
 *   - garbage collection 10 minutes after a flow reaches a terminal
 *     state.
 *
 * Both the CLI and the new accounts-routes HTTP endpoints drive flows
 * through this module — there is no direct caller of the vendor-level
 * OAuth helpers anymore.
 */
import crypto from "node:crypto";
import { logger } from "@elizaos/core";
import { ElizaError } from "@elizaos/core/protocol";
import { listAccounts, loadAccount, saveAccount, } from "./account-storage.js";
import { startCodexDeviceLogin } from "./codex-device.js";
import { startCodexLogin } from "./openai-codex.js";
import { startAnthropicOAuthFlowRaw, } from "./vendor/pi-oauth/anthropic-login.js";
// Browser subscription login can include MFA, account selection, and consent.
// Five minutes routinely expired before a remote user could copy the loopback
// callback URL back into Eliza, destroying the PKCE verifier. Keep the verifier
// in memory long enough for a normal interactive login while retaining a hard
// upper bound and terminal-state cleanup.
const FLOW_TIMEOUT_MS = 15 * 60 * 1000;
const FLOW_GC_MS = 10 * 60 * 1000;
const flows = new Map();
function newSessionId() {
    return crypto.randomUUID();
}
function emit(entry) {
    for (const listener of entry.listeners) {
        listener(entry.state);
    }
}
function scheduleGc(sessionId) {
    const entry = flows.get(sessionId);
    if (!entry)
        return;
    if (entry.gcTimer)
        clearTimeout(entry.gcTimer);
    entry.gcTimer = setTimeout(() => {
        flows.delete(sessionId);
    }, FLOW_GC_MS);
}
function resolveAccountId(opts) {
    return opts.accountId?.trim() || crypto.randomUUID();
}
function normalizeIdentity(value) {
    const normalized = value?.trim().toLowerCase();
    return normalized || undefined;
}
function assertReplacementIdentity(existing, incoming) {
    const comparisons = [
        ["organization", existing.organizationId, incoming.organizationId],
        ["user", existing.userId, incoming.providerAccountId],
        [
            "email",
            normalizeIdentity(existing.email),
            normalizeIdentity(incoming.email),
        ],
    ];
    for (const [field, expected, actual] of comparisons) {
        if (!expected)
            continue;
        if (!actual || expected !== actual) {
            throw new ElizaError(`OAuth replacement ${field} identity does not match`, {
                code: "oauth_flow.replacement_identity_mismatch",
                severity: "fatal",
                context: { field },
            });
        }
    }
}
/** Build the canonical account record without mutating credential storage. */
function buildAccountRecord(args) {
    const now = Date.now();
    const normalizedEmail = normalizeIdentity(args.email);
    const replacement = args.replaceAccountId
        ? loadAccount(args.providerId, args.replaceAccountId, args.storagePolicy)
        : null;
    if (args.replaceAccountId && !replacement) {
        throw new ElizaError("OAuth replacement account no longer exists", {
            code: "oauth_flow.replacement_target_missing",
            severity: "fatal",
            context: {
                providerId: args.providerId,
                accountId: args.replaceAccountId,
            },
        });
    }
    if (replacement) {
        assertReplacementIdentity(replacement, {
            organizationId: args.organizationId,
            providerAccountId: args.providerAccountId,
            email: args.email,
        });
    }
    const deduplicated = replacement
        ? null
        : listAccounts(args.providerId, args.storagePolicy).find((account) => {
            if (args.organizationId &&
                account.organizationId === args.organizationId) {
                return true;
            }
            return Boolean(normalizedEmail &&
                normalizeIdentity(account.email) === normalizedEmail);
        });
    const existing = replacement ?? deduplicated;
    const record = {
        id: existing?.id ?? args.accountId,
        providerId: args.providerId,
        label: replacement?.label ?? args.email ?? args.label,
        source: "oauth",
        credentials: {
            access: args.access,
            refresh: args.refresh,
            expires: args.expires,
            ...(args.idToken ? { idToken: args.idToken } : {}),
        },
        createdAt: existing?.createdAt ?? now,
        updatedAt: now,
        ...(existing?.lastUsedAt ? { lastUsedAt: existing.lastUsedAt } : {}),
        ...(args.providerAccountId
            ? { userId: args.providerAccountId }
            : existing?.userId
                ? { userId: existing.userId }
                : {}),
        ...(args.organizationId ? { organizationId: args.organizationId } : {}),
        ...(args.email ? { email: args.email } : {}),
    };
    return { record, ...(replacement ? { previous: replacement } : {}) };
}
// Anthropic.
/**
 * Start a programmatic Anthropic OAuth flow. Anthropic's redirect URI
 * is hardcoded to `console.anthropic.com/oauth/code/callback` — the
 * UI must surface the auth URL, prompt the user to copy the
 * `code#state` blob, and call `submitCode()` with it. Once the code is
 * submitted, the token exchange runs and the account is persisted.
 */
export function startAnthropicOAuthFlow(opts) {
    return startGenericFlow({
        providerId: "anthropic-subscription",
        opts,
        needsCodeSubmission: true,
        begin: async () => {
            const raw = await startAnthropicOAuthFlowRaw();
            const completion = (async () => {
                const creds = await raw.completion;
                return { creds };
            })();
            return {
                authUrl: raw.authUrl,
                completion,
                submitCode: raw.submitCode,
                cancel: raw.cancel,
            };
        },
    });
}
// Codex (OpenAI ChatGPT subscription).
/**
 * Start a programmatic Codex OAuth flow. Native/local clients can use the
 * loopback listener on :1455. Remote web clients must paste the localhost
 * callback URL because that URL resolves in the browser's device, not on the
 * remote Eliza host. The accountId
 * baked into the JWT is preserved on `LinkedAccountConfig.organizationId`
 * (used by the Codex usage probe via the `ChatGPT-Account-Id` header).
 */
export function startCodexOAuthFlow(opts) {
    if (opts.headless) {
        return startGenericFlow({
            providerId: "openai-codex",
            opts,
            needsCodeSubmission: false,
            begin: async () => {
                const flow = await startCodexDeviceLogin();
                return {
                    authUrl: flow.authUrl,
                    userCode: flow.userCode,
                    completion: flow.credentials.then((creds) => ({ creds })),
                    submitCode: () => undefined,
                    cancel: () => flow.close(),
                };
            },
        });
    }
    return startGenericFlow({
        providerId: "openai-codex",
        opts,
        needsCodeSubmission: true,
        begin: async () => {
            const flow = await startCodexLogin();
            const completion = (async () => {
                const creds = await flow.credentials;
                return { creds, codexFlow: flow };
            })();
            return {
                authUrl: flow.authUrl,
                completion,
                submitCode: (code) => flow.submitCode(code),
                cancel: () => flow.close(),
            };
        },
    });
}
async function startGenericFlow(args) {
    const { providerId, opts, needsCodeSubmission, begin } = args;
    const sessionId = newSessionId();
    const accountId = resolveAccountId(opts);
    const vendor = await begin();
    const startedAt = Date.now();
    const initialState = {
        sessionId,
        providerId,
        status: "pending",
        authUrl: vendor.authUrl,
        needsCodeSubmission,
        ...(opts.replaceAccountId
            ? { replaceAccountId: opts.replaceAccountId }
            : {}),
        startedAt,
    };
    let resolveCompletion;
    let rejectCompletion;
    const completion = new Promise((resolve, reject) => {
        resolveCompletion = resolve;
        rejectCompletion = reject;
    });
    // HTTP/SSE callers observe terminal state through the registry and may never
    // await this in-process promise. Attach a rejection observer so timeout or
    // cancellation does not become a process-level unhandled rejection; callers
    // that do await `completion` still receive the original rejection.
    // error-policy:J5 terminal state is observed through the flow registry/SSE;
    // callers awaiting `completion` still receive the original rejection.
    void completion.catch(() => undefined);
    const entry = {
        state: initialState,
        handle: {}, // filled below
        listeners: new Set(),
    };
    flows.set(sessionId, entry);
    const setTerminal = (next) => {
        if (entry.state.status !== "pending")
            return;
        entry.state = {
            ...entry.state,
            ...next,
            endedAt: Date.now(),
        };
        emit(entry);
        scheduleGc(sessionId);
    };
    const timer = setTimeout(() => {
        const err = new Error("OAuth flow timed out after 5 minutes");
        try {
            vendor.cancel("timeout");
        }
        catch (cancelErr) {
            // error-policy:J6 best-effort teardown — timeout is already terminal and
            // observable; cancellation failure is diagnostic only.
            logger.debug(`[oauth-flow] cancel during timeout failed: ${String(cancelErr)}`);
        }
        setTerminal({ status: "timeout", error: err.message });
        rejectCompletion(err);
    }, FLOW_TIMEOUT_MS);
    // Drive the vendor completion through to account-save and listener emit.
    void (async () => {
        try {
            const { creds } = await vendor.completion;
            clearTimeout(timer);
            let organizationId;
            let email;
            let providerAccountId;
            if (providerId === "anthropic-subscription") {
                const profile = await fetchAnthropicOAuthProfile(creds.access);
                organizationId = profile.organizationId;
                email = profile.email;
                providerAccountId = profile.accountId;
            }
            // Codex bakes the account_id into the JWT — pull it back out for
            // the usage probe header.
            if (providerId === "openai-codex") {
                const codexAccountId = extractCodexAccountId(creds.access);
                if (codexAccountId)
                    organizationId = codexAccountId;
                email = extractJwtEmail(creds.idToken);
            }
            const { record, previous } = buildAccountRecord({
                providerId,
                accountId: providerAccountId ?? accountId,
                ...(opts.replaceAccountId
                    ? { replaceAccountId: opts.replaceAccountId }
                    : {}),
                label: email ?? opts.label,
                access: creds.access,
                refresh: creds.refresh,
                expires: creds.expires,
                ...(creds.idToken ? { idToken: creds.idToken } : {}),
                ...(organizationId ? { organizationId } : {}),
                ...(providerAccountId ? { providerAccountId } : {}),
                ...(email ? { email } : {}),
                storagePolicy: opts.storagePolicy,
            });
            saveAccount(record, opts.storagePolicy);
            try {
                if (opts.onAccountSaved) {
                    await opts.onAccountSaved(record);
                }
            }
            catch (cause) {
                // error-policy:J2 context-adding rethrow — restore the prior account
                // before surfacing adoption failure with its original cause.
                if (previous) {
                    saveAccount(previous, opts.storagePolicy);
                    await opts.onReplacementRollback?.(previous);
                }
                throw new ElizaError("OAuth credential adoption failed", {
                    code: "oauth_flow.replacement_adoption_failed",
                    severity: "fatal",
                    cause,
                });
            }
            // The broadcast state must never carry the tokens — every SSE
            // subscriber receives it verbatim; only the in-process completion
            // promise gets the full record.
            const { credentials: _credentials, ...accountSummary } = record;
            setTerminal({ status: "success", account: accountSummary });
            resolveCompletion({ account: record });
        }
        catch (err) {
            // error-policy:J1 async OAuth boundary translation — publish the terminal
            // error to registry/SSE observers and reject in-process consumers.
            clearTimeout(timer);
            const message = err instanceof Error ? err.message : String(err);
            setTerminal({ status: "error", error: message });
            rejectCompletion(err instanceof Error ? err : new Error(message));
        }
    })();
    let submittedCode = null;
    const handle = {
        sessionId,
        authUrl: vendor.authUrl,
        ...(vendor.userCode ? { userCode: vendor.userCode } : {}),
        needsCodeSubmission,
        completion,
        submitCode: (code) => {
            if (submittedCode === code)
                return;
            if (submittedCode !== null) {
                throw new Error("OAuth callback code was already submitted");
            }
            submittedCode = code;
            vendor.submitCode(code);
        },
        cancel: (reason = "Cancelled") => {
            if (entry.state.status !== "pending")
                return;
            try {
                vendor.cancel(reason);
            }
            catch (err) {
                // error-policy:J6 best-effort teardown — cancellation is already the
                // terminal state; the vendor cleanup failure is logged for diagnosis.
                logger.debug(`[oauth-flow] vendor cancel failed: ${String(err)}`);
            }
            clearTimeout(timer);
            const error = new Error(reason);
            setTerminal({ status: "cancelled", error: reason });
            rejectCompletion(error);
        },
    };
    entry.handle = handle;
    emit(entry);
    return handle;
}
// Registry surface used by the SSE / cancel routes.
export function getFlowState(sessionId) {
    const entry = flows.get(sessionId);
    return entry ? entry.state : null;
}
export function getFlowHandle(sessionId) {
    const entry = flows.get(sessionId);
    return entry ? entry.handle : null;
}
/**
 * Subscribe to status updates for a flow. Replays the current state
 * synchronously so SSE consumers always receive an immediate frame.
 * Returns an unsubscribe function.
 */
export function subscribeFlow(sessionId, listener) {
    const entry = flows.get(sessionId);
    if (!entry)
        return () => { };
    entry.listeners.add(listener);
    // Replay current state.
    listener(entry.state);
    return () => {
        entry.listeners.delete(listener);
    };
}
export function cancelFlow(sessionId, reason) {
    const entry = flows.get(sessionId);
    if (!entry)
        return false;
    if (entry.state.status !== "pending")
        return false;
    entry.handle.cancel(reason);
    return true;
}
export function submitFlowCode(sessionId, code) {
    const entry = flows.get(sessionId);
    if (!entry)
        return false;
    if (entry.state.status !== "pending")
        return false;
    if (!entry.state.needsCodeSubmission)
        return false;
    try {
        entry.handle.submitCode(code);
        return true;
    }
    catch {
        // error-policy:J3 submitted callback data is untrusted; rejection is an
        // explicit invalid signal to the route boundary.
        return false;
    }
}
/**
 * Submit a callback to the pending flow for a provider when a legacy client
 * does not know the newer account-flow session id. A callback `state` is
 * matched against the authorization URL, so parallel flows cannot consume one
 * another's PKCE code. A state-less raw code is accepted only when exactly one
 * provider flow is pending.
 */
export function submitProviderFlowCode(providerId, code) {
    const callbackState = URL.parse(code)?.searchParams.get("state") ?? null;
    const candidates = [...flows.values()].filter((entry) => entry.state.providerId === providerId &&
        entry.state.status === "pending" &&
        entry.state.needsCodeSubmission);
    const matching = callbackState
        ? candidates.filter((entry) => URL.parse(entry.state.authUrl ?? "")?.searchParams.get("state") ===
            callbackState)
        : candidates;
    if (matching.length !== 1)
        return null;
    matching[0]?.handle.submitCode(code);
    return matching[0]?.handle ?? null;
}
/** OpenAI Codex JWT carries `chatgpt_account_id` under a vendor claim. */
function extractCodexAccountId(accessToken) {
    try {
        const parts = accessToken.split(".");
        if (parts.length !== 3)
            return null;
        const payload = parts[1];
        const decoded = JSON.parse(Buffer.from(payload, "base64").toString("utf-8"));
        const claim = decoded["https://api.openai.com/auth"];
        if (!claim || typeof claim !== "object")
            return null;
        const accountId = claim.chatgpt_account_id;
        return typeof accountId === "string" && accountId.length > 0
            ? accountId
            : null;
    }
    catch {
        // error-policy:J3 JWT claims are untrusted optional identity metadata; an
        // undecodable token has no usable account id.
        return null;
    }
}
function extractJwtEmail(token) {
    if (!token)
        return undefined;
    try {
        const payload = token.split(".")[1];
        if (!payload)
            return undefined;
        const decoded = JSON.parse(Buffer.from(payload, "base64url").toString("utf-8"));
        return typeof decoded.email === "string" && decoded.email.length > 0
            ? decoded.email
            : undefined;
    }
    catch {
        // error-policy:J3 untrusted-input sanitizing — an imported id_token without
        // a decodable JWT payload has no usable email identity.
        return undefined;
    }
}
export async function fetchAnthropicOAuthProfile(accessToken, fetchImpl = fetch) {
    let response;
    try {
        response = await fetchImpl("https://api.anthropic.com/api/oauth/profile", {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "anthropic-beta": "oauth-2025-04-20",
                "Content-Type": "application/json",
            },
            signal: AbortSignal.timeout(10_000),
        });
    }
    catch (cause) {
        // error-policy:J2 context-adding rethrow — account linking cannot claim a
        // loaded identity when the authenticated profile request never completed.
        throw new ElizaError("Anthropic OAuth profile request failed", {
            code: "anthropic_oauth.profile_request_failed",
            severity: "ephemeral",
            cause,
        });
    }
    if (!response.ok) {
        throw new ElizaError("Anthropic OAuth profile request was rejected", {
            code: "anthropic_oauth.profile_http_error",
            severity: response.status >= 500 ? "ephemeral" : "fatal",
            context: { status: response.status },
        });
    }
    let profile;
    try {
        profile = await response.json();
    }
    catch (cause) {
        // error-policy:J2 context-adding rethrow — malformed authenticated data is
        // a failed profile load, not a valid profile with empty identity fields.
        throw new ElizaError("Anthropic OAuth profile response was not JSON", {
            code: "anthropic_oauth.profile_invalid_json",
            severity: "fatal",
            cause,
        });
    }
    if (!profile || typeof profile !== "object" || Array.isArray(profile)) {
        throw new ElizaError("Anthropic OAuth profile response was invalid", {
            code: "anthropic_oauth.profile_invalid_shape",
            severity: "fatal",
        });
    }
    const record = profile;
    const rawEmail = record.account?.email ?? record.account?.email_address;
    const rawAccountId = record.account?.uuid;
    const rawOrganizationId = record.organization?.uuid;
    return {
        ...(typeof rawEmail === "string" && rawEmail.length > 0
            ? { email: rawEmail }
            : {}),
        ...(typeof rawAccountId === "string" && rawAccountId.length > 0
            ? { accountId: rawAccountId }
            : {}),
        ...(typeof rawOrganizationId === "string" && rawOrganizationId.length > 0
            ? { organizationId: rawOrganizationId }
            : {}),
    };
}
//# sourceMappingURL=oauth-flow.js.map