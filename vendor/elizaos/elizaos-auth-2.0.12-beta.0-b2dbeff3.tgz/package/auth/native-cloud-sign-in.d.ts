/**
 * Renderer contract for the native Eliza Cloud sign-in client (`packages/auth/android`,
 * `ai.eliza.auth.cloud.CloudSignInPlugin`).
 *
 * A host subclasses `CloudSignInPlugin` under its own Capacitor name; the renderer calls it
 * through a `NativeCloudSignInPort` and checks every answer here before acting on it. The native
 * side holds the Steward session, PKCE verifiers, states and authorization codes: none of them
 * crosses to the renderer, and the outcomes parsed here carry no secret. Anything unexpected
 * (extra keys, another deployment, malformed times or attempt ids) is refused as `unavailable`
 * rather than trusted.
 *
 * Dependency-free on purpose: products may project this single file from the pinned source.
 * Product names and deployment names are supplied by the caller; nothing here names a product.
 */
/** Failure codes the native client rejects with (`PluginCall.reject(message, code)`). */
export type NativeCloudSignInFailureCode = "cancelled" | "login-active" | "invalid-phone" | "invalid-email" | "invalid-code" | "cooldown" | "expired" | "rate-limited" | "offline" | "unavailable" | "account-check" | "state-mismatch" | "browser-closed" | "browser-unavailable" | "provider-refused" | "mfa-browser" | "mfa-unsupported" | "activation-pending" | "storage" | "rejected" | "invalid-request" | "app-link-unverified" | "attempts-exhausted" | "google-account-unavailable";
export declare const NATIVE_CLOUD_SIGN_IN_FAILURE_CODES: ReadonlySet<NativeCloudSignInFailureCode>;
export interface NativeCloudSignInAuthenticated<E extends string = string> {
    status: "authenticated";
    environment: E;
    expiresAt: number;
    /** True when this sign-in created the Cloud account; null when Cloud did not say. */
    accountCreated: boolean | null;
    /** What happened to the key this sign-in replaced; absent when none was saved. */
    previousSignIn?: "revoked" | "unconfirmed";
    /** Native attempt and installed local credential generation; absent on older hosts. */
    attemptId?: string;
    credentialId?: string;
    /** Echo of the caller's immutable interactive request, never a credential. */
    requestId?: string;
}
export interface NativeCloudSignInCodeStarted {
    attemptId: string;
    expiresAt: number;
    resendAt: number;
}
export interface NativeCloudSignInMfaRequired {
    requestId?: string;
    attemptId?: string;
    status: "mfa";
    method: "totp" | "sms" | "passkey";
    expiresAt: number;
}
export interface NativeCloudSignInGoogleMfaRequired<E extends string = string> extends NativeCloudSignInMfaRequired {
    attemptId: string;
    environment: E;
}
export type NativeCloudSignInGoogleOutcome<E extends string = string> = NativeCloudSignInAuthenticated<E> | NativeCloudSignInGoogleMfaRequired<E>;
export interface NativeCloudSignInReadiness {
    google: boolean;
    phone: boolean;
    email: boolean;
}
/** The plugin methods of `CloudSignInPlugin`, as a renderer port. Answers are untrusted until parsed. */
export interface NativeCloudSignInPort<E extends string = string> {
    serviceInfo?(input: {
        environment: E;
    }): Promise<unknown>;
    /** Current installed identity only; available on hosts that emit credentialId. */
    credentialIdentity?(input: {
        environment: E;
    }): Promise<unknown>;
    /** Opens Android's native Google account picker; answers only authenticated or MFA metadata. */
    startGoogle(input: {
        environment: E;
        requestId?: string;
    }): Promise<unknown>;
    startEmail(input: {
        environment: E;
        email: string;
        requestId?: string;
    }): Promise<unknown>;
    startPhone?(input: {
        environment: E;
        phone: string;
        requestId?: string;
    }): Promise<unknown>;
    verifyPhone?(input: {
        attemptId: string;
        code: string;
    }): Promise<unknown>;
    verifyEmail(input: {
        attemptId: string;
        code: string;
    }): Promise<unknown>;
    verifyMfa(input: {
        attemptId: string;
        code: string;
    }): Promise<unknown>;
    /** Revalidates a retained MFA event against the current native attempt; no network or secrets. */
    resumeMfa?(input: {
        attemptId: string;
        environment: E;
    }): Promise<unknown>;
    /** A supplied request scopes cancellation and pending cleanup to that native attempt.
     * Unscoped cancellation is retained for older callers; shared views always supply their ID. */
    cancel(input?: {
        requestId: string;
    }): Promise<void>;
    /** Clears only the native credential picker session after explicit sign-out. */
    clearCredentialState?(): Promise<void>;
    /** Which methods the host offers and whether Cloud is ready for in-app sign-in (`inApp`). */
    status?(input?: {
        environment: E;
        refreshNegative?: boolean;
    }): Promise<unknown>;
    /**
     * `signInCompleted`: a Google return that completed after the app restarted (no waiting call).
     * `signInIncomplete`: a return without a sign-in result arrived with no waiting call.
     * `signInMfaRequired`: a retained hint that must be revalidated through `resumeMfa`.
     */
    addListener?(event: "signInCompleted" | "signInIncomplete" | "signInMfaRequired", listener: (outcome: unknown) => void): Promise<unknown>;
}
export declare class NativeCloudSignInError extends Error {
    readonly code: NativeCloudSignInFailureCode;
    constructor(code: NativeCloudSignInFailureCode);
    /** A native rejection keeps its code only when it is one the client defines. */
    static from(error: unknown): NativeCloudSignInError;
}
export interface NativeCloudSignInCopy {
    /** The deployment's public name, e.g. "Eliza Cloud". */
    serviceName: string;
    /** The app's own name, e.g. "Eliza". */
    productName: string;
}
/** Owner-facing copy. Never includes server text, codes or addresses. */
export declare function nativeCloudSignInFailureMessage(code: NativeCloudSignInFailureCode, { serviceName, productName }: NativeCloudSignInCopy): string;
/** A completed sign-in for exactly this deployment, with nothing but the documented fields. */
export declare function nativeSignInAuthenticated<E extends string>(value: unknown, environment: E): NativeCloudSignInAuthenticated<E>;
/** The answer to `startEmail` or `startPhone`: the attempt and when a new code may be sent. */
export declare function nativeSignInCodeStarted(value: unknown): NativeCloudSignInCodeStarted;
/** The answer to a code verification: signed in, or a second factor is required. */
export declare function nativeSignInVerified<E extends string>(value: unknown, environment: E): NativeCloudSignInAuthenticated<E> | NativeCloudSignInMfaRequired;
/** Google may require a native second factor; bind it to this attempt and deployment. */
export declare function nativeSignInGoogleOutcome<E extends string>(value: unknown, environment: E, now?: number): NativeCloudSignInGoogleOutcome<E>;
/**
 * Explicit method readiness from the host's `status`. Unknown readiness (null) keeps the email
 * error and retry surface; known disabled methods stay hidden. SMS is never inferred.
 */
export declare function nativeSignInReadiness(value: unknown): NativeCloudSignInReadiness | null;
/** Six digits, ignoring spaces and dashes the owner typed; null otherwise. */
export declare const normalizeNativeSignInCode: (value: string) => string | null;
export declare const validNativeSignInEmail: (value: string) => boolean;
/** E.164 with its country code. */
export declare const validNativeSignInPhone: (value: string) => boolean;
//# sourceMappingURL=native-cloud-sign-in.d.ts.map