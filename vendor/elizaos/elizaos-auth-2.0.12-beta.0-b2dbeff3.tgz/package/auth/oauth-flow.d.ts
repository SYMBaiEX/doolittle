/**
 * OAuth flow orchestration registry.
 *
 * Wraps the provider-specific programmatic OAuth helpers
 * (`startAnthropicOAuthFlowRaw` from
 * `vendor/pi-oauth/anthropic-login.ts` and the loopback-listener flow
 * in `openai-codex.ts`) with:
 *
 *   - a 15-minute timeout per flow,
 *   - automatic `saveAccount(...)` after token exchange,
 *   - an in-memory registry keyed by `sessionId` so the HTTP API can
 *     stream progress over SSE and the CLI can `await` completion,
 *   - garbage collection 10 minutes after a flow reaches a terminal
 *     state.
 *
 * Both the CLI and the new accounts-routes HTTP endpoints drive flows
 * through this module — there is no direct caller of the vendor-level
 * OAuth helpers anymore.
 */
import { type AccountCredentialRecord, type AccountStoragePolicy } from "./account-storage.js";
import type { SubscriptionProvider } from "./types.js";
/** Server-tracked status of an in-flight OAuth flow. */
export type FlowStatus = "pending" | "success" | "error" | "cancelled" | "timeout";
/**
 * Credential-free projection of an `AccountCredentialRecord` — the only
 * account shape allowed into {@link FlowState}. `FlowState` is serialized
 * verbatim to every `/api/accounts/:provider/oauth/status` SSE subscriber,
 * so the OAuth access/refresh tokens must never enter it. In-process
 * callers that need the tokens use `OAuthFlowHandle.completion` instead.
 */
export type FlowAccountSummary = Omit<AccountCredentialRecord, "credentials">;
export interface FlowState {
    sessionId: string;
    providerId: SubscriptionProvider;
    status: FlowStatus;
    /** Set on `pending` (so the UI can re-open the browser) and on `success`. */
    authUrl?: string;
    /** Whether the client must offer a callback URL/code input. */
    needsCodeSubmission: boolean;
    /** Existing account selected by the initiating request for atomic replacement. */
    replaceAccountId?: string;
    account?: FlowAccountSummary;
    error?: string;
    startedAt: number;
    endedAt?: number;
}
export interface OAuthFlowHandle {
    sessionId: string;
    authUrl: string;
    /** One-time code entered on the provider's device authorization page. */
    userCode?: string;
    /** Whether the client must offer a callback URL/code input. */
    needsCodeSubmission: boolean;
    /** Resolves with the saved AccountCredentialRecord; rejects on cancel/timeout/error. */
    completion: Promise<{
        account: AccountCredentialRecord;
    }>;
    /** Submit the provider's callback URL or authorization code. */
    submitCode: (code: string) => void;
    cancel: (reason?: string) => void;
}
export interface StartOptions {
    label: string;
    storagePolicy: AccountStoragePolicy;
    accountId?: string;
    /** Existing same-provider account to replace only after OAuth succeeds. */
    replaceAccountId?: string;
    /** Remote/headless clients use Codex device auth instead of loopback PKCE. */
    headless?: boolean;
    /**
     * Called after the account is saved on disk. Used by the HTTP
     * route layer to also write a `LinkedAccountConfig` row into
     * `eliza.json`. Failures here propagate as flow `error`.
     */
    onAccountSaved?: (account: AccountCredentialRecord) => void | Promise<void>;
    /** Restores host metadata if replacement adoption fails after a pool write. */
    onReplacementRollback?: (account: AccountCredentialRecord) => void | Promise<void>;
}
/**
 * Start a programmatic Anthropic OAuth flow. Anthropic's redirect URI
 * is hardcoded to `console.anthropic.com/oauth/code/callback` — the
 * UI must surface the auth URL, prompt the user to copy the
 * `code#state` blob, and call `submitCode()` with it. Once the code is
 * submitted, the token exchange runs and the account is persisted.
 */
export declare function startAnthropicOAuthFlow(opts: StartOptions): Promise<OAuthFlowHandle>;
/**
 * Start a programmatic Codex OAuth flow. Native/local clients can use the
 * loopback listener on :1455. Remote web clients must paste the localhost
 * callback URL because that URL resolves in the browser's device, not on the
 * remote Eliza host. The accountId
 * baked into the JWT is preserved on `LinkedAccountConfig.organizationId`
 * (used by the Codex usage probe via the `ChatGPT-Account-Id` header).
 */
export declare function startCodexOAuthFlow(opts: StartOptions): Promise<OAuthFlowHandle>;
export declare function getFlowState(sessionId: string): FlowState | null;
export declare function getFlowHandle(sessionId: string): OAuthFlowHandle | null;
/**
 * Subscribe to status updates for a flow. Replays the current state
 * synchronously so SSE consumers always receive an immediate frame.
 * Returns an unsubscribe function.
 */
export declare function subscribeFlow(sessionId: string, listener: (state: FlowState) => void): () => void;
export declare function cancelFlow(sessionId: string, reason?: string): boolean;
export declare function submitFlowCode(sessionId: string, code: string): boolean;
/**
 * Submit a callback to the pending flow for a provider when a legacy client
 * does not know the newer account-flow session id. A callback `state` is
 * matched against the authorization URL, so parallel flows cannot consume one
 * another's PKCE code. A state-less raw code is accepted only when exactly one
 * provider flow is pending.
 */
export declare function submitProviderFlowCode(providerId: SubscriptionProvider, code: string): OAuthFlowHandle | null;
export declare function fetchAnthropicOAuthProfile(accessToken: string, fetchImpl?: typeof fetch): Promise<{
    email?: string;
    accountId?: string;
    organizationId?: string;
}>;
//# sourceMappingURL=oauth-flow.d.ts.map