/**
 * Transactional adoption of a Codex CLI login (`CODEX_HOME/auth.json`) into the
 * account pool, with mandatory retirement of the source so exactly one refresher
 * owns the chain.
 *
 * OpenAI Codex refresh tokens are one-time-use (rotate-and-revoke on reuse): if
 * the pool adopts the login while the CLI's `auth.json` stays in place, both
 * sides eventually refresh the same chain, the second refresh replays a consumed
 * token, and OpenAI revokes the whole grant family. Adoption is therefore only
 * safe as an exclusive-ownership transfer.
 *
 * Ownership is established by retiring FIRST and reading SECOND: the source is
 * atomically renamed to an unpredictable retired path, and the credentials are
 * parsed from that retired inode. Whatever bytes the pool stores are exactly the
 * bytes that were removed from the CLI's read path — a concurrent atomic
 * replacement of `auth.json` (Codex's own write pattern) can race the rename,
 * but it can never produce a pool account whose tokens differ from the retired
 * file. A source that reappears after retirement means a live refresher is
 * still running; adoption fails typed (`adopt_codex.concurrent_refresher`)
 * rather than committing a chain another process is actively rotating.
 *
 * This is a deliberate, operator-invoked action (`eliza auth adopt-codex`),
 * never a boot-time auto-import. Claude Max adoption is intentionally not
 * provided: a Claude login is usually the account the operator runs Claude Code
 * with, and pooling it logs that session out — connect a dedicated Claude
 * account through the explicit OAuth flow instead.
 */
import { randomBytes } from "node:crypto";
import { closeSync, constants, fsyncSync, linkSync, lstatSync, openSync, readSync, renameSync, unlinkSync, } from "node:fs";
import path from "node:path";
import { logger } from "@elizaos/core";
import { ElizaError } from "@elizaos/core/protocol";
import { withAccountStorageMutation, } from "../account-storage.js";
/** Every failure mode, as the `code` on the thrown {@link ElizaError}. */
export const ADOPT_CODEX_ERROR_CODES = [
    "adopt_codex.invalid_account_id",
    "adopt_codex.no_source",
    "adopt_codex.source_stat_failed",
    "adopt_codex.not_regular_file",
    "adopt_codex.unreadable",
    "adopt_codex.invalid_tokens",
    "adopt_codex.account_exists",
    "adopt_codex.retire_failed",
    "adopt_codex.pool_write_failed",
    "adopt_codex.concurrent_refresher",
];
function adoptError(code, message, context, cause) {
    return new ElizaError(message, {
        code,
        severity: "fatal",
        ...(context ? { context } : {}),
        ...(cause !== undefined ? { cause } : {}),
    });
}
// Pool account ids flow into both the pool filename and the retired-file
// suffix, so they are validated as a strict identifier at this public
// boundary: no separators, no traversal, no control characters, bounded
// length. Anything else is rejected before any filesystem effect.
const ACCOUNT_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
function validateAccountId(accountId) {
    if (typeof accountId !== "string" ||
        !ACCOUNT_ID_PATTERN.test(accountId) ||
        accountId === "." ||
        accountId === ".." ||
        accountId.includes("..")) {
        throw adoptError("adopt_codex.invalid_account_id", "Account id must be 1-64 chars of [A-Za-z0-9._-], starting alphanumeric, with no traversal sequences", { accountId: String(accountId).slice(0, 80) });
    }
}
function codexAuthPath() {
    return path.join(process.env.CODEX_HOME || path.join(process.env.HOME || "", ".codex"), "auth.json");
}
/** Decode a JWT `exp` (seconds) into ms; undefined when undecodable. */
function jwtExpiryMs(token) {
    const parts = token.split(".");
    if (parts.length < 2)
        return undefined;
    try {
        const payload = JSON.parse(Buffer.from(parts[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf-8"));
        return typeof payload.exp === "number" ? payload.exp * 1000 : undefined;
    }
    catch {
        // error-policy:J3 the JWT is untrusted input; undefined is the explicit
        // invalid-expiry signal rejected by token validation.
        return undefined;
    }
}
function isNonEmptyString(value) {
    return typeof value === "string" && value.length > 0;
}
/**
 * Validate the parsed auth.json token block at runtime. Every field that flows
 * into `.split()` or the pool store must actually be a string — a numeric or
 * object-shaped token from a hand-edited file fails typed here instead of
 * surfacing as an untyped crash downstream.
 */
function validateTokens(parsed, sourceLabel) {
    const tokens = parsed?.tokens;
    if (!tokens ||
        !isNonEmptyString(tokens.access_token) ||
        !isNonEmptyString(tokens.refresh_token) ||
        (tokens.id_token !== undefined && !isNonEmptyString(tokens.id_token)) ||
        (tokens.account_id !== undefined && !isNonEmptyString(tokens.account_id))) {
        throw adoptError("adopt_codex.invalid_tokens", `Codex login at ${sourceLabel} is missing string access/refresh tokens`, { source: sourceLabel });
    }
    const expires = jwtExpiryMs(tokens.access_token);
    if (expires === undefined || !Number.isFinite(expires)) {
        throw adoptError("adopt_codex.invalid_tokens", `Codex login at ${sourceLabel} has no valid access-token expiry`, { source: sourceLabel });
    }
    return {
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        expires,
        ...(tokens.id_token !== undefined ? { id_token: tokens.id_token } : {}),
        ...(tokens.account_id !== undefined
            ? { account_id: tokens.account_id }
            : {}),
    };
}
/**
 * Read a path that must be a regular file, opening with O_NOFOLLOW so a
 * symlink swapped in after the lstat is rejected rather than followed.
 */
function readRegularFile(filePath) {
    let fd;
    try {
        fd = openSync(filePath, constants.O_RDONLY | constants.O_NOFOLLOW);
    }
    catch (err) {
        // error-policy:J2 context-adding rethrow — preserve the filesystem cause in
        // the typed adoption failure.
        throw adoptError("adopt_codex.unreadable", `Could not open ${filePath} as a regular file`, { path: filePath }, err);
    }
    try {
        const chunks = [];
        const buf = Buffer.alloc(64 * 1024);
        let n;
        // biome-ignore lint/suspicious/noAssignInExpressions: standard read loop
        while ((n = readSync(fd, buf, 0, buf.length, null)) > 0) {
            chunks.push(Buffer.from(buf.subarray(0, n)));
        }
        return Buffer.concat(chunks).toString("utf-8");
    }
    finally {
        closeSync(fd);
    }
}
/**
 * Move a retired source back to its original path WITHOUT ever clobbering a
 * file that has appeared there since — `link()` fails with EEXIST on an
 * occupied destination, which makes the no-clobber check atomic rather than a
 * check-then-rename race. An occupied destination means a live refresher
 * recreated the login with a fresher chain; the retired copy must not replace
 * it.
 */
export function restoreRetiredSource(retiredTo, originalPath) {
    try {
        linkSync(retiredTo, originalPath);
    }
    catch (err) {
        // error-policy:J1 no-clobber restore boundary — an occupied destination is
        // an explicit non-restored result; every other link failure throws.
        if (err.code === "EEXIST") {
            return { restored: false, reason: "destination_occupied" };
        }
        throw err;
    }
    unlinkSync(retiredTo);
    fsyncParentDirectory(originalPath);
    return { restored: true };
}
function fsyncParentDirectory(filePath) {
    if (process.platform === "win32")
        return;
    const descriptor = openSync(path.dirname(filePath), constants.O_RDONLY | (constants.O_DIRECTORY ?? 0));
    try {
        fsyncSync(descriptor);
    }
    finally {
        closeSync(descriptor);
    }
}
/**
 * Adopt the Codex CLI login into the pool and retire the source in one
 * transactional operation. Post-condition on success: the pool account exists,
 * the source auth.json is gone from the CLI's read path, and the pool
 * credentials are byte-identical to the retired file. On any failure nothing is
 * committed; where the source was already retired it is restored no-clobber, or
 * its retired location is surfaced in the error context.
 */
function adoptCodexCliLoginLocked(opts, storage) {
    const accountId = opts.accountId ?? "default";
    validateAccountId(accountId);
    const provider = "openai-codex";
    const authPath = opts.codexHome
        ? path.join(opts.codexHome, "auth.json")
        : codexAuthPath();
    // Source must exist and be a regular file (a symlink here could redirect the
    // retirement rename). Only ENOENT means "no login"; any other stat failure
    // (permissions, I/O) is its own failure mode, not a silent absence.
    let stat;
    try {
        stat = lstatSync(authPath);
    }
    catch (err) {
        // error-policy:J2 context-adding rethrow — distinguish a missing source from
        // permission and I/O failures without treating either as healthy.
        if (err.code === "ENOENT") {
            throw adoptError("adopt_codex.no_source", `No Codex login at ${authPath}`, { path: authPath });
        }
        throw adoptError("adopt_codex.source_stat_failed", `Could not stat the Codex login at ${authPath}`, { path: authPath }, err);
    }
    if (!stat.isFile()) {
        throw adoptError("adopt_codex.not_regular_file", `Codex login at ${authPath} is not a regular file; refusing to adopt`, { path: authPath });
    }
    // No implicit overwrite of an existing pool account — checked before any
    // filesystem effect so a collision leaves the world untouched.
    const existing = storage.loadAccount(provider, accountId);
    if (existing && !opts.overwrite) {
        throw adoptError("adopt_codex.account_exists", `A pool account "${provider}/${accountId}" already exists; pass overwrite to replace it`, { provider, accountId });
    }
    // Retire FIRST: atomically claim whatever inode is current. The retired name
    // carries 64 random bits so it is unpredictable (nothing else can pre-create
    // or guess it) and repeated adoptions can never clobber a prior retired
    // credential file.
    const retiredTo = `${authPath}.adopted-${randomBytes(8).toString("hex")}`;
    try {
        renameSync(authPath, retiredTo);
        fsyncParentDirectory(authPath);
    }
    catch (err) {
        // error-policy:J2 context-adding rethrow — retirement must succeed atomically
        // before any credential is adopted.
        throw adoptError("adopt_codex.retire_failed", `Could not retire the Codex source at ${authPath}; exclusive ownership not established`, { path: authPath, retiredTo }, err);
    }
    // Read SECOND, from the retired inode we exclusively own. This is what makes
    // the transfer race-free against Codex's atomic-replace refresh writes: the
    // bytes adopted are by construction the bytes retired.
    let tokens;
    try {
        const raw = readRegularFile(retiredTo);
        let parsed;
        try {
            parsed = JSON.parse(raw);
        }
        catch (err) {
            // error-policy:J2 context-adding rethrow — invalid JSON is a typed source
            // validation failure and retains its parser cause.
            throw adoptError("adopt_codex.unreadable", `Codex login at ${authPath} is not valid JSON`, { path: authPath, retiredTo }, err);
        }
        tokens = validateTokens(parsed, authPath);
    }
    catch (err) {
        // error-policy:J2 rollback then rethrow — validation failure restores the
        // exclusively-retired source when the destination remains free.
        const restore = restoreRetiredSource(retiredTo, authPath);
        if (!restore.restored) {
            logger.warn(`[auth] adoptCodexCliLogin: validation failed and the original path is occupied; the retired source remains at ${retiredTo}`);
        }
        throw err;
    }
    // A source that reappeared between the rename and here means a live Codex
    // process wrote a fresh login — it is still refreshing the chain, and the
    // copy we just retired may already hold consumed tokens. Committing it to
    // the pool would set up the exact dual-refresher revocation this operation
    // exists to prevent.
    let sourceReappeared;
    try {
        lstatSync(authPath);
        sourceReappeared = true;
    }
    catch (err) {
        // error-policy:J3 only ENOENT proves the source stayed retired. Permission
        // and I/O failures cannot be interpreted as absence at this ownership gate.
        if (err.code === "ENOENT") {
            sourceReappeared = false;
        }
        else {
            const restore = restoreRetiredSource(retiredTo, authPath);
            throw adoptError("adopt_codex.source_stat_failed", `Could not verify that ${authPath} remained retired; the Codex source was ${restore.restored ? "restored" : `left retired at ${retiredTo}`}`, { path: authPath, retiredTo, restored: restore.restored }, err);
        }
    }
    if (sourceReappeared) {
        throw adoptError("adopt_codex.concurrent_refresher", `A live process recreated ${authPath} during adoption; stop every running codex process and retry. The retired copy remains at ${retiredTo}`, { path: authPath, retiredTo });
    }
    try {
        const now = Date.now();
        storage.saveAccount({
            id: accountId,
            providerId: provider,
            label: "Adopted Codex CLI login",
            source: "oauth",
            credentials: {
                access: tokens.access_token,
                refresh: tokens.refresh_token,
                expires: tokens.expires,
                ...(tokens.id_token ? { idToken: tokens.id_token } : {}),
            },
            createdAt: existing?.createdAt ?? now,
            updatedAt: now,
            ...(tokens.account_id ? { organizationId: tokens.account_id } : {}),
        });
    }
    catch (err) {
        // error-policy:J2 preserve the atomic adoption context while restoring the
        // retired source whenever ownership still permits it.
        const restore = restoreRetiredSource(retiredTo, authPath);
        if (!restore.restored) {
            // error-policy:J6 best-effort teardown — the pool write already failed
            // and the original path is occupied by a fresher login, so the retired
            // copy stays where it is (surfaced below); the original write failure is
            // the actionable error and is rethrown.
            logger.warn(`[auth] adoptCodexCliLogin: pool write failed and the original path is occupied; the retired source remains at ${retiredTo}`);
        }
        throw adoptError("adopt_codex.pool_write_failed", `Pool account write failed; the Codex source was ${restore.restored ? "restored" : `left retired at ${retiredTo}`}`, { path: authPath, retiredTo, restored: restore.restored }, err);
    }
    return {
        accountId,
        ...(tokens.account_id ? { organizationId: tokens.account_id } : {}),
        retiredTo,
    };
}
export function adoptCodexCliLogin(opts) {
    const accountId = opts.accountId ?? "default";
    validateAccountId(accountId);
    const authPath = opts.codexHome
        ? path.join(opts.codexHome, "auth.json")
        : codexAuthPath();
    let transactionEntered = false;
    try {
        return withAccountStorageMutation(opts.storagePolicy, "adopt-codex-cli-login", (storage) => {
            transactionEntered = true;
            return adoptCodexCliLoginLocked(opts, storage);
        });
    }
    catch (cause) {
        if (cause instanceof ElizaError &&
            ADOPT_CODEX_ERROR_CODES.includes(cause.code)) {
            throw cause;
        }
        throw adoptError("adopt_codex.pool_write_failed", "Account storage was unavailable before Codex credential adoption could commit", { accountId, path: authPath, restored: !transactionEntered }, cause);
    }
}
//# sourceMappingURL=adopt-codex-cli-login.js.map