/**
 * Built-in {@link SubscriptionAuthProvider} descriptors.
 *
 * Vendor-specific credential *discovery* (the surfaces where a login can be
 * found: a first-party CLI login blob, a tool on `PATH`, an unavailable
 * provider) lives here rather than inside host `auth/`, and is drained
 * generically by `auth/credentials.ts` through the `@elizaos/core`
 * subscription-auth registry.
 *
 * These are host built-ins today. The registry API is public, so the
 * model-provider plugin that owns a vendor can register (and thereby own) its
 * own descriptor via `registerSubscriptionAuthProvider` — replacing the
 * built-in without any change to host `auth/`.
 *
 * @module subscription-auth/builtin-providers
 */
/**
 * Register the built-in subscription-auth descriptors if they are not already
 * present. Idempotent (keyed on the registry, so it re-seeds after a test
 * reset), so it is safe to call from every host entry point that drains the
 * registry.
 */
export declare function ensureBuiltinSubscriptionAuthProviders(): void;
//# sourceMappingURL=builtin-providers.d.ts.map