/**
 * Transactional adoption of a Codex CLI login (`CODEX_HOME/auth.json`) into the
 * account pool, with mandatory retirement of the source so exactly one refresher
 * owns the chain.
 *
 * OpenAI Codex refresh tokens are one-time-use (rotate-and-revoke on reuse): if
 * the pool adopts the login while the CLI's `auth.json` stays in place, both
 * sides eventually refresh the same chain, the second refresh replays a consumed
 * token, and OpenAI revokes the whole grant family. Adoption is therefore only
 * safe as an exclusive-ownership transfer.
 *
 * Ownership is established by retiring FIRST and reading SECOND: the source is
 * atomically renamed to an unpredictable retired path, and the credentials are
 * parsed from that retired inode. Whatever bytes the pool stores are exactly the
 * bytes that were removed from the CLI's read path — a concurrent atomic
 * replacement of `auth.json` (Codex's own write pattern) can race the rename,
 * but it can never produce a pool account whose tokens differ from the retired
 * file. A source that reappears after retirement means a live refresher is
 * still running; adoption fails typed (`adopt_codex.concurrent_refresher`)
 * rather than committing a chain another process is actively rotating.
 *
 * This is a deliberate, operator-invoked action (`eliza auth adopt-codex`),
 * never a boot-time auto-import. Claude Max adoption is intentionally not
 * provided: a Claude login is usually the account the operator runs Claude Code
 * with, and pooling it logs that session out — connect a dedicated Claude
 * account through the explicit OAuth flow instead.
 */
import { type AccountStoragePolicy } from "../account-storage.js";
/** Every failure mode, as the `code` on the thrown {@link ElizaError}. */
export declare const ADOPT_CODEX_ERROR_CODES: readonly ["adopt_codex.invalid_account_id", "adopt_codex.no_source", "adopt_codex.source_stat_failed", "adopt_codex.not_regular_file", "adopt_codex.unreadable", "adopt_codex.invalid_tokens", "adopt_codex.account_exists", "adopt_codex.retire_failed", "adopt_codex.pool_write_failed", "adopt_codex.concurrent_refresher"];
export type AdoptCodexErrorCode = (typeof ADOPT_CODEX_ERROR_CODES)[number];
export interface AdoptCodexOptions {
    storagePolicy: AccountStoragePolicy;
    /** Pool account id to create (default "default"). */
    accountId?: string;
    /** Overwrite an existing pool account with this id. Default false → error. */
    overwrite?: boolean;
    /**
     * The `CODEX_HOME` to adopt from. Defaults to the process's
     * `CODEX_HOME`/`~/.codex`. Explicit so a caller can adopt a per-account home
     * (e.g. `~/.codex-acct2`) without mutating process env.
     */
    codexHome?: string;
}
export interface AdoptCodexResult {
    accountId: string;
    organizationId?: string;
    /** Where the source auth.json was moved to (proof of retirement). */
    retiredTo: string;
}
export interface RestoreRetiredResult {
    restored: boolean;
    /** Set when the original path is occupied — restoring would clobber it. */
    reason?: "destination_occupied";
}
/**
 * Move a retired source back to its original path WITHOUT ever clobbering a
 * file that has appeared there since — `link()` fails with EEXIST on an
 * occupied destination, which makes the no-clobber check atomic rather than a
 * check-then-rename race. An occupied destination means a live refresher
 * recreated the login with a fresher chain; the retired copy must not replace
 * it.
 */
export declare function restoreRetiredSource(retiredTo: string, originalPath: string): RestoreRetiredResult;
export declare function adoptCodexCliLogin(opts: AdoptCodexOptions): AdoptCodexResult;
//# sourceMappingURL=adopt-codex-cli-login.d.ts.map