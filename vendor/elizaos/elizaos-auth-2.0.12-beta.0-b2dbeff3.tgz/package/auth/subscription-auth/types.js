/**
 * Subscription-auth extension point.
 *
 * A model vendor's subscription product (its first-party CLI login, the
 * credential-store key, the surfaces where a login can be discovered) is a
 * property of the vendor, not of the host. This interface lets the plugin that
 * owns a vendor describe that product so the host `auth/` layer can stay
 * generic: the host drains the registry to discover and report subscription
 * credentials and never branches on a vendor id. Host `auth/` keeps only the
 * generic account store, credential storage, and refresh mutex.
 */
export {};
//# sourceMappingURL=types.js.map