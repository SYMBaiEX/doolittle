/**
 * Orchestrates headless Codex device login for authentication consumers.
 *
 * The flow owns an isolated temporary CODEX_HOME, parses only the public
 * device prompt, and withholds credentials until the child is terminal and
 * that temporary state has been removed successfully.
 */
import type { OAuthCredentials } from "./types.js";
export interface CodexDeviceFlow {
    authUrl: string;
    userCode: string;
    credentials: Promise<OAuthCredentials>;
    close: () => void;
}
export declare function codexDeviceLoginUsesShell(platform?: NodeJS.Platform): boolean;
export declare function startCodexDeviceLogin(): Promise<CodexDeviceFlow>;
//# sourceMappingURL=codex-device.d.ts.map