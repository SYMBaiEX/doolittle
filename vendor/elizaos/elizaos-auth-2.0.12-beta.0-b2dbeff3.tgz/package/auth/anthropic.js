/**
 * Anthropic OAuth flow (Claude Pro/Max subscription)
 *
 * Uses inlined PKCE + token exchange (vendored OAuth helpers).
 * The callback API is adapted to a start/exchange pattern for HTTP route handlers.
 */
import { exchangeAnthropicAuthorizationCode, loginAnthropic as loginAnthropicFlow, refreshAnthropicToken as refreshAnthropicTokenFlow, } from "./vendor/pi-oauth/anthropic-login.js";
export { exchangeAnthropicAuthorizationCode };
/**
 * Start the Anthropic OAuth flow.
 * Returns an auth URL and a way to submit the code + get credentials.
 */
export async function startAnthropicLogin() {
    let authUrl = "";
    let resolveCode = null;
    let resolveUrlReady = null;
    const codePromise = new Promise((resolve) => {
        resolveCode = resolve;
    });
    const urlReady = new Promise((resolve) => {
        resolveUrlReady = resolve;
    });
    const credentials = loginAnthropicFlow((url) => {
        authUrl = url;
        resolveUrlReady?.();
    }, () => codePromise);
    await urlReady;
    return {
        authUrl,
        submitCode: (code) => resolveCode?.(code),
        credentials,
    };
}
/**
 * Refresh an expired Anthropic token.
 */
export async function refreshAnthropicToken(refreshToken) {
    return refreshAnthropicTokenFlow(refreshToken);
}
//# sourceMappingURL=anthropic.js.map