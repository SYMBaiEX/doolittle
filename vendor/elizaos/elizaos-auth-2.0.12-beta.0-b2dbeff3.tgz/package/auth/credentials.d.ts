import type { SubscriptionCredentialSource } from "@elizaos/host/protocol";
import { type AccountCredentialRecord, type AccountDeletionPlan, type AccountStoragePolicy, type LoadedAccountCredentialRecord } from "./account-storage.js";
import { type AccountCredentialProvider, type OAuthCredentials, type StoredCredentials, type SubscriptionProvider } from "./types.js";
/** Stable failure categories for callers that manage account-pool health. */
export type AccessTokenFailureKind = "auth" | "transient" | "insufficient-lifetime";
/** Typed token resolution result for callers that cannot treat every failure as reauthentication. */
export type AccessTokenOutcome = {
    ok: true;
    accessToken: string;
    expiresAt: number;
    refreshed: boolean;
} | {
    ok: false;
    kind: AccessTokenFailureKind;
    message: string;
    expiresAt?: number;
    minRemainingMs?: number;
};
/** Freshness requested by a token consumer before it starts work. */
export interface GetAccessTokenOptions {
    minRemainingMs?: number;
    /** Required only when an expired credential must be refreshed on disk. */
    storagePolicy?: AccountStoragePolicy;
}
/** Selects the typed token result instead of the legacy nullable return. */
export interface GetAccessTokenOutcomeOptions extends GetAccessTokenOptions {
    outcome: true;
}
/**
 * Save credentials for a provider account.
 *
 * The `accountId` defaults to `"default"`. New accounts are persisted
 * with `source: "oauth"` and `label: "Default"` (or the existing
 * record's label when overwriting).
 */
export declare function saveCredentials(provider: SubscriptionProvider, credentials: OAuthCredentials, accountId: string, storagePolicy: AccountStoragePolicy): LoadedAccountCredentialRecord;
/**
 * Load stored credentials for a provider account.
 * Returns `null` when no account is configured for the given id.
 */
export declare function loadCredentials(provider: SubscriptionProvider, accountId?: string, storagePolicy?: AccountStoragePolicy): StoredCredentials | null;
/**
 * Delete stored credentials for a provider account.
 */
export declare function deleteCredentials(provider: SubscriptionProvider, accountId: string, storagePolicy: AccountStoragePolicy): void;
export declare function preflightProviderCredentialDeletion(providers: readonly AccountCredentialProvider[], storagePolicy: AccountStoragePolicy): AccountDeletionPlan;
/**
 * Delete every stored credential account for a provider.
 */
export declare function deleteProviderCredentials(provider: AccountCredentialProvider, storagePolicy: AccountStoragePolicy): number;
/**
 * Check if credentials exist and are not expired.
 */
export declare function hasValidCredentials(provider: AccountCredentialProvider, accountId?: string, storagePolicy?: AccountStoragePolicy): boolean;
/**
 * List all accounts configured for a provider.
 */
export declare function listProviderAccounts(provider: AccountCredentialProvider, storagePolicy?: AccountStoragePolicy): AccountCredentialRecord[];
/**
 * Get a valid access token, refreshing if needed.
 *
 * Refreshes are serialized per `{provider}:{accountId}` via
 * `accountRefreshMutex` so concurrent callers don't race on the
 * refresh-token grant or the credential file write.
 *
 * `opts.minRemainingMs` widens the refresh window: the token is refreshed
 * unless it has at least this much life left (instead of the default 5-minute
 * buffer). This lets a caller that is about to INJECT the token into a
 * long-running subprocess it cannot later refresh (e.g. a Claude coding spawn
 * with a bare `CLAUDE_CODE_OAUTH_TOKEN`) hand off a token that survives the
 * expected run duration.
 *
 * Returns `null` when no credentials are stored or refresh cannot yield a
 * usable token. Pass `opts.outcome: true` to receive a typed failure reason
 * instead of the legacy nullable token result.
 */
export declare function getAccessToken(provider: AccountCredentialProvider, accountId: string, opts: GetAccessTokenOutcomeOptions): Promise<AccessTokenOutcome>;
export declare function getAccessToken(provider: AccountCredentialProvider, accountId?: string, opts?: GetAccessTokenOptions): Promise<string | null>;
export type { SubscriptionCredentialSource } from "@elizaos/host/protocol";
/**
 * Per-account subscription status row used by the dashboard / API.
 *
 * One row is emitted per stored account for each provider. CLI- /
 * setup-token-derived sources also produce a row with a synthetic
 * `accountId` (e.g. `"claude-code-cli"`); those rows are read-only
 * (they cannot be deleted via `DELETE /api/subscription/{provider}`).
 */
export interface SubscriptionAccountStatus {
    provider: SubscriptionProvider;
    accountId: string;
    label: string;
    configured: boolean;
    valid: boolean;
    expiresAt: number | null;
    source: SubscriptionCredentialSource;
    available?: boolean;
    availabilityReason?: string;
    allowedClient?: string;
    loginHint?: string;
    billingMode?: "subscription-coding-plan" | "subscription-coding-cli";
}
export declare function getSubscriptionStatus(): SubscriptionAccountStatus[];
interface SubscriptionCredentialConfig {
    agents?: {
        defaults?: {
            subscriptionProvider?: string;
            model?: {
                primary?: string;
            };
        };
    };
}
/**
 * Local-only, synchronous part of subscription credential application.
 *
 * Reads stored accounts from disk and reports which coding-agent surfaces
 * they enable. `_config` is accepted for call-site compatibility; subscriptions
 * never mutate it. Performs no network
 * I/O, so it is safe to await on the blocking boot path. Local Claude Code
 * credential discovery is handled by {@link applySubscriptionCredentialsDeferred}.
 *
 * None of the Anthropic / Codex / Gemini / coding-plan branches mutate `config`
 * or `process.env` — they are purely informational logging. No subscription
 * sets `model.primary`: none has a runtime text handler.
 */
export declare function applySubscriptionCredentialsLocal(_config?: SubscriptionCredentialConfig): void;
/**
 * Apply subscription credentials to the environment.
 * Called at startup to make credentials available to elizaOS plugins.
 *
 * Combines local account diagnostics
 * ({@link applySubscriptionCredentialsLocal}) with local Claude Code credential
 * discovery ({@link applySubscriptionCredentialsDeferred}). Startup can call
 * either phase separately; API routes and hot reload use this combined form.
 *
 * **Claude subscription tokens are NOT applied to the runtime environment.**
 * Anthropic's TOS only permits Claude subscription tokens to be used through
 * the Claude Code CLI itself. Eliza honours this by keeping the token
 * available for the task-agent orchestrator (which spawns `claude` CLI
 * subprocesses) but never injecting it into `process.env.ANTHROPIC_API_KEY`.
 *
 * Codex / ChatGPT subscription tokens are also CLI credentials. They are used
 * by Codex task agents only, never injected into `OPENAI_API_KEY`.
 */
export declare function applySubscriptionCredentials(config?: SubscriptionCredentialConfig): Promise<void>;
/**
 * Discover locally stored Claude Code credentials for startup diagnostics.
 *
 * The CLI owns its credential lifecycle, including refreshing expired tokens.
 * Discovery reads its file without exchanging or importing credentials and
 * reports presence without claiming that the provider accepted the login.
 */
export declare function applySubscriptionCredentialsDeferred(): Promise<void>;
//# sourceMappingURL=credentials.d.ts.map