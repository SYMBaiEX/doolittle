/**
 * Async mutex keyed by string. Single in-flight operation per key.
 *
 * Used to serialize OAuth refresh attempts per `{providerId}:{accountId}`
 * pair so concurrent `getAccessToken` calls don't race on file writes
 * (and don't burn refresh-token grants).
 */
export declare class KeyedMutex {
    private readonly inflight;
    /**
     * Run `fn` while holding the lock for `key`. Concurrent callers with
     * the same key are queued and run strictly one at a time — they do NOT
     * share the result. The caller is expected to re-check state (e.g.
     * re-read credentials) after acquire.
     *
     * The queue is built synchronously: each acquirer chains off whatever
     * promise is currently registered for the key and immediately registers
     * itself as the new tail. Two callers arriving in the same tick observe
     * different predecessors, so they cannot run `fn` concurrently.
     */
    acquire<T>(key: string, fn: () => Promise<T>): Promise<T>;
}
export declare const accountRefreshMutex: KeyedMutex;
//# sourceMappingURL=refresh-mutex.d.ts.map