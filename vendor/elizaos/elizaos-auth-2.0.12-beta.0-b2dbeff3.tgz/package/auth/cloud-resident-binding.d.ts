/**
 * Framework-free controller for an on-device ("resident") agent's Eliza Cloud inference binding.
 *
 * The agent always runs on the device. This controller decides only whether Eliza Cloud
 * inference is bound to it, from the saved Cloud sign-in, the verified identity and the plan
 * Cloud reports, and applies that decision through host ports. It owns the rules a host must not
 * re-derive in its UI:
 *
 * - `admit`: one account and plan read. No saved sign-in, a rejected sign-in, a plan that ended or
 *   an unknown plan leaves inference unbound. A changed account between reads is refused.
 * - The offline rule: while Cloud is unreachable, a plan this same sign-in verified within
 *   `OFFLINE_PLAN_GRACE_MS` (7 days) and whose period has not ended keeps its binding (`kept`);
 *   otherwise inference is unbound. Cloud still decides every request once reachable.
 * - `apply`: binds or clears the provider and confirms the credential did not change meanwhile.
 *   A failed bind is cleared; a removal the host cannot confirm is reported as `unknown`.
 * - `requestRebind` (`ResidentRebindQueue`): at most one rebind runs; one more is queued behind it.
 * - `replaceCredential`: a new key revokes the key it replaces first (once, best effort) and only
 *   then stores the new one.
 * - `beginSignIn`: one sign-in step at a time; cancelling the step aborts it.
 *
 * Ports supply the credential store, provider bind/clear, identity, entitlement and the plan
 * admission record. Nothing here renders, names a product, or reads a credential's secret: the
 * controller sees only credential ids. Dependency-free on purpose so products can project this
 * single file from the pinned source; it avoids parameter properties so type stripping loads it.
 */
/** A verified Cloud billing mode within this window keeps its binding while Cloud is unreachable. */
export declare const OFFLINE_PLAN_GRACE_MS: number;
/** What a host stores to recognize a recent verified plan while Cloud is unreachable. */
export interface ResidentPlanAdmissionRecord<E extends string = string> {
    version: 1;
    environment: E;
    credentialId: string;
    userId: string;
    organizationId: string | null;
    status: "active" | "trialing" | "past_due" | "credit-funded";
    planName: string;
    verifiedAt: number;
    endsAt: number | null;
}
/** The saved sign-in, by id only. */
export interface ResidentCredentialRef {
    credentialId: string;
}
/** The identity Cloud verified for the saved sign-in. */
export interface ResidentIdentity {
    credentialId: string;
    userId: string;
    organizationId: string | null;
}
/** How the plan read decided, independent of any UI copy. */
export type ResidentPlanDecision = "admit" | "admit-with-warning" | "needs-plan" | "unknown";
/** One plan read for a verified identity. `outage` marks an unknown plan caused by a billing outage. */
export interface ResidentPlanCheck<V = unknown> {
    decision: ResidentPlanDecision;
    /** The host's plan view (for example a cloud-sdk SubscriptionView), returned unchanged. */
    view: V;
    /** True only when the plan is unknown because billing could not be read. */
    outage: boolean;
    /** What to record for an admitted plan; null when nothing should be recorded. */
    record: {
        status: ResidentPlanAdmissionRecord["status"];
        planName: string;
    } | null;
    /** End of the admitted plan window when Cloud reported one; null for no end; undefined when unknown. */
    endsAt?: number | null;
}
export type ResidentBinding = "cloud" | "unbound" | "kept";
/** Why the binding is what it is; hosts map these to their own copy. */
export type ResidentAdmissionReason = "admitted" | "signed-out" | "sign-in-rejected" | "account-changed" | "offline" | "needs-plan" | "plan-unavailable";
export interface ResidentAdmission<V = unknown> {
    binding: ResidentBinding;
    reason: ResidentAdmissionReason;
    /** Present once the identity was verified. */
    identity?: ResidentIdentity;
    /** Present once the plan was read. */
    plan?: ResidentPlanCheck<V>;
    /** The recent verified plan this sign-in holds, when one exists. */
    recent?: ResidentPlanAdmissionRecord | null;
    /** The plan window in effect: the reported end, else the recent record's end. */
    endsAt?: number | null;
    /** The underlying error for a rejected or unreachable read. */
    error?: unknown;
}
export interface ResidentApplyResult {
    binding: "cloud" | "unbound" | "kept" | "unknown";
    /** Set when binding failed (`cause`) or a removal could not be confirmed (`unconfirmed`). */
    failure?: {
        kind: "bind-failed" | "unbind-unconfirmed";
        cause?: unknown;
    };
}
export interface CloudResidentBindingPorts<V = unknown, E extends string = string> {
    /** The saved sign-in for this environment, or null when signed out. */
    readCredential(signal: AbortSignal): Promise<ResidentCredentialRef | null>;
    /** Verifies the saved sign-in with Cloud. Throws for a rejected or unreachable read. */
    verifyIdentity(signal: AbortSignal): Promise<ResidentIdentity>;
    /** One plan read for the verified identity. Throws for a rejected or unreachable read. */
    checkPlan(identity: ResidentIdentity, signal: AbortSignal): Promise<ResidentPlanCheck<V>>;
    /** Binds Cloud inference and optionally returns the opaque identity/generation
     * guard captured atomically for this invocation's applied or attached binding.
     * Legacy hosts can return void, but cannot perform automatic failed-bind cleanup. */
    bindProvider(credentialId: string, signal: AbortSignal): Promise<void | string>;
    /** Clears only the exact binding represented by the guard, checking it under
     * the host's existing lifecycle/storage lock before and after any shutdown.
     * A changed binding must remain untouched. Never implement with read-then-clear. */
    clearProviderIfCurrent?(bindingGuard: string, signal: AbortSignal): Promise<"cleared" | "changed">;
    /**
     * Removes any Cloud inference binding. Throws when the removal cannot be confirmed. `reason` is
     * `unbound` for a plain unbind (a host may skip work when nothing is stored) and `bind-failed`
     * after a bind that failed or was refused.
     */
    clearProvider(signal: AbortSignal, reason: "unbound" | "bind-failed"): Promise<void>;
    /** The stored plan admission record, already parsed; null when absent or unreadable. */
    readAdmission(): ResidentPlanAdmissionRecord<E> | null;
    /** Stores (or clears, with null) the plan admission record. Best effort. */
    writeAdmission(record: ResidentPlanAdmissionRecord<E> | null): void;
    /** A Cloud outage or no network: not a refusal of the account or the plan. */
    isUnreachable(error: unknown): boolean;
    /** A rejected sign-in, an entitlement for another account, or a changed account. */
    isSignInRejected(error: unknown): boolean;
    /** An error the host must rethrow from `apply` without clearing (for example a stop it could not confirm). */
    isFatalBindError?(error: unknown): boolean;
    now?(): number;
}
export declare class CloudResidentBindingError extends Error {
    readonly code: "account-changed" | "login-active";
    constructor(code: "account-changed" | "login-active");
}
/** Parses a stored admission record; anything malformed is null. */
export declare function parseResidentPlanAdmission<E extends string>(value: unknown, environmentAllowed: (environment: unknown) => environment is E): ResidentPlanAdmissionRecord<E> | null;
/**
 * The recent admitting plan this credential holds, or null: same environment and credential (and
 * user, when given), verified within the grace window, and its period not ended.
 */
export declare function recentResidentPlanAdmission<E extends string>(record: ResidentPlanAdmissionRecord<E> | null, environment: E, credentialId: string | undefined, userId: string | undefined, now: number): ResidentPlanAdmissionRecord<E> | null;
/**
 * At most one rebind of the running resident runs; one more is queued behind it and further
 * requests coalesce. A host whose admission controller is short-lived (one per account read) keeps
 * one of these for the life of the resident so the rule survives across admissions.
 *
 * Every caller learns the outcome of the run that serves it: a request that runs now gets that
 * run's promise; a request that coalesces into the queued run gets the queued run's promise, which
 * resolves or rejects with that run's own result. Nothing is swallowed.
 */
export declare class ResidentRebindQueue {
    private running;
    private next;
    private wanted;
    /**
     * Runs `rebind` now, or queues it behind the running one. `blocked` lets the host defer the run
     * (another operation is in progress); call `resume` once that ends. The queued run uses the
     * latest coalesced caller's `rebind` and `blocked`. The returned promise settles with the run
     * that serves this call; a deferred request settles once the host resumes it.
     */
    request(rebind: () => Promise<void>, blocked?: () => boolean): Promise<void>;
    /** Whether a rebind is waiting for the current work to end. */
    get pending(): boolean;
    /** Whether a rebind is running now. */
    get active(): boolean;
    /** Marks a rebind as wanted without running it (the host runs it with `resume` once idle). */
    queue(): void;
    /**
     * Runs a wanted or queued rebind with the host's `rebind` when nothing is running and nothing
     * blocks it. Callers that coalesced into the queued run receive this run's outcome.
     */
    resume(rebind: () => Promise<void>, blocked?: () => boolean): Promise<void> | undefined;
    /** Starts `rebind` now; a queued request it supersedes settles with this run. */
    private runNow;
    private start;
    /**
     * Starts the queued run once the running one settles, unless the host is still busy. A
     * flag-only `queue()` has no caller to report to, so it waits for the host's `resume`.
     */
    private drain;
}
export declare class CloudResidentBindingController<V = unknown, E extends string = string> {
    private readonly rebinds;
    private signIn;
    readonly environment: E;
    private readonly ports;
    constructor(environment: E, ports: CloudResidentBindingPorts<V, E>);
    private now;
    /** The recent verified plan for this sign-in (the 7-day offline rule), or null. */
    recentAdmission(credentialId: string | undefined, userId?: string): ResidentPlanAdmissionRecord<E> | null;
    /** Records a verified admitting plan for the offline rule. */
    recordAdmission(identity: ResidentIdentity, record: NonNullable<ResidentPlanCheck["record"]>, endsAt: number | null): void;
    /** Cloud reported the plan ended: the offline rule no longer applies to it. */
    forgetAdmission(): void;
    private offline;
    private assertSameCredential;
    /**
     * Reads the saved sign-in, identity and plan and decides the inference binding only. It never
     * decides whether the agent runs.
     */
    admit(signal: AbortSignal): Promise<ResidentAdmission<V>>;
    /** Binds or unbinds Cloud inference before the agent starts. Returns the binding in effect. */
    apply(admission: Pick<ResidentAdmission<V>, "binding" | "identity">, signal: AbortSignal): Promise<ResidentApplyResult>;
    /** Runs `rebind` now or queues it; see `ResidentRebindQueue.request`. */
    requestRebind(rebind: () => Promise<void>, blocked?: () => boolean): Promise<void>;
    /** Whether a rebind is waiting for the current work to end. */
    get rebindPending(): boolean;
    /** Marks a rebind as wanted without running it (the host runs it once idle). */
    queueRebind(): void;
    /** Runs a queued rebind when nothing blocks it. */
    resumeQueued(rebind: () => Promise<void>, blocked?: () => boolean): Promise<void> | undefined;
    /**
     * Starts one sign-in step. Throws `login-active` while another runs. The returned signal aborts
     * when the caller's signal aborts or `cancelSignIn` is called; `end` must be called when done.
     */
    beginSignIn(signal: AbortSignal): {
        signal: AbortSignal;
        end: () => void;
    };
    /** Whether a sign-in step is running. */
    get signInActive(): boolean;
    /** Cancels the running sign-in step, if any. The stored sign-in is left as it was. */
    cancelSignIn(reason?: unknown): void;
    /**
     * Stores a newly issued sign-in. A different key already saved is revoked first (once, best
     * effort; a failed or unconfirmed revocation never blocks the new sign-in), then the new key is
     * written. Returns what happened to the replaced key; undefined when nothing was replaced.
     */
    static replaceCredential<C>(input: {
        read: () => Promise<C | null>;
        same: (previous: C, issued: C) => boolean;
        revoke: (previous: C, signal: AbortSignal) => Promise<boolean>;
        write: (issued: C, signal: AbortSignal) => Promise<void>;
    }, issued: C, signal: AbortSignal): Promise<"revoked" | "unconfirmed" | undefined>;
}
//# sourceMappingURL=cloud-resident-binding.d.ts.map