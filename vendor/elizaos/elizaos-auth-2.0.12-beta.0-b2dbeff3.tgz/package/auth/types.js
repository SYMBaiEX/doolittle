/**
 * Subscription auth types for eliza.
 */
import { codingProviderEnrollmentAvailability, codingProviderSubscriptionAuthMode, codingProviderSubscriptionBillingMode, } from "@elizaos/contracts";
export const SUBSCRIPTION_PROVIDER_IDS = [
    "anthropic-subscription",
    "openai-codex",
    "gemini-cli",
    "zai-coding",
    "kimi-coding",
    "deepseek-coding",
];
export const OAUTH_SUBSCRIPTION_PROVIDER_IDS = [
    "anthropic-subscription",
    "openai-codex",
];
export const CODING_PLAN_KEY_SUBSCRIPTION_PROVIDER_IDS = [
    "zai-coding",
    "kimi-coding",
];
export const EXTERNAL_CLI_SUBSCRIPTION_PROVIDER_IDS = [
    "gemini-cli",
];
export const UNAVAILABLE_SUBSCRIPTION_PROVIDER_IDS = [
    "deepseek-coding",
];
export const DIRECT_ACCOUNT_PROVIDER_IDS = [
    "anthropic-api",
    "openai-api",
    "deepseek-api",
    "zai-api",
    "moonshot-api",
    "cerebras-api",
    "openrouter-api",
    "xai-api",
];
export const ACCOUNT_CREDENTIAL_PROVIDER_IDS = [
    ...SUBSCRIPTION_PROVIDER_IDS,
    ...DIRECT_ACCOUNT_PROVIDER_IDS,
];
export function isSubscriptionProvider(value) {
    return (typeof value === "string" &&
        SUBSCRIPTION_PROVIDER_IDS.includes(value));
}
export function isDirectAccountProvider(value) {
    return (typeof value === "string" &&
        DIRECT_ACCOUNT_PROVIDER_IDS.includes(value));
}
export function isOAuthSubscriptionProvider(value) {
    return (typeof value === "string" &&
        OAUTH_SUBSCRIPTION_PROVIDER_IDS.includes(value));
}
export function isCodingPlanKeySubscriptionProvider(value) {
    return (typeof value === "string" &&
        CODING_PLAN_KEY_SUBSCRIPTION_PROVIDER_IDS.includes(value));
}
export function isExternalCliSubscriptionProvider(value) {
    return (typeof value === "string" &&
        EXTERNAL_CLI_SUBSCRIPTION_PROVIDER_IDS.includes(value));
}
export function isUnavailableSubscriptionProvider(value) {
    return (typeof value === "string" &&
        UNAVAILABLE_SUBSCRIPTION_PROVIDER_IDS.includes(value));
}
export function isAccountCredentialProvider(value) {
    return (typeof value === "string" &&
        ACCOUNT_CREDENTIAL_PROVIDER_IDS.includes(value));
}
export const DIRECT_ACCOUNT_PROVIDER_ENV = {
    "anthropic-api": "ANTHROPIC_API_KEY",
    "openai-api": "OPENAI_API_KEY",
    "deepseek-api": "DEEPSEEK_API_KEY",
    "zai-api": "ZAI_API_KEY",
    "moonshot-api": "MOONSHOT_API_KEY",
    "cerebras-api": "CEREBRAS_API_KEY",
    "openrouter-api": "OPENROUTER_API_KEY",
    "xai-api": "XAI_API_KEY",
};
/** Direct accounts served through the OpenAI-compatible credential bridge. */
export const OPENAI_COMPAT_BASE_BY_DIRECT_PROVIDER = {
    "moonshot-api": "https://api.moonshot.ai/v1",
    "openrouter-api": "https://openrouter.ai/api/v1",
    "xai-api": "https://api.x.ai/v1",
};
/** Maps subscription provider IDs to their model provider short names. */
export const SUBSCRIPTION_PROVIDER_MAP = {
    "anthropic-subscription": "anthropic",
    "openai-codex": "codex-cli",
    "gemini-cli": "gemini-cli",
    "zai-coding": "zai-coding",
    "kimi-coding": "kimi-coding",
    "deepseek-coding": "deepseek-coding",
};
export const CODING_PLAN_PROVIDER_BASE_URL = {
    "zai-coding": "https://api.z.ai/api/coding/paas/v4",
    "kimi-coding": "https://api.kimi.com/coding/v1",
};
export const SUBSCRIPTION_PROVIDER_METADATA = {
    "anthropic-subscription": {
        providerId: "anthropic-subscription",
        displayName: "Claude Subscription",
        selectionIds: ["anthropic-subscription"],
        allowedClient: "Claude Code CLI",
        billingMode: codingProviderSubscriptionBillingMode("anthropic-subscription"),
        authMode: codingProviderSubscriptionAuthMode("anthropic-subscription"),
        availability: codingProviderEnrollmentAvailability("anthropic-subscription"),
        setupHint: "Sign in through the app or run claude auth login.",
        directProviderId: "anthropic-api",
    },
    "openai-codex": {
        providerId: "openai-codex",
        displayName: "OpenAI Codex",
        selectionIds: ["openai-subscription"],
        allowedClient: "Codex CLI",
        billingMode: codingProviderSubscriptionBillingMode("openai-codex"),
        authMode: codingProviderSubscriptionAuthMode("openai-codex"),
        availability: codingProviderEnrollmentAvailability("openai-codex"),
        setupHint: "Sign in through the app or run codex login.",
        directProviderId: "openai-api",
    },
    "gemini-cli": {
        providerId: "gemini-cli",
        displayName: "Gemini CLI",
        selectionIds: ["gemini-subscription"],
        allowedClient: "Gemini CLI",
        billingMode: codingProviderSubscriptionBillingMode("gemini-cli"),
        authMode: codingProviderSubscriptionAuthMode("gemini-cli"),
        availability: codingProviderEnrollmentAvailability("gemini-cli"),
        setupHint: "Run gemini auth login; tokens are not imported into API env vars.",
    },
    "zai-coding": {
        providerId: "zai-coding",
        displayName: "z.ai Coding Plan",
        selectionIds: ["zai-coding-subscription"],
        allowedClient: "z.ai Coding endpoint",
        billingMode: codingProviderSubscriptionBillingMode("zai-coding"),
        authMode: codingProviderSubscriptionAuthMode("zai-coding"),
        availability: codingProviderEnrollmentAvailability("zai-coding"),
        setupHint: "Add a z.ai Coding Plan credential for the dedicated coding endpoint.",
        directProviderId: "zai-api",
        defaultBaseUrl: CODING_PLAN_PROVIDER_BASE_URL["zai-coding"],
        probePath: "/models",
    },
    "kimi-coding": {
        providerId: "kimi-coding",
        displayName: "Kimi Coding Endpoint Key",
        selectionIds: ["kimi-coding-subscription"],
        allowedClient: "Kimi Code endpoint",
        billingMode: codingProviderSubscriptionBillingMode("kimi-coding"),
        authMode: codingProviderSubscriptionAuthMode("kimi-coding"),
        availability: codingProviderEnrollmentAvailability("kimi-coding"),
        setupHint: "Add a Kimi coding-endpoint key for model inference. Kimi ACP uses a separate kimi login OAuth session.",
        directProviderId: "moonshot-api",
        defaultBaseUrl: CODING_PLAN_PROVIDER_BASE_URL["kimi-coding"],
        probePath: "/models",
    },
    "deepseek-coding": {
        providerId: "deepseek-coding",
        displayName: "DeepSeek Coding Plan",
        selectionIds: ["deepseek-coding-subscription"],
        allowedClient: "Unavailable",
        billingMode: codingProviderSubscriptionBillingMode("deepseek-coding"),
        authMode: codingProviderSubscriptionAuthMode("deepseek-coding"),
        availability: codingProviderEnrollmentAvailability("deepseek-coding"),
        setupHint: "Use the DeepSeek direct API-key provider if you have API billing.",
        directProviderId: "deepseek-api",
        availabilityReason: "No first-party DeepSeek coding subscription surface is available to integrate without substituting general API billing.",
    },
};
export function getSubscriptionProviderMetadata(provider) {
    return SUBSCRIPTION_PROVIDER_METADATA[provider];
}
//# sourceMappingURL=types.js.map