/**
 * OpenAI Codex (ChatGPT Plus/Pro subscription) OAuth flow
 *
 * Uses inlined OAuth (vendored helpers).
 * Handles local callback server + manual code paste fallback.
 */
import type { OAuthCredentials } from "./types.js";
export interface CodexFlow {
    authUrl: string;
    state: string;
    /** Submit a manually-pasted code/URL */
    submitCode: (code: string) => void;
    /** Wait for credentials (either via callback server or manual code) */
    credentials: Promise<OAuthCredentials>;
    /** Close the callback server */
    close: () => void;
}
/**
 * Start the OpenAI Codex OAuth flow.
 * Starts a local callback server on port 1455 and returns the auth URL.
 */
export declare function startCodexLogin(): Promise<CodexFlow>;
/**
 * Refresh an expired OpenAI Codex token.
 */
export declare function refreshCodexToken(refreshToken: string): Promise<OAuthCredentials>;
//# sourceMappingURL=openai-codex.d.ts.map