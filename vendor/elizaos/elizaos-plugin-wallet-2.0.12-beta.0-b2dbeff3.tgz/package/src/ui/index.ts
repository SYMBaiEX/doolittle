// UI barrel for hosts that import "@elizaos/plugin-wallet/ui".

export { useWalletState } from "@elizaos/ui";
export { registerApp } from "../register.ts";
export { InventoryAppView } from "./components/InventoryAppView.tsx";
export { InventoryView } from "./InventoryView.tsx";
export { ChainIcon } from "./inventory/ChainIcon.tsx";
export {
  CHAIN_CONFIGS,
  type ChainConfig,
  type ChainKey,
  chainKeyToWalletRpcChain,
  getChainConfig,
  getContractLogoUrl,
  getExplorerTokenUrl,
  getExplorerTxUrl,
  getNativeLogoUrl,
  getStablecoinAddress,
  PRIMARY_CHAIN_KEYS,
  resolveChainKey,
} from "./inventory/chainConfig.ts";
export {
  BSC_GAS_READY_THRESHOLD,
  BSC_GAS_THRESHOLD,
  HEX_ADDRESS_RE,
  isAvaxChainName,
  isBscChainName,
  type NftItem,
  type TokenRow,
  toNormalizedAddress,
} from "./inventory/constants.ts";
export { TokenLogo } from "./inventory/TokenLogo.tsx";
export { useInventoryData } from "./inventory/useInventoryData.ts";
export { walletAppPlugin } from "./plugin.ts";
export {
  buildWalletRpcUpdateRequest,
  resolveInitialWalletRpcSelections,
} from "./wallet-rpc.ts";
export { WALLET_STATUS_WIDGET } from "./widgets/wallet-status.helpers.ts";
export { WalletStatusSidebarWidget } from "./widgets/wallet-status.tsx";
