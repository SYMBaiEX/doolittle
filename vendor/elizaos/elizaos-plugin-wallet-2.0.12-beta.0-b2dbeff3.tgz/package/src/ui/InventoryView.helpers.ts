// Shared wallet data helpers for InventoryView and the `interact` capability
// handler. Kept out of the .tsx so that file exports only React components and
// stays Fast-Refresh-compatible in dev.
// Shared wallet data helpers for InventoryView and the `interact` capability
// handler. Kept out of the .tsx so that file exports only React components and
// stays Fast-Refresh-compatible in dev.
import type {
  WalletAddresses,
  WalletBalancesResponse,
  WalletConfigStatus,
} from "@elizaos/contracts";
import { client } from "@elizaos/ui";
import { parseFiniteAmount } from "./inventory/constants.ts";

export function resolveWalletAddresses({
  walletAddresses,
  walletConfig,
}: {
  walletAddresses: WalletAddresses | null;
  walletConfig: WalletConfigStatus | null;
}): {
  evmAddress: string | null;
  solanaAddress: string | null;
} {
  return {
    evmAddress: walletAddresses?.evmAddress ?? walletConfig?.evmAddress ?? null,
    solanaAddress:
      walletAddresses?.solanaAddress ?? walletConfig?.solanaAddress ?? null,
  };
}

export function parseUsd(value: string | number | null | undefined): number {
  return parseFiniteAmount(value);
}

export function summarizeWalletBalances(
  walletBalances: WalletBalancesResponse | null,
): {
  totalUsd: number;
  tokens: Array<{
    chain: string;
    symbol: string;
    name: string;
    contractAddress: string | null;
    balance: string;
    valueUsd: number;
    isNative: boolean;
  }>;
  chainErrors: Array<{ chain: string; error: string }>;
} {
  const tokens: Array<{
    chain: string;
    symbol: string;
    name: string;
    contractAddress: string | null;
    balance: string;
    valueUsd: number;
    isNative: boolean;
  }> = [];
  const chainErrors: Array<{ chain: string; error: string }> = [];

  for (const chain of walletBalances?.evm?.chains ?? []) {
    const nativeValueUsd = parseUsd(chain.nativeValueUsd);
    tokens.push({
      chain: chain.chain,
      symbol: chain.nativeSymbol,
      name: `${chain.chain} native`,
      contractAddress: null,
      balance: chain.nativeBalance,
      valueUsd: nativeValueUsd,
      isNative: true,
    });
    if (chain.error) {
      chainErrors.push({ chain: chain.chain, error: chain.error });
      continue;
    }
    for (const token of chain.tokens) {
      tokens.push({
        chain: chain.chain,
        symbol: token.symbol,
        name: token.name,
        contractAddress: token.contractAddress,
        balance: token.balance,
        valueUsd: parseUsd(token.valueUsd),
        isNative: false,
      });
    }
  }

  if (walletBalances?.solana) {
    tokens.push({
      chain: "Solana",
      symbol: "SOL",
      name: "Solana native",
      contractAddress: null,
      balance: walletBalances.solana.solBalance,
      valueUsd: parseUsd(walletBalances.solana.solValueUsd),
      isNative: true,
    });
    for (const token of walletBalances.solana.tokens) {
      tokens.push({
        chain: "Solana",
        symbol: token.symbol,
        name: token.name,
        contractAddress: token.mint,
        balance: token.balance,
        valueUsd: parseUsd(token.valueUsd),
        isNative: false,
      });
    }
  }

  tokens.sort(
    (a, b) =>
      (Number.isFinite(b.valueUsd) ? b.valueUsd : 0) -
      (Number.isFinite(a.valueUsd) ? a.valueUsd : 0),
  );
  return {
    totalUsd: tokens.reduce((sum, token) => sum + token.valueUsd, 0),
    tokens,
    chainErrors,
  };
}

export async function loadWalletViewState() {
  const [
    walletAddresses,
    walletConfig,
    walletBalances,
    walletNfts,
    marketOverview,
  ] = await Promise.all([
    client.getWalletAddresses(),
    client.getWalletConfig(),
    client.getWalletBalances(),
    client.getWalletNfts(),
    client.getWalletMarketOverview(),
  ]);
  const summary = summarizeWalletBalances(walletBalances);
  return {
    walletAddresses,
    walletConfig,
    walletBalances,
    walletNfts,
    marketOverview,
    summary,
  };
}
