/**
 * `WalletBackend` implementation backed by Steward, the cloud/mobile
 * multi-tenant signing service — used when `ELIZA_WALLET_BACKEND=steward` or
 * (in `auto` mode) when the agent is cloud-provisioned. Dynamically imports
 * `@elizaos/app-steward` at construction time (avoiding a devDependency
 * cycle) to init the EVM account and fetch vault chain addresses; throws
 * `StewardUnavailableError` if the module can't be loaded or Steward env
 * config (`STEWARD_API_URL`/`STEWARD_AGENT_TOKEN`/`STEWARD_AGENT_ID`) is
 * missing. Solana addresses may be exposed when Steward's vault endpoint
 * returns them, but Solana transaction signing is not yet wired here —
 * `getSolanaSigner()` always throws.
 */
import type { IAgentRuntime } from "@elizaos/core";
import { type DevCloudStewardOperationalTuple } from "@elizaos/plugin-elizacloud/cloud-config/dev-cloud-env-authority";
import { PublicKey } from "@solana/web3.js";
import type { Account, Hex, TypedDataDefinition } from "viem";
import { hexToBytes } from "viem";
import type { WalletAddresses, WalletBackend } from "./backend.js";
import { StewardUnavailableError } from "./errors.js";
import type { SignResult, SignScope } from "./pending.js";

/**
 * Structural stand-in for viem `Account` produced by Steward — avoids incompatible
 * nominal `Account` types when multiple `viem` copies resolve in the workspace.
 */
interface StewardEvmAccountBinding {
  readonly address: `0x${string}`;
  signMessage?(parameters: {
    message: string | { raw: Uint8Array | string };
  }): Promise<Hex>;
  signTypedData?(typedData: TypedDataDefinition): Promise<Hex>;
}

/**
 * Shape of the dynamically imported @elizaos/app-steward module. Defined
 * locally to avoid a devDependency cycle with app-steward.
 */
interface StewardEvmAccountModule {
  initStewardEvmAccount(): Promise<StewardEvmAccountBinding | null>;
  resolveStewardEvmConfig(): {
    apiUrl: string;
    agentToken: string;
    agentId: string;
  } | null;
  fetchStewardVaultChainAddresses(
    apiUrl: string,
    agentToken: string,
    agentId: string,
  ): Promise<{ evm: `0x${string}` | null; solana: string | null }>;
}

const STEWARD_MODULE_ID = ["@elizaos", "app-steward"].join("/");
const STEWARD_ENV_KEYS = [
  "STEWARD_API_URL",
  "STEWARD_TENANT_ID",
  "STEWARD_AGENT_ID",
  "ELIZA_STEWARD_AGENT_ID",
  "STEWARD_API_KEY",
  "STEWARD_AGENT_TOKEN",
] as const;

let stewardProjectionTail = Promise.resolve();

/** @internal Exported for deterministic authority-boundary tests. */
export async function withProjectedStewardAuthority<T>(
  tuple: Extract<DevCloudStewardOperationalTuple, { enabled: true }>,
  operation: () => Promise<T>,
): Promise<T> {
  const predecessor = stewardProjectionTail;
  let release = (): void => {};
  stewardProjectionTail = new Promise<void>((resolve) => {
    release = resolve;
  });
  await predecessor;

  const saved = Object.fromEntries(
    STEWARD_ENV_KEYS.map((key) => [key, process.env[key]]),
  ) as Record<(typeof STEWARD_ENV_KEYS)[number], string | undefined>;
  const projected: Record<
    (typeof STEWARD_ENV_KEYS)[number],
    string | undefined
  > = {
    STEWARD_API_URL: tuple.apiUrl,
    STEWARD_TENANT_ID: tuple.tenantId,
    STEWARD_AGENT_ID: tuple.agentId,
    ELIZA_STEWARD_AGENT_ID: tuple.agentId,
    STEWARD_API_KEY: tuple.apiKey,
    STEWARD_AGENT_TOKEN: tuple.agentToken,
  };

  try {
    for (const key of STEWARD_ENV_KEYS) {
      const value = projected[key];
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
    return await operation();
  } finally {
    for (const key of STEWARD_ENV_KEYS) {
      const value = saved[key];
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
    release();
  }
}

/**
 * Cloud / mobile signing via Steward for EVM. Solana addresses may be exposed from
 * Steward when `/vault/.../addresses` returns them; Solana **transaction** signing is
 * unavailable here — callers must treat Solana writes as unavailable until wired.
 */
export class StewardBackend implements WalletBackend {
  readonly kind = "steward" as const;

  private readonly account: StewardEvmAccountBinding;

  private readonly solanaPubkey: PublicKey | null;

  private constructor(
    account: StewardEvmAccountBinding,
    solanaPubkey: PublicKey | null,
  ) {
    this.account = account;
    this.solanaPubkey = solanaPubkey;
  }

  static async create(
    _runtime: IAgentRuntime,
    authorityTuple?: Extract<
      DevCloudStewardOperationalTuple,
      { enabled: true }
    >,
  ): Promise<StewardBackend> {
    void _runtime;
    if (authorityTuple) {
      return withProjectedStewardAuthority(authorityTuple, () =>
        StewardBackend.createUnmanaged(),
      );
    }
    return StewardBackend.createUnmanaged();
  }

  private static async createUnmanaged(): Promise<StewardBackend> {
    let steward: StewardEvmAccountModule;
    try {
      steward = (await import(STEWARD_MODULE_ID)) as StewardEvmAccountModule;
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      throw new StewardUnavailableError(
        `Cannot load Steward wallet module (@elizaos/app-steward): ${detail}`,
      );
    }

    const account = await steward.initStewardEvmAccount();
    if (!account) {
      throw new StewardUnavailableError(
        "Steward EVM account initialization failed. Set STEWARD_API_URL, STEWARD_AGENT_TOKEN, and STEWARD_AGENT_ID (or a JWT whose payload contains agentId/sub).",
      );
    }

    const cfg = steward.resolveStewardEvmConfig();
    if (!cfg) {
      throw new StewardUnavailableError(
        "Steward env configuration resolved to null after account init.",
      );
    }

    const chains = await steward.fetchStewardVaultChainAddresses(
      cfg.apiUrl,
      cfg.agentToken,
      cfg.agentId,
    );

    let solanaPubkey: PublicKey | null = null;
    if (chains.solana) {
      try {
        solanaPubkey = new PublicKey(chains.solana);
      } catch {
        solanaPubkey = null;
      }
    }

    return new StewardBackend(
      account as StewardEvmAccountBinding,
      solanaPubkey,
    );
  }

  getAddresses(): WalletAddresses {
    return {
      evm: this.account.address as WalletAddresses["evm"],
      solana: this.solanaPubkey,
    };
  }

  canSign(chainHint: "evm" | "solana" | "off-chain"): boolean {
    if (chainHint === "solana") {
      return false;
    }
    return true;
  }

  getEvmAccount(_chainId: number): Account {
    void _chainId;
    return this.account as Account;
  }

  getSolanaSigner(): never {
    throw new StewardUnavailableError(
      "Solana transaction signing via Steward is unavailable in this runtime yet.",
    );
  }

  async signMessage(scope: SignScope, message: Hex): Promise<SignResult> {
    void scope;
    const signMessage = this.account.signMessage?.bind(this.account);
    if (!signMessage) {
      throw new StewardUnavailableError(
        "Steward EVM account does not expose signMessage.",
      );
    }
    const sig = await signMessage({
      message: { raw: hexToBytes(message) },
    });
    return { kind: "signature", signature: sig };
  }

  async signTypedData(
    scope: SignScope,
    typedData: TypedDataDefinition,
  ): Promise<SignResult> {
    void scope;
    const signTypedData = this.account.signTypedData?.bind(this.account);
    if (!signTypedData) {
      throw new StewardUnavailableError(
        "Steward EVM account does not expose signTypedData.",
      );
    }
    const sig = await signTypedData(typedData);
    return { kind: "signature", signature: sig };
  }
}
