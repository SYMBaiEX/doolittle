/**
 * Pure trade safety utilities — no heavy dependencies.
 * Extracted so they can be unit-tested without pulling in the full server.
 */

export type { TradePermissionMode } from "@elizaos/contracts";

import type { TradePermissionMode } from "@elizaos/contracts";

/** Maximum number of autonomous agent trades allowed per calendar day. */
export const AGENT_AUTO_MAX_DAILY_TRADES = 25;

/** Maximum age of a trade quote before it is considered stale. */
export const QUOTE_MAX_AGE_MS = 60_000; // 60 seconds

/** Tracks autonomous trade count for rate-limiting in agent-auto mode. */
export const agentAutoDailyTrades = { count: 0, resetDate: "" };

export function getAgentAutoTradeDate(): string {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Record an autonomous agent trade. Returns true if allowed, false if
 * the daily limit has been reached. Resets the counter on a new calendar day.
 */
export function recordAgentAutoTrade(log?: (msg: string) => void): boolean {
  const today = getAgentAutoTradeDate();
  if (agentAutoDailyTrades.resetDate !== today) {
    agentAutoDailyTrades.count = 0;
    agentAutoDailyTrades.resetDate = today;
  }
  if (agentAutoDailyTrades.count >= AGENT_AUTO_MAX_DAILY_TRADES) {
    log?.(
      `[trade] Agent-auto daily trade limit reached (${AGENT_AUTO_MAX_DAILY_TRADES}). Rejecting autonomous trade.`,
    );
    return false;
  }
  agentAutoDailyTrades.count += 1;
  log?.(
    `[trade] Agent-auto autonomous trade ${agentAutoDailyTrades.count}/${AGENT_AUTO_MAX_DAILY_TRADES} for ${today}`,
  );
  return true;
}

export interface LocalTradeExecutionOptions {
  consumeAgentQuota?: boolean;
}

/**
 * Returns true if local-key execution is permitted for the given actor.
 */
export function canUseLocalTradeExecution(
  mode: TradePermissionMode,
  isAgent: boolean,
  log?: (msg: string) => void,
  options: LocalTradeExecutionOptions = {},
): boolean {
  if (mode === "agent-auto") {
    if (isAgent) {
      if (options.consumeAgentQuota === false) {
        const today = getAgentAutoTradeDate();
        if (agentAutoDailyTrades.resetDate !== today) {
          return true;
        }
        return agentAutoDailyTrades.count < AGENT_AUTO_MAX_DAILY_TRADES;
      }
      return recordAgentAutoTrade(log);
    }
    return true;
  }
  if (mode === "manual-local-key") return !isAgent;
  return false;
}

/**
 * Assert that a trade quote is still fresh. Fails closed: a missing or
 * non-finite `quotedAt` cannot be proven fresh and is rejected, as is any
 * quote older than QUOTE_MAX_AGE_MS.
 */
export function assertQuoteFresh(
  quotedAt: number | undefined,
  now: number = Date.now(),
): void {
  if (typeof quotedAt !== "number" || !Number.isFinite(quotedAt)) {
    throw new Error(
      "Quote is missing a timestamp — please request a fresh quote",
    );
  }
  const age = now - quotedAt;
  if (age > QUOTE_MAX_AGE_MS || age < 0) {
    throw new Error("Quote expired — please request a fresh quote");
  }
}

export function resolveTradePermissionMode(config: {
  features?: { tradePermissionMode?: unknown } | null;
}): TradePermissionMode {
  const raw = config.features?.tradePermissionMode;
  if (
    raw === "user-sign-only" ||
    raw === "manual-local-key" ||
    raw === "agent-auto"
  ) {
    return raw;
  }
  return "user-sign-only";
}
