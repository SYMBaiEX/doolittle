/**
 * Top-level signing and chain-routing service for the wallet plugin. On
 * start it resolves the active {@link WalletBackend} (local EOA or Steward,
 * via `resolveWalletBackend`) and registers all default chain handlers
 * (`registerDefaultWalletChainHandlers`). `routeWalletAction` is the single
 * entry point every wallet subaction (`transfer`, `swap`, `bridge`, `gov`,
 * `pump_fun_buy`, …) dispatches through: it resolves the chain handler by
 * alias, validates required params, and for `mode="simulate"` requests
 * dispatches to the handler's optional `simulate()` (typed
 * `SIMULATION_UNSUPPORTED` failure when the handler does not opt in — never a
 * fallback to the `prepare` echo or to `execute()`). For `dryRun`/
 * `mode=prepare` requests it returns metadata without invoking the handler's
 * `execute()` (bridge is an exception — it always calls `execute()` so
 * Li.Fi/CCTP routing can surface a real quote). If backend resolution fails
 * at boot, the service still starts so metadata/dry-run stays available;
 * `getWalletBackend()` throws the captured error only when a caller actually
 * needs signing. `execute` requests are refused when the wallet the user sees
 * is not the one the chain handlers would sign with (`getExecutionRefusal`):
 * Steward is selected but did not load, or the chain's primary wallet is the
 * Eliza Cloud one. The handlers sign with the runtime's local keys, which
 * belong to a different wallet. `preflightWalletAction` applies the same
 * refusal so it lands before the spend confirmation, not after it.
 */
import {
  type IAgentRuntime,
  type ITokenDataService,
  type IWalletService,
  Service,
  ServiceType,
} from "@elizaos/core";
import { validateWalletBridgeParams } from "../chains/evm/bridge-router.js";
import { validateWalletGovParams } from "../chains/evm/gov-router.js";
import {
  registerDefaultWalletChainHandlers,
  validateWalletPumpFunBuyParams,
  validateWalletTokenParams,
  validateWalletTransferParams,
} from "../chains/registry.js";
import type {
  WalletChainHandler,
  WalletChainHandlerMetadata,
  WalletRouterContext,
  WalletRouterFailure,
  WalletRouterParams,
  WalletRouterResult,
  WalletRouterSubaction,
  WalletSignerMetadata,
} from "../types/wallet-router.js";
import { normalizeWalletChainKey } from "../types/wallet-router.js";
import type { WalletBackend } from "../wallet/backend.js";
import { StewardUnavailableError } from "../wallet/errors.js";
import { resolveWalletBackend } from "../wallet/select-backend.js";
import "../core-augmentation.js";

export const WALLET_BACKEND_SERVICE_TYPE = "wallet-backend" as const;

/** Settings that hold the primary wallet source (`local` / `cloud`) per chain family. */
const PRIMARY_WALLET_SOURCE_SETTING = {
  evm: { key: "WALLET_SOURCE_EVM", label: "EVM" },
  solana: { key: "WALLET_SOURCE_SOLANA", label: "Solana" },
} as const;

/**
 * Runtime service exposing {@link WalletBackend}. Retrieve via
 * `runtime.getService("wallet-backend")`.
 */
export class WalletBackendService extends Service {
  static override serviceType = WALLET_BACKEND_SERVICE_TYPE;

  override capabilityDescription =
    "Wallet backend and chain router (EVM + Solana, local or Steward)";

  private backend: WalletBackend | null = null;
  private backendLoadError: unknown = null;
  private readonly handlers = new Map<string, WalletChainHandler>();
  private readonly aliases = new Map<string, string>();

  static override async start(
    runtime: IAgentRuntime,
  ): Promise<WalletBackendService> {
    const svc = new WalletBackendService(runtime);
    try {
      svc.backend = await resolveWalletBackend(runtime);
    } catch (error) {
      svc.backend = null;
      svc.backendLoadError = error;
      runtime.logger.warn(
        {
          error: error instanceof Error ? error.message : String(error),
        },
        "Wallet backend unavailable; wallet router will expose metadata and dry-run only until signing is configured",
      );
    }
    registerDefaultWalletChainHandlers(svc, runtime);
    return svc;
  }

  getWalletBackend(): WalletBackend {
    if (!this.backend) {
      if (this.backendLoadError instanceof Error) {
        throw this.backendLoadError;
      }
      throw new Error("Wallet backend is not configured");
    }
    return this.backend;
  }

  getWalletBackendOrNull(): WalletBackend | null {
    return this.backend;
  }

  registerChainHandler(handler: WalletChainHandler): void {
    const key = normalizeWalletChainKey(handler.chain);
    this.handlers.set(key, handler);

    const aliases = new Set<string>([
      handler.chain,
      handler.chainId,
      handler.name,
      ...handler.aliases,
    ]);
    for (const alias of aliases) {
      this.aliases.set(normalizeWalletChainKey(alias), key);
    }
  }

  listChainHandlers(): WalletChainHandlerMetadata[] {
    return [...this.handlers.values()].map((handler) =>
      this.toMetadata(handler),
    );
  }

  listChainHandlersForSubaction(
    subaction: WalletRouterSubaction,
  ): WalletChainHandlerMetadata[] {
    return [...this.handlers.values()]
      .filter((handler) => handler.supportedActions.includes(subaction))
      .map((handler) => this.toMetadata(handler));
  }

  getCapabilities(): {
    readonly chains: readonly WalletChainHandlerMetadata[];
  } {
    return {
      chains: this.listChainHandlers(),
    };
  }

  /**
   * Resolve chain + required fields without signing. Used before out-of-band
   * financial confirmation so invalid params fail fast (GHSA-rqm7-f4jc-84x3).
   */
  preflightWalletAction(
    params: WalletRouterParams,
  ): WalletRouterFailure | null {
    const handlerResult = this.resolveHandler(params);
    if (!handlerResult.ok) {
      return handlerResult;
    }
    const required = this.validateRequiredParams(params, handlerResult.handler);
    if (required) {
      return required;
    }
    if (params.dryRun || params.mode !== "execute") {
      return null;
    }
    return this.refuseExecution(handlerResult.handler);
  }

  /**
   * Why `execute` requests for a signer family are refused, or null when they
   * may run. Chain handlers sign with the runtime's local keys, so execution
   * is refused whenever the wallet the user sees and funds is another one.
   */
  getExecutionRefusal(kind: WalletSignerMetadata["kind"]): string | null {
    if (this.backendLoadError instanceof StewardUnavailableError) {
      return `Steward is the selected wallet backend but it did not load: ${this.backendLoadError.message}`;
    }
    if (kind === "off-chain" || this.backend?.kind === "steward") {
      return null;
    }
    const { key, label } = PRIMARY_WALLET_SOURCE_SETTING[kind];
    const source = this.runtime.getSetting(key) ?? process.env[key];
    if (source === "cloud") {
      return `The primary ${label} wallet is the Eliza Cloud wallet, and this agent has no signer for it. Make the local ${label} wallet primary to send from it.`;
    }
    return null;
  }

  async routeWalletAction(
    requested: WalletRouterParams,
  ): Promise<WalletRouterResult> {
    const handlerResult = this.resolveHandler(requested);
    if (!handlerResult.ok) {
      return handlerResult;
    }

    const { handler } = handlerResult;
    const required = this.validateRequiredParams(requested, handler);
    if (required) {
      return required;
    }
    // The executor takes the destination as a handler chain key, so an alias
    // the preflight accepted ("ethereum", "8453") is passed on resolved.
    const destination = this.resolveBridgeDestination(requested.toChain);
    const params: WalletRouterParams =
      requested.subaction === "bridge" && destination
        ? { ...requested, toChain: destination.chain }
        : requested;

    if (params.mode === "simulate") {
      const supported =
        handler.simulation?.supported &&
        handler.simulation.supportedActions.includes(params.subaction) &&
        typeof handler.simulate === "function";
      if (!supported) {
        return {
          ok: false,
          error: "SIMULATION_UNSUPPORTED",
          detail: `${handler.name} does not support simulation for ${params.subaction}.`,
        };
      }
      try {
        // Non-null: `supported` above already checked `handler.simulate` is a function.
        const result = await (
          handler.simulate as NonNullable<typeof handler.simulate>
        )(params, this.createContext());
        return {
          ok: true,
          handler: this.toMetadata(handler),
          result,
        };
      } catch (error) {
        return {
          ok: false,
          error: "EXECUTION_FAILED",
          detail: error instanceof Error ? error.message : String(error),
        };
      }
    }

    if (params.dryRun || params.mode === "prepare") {
      if (
        params.dryRun &&
        (!handler.dryRun.supported ||
          !handler.dryRun.supportedActions.includes(params.subaction))
      ) {
        return {
          ok: false,
          error: "DRY_RUN_UNSUPPORTED",
          detail: `${handler.name} does not support dry-run for ${params.subaction}.`,
        };
      }

      if (params.subaction === "bridge") {
        try {
          const result = await handler.execute(params, this.createContext());
          return {
            ok: true,
            handler: this.toMetadata(handler),
            result,
          };
        } catch (error) {
          return {
            ok: false,
            error: "EXECUTION_FAILED",
            detail: error instanceof Error ? error.message : String(error),
          };
        }
      }

      return {
        ok: true,
        handler: this.toMetadata(handler),
        result: {
          status: "prepared",
          chain: handler.chain,
          chainId: handler.chainId,
          subaction: params.subaction,
          dryRun: params.dryRun,
          mode: params.mode,
          amount: params.amount,
          fromToken: params.fromToken,
          toToken: params.toToken,
          to: params.recipient,
          metadata: {
            signer: handler.signer,
            dryRun: handler.dryRun,
            supportedActions: handler.supportedActions,
            tokens: handler.tokens,
          },
        },
      };
    }

    const refusal = this.refuseExecution(handler);
    if (refusal) {
      return refusal;
    }

    try {
      const result = await handler.execute(params, this.createContext());
      return {
        ok: true,
        handler: this.toMetadata(handler),
        result,
      };
    } catch (error) {
      return {
        ok: false,
        error: "EXECUTION_FAILED",
        detail: error instanceof Error ? error.message : String(error),
      };
    }
  }

  override async stop(): Promise<void> {
    // No persistent connections for local / Steward HTTP clients today.
  }

  private refuseExecution(
    handler: WalletChainHandler,
  ): WalletRouterFailure | null {
    const detail = this.getExecutionRefusal(handler.signer.kind);
    return detail ? { ok: false, error: "EXECUTION_FAILED", detail } : null;
  }

  private resolveHandler(
    params: WalletRouterParams,
  ):
    | { readonly ok: true; readonly handler: WalletChainHandler }
    | WalletRouterFailure {
    if (params.chain) {
      const alias = this.aliases.get(normalizeWalletChainKey(params.chain));
      const handler = alias ? this.handlers.get(alias) : null;
      if (!handler) {
        return {
          ok: false,
          error: "UNSUPPORTED_CHAIN",
          detail: `Unsupported wallet chain "${params.chain}".`,
          candidates: this.listChainHandlers(),
        };
      }
      if (!handler.supportedActions.includes(params.subaction)) {
        return {
          ok: false,
          error: "UNSUPPORTED_SUBACTION",
          detail: `${handler.name} does not support ${params.subaction}.`,
          candidates: [this.toMetadata(handler)],
        };
      }
      return { ok: true, handler };
    }

    const candidates = [...this.handlers.values()].filter((handler) =>
      handler.supportedActions.includes(params.subaction),
    );
    if (candidates.length === 0) {
      return {
        ok: false,
        error: "UNSUPPORTED_SUBACTION",
        detail: `No wallet chain supports ${params.subaction}.`,
      };
    }
    if (candidates.length > 1) {
      return {
        ok: false,
        error: "AMBIGUOUS_CHAIN",
        detail: `Choose a chain for wallet ${params.subaction}.`,
        candidates: candidates.map((handler) => this.toMetadata(handler)),
      };
    }

    const handler = candidates[0];
    return { ok: true, handler };
  }

  /**
   * The bridge destination resolves through the same alias map as the source
   * chain. It must be a registered handler that supports bridge, because the
   * bridge executor quotes against the wallet's configured chains only.
   */
  private resolveBridgeDestination(
    toChain: string | undefined,
  ): WalletChainHandler | null {
    if (!toChain) return null;
    const key = this.aliases.get(normalizeWalletChainKey(toChain));
    const handler = key ? this.handlers.get(key) : undefined;
    return handler?.supportedActions.includes("bridge") ? handler : null;
  }

  private validateRequiredParams(
    params: WalletRouterParams,
    handler: WalletChainHandler,
  ): WalletRouterFailure | null {
    if (params.subaction === "bridge") {
      const detail = validateWalletBridgeParams(params);
      if (detail) {
        return { ok: false, error: "INVALID_PARAMS", detail };
      }
      const destination = this.resolveBridgeDestination(params.toChain);
      if (!destination) {
        return {
          ok: false,
          error: "UNSUPPORTED_CHAIN",
          detail: `Unsupported destination chain "${params.toChain}" for bridge.`,
          candidates: this.listChainHandlersForSubaction("bridge"),
        };
      }
      if (destination.chain === handler.chain) {
        return {
          ok: false,
          error: "INVALID_PARAMS",
          detail: "Source and destination chains must be different for bridge.",
        };
      }
      return null;
    }
    if (params.subaction === "gov") {
      const detail = validateWalletGovParams(params);
      return detail ? { ok: false, error: "INVALID_PARAMS", detail } : null;
    }
    if (!params.amount) {
      return {
        ok: false,
        error: "INVALID_PARAMS",
        detail: "amount is required.",
      };
    }
    if (params.subaction === "transfer") {
      const detail =
        validateWalletTransferParams(params, handler.signer.kind) ??
        validateWalletTokenParams(
          params,
          handler,
          this.getTokenDataService() !== null,
        );
      return detail ? { ok: false, error: "INVALID_PARAMS", detail } : null;
    }
    if (params.subaction === "swap") {
      if (!params.fromToken) {
        return {
          ok: false,
          error: "INVALID_PARAMS",
          detail: "fromToken is required for swap.",
        };
      }
      if (!params.toToken) {
        return {
          ok: false,
          error: "INVALID_PARAMS",
          detail: "toToken is required for swap.",
        };
      }
      const detail = validateWalletTokenParams(
        params,
        handler,
        this.getTokenDataService() !== null,
      );
      return detail ? { ok: false, error: "INVALID_PARAMS", detail } : null;
    }
    if (params.subaction === "pump_fun_buy") {
      const detail = validateWalletPumpFunBuyParams(params);
      return detail ? { ok: false, error: "INVALID_PARAMS", detail } : null;
    }
    return null;
  }

  private createContext(): WalletRouterContext {
    return {
      runtime: this.runtime,
      walletBackend: this.backend,
      walletServices: this.getWalletServices(),
      tokenDataService: this.getTokenDataService(),
    };
  }

  private getWalletServices(): IWalletService[] {
    const runtime = this.runtime as IAgentRuntime & {
      getServicesByType?: <T>(serviceName: string) => T[];
    };
    if (typeof runtime.getServicesByType !== "function") {
      return [];
    }
    return runtime.getServicesByType<IWalletService>(ServiceType.WALLET);
  }

  private getTokenDataService(): ITokenDataService | null {
    return this.runtime.getService<ITokenDataService>(ServiceType.TOKEN_DATA);
  }

  private toMetadata(handler: WalletChainHandler): WalletChainHandlerMetadata {
    return {
      chainId: handler.chainId,
      chain: handler.chain,
      name: handler.name,
      aliases: [...handler.aliases],
      supportedActions: [...handler.supportedActions],
      tokens: handler.tokens.map((token) => ({ ...token })),
      signer: { ...handler.signer },
      dryRun: {
        ...handler.dryRun,
        supportedActions: [...handler.dryRun.supportedActions],
      },
      ...(handler.simulation
        ? {
            simulation: {
              ...handler.simulation,
              supportedActions: [...handler.simulation.supportedActions],
            },
          }
        : {}),
    };
  }
}
