/**
 * Package barrel for `@elizaos/plugin-wallet`: re-exports the wallet plugin
 * object, all chain/analytics/LP services, providers, routes, the SDK
 * (ERC-6551/x402/CCTP/escrow), and supporting types. Consumers should import
 * from here rather than reaching into subpaths.
 */
import "./core-augmentation.js";
import { walletRouteRegistration } from "./register-routes.js";

void walletRouteRegistration;

export * from "./actions/index.js";
export { tradeRouterAction } from "./actions/trade-action.js";
export { BirdeyeService } from "./analytics/birdeye/service.js";
export { DexScreenerService } from "./analytics/dexscreener/index.js";
// Analytics surface (formerly @elizaos/plugin-{lpinfo,dexscreener,defi-news,birdeye}).
export {
  kaminoPlugin,
  lpinfoPlugin,
  steerPlugin,
} from "./analytics/lpinfo/index.js";
export {
  defiNewsPlugin,
  defiNewsProvider,
  NewsDataService,
} from "./analytics/news/index.js";
export {
  TOKEN_INFO_SERVICE_TYPE,
  TokenInfoService,
} from "./analytics/token-info/index.js";
// === Wallet routes extracted from packages/agent ===
// `handleWalletRoutes` is consumed by the agent HTTP server at
// `packages/agent/src/api/server.ts`. The file itself is deliberately
// `@elizaos/agent`-free; the agent injects all required helpers via the
// `WalletRouteContext.deps` interface.
export * from "./api/wallet-routes.js";
export * from "./audit/audit-log.js";
export { walletRouterAction } from "./chains/wallet-action.js";
export * from "./contracts.js";
export { resolveWalletExportRejection } from "./lib/server-wallet-trade.js";
export {
  _resetForTesting,
  getWalletExportAuditLog,
} from "./lib/wallet-export-guard.js";
// LP management surface (formerly @elizaos/plugin-lp-manager).
// Includes Solana DEX adapters (Raydium / Orca / Meteora) under
// chains/solana/dex/* and EVM DEX adapters (Uniswap / PancakeSwap / Aerodrome)
// under chains/evm/dex/*.
export {
  AerodromeLpService,
  aerodromePlugin,
  ConcentratedLiquidityService,
  DexInteractionService,
  default as lpManagerPlugin,
  LP_MANAGER_PLUGIN_NAME,
  orcaPlugin,
  PancakeSwapV3LpService,
  pancakeswapPlugin,
  raydiumPlugin,
  UniswapV3LpService,
  UserLpProfileService,
  uniswapPlugin,
  VaultService,
  YieldOptimizationService,
} from "./lp/lp-manager-entry.js";
export * from "./lp/types.js";
export { default, walletPlugin } from "./plugin.js";
export * from "./policy/policy.js";
export * from "./providers/canonical-provider.js";
export { stewardTradingProvider } from "./providers/steward-trading-provider.js";
export { walletProvider } from "./providers/wallet-provider.js";
export * from "./read.ts";
export * from "./register-routes.js";
export * from "./routes/plugin.js";
/** ERC-6551 / x402 / CCTP / swaps are available from the package barrel. */
export * from "./sdk/index.js";
export * from "./security/trade-confirmation.js";
export type { StewardTradingServiceOptions } from "./services/steward-trading-service.js";
export {
  createTradeIdempotencyKey,
  STEWARD_TRADING_SERVICE_TYPE,
  StewardTradingService,
} from "./services/steward-trading-service.js";
export {
  WALLET_BACKEND_SERVICE_TYPE,
  WalletBackendService,
} from "./services/wallet-backend-service.js";
export * from "./transactions.ts";
export * from "./types/trade.js";
export * from "./types/wallet-router.js";
export * from "./wallet/index.js";
export * from "./wallet-action.js";

export * from "./watcher.ts";
