/**
 * Meteora (Solana DLMM) liquidity-pool management sub-plugin. `init`
 * dynamically imports `MeteoraLpService` because its DLMM dependency is
 * optional; if that import fails, Meteora LP support is silently disabled
 * rather than blocking agent boot. Registers the service's LP protocol
 * provider with the shared `LpManagementService` registry.
 */
import type { IAgentRuntime, Plugin } from "@elizaos/core";
import {
  createSolanaLpProtocolProvider,
  registerLpProtocolProvider,
} from "../../../../lp/services/LpManagementService.ts";
import type { MeteoraLpService } from "./services/MeteoraLpService.ts";

export const meteoraPlugin: Plugin = {
  name: "@elizaos/plugin-meteora",
  description: "A plugin for interacting with the Meteora DEX.",
  services: [],
  providers: [],
  tests: [],
  init: async (_config: Record<string, string>, runtime: IAgentRuntime) => {
    try {
      const serviceModulePath = "./services/MeteoraLpService.ts";
      const { MeteoraLpService } = await import(serviceModulePath);
      console.info("Meteora Plugin Initialized");
      const service =
        runtime.getService(MeteoraLpService.serviceType) ?? (await MeteoraLpService.start(runtime));
      await registerLpProtocolProvider(
        runtime,
        createSolanaLpProtocolProvider({
          dex: "meteora",
          label: "Meteora",
          service: service as Parameters<typeof createSolanaLpProtocolProvider>[0]["service"],
        })
      );
    } catch (error) {
      console.warn(
        "[Meteora] Optional DLMM dependency failed to load; Meteora LP support is disabled.",
        error instanceof Error ? error.message : String(error)
      );
    }
  },
  async dispose(runtime: IAgentRuntime) {
    const svc = runtime.getService<MeteoraLpService>("meteora-lp");
    await svc?.stop();
  },
};

export default meteoraPlugin;
