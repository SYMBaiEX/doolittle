/**
 * Resolves the agent's Solana keypair or public key from runtime settings
 * (base58 or base64 encoded `SOLANA_PRIVATE_KEY`/`WALLET_PRIVATE_KEY`, or
 * `SOLANA_PUBLIC_KEY`/`WALLET_PUBLIC_KEY` for the public-key-only path). If
 * no key is configured, `getWalletKey` generates a new keypair, persists it
 * to runtime settings, and logs the new address so the operator can fund it
 * — callers should not assume a missing key means failure.
 */
import { type IAgentRuntime, logger } from "@elizaos/core";
import { Keypair, PublicKey } from "@solana/web3.js";
import bs58 from "bs58";

export interface KeypairResult {
  keypair?: Keypair;
  publicKey?: PublicKey;
}

function getStringSetting(runtime: IAgentRuntime, key: string): string | null {
  const value = runtime.getSetting(key);
  if (value === null || value === undefined) {
    return null;
  }
  if (typeof value !== "string") {
    throw new Error(`Setting ${key} must be a string, got ${typeof value}`);
  }
  return value;
}

function generateAndStoreKeypair(runtime: IAgentRuntime): Keypair {
  const keypair = Keypair.generate();
  const privateKeyBase58 = bs58.encode(keypair.secretKey);
  const publicKeyBase58 = keypair.publicKey.toBase58();

  runtime.setSetting("SOLANA_PRIVATE_KEY", privateKeyBase58, true);
  runtime.setSetting("SOLANA_PUBLIC_KEY", publicKeyBase58, false);

  logger.warn("No Solana wallet found. Generated new wallet automatically.");
  logger.warn(`New Solana wallet address: ${publicKeyBase58}`);
  logger.warn("Private key has been stored securely in agent settings.");
  logger.warn("Fund this wallet to enable SOL and token transfers.");

  return keypair;
}

/**
 * Read-only public-key lookup: returns the configured wallet's public key or
 * null when no wallet exists. Unlike `getWalletKey`, this NEVER generates or
 * persists a keypair — read-only flows (transaction simulation, #16613) must
 * not mint a secret as a side effect of a lookup.
 */
export function getExistingSolanaPublicKey(runtime: IAgentRuntime): PublicKey | null {
  const publicKeyString =
    getStringSetting(runtime, "SOLANA_PUBLIC_KEY") ??
    getStringSetting(runtime, "WALLET_PUBLIC_KEY");
  return publicKeyString ? new PublicKey(publicKeyString) : null;
}

export async function getWalletKey(
  runtime: IAgentRuntime,
  requirePrivateKey = true
): Promise<KeypairResult> {
  if (requirePrivateKey) {
    const privateKeyString =
      getStringSetting(runtime, "SOLANA_PRIVATE_KEY") ??
      getStringSetting(runtime, "WALLET_PRIVATE_KEY");

    if (!privateKeyString) {
      const keypair = generateAndStoreKeypair(runtime);
      return { keypair };
    }

    try {
      const secretKey = bs58.decode(privateKeyString);
      return { keypair: Keypair.fromSecretKey(secretKey) };
    } catch {
      try {
        const secretKey = Uint8Array.from(Buffer.from(privateKeyString, "base64"));
        return { keypair: Keypair.fromSecretKey(secretKey) };
      } catch {
        throw new Error("Invalid private key format");
      }
    }
  } else {
    const publicKeyString =
      getStringSetting(runtime, "SOLANA_PUBLIC_KEY") ??
      getStringSetting(runtime, "WALLET_PUBLIC_KEY");

    if (publicKeyString) {
      return { publicKey: new PublicKey(publicKeyString) };
    }

    const privateKeyString =
      getStringSetting(runtime, "SOLANA_PRIVATE_KEY") ??
      getStringSetting(runtime, "WALLET_PRIVATE_KEY");

    if (privateKeyString) {
      try {
        const secretKey = bs58.decode(privateKeyString);
        const keypair = Keypair.fromSecretKey(secretKey);
        return { publicKey: keypair.publicKey };
      } catch {
        try {
          const secretKey = Uint8Array.from(Buffer.from(privateKeyString, "base64"));
          const keypair = Keypair.fromSecretKey(secretKey);
          return { publicKey: keypair.publicKey };
        } catch {
          // Invalid format, will generate new keypair below
        }
      }
    }

    const keypair = generateAndStoreKeypair(runtime);
    return { publicKey: keypair.publicKey };
  }
}
