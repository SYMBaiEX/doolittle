/**
 * Solana sub-plugin composed into `walletPlugin`: registers `SolanaService` +
 * `SolanaWalletService`, the Solana wallet provider, and the Solana REST/sign
 * routes. Init is a no-op when `SOLANA_RPC_URL` is unset. If an `INTEL_CHAIN`
 * service is present it registers Solana with it opportunistically (failure
 * to register is logged, not fatal).
 */

import type { IAgentRuntime, ServiceTypeName } from "@elizaos/core";
import type { HttpPlugin as Plugin } from "@elizaos/host/protocol";
import { SOLANA_SERVICE_NAME } from "./constants";
import { walletProvider } from "./providers/wallet";
import { solanaRoutes } from "./routes/index";
import { solanaSignRoutes } from "./routes/sign";
import { SOLANA_WALLET_COMPAT_SERVICE_NAME, SolanaService, SolanaWalletService } from "./service";

function getStringSetting(runtime: IAgentRuntime, key: string): string | null {
  const value = runtime.getSetting(key);
  return typeof value === "string" ? value : null;
}
function parseBoolSetting(value: string | number | boolean | null): boolean {
  if (value === null || value === undefined) return false;
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  const str = String(value).toLowerCase().trim();
  return str === "true" || str === "1" || str === "yes";
}
export const solanaPlugin: Plugin = {
  name: SOLANA_SERVICE_NAME,
  description: "Solana blockchain plugin",
  services: [SolanaService, SolanaWalletService],
  routes: [...solanaRoutes, ...solanaSignRoutes],
  init: async (_, runtime: IAgentRuntime) => {
    if (!getStringSetting(runtime, "SOLANA_RPC_URL")) {
      runtime.logger.log("no SOLANA_RPC_URL, skipping Solana chain init");
      return;
    }
    if (parseBoolSetting(runtime.getSetting("SOLANA_NO_ACTIONS"))) {
      runtime.logger.log("SOLANA_NO_ACTIONS is set, skipping solana actions");
    }
    runtime.registerProvider(walletProvider);
    runtime
      .getServiceLoadPromise("INTEL_CHAIN" as ServiceTypeName)
      .then(() => {
        const traderChainService = runtime.getService("INTEL_CHAIN");
        if (
          traderChainService &&
          typeof traderChainService === "object" &&
          "registerChain" in traderChainService &&
          typeof traderChainService.registerChain === "function"
        ) {
          traderChainService.registerChain({
            name: "Solana services",
            chain: "solana",
            service: SOLANA_SERVICE_NAME,
          });
        }
      })
      .catch((error) => {
        runtime.logger.error({ error }, "Failed to register with INTEL_CHAIN");
      });
  },
  async dispose(runtime: IAgentRuntime) {
    const solana = runtime.getService<SolanaService>(SOLANA_SERVICE_NAME as ServiceTypeName);
    await solana?.stop();
    const wallet = runtime.getService<SolanaWalletService>(
      SOLANA_WALLET_COMPAT_SERVICE_NAME as ServiceTypeName
    );
    await wallet?.stop();
  },
};
export default solanaPlugin;
export { SOLANA_SERVICE_NAME } from "./constants";
export type { SolanaService as ISolanaService } from "./service";
export { SolanaService, SolanaWalletService } from "./service";
export type {
  ApiError,
  ApiResponse,
  PortfolioTokenResponse,
  TokenAccountResponse,
  TokenBalanceResponse,
  WalletAddressResponse,
  WalletBalanceResponse,
  WalletPortfolioResponse,
  WalletTokensResponse,
} from "./types";
