/**
 * EVM token swap: `SwapAction` shops a quote across Li.Fi, Bebop, and
 * KyberSwap (best-price-first, with slippage escalation and per-quote error
 * recovery across `slippageLevels`), handles ERC-20 approval when needed, and
 * submits the winning route's transaction. `buildSwapDetails` turns the LLM's
 * structured intent into concrete `SwapParams`, resolving relative amounts
 * (half/max/percent) against the balance of the token actually being sold: the
 * ERC-20 `fromToken` balance for token inputs, or the native chain balance
 * (with a gas reserve for `max`) only when the input is the native asset.
 * `swapAction` is
 * the `WALLET`/`swap` subaction entry point and always runs through
 * `gateWalletFinancialExecution` before submission.
 */

import {
  type ActionResult,
  type HandlerCallback,
  type IAgentRuntime,
  logger,
  type Memory,
  ModelType,
  type State,
} from "@elizaos/core";
import { parseJSONObjectFromText } from "@elizaos/core/protocol";
import { composePromptFromState } from "@elizaos/plugin-assistant/text/template-rendering";
import {
  createConfig,
  type ExtendedChain,
  getRoutes,
  getStepTransaction,
  getToken,
  type Route,
} from "@lifi/sdk";
import {
  type Address,
  encodeFunctionData,
  formatUnits,
  type Hash,
  type Hex,
  parseAbi,
  parseUnits,
} from "viem";
import {
  gateWalletFinancialExecution,
  walletFinancialGateActionResult,
} from "../../../security/wallet-financial-confirmation.js";
import { runIntentModel } from "../../../utils/intent-trajectory";
import {
  BEBOP_CHAIN_MAP,
  DEFAULT_SLIPPAGE_PERCENT,
  GAS_BUFFER_MULTIPLIER,
  GAS_PRICE_MULTIPLIER,
  KYBERSWAP_CHAIN_MAP,
  KYBERSWAP_NATIVE_SENTINEL,
  NATIVE_TOKEN_ADDRESS,
  TX_CONFIRMATION_TIMEOUT_MS,
} from "../constants";
import { parseEvmBaseUnits } from "../exact-units";
import { requireActionSpec } from "../generated/specs/spec-helpers";
import {
  type ChainBalanceState,
  initWalletProvider,
  type WalletProvider,
} from "../providers/wallet";
import { swapTemplate } from "../templates";
import {
  type BebopRoute,
  BebopRouteSchema,
  EVMError,
  EVMErrorCode,
  type KyberSwapRouteData,
  type KyberSwapRouteSummary,
  parseSwapParams,
  type SupportedChain,
  type SwapParams,
  type SwapQuote,
  type Transaction,
} from "../types";
import { buildSendTxParams, createEvmActionValidator } from "./helpers";
export const DEFAULT_EVM_SWAP_FETCH_TIMEOUT_MS = 10000;
const legacySpec = requireActionSpec("EVM_SWAP");
const spec = { ...legacySpec, name: "WALLET" };

export { swapTemplate };
export class SwapAction {
  constructor(private readonly walletProvider: WalletProvider) {
    const lifiChains: ExtendedChain[] = [];
    for (const config of Object.values(this.walletProvider.chains)) {
      const blockExplorerUrls = config.blockExplorers?.default?.url
        ? [config.blockExplorers.default.url]
        : [];
      const lifiChain = {
        id: config.id,
        name: config.name,
        key: config.name.toLowerCase(),
        chainType: "EVM",
        nativeToken: {
          ...config.nativeCurrency,
          chainId: config.id,
          address: NATIVE_TOKEN_ADDRESS,
          coinKey: config.nativeCurrency.symbol,
          priceUSD: "0",
          logoURI: "",
          symbol: config.nativeCurrency.symbol,
          decimals: config.nativeCurrency.decimals,
          name: config.nativeCurrency.name,
        },
        rpcUrls: {
          public: { http: [config.rpcUrls.default.http[0]] },
        },
        blockExplorerUrls,
        metamask: {
          chainId: `0x${config.id.toString(16)}`,
          chainName: config.name,
          nativeCurrency: config.nativeCurrency,
          rpcUrls: [config.rpcUrls.default.http[0]],
          blockExplorerUrls,
        },
        coin: config.nativeCurrency.symbol,
        mainnet: true,
        diamondAddress: NATIVE_TOKEN_ADDRESS,
      } as ExtendedChain;
      lifiChains.push(lifiChain);
    }
    createConfig({
      integrator: "eliza",
      chains: lifiChains,
      preloadChains: false,
    });
  }
  private async resolveTokenAddress(
    tokenSymbolOrAddress: string,
    chainId: number
  ): Promise<string> {
    if (tokenSymbolOrAddress.startsWith("0x") && tokenSymbolOrAddress.length === 42) {
      return tokenSymbolOrAddress;
    }
    if (tokenSymbolOrAddress === NATIVE_TOKEN_ADDRESS) {
      return tokenSymbolOrAddress;
    }
    const token = await getToken(chainId, tokenSymbolOrAddress);
    return token.address;
  }
  async swap(params: SwapParams): Promise<Transaction> {
    // Validate inputs early to fail fast
    const amount = parseFloat(params.amount);
    if (Number.isNaN(amount) || amount <= 0) {
      throw new EVMError(EVMErrorCode.INVALID_PARAMS, "Amount must be a positive number");
    }
    if (
      !params.fromToken.startsWith("0x") ||
      (params.fromToken.length !== 42 && params.fromToken !== NATIVE_TOKEN_ADDRESS)
    ) {
      throw new EVMError(
        EVMErrorCode.INVALID_PARAMS,
        `Invalid fromToken address: ${params.fromToken}`
      );
    }
    if (
      !params.toToken.startsWith("0x") ||
      (params.toToken.length !== 42 && params.toToken !== NATIVE_TOKEN_ADDRESS)
    ) {
      throw new EVMError(EVMErrorCode.INVALID_PARAMS, `Invalid toToken address: ${params.toToken}`);
    }
    const walletClient = this.walletProvider.getWalletClient(params.chain);
    const [fromAddress] = await walletClient.getAddresses();
    const chainConfig = this.walletProvider.getChainConfigs(params.chain);
    const chainId = chainConfig.id;
    const resolvedFromToken = await this.resolveTokenAddress(params.fromToken, chainId);
    const resolvedToToken = await this.resolveTokenAddress(params.toToken, chainId);
    const resolvedParams: SwapParams = {
      ...params,
      fromToken: resolvedFromToken as Address,
      toToken: resolvedToToken as Address,
    };
    // A confirmed slippageBps is the tolerance the user approved, so quote at
    // exactly that level; only the unstated case escalates through the ladder.
    const slippageLevels =
      params.slippageBps === undefined ? [0.01, 0.015, 0.02] : [params.slippageBps / 10000];
    let lastError: Error | undefined;
    let attemptCount = 0;
    for (const slippage of slippageLevels) {
      logger.info(`Attempting swap with ${(slippage * 100).toFixed(1)}% slippage...`);
      const sortedQuotes = await this.getSortedQuotes(fromAddress, resolvedParams, slippage);
      for (const quote of sortedQuotes) {
        attemptCount++;
        logger.info(`Trying ${quote.aggregator} (attempt ${attemptCount})...`);
        try {
          let result: Transaction | undefined;
          switch (quote.aggregator) {
            case "lifi":
              result = await this.executeLifiQuote(quote);
              break;
            case "bebop":
              result = await this.executeBebopQuote(quote, resolvedParams);
              break;
            case "kyberswap":
              result = await this.executeKyberSwapQuote(quote, resolvedParams);
              break;
          }
          if (result) {
            logger.info(`✅ Swap succeeded via ${quote.aggregator}!`);
            return result;
          }
        } catch (error) {
          lastError = error instanceof Error ? error : new Error(String(error));
          logger.warn(`${quote.aggregator} attempt failed: ${lastError.message}`);
          // If it's a recoverable error, continue to next attempt
          if (this.isRecoverableError(lastError)) {
            continue;
          }
          // Non-recoverable error, throw immediately
          throw lastError;
        }
      }
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
    throw new EVMError(
      EVMErrorCode.CONTRACT_REVERT,
      `All swap attempts failed after ${attemptCount} tries. ${lastError?.message ?? "Unknown error"}`
    );
  }
  /**
   * Wait for a broadcast swap's receipt. A reverted swap throws, so the next
   * route can be tried. Any other failure (receipt timeout, RPC error) leaves
   * the swap's outcome unknown: it may still land, so it is reported as
   * unconfirmed instead of failed, and no other route is tried with the same
   * funds.
   */
  private async waitForSwapReceipt(
    publicClient: ReturnType<WalletProvider["getPublicClient"]>,
    hash: Hash,
    revertedMessage: string
  ): Promise<"confirmed" | "unconfirmed"> {
    let receipt: Awaited<ReturnType<typeof publicClient.waitForTransactionReceipt>>;
    try {
      receipt = await publicClient.waitForTransactionReceipt({
        hash,
        timeout: TX_CONFIRMATION_TIMEOUT_MS,
      });
    } catch (error) {
      // error-policy:J2 the transaction was broadcast; its outcome is unknown.
      logger.warn(
        `Swap ${hash} was broadcast but its receipt could not be read: ${
          error instanceof Error ? error.message : String(error)
        }`
      );
      return "unconfirmed";
    }
    if (receipt.status === "reverted") {
      throw new EVMError(EVMErrorCode.CONTRACT_REVERT, revertedMessage);
    }
    return "confirmed";
  }
  private isRecoverableError(error: Error): boolean {
    const message = error.message;
    return (
      message.includes("price movement") ||
      message.includes("Return amount is not enough") ||
      message.includes("reverted") ||
      message.includes("MEV frontrunning") ||
      message.includes("TRANSFER_FROM_FAILED")
    );
  }
  private async getSortedQuotes(
    fromAddress: Address,
    params: SwapParams,
    slippage: number = DEFAULT_SLIPPAGE_PERCENT
  ): Promise<SwapQuote[]> {
    const decimalsAbi = parseAbi(["function decimals() view returns (uint8)"]);
    let fromTokenDecimals: number;
    const chainConfig = this.walletProvider.getChainConfigs(params.chain);
    if (
      params.fromToken.toUpperCase() === chainConfig.nativeCurrency.symbol.toUpperCase() ||
      params.fromToken === NATIVE_TOKEN_ADDRESS
    ) {
      fromTokenDecimals = chainConfig.nativeCurrency.decimals;
    } else {
      const publicClient = this.walletProvider.getPublicClient(params.chain);
      const decimals = await publicClient.readContract({
        address: params.fromToken as Address,
        abi: decimalsAbi,
        functionName: "decimals",
        authorizationList: undefined,
      });
      fromTokenDecimals = Number(decimals);
    }
    // Parsed here, outside the per-aggregator catch blocks, so an amount the
    // token cannot hold is refused instead of reported as "No routes found".
    const fromAmount = parseEvmBaseUnits(params.amount, fromTokenDecimals).toString();
    const quotesPromises: Promise<SwapQuote | undefined>[] = [
      this.getLifiQuote(fromAddress, params, fromAmount, slippage),
      // The current Bebop request does not carry an enforceable slippage
      // bound. Keep it available for the legacy default path, but never let
      // it win a quote the user confirmed with an explicit tolerance.
      ...(params.slippageBps === undefined
        ? [this.getBebopQuote(fromAddress, params, fromAmount)]
        : []),
      this.getKyberSwapQuote(fromAddress, params, fromAmount, slippage),
    ];
    const quotesResults = await Promise.all(quotesPromises);
    const sortedQuotes = quotesResults.filter((quote): quote is SwapQuote => quote !== undefined);
    sortedQuotes.sort((a, b) => (BigInt(a.minOutputAmount) > BigInt(b.minOutputAmount) ? -1 : 1));
    if (sortedQuotes.length === 0) {
      throw new EVMError(EVMErrorCode.INVALID_PARAMS, "No routes found");
    }
    return sortedQuotes;
  }
  private async getLifiQuote(
    fromAddress: Address,
    params: SwapParams,
    fromAmount: string,
    slippage: number = DEFAULT_SLIPPAGE_PERCENT
  ): Promise<SwapQuote | undefined> {
    try {
      const routes = await getRoutes({
        fromChainId: this.walletProvider.getChainConfigs(params.chain).id,
        toChainId: this.walletProvider.getChainConfigs(params.chain).id,
        fromTokenAddress: params.fromToken,
        toTokenAddress: params.toToken,
        fromAmount,
        fromAddress,
        options: {
          slippage,
          order: "RECOMMENDED",
        },
      });
      if (!routes.routes.length) {
        throw new Error("No routes found");
      }
      return {
        aggregator: "lifi",
        minOutputAmount: routes.routes[0].steps[0].estimate.toAmountMin,
        swapData: routes.routes[0],
      };
    } catch (error) {
      logger.error(
        "Error in getLifiQuote:",
        error instanceof Error ? error.message : String(error)
      );
      return undefined;
    }
  }
  private async getBebopQuote(
    fromAddress: Address,
    params: SwapParams,
    fromAmount: string
  ): Promise<SwapQuote | undefined> {
    try {
      const chainName = BEBOP_CHAIN_MAP[params.chain] ?? params.chain;
      const url = `https://api.bebop.xyz/router/${chainName}/v1/quote`;
      const chainConfig = this.walletProvider.getChainConfigs(params.chain);
      const resolvedFromToken = await this.resolveTokenAddress(params.fromToken, chainConfig.id);
      const resolvedToToken = await this.resolveTokenAddress(params.toToken, chainConfig.id);
      const reqParams = new URLSearchParams({
        sell_tokens: resolvedFromToken,
        buy_tokens: resolvedToToken,
        sell_amounts: fromAmount,
        taker_address: fromAddress,
        approval_type: "Standard",
        skip_validation: "true",
        gasless: "false",
        source: "eliza",
      });
      const response = await fetch(`${url}?${reqParams.toString()}`, {
        method: "GET",
        headers: { accept: "application/json" },
        signal: AbortSignal.timeout(DEFAULT_EVM_SWAP_FETCH_TIMEOUT_MS),
      });
      if (!response.ok) {
        throw new Error(`Bebop API error: ${response.status} ${response.statusText}`);
      }
      const data = await response.json();
      if (!data.routes?.length) {
        throw new Error("No routes found in Bebop API response");
      }
      const firstRoute = data.routes[0];
      const quoteTx = firstRoute?.quote?.tx;
      if (!quoteTx) {
        throw new Error("Invalid route structure in Bebop API response");
      }
      const route: BebopRoute = {
        data: quoteTx.data,
        sellAmount: fromAmount,
        approvalTarget: firstRoute.quote.approvalTarget as Address,
        from: quoteTx.from as Address,
        value: quoteTx.value?.toString() ?? "0",
        to: quoteTx.to as Address,
        gas: quoteTx.gas?.toString() ?? "0",
        gasPrice: quoteTx.gasPrice?.toString() ?? "0",
      };
      // Validate the route structure
      BebopRouteSchema.parse(route);
      // Find buy token info
      const buyTokens = firstRoute.quote.buyTokens;
      if (!buyTokens) {
        throw new Error("Missing buyTokens in Bebop response");
      }
      const buyTokenInfo =
        buyTokens[resolvedToToken] ??
        buyTokens[params.toToken] ??
        buyTokens[resolvedToToken.toLowerCase()];
      if (!buyTokenInfo?.minimumAmount) {
        throw new Error("Cannot determine minimum output amount");
      }
      return {
        aggregator: "bebop",
        minOutputAmount: buyTokenInfo.minimumAmount.toString(),
        swapData: route,
      };
    } catch (error) {
      logger.error(
        "Error in getBebopQuote:",
        error instanceof Error ? error.message : String(error)
      );
      return undefined;
    }
  }
  private async getKyberSwapQuote(
    fromAddress: Address,
    params: SwapParams,
    fromAmount: string,
    slippage: number
  ): Promise<SwapQuote | undefined> {
    try {
      const chainSlug = KYBERSWAP_CHAIN_MAP[params.chain];
      if (!chainSlug) return undefined;
      const fromToken =
        params.fromToken === NATIVE_TOKEN_ADDRESS ? KYBERSWAP_NATIVE_SENTINEL : params.fromToken;
      const toToken =
        params.toToken === NATIVE_TOKEN_ADDRESS ? KYBERSWAP_NATIVE_SENTINEL : params.toToken;
      const url = new URL(`https://aggregator-api.kyberswap.com/${chainSlug}/api/v1/routes`);
      url.searchParams.set("tokenIn", fromToken);
      url.searchParams.set("tokenOut", toToken);
      url.searchParams.set("amountIn", fromAmount);
      url.searchParams.set("gasInclude", "true");
      url.searchParams.set("source", "elizaos");
      const res = await fetch(url.toString(), {
        headers: { "X-Client-Id": "elizaos", Accept: "application/json" },
        signal: AbortSignal.timeout(DEFAULT_EVM_SWAP_FETCH_TIMEOUT_MS),
      });
      if (!res.ok) throw new Error(`KyberSwap API error: ${res.status}`);
      const data = await res.json();
      const routeSummary = data?.data?.routeSummary as KyberSwapRouteSummary | undefined;
      if (!routeSummary?.amountOut) throw new Error("No route found from KyberSwap");
      const slippageBps = Math.round(slippage * 10000);
      // KyberSwap's quote endpoint returns the expected gross output; the
      // guaranteed minimum is computed client-side by applying the slippage
      // tolerance (same math the build endpoint uses internally).
      const minOut = (BigInt(routeSummary.amountOut) * BigInt(10000 - slippageBps)) / 10000n;
      return {
        aggregator: "kyberswap",
        minOutputAmount: minOut.toString(),
        swapData: {
          routeSummary,
          routerAddress: data.data.routerAddress,
          chainSlug,
          fromToken,
          toToken,
          amountIn: fromAmount,
          slippageBps,
          fromAddress,
        } satisfies KyberSwapRouteData,
      };
    } catch (error) {
      logger.error(
        "Error in getKyberSwapQuote:",
        error instanceof Error ? error.message : String(error)
      );
      return undefined;
    }
  }
  private async executeLifiQuote(quote: SwapQuote): Promise<Transaction | undefined> {
    const route = quote.swapData as Route;
    const step = route.steps[0];
    if (!step) {
      throw new EVMError(EVMErrorCode.INVALID_PARAMS, "No steps found in route");
    }
    const stepWithTx = await getStepTransaction(step);
    if (!stepWithTx.transactionRequest) {
      throw new EVMError(EVMErrorCode.INVALID_PARAMS, "No transaction request found in step");
    }
    const chainId = route.fromChainId;
    const chainName = Object.keys(this.walletProvider.chains).find(
      (name) => this.walletProvider.getChainConfigs(name as SupportedChain).id === chainId
    );
    if (!chainName) {
      throw new EVMError(EVMErrorCode.CHAIN_NOT_CONFIGURED, `Chain with ID ${chainId} not found`);
    }
    const walletClient = this.walletProvider.getWalletClient(chainName as SupportedChain);
    const publicClient = this.walletProvider.getPublicClient(chainName as SupportedChain);
    const account = walletClient.account;
    if (!account) {
      throw new EVMError(EVMErrorCode.WALLET_NOT_INITIALIZED, "Wallet account is not available");
    }
    const chain = walletClient.chain;
    if (!chain) {
      throw new EVMError(EVMErrorCode.CHAIN_NOT_CONFIGURED, "Wallet chain is not configured");
    }
    const txRequest = stepWithTx.transactionRequest;
    const fromToken = route.fromToken;
    if (fromToken.address !== NATIVE_TOKEN_ADDRESS) {
      await this.handleTokenApproval(
        publicClient,
        walletClient,
        fromToken.address as Address,
        txRequest.to as Address,
        BigInt(route.fromAmount)
      );
    }
    const hash = await walletClient.sendTransaction(
      buildSendTxParams({
        account,
        to: txRequest.to as Address,
        value: BigInt(txRequest.value ?? "0"),
        data: txRequest.data as Hex,
        chain,
        gas: txRequest.gasLimit
          ? BigInt(Math.floor(Number(txRequest.gasLimit) * GAS_BUFFER_MULTIPLIER))
          : undefined,
        gasPrice: txRequest.gasPrice
          ? BigInt(Math.floor(Number(txRequest.gasPrice) * GAS_PRICE_MULTIPLIER))
          : undefined,
      })
    );
    const confirmationStatus = await this.waitForSwapReceipt(
      publicClient,
      hash,
      `Transaction reverted. Hash: ${hash}`
    );
    return {
      hash,
      from: account.address,
      to: txRequest.to as Address,
      value: BigInt(txRequest.value ?? "0"),
      data: txRequest.data as Hex,
      chainId: route.fromChainId,
      confirmationStatus,
    };
  }
  private async executeBebopQuote(
    quote: SwapQuote,
    params: SwapParams
  ): Promise<Transaction | undefined> {
    const bebopRoute = quote.swapData as BebopRoute;
    const walletClient = this.walletProvider.getWalletClient(params.chain);
    const publicClient = this.walletProvider.getPublicClient(params.chain);
    const account = walletClient.account;
    if (!account) {
      throw new EVMError(EVMErrorCode.WALLET_NOT_INITIALIZED, "Wallet account is not available");
    }
    const chainConfig = this.walletProvider.getChainConfigs(params.chain);
    const resolvedFromToken = await this.resolveTokenAddress(params.fromToken, chainConfig.id);
    if (resolvedFromToken !== NATIVE_TOKEN_ADDRESS) {
      await this.handleTokenApproval(
        publicClient,
        walletClient,
        resolvedFromToken as Address,
        bebopRoute.approvalTarget,
        BigInt(bebopRoute.sellAmount)
      );
    }
    const hash = await walletClient.sendTransaction(
      buildSendTxParams({
        account,
        to: bebopRoute.to as Address,
        value: BigInt(bebopRoute.value),
        data: bebopRoute.data as Hex,
        chain: walletClient.chain,
      })
    );
    const confirmationStatus = await this.waitForSwapReceipt(
      publicClient,
      hash,
      `Bebop swap reverted. Hash: ${hash}`
    );
    return {
      hash,
      from: account.address,
      to: bebopRoute.to,
      value: BigInt(bebopRoute.value),
      data: bebopRoute.data as Hex,
      chainId: chainConfig.id,
      confirmationStatus,
    };
  }
  private async executeKyberSwapQuote(
    quote: SwapQuote,
    params: SwapParams
  ): Promise<Transaction | undefined> {
    const ks = quote.swapData as KyberSwapRouteData;
    const walletClient = this.walletProvider.getWalletClient(params.chain);
    const publicClient = this.walletProvider.getPublicClient(params.chain);
    const account = walletClient.account;
    if (!account) {
      throw new EVMError(EVMErrorCode.WALLET_NOT_INITIALIZED, "Wallet account is not available");
    }
    const buildRes = await fetch(
      `https://aggregator-api.kyberswap.com/${ks.chainSlug}/api/v1/route/build`,
      {
        signal: AbortSignal.timeout(DEFAULT_EVM_SWAP_FETCH_TIMEOUT_MS),
        method: "POST",
        headers: {
          "X-Client-Id": "elizaos",
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          routeSummary: ks.routeSummary,
          sender: account.address,
          recipient: account.address,
          slippageTolerance: ks.slippageBps,
          deadline: Math.floor(Date.now() / 1000) + 1200,
          enableGasEstimation: true,
          source: "elizaos",
        }),
      }
    );
    if (!buildRes.ok) {
      throw new Error(`KyberSwap build failed: ${buildRes.status} ${buildRes.statusText}`);
    }
    const buildData = await buildRes.json();
    const tx = buildData?.data;
    if (!tx?.routerAddress || !tx?.data) {
      throw new Error("Invalid transaction data from KyberSwap build");
    }
    if (ks.fromToken.toLowerCase() !== KYBERSWAP_NATIVE_SENTINEL.toLowerCase()) {
      await this.handleTokenApproval(
        publicClient,
        walletClient,
        ks.fromToken as Address,
        tx.routerAddress as Address,
        BigInt(ks.amountIn)
      );
    }
    const hash = await walletClient.sendTransaction(
      buildSendTxParams({
        account,
        to: tx.routerAddress as Address,
        value: BigInt(tx.transactionValue ?? "0"),
        data: tx.data as Hex,
        chain: walletClient.chain,
      })
    );
    const confirmationStatus = await this.waitForSwapReceipt(
      publicClient,
      hash,
      `KyberSwap swap reverted. Hash: ${hash}`
    );
    return {
      hash,
      from: account.address,
      to: tx.routerAddress as Address,
      value: BigInt(tx.transactionValue ?? "0"),
      data: tx.data as Hex,
      chainId: this.walletProvider.getChainConfigs(params.chain).id,
      confirmationStatus,
    };
  }
  private async handleTokenApproval(
    publicClient: ReturnType<WalletProvider["getPublicClient"]>,
    walletClient: ReturnType<WalletProvider["getWalletClient"]>,
    tokenAddress: Address,
    spenderAddress: Address,
    requiredAmount: bigint
  ): Promise<void> {
    const account = walletClient.account;
    if (!account) {
      throw new EVMError(EVMErrorCode.WALLET_NOT_INITIALIZED, "Wallet account not available");
    }
    const allowanceAbi = parseAbi(["function allowance(address,address) view returns (uint256)"]);
    const allowance = BigInt(
      await publicClient.readContract({
        address: tokenAddress,
        abi: allowanceAbi,
        functionName: "allowance",
        args: [account.address, spenderAddress],
        authorizationList: undefined,
      })
    );
    if (allowance >= requiredAmount) {
      return;
    }
    logger.info(`Approving token for swap...`);
    const approvalData = encodeFunctionData({
      abi: parseAbi(["function approve(address,uint256)"]),
      functionName: "approve",
      args: [spenderAddress, requiredAmount],
    });
    const approvalTx = await walletClient.sendTransaction(
      buildSendTxParams({
        account,
        to: tokenAddress,
        value: 0n,
        data: approvalData,
        chain: walletClient.chain,
      })
    );
    logger.info(`Waiting for approval confirmation...`);
    const approvalReceipt = await publicClient.waitForTransactionReceipt({
      hash: approvalTx,
      timeout: TX_CONFIRMATION_TIMEOUT_MS,
    });
    if (approvalReceipt.status === "reverted") {
      throw new EVMError(
        EVMErrorCode.CONTRACT_REVERT,
        `Token approval failed. Hash: ${approvalTx}`
      );
    }
    logger.info(`Token approval confirmed`);
  }
}
export async function buildSwapDetails(
  state: State,
  message: Memory,
  runtime: IAgentRuntime,
  wp: WalletProvider
): Promise<SwapParams> {
  const chains = wp.getSupportedChains();
  const balances = await wp.getChainBalanceStates();
  state = await runtime.composeState(message, ["RECENT_MESSAGES"], true);
  state.supportedChains = chains.join(" | ");
  state.chainBalances = Object.entries(balances)
    .map(([chain, balance]) => {
      const chainConfig = wp.getChainConfigs(chain as SupportedChain);
      // Name an unreachable chain so the intent model does not read its
      // absence as an empty balance (#31111).
      return balance.status === "ok"
        ? `${chain}: ${balance.balance} ${chainConfig.nativeCurrency.symbol}`
        : `${chain}: balance unavailable (RPC error)`;
    })
    .join(", ");
  const context = composePromptFromState({
    state,
    template: swapTemplate,
  });
  const llmResponse = await runIntentModel({
    runtime,
    taskName: "evm.swap.intent",
    template: context,
    modelType: ModelType.TEXT_LARGE,
  });
  const parsedResponse = parseJSONObjectFromText(llmResponse) as Record<string, unknown> | null;
  if (!parsedResponse) {
    throw new EVMError(
      EVMErrorCode.INVALID_PARAMS,
      "Failed to parse structured response from LLM for swap details."
    );
  }
  const chain = String(parsedResponse.chain ?? "").toLowerCase();
  const amountMode = resolveAmountMode(parsedResponse.amountMode);
  const fromToken = String(parsedResponse.inputToken ?? "");

  // `chain` is an arbitrary lowercased string from the model, so the balance
  // lookup is honestly `string | undefined` (resolveRelativeAmount throws when
  // it is undefined). Validation of the chain itself happens via parseSwapParams.
  const chainState = (balances as Record<string, ChainBalanceState | undefined>)[chain];
  const chainBalance: string | undefined =
    chainState?.status === "ok" ? chainState.balance : undefined;
  const amount =
    amountMode === "absolute"
      ? String(parsedResponse.amount ?? "")
      : await resolveRelativeSwapAmount(wp, chain, fromToken, amountMode, {
          rawPercent: parsedResponse.amountPercent,
          nativeBalance: chainBalance,
        });

  const swapDetails = parseSwapParams({
    fromToken,
    toToken: String(parsedResponse.outputToken ?? ""),
    amount,
    chain,
  });
  if (!wp.chains[swapDetails.chain]) {
    throw new EVMError(
      EVMErrorCode.CHAIN_NOT_CONFIGURED,
      `Chain ${swapDetails.chain} not configured. Available: ${chains.join(", ")}`
    );
  }
  return swapDetails;
}
const AMOUNT_MODES = ["absolute", "half", "max", "percent"] as const;
type AmountMode = (typeof AMOUNT_MODES)[number];
function resolveAmountMode(value: unknown): AmountMode {
  return AMOUNT_MODES.includes(value as AmountMode) ? (value as AmountMode) : "absolute";
}

const ERC20_BALANCE_ABI = parseAbi([
  "function balanceOf(address) view returns (uint256)",
  "function decimals() view returns (uint8)",
]);

/**
 * Decide whether the model's `fromToken` names the chain's native asset. The
 * caller only reaches this for a configured chain (else `getChainConfigs`
 * throws), so a token that is neither the zero-address sentinel nor the native
 * symbol is treated as an ERC-20 whose own balance must be consulted.
 */
function isNativeFromToken(wp: WalletProvider, chain: string, fromToken: string): boolean {
  if (fromToken === NATIVE_TOKEN_ADDRESS) {
    return true;
  }
  const chainConfig = wp.chains[chain] ? wp.getChainConfigs(chain as SupportedChain) : undefined;
  if (!chainConfig) {
    return false;
  }
  return fromToken.toUpperCase() === chainConfig.nativeCurrency.symbol.toUpperCase();
}

/**
 * Read the wallet's on-chain ERC-20 balance for `fromToken` as the raw
 * `balanceOf` integer alongside the token's `decimals`. A symbol is resolved
 * to its address through Li.Fi; a 0x address is used directly. The raw
 * `bigint` is returned (not a formatted string) so the relative-amount math
 * can stay in exact integer arithmetic and never round-trips through float64.
 * Any resolution or RPC failure becomes an INVALID_PARAMS error so the
 * relative-amount math never silently falls back to the native balance.
 */
async function fetchFromTokenBalance(
  wp: WalletProvider,
  chain: string,
  fromToken: string
): Promise<{ raw: bigint; decimals: number }> {
  const chainConfig = wp.getChainConfigs(chain as SupportedChain);
  try {
    const tokenAddress: Address =
      fromToken.startsWith("0x") && fromToken.length === 42
        ? (fromToken as Address)
        : ((await getToken(chainConfig.id, fromToken)).address as Address);

    const publicClient = wp.getPublicClient(chain as SupportedChain);
    const owner = wp.getAddress();

    const [rawBalance, decimals] = await Promise.all([
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_BALANCE_ABI,
        functionName: "balanceOf",
        args: [owner],
        authorizationList: undefined,
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_BALANCE_ABI,
        functionName: "decimals",
        authorizationList: undefined,
      }),
    ]);

    return { raw: BigInt(rawBalance as bigint), decimals: Number(decimals) };
  } catch (error) {
    // error-policy:J2 wrap the resolution/RPC failure with a typed, actionable
    // error; never resolve a relative amount against the wrong (native) basis.
    if (error instanceof EVMError) {
      throw error;
    }
    throw new EVMError(
      EVMErrorCode.INVALID_PARAMS,
      `Cannot resolve a relative swap amount: failed to read the ${fromToken} balance on ${chain}.`,
      error instanceof Error ? error : undefined
    );
  }
}

/**
 * Turn a relative swap intent into a concrete amount using the balance of the
 * token actually being sold. When `fromToken` is the native asset the native
 * chain balance is used (with the `max` gas reserve); otherwise the ERC-20
 * `fromToken` balance is fetched and used with no gas reserve, because the gas
 * token is a separate asset.
 */
async function resolveRelativeSwapAmount(
  wp: WalletProvider,
  chain: string,
  fromToken: string,
  mode: Exclude<AmountMode, "absolute">,
  opts: { rawPercent: unknown; nativeBalance: string | undefined }
): Promise<string> {
  if (isNativeFromToken(wp, chain, fromToken)) {
    // Native decimals are chain-specific (e.g. Tempo uses 6); fall back to
    // 18 only when the chain itself is not configured (parseSwapParams will
    // reject it below).
    const chainConfig = wp.chains[chain] ? wp.getChainConfigs(chain as SupportedChain) : undefined;
    const nativeDecimals = chainConfig?.nativeCurrency.decimals ?? 18;
    return resolveRelativeAmount(mode, opts.rawPercent, opts.nativeBalance, nativeDecimals);
  }
  const { raw, decimals } = await fetchFromTokenBalance(wp, chain, fromToken);
  return resolveRelativeTokenAmount(mode, opts.rawPercent, raw, decimals);
}

/**
 * Resolve a relative ERC-20 swap size ("half"/"max"/"percent") into an
 * absolute, human-readable amount using exact integer arithmetic on the raw
 * `balanceOf` value, formatting to decimal exactly once at the end. Working in
 * `bigint` keeps every wei of a token balance whose magnitude the caller does
 * not control: 18-decimal balances span both dust and >1e24-token ranges where
 * `Number(...).toString()` loses precision past ~15 significant digits and
 * emits exponential notation (e.g. `"5e-13"`, `"1e+24"`) that `parseUnits`
 * rejects. `max` spends the whole balance (gas is a separate asset). Throws
 * INVALID_PARAMS when the percentage is out of the 1-100 range.
 */
function resolveRelativeTokenAmount(
  mode: Exclude<AmountMode, "absolute">,
  rawPercent: unknown,
  raw: bigint,
  decimals: number
): string {
  if (mode === "half") {
    return formatUnits(raw / 2n, decimals);
  }
  if (mode === "max") {
    return formatUnits(raw, decimals);
  }

  const percent = Number(rawPercent);
  if (!Number.isFinite(percent) || percent < 1 || percent > 100) {
    throw new EVMError(
      EVMErrorCode.INVALID_PARAMS,
      `Swap percentage must be between 1 and 100, received: ${String(rawPercent)}`
    );
  }
  // Scale the percent to an integer basis-of-a-million so a fractional percent
  // stays representable while the (possibly huge) balance keeps every wei; the
  // division by 100_000_000 then yields `raw * percent / 100` in pure bigint.
  const scaledPercent = BigInt(Math.round(percent * 1_000_000));
  return formatUnits((raw * scaledPercent) / 100_000_000n, decimals);
}

/**
 * Reverse `formatUnits(wei, nativeDecimals)` exactly. `parseFloat` then
 * `Number#toString` turns tiny balances into `"5e-7"`, which `parseUnits`
 * rejects, so the relative swap never gets a quote.
 */
function nativeBalanceToWei(balance: string, nativeDecimals: number): bigint {
  try {
    return parseUnits(balance, nativeDecimals);
  } catch (error) {
    throw new EVMError(
      EVMErrorCode.INVALID_PARAMS,
      `Cannot resolve a relative swap amount: native balance is not an exact ${nativeDecimals}-decimal value.`,
      error instanceof Error ? error : undefined
    );
  }
}

/**
 * Resolve a relative native-asset swap size ("half"/"max"/"percent") into an
 * absolute, human-readable amount string from the supplied native balance.
 * `max` keeps a 10% gas reserve. Arithmetic stays in wei and floors, so the
 * quote cannot ask for more than that share. Throws INVALID_PARAMS when the
 * balance is unknown, not an exact decimal, or a percentage is outside 1-100.
 */
function resolveRelativeAmount(
  mode: Exclude<AmountMode, "absolute">,
  rawPercent: unknown,
  balance: string | undefined,
  nativeDecimals: number
): string {
  if (balance === undefined) {
    throw new EVMError(
      EVMErrorCode.INVALID_PARAMS,
      `Cannot resolve a relative swap amount: unknown balance for the selected chain.`
    );
  }
  const raw = nativeBalanceToWei(balance, nativeDecimals);
  if (mode === "max") {
    return formatUnits((raw * 9n) / 10n, nativeDecimals);
  }
  return resolveRelativeTokenAmount(mode, rawPercent, raw, nativeDecimals);
}
export const swapAction = {
  name: spec.name,
  description: spec.description,
  descriptionCompressed: spec.descriptionCompressed,
  contexts: ["finance", "crypto", "wallet"],
  contextGate: { anyOf: ["finance", "crypto", "wallet"] },
  roleGate: { minRole: "ADMIN" },
  parameters: [
    {
      name: "fromToken",
      description: "Input token symbol or address.",
      required: true,
      schema: { type: "string" },
    },
    {
      name: "toToken",
      description: "Output token symbol or address.",
      required: true,
      schema: { type: "string" },
    },
    {
      name: "amount",
      description: "Human-readable amount to swap.",
      required: true,
      schema: { type: "string" },
    },
    {
      name: "chain",
      description: "EVM chain for the swap.",
      required: false,
      schema: { type: "string" },
    },
  ],
  handler: async (
    runtime: IAgentRuntime,
    message: Memory,
    state?: State,
    _options?: Record<string, unknown>,
    callback?: HandlerCallback
  ): Promise<ActionResult> => {
    const walletProvider = await initWalletProvider(runtime);
    if (!state) {
      state = await runtime.composeState(message);
    }
    const swapOptions = await buildSwapDetails(state, message, runtime, walletProvider);
    const gate = await gateWalletFinancialExecution({
      runtime,
      message,
      params: {
        subaction: "swap",
        chain: swapOptions.chain,
        amount: swapOptions.amount,
        fromToken: swapOptions.fromToken,
        toToken: swapOptions.toToken,
        mode: "execute",
        dryRun: false,
      },
      callback,
    });
    if (!gate.proceed) {
      return walletFinancialGateActionResult(gate);
    }
    const action = new SwapAction(walletProvider);
    const swapResp = await action.swap(swapOptions);
    const successText = `✅ Successfully swapped ${swapOptions.amount} ${swapOptions.fromToken} for ${swapOptions.toToken} on ${swapOptions.chain}\nTransaction Hash: ${swapResp.hash}`;
    if (callback) {
      callback({
        text: successText,
        content: {
          success: true,
          hash: swapResp.hash,
          chain: swapOptions.chain,
          fromToken: swapOptions.fromToken,
          toToken: swapOptions.toToken,
          amount: swapOptions.amount,
        },
      });
    }
    return {
      success: true,
      text: successText,
      values: {
        swapSucceeded: true,
        inputToken: swapOptions.fromToken,
        outputToken: swapOptions.toToken,
      },
      data: {
        actionName: "EVM_SWAP_TOKENS",
        transactionHash: swapResp.hash,
        chain: swapOptions.chain,
        fromToken: swapOptions.fromToken,
        toToken: swapOptions.toToken,
        amount: swapOptions.amount,
      },
    };
  },
  template: swapTemplate,
  validate: createEvmActionValidator({
    keywords: ["swap", "exchange", "trade", "token"],
    regex: /\b(?:swap|exchange|trade|token)\b/i,
  }),
  examples: [
    [
      {
        name: "user",
        user: "user",
        content: {
          text: "Swap 1 WETH for USDC on Arbitrum",
          action: "TOKEN_SWAP",
        },
      },
    ],
    [
      {
        name: "user",
        user: "user",
        content: {
          text: "Please exchange 250 USDC to ETH on Base",
          action: "TOKEN_SWAP",
        },
      },
    ],
    [
      {
        name: "user",
        user: "user",
        content: {
          text: "Intercambia la mitad de mis USDT por ETH en Arbitrum",
          action: "TOKEN_SWAP",
        },
      },
    ],
    [
      {
        name: "user",
        user: "user",
        content: {
          text: "把我全部的 USDC 换成 WETH，在 Base 上",
          action: "TOKEN_SWAP",
        },
      },
    ],
    [
      {
        name: "user",
        user: "user",
        content: {
          text: "Trade 30% of my ETH balance into USDC",
          action: "TOKEN_SWAP",
        },
      },
    ],
  ],
  similes: spec.similes ? [...spec.similes] : [],
};
