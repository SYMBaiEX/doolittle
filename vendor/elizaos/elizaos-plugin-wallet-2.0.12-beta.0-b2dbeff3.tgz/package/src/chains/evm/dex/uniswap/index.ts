/**
 * Uniswap V3 liquidity-pool management sub-plugin: registers
 * `UniswapV3LpService` and its LP protocol provider with the shared
 * `LpManagementService` registry.
 */
import type { IAgentRuntime, Plugin } from "@elizaos/core";
import {
  createEvmLpProtocolProvider,
  registerLpProtocolProvider,
} from "../../../../lp/services/LpManagementService.ts";
import { UniswapV3LpService } from "./services/UniswapV3LpService.ts";

export const uniswapPlugin: Plugin = {
  name: "@elizaos/plugin-lp-manager/uniswap",
  description: "Uniswap V3 liquidity pool management plugin",
  services: [UniswapV3LpService],
  actions: [],
  providers: [],
  init: async (_config: Record<string, string>, runtime: IAgentRuntime) => {
    console.info("Uniswap V3 Plugin initialized");
    const service =
      runtime.getService<UniswapV3LpService>(
        UniswapV3LpService.serviceType,
      ) ?? (await UniswapV3LpService.start(runtime));
    await registerLpProtocolProvider(
      runtime,
      createEvmLpProtocolProvider({
        dex: "uniswap",
        label: "Uniswap V3",
        service,
        appliesRange: true,
        closeNeedsTokenId: true,
      }),
    );
  },
  async dispose(runtime: IAgentRuntime) {
    const svc = runtime.getService<UniswapV3LpService>(
      UniswapV3LpService.serviceType,
    );
    await svc?.stop();
  },
};

export * from "./types.ts";
export { UniswapV3LpService };

export default uniswapPlugin;
