/**
 * Aerodrome (Base) DEX liquidity-pool management sub-plugin: registers
 * `AerodromeLpService` and its LP protocol provider with the shared
 * `LpManagementService` registry.
 */
import type { IAgentRuntime, Plugin } from "@elizaos/core";
import {
  createEvmLpProtocolProvider,
  registerLpProtocolProvider,
} from "../../../../lp/services/LpManagementService.ts";
import { AerodromeLpService } from "./services/AerodromeLpService.ts";

export const aerodromePlugin: Plugin = {
  name: "@elizaos/plugin-lp-manager/aerodrome",
  description: "Aerodrome DEX liquidity pool management plugin for Base chain",
  services: [AerodromeLpService],
  actions: [],
  providers: [],
  init: async (_config: Record<string, string>, runtime: IAgentRuntime) => {
    console.info("Aerodrome Plugin initialized");
    const service =
      runtime.getService<AerodromeLpService>(AerodromeLpService.serviceType) ??
      (await AerodromeLpService.start(runtime));
    await registerLpProtocolProvider(
      runtime,
      createEvmLpProtocolProvider({
        dex: "aerodrome",
        label: "Aerodrome",
        service,
        closeAppliesAmount: true,
      }),
    );
  },
  async dispose(runtime: IAgentRuntime) {
    const svc = runtime.getService<AerodromeLpService>(
      AerodromeLpService.serviceType,
    );
    await svc?.stop();
  },
};

export * from "./types.ts";
export { AerodromeLpService };

export default aerodromePlugin;
