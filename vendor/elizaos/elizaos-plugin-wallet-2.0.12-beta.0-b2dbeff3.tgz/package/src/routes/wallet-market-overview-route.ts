/**
 * `handleWalletMarketOverviewRoute` serves `/api/wallet/market-overview`:
 * price snapshots and top movers from CoinGecko plus highlighted Polymarket
 * predictions, normalized into `WalletMarketOverviewResponse` and merged into
 * per-source `WalletMarketOverviewSource` status (available/stale/error) so
 * the client can render partial data gracefully. Uses the cloud preview
 * endpoint (`resolveCloudApiBaseUrl`) first, then fills unavailable price/mover
 * sources from direct CoinGecko feeds. Caches successful responses for
 * `MARKET_OVERVIEW_CACHE_TTL_MS`
 * and serves stale-but-cached data on upstream failure, and rate-limits
 * refreshes per client address via `consumeRefreshSlot`.
 */
import type http from "node:http";
import { logger } from "@elizaos/core";
import { resolveCloudApiBaseUrl } from "@elizaos/plugin-elizacloud/cloud-config/base-url";
import type {
  WalletMarketOverviewResponse,
  WalletMarketOverviewSource,
  WalletMarketPrediction,
} from "../contracts.js";
import {
  buildCoinGeckoMarketsUrl,
  buildMarketMovers,
  buildMarketPriceSnapshots,
  COINGECKO_MARKET_PROVIDER,
  type CoinGeckoMarketRecord,
  POLYMARKET_MARKET_PROVIDER,
  parseCoinGeckoMarkets,
} from "../lib/market-overview.js";

const MARKET_OVERVIEW_PATH = "/api/wallet/market-overview";
const CLOUD_MARKET_OVERVIEW_PREVIEW_PATH = "/market/preview/wallet-overview";
const MARKET_OVERVIEW_CACHE_TTL_MS = 120_000;
const MARKET_OVERVIEW_FETCH_TIMEOUT_MS = 8_000;
const MARKET_OVERVIEW_REFRESH_WINDOW_MS = 60_000;
const MARKET_OVERVIEW_REFRESH_LIMIT = 24;
const POLYMARKET_MARKET_LIMIT = 10;
const CACHE_CONTROL_VALUE = "public, max-age=60, stale-while-revalidate=180";

function isAbortError(error: unknown): boolean {
  return error instanceof DOMException
    ? error.name === "AbortError" || error.name === "TimeoutError"
    : error instanceof Error &&
        (error.name === "AbortError" || error.name === "TimeoutError");
}

function createTimeoutError(message: string): Error {
  const timeoutError = new Error(message);
  timeoutError.name = "TimeoutError";
  return timeoutError;
}

async function fetchWithTimeoutGuard(
  input: string | URL,
  init: RequestInit,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const upstreamSignal = init.signal;
  let timedOut = false;

  const onAbort = () => {
    controller.abort();
  };

  if (upstreamSignal) {
    if (upstreamSignal.aborted) {
      controller.abort();
    } else {
      upstreamSignal.addEventListener("abort", onAbort, { once: true });
    }
  }

  const timeoutHandle = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  try {
    return await fetch(input, {
      ...init,
      signal: controller.signal,
    });
  } catch (error) {
    if (timedOut && isAbortError(error)) {
      throw createTimeoutError(
        `Upstream request timed out after ${timeoutMs}ms`,
      );
    }
    throw error;
  } finally {
    clearTimeout(timeoutHandle);
    if (upstreamSignal) {
      upstreamSignal.removeEventListener("abort", onAbort);
    }
  }
}

interface PolymarketMarketRecord {
  slug: string | null;
  question: string;
  outcomeLabels: string[];
  outcomeProbabilities: (number | null)[];
  volume24hUsd: number;
  totalVolumeUsd: number | null;
  endsAt: string | null;
  imageUrl: string | null;
}

interface CachedWalletMarketOverview {
  response: WalletMarketOverviewResponse;
  expiresAt: number;
}

interface RateLimitBucket {
  count: number;
  resetAt: number;
}

type WalletMarketOverviewFetch = typeof fetchWithTimeoutGuard;

let cachedWalletMarketOverview: CachedWalletMarketOverview | null = null;
let walletMarketOverviewInFlight: Promise<WalletMarketOverviewResponse> | null =
  null;
const walletMarketRefreshBuckets = new Map<string, RateLimitBucket>();
let walletMarketOverviewFetch: WalletMarketOverviewFetch =
  fetchWithTimeoutGuard;

function scrubStackFields(value: unknown): unknown {
  if (value instanceof Error) {
    return { error: value.message || "Internal error" };
  }
  if (Array.isArray(value)) {
    return value.map(scrubStackFields);
  }
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [key, nestedValue] of Object.entries(
      value as Record<string, unknown>,
    )) {
      if (key === "stack" || key === "stackTrace") continue;
      out[key] = scrubStackFields(nestedValue);
    }
    return out;
  }
  return value;
}

function sendJson(
  res: http.ServerResponse,
  status: number,
  body: unknown,
): void {
  if (res.headersSent) return;
  res.statusCode = status;
  res.setHeader("content-type", "application/json; charset=utf-8");
  res.end(JSON.stringify(scrubStackFields(body)));
}

function sendJsonError(
  res: http.ServerResponse,
  status: number,
  message: string,
): void {
  sendJson(res, status, { error: message });
}

function marketOverviewErrorMessage(error: unknown): string {
  return error instanceof Error && error.message.trim().length > 0
    ? error.message.trim()
    : "Upstream market feed failed";
}

function buildMarketOverviewSource(
  source: Pick<
    WalletMarketOverviewSource,
    "providerId" | "providerName" | "providerUrl"
  >,
  {
    available,
    stale,
    error,
  }: Pick<WalletMarketOverviewSource, "available" | "stale" | "error">,
): WalletMarketOverviewSource {
  return {
    ...source,
    available,
    stale,
    error,
  };
}

function markMarketOverviewSourcesStale(
  sources: WalletMarketOverviewResponse["sources"],
): WalletMarketOverviewResponse["sources"] {
  return {
    prices: {
      ...sources.prices,
      stale: true,
    },
    movers: {
      ...sources.movers,
      stale: true,
    },
    predictions: {
      ...sources.predictions,
      stale: true,
    },
  };
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function numberFromUnknown(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value !== "string" || value.trim().length === 0) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function stringFromUnknown(value: unknown): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value : null;
}

function parseArray(value: unknown): unknown[] {
  if (Array.isArray(value)) {
    return value;
  }

  if (typeof value !== "string" || value.trim().length === 0) return [];

  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function clampProbability(value: number | null): number | null {
  if (value === null || !Number.isFinite(value)) return null;
  return Math.min(1, Math.max(0, value));
}

function mapPolymarketMarket(input: unknown): PolymarketMarketRecord | null {
  const record = asRecord(input);
  if (!record) return null;

  const question = stringFromUnknown(record.question);
  if (!question) return null;

  const outcomeLabels = parseArray(record.outcomes).map(
    (value) => stringFromUnknown(value) ?? "",
  );
  const outcomeProbabilities = parseArray(record.outcomePrices).map((value) =>
    clampProbability(numberFromUnknown(value)),
  );
  const volume24hUsd = numberFromUnknown(record.volume24hr);

  if (volume24hUsd === null) return null;

  return {
    slug: stringFromUnknown(record.slug),
    question,
    outcomeLabels,
    outcomeProbabilities,
    volume24hUsd,
    totalVolumeUsd: numberFromUnknown(record.volume),
    endsAt: stringFromUnknown(record.endDate),
    imageUrl: stringFromUnknown(record.image) ?? stringFromUnknown(record.icon),
  };
}

function highlightedPredictionOutcome(market: PolymarketMarketRecord): {
  label: string;
  probability: number | null;
} {
  const yesIndex = market.outcomeLabels.findIndex(
    (label) => label.trim().toLowerCase() === "yes",
  );
  if (yesIndex >= 0) {
    return {
      label: market.outcomeLabels[yesIndex] ?? "Yes",
      probability: market.outcomeProbabilities[yesIndex] ?? null,
    };
  }

  let highestIndex = -1;
  let highestProbability = -1;
  for (const [index, probability] of market.outcomeProbabilities.entries()) {
    if (probability !== null && probability > highestProbability) {
      highestIndex = index;
      highestProbability = probability;
    }
  }

  if (highestIndex >= 0) {
    return {
      label: market.outcomeLabels[highestIndex] || "Top",
      probability: market.outcomeProbabilities[highestIndex] ?? null,
    };
  }

  return { label: "Top", probability: null };
}

async function fetchCoinGeckoMarkets(): Promise<CoinGeckoMarketRecord[]> {
  const response = await walletMarketOverviewFetch(
    buildCoinGeckoMarketsUrl(),
    {
      method: "GET",
      headers: {
        accept: "application/json",
        "user-agent": "Eliza Wallet Market Feed/1.0",
      },
    },
    MARKET_OVERVIEW_FETCH_TIMEOUT_MS,
  );

  if (!response.ok) {
    throw new Error(`CoinGecko responded ${response.status}`);
  }

  const payload: unknown = await response.json();
  return parseCoinGeckoMarkets(payload);
}

async function fetchPolymarketMarkets(): Promise<PolymarketMarketRecord[]> {
  const url = new URL("https://gamma-api.polymarket.com/markets");
  url.searchParams.set("active", "true");
  url.searchParams.set("closed", "false");
  url.searchParams.set("order", "volume24hr");
  url.searchParams.set("ascending", "false");
  url.searchParams.set("limit", String(POLYMARKET_MARKET_LIMIT));

  const response = await walletMarketOverviewFetch(
    url,
    {
      method: "GET",
      headers: {
        accept: "application/json",
        "user-agent": "Eliza Wallet Market Feed/1.0",
      },
    },
    MARKET_OVERVIEW_FETCH_TIMEOUT_MS,
  );

  if (!response.ok) {
    throw new Error(`Polymarket responded ${response.status}`);
  }

  const payload: unknown = await response.json();
  if (!Array.isArray(payload)) {
    throw new Error("Polymarket payload was not an array");
  }

  return payload
    .map(mapPolymarketMarket)
    .filter((market): market is PolymarketMarketRecord => market !== null);
}

function buildPredictions(
  markets: PolymarketMarketRecord[],
): WalletMarketPrediction[] {
  const seenQuestions = new Set<string>();
  const predictions: WalletMarketPrediction[] = [];

  for (const market of markets) {
    const normalizedQuestion = market.question.trim().toLowerCase();
    if (seenQuestions.has(normalizedQuestion)) continue;
    seenQuestions.add(normalizedQuestion);

    const highlightedOutcome = highlightedPredictionOutcome(market);
    predictions.push({
      id: market.slug ?? normalizedQuestion,
      slug: market.slug,
      question: market.question,
      highlightedOutcomeLabel: highlightedOutcome.label,
      highlightedOutcomeProbability: highlightedOutcome.probability,
      volume24hUsd: market.volume24hUsd,
      totalVolumeUsd: market.totalVolumeUsd,
      endsAt: market.endsAt,
      imageUrl: market.imageUrl,
    });
  }

  return predictions.slice(0, 6);
}

function isWalletMarketOverviewSource(
  value: unknown,
): value is WalletMarketOverviewResponse["sources"][keyof WalletMarketOverviewResponse["sources"]] {
  const record = asRecord(value);
  return (
    record !== null &&
    typeof record.providerId === "string" &&
    typeof record.providerName === "string" &&
    typeof record.providerUrl === "string" &&
    typeof record.available === "boolean" &&
    typeof record.stale === "boolean" &&
    (typeof record.error === "string" || record.error === null)
  );
}

function isWalletMarketOverviewResponse(
  value: unknown,
): value is WalletMarketOverviewResponse {
  const record = asRecord(value);
  const sources = asRecord(record?.sources);
  return (
    record !== null &&
    typeof record.generatedAt === "string" &&
    typeof record.cacheTtlSeconds === "number" &&
    typeof record.stale === "boolean" &&
    sources !== null &&
    isWalletMarketOverviewSource(sources.prices) &&
    isWalletMarketOverviewSource(sources.movers) &&
    isWalletMarketOverviewSource(sources.predictions) &&
    Array.isArray(record.prices) &&
    Array.isArray(record.movers) &&
    Array.isArray(record.predictions)
  );
}

function resolveWalletMarketOverviewCloudPreviewUrl(): string {
  return `${resolveCloudApiBaseUrl(process.env.ELIZAOS_CLOUD_BASE_URL)}${CLOUD_MARKET_OVERVIEW_PREVIEW_PATH}`;
}

async function fetchCloudWalletMarketOverview(
  clientAddress: string,
): Promise<WalletMarketOverviewResponse> {
  const response = await walletMarketOverviewFetch(
    resolveWalletMarketOverviewCloudPreviewUrl(),
    {
      method: "GET",
      headers: {
        accept: "application/json",
        "user-agent": "Eliza Wallet Market Feed/1.0",
        ...(clientAddress !== "unknown"
          ? { "x-forwarded-for": clientAddress }
          : {}),
      },
    },
    MARKET_OVERVIEW_FETCH_TIMEOUT_MS,
  );

  if (!response.ok) {
    throw new Error(`Cloud preview responded ${response.status}`);
  }

  const payload: unknown = await response.json();
  if (!isWalletMarketOverviewResponse(payload)) {
    throw new Error("Cloud preview payload was invalid");
  }

  return payload;
}

async function buildWalletMarketOverview(
  clientAddress: string,
): Promise<WalletMarketOverviewResponse> {
  const [cloudPreviewResult, polymarketResult] = await Promise.allSettled([
    fetchCloudWalletMarketOverview(clientAddress),
    fetchPolymarketMarkets(),
  ]);
  const polymarketMarkets =
    polymarketResult.status === "fulfilled" ? polymarketResult.value : [];
  const polymarketError =
    polymarketResult.status === "rejected"
      ? marketOverviewErrorMessage(polymarketResult.reason)
      : null;

  if (cloudPreviewResult.status === "fulfilled") {
    if (polymarketError) {
      logger.warn(
        `[WalletMarketOverviewRoute] Polymarket feed unavailable (${polymarketError})`,
      );
    }

    const cloud = cloudPreviewResult.value;
    const response = { ...cloud, sources: { ...cloud.sources } };
    if (!cloud.sources.prices.available || !cloud.sources.movers.available) {
      try {
        const markets = await fetchCoinGeckoMarkets();
        const source = buildMarketOverviewSource(COINGECKO_MARKET_PROVIDER, {
          available: true,
          stale: false,
          error: null,
        });
        if (!cloud.sources.prices.available) {
          response.prices = buildMarketPriceSnapshots(markets);
          response.sources.prices = source;
        }
        if (!cloud.sources.movers.available) {
          response.movers = buildMarketMovers(markets);
          response.sources.movers = source;
        }
      } catch (error) {
        // error-policy:J4 Preserve the cloud's partial/stale data and source
        // errors if the independently attempted direct feed is unavailable too.
        logger.warn(
          `[WalletMarketOverviewRoute] Direct CoinGecko fallback unavailable (${marketOverviewErrorMessage(error)})`,
        );
      }
    }
    if (polymarketError === null) {
      response.predictions = buildPredictions(polymarketMarkets);
      response.sources.predictions = buildMarketOverviewSource(
        POLYMARKET_MARKET_PROVIDER,
        {
          available: true,
          stale: false,
          error: null,
        },
      );
    }
    return response;
  }

  {
    const error = cloudPreviewResult.reason;
    logger.warn(
      `[WalletMarketOverviewRoute] Cloud preview unavailable (${marketOverviewErrorMessage(error)}); falling back to direct feeds`,
    );
  }

  const [coinGeckoResult] = await Promise.allSettled([fetchCoinGeckoMarkets()]);
  const coinGeckoMarkets =
    coinGeckoResult.status === "fulfilled" ? coinGeckoResult.value : [];
  const coinGeckoError =
    coinGeckoResult.status === "rejected"
      ? marketOverviewErrorMessage(coinGeckoResult.reason)
      : null;

  if (coinGeckoError) {
    logger.warn(
      `[WalletMarketOverviewRoute] CoinGecko feed unavailable (${coinGeckoError})`,
    );
  }

  if (polymarketError) {
    logger.warn(
      `[WalletMarketOverviewRoute] Polymarket feed unavailable (${polymarketError})`,
    );
  }

  if (coinGeckoError && polymarketError) {
    throw new Error(
      `CoinGecko: ${coinGeckoError}; Polymarket: ${polymarketError}`,
    );
  }

  return {
    generatedAt: new Date().toISOString(),
    cacheTtlSeconds: Math.floor(MARKET_OVERVIEW_CACHE_TTL_MS / 1000),
    stale: false,
    sources: {
      prices: buildMarketOverviewSource(COINGECKO_MARKET_PROVIDER, {
        available: coinGeckoError === null,
        stale: false,
        error: coinGeckoError,
      }),
      movers: buildMarketOverviewSource(COINGECKO_MARKET_PROVIDER, {
        available: coinGeckoError === null,
        stale: false,
        error: coinGeckoError,
      }),
      predictions: buildMarketOverviewSource(POLYMARKET_MARKET_PROVIDER, {
        available: polymarketError === null,
        stale: false,
        error: polymarketError,
      }),
    },
    prices: buildMarketPriceSnapshots(coinGeckoMarkets),
    movers: buildMarketMovers(coinGeckoMarkets),
    predictions: buildPredictions(polymarketMarkets),
  };
}

function freshCachedWalletMarketOverview(): WalletMarketOverviewResponse | null {
  if (
    !cachedWalletMarketOverview ||
    cachedWalletMarketOverview.expiresAt <= Date.now()
  ) {
    return null;
  }

  return cachedWalletMarketOverview.response;
}

function staleCachedWalletMarketOverview(): WalletMarketOverviewResponse | null {
  if (!cachedWalletMarketOverview) return null;
  return {
    ...cachedWalletMarketOverview.response,
    stale: true,
    sources: markMarketOverviewSourcesStale(
      cachedWalletMarketOverview.response.sources,
    ),
  };
}

function resolveClientAddress(req: http.IncomingMessage): string {
  const forwardedFor = req.headers["x-forwarded-for"];
  if (typeof forwardedFor === "string" && forwardedFor.trim().length > 0) {
    return forwardedFor.split(",")[0]?.trim() || "unknown";
  }
  if (Array.isArray(forwardedFor) && forwardedFor.length > 0) {
    return forwardedFor[0]?.trim() || "unknown";
  }
  return req.socket.remoteAddress ?? "unknown";
}

function consumeRefreshSlot(clientAddress: string): {
  allowed: boolean;
  retryAfterSeconds: number;
} {
  const now = Date.now();

  for (const [key, bucket] of walletMarketRefreshBuckets) {
    if (bucket.resetAt <= now) {
      walletMarketRefreshBuckets.delete(key);
    }
  }

  const bucket = walletMarketRefreshBuckets.get(clientAddress);
  if (!bucket || bucket.resetAt <= now) {
    walletMarketRefreshBuckets.set(clientAddress, {
      count: 1,
      resetAt: now + MARKET_OVERVIEW_REFRESH_WINDOW_MS,
    });
    return {
      allowed: true,
      retryAfterSeconds: Math.ceil(MARKET_OVERVIEW_REFRESH_WINDOW_MS / 1000),
    };
  }

  if (bucket.count >= MARKET_OVERVIEW_REFRESH_LIMIT) {
    return {
      allowed: false,
      retryAfterSeconds: Math.max(1, Math.ceil((bucket.resetAt - now) / 1000)),
    };
  }

  bucket.count += 1;
  walletMarketRefreshBuckets.set(clientAddress, bucket);
  return {
    allowed: true,
    retryAfterSeconds: Math.max(1, Math.ceil((bucket.resetAt - now) / 1000)),
  };
}

function setPublicMarketHeaders(res: http.ServerResponse): void {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", CACHE_CONTROL_VALUE);
}

async function loadWalletMarketOverview(
  clientAddress: string,
): Promise<WalletMarketOverviewResponse> {
  const fresh = freshCachedWalletMarketOverview();
  if (fresh) return fresh;

  if (!walletMarketOverviewInFlight) {
    walletMarketOverviewInFlight = buildWalletMarketOverview(clientAddress)
      .then((response) => {
        cachedWalletMarketOverview = {
          response,
          expiresAt: Date.now() + MARKET_OVERVIEW_CACHE_TTL_MS,
        };
        return response;
      })
      .catch((error) => {
        const stale = staleCachedWalletMarketOverview();
        if (stale) {
          logger.warn(
            `[WalletMarketOverviewRoute] Refresh failed; serving stale market overview (${error instanceof Error ? error.message : String(error)})`,
          );
          return stale;
        }
        throw error;
      })
      .finally(() => {
        walletMarketOverviewInFlight = null;
      });
  }

  return walletMarketOverviewInFlight;
}

export async function handleWalletMarketOverviewRoute(
  req: http.IncomingMessage,
  res: http.ServerResponse,
): Promise<boolean> {
  const method = (req.method ?? "GET").toUpperCase();
  const url = new URL(req.url ?? "/", "http://localhost");

  if (url.pathname !== MARKET_OVERVIEW_PATH) {
    return false;
  }

  setPublicMarketHeaders(res);

  if (method === "OPTIONS") {
    res.statusCode = 204;
    res.end();
    return true;
  }

  if (method !== "GET") {
    sendJsonError(res, 405, "Method not allowed");
    return true;
  }

  const clientAddress = resolveClientAddress(req);

  const fresh = freshCachedWalletMarketOverview();
  if (fresh) {
    sendJson(res, 200, fresh);
    return true;
  }

  if (!walletMarketOverviewInFlight) {
    const rateLimit = consumeRefreshSlot(clientAddress);
    if (!rateLimit.allowed) {
      const stale = staleCachedWalletMarketOverview();
      if (stale) {
        sendJson(res, 200, stale);
        return true;
      }
      res.setHeader("Retry-After", String(rateLimit.retryAfterSeconds));
      sendJsonError(res, 429, "Too many market overview refreshes");
      return true;
    }
  }

  try {
    const overview = await loadWalletMarketOverview(clientAddress);
    sendJson(res, 200, overview);
  } catch (error) {
    logger.error(
      `[WalletMarketOverviewRoute] Failed to load market overview (${error instanceof Error ? error.message : String(error)})`,
    );
    sendJsonError(res, 502, "Failed to load market overview");
  }

  return true;
}

export function __resetWalletMarketOverviewCacheForTests(): void {
  cachedWalletMarketOverview = null;
  walletMarketOverviewInFlight = null;
  walletMarketRefreshBuckets.clear();
  walletMarketOverviewFetch = fetchWithTimeoutGuard;
}

export function __setWalletMarketOverviewFetchForTests(
  fetcher: WalletMarketOverviewFetch,
): void {
  walletMarketOverviewFetch = fetcher;
}
