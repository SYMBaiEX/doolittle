/**
 * DexScreener HTTP client (`Service` of type `"dexscreener"`): pair/token
 * search, trending/new-pair discovery, boosted tokens, and price/order
 * lookups. Several methods are proxies over endpoints DexScreener doesn't
 * expose directly (trending, new pairs) — see inline notes per method.
 * Resolves its base URL + auth headers from Eliza Cloud routing when no
 * direct `DEXSCREENER_API_URL` is configured, and self rate-limits between
 * requests via `DEXSCREENER_RATE_LIMIT_DELAY`.
 */

import { cloudServiceApisBaseUrl } from "@elizaos/cloud-routing";
import { type IAgentRuntime, Service } from "@elizaos/core";
import { parseClampedInteger } from "@elizaos/core/protocol";
import { toWalletCloudRoutingSettings } from "../cloud-routing-authority";
import { dexScreenerErrorMessage } from "./errors";
import type {
  DexScreenerBoostedToken,
  DexScreenerChainParams,
  DexScreenerConfig,
  DexScreenerNewPairsParams,
  DexScreenerOrder,
  DexScreenerPair,
  DexScreenerPairParams,
  DexScreenerProfile,
  DexScreenerSearchParams,
  DexScreenerServiceResponse,
  DexScreenerTokenParams,
  DexScreenerTrendingParams,
} from "./types";

type DexScreenerBoostedWire = DexScreenerBoostedToken & {
  labels?: string[];
};
type TokensV1Wire = DexScreenerPair | DexScreenerPair[];

/** Omitted or non-finite means the method default. Explicit 0 is an empty page. */
function explicitListLimit(
  limit: number | undefined,
  fallback: number,
): number {
  if (typeof limit !== "number" || !Number.isFinite(limit)) return fallback;
  return Math.max(0, Math.floor(limit));
}
export class DexScreenerService extends Service {
  static serviceType = "dexscreener" as const;
  private baseUrl!: string;
  private defaultHeaders!: Record<string, string>;
  private dexConfig!: DexScreenerConfig;
  private lastRequestTime = 0;
  public capabilityDescription =
    "Provides DEX analytics and token information from DexScreener";
  static async start(runtime: IAgentRuntime): Promise<Service> {
    const service = new DexScreenerService(runtime);
    const customBase = String(
      runtime.getSetting("DEXSCREENER_API_URL") ?? "",
    ).trim();
    const delayRaw = runtime.getSetting("DEXSCREENER_RATE_LIMIT_DELAY");
    const rateLimitDelay = parseClampedInteger(String(delayRaw ?? "100"), {
      min: 0,
      max: 5000,
      fallback: 100,
    });
    let apiUrl: string;
    const authHeaders: Record<string, string> = {};
    if (customBase.length > 0) {
      apiUrl = customBase.replace(/\/+$/, "");
    } else {
      const cloud = cloudServiceApisBaseUrl(
        toWalletCloudRoutingSettings(runtime),
        "dexscreener",
      );
      if (cloud !== null) {
        apiUrl = cloud.baseUrl;
        Object.assign(authHeaders, cloud.headers);
      } else {
        apiUrl = "https://api.dexscreener.com";
      }
    }
    service.dexConfig = {
      apiUrl,
      rateLimitDelay,
    };
    service.baseUrl = apiUrl;
    service.defaultHeaders = {
      Accept: "application/json",
      "User-Agent": "ElizaOS-DexScreener-Plugin/1.0",
      ...authHeaders,
    };
    return service;
  }
  async stop(): Promise<void> {}
  private async get<T>(
    path: string,
    params?: Record<string, string>,
  ): Promise<T> {
    let url = `${this.baseUrl}${path}`;
    if (params && Object.keys(params).length > 0) {
      url += `?${new URLSearchParams(params).toString()}`;
    }
    const response = await fetch(url, {
      headers: this.defaultHeaders,
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw Object.assign(
        new Error(errData?.message || `HTTP ${response.status}`),
        {
          response: { data: errData },
        },
      );
    }
    return response.json() as Promise<T>;
  }
  private async rateLimit(): Promise<void> {
    const delayMs = this.dexConfig.rateLimitDelay ?? 100;
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    if (timeSinceLastRequest < delayMs) {
      await new Promise((resolve) =>
        setTimeout(resolve, delayMs - timeSinceLastRequest),
      );
    }
    this.lastRequestTime = Date.now();
  }
  async search(
    params: DexScreenerSearchParams,
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      await this.rateLimit();
      const data = await this.get<{
        pairs?: DexScreenerPair[];
      }>(`/latest/dex/search`, { q: params.query });
      return {
        success: true,
        data: data.pairs || [],
      };
    } catch (caught: unknown) {
      console.error("DexScreener search error:", caught);
      return {
        success: false,
        error: dexScreenerErrorMessage(caught) || "Failed to search tokens",
      };
    }
  }
  async getTokenPairs(
    params: DexScreenerTokenParams,
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      await this.rateLimit();
      const data = await this.get<{
        pairs?: DexScreenerPair[];
      }>(`/latest/dex/tokens/${params.tokenAddress}`);
      return {
        success: true,
        data: data.pairs || [],
      };
    } catch (caught: unknown) {
      console.error("DexScreener getTokenPairs error:", caught);
      return {
        success: false,
        error: dexScreenerErrorMessage(caught) || "Failed to get token pairs",
      };
    }
  }
  async getPair(
    params: DexScreenerPairParams,
  ): Promise<DexScreenerServiceResponse<DexScreenerPair>> {
    try {
      await this.rateLimit();
      const data = await this.get<{
        pair?: DexScreenerPair;
      }>(`/latest/dex/pairs/${params.pairAddress}`);
      if (!data.pair) {
        return {
          success: false,
          error: "Pair not found",
        };
      }
      return {
        success: true,
        data: data.pair,
      };
    } catch (caught: unknown) {
      console.error("DexScreener getPair error:", caught);
      return {
        success: false,
        error: dexScreenerErrorMessage(caught) || "Failed to get pair",
      };
    }
  }
  async getTrending(
    params: DexScreenerTrendingParams = {},
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      const limit = explicitListLimit(params.limit, 10);
      if (limit === 0) {
        return { success: true, data: [] };
      }
      await this.rateLimit();
      // DexScreener has no direct trending endpoint; use top boosted tokens
      // as a proxy signal.
      const responseData = await this.get<
        DexScreenerBoostedToken[] | DexScreenerBoostedToken
      >(`/token-boosts/top/v1`);
      const boostedTokens = Array.isArray(responseData)
        ? responseData
        : [responseData];
      const pairPromises = boostedTokens.slice(0, limit).map(async (token) => {
        try {
          const pairData = await this.get<TokensV1Wire>(
            `/tokens/v1/${token.chainId}/${token.tokenAddress}`,
          );
          // A boosted token with no pairs returns []; [][0] is undefined,
          // which would leak past the downstream `!== null` filter, so guard
          // the length like getNewPairs does.
          return Array.isArray(pairData) && pairData.length > 0
            ? pairData[0]
            : null;
        } catch (error) {
          console.error(
            `Failed to get pair data for ${token.tokenAddress}:`,
            error,
          );
          return null;
        }
      });
      const pairs = (await Promise.all(pairPromises)).filter(
        (pair) => pair !== null,
      );
      return {
        success: true,
        data: pairs,
      };
    } catch (caught: unknown) {
      console.error("DexScreener getTrending error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) || "Failed to get trending pairs",
      };
    }
  }
  async getPairsByChain(
    params: DexScreenerChainParams,
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      const limit = explicitListLimit(params.limit, 20);
      if (limit === 0) {
        return { success: true, data: [] };
      }
      await this.rateLimit();
      // DexScreener has no chain-scoped listing endpoint, so search by chain
      // name and filter the results down to that chain.
      const data = await this.get<{
        pairs?: DexScreenerPair[];
      }>(`/latest/dex/search`, { q: params.chain });
      let pairs: DexScreenerPair[] = data.pairs || [];
      pairs = pairs.filter(
        (pair) => pair.chainId.toLowerCase() === params.chain.toLowerCase(),
      );
      if (params.sortBy) {
        pairs.sort((a, b) => {
          switch (params.sortBy) {
            case "volume":
              return (b.volume.h24 || 0) - (a.volume.h24 || 0);
            case "liquidity":
              return (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0);
            case "priceChange":
              return (b.priceChange.h24 || 0) - (a.priceChange.h24 || 0);
            case "txns":
              return (
                (b.txns.h24.buys + b.txns.h24.sells || 0) -
                (a.txns.h24.buys + a.txns.h24.sells || 0)
              );
            default:
              return 0;
          }
        });
      }
      const limitedPairs = pairs.slice(0, limit);
      return {
        success: true,
        data: limitedPairs,
      };
    } catch (caught: unknown) {
      console.error("DexScreener getPairsByChain error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) || "Failed to get pairs by chain",
      };
    }
  }
  async getNewPairs(
    params: DexScreenerNewPairsParams = {},
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      const limit = explicitListLimit(params.limit, 10);
      if (limit === 0) {
        return { success: true, data: [] };
      }
      await this.rateLimit();
      // DexScreener has no direct new-pairs endpoint; use the latest token
      // profiles as a proxy for newly listed tokens.
      const responseData = await this.get<
        DexScreenerProfile[] | DexScreenerProfile
      >(`/token-profiles/latest/v1`);
      const profiles = Array.isArray(responseData)
        ? responseData
        : [responseData];
      const filteredProfiles = params.chain
        ? profiles.filter(
            (p) => p.chainId.toLowerCase() === params.chain?.toLowerCase(),
          )
        : profiles;
      const pairPromises = filteredProfiles
        .slice(0, limit)
        .map(async (profile) => {
          try {
            const pairData = await this.get<TokensV1Wire>(
              `/tokens/v1/${profile.chainId}/${profile.tokenAddress}`,
            );
            const pairs = Array.isArray(pairData) ? pairData : [];
            if (pairs.length > 0) {
              return {
                ...pairs[0],
                labels: pairs[0].labels?.includes("new")
                  ? pairs[0].labels
                  : [...(pairs[0].labels || []), "new"],
              };
            }
            return null;
          } catch (error) {
            console.error(
              `Failed to get pair data for ${profile.tokenAddress}:`,
              error,
            );
            return null;
          }
        });
      const pairs = (await Promise.all(pairPromises)).filter(
        (pair) => pair !== null,
      );
      return {
        success: true,
        data: pairs,
      };
    } catch (caught: unknown) {
      console.error("DexScreener getNewPairs error:", caught);
      return {
        success: false,
        error: dexScreenerErrorMessage(caught) || "Failed to get new pairs",
      };
    }
  }
  async getTokenProfile(
    tokenAddress: string,
  ): Promise<DexScreenerServiceResponse<DexScreenerProfile>> {
    try {
      await this.rateLimit();
      // No lookup-by-address endpoint exists; fetch the latest profiles and
      // find the matching token address.
      const responseData = await this.get<
        DexScreenerProfile[] | DexScreenerProfile
      >(`/token-profiles/latest/v1`);
      const profiles = Array.isArray(responseData)
        ? responseData
        : [responseData];
      const profile = profiles.find(
        (p) => p.tokenAddress.toLowerCase() === tokenAddress.toLowerCase(),
      );
      if (!profile) {
        return {
          success: false,
          error: "Token profile not found",
        };
      }
      return {
        success: true,
        data: profile,
      };
    } catch (caught: unknown) {
      console.error("DexScreener getTokenProfile error:", caught);
      return {
        success: false,
        error: dexScreenerErrorMessage(caught) || "Failed to get token profile",
      };
    }
  }
  formatPrice(price: string | number): string {
    const numPrice = typeof price === "string" ? parseFloat(price) : price;
    if (numPrice >= 1) return numPrice.toFixed(2);
    if (numPrice >= 0.01) {
      const text = numPrice.toFixed(4);
      // 0.99996 renders "1.0000". Use the dollar tier for that display.
      return text === "1.0000" ? numPrice.toFixed(2) : text;
    }
    const text = numPrice.toFixed(8);
    return text === "0.01000000" ? numPrice.toFixed(4) : text;
  }
  formatPriceChange(change: number): string {
    const sign = change >= 0 ? "+" : "";
    return `${sign}${change.toFixed(2)}%`;
  }
  formatUsdValue(value: number): string {
    const tiers = [
      { divisor: 1_000_000_000, suffix: "B" },
      { divisor: 1_000_000, suffix: "M" },
      { divisor: 1_000, suffix: "K" },
      { divisor: 1, suffix: "" },
    ];
    let index = tiers.findIndex((tier) => value >= tier.divisor);
    if (index < 0) index = tiers.length - 1;
    let scaled = (value / tiers[index].divisor).toFixed(2);
    // 999_999 / 1000 renders "1000.00". Promote that display to the next
    // suffix. Leave every other rounded value on the tier it started on.
    if (scaled === "1000.00" && index > 0) {
      index -= 1;
      scaled = (value / tiers[index].divisor).toFixed(2);
    }
    return `$${scaled}${tiers[index].suffix}`;
  }
  async getMultipleTokens(
    chainId: string,
    tokenAddresses: string[],
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      if (tokenAddresses.length > 30) {
        return {
          success: false,
          error: "Maximum 30 token addresses allowed",
        };
      }
      await this.rateLimit();
      const addresses = tokenAddresses.join(",");
      const data = await this.get<DexScreenerPair[] | DexScreenerPair>(
        `/tokens/v1/${chainId}/${addresses}`,
      );
      return {
        success: true,
        data: Array.isArray(data) ? data : data ? [data] : [],
      };
    } catch (caught: unknown) {
      console.error("DexScreener getMultipleTokens error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) || "Failed to get multiple tokens",
      };
    }
  }
  async getLatestTokenProfiles(): Promise<
    DexScreenerServiceResponse<DexScreenerProfile[]>
  > {
    try {
      await this.rateLimit();
      const data = await this.get<DexScreenerProfile[] | DexScreenerProfile>(
        `/token-profiles/latest/v1`,
      );
      return {
        success: true,
        data: Array.isArray(data) ? data : [data],
      };
    } catch (caught: unknown) {
      console.error("DexScreener getLatestTokenProfiles error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) ||
          "Failed to get latest token profiles",
      };
    }
  }
  async getLatestBoostedTokens(): Promise<
    DexScreenerServiceResponse<DexScreenerBoostedWire[]>
  > {
    try {
      await this.rateLimit();
      const data = await this.get<
        DexScreenerBoostedWire[] | DexScreenerBoostedWire
      >(`/token-boosts/latest/v1`);
      return {
        success: true,
        data: Array.isArray(data) ? data : [data],
      };
    } catch (caught: unknown) {
      console.error("DexScreener getLatestBoostedTokens error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) ||
          "Failed to get latest boosted tokens",
      };
    }
  }
  async getTopBoostedTokens(): Promise<
    DexScreenerServiceResponse<DexScreenerBoostedWire[]>
  > {
    try {
      await this.rateLimit();
      const data = await this.get<
        DexScreenerBoostedWire[] | DexScreenerBoostedWire
      >(`/token-boosts/top/v1`);
      return {
        success: true,
        data: Array.isArray(data) ? data : [data],
      };
    } catch (caught: unknown) {
      console.error("DexScreener getTopBoostedTokens error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) || "Failed to get top boosted tokens",
      };
    }
  }
  async checkOrderStatus(
    chainId: string,
    tokenAddress: string,
  ): Promise<DexScreenerServiceResponse<DexScreenerOrder[]>> {
    try {
      await this.rateLimit();
      const data = await this.get<DexScreenerOrder[] | DexScreenerOrder>(
        `/orders/v1/${chainId}/${tokenAddress}`,
      );
      return {
        success: true,
        data: Array.isArray(data) ? data : data ? [data] : [],
      };
    } catch (caught: unknown) {
      console.error("DexScreener checkOrderStatus error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) || "Failed to check order status",
      };
    }
  }
  async getTokenPairsByChain(
    chainId: string,
    tokenAddress: string,
  ): Promise<DexScreenerServiceResponse<DexScreenerPair[]>> {
    try {
      await this.rateLimit();
      const data = await this.get<DexScreenerPair[] | DexScreenerPair>(
        `/token-pairs/v1/${chainId}/${tokenAddress}`,
      );
      return {
        success: true,
        data: Array.isArray(data) ? data : data ? [data] : [],
      };
    } catch (caught: unknown) {
      console.error("DexScreener getTokenPairsByChain error:", caught);
      return {
        success: false,
        error:
          dexScreenerErrorMessage(caught) ||
          "Failed to get token pairs by chain",
      };
    }
  }
}
