/**
 * `KAMINO_LENDING` provider: DM-only report of the user's Kamino lending/
 * borrowing positions, resolved from their Solana metawallet(s), alongside
 * available reserves and market data, narrated via an LLM pass. Gated to
 * `OWNER` role and direct messages since it reads account wallet data.
 */
import type {
  Entity,
  IAgentRuntime,
  Memory,
  Provider,
  State,
} from "@elizaos/core";
import { ModelType } from "@elizaos/core";
import type { KaminoService } from "../services/kaminoService";

const KAMINO_LEND_PROGRAM_ID = "GzFgdRJXmawPhGeBsyRCDLx4jAKPsvbUqoqitzppkzkW";
type AccountLike = {
  id?: unknown;
  username?: unknown;
  name?: unknown;
  metawallets?: Array<{
    keypairs?: Record<string, { publicKey?: unknown }>;
  }>;
};

type Metawallets = NonNullable<AccountLike["metawallets"]>;

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object";
}

function isMetawallets(value: unknown): value is Metawallets {
  return (
    Array.isArray(value) &&
    value.every(
      (metawallet) =>
        isRecord(metawallet) &&
        (metawallet.keypairs === undefined || isRecord(metawallet.keypairs)),
    )
  );
}

async function getAccountFromMessage(
  runtime: IAgentRuntime,
  message: Memory,
): Promise<unknown | null> {
  const entity = await runtime.getEntityById(message.entityId);
  if (!entity) {
    return null;
  }

  return buildAccountLike(entity);
}

function buildAccountLike(entity: Entity): AccountLike {
  const metadata = isRecord(entity.metadata) ? entity.metadata : {};
  const account = isRecord(metadata.account) ? metadata.account : {};
  const firstName = entity.names[0];

  return {
    ...metadata,
    ...account,
    id: entity.id,
    username: account.username ?? metadata.username,
    name: account.name ?? metadata.name ?? firstName,
    metawallets: isMetawallets(account.metawallets)
      ? account.metawallets
      : isMetawallets(metadata.metawallets)
        ? metadata.metawallets
        : undefined,
  };
}

function getSolanaWalletAddresses(account: unknown): string[] {
  const walletAddresses: string[] = [];
  const accountData = account as AccountLike;

  if (!Array.isArray(accountData.metawallets)) {
    return walletAddresses;
  }

  for (const mw of accountData.metawallets) {
    if (!mw.keypairs) {
      continue;
    }

    for (const [chain, kp] of Object.entries(mw.keypairs)) {
      if (chain === "solana" && kp.publicKey) {
        walletAddresses.push(String(kp.publicKey));
      }
    }
  }

  return walletAddresses;
}

function formatAccountForPrompt(account: unknown): string {
  if (!account) {
    return "account_status: not found";
  }

  const accountData = account as AccountLike;
  const lines = ["account_status: available"];
  const identifiers = {
    id: accountData.id,
    username: accountData.username,
    name: accountData.name,
  };

  for (const [key, value] of Object.entries(identifiers)) {
    if (value !== undefined && value !== null && value !== "") {
      lines.push(`${key}: ${formatPromptValue(value)}`);
    }
  }

  const solanaWallets = getSolanaWalletAddresses(account);
  lines.push(`solana_wallet_count: ${solanaWallets.length}`);
  solanaWallets.forEach((wallet, index) => {
    lines.push(`solana_wallets[${index}]: ${wallet}`);
  });

  return lines.join("\n");
}

function formatPromptValue(value: unknown): string {
  if (value === null || value === undefined) {
    return "N/A";
  }

  if (typeof value === "string") {
    return value;
  }

  if (typeof value === "number" || typeof value === "boolean") {
    return String(value);
  }

  return String(value);
}

export const kaminoProvider: Provider = {
  name: "KAMINO_LENDING",
  description:
    "Provides information about Kamino lending protocol positions, market data, and available lending/borrowing opportunities",
  descriptionCompressed:
    "Kamino lending positions, markets, lend/borrow opportunities",
  dynamic: true,
  contexts: ["finance", "crypto", "wallet"],
  contextGate: { anyOf: ["finance", "crypto", "wallet"] },
  cacheStable: false,
  cacheScope: "turn",
  roleGate: { minRole: "OWNER" },
  get: async (runtime: IAgentRuntime, message: Memory, _state: State) => {
    let kaminoInfo = "";

    try {
      const isDM = message.content.channelType?.toUpperCase() === "DM";
      if (isDM) {
        const account = await getAccountFromMessage(runtime, message);
        if (!account) {
          return {
            data: {},
            values: {},
            text: "No account found for this user.",
          };
        }

        const kaminoService = runtime.getService(
          "KAMINO_SERVICE",
        ) as KaminoService;
        if (!kaminoService) {
          return {
            data: {},
            values: {},
            text: "Kamino service not available.",
          };
        }

        kaminoInfo += `=== KAMINO LENDING PROTOCOL REPORT ===\n\n`;

        const userPositions = await getUserKaminoPositions(
          kaminoService,
          account,
        );
        const availableReserves =
          await getAvailableKaminoReserves(kaminoService);
        const marketOverview = await getKaminoMarketOverview(kaminoService);
        const discoveredMarkets =
          await getDiscoveredKaminoMarkets(kaminoService);

        const enhancedReport = await generateEnhancedKaminoLendingReport(
          runtime,
          {
            account,
            userPositions,
            availableReserves,
            marketOverview,
            discoveredMarkets,
            kaminoService,
          },
        );

        kaminoInfo += enhancedReport;
      } else {
        kaminoInfo =
          "Kamino lending protocol information is only available in private messages.";
      }
    } catch (error) {
      console.error("Error in Kamino provider:", error);
      kaminoInfo = `Error generating Kamino report: ${error instanceof Error ? error.message : "Unknown error"}`;
    }

    const data = {
      kaminoLending: kaminoInfo,
    };

    const text = `${kaminoInfo}\n`;

    return {
      data,
      values: {},
      text,
    };
  },
};

async function getUserKaminoPositions(
  kaminoService: KaminoService,
  account: unknown,
): Promise<string> {
  let positionsInfo = "📊 YOUR KAMINO POSITIONS:\n\n";

  try {
    const walletAddresses = getSolanaWalletAddresses(account);

    if (walletAddresses.length === 0) {
      positionsInfo += "No Solana wallets found in your account.\n\n";
      return positionsInfo;
    }

    for (const walletAddress of walletAddresses) {
      positionsInfo += `🔸 Wallet: ${walletAddress}\n`;

      try {
        const positions = await kaminoService.getUserPositions(walletAddress);

        if ("error" in positions) {
          positionsInfo += `   ❌ Error: ${positions.error}\n\n`;
        } else if (
          positions.lending.length === 0 &&
          positions.borrowing.length === 0
        ) {
          positionsInfo += "   No Kamino positions found.\n\n";

          if (positions.markets && positions.markets.length > 0) {
            positionsInfo += `   🔍 Discovered ${positions.markets.length} Kamino markets\n`;
            positionsInfo += `   📊 User has ${positions.userAccounts || 0} token accounts\n\n`;
          }
        } else {
          if (positions.lending.length > 0) {
            positionsInfo += `   💰 LENDING POSITIONS (${positions.lending.length}):\n\n`;

            for (const position of positions.lending) {
              positionsInfo += `   📈 ${position.token || "Unknown Token"}\n`;
              positionsInfo += `      Amount: ${position.amount?.toFixed(6) || "N/A"}\n`;
              positionsInfo += `      Value: $${position.value?.toFixed(2) || "N/A"}\n`;
              positionsInfo += `      APY: ${position.apy?.toFixed(2) || "N/A"}%\n`;
              positionsInfo += `      Market: ${position.market || "N/A"}\n\n`;
            }
          }

          if (positions.borrowing.length > 0) {
            positionsInfo += `   💳 BORROWING POSITIONS (${positions.borrowing.length}):\n\n`;

            for (const position of positions.borrowing) {
              positionsInfo += `   📉 ${position.token || "Unknown Token"}\n`;
              positionsInfo += `      Amount: ${position.amount?.toFixed(6) || "N/A"}\n`;
              positionsInfo += `      Value: $${position.value?.toFixed(2) || "N/A"}\n`;
              positionsInfo += `      APY: ${position.apy?.toFixed(2) || "N/A"}%\n`;
              positionsInfo += `      Market: ${position.market || "N/A"}\n\n`;
            }
          }

          if (positions.totalValue !== undefined) {
            positionsInfo += `   💼 TOTAL PORTFOLIO VALUE: $${positions.totalValue.toFixed(2)}\n\n`;
          }
        }
      } catch (error) {
        console.error(
          `Error fetching positions for wallet ${walletAddress}:`,
          error,
        );
        positionsInfo += "   Error fetching positions for this wallet.\n\n";
      }
    }
  } catch (error) {
    console.error("Error fetching user Kamino positions:", error);
    positionsInfo += "Error fetching positions. Please try again later.\n\n";
  }

  return positionsInfo;
}

async function getAvailableKaminoReserves(
  kaminoService: KaminoService,
): Promise<string> {
  let reservesInfo = "🏦 AVAILABLE KAMINO RESERVES:\n\n";

  try {
    const reserves = await kaminoService.getAvailableReserves();

    if (reserves.length === 0) {
      reservesInfo += "No reserves available at the moment.\n";
      reservesInfo += "This may be due to:\n";
      reservesInfo += "- Kamino SDK not being installed\n";
      reservesInfo += "- Network connectivity issues\n";
      reservesInfo += "- Service initialization problems\n\n";
      return reservesInfo;
    }

    const topLendingReserves = reserves
      .filter((r) => r.supplyApy > 0)
      .sort((a, b) => {
        const bApy =
          typeof b.supplyApy === "number" && Number.isFinite(b.supplyApy)
            ? b.supplyApy
            : 0;
        const aApy =
          typeof a.supplyApy === "number" && Number.isFinite(a.supplyApy)
            ? a.supplyApy
            : 0;
        return (
          bApy - aApy ||
          (a.marketName || a.market || "").localeCompare(
            b.marketName || b.market || "",
          )
        );
      });

    if (topLendingReserves.length > 0) {
      reservesInfo += "💰 TOP LENDING OPPORTUNITIES:\n\n";

      for (const reserve of topLendingReserves) {
        reservesInfo += `🔸 ${reserve.marketName || reserve.market || "Unknown"}\n`;
        reservesInfo += `   Supply APY: ${reserve.supplyApy.toFixed(2) || "N/A"}%\n`;
        reservesInfo += `   Borrow APY: ${reserve.borrowApy.toFixed(2) || "N/A"}%\n`;
        reservesInfo += `   Total Supply: $${reserve.totalSupply.toLocaleString() || "N/A"}\n`;
        reservesInfo += `   Total Borrow: $${reserve.totalBorrow.toLocaleString() || "N/A"}\n`;
        reservesInfo += `   Utilization: ${(reserve.utilization * 100).toFixed(2) || "N/A"}%\n`;
        reservesInfo += `   Market: ${reserve.marketName || "Unknown"}\n\n`;
      }
    }

    reservesInfo += `Total reserves available: ${reserves.length}\n\n`;
  } catch (error) {
    console.error("Error fetching available Kamino reserves:", error);
    reservesInfo += "Error fetching reserves. Please try again later.\n\n";
  }

  return reservesInfo;
}

async function getKaminoMarketOverview(
  kaminoService: KaminoService,
): Promise<string> {
  let marketInfo = "📈 KAMINO MARKET OVERVIEW:\n\n";

  try {
    const overview = await kaminoService.getMarketOverview();

    if (!overview) {
      marketInfo += "Market data not available at the moment.\n";
      marketInfo += "This may be due to:\n";
      marketInfo += "- Kamino SDK not being installed\n";
      marketInfo += "- Network connectivity issues\n";
      marketInfo += "- Service initialization problems\n\n";
      return marketInfo;
    }

    marketInfo += `📊 Total Markets: ${overview.totalMarkets}\n`;
    marketInfo += `💰 Total TVL: $${overview.totalTvl.toLocaleString() || "N/A"}\n`;
    marketInfo += `💳 Total Borrowed: $${overview.totalBorrowed.toLocaleString() || "N/A"}\n\n`;

    if (overview.markets && overview.markets.length > 0) {
      marketInfo += "🏆 TOP MARKETS BY TVL:\n\n";

      const topMarkets = overview.markets.sort(
        (a, b) => (b.lamports || 0) - (a.lamports || 0),
      );

      for (const market of topMarkets) {
        marketInfo += `🔸 ${market.marketName || "Unknown Market"}\n`;
        marketInfo += `   Address: ${market.address}\n`;
        marketInfo += `   Data Size: ${market.dataSize.toLocaleString()} bytes\n`;
        marketInfo += `   Lamports: ${market.lamports.toLocaleString()}\n`;
        marketInfo += `   Owner: ${market.owner}\n\n`;
      }
    }
  } catch (error) {
    console.error("Error fetching Kamino market overview:", error);
    marketInfo += "Error fetching market data. Please try again later.\n\n";
  }

  return marketInfo;
}

async function getDiscoveredKaminoMarkets(
  kaminoService: KaminoService,
): Promise<string> {
  let marketsInfo = "🔍 DISCOVERED KAMINO MARKETS:\n\n";

  try {
    const markets = await kaminoService.discoverMarkets();

    if (markets.length === 0) {
      marketsInfo += "No markets discovered at the moment.\n\n";
      return marketsInfo;
    }

    marketsInfo += `📊 Total Markets Discovered: ${markets.length}\n\n`;

    marketsInfo += "🏪 DISCOVERED MARKET ADDRESSES:\n\n";

    for (let i = 0; i < markets.length; i++) {
      const market = markets[i];
      marketsInfo += `${i + 1}. ${market.toString()}\n`;
    }

    marketsInfo += "\n";

    marketsInfo += "📈 MARKET DISCOVERY STATS:\n";
    marketsInfo += `• Program ID: ${KAMINO_LEND_PROGRAM_ID}\n`;
    marketsInfo += `• Discovery Method: Program Account Query\n`;
    marketsInfo += `• Data Size Filter: 1024 bytes\n`;
    marketsInfo += `• Discovery Time: ${new Date().toLocaleString()}\n\n`;
  } catch (error) {
    console.error("Error fetching discovered Kamino markets:", error);
    marketsInfo += "Error discovering markets. Please try again later.\n\n";
  }

  return marketsInfo;
}

async function generateEnhancedKaminoLendingReport(
  runtime: IAgentRuntime,
  data: {
    account: unknown;
    userPositions: string;
    availableReserves: string;
    marketOverview: string;
    discoveredMarkets: string;
    kaminoService: KaminoService;
  },
): Promise<string> {
  try {
    const lendingPrompt = `Generate a comprehensive lending analysis report for Kamino Finance lending.

USER ACCOUNT DATA:
${formatAccountForPrompt(data.account)}

USER POSITIONS:
${data.userPositions}

AVAILABLE RESERVES:
${data.availableReserves}

MARKET OVERVIEW:
${data.marketOverview}

DISCOVERED MARKETS:
${data.discoveredMarkets}

Please generate a professional, engaging report that includes:

1. **Portfolio Summary** - Overview of the user's current Kamino lending positions and performance
2. **Market Analysis** - Current state of Kamino lending markets and opportunities
3. **Position Analysis** - Detailed breakdown of user's lending and borrowing positions
4. **Opportunity Assessment** - Analysis of the best lending and borrowing opportunities available
5. **Risk Management** - Key risks and considerations for the user's current positions
6. **Strategy Recommendations** - Specific, actionable recommendations for portfolio optimization
7. **Market Trends** - How current market conditions affect lending strategies

Format the report with:
- Clear sections with descriptive headers
- Use emojis for visual appeal and quick scanning
- Include specific numbers and percentages
- Provide professional but engaging tone
- Focus on actionable insights for this specific user
- Include relevant comparisons to market standards
- End with a concise summary and next steps

Make it comprehensive yet easy to read. Be specific about the user's data and provide clear, personalized insights about their Kamino lending situation.

Generate a professional Kamino lending analysis report:`;

    const enhancedReport = await runtime.useModel(ModelType.TEXT_LARGE, {
      prompt: lendingPrompt,
    });

    return (
      enhancedReport ||
      `${data.userPositions}\n\n${data.availableReserves}\n\n${data.marketOverview}\n\n${data.discoveredMarkets}`
    );
  } catch (error) {
    console.error("Error generating enhanced Kamino lending report:", error);
    return `${data.userPositions}\n\n${data.availableReserves}\n\n${data.marketOverview}\n\n${data.discoveredMarkets}`;
  }
}
