/**
 * `KAMINO_LIQUIDITY` provider: renders Kamino liquidity pool/strategy data
 * (optionally scoped to a token address found in the message) into planner
 * context, using an LLM pass to turn raw pool stats into a readable report.
 */
import type { IAgentRuntime, Memory, Provider, State } from "@elizaos/core";
import { ModelType } from "@elizaos/core";
import type {
  KaminoLiquidityService,
  KaminoStrategy,
} from "../services/kaminoLiquidityService";

function asPromptRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object"
    ? (value as Record<string, unknown>)
    : {};
}

function formatTokenInfoForPrompt(tokenInfo: unknown): string {
  if (!tokenInfo) {
    return "token_status: not resolved";
  }

  const token = asPromptRecord(tokenInfo);
  const fields = [
    ["token_status", "resolved"],
    ["name", token.name],
    ["symbol", token.symbol],
    ["address", token.address],
    ["price_usd", token.price],
    ["liquidity_usd", token.liquidity],
    ["market_cap_usd", token.marketCap],
    ["volume_24h_usd", token.volume24h],
    ["price_change_24h_percent", token.priceChange24h],
    ["decimals", token.decimals],
  ];

  return fields
    .filter(
      ([, value]) => value !== undefined && value !== null && value !== "",
    )
    .map(([key, value]) => `${key}: ${formatPromptValue(value)}`)
    .join("\n");
}

function formatMarketStatsForPrompt(marketStats: unknown): string {
  if (!marketStats) {
    return "market_status: not available";
  }

  const stats = asPromptRecord(marketStats);
  const stakingYields = asPromptRecord(stats.stakingYields);
  const medianYields = asPromptRecord(stats.medianYields);
  const limoTrades = asPromptRecord(stats.limoTrades);

  return [
    "market_status: available",
    `timestamp: ${formatPromptValue(stats.timestamp)}`,
    `staking_yields_total: ${formatPromptValue(stakingYields.total)}`,
    `staking_yields_average_apy: ${formatPromptValue(stakingYields.averageApy)}`,
    `staking_yields_max_apy: ${formatPromptValue(stakingYields.maxApy)}`,
    `staking_yields_min_apy: ${formatPromptValue(stakingYields.minApy)}`,
    `median_yields_total: ${formatPromptValue(medianYields.total)}`,
    `median_yields_average_apy: ${formatPromptValue(medianYields.averageApy)}`,
    `limo_trades_total: ${formatPromptValue(limoTrades.total)}`,
    `limo_trades_total_volume_usd: ${formatPromptValue(limoTrades.totalVolume)}`,
    `limo_trades_average_tip_usd: ${formatPromptValue(limoTrades.averageTip)}`,
    `limo_trades_average_surplus_usd: ${formatPromptValue(limoTrades.averageSurplus)}`,
  ].join("\n");
}

function formatPromptValue(value: unknown): string {
  if (value === null || value === undefined) {
    return "N/A";
  }

  if (typeof value === "number") {
    return Number.isFinite(value) ? String(value) : "N/A";
  }

  if (typeof value === "string") {
    return value;
  }

  if (typeof value === "boolean") {
    return String(value);
  }

  return String(value);
}

export const kaminoLiquidityProvider: Provider = {
  name: "KAMINO_LIQUIDITY",
  description:
    "Provides information about Kamino liquidity pools, strategies, and token-specific liquidity data",
  descriptionCompressed:
    "provide information Kamino liquidity pool, strategy, token-specific liquidity data",
  dynamic: true,
  contexts: ["finance", "crypto", "wallet"],
  contextGate: { anyOf: ["finance", "crypto", "wallet"] },
  cacheStable: false,
  cacheScope: "turn",
  roleGate: { minRole: "USER" },
  get: async (runtime: IAgentRuntime, message: Memory, _state: State) => {
    let liquidityInfo = "";

    try {
      const content = message.content.text || "";
      const tokenMatch = content.match(/([A-Za-z0-9]{32,44})/);

      let tokenIdentifier = "";
      if (tokenMatch) {
        tokenIdentifier = tokenMatch[1];
      }

      const kaminoLiquidityService = runtime.getService(
        "KAMINO_LIQUIDITY_SERVICE",
      ) as KaminoLiquidityService;
      if (!kaminoLiquidityService) {
        liquidityInfo += "❌ Kamino liquidity service not available.\n";
      } else {
        if (tokenIdentifier) {
          liquidityInfo += `=== KAMINO LIQUIDITY POOL STATS ===\n\n`;
          liquidityInfo += `Token: ${tokenIdentifier}\n\n`;

          const tokenInfo =
            await kaminoLiquidityService.resolveTokenWithBirdeye(
              tokenIdentifier,
            );
          if (tokenInfo) {
            liquidityInfo += `🔍 Token Resolution via Birdeye:\n`;
            liquidityInfo += `   📝 Name: ${tokenInfo.name}\n`;
            liquidityInfo += `   🔖 Symbol: ${tokenInfo.symbol}\n`;
            liquidityInfo += `   🔗 Address: ${tokenInfo.address}\n`;
            liquidityInfo += `   💵 Price: $${tokenInfo.price?.toFixed(6) || "N/A"}\n`;
            liquidityInfo += `   💧 Liquidity: $${tokenInfo.liquidity?.toLocaleString() || "N/A"}\n`;
            liquidityInfo += `   📊 Market Cap: $${tokenInfo.marketCap?.toLocaleString() || "N/A"}\n`;
            liquidityInfo += `   📈 24h Change: ${tokenInfo.priceChange24h?.toFixed(2) || "N/A"}%\n\n`;
          }

          const poolStats = await getKaminoLiquidityStats(
            kaminoLiquidityService,
            tokenIdentifier,
          );

          const enhancedReport = await generateEnhancedKaminoLiquidityReport(
            runtime,
            {
              tokenIdentifier,
              tokenInfo,
              poolStats,
              kaminoLiquidityService,
            },
          );

          liquidityInfo += enhancedReport;
        } else {
          // No specific token given: show a protocol overview via
          // testConnection() instead of the more expensive per-token RPC lookups.
          liquidityInfo += `=== KAMINO LIQUIDITY PROTOCOL OVERVIEW ===\n\n`;
          liquidityInfo += `🔍 Kamino Liquidity Protocol Information\n\n`;

          const testResults = await kaminoLiquidityService.testConnection();

          liquidityInfo += `📊 Protocol Status:\n`;
          liquidityInfo += `   ✅ Connection: ${testResults.connectionTest ? "Connected" : "Failed"}\n`;
          liquidityInfo += `   📋 Program ID: ${testResults.programId}\n`;
          liquidityInfo += `   🔗 RPC Endpoint: ${testResults.rpcEndpoint}\n`;
          liquidityInfo += `   📈 Available Strategies: ${testResults.strategyCount}\n\n`;

          liquidityInfo += await getKaminoProtocolInfo(kaminoLiquidityService);

          liquidityInfo += `💡 How to use:\n`;
          liquidityInfo += `   • Provide a token address to search for specific liquidity pools\n`;
          liquidityInfo += `   • Example: "Check Kamino liquidity for HeLp6NuQkmYB4pYWo2zYs22mESHXPQYzXbB8n4V98jwC"\n`;
          liquidityInfo += `   • Visit https://app.kamino.finance/liquidity to view all pools\n\n`;
        }
      }
    } catch (error) {
      console.error("Error in Kamino liquidity provider:", error);
      liquidityInfo = `Error generating Kamino liquidity report: ${error instanceof Error ? error.message : "Unknown error"}`;
    }

    const data = {
      kaminoLiquidity: liquidityInfo,
    };

    const text = `${liquidityInfo}\n`;

    return {
      data,
      values: {},
      text,
    };
  },
};

async function getKaminoLiquidityStats(
  kaminoLiquidityService: KaminoLiquidityService,
  tokenIdentifier: string,
): Promise<string> {
  let statsInfo = "";

  try {
    statsInfo += `🔍 SEARCHING FOR KAMINO LIQUIDITY POOLS...\n\n`;

    const tokenStats =
      await kaminoLiquidityService.getTokenLiquidityStats(tokenIdentifier);

    if (tokenStats.strategies.length > 0) {
      statsInfo += `📊 FOUND ${tokenStats.strategies.length} RELEVANT STRATEGIES:\n\n`;
      statsInfo += `Token: ${tokenStats.tokenName}\n`;
      statsInfo += `Total TVL: $${tokenStats.totalTvl.toLocaleString()}\n`;
      statsInfo += `24h Volume: $${tokenStats.totalVolume.toLocaleString()}\n`;
      statsInfo += `APY Range: ${tokenStats.apyRange.min.toFixed(2)}% - ${tokenStats.apyRange.max.toFixed(2)}%\n\n`;

      const strategyTypes = new Map<string, KaminoStrategy[]>();
      tokenStats.strategies.forEach((strategy) => {
        const type = strategy.strategyType;
        if (!strategyTypes.has(type)) {
          strategyTypes.set(type, []);
        }
        strategyTypes.get(type)?.push(strategy);
      });

      for (const [type, strategies] of strategyTypes) {
        statsInfo += `🏊‍♂️ ${type.toUpperCase()} (${strategies.length} strategies):\n`;
        const totalTvl = strategies.reduce(
          (sum, s) => sum + (s.estimatedTvl || 0),
          0,
        );
        const avgApy =
          strategies.reduce((sum, s) => sum + (s.apy || 0), 0) /
          strategies.length;
        statsInfo += `   💰 Total TVL: $${totalTvl.toLocaleString()}\n`;
        statsInfo += `   🎯 Average APY: ${avgApy.toFixed(2)}%\n\n`;

        for (const strategy of strategies) {
          statsInfo += await getStrategyDetails(strategy);
        }
      }

      statsInfo += `🔗 **View on Kamino:** https://app.kamino.finance/liquidity\n\n`;
    } else {
      statsInfo += `❌ No Kamino liquidity strategies found for ${tokenIdentifier}\n\n`;
      statsInfo += `🔍 Analysis Results:\n`;
      statsInfo += `   • Token: ${tokenStats.tokenName}\n`;
      statsInfo += `   • Searched through Kamino liquidity program with optimized filters\n`;
      statsInfo += `   • No strategies containing this token were found\n\n`;
      statsInfo += `💡 Possible reasons:\n`;
      statsInfo += `   • Token may not be listed on Kamino liquidity pools\n`;
      statsInfo += `   • Token might be too new or have low liquidity\n`;
      statsInfo += `   • Token may be listed under a different address\n`;
      statsInfo += `   • Token might be in a different strategy type\n\n`;
      statsInfo += `🔗 Check available strategies at: https://app.kamino.finance/liquidity\n`;
    }

    statsInfo += await getKaminoProtocolInfo(kaminoLiquidityService);
  } catch (error) {
    console.error("Error getting Kamino liquidity stats:", error);
    statsInfo += `❌ Error fetching liquidity data: ${error instanceof Error ? error.message : "Unknown error"}\n`;
  }

  return statsInfo;
}

async function getStrategyDetails(strategy: KaminoStrategy): Promise<string> {
  let details = `   🏊‍♂️ STRATEGY: ${strategy.address}\n`;
  details += `      📈 Type: ${strategy.strategyType}\n`;
  details += `      💰 TVL: $${strategy.estimatedTvl.toLocaleString()}\n`;
  details += `      📊 24h Volume: $${strategy.volume24h.toLocaleString()}\n`;
  details += `      🎯 APY: ${strategy.apy.toFixed(2)}%\n`;
  details += `      🔄 Rebalancing: ${strategy.rebalancing}\n`;
  details += `      💸 Fee Tier: ${strategy.feeTier}\n`;
  details += `      🕒 Last Rebalance: ${new Date(strategy.lastRebalance).toLocaleDateString()}\n`;

  if (strategy.positions && strategy.positions.length > 0) {
    details += `      📍 Positions:\n`;
    for (const position of strategy.positions) {
      details += `         • ${position.type}: ${position.range} ($${position.liquidity.toLocaleString()})\n`;
    }
  }

  details += `\n`;

  return details;
}

async function getKaminoProtocolInfo(
  kaminoLiquidityService: KaminoLiquidityService,
): Promise<string> {
  let info = `🌊 KAMINO LIQUIDITY PROTOCOL INFO:\n\n`;

  try {
    const testResults = await kaminoLiquidityService.testConnection();

    info += `📋 Program ID: ${testResults.programId}\n`;
    info += `🔗 RPC Endpoint: ${testResults.rpcEndpoint}\n`;
    info += `✅ Connection Status: ${testResults.connectionTest ? "Connected" : "Failed"}\n`;
    info += `📊 Strategy Count: ${testResults.strategyCount}\n\n`;

    info += `🔗 Useful Links:\n`;
    info += `   • Kamino App: https://app.kamino.finance/liquidity\n`;
    info += `   • Documentation: https://docs.kamino.finance\n`;
    info += `   • GitHub: https://github.com/Kamino-Finance\n\n`;

    info += `💡 How to use:\n`;
    info += `   • Visit the Kamino app to view all available liquidity pools\n`;
    info += `   • Deposit tokens to earn yield from automated market making\n`;
    info += `   • Strategies automatically rebalance to maintain optimal positions\n`;
  } catch (error) {
    console.error("Error getting protocol info:", error);
    info += `❌ Error fetching protocol information\n`;
  }

  return info;
}

/** Turns raw pool stats + market context into a narrative report via an LLM pass. */
async function generateEnhancedKaminoLiquidityReport(
  runtime: IAgentRuntime,
  data: {
    tokenIdentifier: string;
    tokenInfo: unknown;
    poolStats: string;
    kaminoLiquidityService: KaminoLiquidityService;
  },
): Promise<string> {
  try {
    const marketStats = await data.kaminoLiquidityService.getMarketStatistics();

    const liquidityPrompt = `Generate a comprehensive liquidity analysis report for token ${data.tokenIdentifier} on Kamino Finance.

TOKEN INFORMATION:
${formatTokenInfoForPrompt(data.tokenInfo)}

POOL STATISTICS:
${data.poolStats}

MARKET CONTEXT:
${formatMarketStatsForPrompt(marketStats)}

Please generate a professional, engaging report that includes:

1. **Token Overview** - Brief introduction to the token and its market position
2. **Liquidity Analysis** - Detailed breakdown of Kamino liquidity pools and strategies
3. **Performance Metrics** - TVL, APY ranges, volume analysis, and key performance indicators
4. **Strategy Assessment** - Analysis of different strategy types (staking, Limo trading) and their effectiveness
5. **Market Insights** - How this token's liquidity compares to market trends
6. **Risk & Opportunity Analysis** - Key risks and opportunities for liquidity providers
7. **Investment Recommendations** - Clear, actionable insights for potential investors

Format the report with:
- Clear sections with descriptive headers
- Use emojis for visual appeal and quick scanning
- Include specific numbers and percentages
- Provide professional but engaging tone
- Focus on actionable insights
- Include relevant comparisons to market standards
- End with a concise summary

Make it comprehensive yet easy to read. Be specific about the data and provide clear insights about this particular token's liquidity situation on Kamino Finance.

Generate a professional Kamino liquidity analysis report:`;

    const enhancedReport = await runtime.useModel(ModelType.TEXT_LARGE, {
      prompt: liquidityPrompt,
    });

    return enhancedReport || data.poolStats;
  } catch (error) {
    console.error("Error generating enhanced Kamino liquidity report:", error);
    return data.poolStats;
  }
}
