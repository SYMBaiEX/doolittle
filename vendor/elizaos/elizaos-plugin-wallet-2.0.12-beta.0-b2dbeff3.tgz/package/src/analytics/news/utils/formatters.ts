/**
 * Utility functions for formatting DeFi news data
 */

/**
 * Format a number as currency (USD)
 */
export function formatCurrency(value: number, decimals: number = 2): string {
  const abs = Math.abs(value);
  const tiers: Array<[number, string]> = [
    [1e12, "T"],
    [1e9, "B"],
    [1e6, "M"],
    [1e3, "K"],
    [1, ""],
  ];
  for (let i = 0; i < tiers.length; i++) {
    const [threshold, suffix] = tiers[i];
    if (abs >= threshold) {
      const scaled = value / threshold;
      // If rounding pushes the scaled value to 1000, promote to the next tier
      // (e.g. 999999 -> "$1.00M", not "$1000.00K").
      if (Math.abs(Number(scaled.toFixed(decimals))) >= 1000 && i > 0) {
        const [higherThreshold, higherSuffix] = tiers[i - 1];
        return `$${(value / higherThreshold).toFixed(decimals)}${higherSuffix}`;
      }
      return `$${scaled.toFixed(decimals)}${suffix}`;
    }
  }
  return `$${value.toFixed(decimals)}`;
}

/**
 * Format a percentage with appropriate emoji
 */
export function formatPercentage(value: number, decimals: number = 2): string {
  const emoji = value >= 0 ? "📈" : "📉";
  const sign = value >= 0 ? "+" : "";
  return `${emoji} ${sign}${value.toFixed(decimals)}%`;
}

/**
 * Format a timestamp as a human-readable date
 */
export function formatDate(timestamp: number | string): string {
  const date = new Date(timestamp);
  return date.toLocaleString();
}

/**
 * Format a relative time (e.g., "2 hours ago")
 */
export function formatRelativeTime(timestamp: number | string): string {
  const now = Date.now();
  const date = new Date(timestamp).getTime();
  const diff = now - date;

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    return `${days} day${days > 1 ? "s" : ""} ago`;
  } else if (hours > 0) {
    return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  } else if (minutes > 0) {
    return `${minutes} minute${minutes > 1 ? "s" : ""} ago`;
  } else {
    return `${seconds} second${seconds > 1 ? "s" : ""} ago`;
  }
}

/**
 * Get sentiment emoji
 */
export function getSentimentEmoji(sentiment?: string): string {
  if (!sentiment) return "😐";

  switch (sentiment.toLowerCase()) {
    case "positive":
      return "😊";
    case "negative":
      return "😟";
    case "neutral":
      return "😐";
    default:
      return "😐";
  }
}

/**
 * Format large numbers with commas
 */
export function formatNumber(value: number, decimals: number = 0): string {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/**
 * Extract token symbol from text
 */
export function extractTokenSymbol(text: string): string | null {
  // Match 3-5 uppercase letters that might be a token symbol
  const match = text.match(/\b([A-Z]{3,5})\b/);
  return match ? match[1] : null;
}

/**
 * Clean HTML tags from text
 */
export function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, "");
}

/**
 * Validate if a string is a valid token address
 */
export function isValidTokenAddress(address: string): boolean {
  // Ethereum address (0x followed by 40 hex characters)
  const ethRegex = /^0x[a-fA-F0-9]{40}$/;
  // Solana address (base58, 32-44 characters)
  const solRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

  return ethRegex.test(address) || solRegex.test(address);
}
