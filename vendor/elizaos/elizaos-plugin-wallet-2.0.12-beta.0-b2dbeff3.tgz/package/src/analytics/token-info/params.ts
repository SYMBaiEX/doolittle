/**
 * Turns loose `WALLET` action options (and, failing that, free-form message
 * text) into a typed `TokenInfoParams` query: subaction aliasing/normalization
 * (`normalizeTokenInfoSubaction`, `SUBACTION_ALIASES`), keyword-based intent
 * inference when no explicit subaction is given (`inferTokenInfoSubaction`),
 * and tolerant param readers that coerce strings/numbers/booleans from a
 * merged top-level + nested `parameters` bag.
 */
import type { HandlerOptions, Memory, State } from "@elizaos/core";
import {
  TOKEN_INFO_SUBACTIONS,
  type TokenInfoParams,
  type TokenInfoSubaction,
} from "./types";

const SUBACTION_ALIASES: Record<string, TokenInfoSubaction> = {
  lookup: "token",
  info: "token",
  pairs: "chain_pairs",
  "new pairs": "new_pairs",
  "new-pairs": "new_pairs",
  new_pairs: "new_pairs",
  chain_pairs: "chain_pairs",
  "chain-pairs": "chain_pairs",
  chainpairs: "chain_pairs",
  boosted_tokens: "boosted",
  boostedtokens: "boosted",
  token_profiles: "profiles",
  tokenprofiles: "profiles",
  wallet_address: "wallet",
  "wallet-address": "wallet",
  portfolio: "wallet",
};

export function readParams(options?: unknown): Record<string, unknown> {
  const direct =
    options && typeof options === "object"
      ? (options as Record<string, unknown>)
      : {};
  const parameters =
    direct.parameters && typeof direct.parameters === "object"
      ? (direct.parameters as Record<string, unknown>)
      : {};
  return { ...direct, ...parameters };
}

export function readStringParam(
  options: unknown,
  ...keys: string[]
): string | undefined {
  const params = readParams(options);
  for (const key of keys) {
    const value = params[key];
    if (typeof value === "string" && value.trim().length > 0) {
      return value.trim();
    }
  }
  return undefined;
}

export function readNumberParam(
  options: unknown,
  key: string,
  fallback?: number,
): number | undefined {
  const value = readParams(options)[key];
  const parsed =
    typeof value === "number"
      ? value
      : typeof value === "string" && value.trim().length > 0
        ? Number(value)
        : Number.NaN;
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function readBooleanParam(
  options: unknown,
  key: string,
): boolean | undefined {
  const value = readParams(options)[key];
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["true", "1", "yes"].includes(normalized)) return true;
    if (["false", "0", "no"].includes(normalized)) return false;
  }
  return undefined;
}

export function normalizeTokenInfoSubaction(
  value: unknown,
): TokenInfoSubaction | undefined {
  if (typeof value !== "string") return undefined;
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
  if ((TOKEN_INFO_SUBACTIONS as readonly string[]).includes(normalized)) {
    return normalized as TokenInfoSubaction;
  }
  return (
    SUBACTION_ALIASES[normalized] ?? SUBACTION_ALIASES[value.toLowerCase()]
  );
}

export function inferTokenInfoSubaction(
  message: Memory,
  state?: State,
): TokenInfoSubaction {
  const text = [
    typeof message.content.text === "string" ? message.content.text : "",
    typeof state?.values?.recentMessages === "string"
      ? state.values.recentMessages
      : "",
  ]
    .join("\n")
    .toLowerCase();

  if (/\b(wallet|portfolio|holdings)\b/.test(text)) return "wallet";
  if (/\b(boosted|promoted|sponsored)\b/.test(text)) return "boosted";
  if (/\b(profile|profiles)\b/.test(text)) return "profiles";
  if (
    /\b(new|latest|fresh)\b/.test(text) &&
    /\b(pair|pairs|tokens?)\b/.test(text)
  ) {
    return "new_pairs";
  }
  if (
    /\b(pair|pairs)\b/.test(text) &&
    /\b(chain|ethereum|solana|base|bsc|polygon|arbitrum|optimism|avalanche)\b/.test(
      text,
    )
  ) {
    return "chain_pairs";
  }
  if (/\b(trending|hot|popular|gainers)\b/.test(text)) return "trending";
  if (/\b(search|find|look for)\b/.test(text)) return "search";
  return "token";
}

export function parseTokenInfoParams(
  message: Memory,
  state?: State,
  options?: HandlerOptions | Record<string, unknown>,
): TokenInfoParams {
  const raw = readParams(options);
  const content =
    typeof message.content.text === "string" ? message.content.text : "";
  const address = readStringParam(raw, "address", "tokenAddress", "wallet");
  const explicitQuery = readStringParam(raw, "query", "token", "symbol");
  // `operation` is the declared planner argument. `raw.subaction` and
  // `raw.action` carry the WALLET discriminator (`token_info`) on the planner
  // path, not a token-info subaction, so they only match when a direct caller
  // put a real subaction there. With no explicit subaction, a declared
  // `address` or `query` names the token to look up; only a request with
  // neither is classified from the message text.
  const subaction =
    normalizeTokenInfoSubaction(raw.operation) ??
    normalizeTokenInfoSubaction(raw.subaction) ??
    normalizeTokenInfoSubaction(raw.kind) ??
    normalizeTokenInfoSubaction(raw.action) ??
    (address || explicitQuery
      ? "token"
      : inferTokenInfoSubaction(message, state));
  const target = readStringParam(raw, "target", "provider", "source");
  const query = explicitQuery ?? (subaction === "search" ? content : undefined);
  const timeframeRaw = readStringParam(raw, "timeframe");
  const timeframe =
    timeframeRaw === "1h" || timeframeRaw === "6h" || timeframeRaw === "24h"
      ? timeframeRaw
      : undefined;
  const sortByRaw = readStringParam(raw, "sortBy", "sort");
  const sortBy =
    sortByRaw === "volume" ||
    sortByRaw === "liquidity" ||
    sortByRaw === "priceChange" ||
    sortByRaw === "txns"
      ? sortByRaw
      : undefined;
  const kindRaw = readStringParam(raw, "kind", "mode");
  const kind =
    kindRaw === "wallet-address" ||
    kindRaw === "token-address" ||
    kindRaw === "token-symbol"
      ? kindRaw
      : undefined;

  return {
    target,
    subaction,
    query,
    address,
    tokenAddress: readStringParam(raw, "tokenAddress") ?? address,
    chain: readStringParam(raw, "chain", "network"),
    timeframe,
    limit: readNumberParam(raw, "limit"),
    offset: readNumberParam(raw, "offset"),
    sortBy,
    top: readBooleanParam(raw, "top"),
    kind,
    id: readStringParam(raw, "id", "coinId"),
  };
}

export function selectedContextMatches(
  state: State | undefined,
  contexts: readonly string[],
): boolean {
  const selected = new Set<string>();
  const collect = (value: unknown) => {
    if (!Array.isArray(value)) return;
    for (const item of value) {
      if (typeof item === "string") selected.add(item);
    }
  };
  collect(
    (state?.values as Record<string, unknown> | undefined)?.selectedContexts,
  );
  collect(
    (state?.data as Record<string, unknown> | undefined)?.selectedContexts,
  );
  const contextObject = (state?.data as Record<string, unknown> | undefined)
    ?.contextObject as
    | {
        trajectoryPrefix?: { selectedContexts?: unknown };
        metadata?: { selectedContexts?: unknown };
      }
    | undefined;
  collect(contextObject?.trajectoryPrefix?.selectedContexts);
  collect(contextObject?.metadata?.selectedContexts);
  return contexts.some((context) => selected.has(context));
}
