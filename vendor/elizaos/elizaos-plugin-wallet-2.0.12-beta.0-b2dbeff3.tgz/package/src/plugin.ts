/**
 * Composes `walletPlugin`, the top-level plugin object the agent loads:
 * merges the core wallet-backend plugin (signing service + `wallet` provider)
 * with the EVM and Solana sub-plugins' services/providers/actions/routes, and
 * registers the Birdeye/DexScreener/TokenInfo analytics services. `init` and
 * `dispose` fan out to each composed piece in turn.
 */

import { resolveCloudRoute } from "@elizaos/cloud-routing";
import {
  type IAgentRuntime,
  parseBooleanFromText,
  type ServiceClass,
} from "@elizaos/core";
import type { HttpPlugin as Plugin } from "@elizaos/host/protocol";
import { tradeRouterAction } from "./actions/trade-action.js";
import { agentPortfolioProvider } from "./analytics/birdeye/providers/agent-portfolio-provider.js";
import { marketProvider } from "./analytics/birdeye/providers/market.js";
import { trendingProvider } from "./analytics/birdeye/providers/trending.js";
import { registerBirdeyeSearchCategories } from "./analytics/birdeye/search-category.js";
import {
  BIRDEYE_ROUTE_SPEC,
  BirdeyeService,
} from "./analytics/birdeye/service.js";
import { toWalletCloudRoutingSettings } from "./analytics/cloud-routing-authority.js";
import { registerDexScreenerSearchCategory } from "./analytics/dexscreener/search-category.js";
import { DexScreenerService } from "./analytics/dexscreener/service.js";
import { TokenInfoService } from "./analytics/token-info/service.js";
import evmPlugin from "./chains/evm/index.js";
import solanaPlugin from "./chains/solana/index.js";
import { stewardTradingProvider } from "./providers/steward-trading-provider.js";
import { walletProvider } from "./providers/wallet-provider.js";
import { StewardTradingService } from "./services/steward-trading-service.js";
import {
  WALLET_BACKEND_SERVICE_TYPE,
  WalletBackendService,
} from "./services/wallet-backend-service.js";

const coreWalletPlugin: Plugin = {
  name: "wallet-backend",
  description: "Wallet backend service + wallet provider (Steward / local).",
  services: [WalletBackendService, StewardTradingService],
  providers: [walletProvider, stewardTradingProvider],
  actions: [tradeRouterAction],
};
function concatServices(
  ...chunks: (readonly ServiceClass[] | undefined)[]
): ServiceClass[] {
  const out: ServiceClass[] = [];
  for (const c of chunks) {
    if (c) out.push(...c);
  }
  return out;
}
function concatPlugins<T>(...chunks: (readonly T[] | undefined)[]): T[] {
  const out: T[] = [];
  for (const c of chunks) {
    if (c) out.push(...c);
  }
  return out;
}
async function initBirdeyeAnalytics(runtime: IAgentRuntime): Promise<void> {
  const birdeyeRoute = resolveCloudRoute(
    toWalletCloudRoutingSettings(runtime),
    BIRDEYE_ROUTE_SPEC,
  );
  registerBirdeyeSearchCategories(runtime, {
    enabled: birdeyeRoute.source !== "disabled",
    disabledReason:
      birdeyeRoute.source === "disabled"
        ? "BIRDEYE_API_KEY or Eliza Cloud route is not configured."
        : undefined,
  });
  if (birdeyeRoute.source === "disabled") {
    runtime.logger.log(
      "birdeye: no BIRDEYE_API_KEY and Eliza Cloud not connected, skipping plugin-birdeye init",
    );
    return;
  }
  const walletAddr = runtime.getSetting("BIRDEYE_WALLET_ADDR");
  if (walletAddr) {
    runtime.registerProvider(agentPortfolioProvider);
  }
  runtime.registerProvider(marketProvider);
  const beNoTrending = parseBooleanFromText(
    String(runtime.getSetting("BIRDEYE_NO_TRENDING") ?? ""),
  );
  if (!beNoTrending) {
    runtime.registerProvider(trendingProvider);
  } else {
    runtime.logger.log(
      "BIRDEYE_NO_TRENDING is set, skipping trending provider",
    );
  }
}
const analyticsServices: ServiceClass[] = [
  BirdeyeService,
  DexScreenerService,
  TokenInfoService,
] as ServiceClass[];
/**
 * Single plugin surface: EVM + Solana wallet backend.
 * Consumers should depend only on `@elizaos/plugin-wallet`.
 */
export const walletPlugin: Plugin = {
  name: "wallet",
  description:
    "Non-custodial wallet for elizaOS — EVM + Solana, Steward/local backends, x402, CCTP, and venue routing.",
  services: concatServices(
    coreWalletPlugin.services,
    evmPlugin.services as ServiceClass[] | undefined,
    solanaPlugin.services as ServiceClass[] | undefined,
    analyticsServices,
  ),
  providers: concatPlugins(coreWalletPlugin.providers, evmPlugin.providers),
  actions: concatPlugins(coreWalletPlugin.actions, evmPlugin.actions),
  routes: concatPlugins(evmPlugin.routes, solanaPlugin.routes),
  init: async (config, runtime) => {
    await coreWalletPlugin.init?.(config, runtime);
    await evmPlugin.init?.(config, runtime);
    await solanaPlugin.init?.(config, runtime);
    registerDexScreenerSearchCategory(runtime);
    await initBirdeyeAnalytics(runtime);
  },
  async dispose(runtime: IAgentRuntime) {
    await evmPlugin.dispose?.(runtime);
    await solanaPlugin.dispose?.(runtime);
    const birdeye = runtime.getService<BirdeyeService>(
      BirdeyeService.serviceType,
    );
    await birdeye?.stop();
    const dexscreener = runtime.getService<DexScreenerService>(
      DexScreenerService.serviceType,
    );
    await dexscreener?.stop();
    const tokenInfo = runtime.getService<TokenInfoService>(
      TokenInfoService.serviceType,
    );
    await tokenInfo?.stop();
    const walletBackend = runtime.getService<WalletBackendService>(
      WALLET_BACKEND_SERVICE_TYPE,
    );
    await walletBackend?.stop();
    const stewardTrading = runtime.getService<StewardTradingService>(
      StewardTradingService.serviceType,
    );
    await stewardTrading?.stop();
  },
};
export default walletPlugin;
