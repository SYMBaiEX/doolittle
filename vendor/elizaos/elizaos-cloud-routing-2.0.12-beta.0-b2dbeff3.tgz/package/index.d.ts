/**
 * Public surface for cloud-routing feature metadata and route resolution.
 */
export { DEFAULT_FEATURE_POLICY, FEATURE_IDS, FEATURE_POLICIES, FEATURES, type Feature, type FeaturePolicy, type FeaturePolicyMap, getFeature, isFeature, isFeaturePolicy, } from "./features.js";
export { cloudServiceApisBaseUrl, getFeaturePolicy, getFeaturePolicyMap, isCloudConnected, RoutingPolicyError, type RuntimeSettings, resolveCloudRoute, resolveFeatureCloudRoute, toRuntimeSettings, } from "./resolve.js";
export type { CloudRoute, CloudRouteSource, FeatureCloudRoute, RouteSpec, } from "./types.js";
//# sourceMappingURL=index.d.ts.map