/**
 * Constructs the mutable state shared by agent API route adapters. Keeping the
 * initialization contract separate from the HTTP listener makes first-run,
 * runtime-backed, and stopped-server states deterministic and testable.
 */
import { type AgentAutomationMode, type AgentRuntime, type AgentLogEntry as LogEntry } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
import type { PluginEntry, ServerState } from "./server-types.js";
/**
 * Retention of the in-memory diagnostics log (`GET /api/logs`). The buffer
 * keeps the newest `ELIZA_API_LOG_BUFFER_MAX` entries (default 1000), plus at
 * most one recent credit warning needed by chat failure replies. It may
 * briefly hold up to 10% more, because eviction runs in batches so that one
 * log line does not shift the whole array. Older entries remain in the log
 * files and the process output. This buffer is diagnostics only; it is never
 * model context.
 */
export declare const API_LOG_BUFFER_MAX_ENV = "ELIZA_API_LOG_BUFFER_MAX";
export declare const DEFAULT_API_LOG_BUFFER_MAX = 1000;
/** The existing chat fallback reads credit evidence from the last minute. */
export declare function findRecentInsufficientCreditsLog(logBuffer: LogEntry[], lookbackMs?: number): LogEntry | null;
/** Reads the retention from the environment; a value that is set must be a positive integer. */
export declare function resolveApiLogBufferMax(raw?: string | undefined): number;
/** Appends entries in place (routes hold the array reference) and applies the retention. */
export declare function appendApiLogEntries(buffer: LogEntry[], entries: readonly LogEntry[], max: number): void;
export type InitialAgentState = Extract<ServerState["agentState"], "not_started" | "starting" | "stopped" | "error">;
export interface CreateServerStateOptions {
    config: ElizaConfig;
    runtime?: AgentRuntime;
    initialAgentState?: InitialAgentState;
    plugins: PluginEntry[];
    deletedConversationIds: Set<string>;
    resolveAgentName(config: ElizaConfig): string;
    detectRuntimeModel(runtime: AgentRuntime | null, config: ElizaConfig): string | undefined;
    resolveAgentAutomationMode(config: ElizaConfig): AgentAutomationMode;
    resolveTradePermissionMode(config: ElizaConfig): ServerState["tradePermissionMode"];
}
export declare function createServerState(options: CreateServerStateOptions): ServerState;
