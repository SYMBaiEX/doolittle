/**
 * Approval / pending-user-action routes.
 *
 * `GET /api/approvals` is the canonical read surface for work that is blocked
 * on the user. It aggregates legacy owner approval rows, task-based approval
 * records, and pending planner prompts into the shared `PendingUserAction`
 * contract so clients render one list without knowing producer internals.
 *
 * `POST /api/approvals/:id/resolve` applies the owner's tap in a review dialog.
 * The body names the decision and the revision the owner reviewed; the row
 * must be unchanged since, and still pending or retryable. The server gate
 * makes it owner-only.
 * Only Calendar approvals resolve here today.
 */
import type http from "node:http";
import { type IAgentRuntime, type PendingUserAction, type Task } from "@elizaos/core";
import type { RouteHelpers } from "@elizaos/host/protocol";
import { type ApprovalAction, type ApprovalRequest, type ApprovalRequestState } from "@elizaos/plugin-assistant";
interface ApprovalRouteRuntime {
    agentId?: string;
    getSetting?: IAgentRuntime["getSetting"];
    getService: (type: string) => unknown;
}
export interface ApprovalRouteState {
    runtime: ApprovalRouteRuntime | null;
}
export interface ApprovalRequestDto {
    id: string;
    state: ApprovalRequestState;
    requestedBy: string;
    subjectUserId: string;
    action: ApprovalAction;
    payload: ApprovalRequest["payload"];
    channel: ApprovalRequest["channel"];
    reason: string;
    expiresAt: string;
    resolvedAt: string | null;
    resolvedBy: string | null;
    resolutionReason: string | null;
    execution: {
        attemptId: string;
        provider: string;
        providerIdempotencyKey: string;
        claimedAt: string;
        dispatchStartedAt: string | null;
        providerReceipt: Readonly<Record<string, unknown>> | null;
        error: string | null;
        reconciledAt: string | null;
        reconciledBy: string | null;
        reconciliationReason: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
    revision: string;
}
/**
 * Parse the approvals `state` query. Omitted/empty keeps the pending default.
 * `all` means no state filter. A known lifecycle state selects that queue.
 * Any other token used to fall through to pending, so `state=DONE` or
 * `state=complete` silently listed pending work.
 */
export declare function parseApprovalState(raw: string | null): {
    ok: true;
    state: ApprovalRequestState | null;
} | {
    ok: false;
    message: string;
};
/**
 * The reviewed-row identity a client compares at the tap: every field the
 * review shows plus `updatedAt`, so any change to the row changes it.
 */
export declare function approvalRevision(approval: ApprovalRequest): string;
export declare function approvalTaskToPendingAction(task: Task): PendingUserAction | null;
export declare function handleApprovalRoute(req: http.IncomingMessage, res: http.ServerResponse, pathname: string, method: string, state: ApprovalRouteState, helpers: RouteHelpers): Promise<boolean>;
export {};
