export declare const SELF_API_UNREACHABLE_TEXT = "The local API is not reachable in this build.";
/** Set by the API server; undefined returns to the env inference. */
export declare function setSelfApiTcpListenerBound(bound: boolean | undefined): void;
export declare function hasSelfApiTcpListener(env?: NodeJS.ProcessEnv): boolean;
/** Base URL for HTTP self calls, or null when nothing of ours listens. */
export declare function resolveSelfApiTcpBaseUrl(env?: NodeJS.ProcessEnv): string | null;
