/**
 * Database management API handlers for the Eliza Control UI.
 *
 * Provides endpoints for:
 * - Database provider configuration (PGLite vs Postgres)
 * - Connection testing for remote Postgres
 * - Table browsing and introspection
 * - Row-level CRUD operations
 * - Raw SQL query execution
 * - Database status and health
 *
 * All data endpoints use the active runtime's database adapter (Drizzle ORM)
 * so they work identically for both PGLite and Postgres.
 */
import dns from "node:dns";
import net from "node:net";
import { promisify } from "node:util";
import { isLoopbackHost, logger, normalizeHostLike, normalizeIpForPolicy, parseClampedInteger, } from "@elizaos/core";
import { readJsonBody as parseJsonBody, sendJson, sendJsonError, } from "@elizaos/host";
import { resolveApiBindHost, } from "@elizaos/host/protocol";
import { loadElizaConfig, saveElizaConfig } from "../config/config.js";
import { checkReadOnly, executeReadOnlySql, } from "../security/sql-readonly-guard.js";
import { decodePathComponent } from "./server-helpers.js";
export { stripSqlBlockComments, stripSqlDollarQuotedLiterals, stripSqlLineComments, } from "../shared/sql-sanitizers.js";
import { parseRequestedSchema, qualifiedTable, quoteIdent, resolveTableSchema, } from "../shared/database-table.js";
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
async function readJsonBody(req, res) {
    return parseJsonBody(req, res, {
        maxBytes: 2 * 1024 * 1024,
    });
}
/**
 * Build a Postgres connection string from individual credential fields.
 */
function buildConnectionString(creds) {
    if (creds.connectionString)
        return creds.connectionString;
    const host = creds.host ?? "localhost";
    const port = creds.port ?? 5432;
    const user = encodeURIComponent(creds.user ?? "postgres");
    const password = creds.password ? encodeURIComponent(creds.password) : "";
    const database = creds.database ?? "postgres";
    const auth = password ? `${user}:${password}` : user;
    const sslParam = creds.ssl ? "?sslmode=verify-full" : "";
    return `postgresql://${auth}@${host}:${port}/${database}${sslParam}`;
}
/**
 * Return a copy of credentials with host pinned to a validated IP address.
 * For connection strings, rewrites URL hostname to avoid re-resolution later.
 */
function withPinnedHost(creds, pinnedHost) {
    const normalizedPinned = pinnedHost.replace(/^::ffff:/i, "");
    const next = { ...creds, host: normalizedPinned };
    if (next.connectionString) {
        try {
            const parsed = new URL(next.connectionString);
            parsed.hostname = normalizedPinned;
            // Preserve DNS pinning even when libpq-style query params are present.
            // `host` / `hostaddr` can override URI hostname; force both to pinned IP.
            parsed.searchParams.set("host", normalizedPinned);
            parsed.searchParams.set("hostaddr", normalizedPinned);
            next.connectionString = parsed.toString();
        }
        catch {
            // Validation has already parsed this once, but if URL rewriting fails,
            // force builder path to use the pinned host.
            delete next.connectionString;
        }
    }
    return next;
}
// ---------------------------------------------------------------------------
// Host validation — prevent SSRF via database connection endpoints
// ---------------------------------------------------------------------------
const dnsLookupAll = promisify(dns.lookup);
/**
 * IP ranges that are ALWAYS blocked regardless of bind address.
 * Cloud metadata and "this" network are never legitimate Postgres targets.
 */
const ALWAYS_BLOCKED_IP_PATTERNS = [
    /^169\.254\./, // Link-local / cloud metadata (AWS, GCP, Azure)
    /^0\./, // "This" network
    /^fe[89ab][0-9a-f]:/i, // IPv6 link-local fe80::/10
];
/**
 * Private/internal IP ranges — blocked only when the API is bound to a
 * non-loopback address (i.e. remotely reachable).  When bound to 127.0.0.1
 * (the default), these are allowed since local Postgres is the most common
 * setup and an attacker who can reach the loopback API already has local
 * network access.
 */
const PRIVATE_IP_PATTERNS = [
    /^127\./, // IPv4 loopback
    /^10\./, // RFC 1918 Class A
    /^172\.(1[6-9]|2\d|3[01])\./, // RFC 1918 Class B
    /^192\.168\./, // RFC 1918 Class C
    /^::1$/, // IPv6 loopback
    /^f[cd][0-9a-f]{2}:/i, // IPv6 ULA (fc00::/7 includes fc00::–fdff::)
];
/**
 * Returns true when the API server is bound to a loopback-only address.
 * In that case, private/internal IP ranges are allowed for DB connections
 * since only local processes can reach the API.
 */
function isApiLoopbackOnly() {
    let bind = resolveApiBindHost(process.env).trim().toLowerCase();
    if (!bind)
        bind = "127.0.0.1";
    // Accept accidental URL-shaped bind values.
    if (bind.startsWith("http://") || bind.startsWith("https://")) {
        try {
            const parsed = new URL(bind);
            bind = parsed.hostname.toLowerCase();
        }
        catch {
            // Fall through and treat as raw host value.
        }
    }
    // [::1]:2138 -> ::1
    const bracketedIpv6 = /^\[([^\]]+)\](?::\d+)?$/.exec(bind);
    if (bracketedIpv6?.[1]) {
        bind = bracketedIpv6[1];
    }
    else {
        // localhost:2138 -> localhost, 127.0.0.1:2138 -> 127.0.0.1
        const singleColonHostPort = /^([^:]+):(\d+)$/.exec(bind);
        if (singleColonHostPort?.[1]) {
            bind = singleColonHostPort[1];
        }
    }
    bind = bind.replace(/^\[|\]$/g, "");
    // Reuse the strict loopback classifier to avoid hostname prefix bypasses
    // such as "127.evil.com" that are not literal 127.0.0.0/8 IPs.
    return isLoopbackHost(bind);
}
/**
 * Extract all potential hosts from a Postgres connection string or credentials object.
 * Includes query params like ?host= and ?hostaddr= which Postgres clients honor.
 * Returns an error when the connection string cannot be parsed as a URL, and an
 * empty host list when no host can be determined.
 */
function extractHosts(creds) {
    if (creds.connectionString) {
        let url;
        try {
            url = new URL(creds.connectionString);
        }
        catch {
            return {
                hosts: null,
                error: "Invalid PostgreSQL connection string: expected a postgres:// or " +
                    "postgresql:// URL. Check the value for a missing scheme or stray characters.",
            };
        }
        const hosts = [];
        // PostgreSQL connection strings can have ?host= param that overrides URI hostname
        const hostParam = url.searchParams.get("host");
        if (hostParam) {
            hosts.push(...hostParam
                .split(",")
                .map((h) => normalizeHostLike(h))
                .filter(Boolean));
        }
        // Also check hostaddr param
        const hostAddrParam = url.searchParams.get("hostaddr");
        if (hostAddrParam) {
            hosts.push(...hostAddrParam
                .split(",")
                .map((h) => normalizeHostLike(h))
                .filter(Boolean));
        }
        // Include URI hostname
        if (url.hostname) {
            hosts.push(normalizeHostLike(url.hostname));
        }
        return { hosts: [...new Set(hosts)], error: null };
    }
    if (creds.host) {
        const host = normalizeHostLike(creds.host);
        return { hosts: host ? [host] : [], error: null };
    }
    return { hosts: [], error: null };
}
/**
 * Check whether an IP address falls in a blocked range.
 * When the API is remotely reachable, private ranges are also blocked.
 */
function isBlockedIp(ip) {
    const normalized = normalizeIpForPolicy(ip);
    if (ALWAYS_BLOCKED_IP_PATTERNS.some((p) => p.test(normalized)))
        return true;
    if (!isApiLoopbackOnly() &&
        PRIVATE_IP_PATTERNS.some((p) => p.test(normalized)))
        return true;
    return false;
}
/**
 * Validate that all target hosts do not resolve to blocked addresses.
 *
 * Performs DNS resolution to catch hostnames like `metadata.google.internal`
 * or `169.254.169.254.nip.io` that resolve to link-local / cloud metadata
 * IPs.  Also handles IPv6-mapped IPv4 addresses (e.g. `::ffff:169.254.x.y`).
 *
 * Returns a validation result including a pinned host IP when successful.
 */
export async function validateDbHost(creds, opts = {}) {
    const extracted = extractHosts(creds);
    if (extracted.hosts === null) {
        return { error: extracted.error, pinnedHost: null };
    }
    const hosts = extracted.hosts;
    if (hosts.length === 0) {
        return {
            error: "Could not determine target host from the provided credentials.",
            pinnedHost: null,
        };
    }
    let pinnedHost = null;
    for (const host of hosts) {
        const literalNormalized = normalizeIpForPolicy(host);
        // First check the literal host string (catches raw IPs without DNS lookup)
        if (isBlockedIp(literalNormalized)) {
            return {
                error: `Connection to "${host}" is blocked: link-local and metadata addresses are not allowed.`,
                pinnedHost: null,
            };
        }
        // Literal IPs are already pinned and do not require DNS.
        if (net.isIP(literalNormalized)) {
            if (!pinnedHost)
                pinnedHost = literalNormalized;
            continue;
        }
        // Resolve DNS and check all resulting IPs
        try {
            const results = await dnsLookupAll(host, { all: true });
            const addresses = Array.isArray(results) ? results : [results];
            for (const entry of addresses) {
                const ip = typeof entry === "string"
                    ? entry
                    : entry.address;
                const normalized = normalizeIpForPolicy(ip);
                if (isBlockedIp(normalized)) {
                    return {
                        error: `Connection to "${host}" is blocked: it resolves to ${ip} ` +
                            `which is a link-local or metadata address.`,
                        pinnedHost: null,
                    };
                }
                if (!pinnedHost)
                    pinnedHost = normalized;
            }
        }
        catch {
            // For "save config" flows we allow unresolved hostnames so users can
            // persist remote endpoints that are only resolvable from their runtime
            // network. For "test connection" flows we keep strict DNS requirements.
            if (!opts.allowUnresolvedHostnames) {
                return {
                    error: `Connection to "${host}" failed DNS resolution during validation. ` +
                        "Use a resolvable hostname or a literal IP address.",
                    pinnedHost: null,
                };
            }
        }
    }
    if (!pinnedHost) {
        if (opts.allowUnresolvedHostnames) {
            return { error: null, pinnedHost: null };
        }
        return {
            error: "Could not validate any host to a concrete IP address.",
            pinnedHost: null,
        };
    }
    return { error: null, pinnedHost };
}
/** Convert a JS value to a SQL literal for use in raw queries. */
function sqlLiteral(v) {
    if (v === null || v === undefined)
        return "NULL";
    if (typeof v === "number")
        return String(v);
    if (typeof v === "boolean")
        return v ? "TRUE" : "FALSE";
    if (typeof v === "object")
        return `'${JSON.stringify(v).replace(/'/g, "''")}'::jsonb`;
    return `'${String(v).replace(/'/g, "''")}'`;
}
/** Build a "col = val" SQL assignment clause. */
function sqlAssign(col, val) {
    if (val === null || val === undefined)
        return `${quoteIdent(col)} = NULL`;
    return `${quoteIdent(col)} = ${sqlLiteral(val)}`;
}
/** Build a "col = val" or "col IS NULL" SQL WHERE predicate. */
function sqlPredicate(col, val) {
    if (val === null || val === undefined)
        return `${quoteIdent(col)} IS NULL`;
    return `${quoteIdent(col)} = ${sqlLiteral(val)}`;
}
// Cached drizzle-orm sql helper; resolved once on first call.
let _sqlHelper = null;
async function getDrizzleSql() {
    if (!_sqlHelper) {
        const drizzle = await import("drizzle-orm");
        _sqlHelper = drizzle.sql;
    }
    return _sqlHelper;
}
function isQueryRow(value) {
    return typeof value === "object" && value !== null;
}
function normalizeQueryRows(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    return value.filter(isQueryRow);
}
/** Execute raw SQL via the runtime's Drizzle adapter. */
async function executeRawSql(runtime, sqlText) {
    const drizzleSql = await getDrizzleSql();
    const db = runtime.adapter.db;
    const rawQuery = drizzleSql?.raw(sqlText);
    if (!rawQuery)
        throw new Error("SQL module not available");
    const result = await db.execute(rawQuery);
    const rows = normalizeQueryRows(result.rows);
    let columns = [];
    if (result.fields && Array.isArray(result.fields)) {
        columns = result.fields.map((f) => f.name);
    }
    else if (rows.length > 0) {
        columns = Object.keys(rows[0]);
    }
    return { rows, columns };
}
/**
 * Detect the current database provider from environment / runtime state.
 */
function detectCurrentProvider() {
    return process.env.POSTGRES_URL ? "postgres" : "pglite";
}
async function requireTableSchema(req, res, runtime, tableName) {
    const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
    const parsed = parseRequestedSchema(url.searchParams.get("schema"));
    if (!parsed.ok) {
        sendJsonError(res, "schema must name a non-system database schema", 400);
        return null;
    }
    const schema = await resolveTableSchema((query) => executeRawSql(runtime, query), tableName, parsed.schema);
    if (!schema) {
        sendJsonError(res, `Table "${tableName}" not found`, 404);
        return null;
    }
    return schema;
}
// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------
/**
 * GET /api/database/status
 * Returns current connection status, provider, table count, version.
 */
async function handleGetStatus(_req, res, runtime) {
    const provider = detectCurrentProvider();
    if (!runtime?.adapter) {
        sendJson(res, {
            provider,
            connected: false,
            serverVersion: null,
            tableCount: 0,
            pgliteDataDir: process.env.PGLITE_DATA_DIR ?? null,
            postgresHost: null,
        });
        return;
    }
    const { rows } = await executeRawSql(runtime, "SELECT version()");
    const serverVersion = rows.length > 0
        ? String(rows[0].version ?? "")
        : null;
    const tableResult = await executeRawSql(runtime, `SELECT count(*) AS cnt
       FROM information_schema.tables
      WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
        AND table_type = 'BASE TABLE'`);
    const tableCount = tableResult.rows.length > 0
        ? Number(tableResult.rows[0].cnt ?? 0)
        : 0;
    const status = {
        provider,
        connected: true,
        serverVersion,
        tableCount,
        pgliteDataDir: provider === "pglite" ? (process.env.PGLITE_DATA_DIR ?? null) : null,
        postgresHost: provider === "postgres"
            ? (process.env.POSTGRES_URL?.replace(/^postgresql:\/\/[^@]*@/, "").replace(/\/.*$/, "") ?? null)
            : null,
    };
    sendJson(res, status);
}
/**
 * GET /api/database/config
 * Returns the persisted database configuration from eliza.json.
 */
function handleGetConfig(_req, res) {
    const config = loadElizaConfig();
    const dbConfig = config.database ?? { provider: "pglite" };
    sendJson(res, {
        config: sanitizeDatabaseConfig(dbConfig),
        activeProvider: detectCurrentProvider(),
        needsRestart: (dbConfig.provider ?? "pglite") !== detectCurrentProvider(),
    });
}
const MASKED_PASSWORD = "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
/**
 * Mask the password in a Postgres connection string, keeping the scheme,
 * user, host and params. An unparseable string is masked whole.
 */
export function maskConnectionString(connectionString) {
    try {
        const url = new URL(connectionString);
        if (url.password)
            url.password = "***";
        if (url.searchParams.has("password")) {
            url.searchParams.set("password", "***");
        }
        return url.toString();
    }
    catch {
        return MASKED_PASSWORD;
    }
}
/** Copy of a database config with the Postgres password and DSN masked. */
export function sanitizeDatabaseConfig(dbConfig) {
    const sanitized = { ...dbConfig };
    if (sanitized.postgres?.password) {
        sanitized.postgres = { ...sanitized.postgres, password: MASKED_PASSWORD };
    }
    if (sanitized.postgres?.connectionString) {
        sanitized.postgres = {
            ...sanitized.postgres,
            connectionString: maskConnectionString(sanitized.postgres.connectionString),
        };
    }
    return sanitized;
}
/**
 * PUT /api/database/config
 * Saves new database configuration. Does NOT restart the agent automatically;
 * the UI prompts the user to restart.
 */
async function handlePutConfig(req, res, liveConfig) {
    const body = await readJsonBody(req, res);
    if (!body)
        return;
    // Validate
    if (body.provider &&
        body.provider !== "pglite" &&
        body.provider !== "postgres") {
        sendJsonError(res, `Invalid provider: ${String(body.provider)}. Must be "pglite" or "postgres".`);
        return;
    }
    // Load current config so validation can account for unchanged provider.
    const config = loadElizaConfig();
    const existingDb = config.database ?? {};
    const effectiveProvider = body.provider ?? existingDb.provider ?? "pglite";
    if (body.postgres) {
        const pg = body.postgres;
        if (effectiveProvider === "postgres" && !pg.connectionString && !pg.host) {
            sendJsonError(res, "Postgres configuration requires either a connectionString or at least a host.");
            return;
        }
        const validation = await validateDbHost(pg, {
            allowUnresolvedHostnames: Boolean(pg.connectionString),
        });
        if (validation.error) {
            sendJsonError(res, validation.error);
            return;
        }
        // The host is stored as entered: pinning to the resolved IP would break
        // TLS name checks and DNS failover. Boot re-validates the host and pins
        // its address (see pinConfiguredPostgresUrl in runtime/eliza.ts).
    }
    // Merge: keep existing postgres/pglite sub-configs unless explicitly provided
    const merged = {
        ...existingDb,
        ...body,
    };
    // If switching to postgres, ensure postgres config is present
    if (merged.provider === "postgres" && body.postgres) {
        merged.postgres = {
            ...existingDb.postgres,
            ...body.postgres,
        };
    }
    // If switching to pglite, ensure pglite config is present
    if (merged.provider === "pglite" && body.pglite) {
        merged.pglite = { ...existingDb.pglite, ...body.pglite };
    }
    config.database = merged;
    saveElizaConfig(config);
    // Mirror into the live server config so a later full save of it does not
    // write the previous database settings back to disk.
    if (liveConfig)
        liveConfig.database = merged;
    logger.info({ src: "database-api", provider: merged.provider }, "Database configuration saved");
    sendJson(res, {
        saved: true,
        config: sanitizeDatabaseConfig(merged),
        needsRestart: (merged.provider ?? "pglite") !== detectCurrentProvider(),
    });
}
/**
 * POST /api/database/test
 * Tests a Postgres connection without persisting anything.
 * Body: { connectionString?, host?, port?, user?, password?, database?, ssl? }
 */
async function handleTestConnection(req, res) {
    const body = await readJsonBody(req, res);
    if (!body)
        return;
    const validation = await validateDbHost(body);
    if (validation.error) {
        sendJsonError(res, validation.error);
        return;
    }
    const pinnedCreds = validation.pinnedHost
        ? withPinnedHost(body, validation.pinnedHost)
        : body;
    const connectionString = buildConnectionString(pinnedCreds);
    const start = Date.now();
    // Dynamically import pg to avoid hard-coupling (it is a peer dep via plugin-sql)
    let Pool;
    try {
        const pgModule = await import("pg");
        Pool = pgModule.default.Pool;
    }
    catch {
        sendJson(res, {
            success: false,
            serverVersion: null,
            error: "PostgreSQL client library (pg) is not available. Ensure @elizaos/plugin-sql is installed.",
            durationMs: Date.now() - start,
        });
        return;
    }
    const pool = new Pool({
        connectionString,
        max: 1,
        connectionTimeoutMillis: 10000,
        idleTimeoutMillis: 5000,
    });
    let client = null;
    try {
        client = await pool.connect();
        const versionResult = await client.query("SELECT version()");
        const serverVersion = String(versionResult.rows[0]?.version ?? "");
        const durationMs = Date.now() - start;
        sendJson(res, {
            success: true,
            serverVersion,
            error: null,
            durationMs,
        });
    }
    catch (err) {
        const durationMs = Date.now() - start;
        // error-policy:J1 retain driver diagnostics in structured logs without
        // returning server paths, SQL, or connection internals to the caller.
        logger.error({ err }, "[database-api] PostgreSQL connection test failed");
        sendJson(res, {
            success: false,
            serverVersion: null,
            error: "Database connection failed",
            durationMs,
        });
    }
    finally {
        if (client)
            client.release();
        await pool.end();
    }
}
/**
 * GET /api/database/tables
 * Lists all user tables with column metadata and approximate row counts.
 */
async function handleGetTables(_req, res, runtime) {
    // Get all user tables
    const tablesResult = await executeRawSql(runtime, `SELECT
       t.table_schema AS schema,
       t.table_name AS name,
       COALESCE(s.n_live_tup, 0) AS row_count
     FROM information_schema.tables t
     LEFT JOIN pg_stat_user_tables s
       ON s.schemaname = t.table_schema
       AND s.relname = t.table_name
     WHERE t.table_schema NOT IN ('pg_catalog', 'information_schema')
       AND t.table_type = 'BASE TABLE'
     ORDER BY t.table_schema, t.table_name`);
    // Get columns for all tables in one query
    const columnsResult = await executeRawSql(runtime, `SELECT
       c.table_schema AS schema,
       c.table_name AS table_name,
       c.column_name AS name,
       c.data_type AS type,
       (c.is_nullable = 'YES') AS nullable,
       c.column_default AS default_value,
       COALESCE(
         (SELECT true
          FROM information_schema.table_constraints tc
          JOIN information_schema.key_column_usage kcu
            ON tc.constraint_name = kcu.constraint_name
           AND tc.table_schema = kcu.table_schema
          WHERE tc.constraint_type = 'PRIMARY KEY'
            AND tc.table_schema = c.table_schema
            AND tc.table_name = c.table_name
            AND kcu.column_name = c.column_name),
         false
       ) AS is_primary_key
     FROM information_schema.columns c
     WHERE c.table_schema NOT IN ('pg_catalog', 'information_schema')
     ORDER BY c.table_schema, c.table_name, c.ordinal_position`);
    // Group columns by table
    const columnsByTable = new Map();
    for (const row of columnsResult.rows) {
        const key = JSON.stringify([row.schema, row.table_name]);
        const cols = columnsByTable.get(key) ?? [];
        cols.push({
            name: String(row.name),
            type: String(row.type),
            nullable: Boolean(row.nullable),
            defaultValue: row.default_value != null ? String(row.default_value) : null,
            isPrimaryKey: Boolean(row.is_primary_key),
        });
        columnsByTable.set(key, cols);
    }
    const tables = tablesResult.rows.map((row) => {
        const key = JSON.stringify([row.schema, row.name]);
        return {
            name: String(row.name),
            schema: String(row.schema),
            rowCount: Number(row.row_count ?? 0),
            columns: columnsByTable.get(key) ?? [],
        };
    });
    sendJson(res, { tables });
}
const ROWS_DEFAULT_LIMIT = 50;
const ROWS_MAX_LIMIT = 500;
/**
 * Parse + clamp the `offset`/`limit` query params for row pagination. The
 * values are interpolated into the SQL `LIMIT ... OFFSET ...` clause, so they
 * MUST come out as safe non-negative integers: `Math.max(0, Number("abc"))` is
 * `NaN` (Math.max propagates NaN), and a raw `Number()` also lets through
 * floats ("1.5") and "Infinity" — all of which previously reached the query
 * text and made the whole request 500. Non-numeric/unsafe input falls back to
 * the defaults; out-of-range integers clamp. Exported for unit tests.
 */
export function parseRowsPagination(offsetRaw, limitRaw) {
    return {
        offset: parseClampedInteger(offsetRaw, { fallback: 0, min: 0 }),
        limit: parseClampedInteger(limitRaw, {
            fallback: ROWS_DEFAULT_LIMIT,
            min: 1,
            max: ROWS_MAX_LIMIT,
        }),
    };
}
/**
 * Parse the `order` query for row retrieval. The token is interpolated into
 * `ORDER BY ... ASC|DESC`, so only the Control UI's exact `asc`/`desc`
 * identities are legal. `order=DESC` used to become ASC because only the
 * lowercase `desc` token flipped the direction.
 */
export function parseRowsSortOrder(raw) {
    if (raw === null || raw === "")
        return { ok: true, order: "ASC" };
    if (raw === "asc")
        return { ok: true, order: "ASC" };
    if (raw === "desc")
        return { ok: true, order: "DESC" };
    return { ok: false };
}
/**
 * GET /api/database/tables/:table/rows?offset=0&limit=50&sort=col&order=asc&search=term
 * Paginated row retrieval for a specific table.
 */
async function handleGetRows(req, res, runtime, tableName) {
    const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
    const { offset, limit } = parseRowsPagination(url.searchParams.get("offset"), url.searchParams.get("limit"));
    const parsedOrder = parseRowsSortOrder(url.searchParams.get("order"));
    if (!parsedOrder.ok) {
        sendJsonError(res, "order must be asc or desc", 400);
        return;
    }
    const sortCol = url.searchParams.get("sort") ?? "";
    const sortOrder = parsedOrder.order;
    const search = url.searchParams.get("search") ?? "";
    const parsedSchema = parseRequestedSchema(url.searchParams.get("schema"));
    if (!parsedSchema.ok) {
        sendJsonError(res, "schema must name a non-system database schema", 400);
        return;
    }
    const schema = await resolveTableSchema((query) => executeRawSql(runtime, query), tableName, parsedSchema.schema);
    if (!schema) {
        sendJsonError(res, `Table "${tableName}" not found`, 404);
        return;
    }
    const relation = qualifiedTable(schema, tableName);
    // Get column names for this table (for search and sort validation)
    const safeTableName = tableName.replace(/'/g, "''");
    const safeSchema = schema.replace(/'/g, "''");
    const colResult = await executeRawSql(runtime, `SELECT column_name, data_type
     FROM information_schema.columns
     WHERE table_name = '${safeTableName}'
       AND table_schema = '${safeSchema}'
     ORDER BY ordinal_position`);
    const columnNames = colResult.rows.map((r) => String(r.column_name));
    const columnTypes = new Map(colResult.rows.map((r) => [String(r.column_name), String(r.data_type)]));
    // Validate sort column
    const validSort = sortCol && columnNames.includes(sortCol) ? sortCol : "";
    // Build search clause: search across all text-castable columns
    let whereClause = "";
    if (search.trim()) {
        // Escape ILIKE special characters: backslash first (since it becomes
        // the escape character), then the ILIKE wildcards % and _.
        const escapedSearch = search
            .replace(/'/g, "''")
            .replace(/\\/g, "\\\\")
            .replace(/%/g, "\\%")
            .replace(/_/g, "\\_");
        const textColumns = columnNames.filter((col) => {
            const t = columnTypes.get(col) ?? "";
            return (t.includes("char") ||
                t.includes("text") ||
                t === "uuid" ||
                t === "jsonb" ||
                t === "json" ||
                t === "integer" ||
                t === "bigint" ||
                t === "numeric" ||
                t === "timestamp" ||
                t.includes("timestamp"));
        });
        if (textColumns.length > 0) {
            const conditions = textColumns.map((col) => `${quoteIdent(col)}::text ILIKE '%${escapedSearch}%' ESCAPE '\\'`);
            whereClause = `WHERE (${conditions.join(" OR ")})`;
        }
    }
    // Count total (with search filter)
    const countResult = await executeRawSql(runtime, `SELECT count(*) AS total FROM ${relation} ${whereClause}`);
    const total = Number(countResult.rows[0]?.total ?? 0);
    // OFFSET pages are separate queries, so the order must be total: a sort
    // column with ties (or no ORDER BY at all) lets rows trade places between
    // pages and be shown twice or never. The primary key breaks ties; a table
    // without one falls back to its physical row id. ctid can move after an
    // UPDATE or VACUUM FULL, so that fallback is stable only inside one query.
    // The probe must use the same relation an unqualified FROM resolves: a
    // same-named table in another schema would otherwise add columns the read
    // does not have, and the page query would fail.
    const pkResult = await executeRawSql(runtime, `SELECT kcu.column_name
     FROM information_schema.table_constraints tc
     JOIN information_schema.key_column_usage kcu
       ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
      AND tc.table_name = kcu.table_name
     WHERE tc.constraint_type = 'PRIMARY KEY'
       AND tc.table_name = '${safeTableName}'
       AND tc.table_schema = '${safeSchema}'
     ORDER BY kcu.ordinal_position`);
    const tieBreak = pkResult.rows.length
        ? pkResult.rows.map((r) => quoteIdent(String(r.column_name)))
        : ["tableoid", "ctid"];
    const orderTerms = [
        ...(validSort ? [quoteIdent(validSort)] : []),
        ...tieBreak.filter((term) => !validSort || term !== quoteIdent(validSort)),
    ].map((term) => `${term} ${sortOrder}`);
    // Fetch rows
    const orderClause = `ORDER BY ${orderTerms.join(", ")}`;
    const query = `SELECT * FROM ${relation} ${whereClause} ${orderClause} LIMIT ${limit} OFFSET ${offset}`;
    const result = await executeRawSql(runtime, query);
    sendJson(res, {
        table: tableName,
        rows: result.rows,
        columns: result.columns,
        total,
        offset,
        limit,
    });
}
/**
 * POST /api/database/tables/:table/rows
 * Insert a new row. Body: { data: Record<string, unknown> }
 */
async function handleInsertRow(req, res, runtime, tableName) {
    const body = await readJsonBody(req, res);
    if (!body)
        return;
    if (!body.data ||
        typeof body.data !== "object" ||
        Object.keys(body.data).length === 0) {
        sendJsonError(res, "Request body must include a non-empty 'data' object.");
        return;
    }
    const schema = await requireTableSchema(req, res, runtime, tableName);
    if (!schema)
        return;
    const columns = Object.keys(body.data);
    const values = Object.values(body.data);
    const colList = columns.map((c) => quoteIdent(c)).join(", ");
    const valList = values.map(sqlLiteral).join(", ");
    const result = await executeRawSql(runtime, `INSERT INTO ${qualifiedTable(schema, tableName)} (${colList}) VALUES (${valList}) RETURNING *`);
    sendJson(res, { inserted: true, row: result.rows[0] ?? null }, 201);
}
/**
 * PUT /api/database/tables/:table/rows
 * Update a row. Body: { where: Record<string, unknown>, data: Record<string, unknown> }
 */
async function handleUpdateRow(req, res, runtime, tableName) {
    const body = await readJsonBody(req, res);
    if (!body)
        return;
    if (!body.where || Object.keys(body.where).length === 0) {
        sendJsonError(res, "Request body must include a non-empty 'where' object for row identification.");
        return;
    }
    if (!body.data || Object.keys(body.data).length === 0) {
        sendJsonError(res, "Request body must include a non-empty 'data' object with fields to update.");
        return;
    }
    const schema = await requireTableSchema(req, res, runtime, tableName);
    if (!schema)
        return;
    const setClauses = Object.entries(body.data).map(([col, val]) => sqlAssign(col, val));
    const whereClauses = Object.entries(body.where).map(([col, val]) => sqlPredicate(col, val));
    const result = await executeRawSql(runtime, `UPDATE ${qualifiedTable(schema, tableName)}
        SET ${setClauses.join(", ")}
      WHERE ${whereClauses.join(" AND ")}
      RETURNING *`);
    if (result.rows.length === 0) {
        sendJsonError(res, "No matching row found to update.", 404);
        return;
    }
    sendJson(res, { updated: true, row: result.rows[0] });
}
/**
 * DELETE /api/database/tables/:table/rows
 * Delete a row. Body: { where: Record<string, unknown> }
 */
async function handleDeleteRow(req, res, runtime, tableName) {
    const body = await readJsonBody(req, res);
    if (!body)
        return;
    if (!body.where || Object.keys(body.where).length === 0) {
        sendJsonError(res, "Request body must include a non-empty 'where' object for row identification.");
        return;
    }
    const schema = await requireTableSchema(req, res, runtime, tableName);
    if (!schema)
        return;
    const whereClauses = Object.entries(body.where).map(([col, val]) => sqlPredicate(col, val));
    const result = await executeRawSql(runtime, `DELETE FROM ${qualifiedTable(schema, tableName)}
      WHERE ${whereClauses.join(" AND ")}
      RETURNING *`);
    if (result.rows.length === 0) {
        sendJsonError(res, "No matching row found to delete.", 404);
        return;
    }
    sendJson(res, { deleted: true, row: result.rows[0] });
}
/**
 * POST /api/database/query
 * Execute a raw SQL query. Body: { sql: string, readOnly?: boolean }
 */
async function handleQuery(req, res, runtime) {
    const body = await readJsonBody(req, res);
    if (!body)
        return;
    if (!body.sql ||
        typeof body.sql !== "string" ||
        body.sql.trim().length === 0) {
        sendJsonError(res, "Request body must include a non-empty 'sql' string.");
        return;
    }
    const sqlText = body.sql.trim();
    const readOnly = body.readOnly !== false;
    if (readOnly) {
        const guard = checkReadOnly(sqlText);
        if (!guard.ok) {
            sendJsonError(res, `Read-only query refused: ${"reason" in guard ? guard.reason : "not read-only"}`);
            return;
        }
    }
    const start = Date.now();
    const result = readOnly
        ? await executeReadOnlySql(runtime.adapter.db, sqlText)
        : await executeRawSql(runtime, sqlText);
    const durationMs = Date.now() - start;
    const queryResult = {
        columns: result.columns,
        rows: result.rows,
        rowCount: result.rows.length,
        durationMs,
    };
    sendJson(res, queryResult);
}
// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
/**
 * Route a database API request. Returns true if handled, false if not matched.
 *
 * Expected URL patterns:
 *   GET    /api/database/status
 *   GET    /api/database/config
 *   PUT    /api/database/config
 *   POST   /api/database/test
 *   GET    /api/database/tables
 *   GET    /api/database/tables/:table/rows
 *   POST   /api/database/tables/:table/rows
 *   PUT    /api/database/tables/:table/rows
 *   DELETE /api/database/tables/:table/rows
 *   POST   /api/database/query
 */
export async function handleDatabaseRoute(req, res, runtime, pathname, liveConfig) {
    const method = req.method ?? "GET";
    // ── GET /api/database/status ──────────────────────────────────────────
    if (method === "GET" && pathname === "/api/database/status") {
        await handleGetStatus(req, res, runtime);
        return true;
    }
    // ── GET /api/database/config ──────────────────────────────────────────
    if (method === "GET" && pathname === "/api/database/config") {
        handleGetConfig(req, res);
        return true;
    }
    // ── PUT /api/database/config ──────────────────────────────────────────
    if (method === "PUT" && pathname === "/api/database/config") {
        await handlePutConfig(req, res, liveConfig);
        return true;
    }
    // ── POST /api/database/test ───────────────────────────────────────────
    if (method === "POST" && pathname === "/api/database/test") {
        await handleTestConnection(req, res);
        return true;
    }
    // Routes below require a live runtime with a database adapter
    if (!runtime?.adapter) {
        sendJsonError(res, "Database not available. The agent may not be running or the database adapter is not initialized.", 503);
        return true;
    }
    // ── GET /api/database/tables ──────────────────────────────────────────
    if (method === "GET" && pathname === "/api/database/tables") {
        await handleGetTables(req, res, runtime);
        return true;
    }
    // ── POST /api/database/query ──────────────────────────────────────────
    if (method === "POST" && pathname === "/api/database/query") {
        await handleQuery(req, res, runtime);
        return true;
    }
    // ── Table row operations: /api/database/tables/:table/rows ────────────
    const rowsMatch = pathname.match(/^\/api\/database\/tables\/([^/]+)\/rows$/);
    if (rowsMatch) {
        const tableNameDecoded = decodePathComponent(rowsMatch[1], res, "database table name");
        if (tableNameDecoded === null)
            return true;
        if (method === "GET") {
            await handleGetRows(req, res, runtime, tableNameDecoded);
            return true;
        }
        if (method === "POST") {
            await handleInsertRow(req, res, runtime, tableNameDecoded);
            return true;
        }
        if (method === "PUT") {
            await handleUpdateRow(req, res, runtime, tableNameDecoded);
            return true;
        }
        if (method === "DELETE") {
            await handleDeleteRow(req, res, runtime, tableNameDecoded);
            return true;
        }
    }
    return false;
}
