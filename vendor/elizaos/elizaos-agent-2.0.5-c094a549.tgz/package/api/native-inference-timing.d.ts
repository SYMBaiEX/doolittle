/** Last native owner turn only; status reads never query logs or the global timing registry. */
import { type IAgentRuntime, type InferenceFlowStage, type InferenceTurnSummary } from "@elizaos/core";
export interface NativeInferenceTiming {
    version: 1;
    traceId?: string;
    totalMs: number | null;
    timeToFirstVisibleMs: number | null;
    timeToReplyMs: number | null;
    timeToResponseFinalizedMs: number | null;
    stages: {
        stage: InferenceFlowStage;
        totalMs: number;
        toFirstVisibleMs: number | null;
    }[];
}
/** Capture authority before generation, then observe its existing host timer. */
export declare function captureNativeInferenceTiming(runtime: IAgentRuntime, sender: string): ((summary: InferenceTurnSummary) => void) | undefined;
export declare function readNativeInferenceTiming(runtime: IAgentRuntime): NativeInferenceTiming | undefined;
