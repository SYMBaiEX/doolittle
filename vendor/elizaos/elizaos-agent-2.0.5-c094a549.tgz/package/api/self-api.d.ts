import type { DispatchRouteArgs } from "./dispatch-route.js";
export interface SelfApiReadRequest {
    runtime: DispatchRouteArgs["runtime"];
    path: string;
    query?: Record<string, string>;
    isAuthorized: () => boolean;
    timeoutMs: number;
}
export interface SelfApiResponse {
    status: number;
    /** Parsed JSON for a 2xx response; undefined otherwise. */
    body: unknown;
}
export declare function callSelfApi({ runtime, path, query, isAuthorized, timeoutMs, }: SelfApiReadRequest): Promise<SelfApiResponse>;
