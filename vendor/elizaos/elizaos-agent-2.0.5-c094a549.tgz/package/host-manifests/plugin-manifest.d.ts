/**
 * Plugin manifest evaluation engine — decides which plugins auto-enable by
 * reading each plugin's own manifest instead of a centralized map.
 *
 * Each plugin declares its auto-enable conditions in its package.json under
 * `elizaos.plugin`, optionally pointing at a small JS module that implements
 * the actual `shouldEnable(ctx)` check:
 *
 *   {
 *     "elizaos": {
 *       "plugin": {
 *         "autoEnableModule": "./dist/auto-enable.js",
 *         "force": false,
 *         "capabilities": ["text-large", "tool-use"]
 *       }
 *     }
 *   }
 *
 * The check module exports:
 *
 *   export function shouldEnable(ctx: PluginAutoEnableContext): boolean | Promise<boolean>;
 *   export function shouldForce?(ctx: PluginAutoEnableContext): boolean;  // optional override
 *
 * The engine walks candidate plugin packages, reads each package.json for the
 * elizaos.plugin block, dynamic-imports the autoEnableModule, evaluates
 * shouldEnable + shouldForce against the runtime context, and returns a verdict
 * per plugin (never throwing — failures surface in the verdict's `error`).
 *
 * This replaces the centralized maps in plugin-auto-enable-engine.ts. Both
 * engines coexist during the migration: the new one runs first, the old one
 * fills gaps for plugins that haven't migrated yet. When all plugins ship a
 * manifest, the central maps and the old engine can be deleted.
 */
import type { PluginAutoEnableContext, PluginAutoEnableModule } from "@elizaos/core";
import type { ElizaConfig } from "@elizaos/host/protocol";
export type { PluginAutoEnableContext, PluginAutoEnableModule };
/** Subset of package.json the manifest reader cares about. */
export interface PluginPackageManifestBlock {
    /**
     * Path (relative to the plugin's package root) to the autoEnable check module.
     * The module must implement {@link PluginAutoEnableModule}.
     */
    autoEnableModule?: string;
    /**
     * Static capability declarations. Apps can use these to filter candidates
     * (e.g. "I only need plugins that declare `wallet` capability"). Purely
     * informational — the engine doesn't act on them today.
     */
    capabilities?: string[];
    /**
     * Hard-coded force flag. When true, the plugin overrides
     * `config.plugins.entries[X].enabled === false`. Equivalent to a
     * `shouldForce` that always returns true; useful when force is unconditional.
     */
    force?: boolean;
}
export interface PluginPackageManifest {
    name: string;
    version?: string;
    elizaos?: {
        plugin?: PluginPackageManifestBlock;
    };
}
/**
 * Minimal candidate shape for the autoEnable manifest evaluator: only the
 * package name and root dir are needed.
 */
export interface PluginManifestCandidate {
    /** npm package name (e.g. "@elizaos/plugin-anthropic"). */
    packageName: string;
    /** Absolute path to the package root (the dir containing package.json). */
    packageRoot: string;
}
/** Verdict for a single candidate after evaluating its manifest. */
export interface PluginManifestVerdict {
    packageName: string;
    /** Short id derived from the package name, e.g. "anthropic" for "@elizaos/plugin-anthropic". */
    shortId: string;
    /** True when shouldEnable() returned truthy. */
    enabled: boolean;
    /** True when shouldForce() returned truthy or `manifest.force === true`. */
    force: boolean;
    /** Capabilities declared in package.json. */
    capabilities: string[];
    /** Human-readable reason for the verdict — used for `[eliza] Plugin auto-enable: ...` log lines. */
    reason: string | null;
    /** When non-null the manifest existed but the check module failed to load/run; the plugin is treated as not-enabled. */
    error: string | null;
}
/**
 * Derive the short id used for `plugins.allow` and `plugins.entries` lookups.
 * Mirrors the logic in plugin-auto-enable-engine.addToAllowlist.
 */
export declare function pluginShortId(packageName: string): string;
/**
 * Read `package.json` for a candidate and extract the elizaos.plugin block.
 * Returns null when no package.json exists or it doesn't declare an elizaos.plugin block.
 */
export declare function readPluginPackageManifest(packageRoot: string): Promise<PluginPackageManifest | null>;
/**
 * Evaluate one candidate's manifest against the runtime context. Pure
 * verdict — caller decides how to apply it to the allow list / force overrides.
 */
export declare function evaluatePluginManifest(candidate: PluginManifestCandidate, ctx: PluginAutoEnableContext): Promise<PluginManifestVerdict | null>;
/**
 * Evaluate every candidate. Verdicts come back in the same order as the input.
 * Failures are reported in the verdict's `error` field — this function never
 * throws so a single bad manifest can't kill auto-enable for the rest.
 */
export declare function evaluatePluginManifests(candidates: PluginManifestCandidate[], ctx: PluginAutoEnableContext): Promise<PluginManifestVerdict[]>;
/**
 * Apply manifest verdicts to a config: push enabled plugins onto
 * `plugins.allow` (with the short id and full package name), set
 * `plugins.entries[shortId].enabled = true` for forced ones, and append
 * human-readable strings to `changes` for log surfacing.
 */
export declare function applyPluginManifestVerdicts(config: Partial<ElizaConfig>, verdicts: PluginManifestVerdict[], changes: string[]): void;
