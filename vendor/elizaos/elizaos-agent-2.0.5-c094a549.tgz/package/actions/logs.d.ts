/**
 * LOGS — polymorphic action for log inspection.
 *
 *   search    → GET /api/logs   (filter by source/level/tag/since; the log buffer
 *                                lives on server state, not the runtime, so this
 *                                runs in process when no listener is bound)
 *   delete    → DELETE /api/logs (clears the in-memory log buffer; over HTTP only,
 *                                and refused when no listener is bound)
 */
import { type Action } from "@elizaos/core";
export declare const logsAction: Action;
