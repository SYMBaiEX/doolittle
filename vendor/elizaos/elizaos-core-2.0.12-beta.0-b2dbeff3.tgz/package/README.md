# @elizaos/core

The Node runtime kernel: plugin registration, authorization, state composition,
model dispatch, memory, cancellation and effect settlement.

Use `@elizaos/core` for the Node runtime and `@elizaos/core/protocol` for
browser-safe contracts and pure helpers. Renderer speech consumers use
`@elizaos/core/speech` for speech text helpers and structured errors without
loading the complete protocol catalog; task choice widget consumers use
`@elizaos/core/task-widgets` the same way. Internal modules import their defining
files directly. Implementation leaves are private; JSON catalog assets retain
explicit data exports. Hosts compose database adapters, model providers and
`@elizaos/plugin-assistant` explicitly.

`@elizaos/core/read-memo` exposes the same `SingleFlightMemo` used by runtime
reads. Hosts retain owner-scoped keys and source invalidation; rejected reads
evict themselves so the next explicit read can retry.

Browser log sinks use `@elizaos/core/logging` for the canonical logger types and
credential redaction. `@elizaos/core/view-interaction` exposes renderer routing
and completed-action handoff contracts without the full protocol catalog.
`@elizaos/core/schema-types` exposes the JSON value, action-parameter schema,
generated-object schema and view-capability types as a type-only leaf entry.

Model providers use request guards from `@elizaos/core`. The protocol entry
exports only their types, so browser code does not load the Node turn context.

HTTP lifecycle, native platform detection and library policy, build variants,
process guards, restart, application configuration and boot environment resolution live
in `@elizaos/host`, with browser-safe configuration in `@elizaos/host/protocol`.
Portable acoustic processing lives in `@elizaos/voice`.
Cross-domain DTOs and validation live in `@elizaos/contracts`. Core imports none
of these owners.

Runtime settings are per-agent. Explicit host environment fallbacks remain for
the secret/PII master switches and process execution policies; per-agent switch
values take precedence. Model context, authorization evidence and effect receipts
remain complete. Source restoration requires its original authorized binding.

Pass-through model results honor cancellation when their lazy `text` promise is
consumed, including after the provider body completes or while finish metadata
is pending. Cancelled text rejects with the owning signal's original reason.

`asRecord` accepts plain records; `asObjectRecord` also accepts class and built-in
object instances. Both reject arrays and null. `hasPlainObjectTag` checks the
object tag. Persisted canonical JSON bytes retain their existing meaning;
`stableJsonString` returns `undefined` for JSON-invisible root values.

From the repository root:

```bash
bun run --cwd packages/core build
bun run --cwd packages/core test
bun run --cwd packages/core typecheck
bun run --cwd packages/core lint:check
bun run verify
```

The browser-safe protocol exports `TaskEventReader` and `mergeTaskEventPage` for
read-only task activity feeds. Inject a task ID/cursor read transport and a state
observer; call `start(taskId)`, `refresh()` for explicit retry, and `stop()` on
teardown. The reader validates every page against the shared event protocol,
retains admitted history on failure, fences stale replies across task switches,
and polls until a terminal task has no unknown outcome. It never runs task actions.
Hosts own activity labels, layout, reading position, error copy, and task-control
refresh policy. Observer snapshots are detached from the admitted history.

`admitTaskChoiceResponse` in the browser-safe protocol barrel validates optional reply widgets, enforces a host-supplied count limit and binds every widget to the requesting task ID/epoch. It returns detached widget data. Hosts retain count policy, UI and error wording; successful admission grants no execution authority.

Integration checks live in `test/`; unit `.test.ts` files have been removed from
`src/`. Packed-consumer verification exercises published exports and runtime
initialization. Live model checks remain opt-in.
